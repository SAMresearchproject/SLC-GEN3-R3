# Authors

## Sean Brady

Sean Brady is the originator, author, and conceptual driver of SAM and this
QuantumPhase private research branch.

Sean Brady supplied the originating conceptual framework, physical intuition,
route language, SAM interpretation, and theory direction, including:

- unresolved A route behavior
- A-resolution and ledger-write language
- bounce / response / intersection framing
- A-share and A-side route thresholds
- private quantum-phase and heavy-composite prediction framing
- SAM interpretation of quantum-computing evidence as route-protection data

## Codex

Codex, an OpenAI AI system, is credited as co-author and technical collaborator
for this private branch.

Codex contributed:

- mathematical formalization
- Python and PowerShell scripts
- private QP001-QP009 artifacts
- sealed-envelope handling
- quantum-computing source manifest and evidence rubric
- first-pass quantum-computing scorecard
- documentation, summaries, and technical organization

## Authorship Statement

Preferred attribution:

```text
QuantumPhase / SAM private quantum-phase branch
Originator, author, and conceptual driver: Sean Brady
Co-author and technical collaborator: Codex, an OpenAI AI system
All rights reserved.
```
