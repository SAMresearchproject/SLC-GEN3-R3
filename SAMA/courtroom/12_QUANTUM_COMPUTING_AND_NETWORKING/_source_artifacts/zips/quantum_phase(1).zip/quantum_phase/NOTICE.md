# Notice

This repository is private research material for the SAM / QuantumPhase branch.

## Rights And Attribution

Original SAM / QuantumPhase material:

```text
Originator, author, and conceptual driver: Sean Brady
Co-author and technical collaborator: Codex, an OpenAI AI system
Copyright (c) 2026 Sean Brady. All rights reserved.
```

## Third-Party Source Snapshots

The `data/quantum_computing/snapshots/` folder may contain local research
snapshots of third-party public web pages, documentation, PDFs, reports, or
source references.

Those snapshots are included only for private research provenance and evidence
tracking. They are not original SAM / QuantumPhase works and are not relicensed
by this repository.

Each third-party source remains subject to its own copyright, license, terms,
and owner rights.

## Private Repository Intent

This repository is intended to remain private unless Sean Brady explicitly
chooses otherwise.

Do not redistribute, mirror, train on, or publish this repository or its
contents without written permission from Sean Brady.
