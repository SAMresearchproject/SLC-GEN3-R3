# FUS001 Preflight - Shared Response Closure Metric Freeze

## Mode

```text
FORWARD_APPLICATION_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = False
confirmation_or_double_check = False
new_forward_work = True
```

FUS001 does not rerun CH034 or QGA063-QGA067. It reads their existing artifacts
and freezes a first SAM-native fusion application metric.

## Question

```text
Can CH034 shared-plate fusion-toy metrics be restated as response-geometry
metrics in the QGA063-QGA067 interaction language?
```

## Claim Boundary

```text
reactor design = not claimed
net energy = not claimed
fusion rate = not claimed
binding energy = not claimed
external fusion data used = false
```

## Selection Rule

```text
selected shared response metric iff:
  branch == shared_plate
  shared_closure_score > 0
  response_burden_delta > 0
  slide_efficiency > 0
  fusion_candidate_status == FUSION_SLIDE_CANDIDATE
```

Baselines and rows with negative burden/slide remain controls.
