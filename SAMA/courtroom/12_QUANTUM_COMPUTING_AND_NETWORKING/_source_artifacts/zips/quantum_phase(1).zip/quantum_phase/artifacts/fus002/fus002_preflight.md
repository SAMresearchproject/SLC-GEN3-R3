# FUS002 Preflight - A-Window Pulse Scan

## Mode

```text
FORWARD_APPLICATION_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = False
confirmation_or_double_check = False
new_forward_work = True
```

FUS002 does not rerun CH034 or FUS001. It reads the existing CH034 A-frequency
ramp artifacts and the FUS001 metric freeze, then classifies native A windows
for shared-response closure screening.

## Question

```text
Does the SAM-native A window around A_SHARE identify a shared-closure region
before destructive high-A reorganization?
```

## Required Bands

```text
A0 = 0.026525823848649224
A_SIDE = 1/24
A_SHARE = 1/12
A = 0.20
A = 0.99
```

No external fusion data and no fitted parameters are used.
