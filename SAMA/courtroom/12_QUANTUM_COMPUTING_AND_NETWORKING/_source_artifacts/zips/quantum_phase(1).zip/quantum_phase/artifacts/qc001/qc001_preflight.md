# QC001 Preflight - Particle-Informed Paul Revere Carrier Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = False
confirmation_or_double_check = False
new_forward_work = True
```

QC001 does not rerun QP012B, QP016, QP037, QP038, QP061, or the Phase 4
particle tables. It reads their frozen artifacts as inputs and builds a new
quantum-computing carrier selector.

## Question

```text
Which SAM-native particle/route family is the best physical carrier for the
Paul Revere pre-resolution letter?
```

## Selector Inputs

```text
artifacts/qp012b/qp012b_route_lead_table.csv
artifacts/qp016/qp016_stable_mode_selector_table.csv
artifacts/qp037/qp037_particle_identity_freeze_table.csv
artifacts/qp038/qp038_identity_composite_boundary_table.csv
phase4_tables/phase4_parameter_free_particle_table.csv
phase4_tables/phase4_particle_periodic_matrix.csv
artifacts/qp061/qp061_summary.json
```

## Native Separation Rule

```text
letter carrier       = route that maximizes pre-resolution lead while preserving unresolved closure
control envelope     = controllable interaction lane that can expose/read without being the carrier
boundary sensor      = route that reports reorganization pressure without final-outcome leakage
material support     = composite/triadic lane that holds apparatus structure
```

No external quantum hardware data and no fitted weights are used.
