# QC002 Preflight

```text
gate = QC002_PRIVATE_CARRIER_ENVELOPE_SEPARATION_LAW
test_type = FORWARD_MODEL_BUILD
is_audit_or_retest = false
confirmation_or_double_check = false
new_external_hardware_data = false
free_parameters_allowed = 0
generated_at_utc = 2026-06-09T16:42:57.676424+00:00
```

QC002 uses QC001 as the selected carrier/envelope/sensor source and imports
QN006, QN012, and QN013 as already-frozen letter-safety machinery.

Required inputs:

```text
artifacts\qc001\qc001_summary.json
artifacts\qc001\qc001_particle_informed_carrier_selector.csv
artifacts\qc001\qc001_carrier_envelope_support_stack.csv
artifacts\qn006\letter_safe_correction_rules.csv
artifacts\qn012\paul_revere_self_correction_map.csv
artifacts\qn013\sam_qn_live_data_validation_rules.csv
artifacts\qn013\sam_qn_trial_score_rules.csv
```
