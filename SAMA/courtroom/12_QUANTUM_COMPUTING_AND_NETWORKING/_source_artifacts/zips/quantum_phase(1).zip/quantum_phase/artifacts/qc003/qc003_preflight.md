# QC003 Preflight

```text
gate = QC003_PRIVATE_PARTICLE_INFORMED_NATIVE_GATE_CATALOG
test_type = FORWARD_MODEL_BUILD
is_audit_or_retest = false
confirmation_or_double_check = false
new_external_hardware_data = false
free_parameters_allowed = 0
generated_at_utc = 2026-06-09T16:54:13.037291+00:00
```

QC003 promotes the QC002 primitive rows into a native gate catalog. It does not
rerun QC002 and does not use external hardware data.

```text
artifacts\qc002\qc002_summary.json
artifacts\qc002\qc002_gate_primitive_catalog.csv
artifacts\qc002\qc002_gate_boundary_conditions.csv
artifacts\qc002\qc002_pre_write_leakage_firewall.csv
artifacts\qn013\sam_qn_trial_score_rules.csv
```
