# QC004 Preflight

```text
gate = QC004_PRIVATE_PAUL_REVERE_READOUT_PROTOCOL
test_type = FORWARD_MODEL_BUILD
is_audit_or_retest = false
confirmation_or_double_check = false
new_external_hardware_data = false
free_parameters_allowed = 0
generated_at_utc = 2026-06-09T16:56:31.254093+00:00
```
