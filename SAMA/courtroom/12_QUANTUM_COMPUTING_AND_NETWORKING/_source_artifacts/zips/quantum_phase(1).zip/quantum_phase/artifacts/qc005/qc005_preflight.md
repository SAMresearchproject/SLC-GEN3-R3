# QC005 Preflight

```text
gate = QC005_PRIVATE_MATERIAL_ISOTOPE_SUPPORT_FILTER
test_type = FORWARD_MODEL_BUILD
is_audit_or_retest = false
confirmation_or_double_check = false
new_external_hardware_data = false
new_external_source_intake = false
free_parameters_allowed = 0
generated_at_utc = 2026-06-09T16:59:13.682713+00:00
```
