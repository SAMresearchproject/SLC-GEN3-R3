# QN002 Preflight - Private Link Survival And Contact Suppression Law

## Mode

```text
FORWARD_NETWORK_LINK_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN002 does not rerun QN001, QP013, or QP014. It imports their frozen outputs and
builds the first SAM-native quantum-network link survival score.

## Question

```text
Can a network link be scored by no-write survival, A-contact suppression, and
carrier route capacity?
```

## Success Condition

```text
The selected carrier survives as unresolved state across a segment without
requiring final route identity to be known.
```

No external quantum-network hardware data and no fitted link parameters are
introduced.
