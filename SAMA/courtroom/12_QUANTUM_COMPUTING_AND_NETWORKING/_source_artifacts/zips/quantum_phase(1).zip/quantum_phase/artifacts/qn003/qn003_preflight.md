# QN003 Preflight - Private Ledger-Safe Relay / Repeater Law

## Mode

```text
FORWARD_NETWORK_RELAY_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN003 does not rerun QN001, QN002, or QP015. It imports their frozen outputs and
builds the first SAM-native relay/repeater law.

## Question

```text
What does a SAM repeater copy, and what must it never copy?
```

## Success Condition

```text
The relay transfers route pressure / syndrome structure while preserving the
forbidden final-outcome boundary.
```

No external quantum-network hardware data and no fitted relay parameters are
introduced.
