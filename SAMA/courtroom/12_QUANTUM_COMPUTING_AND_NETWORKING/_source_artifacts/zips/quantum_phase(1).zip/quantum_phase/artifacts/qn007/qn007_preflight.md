# QN007 Preflight - Earth-A Deployment Surface

## Mode

```text
FORWARD_EARTH_A_DEPLOYMENT_SURFACE_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN007 does not rerun QN001-QN006. It imports frozen outputs and separates
literal Earth gravitational A from apparatus-supplied network controls.

## Question

```text
At Earth A, which network controls must be supplied by apparatus rather than
literal gravitational A?
```

## Success Condition

```text
The campaign separates fixed Earth A from engineered A-contact, shielding,
cooling, timing, and geometry controls.
```

No external quantum-network hardware data and no fitted deployment parameters
are introduced.
