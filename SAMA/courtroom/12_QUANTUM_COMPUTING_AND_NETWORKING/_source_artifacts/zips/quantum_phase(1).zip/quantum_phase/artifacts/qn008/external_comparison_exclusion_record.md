# External Comparison Exclusion Record - QN008

## Status

```text
QN008_SEALED_LAB_BENCHMARK_MANIFEST_FROZEN
```

QN008 freezes the internal SAM quantum-network package before external
quantum-network benchmark comparison.

## Exclusion Rule

```text
No external quantum-network hardware data, rate records, distance records,
commercial protocol performance claims, or platform-specific benchmark values
enter QN001-QN008.
```

External comparison may begin only after this manifest.

## Frozen Benchmark Objects

```text
benchmark_rows = 8
sealed_hash_rows = 14
gate_check_passes = 40/40
wrong_control_passes = 32/32
```

## Allowed Later Comparison Questions

```text
Does a candidate platform preserve unresolved carrier state?
Can it transport allowed syndrome/stress/timing letters without final-outcome leakage?
Can it perform real-time correction before the A_SHARE/write window closes?
Can it separate carrier, envelope, sensor, relay, ledger node, and support roles?
Does its deployment supply apparatus controls rather than relying on literal Earth A?
```

## Sealed Source Hashes

See:

```text
artifacts/qn008/sealed_qn_artifact_hash_manifest.csv
```
