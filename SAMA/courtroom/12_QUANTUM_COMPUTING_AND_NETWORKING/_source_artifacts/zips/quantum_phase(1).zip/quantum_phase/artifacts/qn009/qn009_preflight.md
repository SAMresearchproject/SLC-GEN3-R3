# QN009 Preflight - Benchmark Comparator Schema

## Mode

```text
FORWARD_BENCHMARK_COMPARATOR_SCHEMA_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN009 does not rerun QN001-QN008 and does not import external hardware data.
It converts the sealed QN008 benchmark manifest into a comparator schema for
later approved external review.

## Question

```text
Can SAM define the candidate-hardware comparison grammar before any candidate
hardware data enters the branch?
```

## Success Condition

```text
All benchmark rows, role maps, leakage blockers, and comparison statuses are
frozen with no platform claims, no ranking weights, and no external data.
```
