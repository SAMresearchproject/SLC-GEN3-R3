# QN010 Preflight - Approved External Benchmark Comparison

## Mode

```text
FORWARD_APPROVED_EXTERNAL_BENCHMARK_COMPARISON
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
external_data_allowed = true
```

QN010 does not rerun QN001-QN009. QN009 already froze the comparator schema.
QN010 is the first gate where external quantum-network platform facts enter,
and every external fact must be source-manifested before comparison.

## Question

```text
Which current quantum-network platform families line up best with the sealed
SAM QN001-QN009 comparator?
```

## Success Condition

```text
Every candidate comparison row cites external source IDs, uses the frozen
QN009 status vocabulary, triggers SAM_BLOCKER for forbidden leakage if present,
and introduces no fitted platform weights.
```
