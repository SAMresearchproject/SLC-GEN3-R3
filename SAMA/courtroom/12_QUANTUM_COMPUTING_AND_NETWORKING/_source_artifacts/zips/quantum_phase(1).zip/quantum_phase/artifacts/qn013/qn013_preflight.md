# QN013 Preflight - Live Data Ingestion and Scoring Protocol

## Mode

```text
FORWARD_LIVE_DATA_INGESTION_SCORING_PROTOCOL
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN013 does not rerun QN001-QN012. It builds the live ingestion/scoring engine
for the QN012 blank data package. Demo rows are synthetic protocol fixtures
used to prove the scorer mechanics; they are not external benchmark data.

## Question

```text
Can SAM ingest a filled QN012-style data package and score self-correction by
Paul Revere letters without reading the final answer before write?
```

## Success Condition

```text
The scorer returns PASS/PARTIAL/NOT_READY/SAM_BLOCKER from package validity,
temporal order, self-correction evidence, route-surface readiness, and leakage
firewall rules.
```
