# QP022C Preflight - Lane Separation Rule

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

## Question

```text
Can neutral, charged, and transition lanes be separated from endpoint route
grammar plus the QP022B derived hub support, without using QP004 role labels as
selector inputs?
```

## Selector Inputs

```text
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp022b/qp022b_hub_support_edges.csv
artifacts/qp022b/qp022b_summary.json
```

QP004 is comparison only.

## Pass

```text
exactly three lanes are selected
each lane has exactly two endpoint routes
all six lane edges are hub-supported
the derived lane pair sets match QP004 exactly when compared after selection
```

## Boundary

```text
lanes are partly recovered but one endpoint class remains ambiguous.
```

## Failure

```text
lane separation conflicts with the lower route grammar or QP004 comparison.
```
