# QP022D Preflight - Derived-Topology Replay

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP022D is not checking whether QP017B was correct. It asks whether the role
selector shape that QP017B needed can now be replayed using QP022-derived
topology rather than imported QP004 topology.

## Selector Inputs

```text
artifacts/qp016/qp016_stable_mode_selector_table.csv
artifacts/qp022b/qp022b_summary.json
artifacts/qp022c/qp022c_summary.json
artifacts/qp022c/qp022c_endpoint_lane_table.csv
artifacts/qp022c/qp022c_lane_separation_table.csv
```

## Explicitly Not Used As Selector

```text
artifacts/qp004/*
artifacts/qp017/qp017_stable_mode_role_operator_bridge.csv role/operator columns
audits/private_hostile_qp010_qp021/*
```

## Question

```text
Can the QP016 stable/boundary surface plus QP022-derived topology select the
same stable anchor, boundary bridge, and charged carrier separation that QP017B
previously required?
```
