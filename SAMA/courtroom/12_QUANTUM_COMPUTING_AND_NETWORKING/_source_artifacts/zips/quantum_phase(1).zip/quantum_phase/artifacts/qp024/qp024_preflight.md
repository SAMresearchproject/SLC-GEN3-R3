# QP024 Preflight - Open Slot Promotion Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP024 starts from the QP023 open-slot inventory and asks whether any held-open
particle slots promote under already-native SAM thresholds.

## Selector Inputs

```text
artifacts/qp023/qp023_open_slot_inventory.csv
artifacts/qp023/qp023_summary.json
artifacts/qp016/qp016_summary.json
```

## Question

```text
Do any held-open slots clear A_SIDE or A_SHARE now, and if not, which open
slots are the highest-pressure frontier for the next forward gate?
```
