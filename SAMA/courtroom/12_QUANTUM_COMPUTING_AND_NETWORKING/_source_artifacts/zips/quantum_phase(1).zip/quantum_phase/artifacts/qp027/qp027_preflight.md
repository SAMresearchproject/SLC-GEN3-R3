# QP027 Preflight - Route Exposure Residual Crumb Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP027 starts from the QP026 remaining residual after `A0 / (R + 2^D)` and tests
whether QP001 route-exposure crumbs account for that remainder.

## Selector Inputs

```text
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp026/qp026_summary.json
artifacts/qp026/qp026_residual_closure_table.csv
```

## Sealed Candidate Family

```text
all unique QP001 route-exposure subsets with subset size 1, 2, or 3
```

No multiplicities are allowed. QP027 may add each route exposure at most once.

## Question

```text
Does the QP026 remainder match a native route-exposure crumb bundle, and does
that bundle close A_SIDE or leave a smaller residual?
```
