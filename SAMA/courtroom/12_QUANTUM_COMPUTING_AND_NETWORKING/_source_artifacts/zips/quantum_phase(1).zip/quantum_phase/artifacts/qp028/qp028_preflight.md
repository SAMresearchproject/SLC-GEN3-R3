# QP028 Preflight - Ultra Residual Floor Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP028 starts from the QP027 ultra-residual and tests whether any whole QP001
route-exposure quantum can be added without overshooting `A_SIDE`.

## Selector Inputs

```text
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp027/qp027_summary.json
artifacts/qp027/qp027_stable_residual_chain_table.csv
```

## Question

```text
Is the QP027 ultra-residual above or below the smallest available QP001 route
exposure floor?
```
