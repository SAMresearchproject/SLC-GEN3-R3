# QP031 Preflight - Boundary Floor Open Slot Propagation Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP031 does not rerun QP024-QP030. It applies the QP030-selected boundary-floor
role to the existing open particle-slot and lane-prefix surfaces.

## Selector Inputs

```text
artifacts/qp024/qp024_open_slot_frontier_table.csv
artifacts/qp025/qp025_lane_reinforcement_table.csv
artifacts/qp025/qp025_open_prefix_reinforcement_table.csv
artifacts/qp030/qp030_summary.json
artifacts/qp030/qp030_role_decision_table.csv
```

## Application Rule

```text
APPLY_BOUNDARY_FLOOR_BEFORE_ROUTE_CRUMBS
```

Boundary-floor propagation is tested before route crumbs. Route crumbs are only
reported on the lane where QP030's mechanism chain already exists.

## Question

```text
Does the selected boundary-inventory floor promote any open particle slot, or
does it propagate only as lane-level ledger support?
```
