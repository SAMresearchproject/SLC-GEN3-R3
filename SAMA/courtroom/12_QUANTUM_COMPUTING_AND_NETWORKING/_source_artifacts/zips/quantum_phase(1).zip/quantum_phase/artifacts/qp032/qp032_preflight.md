# QP032 Preflight - Ultra Residual W/I Mismatch Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP032 does not rerun QP030 or QP031. It starts from the QP031 lane-support
limit and asks whether the remaining ultra residual is the mismatch between the
half-write target and the information-return support.

## Selector Inputs

```text
artifacts/core/phase_field_engine_summary.json
artifacts/qp030/qp030_summary.json
artifacts/qp031/qp031_summary.json
artifacts/qp031/qp031_lane_boundary_floor_summary.csv
artifacts/qp031/qp031_slot_boundary_floor_propagation_table.csv
```

## W/I Closure Definition

```text
W_target = A_SIDE
I_return = stable lane after boundary floor plus allowed route crumbs
W/I mismatch = W_target - I_return
```

## Question

```text
Is the QP031 ultra residual a W/I mismatch boundary, an additive route
continuation, or a single-slot promotion deficit?
```
