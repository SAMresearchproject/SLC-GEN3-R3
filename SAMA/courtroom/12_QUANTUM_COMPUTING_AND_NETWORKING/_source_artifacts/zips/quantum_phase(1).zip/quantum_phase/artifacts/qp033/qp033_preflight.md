# QP033 Preflight - Slot W/I Self-Support Table

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP033 does not rerun QP031 or QP032. It applies the Phase 3 rule that particle
identity requires write-anchor / information-return self-support.

## Selector Inputs

```text
artifacts/qp024/qp024_open_slot_frontier_table.csv
artifacts/qp031/qp031_lane_boundary_floor_summary.csv
artifacts/qp031/qp031_slot_boundary_floor_propagation_table.csv
artifacts/qp032/qp032_summary.json
artifacts/qp032/qp032_wi_closure_decision_table.csv
```

## W/I Slot Rule

```text
W_slot = open slot support after boundary floor
I_return_slot = lane information return distributed by native slot share
W/I self-support score = 1 - abs(W_slot - I_return_slot) / max(W_slot, I_return_slot)
fixed point contact = abs(W_slot - I_return_slot) <= QP032 W/I mismatch
```

No fitted weights are introduced.

## Question

```text
Which open slots have the strongest W/I self-support, and does any slot reach
the QP032 fixed-point mismatch scale?
```
