# QP034 Preflight - Lane Support vs Particle Identity Separator

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP034 does not rerun QP031-QP033. It separates collective lane support from
localized particle identity using the W/I mismatch and slot self-support outputs.

## Selector Inputs

```text
artifacts/qp031/qp031_lane_boundary_floor_summary.csv
artifacts/qp032/qp032_summary.json
artifacts/qp033/qp033_summary.json
artifacts/qp033/qp033_slot_wi_self_support_table.csv
```

## Question

```text
Why can the stable lane reach the route-floor limit while no open particle slot
promotes?
```
