# QP035 Preflight - Half-Write / Information Fixed-Point Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP035 does not rerun QP032-QP034. It applies the Phase 3 fixed-point concept to
the open-slot W/I table.

## Selector Inputs

```text
artifacts/qp032/qp032_summary.json
artifacts/qp033/qp033_slot_wi_self_support_table.csv
artifacts/qp034/qp034_summary.json
artifacts/qp034/qp034_lane_identity_separation_table.csv
```

## Fixed-Point Conditions

```text
direct W/I contact:      abs(W_slot - I_return_slot) <= ultra residual
half-split contact:      abs(W_slot/2 - I_return_slot/2) <= ultra residual
closure complement:      abs((W_slot/2 + I_return_slot/2) - A_SIDE) <= ultra residual
```

No fitted weights are introduced.

## Question

```text
Does any open slot satisfy a native half-write / information-return fixed-point
condition, or is a local return correction still missing?
```
