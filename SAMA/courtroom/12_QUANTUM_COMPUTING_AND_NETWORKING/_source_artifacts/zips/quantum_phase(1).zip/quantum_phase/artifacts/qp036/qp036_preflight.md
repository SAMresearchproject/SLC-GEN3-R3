# QP036 Preflight - Local Information-Return Correction Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP036 does not rerun QP032-QP035 and does not check whether those results were
right. It uses the QP035 missing local-return correction as the next forward
target.

## Selector Inputs

```text
artifacts/core/phase_field_engine_summary.json
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp026/qp026_native_residual_candidate_table.csv
artifacts/qp030/qp030_summary.json
artifacts/qp031/qp031_summary.json
artifacts/qp035/qp035_summary.json
artifacts/qp035/qp035_fixed_point_selector_table.csv
artifacts/qp035/qp035_local_return_correction_table.csv
```

## Candidate Families

```text
native denominator ratios from QP026
whole QP001 route-exposure bundles up to three routes
selected QP030/QP031 residual-chain return scales
local return reservation:
    residual_after_floor * R*(D + alpha_H) - minimum_route_exposure * R
```

The return-reservation family is predeclared here because QP035 identifies a
local information return, not another global lane push. It uses only quantities
already selected before QP036:

```text
residual_after_floor       from QP030
R, D, alpha_H              from the core phase engine
minimum_route_exposure     from QP030/QP031
```

No fitted weights are introduced.

## Question

```text
Does SAM/QP contain a native local return correction that can reduce strong
W/I support to fixed-point particle identity?
```
