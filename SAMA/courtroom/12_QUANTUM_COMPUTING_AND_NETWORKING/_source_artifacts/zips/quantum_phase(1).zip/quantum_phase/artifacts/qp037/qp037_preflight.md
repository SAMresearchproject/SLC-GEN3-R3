# QP037 Preflight - Particle Identity Closure Freeze

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP037 does not rerun QP032-QP036. It freezes the identity status implied by the
QP036 selected local return correction.

## Selector Inputs

```text
artifacts/qp035/qp035_fixed_point_selector_table.csv
artifacts/qp036/qp036_summary.json
artifacts/qp036/qp036_local_return_candidate_table.csv
artifacts/qp036/qp036_slot_application_table.csv
```

## Freeze Rule

```text
Use only the QP036 selected correction.
Apply it only to the lane for which QP036 selected it, unless the candidate is
marked ANY.
Promote a slot only when corrected_WI_delta <= QP032/QP036 ultra residual.
Keep per-slot alternate candidate contacts out of the freeze decision.
```

No fitted weights are introduced.

## Question

```text
Which slots promote, remain held open, or are blocked under W/I closure after
the selected local return correction?
```
