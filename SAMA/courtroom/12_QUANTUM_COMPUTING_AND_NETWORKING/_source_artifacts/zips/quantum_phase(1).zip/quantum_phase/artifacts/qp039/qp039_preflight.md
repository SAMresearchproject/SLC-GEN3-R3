# QP039 Preflight - W/I Identity to Composite Return Channel Selector

```text
test_id = QP039
test_name = PRIVATE_WI_IDENTITY_TO_COMPOSITE_RETURN_CHANNEL_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp037/qp037_particle_identity_freeze_table.csv
artifacts/qp038/qp038_summary.json
artifacts/qp038/qp038_identity_composite_boundary_table.csv
artifacts/qp006/qp006_heavy_composite_slot_priority_table.csv
phase4_tables/phase4_composite_support_table.csv
phase4_tables/phase4_composite_scaffold_table.csv
phase4_tables/phase4_blank_registry.csv
```

## Expected Outputs

```text
artifacts/qp039/qp039_summary.json
artifacts/qp039/qp039_return_channel_table.csv
artifacts/qp039/qp039_scaffold_join_table.csv
artifacts/qp039/qp039_composite_support_channel_table.csv
artifacts/qp039/qp039_composite_role_queue_table.csv
artifacts/qp039/qp039_blank_delta_table.csv
docs/reports/QP039_PRIVATE_WI_IDENTITY_TO_COMPOSITE_RETURN_CHANNEL_SELECTOR.md
```

## Forward Question

```text
How does a frozen local W/I identity become a many-SW composite return channel?
```

## Selector Rule

A return channel is selected only when:

```text
local W/I identity is PROMOTED
identity class = LOCAL_RETURN_WI_FIXED_POINT_IDENTITY
QP038 boundary status = LOCAL_IDENTITY_PROMOTED_COMPOSITE_BINDING_HELD_OPEN
both q anti-q scaffold orientations exist in the Phase 4 scaffold table
native composite strength remains below A-share
composite priority class remains P3_SCAFFOLD_HELD_OPEN
```

This fills a bridge blank. It does not emit a composite mass readout.
