# QP040 Preflight - Native Binding Residue Operator

```text
test_id = QP040
test_name = PRIVATE_NATIVE_BINDING_RESIDUE_OPERATOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp039/qp039_summary.json
artifacts/qp039/qp039_return_channel_table.csv
artifacts/qp039/qp039_composite_support_channel_table.csv
artifacts/qp039/qp039_composite_role_queue_table.csv
phase4_tables/phase4_composite_support_table.csv
```

## Expected Outputs

```text
artifacts/qp040/qp040_summary.json
artifacts/qp040/qp040_binding_residue_operator_table.csv
artifacts/qp040/qp040_support_row_replay_without_observed_mass.csv
artifacts/qp040/qp040_scaffold_fill_handoff_table.csv
docs/reports/QP040_PRIVATE_NATIVE_BINDING_RESIDUE_OPERATOR.md
```

## Forward Question

```text
Given a composite scaffold and its constituent SAM masses, what native residue
or return deficit determines whether a bound composite mass readout exists?
```

## Operator Candidate

```text
R_bind(q, D) = 1 / (1 + (A0/2) * q / 2^D)
```

This gate extracts and freezes the common operator form from the selected native
support formulas. It does not use observed composite masses.
