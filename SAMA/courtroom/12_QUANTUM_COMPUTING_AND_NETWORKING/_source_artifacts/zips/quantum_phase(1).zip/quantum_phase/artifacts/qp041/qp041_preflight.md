# QP041 Preflight - Meson Scaffold Fill Pass

```text
test_id = QP041
test_name = PRIVATE_MESON_SCAFFOLD_FILL_PASS
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp040/qp040_summary.json
artifacts/qp040/qp040_binding_residue_operator_table.csv
artifacts/qp039/qp039_composite_role_queue_table.csv
phase4_tables/phase4_composite_support_table.csv
phase4_tables/phase4_composite_scaffold_table.csv
```

## Expected Outputs

```text
artifacts/qp041/qp041_summary.json
artifacts/qp041/qp041_meson_fill_table.csv
artifacts/qp041/qp041_meson_open_boundary_table.csv
artifacts/qp041/qp041_meson_family_fill_map.csv
docs/reports/QP041_PRIVATE_MESON_SCAFFOLD_FILL_PASS.md
```

## Forward Question

```text
Which of the 36 q anti-q meson scaffold slots receive a unique native mass
readout from QP039 and QP040?
```

Rows are filled only from selected native composite support families and the
QP040 binding-residue operator. Observed meson masses are not used.
