# QP041B Preflight - High-Priority Meson Role-Scale Selector

```text
test_id = QP041B
test_name = PRIVATE_HIGH_PRIORITY_MESON_ROLE_SCALE_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp005/qp005_native_composite_interaction_strength_summary.json
artifacts/qp005/qp005_native_composite_interaction_strength_table.csv
artifacts/qp039/qp039_composite_role_queue_table.csv
artifacts/qp040/qp040_summary.json
artifacts/qp041/qp041_summary.json
artifacts/qp041/qp041_meson_open_boundary_table.csv
phase4_tables/phase4_composite_scaffold_table.csv
```

## Expected Outputs

```text
artifacts/qp041b/qp041b_summary.json
artifacts/qp041b/qp041b_high_priority_meson_role_scale_table.csv
artifacts/qp041b/qp041b_pair_role_scale_selector_table.csv
artifacts/qp041b/qp041b_meson_boundary_delta_table.csv
docs/reports/QP041B_PRIVATE_HIGH_PRIORITY_MESON_ROLE_SCALE_SELECTOR.md
```

## Forward Question

```text
Can the QP005 native interaction mass coordinate fill the QP041 high-priority
meson role-scale blanks without using observed meson masses?
```

This gate can fill role-scale coordinates. It does not claim final bound meson
mass readouts unless a binding residue/readout selector is also selected.
