# QP045 Preflight - A-share Microcell Coarse-Grain Selector

```text
test_id = QP045
test_name = PRIVATE_A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp001/qp001_phase_functional_summary.json
artifacts/qp043/qp043_unknown_mode_assignment_table.csv
artifacts/qp044/qp044_summary.json
phase4_tables/phase4_parameter_free_particle_table.csv
```

## Expected Outputs

```text
artifacts/qp045/qp045_summary.json
artifacts/qp045/qp045_microcell_coarse_grain_table.csv
artifacts/qp045/qp045_selector_ladder.csv
artifacts/qp045/qp045_uniform_partition_map.csv
docs/reports/QP045_PRIVATE_A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR.md
```

## Forward Question

```text
How does SAM-UNK-050, the uniform 12 microcell lattice, coarse-grain into one
meaningful A-share/write structure?
```

This gate selects a native coarse-grain law from R=12 and QP001 thresholds. It
does not use observed masses or external particle data.
