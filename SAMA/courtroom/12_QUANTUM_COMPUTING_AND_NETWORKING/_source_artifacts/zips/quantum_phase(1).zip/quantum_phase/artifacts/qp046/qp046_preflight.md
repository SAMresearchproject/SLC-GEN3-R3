# QP046 Preflight - Partition Geometry Lane Selector

```text
test_id = QP046
test_name = PRIVATE_PARTITION_GEOMETRY_LANE_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp045/qp045_uniform_partition_map.csv
artifacts/qp045/qp045_summary.json
artifacts/qp043/qp043_unknown_mode_assignment_table.csv
artifacts/qp022a/qp022a_route_inventory_table.csv
artifacts/qp037/qp037_particle_identity_freeze_table.csv
phase4_tables/phase4_parameter_free_particle_table.csv
```

## Expected Outputs

```text
artifacts/qp046/qp046_summary.json
artifacts/qp046/qp046_partition_geometry_lane_table.csv
artifacts/qp046/qp046_axis_duality_table.csv
docs/reports/QP046_PRIVATE_PARTITION_GEOMETRY_LANE_SELECTOR.md
```

## Forward Question

```text
Given that QP045 showed all uniform divisor partitions of R=12 carry one
A-share, which native partition geometry selects each lane?
```

This is a forward selector gate. It does not rerun QP045 and does not test
prior results; it uses the QP045 law as input and assigns lane meaning from
geometry.
