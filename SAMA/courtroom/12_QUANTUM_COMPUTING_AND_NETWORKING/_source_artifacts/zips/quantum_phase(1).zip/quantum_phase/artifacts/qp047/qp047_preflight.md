# QP047 Preflight - Nuclear Binding and Isotope A-road Selector

```text
test_id = QP047
test_name = PRIVATE_NUCLEAR_BINDING_ISOTOPE_A_ROAD_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
phase4_tables/phase4_element_periodic_atlas.csv
phase4_tables/phase4_a_road_coherence_gate_table.csv
phase4_tables/phase4_composite_support_table.csv
artifacts/qp040/qp040_binding_residue_operator_table.csv
artifacts/qp046/qp046_summary.json
```

## Expected Outputs

```text
artifacts/qp047/qp047_summary.json
artifacts/qp047/qp047_element_a_road_context_table.csv
artifacts/qp047/qp047_a_road_band_summary_table.csv
artifacts/qp047/qp047_nuclear_support_bridge_table.csv
docs/reports/QP047_PRIVATE_NUCLEAR_BINDING_ISOTOPE_A_ROAD_SELECTOR.md
phase4_tables/phase4_element_a_road_context_v1.csv
phase4_tables/phase4_blank_registry_v3.csv
```

## Forward Question

```text
Which element/isotope rows can be filled now as SAM-native A-road formation
context, and which rows still need a nuclear isotope mass-readout selector?
```

This is a forward element-layer fill pass. It does not rerun prior gates and
does not use observed isotope masses or abundance values as selector inputs.
