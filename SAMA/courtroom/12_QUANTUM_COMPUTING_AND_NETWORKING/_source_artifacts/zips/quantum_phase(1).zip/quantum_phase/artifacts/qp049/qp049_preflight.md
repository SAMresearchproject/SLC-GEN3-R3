# QP049 Preflight - Isotope Seed Identity Selector

```text
test_id = QP049
test_name = PRIVATE_ISOTOPE_SEED_IDENTITY_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp048/qp048_summary.json
artifacts/qp047/qp047_element_a_road_context_table.csv
artifacts/qp047/qp047_nuclear_support_bridge_table.csv
phase4_tables/phase4_composite_support_table.csv
phase4_tables/phase4_parameter_free_particle_table.csv
```

## Expected Outputs

```text
artifacts/qp049/qp049_summary.json
artifacts/qp049/qp049_isotope_seed_identity_table.csv
artifacts/qp049/qp049_seed_family_summary_table.csv
artifacts/qp049/qp049_radix_alpha_cycle_table.csv
docs/reports/QP049_PRIVATE_ISOTOPE_SEED_IDENTITY_SELECTOR.md
phase4_tables/phase5_isotope_seed_identity_v1.csv
```

## Forward Question

```text
Can SAM select a native isotope seed identity for each element before isotope
mass/readout, using only proton/neutron/deuteron/alpha support and Z?
```

This is a forward seed selector. It does not use observed isotope masses and
does not emit isotope masses.
