# QP051 Preflight - Neutron Excess Binding Depth Selector

```text
test_id = QP051
test_name = PRIVATE_NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp050/qp050_summary.json
artifacts/qp050/qp050_symmetric_seed_mass_readout_table.csv
artifacts/qp049/qp049_isotope_seed_identity_table.csv
artifacts/qp047/qp047_element_a_road_context_table.csv
artifacts/qp040/qp040_binding_residue_operator_table.csv
```

## Expected Outputs

```text
artifacts/qp051/qp051_summary.json
artifacts/qp051/qp051_neutron_excess_binding_depth_lane_table.csv
artifacts/qp051/qp051_band_depth_selector_summary_table.csv
artifacts/qp051/qp051_binding_operator_selector_summary_table.csv
docs/reports/QP051_PRIVATE_NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR.md
phase4_tables/phase5_neutron_excess_binding_depth_lanes_v1.csv
```

## Forward Question

```text
Given the QP050 symmetric isotope seed surface, what native lane selects
neutron-excess/binding-depth ownership before final isotope mass readout?
```

This is a new forward selector gate. It does not rerun or audit QP050.
