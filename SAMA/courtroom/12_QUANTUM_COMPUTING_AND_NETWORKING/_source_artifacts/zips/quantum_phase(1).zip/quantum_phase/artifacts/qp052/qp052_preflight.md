# QP052 Preflight - Numeric DeltaN and Binding Mass Selector

```text
test_id = QP052
test_name = PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp051/qp051_summary.json
artifacts/qp051/qp051_neutron_excess_binding_depth_lane_table.csv
phase4_tables/phase4_composite_support_table.csv
```

## Expected Outputs

```text
artifacts/qp052/qp052_summary.json
artifacts/qp052/qp052_numeric_deltaN_binding_mass_table.csv
artifacts/qp052/qp052_depth_packet_summary_table.csv
artifacts/qp052/qp052_lane_mass_summary_table.csv
docs/reports/QP052_PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR.md
phase4_tables/phase5_numeric_deltaN_binding_mass_v1.csv
```

## Forward Question

```text
Can SAM convert the QP051 neutron-excess depth lane into closed integer
DeltaN packets and a native bound-neutron mass correction?
```

This is a new forward selector gate. It does not rerun or audit QP051.
