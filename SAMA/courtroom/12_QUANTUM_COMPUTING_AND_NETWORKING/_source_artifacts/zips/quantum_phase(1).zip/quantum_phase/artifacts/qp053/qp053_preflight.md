# QP053 Preflight - Isotope Roster Stability Selector

```text
test_id = QP053
test_name = PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp052/qp052_summary.json
artifacts/qp052/qp052_numeric_deltaN_binding_mass_table.csv
artifacts/qp051/qp051_neutron_excess_binding_depth_lane_table.csv
```

## Expected Outputs

```text
artifacts/qp053/qp053_summary.json
artifacts/qp053/qp053_isotope_roster_stability_lane_table.csv
artifacts/qp053/qp053_residual_twelfths_summary_table.csv
artifacts/qp053/qp053_roster_lane_summary_table.csv
docs/reports/QP053_PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR.md
phase4_tables/phase5_isotope_roster_stability_lanes_v1.csv
```

## Forward Question

```text
Can the QP052 fractional packet residual select isotope roster/stability lanes
without observed isotope masses?
```

This is a new forward roster split. It does not rerun or audit QP052.
