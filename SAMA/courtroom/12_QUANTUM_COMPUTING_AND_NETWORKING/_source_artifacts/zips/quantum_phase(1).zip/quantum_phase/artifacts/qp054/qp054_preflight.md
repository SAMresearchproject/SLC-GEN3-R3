# QP054 Preflight - Isotope Neighbor Ladder Selector

```text
test_id = QP054
test_name = PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp053/qp053_summary.json
artifacts/qp053/qp053_isotope_roster_stability_lane_table.csv
artifacts/qp052/qp052_numeric_deltaN_binding_mass_table.csv
```

## Expected Outputs

```text
artifacts/qp054/qp054_summary.json
artifacts/qp054/qp054_isotope_neighbor_ladder_table.csv
artifacts/qp054/qp054_ladder_role_summary_table.csv
docs/reports/QP054_PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR.md
phase4_tables/phase5_isotope_neighbor_ladder_v1.csv
```

## Forward Question

```text
Can SAM use the residual-twelfths roster lane to generate neighboring isotope
ladder candidates around the QP052 primary candidate?
```

This is a new forward ladder generator. It does not rerun or audit QP053.
