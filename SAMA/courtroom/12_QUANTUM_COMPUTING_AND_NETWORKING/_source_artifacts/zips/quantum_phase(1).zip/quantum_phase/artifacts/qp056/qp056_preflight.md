# QP056 Preflight - Residual Stability Decay Pressure Selector

```text
test_id = QP056
test_name = PRIVATE_RESIDUAL_STABILITY_DECAY_PRESSURE_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
observed_half_lives_used = false
observed_abundance_used_as_selector = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp055/qp055_summary.json
artifacts/qp054/qp054_isotope_neighbor_ladder_table.csv
```

## Expected Outputs

```text
artifacts/qp056/qp056_summary.json
artifacts/qp056/qp056_residual_stability_decay_pressure_table.csv
artifacts/qp056/qp056_decay_pressure_summary_table.csv
artifacts/qp056/qp056_native_preference_summary_table.csv
docs/reports/QP056_PRIVATE_RESIDUAL_STABILITY_DECAY_PRESSURE_SELECTOR.md
phase4_tables/phase5_residual_stability_decay_pressure_v1.csv
```

## Forward Question

```text
Can SAM classify stability/decay pressure from the QP054 residual-twelfths
neighbor ladder without observed isotope masses, half-lives, or abundances?
```

This is a new forward pressure selector. It does not rerun or audit QP054/QP055.
