# QP057 Preflight - Decay Direction and Chain Selector

```text
test_id = QP057
test_name = PRIVATE_DECAY_DIRECTION_AND_CHAIN_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_decay_modes_used = false
observed_half_lives_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp056/qp056_summary.json
artifacts/qp056/qp056_residual_stability_decay_pressure_table.csv
```

## Expected Outputs

```text
artifacts/qp057/qp057_summary.json
artifacts/qp057/qp057_decay_direction_chain_table.csv
artifacts/qp057/qp057_direction_summary_table.csv
docs/reports/QP057_PRIVATE_DECAY_DIRECTION_CHAIN_SELECTOR.md
phase4_tables/phase5_decay_direction_chain_v1.csv
```

## Forward Question

```text
Can SAM select native decay/rebalance direction from the QP056 pressure lanes?
```

This is a new forward direction selector. It does not rerun or audit QP056.
