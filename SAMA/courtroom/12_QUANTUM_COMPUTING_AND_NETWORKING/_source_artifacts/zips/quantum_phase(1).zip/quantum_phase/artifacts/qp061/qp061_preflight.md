# QP061 Preflight - Private Approved Sealed Isotope Comparison

```text
test_id = QP061
test_name = PRIVATE_APPROVED_SEALED_ISOTOPE_COMPARISON
test_type = FORWARD_SEALED_EXTERNAL_COMPARISON
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
external_data_permission_gate = satisfied_by_user_ready_message
explicit_user_approval = I'm ready.
public_repo_write = false
external_data_used = true
external_data_source = IAEA_LiveChart_ground_states_all
observed_isotope_masses_used = true
observed_decay_modes_used = true
observed_half_lives_used = true
observed_abundances_used = true
prediction_manifest_mutation_allowed = false
free_parameters_introduced = 0
```

## Source Inputs

```text
phase4_tables/phase5_sealed_prediction_manifest.csv
phase4_tables/phase5_sealed_hash_manifest.csv
artifacts/qp060/qp060_summary.json
https://nds.iaea.org/relnsd/v1/data?fields=ground_states&nuclides=all
```

## Expected Outputs

```text
artifacts/qp061/qp061_external_source_manifest.csv
artifacts/qp061/qp061_observed_roster_normalized.csv
artifacts/qp061/qp061_sealed_row_comparison.csv
artifacts/qp061/qp061_element_coverage_summary.csv
artifacts/qp061/qp061_lane_summary.csv
artifacts/qp061/qp061_band_summary.csv
artifacts/qp061/qp061_summary.json
docs/reports/QP061_PRIVATE_APPROVED_SEALED_ISOTOPE_COMPARISON.md
```

## Forward Question

```text
What happens when the frozen QP060 Phase 5 isotope prediction manifest is opened
against an approved external isotope ground-state catalogue without refit?
```

This is not an audit, retest, or confirmation rerun. It is the first sealed
external comparison. The QP060 prediction manifest is hash-checked and then
treated as immutable.
