# Private Hostile Audit Plan - QP010-QP021

## Audit Mode

```text
HOSTILE_AUDIT_NOT_FORWARD_GATE
```

This audit does not create new QP gates. It attacks the frozen package.

## Priority Questions

1. Does QP017 legitimately promote stable/boundary modes into role/operator lanes?
2. Does QP018 select particle slots without mixing incompatible lanes?
3. Does QP019 legitimately connect selected slots to QP007/QP008 native mass surfaces?
4. Does QP021 correctly identify a charged parallel-carrier bridge?
5. Is QP010 external clue provenance clearly separated from QP011-QP021 internal bridge work?

## First Pass Output Files

```text
results/001_qp017_role_operator_promotion.md
results/002_qp018_particle_slot_selection.md
results/003_qp019_mass_surface_bridge.md
results/004_qp021_charged_lane_bridge.md
results/005_qp010_provenance_separation.md
AUDIT_VERDICT.md
```

## Finding Template

```text
finding_id:
severity:
surface:
claim_under_attack:
evidence:
attack:
possible_resolution:
retest_needed:
```

## Retest Policy

No retest is run from this audit plan.

Retests can only be proposed in:

```text
suggested_retests/
```

and require explicit approval before execution.
