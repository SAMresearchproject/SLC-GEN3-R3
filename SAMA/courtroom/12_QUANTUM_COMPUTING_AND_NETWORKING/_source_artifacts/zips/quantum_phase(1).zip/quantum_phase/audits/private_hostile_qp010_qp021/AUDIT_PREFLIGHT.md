# Private Hostile Audit Preflight - QP010-QP021

## Status

```text
HOSTILE_AUDIT_REVIEW_ACTIVE_AFTER_APPROVED_RETESTS
```

Active mode has been changed back to:

```text
HOSTILE_AUDIT_REVIEW
```

Approved retest execution is complete. Retest outputs are evidence for hostile
review only; they are not forward QP gates and they do not modify the frozen
package.

Retest execution preflight remains preserved at:

```text
audits/private_hostile_qp010_qp021/RETEST_EXECUTION_PREFLIGHT.md
```

This folder remains the only allowed workspace for audit/retest work on the
frozen QP010-QP021 QuantumPhase package.

The hostile audit first pass is preserved. The active task is now review of the
updated testing record.

## Scope

Audit target:

```text
QP010-QP021 private QuantumPhase bridge package
```

Frozen package claim under attack:

```text
protected unresolved route
-> decoherence / ledger leakage
-> syndrome boundary write
-> pre-resolution route letter
-> A-contact suppression
-> Born-style route weights
-> interference / ledger commit
-> stable mode selector
-> role/operator bridge
-> particle-slot selector
-> native mass-surface bridge
-> charged parallel-carrier bridge
```

## Hard Isolation Rule

All hostile audit outputs must stay under:

```text
audits/private_hostile_qp010_qp021/
```

Allowed audit outputs:

```text
results/
suggested_retests/
evidence/
AUDIT_PREFLIGHT.md
AUDIT_PLAN.md
AUDIT_VERDICT.md
```

Forbidden during hostile audit unless Sean explicitly approves:

```text
editing frozen QP artifacts
editing frozen QP reports
editing QP source scripts
running retests as if they are forward gates
promoting audit findings into the frozen package
rewriting package claims to make them easier to defend
```

## Auditor Posture

The auditor must attack the bridge, not defend the package.

Required posture:

```text
assume a hostile technical reader
prefer finding the break point over preserving the story
separate evidence from interpretation
mark circularity, leakage, hidden selection, and provenance risk
state when a claim is stronger than the artifact supports
```

The auditor may not dismiss a result merely because it is unconventional.

The auditor may mark a result as risky when:

```text
the input is not native to the claimed lane
the selector depends on a downstream outcome
the same artifact serves as both selector and validation
the bridge changes role without a declared rule
the result needs a retest to distinguish success from boundary
```

## Retest Rule

Retests are not allowed to run automatically.

Any retest, verification, replay, or double-check must first produce a file in:

```text
suggested_retests/
```

That file must include:

```text
retest name
reason the retest is necessary
exact artifact under question
what would count as pass
what would count as boundary
what would count as failure
whether the retest can modify frozen package files
```

Default:

```text
retests cannot modify frozen package files
```

## Finding Classes

```text
BLOCKER
MAJOR
MINOR
INFO
RETEST_RECOMMENDED
```

BLOCKER:

```text
The bridge cannot be considered frozen until resolved.
```

MAJOR:

```text
The bridge may survive, but the package claim must be narrowed or tested.
```

MINOR:

```text
Documentation, provenance, or clarity issue that does not currently break the bridge.
```

INFO:

```text
Observation worth recording but not a defect.
```

RETEST_RECOMMENDED:

```text
The audit cannot decide from artifacts alone.
```

## Evidence Rule

Every finding must cite at least one local artifact path.

Preferred evidence targets:

```text
artifacts/qp017/
artifacts/qp018/
artifacts/qp019/
artifacts/qp020/
artifacts/qp021/
docs/reports/PRIVATE_FREEZE_QP010_QP021_HOSTILE_AUDIT_HANDOFF.md
```

## Stop Rule

If a BLOCKER is found, the audit should stop forward packaging and write:

```text
results/BLOCKER_<short_name>.md
```

If no BLOCKER is found, the audit should continue until all priority surfaces
are checked:

```text
QP017 role/operator promotion
QP018 particle-slot selection
QP019 native mass-surface bridge
QP021 charged parallel-carrier bridge
QP010 provenance separation
```

## Honesty Rule

Codex is a co-author and is not a fully independent outside reviewer.

For this audit, Codex must operate under adversarial constraints:

```text
no defense by default
no softening finding language
no package edits during audit
no claiming independence
no treating pleasing narrative as evidence
```
