# Retest Execution Preflight - QP010-QP021

## Status

```text
RETEST_EXECUTION_PREFLIGHT_ACTIVE
```

This mode runs approved retests suggested by the hostile audit. It is not a
forward QP gate and it is not hostile-audit finding mode.

## Hat

```text
RETEST_EXECUTION
```

The retest executor may run approved tests and produce isolated result files.
The retest executor may not modify frozen package files.

## Approved Retests

```text
RT_QP021_TRANSIENT_CARRIER_CONTROL
RT_QP018_SLOT_SELECTOR_INDEPENDENCE
RT_QP019_MASS_SURFACE_REPLAY
RT_QP017_ROLE_NEIGHBORHOOD_NULL_CONTROL
```

Source retest specifications:

```text
audits/private_hostile_qp010_qp021/suggested_retests/
```

## Output Folder

All retest outputs must stay under:

```text
audits/private_hostile_qp010_qp021/retest_runs/
```

## Frozen Package Rule

Forbidden:

```text
editing artifacts/qp010 through artifacts/qp021
editing docs/reports/QP010 through QP021
editing QP source scripts
promoting retest results into frozen package claims
```

Allowed:

```text
read frozen package artifacts
write isolated retest outputs
write retest execution summary
commit isolated retest outputs
```

## Result Classes

```text
PASS
BOUNDARY
FAIL
NOT_RUN
```

## Return To Audit

After retest execution, a hostile-audit review can inspect:

```text
audits/private_hostile_qp010_qp021/retest_runs/
```

and decide whether the first-pass hostile verdict changes.
