# QP017 Boundary Removal Campaign

## Status

```text
HOSTILE_REVIEW_COMPLETE_BOUNDARY_REMOVED_SCOPED
```

This campaign responds to the first hostile-audit retest boundary:

```text
RT_QP017_ROLE_NEIGHBORHOOD_NULL_CONTROL = BOUNDARY
```

The first campaign retest has been executed:

```text
RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR = PASS
```

Output:

```text
audits/private_hostile_qp010_qp021/retest_runs/RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR/
```

## Trigger

Evidence:

```text
audits/private_hostile_qp010_qp021/retest_runs/RT_QP017_ROLE_NEIGHBORHOOD_NULL_CONTROL/summary.json
```

Boundary result:

```text
real_map_promotes_expected_pair = true
wrong_controls_reproducing_expected_pair = 20
controls_run = 27
```

Meaning:

```text
QP017's current role-neighborhood bridge finds the expected pair,
but the selector is too broad to claim specificity.
```

## Campaign Purpose

Remove or preserve the QP017 boundary responsibly.

The campaign must decide whether QP017 can be sharpened from:

```text
coarse role-neighborhood bridge
```

to:

```text
specific topological role bridge
```

without modifying frozen package files and without weakening the hostile audit
record.

## Current Safe Claim

Until this campaign passes:

```text
QP017 is a coarse role-neighborhood bridge.
```

Not allowed:

```text
QP017 uniquely derives role/operator structure.
```

## Non-Goals

This campaign does not:

```text
change frozen QP010-QP021 artifacts
rewrite package claims to sound stronger
rerun the full QP chain
make public-facing material
upgrade bridge/integration results into independent derivations
```

## Audit-Safe Routing

All campaign work must stay under:

```text
audits/private_hostile_qp010_qp021/
```

Suggested retests stay under:

```text
audits/private_hostile_qp010_qp021/suggested_retests/
```

Approved retest execution outputs stay under:

```text
audits/private_hostile_qp010_qp021/retest_runs/
```

Frozen package files are read-only.

## Boundary Diagnosis

The likely failure mode is the QP004 route-role graph.

QP004 has a broad connector:

```text
QUBIT-CL-001
```

Many role neighborhoods touch `CL`, so permuted or masked controls can preserve
enough role-neighborhood contact for the current QP017 logic to reproduce:

```text
QUBIT-NL-001<->QUBIT-NL-001
QUBIT-NL-001<->QUBIT-UNK-001
```

Therefore the next selector must add information beyond simple route-role
neighborhood contact.

## Candidate Sharpening Principles

A sharper QP017 selector should require all of:

```text
1. QP016 mode status:
   stable self-closure or boundary reorganization candidate

2. route topology:
   self-closure anchor and asymmetric boundary bridge are different classes

3. role-graph topology:
   promotion is not just "touches a role neighborhood"

4. CL hub penalty:
   role support through CL alone cannot count as specificity

5. lane separation:
   neutral stable anchor, boundary/reorganization bridge, and charged carrier
   must remain distinct

6. wrong-control rejection:
   null/permutation controls must fail to reproduce the same promoted pair
```

## Campaign Gates

### BR017-0 - Claim Guard

Purpose:

```text
freeze the narrowed language before more testing
```

Output:

```text
audit note preserving "coarse role-neighborhood bridge" wording
```

Pass:

```text
frozen package remains untouched
audit campaign uses narrowed QP017 language
```

### BR017-1 - Role Graph Anatomy

Purpose:

```text
map QP004 route-role graph and quantify CL hub dominance
```

Outputs:

```text
role graph degree table
route-role incidence table
CL hub exposure table
```

Pass:

```text
campaign identifies which role contacts are specific and which are hub-mediated
```

Boundary:

```text
QP004 graph is too hub-dominated to separate specific role topology
```

### RT-QP017B - Topological Role Selector

Purpose:

```text
test a sharpened selector against wrong controls
```

Primary specification:

```text
audits/private_hostile_qp010_qp021/suggested_retests/RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR.md
```

Pass:

```text
real map promotes NL/NL and NL/UNK
wrong controls fail
charged carrier lane remains separate
```

Boundary:

```text
real map promotes expected pair, but some controls still pass
```

Failure:

```text
expected pair is not selected or lane separation breaks
```

### BR017-2 - Downstream Compatibility Check

Purpose:

```text
verify that any sharper QP017 selector does not break QP018-QP021 surviving retests
```

This is not a full package rerun. It checks compatibility only:

```text
QP018 slot independence
QP019 mass-surface replay
QP021 charged carrier control
```

Pass:

```text
QP017 boundary is removed and downstream retest passes remain intact
```

Boundary:

```text
QP017 sharpens but downstream compatibility becomes ambiguous
```

Failure:

```text
QP017 sharpens by breaking downstream bridge logic
```

### BR017-F - Hostile Audit Review

Purpose:

```text
update hostile audit verdict without editing frozen package files
```

Possible outcomes:

```text
BOUNDARY_REMOVED
BOUNDARY_PRESERVED_FOR_PHASE2
FAILURE_REQUIRES_PACKAGE_DOWNGRADE
```

## Campaign Success

The campaign succeeds if:

```text
RT-QP017B passes
BR017-2 downstream compatibility passes
hostile audit review upgrades QP017 from boundary to closed
```

## Responsible Boundary Outcome

If QP017B remains boundary:

```text
freeze package remains valid as a bridge package
QP017 stays coarse
phase 2 starts with role-topology selector derivation
```

If QP017B fails:

```text
stop
do not soften result
write failure review in the audit folder
consider package downgrade before any further work
```

## RT-QP017B Execution Result

Result:

```text
PASS
```

Core result:

```text
real_map_promotes_expected_pair = true
real_map_keeps_charged_carrier_separate = true
support_challenge_controls_reproducing_full_selector = 0
```

Important note:

```text
global_stable_boundary_controls_reproducing = 95
full_selector_controls_reproducing = 15
unchanged_support_controls_reproducing_full_selector = 15
```

Interpretation:

```text
The sharpened selector survives controls that alter the selected support
topology. Some global permutations still reproduce the result when the local
selected support subgraph is unchanged, and automorphism-equivalent cases are
reported separately.
```

## Recommended Next Step

Do not promote the result into the frozen package automatically.

Recommended next action:

```text
freeze the post-retest audit status
```

Audit review decision:

```text
QP017 boundary is removed for the scoped topological role-selector claim.
Claim guard remains: QP017 is not a direct derivation of all role/operators.
```
