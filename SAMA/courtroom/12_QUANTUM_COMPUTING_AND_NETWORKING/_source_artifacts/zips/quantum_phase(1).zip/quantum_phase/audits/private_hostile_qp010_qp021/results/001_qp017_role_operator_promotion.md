# 001 - QP017 Role Operator Promotion

## Finding Summary

```text
surface: QP017 role/operator promotion
finding_class: MAJOR
blocker: False
retest_recommended: True
```

## Claim Under Attack

QP017 claims that QP016 stable/candidate modes bridge into QP004
role/operator space without promoting transient tails.

## Evidence

```text
artifacts/qp017/qp017_summary.json
artifacts/qp017/qp017_stable_mode_role_operator_bridge.csv
artifacts/qp004/qp004_phase_to_particle_role_operator_bridge.csv
```

QP017 promotes two rows:

```text
QUBIT-NL-001<->QUBIT-NL-001
  STABLE_ROLE_ANCHOR_PROMOTED

QUBIT-NL-001<->QUBIT-UNK-001
  CROSS_ROLE_BOUNDARY_REORGANIZATION
```

QP017 summary reports:

```text
role_lane_promotions = 2
stable_role_anchors = 1
boundary_role_bridges = 1
transient_role_rejections = 26
```

## Hostile Attack

The promoted stable anchor is not a direct QP004 required phase pair. It is a
role-neighborhood promotion. In QP004, the neutral role is supported by:

```text
QUBIT-BN-001<->QUBIT-CL-001
QUBIT-CL-001<->QUBIT-NL-001
```

QP017 promotes:

```text
QUBIT-NL-001<->QUBIT-NL-001
```

That can be a valid anchor rule, but the audit should not allow it to be
described as a direct old role/operator match. The current report mostly avoids
that wording, but the frozen package should preserve the distinction:

```text
role-neighborhood anchor
not direct QP004 role pair
```

The boundary bridge also depends on route-neighborhood contact:

```text
NL touches neutral identity role neighborhood
UNK touches transition/color role neighborhood
```

That is plausible, but not independently stress-tested in the frozen artifacts.

## Possible Resolution

Keep QP017 as a bridge, but phrase it as:

```text
QP017 promotes route-neighborhood role anchors and boundary bridges.
```

Do not phrase it as:

```text
QP017 directly derives QP004 particle role operators.
```

## Retest Needed

Yes. Suggested retest file:

```text
audits/private_hostile_qp010_qp021/suggested_retests/RT_QP017_ROLE_NEIGHBORHOOD_NULL_CONTROL.md
```

## Audit Verdict

```text
MAJOR: QP017 survives as a route-neighborhood bridge, not as direct role/operator derivation.
```
