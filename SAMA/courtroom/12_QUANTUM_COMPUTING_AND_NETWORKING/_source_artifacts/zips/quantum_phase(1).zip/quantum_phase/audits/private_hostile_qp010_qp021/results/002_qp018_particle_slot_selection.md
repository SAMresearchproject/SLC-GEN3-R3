# 002 - QP018 Particle Slot Selection

## Finding Summary

```text
surface: QP018 particle-slot selection
finding_class: MAJOR
blocker: False
retest_recommended: True
```

## Claim Under Attack

QP018 claims that QP017 promoted role surfaces select particle slots without
promoting transient tails.

## Evidence

```text
artifacts/qp018/qp018_summary.json
artifacts/qp018/qp018_role_bridge_particle_slot_selector.csv
artifacts/qp006/qp006_heavy_composite_slot_priority_table.csv
artifacts/qp008/qp008_heavy_role_shift_selector_table.csv
```

QP018 promotes:

```text
b<->s = STABLE_ANCHOR_SLOT_SELECTED
c<->s = BOUNDARY_REORGANIZATION_SLOT_SELECTED
```

QP018 also reports:

```text
particle_slot_promotions = 2
held_open_reachable_slots = 4
qp008_selected_outside_qp017_bridge = 2
```

## Hostile Attack

QP018 does not select particle slots from QP017 alone. It uses QP006 slot
priority data and QP008 selected rows. That is allowed if QP018 is explicitly a
bridge into existing private particle-slot evidence.

It is not allowed to overstate QP018 as an independent particle-slot predictor.

The strongest hostile concern is downstream dependence:

```text
QP018 promotes a slot only when the role is reached by QP017 and QP008 already selected the slot.
```

That means QP018 is a consistency bridge, not a fresh selector independent of
the earlier particle lane.

## Possible Resolution

Keep the claim narrow:

```text
QP018 maps QP017 role surfaces onto previously selected private particle slots.
```

Avoid:

```text
QP018 independently predicts particle slots.
```

## Retest Needed

Yes. Suggested retest file:

```text
audits/private_hostile_qp010_qp021/suggested_retests/RT_QP018_SLOT_SELECTOR_INDEPENDENCE.md
```

## Audit Verdict

```text
MAJOR: QP018 is a bridge/consistency result, not an independent particle-slot predictor.
```
