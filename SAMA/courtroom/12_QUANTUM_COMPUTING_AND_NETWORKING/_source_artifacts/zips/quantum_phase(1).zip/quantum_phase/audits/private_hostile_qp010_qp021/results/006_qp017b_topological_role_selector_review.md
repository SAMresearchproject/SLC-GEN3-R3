# 006 - QP017B Topological Role Selector Hostile Review

## Finding Summary

```text
surface: QP017 role/operator promotion after QP017B
finding_class: MAJOR_RESOLVED_WITH_SCOPED_CLAIM_GUARD
blocker: False
boundary_removed: True
```

## Claim Under Attack

QP017 originally survived only as a route-neighborhood bridge because the first
null-control retest showed that the broad role-neighborhood rule could be
reproduced by wrong controls.

The updated claim under review is narrower:

```text
QP017 promotes a specific topological role bridge when QP016 mode class,
route topology, CL-hub penalty, and charged-lane separation are all required.
```

## Evidence

```text
audits/private_hostile_qp010_qp021/retest_runs/RT_QP017_ROLE_NEIGHBORHOOD_NULL_CONTROL/summary.json
audits/private_hostile_qp010_qp021/retest_runs/RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR/summary.json
audits/private_hostile_qp010_qp021/retest_runs/RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR/role_graph_degree_table.csv
audits/private_hostile_qp010_qp021/retest_runs/RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR/route_role_incidence_table.csv
audits/private_hostile_qp010_qp021/retest_runs/RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR/topological_selector_control_table.csv
artifacts/qp017/qp017_stable_mode_role_operator_bridge.csv
artifacts/qp004/qp004_phase_to_particle_role_operator_bridge.csv
```

Original boundary:

```text
RT_QP017_ROLE_NEIGHBORHOOD_NULL_CONTROL = BOUNDARY
real_map_promotes_expected_pair = true
wrong_controls_reproducing_expected_pair = 20
controls_run = 27
```

Updated test:

```text
RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR = PASS
real_map_promotes_expected_pair = true
real_map_keeps_charged_carrier_separate = true
support_challenge_controls_reproducing_full_selector = 0
controls_run_total = 726
frozen_package_files_modified = false
```

## Hostile Attack

The first-pass attack remains valid against the broad wording:

```text
QP017 cannot be described as a direct derivation of QP004 role/operators.
```

The old selector promoted a plausible pair, but too many wrong controls could
also promote it. That made the original QP017 wording a MAJOR boundary.

QP017B changes the tested object. It is not just the old role-neighborhood rule
again. It requires:

```text
QP016 stable/boundary mode class
non-CL neutral self-closure support
neutral-to-transition boundary topology
CL hub penalty
separate charged transient carrier lane
```

The hostile risk is whether this new selector merely hides the old weakness.
The most important adverse evidence is:

```text
global_stable_boundary_controls_reproducing = 95
full_selector_controls_reproducing = 15
unchanged_support_controls_reproducing_full_selector = 15
automorphism_equivalent_controls_reproducing_expected_pair = 7
```

Those numbers prevent overclaiming. The selector is not unique under arbitrary
global relabelings of routes.

However, the decisive counterpoint is:

```text
support_challenge_controls_reproducing_full_selector = 0
```

The controls that actually change the selected support topology do not
reproduce the full selector. The full selector also keeps the charged carrier
lane separate.

## Hostile Decision

The QP017 boundary from the first retest is removed for the narrowed claim:

```text
BOUNDARY_REMOVED_FOR_TOPOLOGICAL_ROLE_SELECTOR
```

Allowed wording:

```text
QP017B supports a specific topological role bridge from QP016 stable/boundary
mode classes into QP004 role topology, with CL-hub-only support rejected and
charged transient carriers kept separate.
```

Not allowed wording:

```text
QP017 directly derives all role/operators.
QP017 is independent of QP004 role topology.
QP017 alone proves the full particle table.
```

## Residual Guard

This is now a scoped claim guard, not an open blocker:

```text
SCOPED_CLAIM_GUARD: preserve "topological role bridge" language.
```

If future text claims direct role/operator derivation, this finding reopens as
a MAJOR or BLOCKER depending on where the claim appears.

## Audit Verdict

```text
MAJOR_RESOLVED_WITH_SCOPED_CLAIM_GUARD
QP017 boundary removed for topological role-selector specificity.
Frozen package remains untouched.
```
