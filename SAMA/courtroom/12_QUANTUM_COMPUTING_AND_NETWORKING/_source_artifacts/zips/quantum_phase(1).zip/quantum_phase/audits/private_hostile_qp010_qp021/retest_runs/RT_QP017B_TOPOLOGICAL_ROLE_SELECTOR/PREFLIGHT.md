# RT_QP017B Execution Preflight

## Mode

```text
RETEST_EXECUTION
```

## Approval

```text
User explicitly approved execution with: Run it please
```

## Reason

```text
RT_QP017_ROLE_NEIGHBORHOOD_NULL_CONTROL returned BOUNDARY because 20/27 wrong controls reproduced the expected role-neighborhood pair.
RT_QP017B tests whether adding topology and CL-hub penalties makes QP017 specific.
```

## Frozen Package Rule

```text
No artifacts/qp010 through artifacts/qp021 files may be modified.
No frozen report package files may be modified.
Outputs remain isolated under audits/private_hostile_qp010_qp021/retest_runs/RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR/.
```
