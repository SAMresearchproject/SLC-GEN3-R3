# RT_QP017B - Topological Role Selector

## Result

```text
PASS
```

## Summary

```json
{
  "generated_at_utc": "2026-06-07T18:54:25.540992+00:00",
  "retest": "RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR",
  "result": "PASS",
  "real_map_promotes_expected_pair": true,
  "real_map_keeps_charged_carrier_separate": true,
  "global_stable_boundary_controls_reproducing": 95,
  "full_selector_controls_reproducing": 15,
  "support_challenge_controls_reproducing_full_selector": 0,
  "unchanged_support_controls_reproducing_full_selector": 15,
  "automorphism_equivalent_controls_reproducing_expected_pair": 7,
  "controls_run_total": 726,
  "control_result_counts": {
    "REAL_PASS": 1,
    "CONTROL_REJECTED": 630,
    "AUTOMORPHISM_REPRODUCES": 7,
    "STABLE_BOUNDARY_ONLY_REPRODUCES": 80,
    "UNCHANGED_SUPPORT_REPRODUCES": 8
  },
  "global_stable_boundary_labels_reproducing": [
    "ROUTE_PERM_003",
    "ROUTE_PERM_055",
    "ROUTE_PERM_057",
    "ROUTE_PERM_079",
    "ROUTE_PERM_081",
    "ROUTE_PERM_103",
    "ROUTE_PERM_104",
    "ROUTE_PERM_105",
    "ROUTE_PERM_106",
    "ROUTE_PERM_107",
    "ROUTE_PERM_108",
    "ROUTE_PERM_121",
    "ROUTE_PERM_123",
    "ROUTE_PERM_175",
    "ROUTE_PERM_177",
    "ROUTE_PERM_199",
    "ROUTE_PERM_201",
    "ROUTE_PERM_223",
    "ROUTE_PERM_224",
    "ROUTE_PERM_225",
    "ROUTE_PERM_226",
    "ROUTE_PERM_227",
    "ROUTE_PERM_228",
    "ROUTE_PERM_241",
    "ROUTE_PERM_243",
    "ROUTE_PERM_247",
    "ROUTE_PERM_249",
    "ROUTE_PERM_253",
    "ROUTE_PERM_255",
    "ROUTE_PERM_265",
    "ROUTE_PERM_267",
    "ROUTE_PERM_271",
    "ROUTE_PERM_273",
    "ROUTE_PERM_277",
    "ROUTE_PERM_279",
    "ROUTE_PERM_289",
    "ROUTE_PERM_291",
    "ROUTE_PERM_295",
    "ROUTE_PERM_297",
    "ROUTE_PERM_301",
    "ROUTE_PERM_303",
    "ROUTE_PERM_313",
    "ROUTE_PERM_315",
    "ROUTE_PERM_319",
    "ROUTE_PERM_321",
    "ROUTE_PERM_325",
    "ROUTE_PERM_327",
    "ROUTE_PERM_337",
    "ROUTE_PERM_338",
    "ROUTE_PERM_339"
  ],
  "full_selector_labels_reproducing": [
    "ROUTE_PERM_003",
    "ROUTE_PERM_106",
    "ROUTE_PERM_108",
    "ROUTE_PERM_121",
    "ROUTE_PERM_123",
    "ROUTE_PERM_226",
    "ROUTE_PERM_228",
    "ROUTE_PERM_241",
    "ROUTE_PERM_243",
    "ROUTE_PERM_265",
    "ROUTE_PERM_267",
    "ROUTE_PERM_340",
    "ROUTE_PERM_342",
    "ROUTE_PERM_346",
    "ROUTE_PERM_348"
  ],
  "support_challenge_labels_reproducing": [],
  "unchanged_support_labels_reproducing": [
    "ROUTE_PERM_003",
    "ROUTE_PERM_106",
    "ROUTE_PERM_108",
    "ROUTE_PERM_121",
    "ROUTE_PERM_123",
    "ROUTE_PERM_226",
    "ROUTE_PERM_228",
    "ROUTE_PERM_241",
    "ROUTE_PERM_243",
    "ROUTE_PERM_265",
    "ROUTE_PERM_267",
    "ROUTE_PERM_340",
    "ROUTE_PERM_342",
    "ROUTE_PERM_346",
    "ROUTE_PERM_348"
  ],
  "automorphism_control_labels_reproducing": [
    "ROUTE_PERM_003",
    "ROUTE_PERM_106",
    "ROUTE_PERM_108",
    "ROUTE_PERM_265",
    "ROUTE_PERM_267",
    "ROUTE_PERM_340",
    "ROUTE_PERM_342"
  ],
  "expected_stable_pairs": [
    "QUBIT-NL-001<->QUBIT-NL-001"
  ],
  "selected_stable_pairs": [
    "QUBIT-NL-001<->QUBIT-NL-001"
  ],
  "expected_boundary_pairs": [
    "QUBIT-NL-001<->QUBIT-UNK-001"
  ],
  "selected_boundary_pairs": [
    "QUBIT-NL-001<->QUBIT-UNK-001"
  ],
  "expected_charged_carrier_pairs": [
    "QUBIT-CL-001<->QUBIT-TM-001",
    "QUBIT-CL-001<->QUBIT-TP-001"
  ],
  "selected_charged_carrier_pairs": [
    "QUBIT-CL-001<->QUBIT-TM-001",
    "QUBIT-CL-001<->QUBIT-TP-001"
  ],
  "boundary_reason": "support-changing controls do not reproduce the full selector; unchanged-support and automorphism-equivalent reproductions are reported separately",
  "frozen_package_files_modified": false
}
```

## Scope

This retest was run in isolated retest-execution mode after explicit user approval.
Frozen package files were not modified.
