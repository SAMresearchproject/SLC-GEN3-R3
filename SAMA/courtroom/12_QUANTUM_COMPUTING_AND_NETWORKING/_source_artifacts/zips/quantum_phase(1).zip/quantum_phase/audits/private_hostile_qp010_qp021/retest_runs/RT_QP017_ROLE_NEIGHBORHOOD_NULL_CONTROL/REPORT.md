# RT_QP017_ROLE_NEIGHBORHOOD_NULL_CONTROL

## Result

```text
BOUNDARY
```

## Summary

```json
{
  "retest": "RT_QP017_ROLE_NEIGHBORHOOD_NULL_CONTROL",
  "result": "BOUNDARY",
  "real_map_promotes_expected_pair": true,
  "wrong_controls_reproducing_expected_pair": 20,
  "controls_run": 27,
  "boundary_reason": "role-neighborhood rule is broad enough that some permuted controls reproduce the same promoted pair"
}
```

## Scope

This retest was run in isolated retest-execution mode. Frozen package files were not modified.
