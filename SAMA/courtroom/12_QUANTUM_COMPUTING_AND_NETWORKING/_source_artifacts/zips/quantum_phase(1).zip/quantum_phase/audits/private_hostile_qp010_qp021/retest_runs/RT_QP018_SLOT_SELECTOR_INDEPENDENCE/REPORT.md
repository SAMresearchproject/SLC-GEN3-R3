# RT_QP018_SLOT_SELECTOR_INDEPENDENCE

## Result

```text
PASS
```

## Summary

```json
{
  "retest": "RT_QP018_SLOT_SELECTOR_INDEPENDENCE",
  "result": "PASS",
  "top_anchor_without_qp008": "b<->s",
  "top_boundary_without_qp008": "c<->s",
  "rows_ranked_without_qp008": 6
}
```

## Scope

This retest was run in isolated retest-execution mode. Frozen package files were not modified.
