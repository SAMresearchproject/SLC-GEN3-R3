# RT_QP019_MASS_SURFACE_REPLAY

## Result

```text
PASS
```

## Summary

```json
{
  "retest": "RT_QP019_MASS_SURFACE_REPLAY",
  "result": "PASS",
  "selected_surfaces_without_qp008": {
    "b<->s": "CLOSURE_COMPLEMENT_SURFACE",
    "c<->s": "CLOSURE_COMPLEMENT_SURFACE"
  },
  "expected_surfaces": {
    "b<->s": "CLOSURE_COMPLEMENT_SURFACE",
    "c<->s": "CLOSURE_COMPLEMENT_SURFACE"
  },
  "promoted_pairs_replayed": [
    "b<->s",
    "c<->s"
  ]
}
```

## Scope

This retest was run in isolated retest-execution mode. Frozen package files were not modified.
