# RT_QP021_TRANSIENT_CARRIER_CONTROL

## Result

```text
PASS
```

## Summary

```json
{
  "retest": "RT_QP021_TRANSIENT_CARRIER_CONTROL",
  "result": "PASS",
  "required_charged_pairs": [
    "QUBIT-CL-001<->QUBIT-TM-001",
    "QUBIT-CL-001<->QUBIT-TP-001"
  ],
  "selected_pairs": [
    "QUBIT-CL-001<->QUBIT-TM-001",
    "QUBIT-CL-001<->QUBIT-TP-001"
  ],
  "direct_transient_rows": 6,
  "wrong_controls_selected": []
}
```

## Scope

This retest was run in isolated retest-execution mode. Frozen package files were not modified.
