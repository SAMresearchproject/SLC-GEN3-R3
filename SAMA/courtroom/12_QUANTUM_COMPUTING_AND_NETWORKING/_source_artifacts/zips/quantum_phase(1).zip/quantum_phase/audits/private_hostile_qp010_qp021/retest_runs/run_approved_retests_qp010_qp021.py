from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from itertools import permutations
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
AUDIT_DIR = ROOT / "audits" / "private_hostile_qp010_qp021"
OUT_DIR = AUDIT_DIR / "retest_runs"

ARTIFACTS = ROOT / "artifacts"
QP004 = ARTIFACTS / "qp004" / "qp004_phase_to_particle_role_operator_bridge.csv"
QP006 = ARTIFACTS / "qp006" / "qp006_heavy_composite_slot_priority_table.csv"
QP007 = ARTIFACTS / "qp007" / "qp007_role_operator_mass_closure_trial_table.csv"
QP008 = ARTIFACTS / "qp008" / "qp008_heavy_role_shift_selector_table.csv"
QP017 = ARTIFACTS / "qp017" / "qp017_stable_mode_role_operator_bridge.csv"
QP018 = ARTIFACTS / "qp018" / "qp018_role_bridge_particle_slot_selector.csv"
QP019 = ARTIFACTS / "qp019" / "qp019_particle_slot_native_mass_surface_bridge.csv"
QP021 = ARTIFACTS / "qp021" / "qp021_summary.json"

CHARGED_ROLE = "DUAL_POLARITY_CHARGED_HEAVY_ROLE_OPERATOR"
NEUTRAL_ROLE = "NEUTRAL_BINARY_MIXING_ROLE_OPERATOR"
TRANSITION_ROLE = "TRANSITION_COLOR_COUPLED_ROLE_OPERATOR"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def normalize_pair(pair: str) -> str:
    left, right = pair.split("<->", 1)
    return "<->".join(sorted([left, right]))


def split_pair(pair: str) -> tuple[str, str]:
    left, right = pair.split("<->", 1)
    return left, right


def split_semicolon(value: str) -> list[str]:
    return [item.strip() for item in value.split(";") if item.strip()]


def split_required_pairs(value: str) -> list[str]:
    return [normalize_pair(item) for item in split_semicolon(value)]


def role_map_from_qp004(qp004_rows: list[dict[str, str]]) -> dict[str, set[str]]:
    route_roles: dict[str, set[str]] = defaultdict(set)
    for row in qp004_rows:
        role = row["phase_role_operator"]
        for pair in split_required_pairs(row["required_phase_pairs"]):
            left, right = split_pair(pair)
            route_roles[left].add(role)
            route_roles[right].add(role)
    return route_roles


def q4_route_pairs(qp004_rows: list[dict[str, str]], role: str) -> set[str]:
    pairs: set[str] = set()
    for row in qp004_rows:
        if row["phase_role_operator"] == role:
            pairs.update(split_required_pairs(row["required_phase_pairs"]))
    return pairs


def classify_qp017_from_role_map(row: dict[str, str], route_roles: dict[str, set[str]]) -> str:
    selector = row["qp016_selector_class"]
    pair_structure = row["qp016_pair_structure"]
    route_i_roles = route_roles.get(row["route_i"], set())
    route_j_roles = route_roles.get(row["route_j"], set())
    common_roles = route_i_roles.intersection(route_j_roles)

    if selector == "STABLE_SELF_CLOSURE_MODE_SELECTED":
        return "STABLE_ROLE_ANCHOR_PROMOTED" if route_i_roles or route_j_roles else "STABLE_MODE_WITHOUT_ROLE_OPERATOR"
    if selector == "BOUNDARY_REORGANIZATION_CANDIDATE":
        if common_roles:
            return "SHARED_ROLE_FAMILY_REORGANIZATION"
        if route_i_roles and route_j_roles:
            return "CROSS_ROLE_BOUNDARY_REORGANIZATION"
        if route_i_roles or route_j_roles:
            return "ONE_SIDED_ROLE_BOUNDARY_REORGANIZATION"
        return "UNMAPPED_BOUNDARY_REORGANIZATION"
    if pair_structure == "SELF_CLOSURE":
        return "TRANSIENT_SELF_CLOSURE_REJECTED"
    return "TRANSIENT_ROLE_TAIL_REJECTED"


def rt_qp021_transient_carrier_control(qp004_rows: list[dict[str, str]], qp017_rows: list[dict[str, str]]) -> dict[str, object]:
    out = OUT_DIR / "RT_QP021_TRANSIENT_CARRIER_CONTROL"
    required = q4_route_pairs(qp004_rows, CHARGED_ROLE)
    direct_rows = [
        row
        for row in qp017_rows
        if row["role_bridge_class"] == "TRANSIENT_DIRECT_ROLE_CONTACT_REJECTED"
    ]
    rows: list[dict[str, object]] = []
    selected: list[str] = []
    for row in direct_rows:
        pair = normalize_pair(row["route_pair"])
        roles = set(split_semicolon(row["direct_qp004_role_operators"]))
        selected_by_rule = CHARGED_ROLE in roles and pair in required
        if selected_by_rule:
            selected.append(pair)
        rows.append(
            {
                "route_pair": pair,
                "direct_roles": row["direct_qp004_role_operators"],
                "selected_by_charged_carrier_rule": selected_by_rule,
                "control_class": "CHARGED" if CHARGED_ROLE in roles else "NON_CHARGED_CONTROL",
            }
        )
    selected_set = set(selected)
    result = "PASS" if selected_set == required and len(selected_set) == 2 else "BOUNDARY" if selected_set else "FAIL"
    summary = {
        "retest": "RT_QP021_TRANSIENT_CARRIER_CONTROL",
        "result": result,
        "required_charged_pairs": sorted(required),
        "selected_pairs": sorted(selected_set),
        "direct_transient_rows": len(direct_rows),
        "wrong_controls_selected": [
            row["route_pair"]
            for row in rows
            if row["selected_by_charged_carrier_rule"] and row["route_pair"] not in required
        ],
    }
    write_csv(out / "route_control_table.csv", rows, ["route_pair", "direct_roles", "selected_by_charged_carrier_rule", "control_class"])
    write_json(out / "summary.json", summary)
    write_report(out / "REPORT.md", summary)
    return summary


def rt_qp018_slot_selector_independence(qp006_rows: list[dict[str, str]], qp017_rows: list[dict[str, str]]) -> dict[str, object]:
    out = OUT_DIR / "RT_QP018_SLOT_SELECTOR_INDEPENDENCE"
    promoted_roles = set()
    anchor_roles = set()
    boundary_roles = set()
    role_strength: dict[str, float] = {}
    for row in qp017_rows:
        if row["promote_to_role_lane"] != "True":
            continue
        roles = set()
        for field in ("direct_qp004_role_operators", "route_i_role_operators", "route_j_role_operators", "shared_role_operators"):
            roles.update(split_semicolon(row[field]))
        for role in roles:
            promoted_roles.add(role)
            role_strength[role] = max(role_strength.get(role, 0.0), float(row["role_operator_bridge_strength"]))
            if row["role_bridge_class"] == "STABLE_ROLE_ANCHOR_PROMOTED":
                anchor_roles.add(role)
            if "REORGANIZATION" in row["role_bridge_class"]:
                boundary_roles.add(role)

    rows: list[dict[str, object]] = []
    for row in qp006_rows:
        role = row["phase_role_operator"]
        if role not in promoted_roles:
            continue
        surface = "ANCHOR" if role in anchor_roles else "BOUNDARY" if role in boundary_roles else "PROMOTED"
        score = float(row["native_interaction_strength"]) * role_strength.get(role, 0.0)
        rows.append(
            {
                "suk055_pair": row["suk055_pair"],
                "phase_role_operator": role,
                "surface": surface,
                "native_interaction_strength": row["native_interaction_strength"],
                "bridge_strength": role_strength.get(role, 0.0),
                "score_without_qp008": score,
            }
        )
    rows.sort(key=lambda item: (item["surface"], -float(item["score_without_qp008"])))
    top_anchor = next((row["suk055_pair"] for row in rows if row["surface"] == "ANCHOR"), "")
    top_boundary = next((row["suk055_pair"] for row in rows if row["surface"] == "BOUNDARY"), "")
    result = "PASS" if top_anchor == "b<->s" and top_boundary == "c<->s" else "BOUNDARY" if top_anchor or top_boundary else "FAIL"
    summary = {
        "retest": "RT_QP018_SLOT_SELECTOR_INDEPENDENCE",
        "result": result,
        "top_anchor_without_qp008": top_anchor,
        "top_boundary_without_qp008": top_boundary,
        "rows_ranked_without_qp008": len(rows),
    }
    write_csv(out / "slot_independence_rank_table.csv", rows, ["suk055_pair", "phase_role_operator", "surface", "native_interaction_strength", "bridge_strength", "score_without_qp008"])
    write_json(out / "summary.json", summary)
    write_report(out / "REPORT.md", summary)
    return summary


def rt_qp019_mass_surface_replay(qp007_rows: list[dict[str, str]], qp018_rows: list[dict[str, str]]) -> dict[str, object]:
    out = OUT_DIR / "RT_QP019_MASS_SURFACE_REPLAY"
    promoted_pairs = [
        row["suk055_pair"]
        for row in qp018_rows
        if row["promote_to_particle_slot_lane"] == "True"
    ]
    rows: list[dict[str, object]] = []
    selected: dict[str, str] = {}
    for pair in promoted_pairs:
        candidates = [row for row in qp007_rows if row["suk055_pair"] == pair]
        def key(row: dict[str, str]) -> tuple[int, float]:
            class_rank = 0 if row["integer_shift_contact_class"] == "INTEGER_SHIFT_A_SHARE_CONTACT" else 1
            return (class_rank, abs(float(row["integer_shift_delta"])))
        ranked = sorted(candidates, key=key)
        if ranked:
            selected[pair] = ranked[0]["surface_name"]
        for rank, row in enumerate(ranked, start=1):
            rows.append(
                {
                    "suk055_pair": pair,
                    "replay_rank": rank,
                    "surface_name": row["surface_name"],
                    "integer_shift_contact_class": row["integer_shift_contact_class"],
                    "integer_shift_delta": row["integer_shift_delta"],
                    "selected_by_replay": rank == 1,
                    "surface_mass_MeV": row["surface_mass_MeV"],
                }
            )
    expected = {"b<->s": "CLOSURE_COMPLEMENT_SURFACE", "c<->s": "CLOSURE_COMPLEMENT_SURFACE"}
    result = "PASS" if selected == expected else "BOUNDARY" if selected else "FAIL"
    summary = {
        "retest": "RT_QP019_MASS_SURFACE_REPLAY",
        "result": result,
        "selected_surfaces_without_qp008": selected,
        "expected_surfaces": expected,
        "promoted_pairs_replayed": promoted_pairs,
    }
    write_csv(out / "mass_surface_replay_table.csv", rows, ["suk055_pair", "replay_rank", "surface_name", "integer_shift_contact_class", "integer_shift_delta", "selected_by_replay", "surface_mass_MeV"])
    write_json(out / "summary.json", summary)
    write_report(out / "REPORT.md", summary)
    return summary


def rt_qp017_role_neighborhood_null_control(qp004_rows: list[dict[str, str]], qp017_rows: list[dict[str, str]]) -> dict[str, object]:
    out = OUT_DIR / "RT_QP017_ROLE_NEIGHBORHOOD_NULL_CONTROL"
    real_map = role_map_from_qp004(qp004_rows)
    selected_rows = [
        row for row in qp017_rows if row["qp016_selector_class"] in {"STABLE_SELF_CLOSURE_MODE_SELECTED", "BOUNDARY_REORGANIZATION_CANDIDATE"}
    ]
    routes = sorted(real_map.keys())
    non_cl_routes = [route for route in routes if route != "QUBIT-CL-001"]
    controls: list[tuple[str, dict[str, set[str]]]] = [("REAL_MAP", real_map)]

    for removed in ("QUBIT-NL-001", "QUBIT-UNK-001"):
        masked = {route: set(roles) for route, roles in real_map.items() if route != removed}
        controls.append((f"MASK_{removed}", masked))

    base_roles = {route: set(real_map.get(route, set())) for route in routes}
    for index, perm in enumerate(permutations(non_cl_routes), start=1):
        if index > 24:
            break
        permuted = {"QUBIT-CL-001": set(base_roles.get("QUBIT-CL-001", set()))}
        for src, dst in zip(non_cl_routes, perm):
            permuted[src] = set(base_roles.get(dst, set()))
        controls.append((f"PERM_{index:02d}", permuted))

    rows: list[dict[str, object]] = []
    same_pair_controls = 0
    real_classes: dict[str, str] = {}
    for label, role_map in controls:
        classes = {row["route_pair"]: classify_qp017_from_role_map(row, role_map) for row in selected_rows}
        if label == "REAL_MAP":
            real_classes = classes
        same_pair = classes.get("QUBIT-NL-001<->QUBIT-NL-001") == "STABLE_ROLE_ANCHOR_PROMOTED" and classes.get("QUBIT-NL-001<->QUBIT-UNK-001") == "CROSS_ROLE_BOUNDARY_REORGANIZATION"
        if label != "REAL_MAP" and same_pair:
            same_pair_controls += 1
        rows.append(
            {
                "control": label,
                "nl_self_class": classes.get("QUBIT-NL-001<->QUBIT-NL-001", ""),
                "nl_unk_class": classes.get("QUBIT-NL-001<->QUBIT-UNK-001", ""),
                "same_promoted_pair_as_real": same_pair,
            }
        )
    real_passes = real_classes.get("QUBIT-NL-001<->QUBIT-NL-001") == "STABLE_ROLE_ANCHOR_PROMOTED" and real_classes.get("QUBIT-NL-001<->QUBIT-UNK-001") == "CROSS_ROLE_BOUNDARY_REORGANIZATION"
    result = "PASS" if real_passes and same_pair_controls == 0 else "BOUNDARY" if real_passes else "FAIL"
    summary = {
        "retest": "RT_QP017_ROLE_NEIGHBORHOOD_NULL_CONTROL",
        "result": result,
        "real_map_promotes_expected_pair": real_passes,
        "wrong_controls_reproducing_expected_pair": same_pair_controls,
        "controls_run": len(controls),
        "boundary_reason": "role-neighborhood rule is broad enough that some permuted controls reproduce the same promoted pair" if same_pair_controls else "",
    }
    write_csv(out / "role_neighborhood_null_control_table.csv", rows, ["control", "nl_self_class", "nl_unk_class", "same_promoted_pair_as_real"])
    write_json(out / "summary.json", summary)
    write_report(out / "REPORT.md", summary)
    return summary


def write_report(path: Path, summary: dict[str, object]) -> None:
    lines = [
        f"# {summary['retest']}",
        "",
        "## Result",
        "",
        "```text",
        str(summary["result"]),
        "```",
        "",
        "## Summary",
        "",
        "```json",
        json.dumps(summary, indent=2),
        "```",
        "",
        "## Scope",
        "",
        "This retest was run in isolated retest-execution mode. Frozen package files were not modified.",
        "",
    ]
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("\n".join(lines), encoding="utf-8")


def write_overall_report(summaries: list[dict[str, object]]) -> None:
    counts = Counter(str(summary["result"]) for summary in summaries)
    overall = "PASS_WITH_BOUNDARY" if counts.get("FAIL", 0) == 0 and counts.get("BOUNDARY", 0) else "PASS" if counts.get("FAIL", 0) == 0 else "FAIL"
    payload = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "mode": "RETEST_EXECUTION",
        "overall_result": overall,
        "counts": dict(counts),
        "retests": summaries,
        "frozen_package_files_modified": False,
    }
    write_json(OUT_DIR / "APPROVED_RETESTS_SUMMARY.json", payload)
    lines = [
        "# Approved Retests Summary - QP010-QP021",
        "",
        "## Overall Result",
        "",
        "```text",
        overall,
        "```",
        "",
        "## Counts",
        "",
        "```json",
        json.dumps(dict(counts), indent=2),
        "```",
        "",
        "## Retest Results",
        "",
    ]
    for summary in summaries:
        lines.extend(
            [
                f"### {summary['retest']}",
                "",
                "```text",
                str(summary["result"]),
                "```",
                "",
            ]
        )
    lines.extend(
        [
            "## Freeze Impact",
            "",
            "```text",
            "frozen package files modified = False",
            "hostile audit review still required to interpret retest outputs",
            "```",
            "",
        ]
    )
    (OUT_DIR / "APPROVED_RETESTS_SUMMARY.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    qp004_rows = read_csv(QP004)
    qp006_rows = read_csv(QP006)
    qp007_rows = read_csv(QP007)
    qp017_rows = read_csv(QP017)
    qp018_rows = read_csv(QP018)
    summaries = [
        rt_qp021_transient_carrier_control(qp004_rows, qp017_rows),
        rt_qp018_slot_selector_independence(qp006_rows, qp017_rows),
        rt_qp019_mass_surface_replay(qp007_rows, qp018_rows),
        rt_qp017_role_neighborhood_null_control(qp004_rows, qp017_rows),
    ]
    write_overall_report(summaries)
    for summary in summaries:
        print(f"{summary['retest']}={summary['result']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
