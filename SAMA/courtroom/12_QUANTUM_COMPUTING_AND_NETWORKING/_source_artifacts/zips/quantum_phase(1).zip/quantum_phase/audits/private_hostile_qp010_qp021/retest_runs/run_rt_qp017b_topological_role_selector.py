from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from itertools import permutations
from pathlib import Path


ROOT = Path(__file__).resolve().parents[3]
AUDIT_DIR = ROOT / "audits" / "private_hostile_qp010_qp021"
OUT_DIR = AUDIT_DIR / "retest_runs" / "RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR"

ARTIFACTS = ROOT / "artifacts"
QP004 = ARTIFACTS / "qp004" / "qp004_phase_to_particle_role_operator_bridge.csv"
QP017 = ARTIFACTS / "qp017" / "qp017_stable_mode_role_operator_bridge.csv"

CHARGED_ROLE = "DUAL_POLARITY_CHARGED_HEAVY_ROLE_OPERATOR"
NEUTRAL_ROLE = "NEUTRAL_BINARY_MIXING_ROLE_OPERATOR"
TRANSITION_ROLE = "TRANSITION_COLOR_COUPLED_ROLE_OPERATOR"

EXPECTED_STABLE = {"QUBIT-NL-001<->QUBIT-NL-001"}
EXPECTED_BOUNDARY = {"QUBIT-NL-001<->QUBIT-UNK-001"}
EXPECTED_CHARGED = {"QUBIT-CL-001<->QUBIT-TM-001", "QUBIT-CL-001<->QUBIT-TP-001"}
RELEVANT_SUPPORT_PAIRS = {
    "QUBIT-CL-001<->QUBIT-NL-001",
    "QUBIT-CL-001<->QUBIT-UNK-001",
    "QUBIT-CL-001<->QUBIT-TM-001",
    "QUBIT-CL-001<->QUBIT-TP-001",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def normalize_pair(pair: str) -> str:
    left, right = pair.split("<->", 1)
    return "<->".join(sorted([left, right]))


def split_pair(pair: str) -> tuple[str, str]:
    left, right = normalize_pair(pair).split("<->", 1)
    return left, right


def split_semicolon(value: str) -> list[str]:
    return [item.strip() for item in value.split(";") if item.strip()]


def split_required_pairs(value: str) -> list[str]:
    return [normalize_pair(item) for item in split_semicolon(value)]


def role_kind(role: str) -> str:
    if role == NEUTRAL_ROLE:
        return "NEUTRAL"
    if role == TRANSITION_ROLE:
        return "TRANSITION"
    if role == CHARGED_ROLE:
        return "CHARGED"
    return "UNKNOWN"


def qp004_edges(qp004_rows: list[dict[str, str]]) -> list[tuple[str, str, str]]:
    edges: set[tuple[str, str, str]] = set()
    for row in qp004_rows:
        role = row["phase_role_operator"]
        for pair in split_required_pairs(row["required_phase_pairs"]):
            left, right = split_pair(pair)
            edges.add((left, right, role))
    return sorted(edges)


def canonical_edges(edges: list[tuple[str, str, str]]) -> tuple[tuple[str, str, str], ...]:
    return tuple(sorted((min(left, right), max(left, right), role) for left, right, role in edges))


def selected_support_signature(edges: list[tuple[str, str, str]]) -> tuple[tuple[str, str, str], ...]:
    support_edges = [
        (left, right, role)
        for left, right, role in edges
        if f"{left}<->{right}" in RELEVANT_SUPPORT_PAIRS
    ]
    return canonical_edges(support_edges)


def route_topology(edges: list[tuple[str, str, str]]) -> dict[str, dict[str, set[str]]]:
    topology: dict[str, dict[str, set[str]]] = defaultdict(lambda: {"roles": set(), "partners": set(), "role_kinds": set()})
    for left, right, role in edges:
        for route, partner in ((left, right), (right, left)):
            topology[route]["roles"].add(role)
            topology[route]["partners"].add(partner)
            topology[route]["role_kinds"].add(role_kind(role))
    return topology


def direct_role_for_pair(edges: list[tuple[str, str, str]], pair: str) -> set[str]:
    left, right = split_pair(pair)
    return {role for edge_left, edge_right, role in edges if {edge_left, edge_right} == {left, right}}


def topology_rows(edges: list[tuple[str, str, str]]) -> list[dict[str, object]]:
    topology = route_topology(edges)
    rows: list[dict[str, object]] = []
    for route in sorted(topology):
        rows.append(
            {
                "route": route,
                "degree": len(topology[route]["partners"]),
                "roles": ";".join(sorted(topology[route]["roles"])),
                "role_kinds": ";".join(sorted(topology[route]["role_kinds"])),
                "partners": ";".join(sorted(topology[route]["partners"])),
                "is_cl_hub": route == "QUBIT-CL-001",
            }
        )
    return rows


def edge_rows(edges: list[tuple[str, str, str]]) -> list[dict[str, object]]:
    return [
        {
            "route_pair": f"{left}<->{right}",
            "left": left,
            "right": right,
            "role_operator": role,
            "role_kind": role_kind(role),
            "is_cl_hub_edge": "QUBIT-CL-001" in {left, right},
        }
        for left, right, role in sorted(edges)
    ]


def select_with_topology(qp017_rows: list[dict[str, str]], edges: list[tuple[str, str, str]]) -> dict[str, object]:
    topology = route_topology(edges)
    stable_pairs: set[str] = set()
    boundary_pairs: set[str] = set()
    charged_pairs: set[str] = set()
    decisions: list[dict[str, object]] = []

    for row in qp017_rows:
        pair = normalize_pair(row["route_pair"])
        route_i = row["route_i"]
        route_j = row["route_j"]
        selector = row["qp016_selector_class"]
        pair_structure = row["qp016_pair_structure"]
        role_i = topology.get(route_i, {"roles": set(), "role_kinds": set()})
        role_j = topology.get(route_j, {"roles": set(), "role_kinds": set()})
        kinds_i = set(role_i["role_kinds"])
        kinds_j = set(role_j["role_kinds"])
        direct_roles = direct_role_for_pair(edges, pair)

        selected_class = "NOT_SELECTED"
        reason = "selector did not meet topological requirements"

        stable_ok = (
            selector == "STABLE_SELF_CLOSURE_MODE_SELECTED"
            and pair_structure == "SELF_CLOSURE"
            and route_i == route_j
            and route_i != "QUBIT-CL-001"
            and kinds_i == {"NEUTRAL"}
        )
        if stable_ok:
            stable_pairs.add(pair)
            selected_class = "STABLE_TOPOLOGICAL_ROLE_ANCHOR"
            reason = "QP016 stable self-closure with non-CL neutral endpoint support"

        boundary_ok = (
            selector == "BOUNDARY_REORGANIZATION_CANDIDATE"
            and pair_structure == "MIXED_ROUTE_INTERSECTION"
            and route_i != route_j
            and "QUBIT-CL-001" not in {route_i, route_j}
            and kinds_i == {"NEUTRAL"}
            and kinds_j == {"TRANSITION"}
            and not direct_roles
        )
        if boundary_ok:
            boundary_pairs.add(pair)
            selected_class = "BOUNDARY_TOPOLOGICAL_ROLE_BRIDGE"
            reason = "QP016 boundary bridge links neutral endpoint support to transition endpoint support without direct CL carrier promotion"

        direct_charged = direct_roles == {CHARGED_ROLE} and pair in EXPECTED_CHARGED
        charged_ok = (
            row["role_bridge_class"] == "TRANSIENT_DIRECT_ROLE_CONTACT_REJECTED"
            and direct_charged
        )
        if charged_ok:
            charged_pairs.add(pair)
            selected_class = "CHARGED_TRANSIENT_CARRIER_SEPARATED"
            reason = "direct charged CL carrier contact is retained outside stable/boundary promotion"

        decisions.append(
            {
                "route_pair": pair,
                "qp016_selector_class": selector,
                "qp016_pair_structure": pair_structure,
                "route_i_role_kinds": ";".join(sorted(kinds_i)),
                "route_j_role_kinds": ";".join(sorted(kinds_j)),
                "direct_roles": ";".join(sorted(direct_roles)),
                "selected_class": selected_class,
                "reason": reason,
            }
        )

    return {
        "stable_pairs": sorted(stable_pairs),
        "boundary_pairs": sorted(boundary_pairs),
        "charged_pairs": sorted(charged_pairs),
        "decisions": decisions,
    }


def relabel_edges(edges: list[tuple[str, str, str]], mapping: dict[str, str]) -> list[tuple[str, str, str]]:
    relabeled = []
    for left, right, role in edges:
        new_left = mapping.get(left, left)
        new_right = mapping.get(right, right)
        relabeled.append((min(new_left, new_right), max(new_left, new_right), role))
    return sorted(set(relabeled))


def controls_from_real_edges(edges: list[tuple[str, str, str]]) -> list[tuple[str, str, list[tuple[str, str, str]]]]:
    controls: list[tuple[str, str, list[tuple[str, str, str]]]] = [("REAL_MAP", "REAL", edges)]
    routes = sorted({route for left, right, _role in edges for route in (left, right)})
    non_cl_routes = [route for route in routes if route != "QUBIT-CL-001"]

    controls.append(("MASK_CL_HUB", "MASK", [edge for edge in edges if "QUBIT-CL-001" not in {edge[0], edge[1]}]))
    controls.append(("MASK_QUBIT-NL-001", "MASK", [edge for edge in edges if "QUBIT-NL-001" not in {edge[0], edge[1]}]))
    controls.append(("MASK_QUBIT-UNK-001", "MASK", [edge for edge in edges if "QUBIT-UNK-001" not in {edge[0], edge[1]}]))
    controls.append(("CHARGED_LANE_ONLY", "CHARGED_CONTROL", [edge for edge in edges if edge[2] == CHARGED_ROLE]))
    controls.append(("NEUTRAL_LANE_ONLY", "LANE_CONTROL", [edge for edge in edges if edge[2] == NEUTRAL_ROLE]))
    controls.append(("TRANSITION_LANE_ONLY", "LANE_CONTROL", [edge for edge in edges if edge[2] == TRANSITION_ROLE]))

    identity = {route: route for route in routes}
    for index, permuted in enumerate(permutations(non_cl_routes), start=1):
        mapping = dict(identity)
        for src, dst in zip(non_cl_routes, permuted):
            mapping[src] = dst
        if all(mapping[route] == route for route in non_cl_routes):
            continue
        controls.append((f"ROUTE_PERM_{index:03d}", "ROUTE_PERMUTATION", relabel_edges(edges, mapping)))
    return controls


def write_report(summary: dict[str, object]) -> None:
    lines = [
        "# RT_QP017B - Topological Role Selector",
        "",
        "## Result",
        "",
        "```text",
        str(summary["result"]),
        "```",
        "",
        "## Summary",
        "",
        "```json",
        json.dumps(summary, indent=2),
        "```",
        "",
        "## Scope",
        "",
        "This retest was run in isolated retest-execution mode after explicit user approval.",
        "Frozen package files were not modified.",
        "",
    ]
    (OUT_DIR / "REPORT.md").write_text("\n".join(lines), encoding="utf-8")


def write_preflight() -> None:
    lines = [
        "# RT_QP017B Execution Preflight",
        "",
        "## Mode",
        "",
        "```text",
        "RETEST_EXECUTION",
        "```",
        "",
        "## Approval",
        "",
        "```text",
        "User explicitly approved execution with: Run it please",
        "```",
        "",
        "## Reason",
        "",
        "```text",
        "RT_QP017_ROLE_NEIGHBORHOOD_NULL_CONTROL returned BOUNDARY because 20/27 wrong controls reproduced the expected role-neighborhood pair.",
        "RT_QP017B tests whether adding topology and CL-hub penalties makes QP017 specific.",
        "```",
        "",
        "## Frozen Package Rule",
        "",
        "```text",
        "No artifacts/qp010 through artifacts/qp021 files may be modified.",
        "No frozen report package files may be modified.",
        "Outputs remain isolated under audits/private_hostile_qp010_qp021/retest_runs/RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR/.",
        "```",
        "",
    ]
    (OUT_DIR / "PREFLIGHT.md").write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    qp004_rows = read_csv(QP004)
    qp017_rows = read_csv(QP017)
    real_edges = qp004_edges(qp004_rows)
    real_canonical = canonical_edges(real_edges)
    real_support_signature = selected_support_signature(real_edges)

    write_preflight()
    write_csv(
        OUT_DIR / "role_graph_degree_table.csv",
        topology_rows(real_edges),
        ["route", "degree", "roles", "role_kinds", "partners", "is_cl_hub"],
    )
    write_csv(
        OUT_DIR / "route_role_incidence_table.csv",
        edge_rows(real_edges),
        ["route_pair", "left", "right", "role_operator", "role_kind", "is_cl_hub_edge"],
    )

    real_selection = select_with_topology(qp017_rows, real_edges)
    write_csv(
        OUT_DIR / "real_topological_selector_decisions.csv",
        real_selection["decisions"],
        [
            "route_pair",
            "qp016_selector_class",
            "qp016_pair_structure",
            "route_i_role_kinds",
            "route_j_role_kinds",
            "direct_roles",
            "selected_class",
            "reason",
        ],
    )

    control_rows: list[dict[str, object]] = []
    global_stable_boundary_controls_reproducing = 0
    full_selector_controls_reproducing = 0
    support_challenge_controls_reproducing = 0
    unchanged_support_controls_reproducing = 0
    automorphism_controls_reproducing = 0
    global_stable_boundary_labels: list[str] = []
    full_selector_labels: list[str] = []
    support_challenge_labels: list[str] = []
    unchanged_support_labels: list[str] = []
    automorphism_labels: list[str] = []
    result_counter: Counter[str] = Counter()

    for label, control_class, control_edges in controls_from_real_edges(real_edges):
        selection = select_with_topology(qp017_rows, control_edges)
        stable = set(selection["stable_pairs"])
        boundary = set(selection["boundary_pairs"])
        charged = set(selection["charged_pairs"])
        reproduces_expected_stable_boundary = stable == EXPECTED_STABLE and boundary == EXPECTED_BOUNDARY
        charged_separate = charged == EXPECTED_CHARGED and not (charged & stable) and not (charged & boundary)
        reproduces_full_selector = reproduces_expected_stable_boundary and charged_separate
        is_automorphism = canonical_edges(control_edges) == real_canonical and label != "REAL_MAP"
        selected_support_changed = selected_support_signature(control_edges) != real_support_signature
        if label != "REAL_MAP" and reproduces_expected_stable_boundary:
            global_stable_boundary_controls_reproducing += 1
            global_stable_boundary_labels.append(label)
        if label != "REAL_MAP" and reproduces_full_selector:
            full_selector_controls_reproducing += 1
            full_selector_labels.append(label)
            if selected_support_changed:
                support_challenge_controls_reproducing += 1
                support_challenge_labels.append(label)
            else:
                unchanged_support_controls_reproducing += 1
                unchanged_support_labels.append(label)
        if label != "REAL_MAP" and reproduces_full_selector:
            if is_automorphism:
                automorphism_controls_reproducing += 1
                automorphism_labels.append(label)
        control_result = (
            "REAL_PASS"
            if label == "REAL_MAP" and reproduces_full_selector
            else "AUTOMORPHISM_REPRODUCES"
            if is_automorphism and reproduces_full_selector
            else "UNCHANGED_SUPPORT_REPRODUCES"
            if label != "REAL_MAP" and reproduces_full_selector and not selected_support_changed
            else "SUPPORT_CHALLENGE_REPRODUCES"
            if label != "REAL_MAP" and reproduces_full_selector and selected_support_changed
            else "STABLE_BOUNDARY_ONLY_REPRODUCES"
            if label != "REAL_MAP" and reproduces_expected_stable_boundary
            else "CONTROL_REJECTED"
        )
        result_counter[control_result] += 1
        control_rows.append(
            {
                "control": label,
                "control_class": control_class,
                "control_result": control_result,
                "graph_automorphism_of_real": is_automorphism,
                "stable_pairs": ";".join(sorted(stable)),
                "boundary_pairs": ";".join(sorted(boundary)),
                "charged_carrier_pairs": ";".join(sorted(charged)),
                "reproduces_expected_stable_boundary": reproduces_expected_stable_boundary,
                "reproduces_full_selector": reproduces_full_selector,
                "selected_support_changed": selected_support_changed,
                "charged_lane_separate": charged_separate,
            }
        )

    real_passes = (
        set(real_selection["stable_pairs"]) == EXPECTED_STABLE
        and set(real_selection["boundary_pairs"]) == EXPECTED_BOUNDARY
    )
    real_charged = set(real_selection["charged_pairs"]) == EXPECTED_CHARGED
    result = "PASS" if real_passes and real_charged and support_challenge_controls_reproducing == 0 else "BOUNDARY" if real_passes else "FAIL"
    boundary_reason = ""
    if result == "BOUNDARY":
        boundary_reason = "topological selector selects the real pair but support-changing controls still reproduce the full selector"
    if result == "PASS" and (unchanged_support_controls_reproducing or automorphism_controls_reproducing or global_stable_boundary_controls_reproducing):
        boundary_reason = "support-changing controls do not reproduce the full selector; unchanged-support and automorphism-equivalent reproductions are reported separately"

    summary = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "retest": "RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR",
        "result": result,
        "real_map_promotes_expected_pair": real_passes,
        "real_map_keeps_charged_carrier_separate": real_charged,
        "global_stable_boundary_controls_reproducing": global_stable_boundary_controls_reproducing,
        "full_selector_controls_reproducing": full_selector_controls_reproducing,
        "support_challenge_controls_reproducing_full_selector": support_challenge_controls_reproducing,
        "unchanged_support_controls_reproducing_full_selector": unchanged_support_controls_reproducing,
        "automorphism_equivalent_controls_reproducing_expected_pair": automorphism_controls_reproducing,
        "controls_run_total": len(control_rows),
        "control_result_counts": dict(result_counter),
        "global_stable_boundary_labels_reproducing": global_stable_boundary_labels[:50],
        "full_selector_labels_reproducing": full_selector_labels[:50],
        "support_challenge_labels_reproducing": support_challenge_labels,
        "unchanged_support_labels_reproducing": unchanged_support_labels[:50],
        "automorphism_control_labels_reproducing": automorphism_labels[:25],
        "expected_stable_pairs": sorted(EXPECTED_STABLE),
        "selected_stable_pairs": real_selection["stable_pairs"],
        "expected_boundary_pairs": sorted(EXPECTED_BOUNDARY),
        "selected_boundary_pairs": real_selection["boundary_pairs"],
        "expected_charged_carrier_pairs": sorted(EXPECTED_CHARGED),
        "selected_charged_carrier_pairs": real_selection["charged_pairs"],
        "boundary_reason": boundary_reason,
        "frozen_package_files_modified": False,
    }
    write_csv(
        OUT_DIR / "topological_selector_control_table.csv",
        control_rows,
        [
            "control",
            "control_class",
            "control_result",
            "graph_automorphism_of_real",
            "stable_pairs",
            "boundary_pairs",
            "charged_carrier_pairs",
            "reproduces_expected_stable_boundary",
            "reproduces_full_selector",
            "selected_support_changed",
            "charged_lane_separate",
        ],
    )
    write_json(OUT_DIR / "summary.json", summary)
    write_report(summary)
    print(f"RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR={result}")
    print(json.dumps(summary, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
