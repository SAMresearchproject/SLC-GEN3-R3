# RT-QP017B - Topological Role Selector

## Status

```text
EXECUTED
```

This retest has been run.

Output:

```text
audits/private_hostile_qp010_qp021/retest_runs/RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR/
```

Result:

```text
PASS
```

## Reason

RT-QP017 showed that QP017's current role-neighborhood bridge is too broad:

```text
wrong_controls_reproducing_expected_pair = 20/27
```

The next retest must determine whether adding topology and hub penalties can
make QP017 specific.

## Artifact Under Question

```text
artifacts/qp017/qp017_stable_mode_role_operator_bridge.csv
artifacts/qp004/qp004_phase_to_particle_role_operator_bridge.csv
```

## Proposed Selector Inputs

Use only existing frozen artifacts as read-only inputs:

```text
QP016 selector class from QP017 table
QP017 route pair and pair structure
QP004 required phase-pair graph
QP004 role/operator labels
```

## Proposed Topological Requirements

The sharpened selector must distinguish:

```text
stable anchor:
  self-closure
  QP016 stable mode
  role support not explainable by CL hub contact alone

boundary bridge:
  mixed route
  QP016 boundary reorganization candidate
  connects two role neighborhoods with different lane identities

charged carrier:
  paired transient direct contacts
  kept out of stable/boundary promotion
```

## Required Controls

Run against:

```text
real QP004 route-role graph
route-role permutations
CL-hub masked controls
NL-masked controls
UNK-masked controls
charged-lane controls
```

## Pass

```text
real map promotes:
  QUBIT-NL-001<->QUBIT-NL-001
  QUBIT-NL-001<->QUBIT-UNK-001

wrong controls fail to reproduce the same promoted pair
charged carrier lane remains separate:
  QUBIT-CL-001<->QUBIT-TM-001
  QUBIT-CL-001<->QUBIT-TP-001
```

## Boundary

```text
real map promotes the expected pair,
but some wrong controls still reproduce it
```

## Failure

```text
expected pair is not selected
or charged carrier lane is mixed into stable/boundary promotion
```

## May Modify Frozen Package Files

```text
False
```

## Output Location If Approved

```text
audits/private_hostile_qp010_qp021/retest_runs/RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR/
```
