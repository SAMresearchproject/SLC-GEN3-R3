# RT-QP017 - Role Neighborhood Null Control

## Status

```text
SUGGESTED_RETEST_ONLY
```

This retest has not been run.

## Reason

QP017 promotes role-neighborhood anchors, not direct QP004 role pairs. A null
control should test whether the promotion is specific or an artifact of broad
route-role neighborhood overlap.

## Artifact Under Question

```text
artifacts/qp017/qp017_stable_mode_role_operator_bridge.csv
```

## Proposed Retest

Hold QP016 stable/candidate classes fixed, but permute or mask QP004
route-role neighborhood assignments and rerun the QP017 promotion logic in an
isolated audit output folder.

## Pass

```text
NL/NL and NL/UNK remain uniquely promoted under the real QP004 map
wrong-control maps fail to reproduce the same promoted bridge pair
```

## Boundary

```text
real map still promotes the expected pair, but wrong-control maps sometimes promote comparable pairs
```

## Failure

```text
promotion is not specific to the real QP004 role map
```

## May Modify Frozen Package Files

```text
False
```
