# RT-QP018 - Slot Selector Independence

## Status

```text
SUGGESTED_RETEST_ONLY
```

This retest has not been run.

## Reason

QP018 uses QP008 selected rows. A hostile reader can argue that QP018 is a
consistency bridge, not an independent particle-slot selector.

## Artifact Under Question

```text
artifacts/qp018/qp018_role_bridge_particle_slot_selector.csv
```

## Proposed Retest

Run an isolated audit-only QP018 variant that ranks slots from QP017 role
surface plus QP006 slot priority only, without the QP008 selected flag as a
promotion requirement.

## Pass

```text
b<->s and c<->s still land as the top stable/boundary selected slots
```

## Boundary

```text
b<->s or c<->s remain high but not uniquely selected
```

## Failure

```text
QP018 slot promotion depends entirely on importing QP008 selections
```

## May Modify Frozen Package Files

```text
False
```
