# RT-QP019 - Mass Surface Replay

## Status

```text
SUGGESTED_RETEST_ONLY
```

This retest has not been run.

## Reason

QP019 carries QP007/QP008 selected mass surfaces. A hostile reader can argue
that no independent mass-surface selection happens at QP019.

## Artifact Under Question

```text
artifacts/qp019/qp019_particle_slot_native_mass_surface_bridge.csv
```

## Proposed Retest

Replay QP019 against all QP007 candidate surfaces for QP018-promoted slots,
without importing QP008 selected_surface as a fixed selector.

## Pass

```text
the replay independently recovers the same selected surfaces for b<->s and c<->s
```

## Boundary

```text
the same surfaces remain plausible but not unique
```

## Failure

```text
QP019 bridge depends entirely on QP008 selected-surface import
```

## May Modify Frozen Package Files

```text
False
```
