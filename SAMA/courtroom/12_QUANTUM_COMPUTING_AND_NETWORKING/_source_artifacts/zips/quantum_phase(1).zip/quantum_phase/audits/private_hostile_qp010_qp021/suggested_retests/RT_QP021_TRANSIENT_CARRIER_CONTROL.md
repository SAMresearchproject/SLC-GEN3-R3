# RT-QP021 - Transient Carrier Control

## Status

```text
SUGGESTED_RETEST_ONLY
```

This retest has not been run.

## Reason

QP021 reinterprets QP017 transient direct role contacts as charged carrier
contacts. This is the highest-risk rule in the frozen package.

## Artifact Under Question

```text
artifacts/qp021/qp021_charged_route_support.csv
artifacts/qp017/qp017_stable_mode_role_operator_bridge.csv
```

## Proposed Retest

Before looking at charged mass readouts, define a frozen transient-carrier rule
over all QP017 `TRANSIENT_DIRECT_ROLE_CONTACT_REJECTED` rows. Test whether the
rule uniquely selects the paired charged contacts:

```text
QUBIT-CL-001<->QUBIT-TM-001
QUBIT-CL-001<->QUBIT-TP-001
```

and rejects comparable neutral/transition controls.

## Pass

```text
the charged pair is uniquely selected and wrong-control transient contacts fail
```

## Boundary

```text
the charged pair is selected, but additional transient direct contacts also pass
```

## Failure

```text
the transient-carrier rule is not specific to charged lane support
```

## May Modify Frozen Package Files

```text
False
```
