param(
    [string]$Root = "E:\quantum_phase\data\quantum_computing"
)

$ErrorActionPreference = "Stop"
$indexDir = Join-Path $Root "indexes"
$snapshotDir = Join-Path $Root "snapshots"
$manifestPath = Join-Path $indexDir "quantum_computing_sources.csv"
$coveragePath = Join-Path $indexDir "quantum_source_coverage.csv"
$mdPath = Join-Path $indexDir "QUANTUM_COMPUTING_DATA_INDEX.md"

$sources = @(Import-Csv -LiteralPath $manifestPath)
$logs = @(Get-ChildItem -LiteralPath $indexDir -Filter "download_log*.csv" | ForEach-Object {
    Import-Csv -LiteralPath $_.FullName | ForEach-Object {
        $_ | Add-Member -NotePropertyName log_file -NotePropertyValue (Split-Path -Leaf $PSCommandPath) -Force
        $_
    }
})

$latestBySource = @{}
foreach ($row in $logs) {
    $latestBySource[$row.source_id] = $row
}

$coverage = foreach ($source in $sources) {
    $snap = Get-ChildItem -LiteralPath $snapshotDir -ErrorAction SilentlyContinue |
        Where-Object { $_.Name -like "$($source.source_id)-*" } |
        Sort-Object LastWriteTime -Descending |
        Select-Object -First 1
    $log = $latestBySource[$source.source_id]
    [pscustomobject]@{
        source_id = $source.source_id
        category = $source.category
        organization = $source.organization
        platform_or_topic = $source.platform_or_topic
        priority = $source.priority
        status = if ($snap) { "SNAPSHOT_PRESENT" } elseif ($log) { $log.status } else { "NOT_ATTEMPTED" }
        snapshot_file = if ($snap) { $snap.Name } elseif ($log) { $log.snapshot_file } else { "" }
        bytes = if ($snap) { $snap.Length } elseif ($log) { $log.bytes } else { 0 }
        sha256 = if ($snap) { (Get-FileHash -LiteralPath $snap.FullName -Algorithm SHA256).Hash.ToLowerInvariant() } elseif ($log) { $log.sha256 } else { "" }
        url = $source.url
        initial_read = $source.initial_read
        notes = $source.notes
    }
}

$coverage | Export-Csv -LiteralPath $coveragePath -NoTypeInformation -Encoding UTF8

$statusCounts = $coverage | Group-Object status | Sort-Object Name
$categoryCounts = $coverage | Group-Object category | Sort-Object Name
$priorityCounts = $coverage | Group-Object priority | Sort-Object Name
$snapshotCount = ($coverage | Where-Object status -eq "SNAPSHOT_PRESENT").Count
$totalBytes = ($coverage | Measure-Object bytes -Sum).Sum

$failedLines = $coverage |
    Where-Object { $_.status -ne "SNAPSHOT_PRESENT" } |
    ForEach-Object { "| $($_.source_id) | $($_.organization) | $($_.status) | $($_.url) |" }
if (-not $failedLines) {
    $failedLines = @("| none | none | none | none |")
}

$statusLines = $statusCounts | ForEach-Object { "| $($_.Name) | $($_.Count) |" }
$categoryLines = $categoryCounts | ForEach-Object { "| $($_.Name) | $($_.Count) |" }
$priorityLines = $priorityCounts | ForEach-Object { "| $($_.Name) | $($_.Count) |" }

$md = @"
# Quantum Computing Data Index

Private working folder: ``$Root``

Generated: $((Get-Date).ToUniversalTime().ToString("o"))

## Coverage

~~~text
manifest sources = $($sources.Count)
snapshots present = $snapshotCount
snapshot bytes = $totalBytes
~~~

## Status Counts

| Status | Count |
| --- | ---: |
$($statusLines -join "`n")

## Category Counts

| Category | Count |
| --- | ---: |
$($categoryLines -join "`n")

## Priority Counts

| Priority | Count |
| --- | ---: |
$($priorityLines -join "`n")

## Missing Or Blocked Sources

| Source | Organization | Status | URL |
| --- | --- | --- | --- |
$($failedLines -join "`n")

## First-Pass Evidence Map

### Strong Current Signals

- Google Quantum AI: strongest public QEC signal from Willow below-threshold surface-code work.
- Quantinuum: strong trapped-ion benchmark and logical/error-correction lane.
- IBM: strongest ecosystem/platform/roadmap documentation and public cloud hardware surface.
- Neutral atoms: Atom/QuEra/NIST lane has credible scaling and logical-qubit momentum.

### High-Upside, Needs More Public Proof

- PsiQuantum: strong scale/manufacturing story, but needs more public hardware benchmark evidence.
- Xanadu: strong photonic modular/networking story, but needs careful separation between demonstration and utility-scale FTQC.
- Microsoft topological/Majorana: highest upside if validated, but should carry the highest evidence burden.

### Useful But Must Be Classified Correctly

- D-Wave: real annealing platform; evaluate as annealing/optimization/sampling, not universal gate-model FTQC.
- Rigetti: useful superconducting competitor lane; compare by fidelity, QEC path, and independent benchmarks.
- IonQ: serious trapped-ion architecture; cross-check AQ and investor-style claims against QED-C/DARPA style evidence.

## Next Work

1. Extract ``claim_inventory.csv`` from local snapshots.
2. Extract ``hardware_metrics.csv`` where public fields are available.
3. Score each organization with ``QUANTUM_COMPUTING_EVALUATION_RUBRIC.md``.
4. Separate universal gate-model, annealing, analog simulation, photonic networking, software, and security claims.
5. Manually retrieve blocked PDFs/pages if they matter for the final ranking.

## Files

~~~text
indexes/quantum_computing_sources.csv
indexes/quantum_source_coverage.csv
indexes/QUANTUM_COMPUTING_EVALUATION_RUBRIC.md
snapshots/
collect_quantum_sources.ps1
build_quantum_data_index.ps1
~~~
"@

$md | Set-Content -LiteralPath $mdPath -Encoding UTF8
Write-Host "Coverage: $coveragePath"
Write-Host "Index: $mdPath"
