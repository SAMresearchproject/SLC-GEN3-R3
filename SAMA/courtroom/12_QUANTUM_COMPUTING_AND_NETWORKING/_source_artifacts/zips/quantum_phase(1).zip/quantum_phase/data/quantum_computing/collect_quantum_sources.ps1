param(
    [string]$ManifestPath = "E:\quantum_phase\data\quantum_computing\indexes\quantum_computing_sources.csv",
    [string]$SnapshotDir = "E:\quantum_phase\data\quantum_computing\snapshots",
    [string]$LogPath = "E:\quantum_phase\data\quantum_computing\indexes\download_log.csv",
    [int]$Start = 0,
    [int]$Limit = 0,
    [int]$TimeoutSec = 20,
    [switch]$SkipExisting
)

$ErrorActionPreference = "Continue"
New-Item -ItemType Directory -Force -Path $SnapshotDir | Out-Null
New-Item -ItemType Directory -Force -Path (Split-Path -Parent $LogPath) | Out-Null

function Get-SafeName {
    param(
        [string]$SourceId,
        [string]$Organization,
        [string]$Title,
        [string]$Url
    )
    $extension = ".html"
    $uri = [Uri]$Url
    $path = $uri.AbsolutePath
    if ($path -match "\.pdf$" -or $Url -match "asPDF=1") {
        $extension = ".pdf"
    }
    elseif ($path -match "\.json$") {
        $extension = ".json"
    }
    $stem = "$SourceId-$Organization-$Title"
    $stem = $stem -replace "[^A-Za-z0-9._-]+", "_"
    if ($stem.Length -gt 140) {
        $stem = $stem.Substring(0, 140)
    }
    return "$stem$extension"
}

$headers = @{
    "User-Agent" = "Mozilla/5.0 (SAM private research source collector; contact: local)"
    "Accept" = "text/html,application/xhtml+xml,application/xml,application/pdf;q=0.9,*/*;q=0.8"
}

$sources = @(Import-Csv -LiteralPath $ManifestPath)
if ($Start -lt 0) {
    throw "Start must be >= 0"
}
if ($Limit -gt 0) {
    $sources = @($sources | Select-Object -Skip $Start -First $Limit)
}
elseif ($Start -gt 0) {
    $sources = @($sources | Select-Object -Skip $Start)
}
$logRows = @()

foreach ($source in $sources) {
    $fileName = Get-SafeName -SourceId $source.source_id -Organization $source.organization -Title $source.source_title -Url $source.url
    $target = Join-Path $SnapshotDir $fileName
    $status = "OK"
    $message = ""
    $bytes = 0
    $sha256 = ""
    if ($SkipExisting -and (Test-Path -LiteralPath $target)) {
        $item = Get-Item -LiteralPath $target
        $bytes = $item.Length
        if ($bytes -gt 0) {
            $sha256 = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
            $status = "SKIPPED_EXISTING"
            $message = "Existing snapshot retained"
            $logRows += [pscustomobject]@{
                source_id = $source.source_id
                organization = $source.organization
                source_title = $source.source_title
                url = $source.url
                snapshot_file = $fileName
                status = $status
                bytes = $bytes
                sha256 = $sha256
                message = $message
                collected_at_utc = (Get-Date).ToUniversalTime().ToString("o")
            }
            continue
        }
    }
    try {
        Invoke-WebRequest -Uri $source.url -OutFile $target -Headers $headers -MaximumRedirection 8 -TimeoutSec $TimeoutSec
        $item = Get-Item -LiteralPath $target
        $bytes = $item.Length
        $sha256 = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    catch {
        $status = "FAILED"
        $message = $_.Exception.Message
        if (Test-Path -LiteralPath $target) {
            try {
                $item = Get-Item -LiteralPath $target
                $bytes = $item.Length
                if ($bytes -gt 0) {
                    $sha256 = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
                    $status = "PARTIAL"
                }
            }
            catch {
                $message = "$message | hash_failed=$($_.Exception.Message)"
            }
        }
    }
    $logRows += [pscustomobject]@{
        source_id = $source.source_id
        organization = $source.organization
        source_title = $source.source_title
        url = $source.url
        snapshot_file = $fileName
        status = $status
        bytes = $bytes
        sha256 = $sha256
        message = $message
        collected_at_utc = (Get-Date).ToUniversalTime().ToString("o")
    }
}

$logRows | Export-Csv -LiteralPath $LogPath -NoTypeInformation -Encoding UTF8
$summary = $logRows | Group-Object status | Select-Object Name,Count
$summary | Format-Table -AutoSize
Write-Host "Log: $LogPath"
