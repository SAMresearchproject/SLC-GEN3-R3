﻿# Quantum Computing Data Index

Private working folder: `E:\quantum_phase\data\quantum_computing`

Generated: 2026-06-07T13:06:24.4199963Z

## Coverage

~~~text
manifest sources = 40
snapshots present = 33
snapshot bytes = 7620979
~~~

## Status Counts

| Status | Count |
| --- | ---: |
| FAILED | 7 |
| SNAPSHOT_PRESENT | 33 |

## Category Counts

| Category | Count |
| --- | ---: |
| annealing | 3 |
| benchmarking | 7 |
| neutral-atom | 6 |
| overview | 1 |
| photonic | 5 |
| software | 1 |
| superconducting | 9 |
| topological | 2 |
| trapped-ion | 6 |

## Priority Counts

| Priority | Count |
| --- | ---: |
| P0 | 22 |
| P1 | 13 |
| P2 | 5 |

## Missing Or Blocked Sources

| Source | Organization | Status | URL |
| --- | --- | --- | --- |
| QC003 | IBM | FAILED | https://www.ibm.com/quantum/technology |
| QC013 | Quantinuum | FAILED | https://docs.quantinuum.com/h-series/data_sheets/Quantinuum%20H2%20Product%20Data%20Sheet.pdf |
| QC017 | IonQ | FAILED | https://www.sec.gov/Archives/edgar/data/1824920/000119312526197584/d938156dars.pdf |
| QC025 | D-Wave | FAILED | https://support.dwavesys.com/hc/en-us/articles/32105885880087-D-Wave-s-Advantage2-Quantum-Computer-Now-Generally-Available |
| QC027 | Rigetti | FAILED | https://investors.rigetti.com/news-releases/news-release-details/rigetti-computing-launches-84-qubit-ankaatm-3-system-achieves |
| QC030 | Xanadu | FAILED | https://investors.xanadu.ai/static-files/d887c51f-e3a6-4234-a225-df6d57ca140c |
| QC033 | PsiQuantum + GlobalFoundries | FAILED | https://www.psiquantum.com/news-import/psiquantum-and-globalfoundries-to-build-the-worlds-first-full-scale-quantum-computer |

## First-Pass Evidence Map

### Strong Current Signals

- Google Quantum AI: strongest public QEC signal from Willow below-threshold surface-code work.
- Quantinuum: strong trapped-ion benchmark and logical/error-correction lane.
- IBM: strongest ecosystem/platform/roadmap documentation and public cloud hardware surface.
- Neutral atoms: Atom/QuEra/NIST lane has credible scaling and logical-qubit momentum.

### High-Upside, Needs More Public Proof

- PsiQuantum: strong scale/manufacturing story, but needs more public hardware benchmark evidence.
- Xanadu: strong photonic modular/networking story, but needs careful separation between demonstration and utility-scale FTQC.
- Microsoft topological/Majorana: highest upside if validated, but should carry the highest evidence burden.

### Useful But Must Be Classified Correctly

- D-Wave: real annealing platform; evaluate as annealing/optimization/sampling, not universal gate-model FTQC.
- Rigetti: useful superconducting competitor lane; compare by fidelity, QEC path, and independent benchmarks.
- IonQ: serious trapped-ion architecture; cross-check AQ and investor-style claims against QED-C/DARPA style evidence.

## Next Work

1. Extract `claim_inventory.csv` from local snapshots.
2. Extract `hardware_metrics.csv` where public fields are available.
3. Score each organization with `QUANTUM_COMPUTING_EVALUATION_RUBRIC.md`.
4. Separate universal gate-model, annealing, analog simulation, photonic networking, software, and security claims.
5. Manually retrieve blocked PDFs/pages if they matter for the final ranking.

## Files

~~~text
indexes/quantum_computing_sources.csv
indexes/quantum_source_coverage.csv
indexes/QUANTUM_COMPUTING_EVALUATION_RUBRIC.md
snapshots/
collect_quantum_sources.ps1
build_quantum_data_index.ps1
~~~
