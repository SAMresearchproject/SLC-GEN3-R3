# Quantum Computing Evaluation Rubric

Private working folder: `D:\quantum_phase\data\quantum_computing`

## Purpose

This rubric is for sorting quantum-computing approaches by evidence quality.
It is not a final verdict on any company.

The working question is:

```text
Who is doing quantum computing right, and who is doing it wrong?
```

The disciplined version is:

```text
Which teams show credible progress toward useful, error-corrected quantum
computation, and which claims are mostly marketing, raw qubit count, or
architecture story without enough public evidence?
```

## Primary Rule

Useful quantum computing is not measured by raw qubit count alone.

High-quality evidence should show at least some of:

- logical qubit behavior
- error correction improving with scale
- transparent hardware metrics
- application-oriented benchmark performance
- reproducible public access or independent validation
- credible path from present hardware to fault-tolerant operation
- clear separation between universal gate-model computing, annealing, simulation,
  networking, sensing, and software-only claims

## Evidence Axes

### E1 - Error Correction And Logical Qubits

High signal:

- below-threshold quantum error correction
- logical error rate below physical error rate
- repeated syndrome extraction / real-time decoding
- logical qubit lifetime improvement
- logical gates, not just logical memory

Low signal:

- raw qubit count without error correction
- error mitigation only, presented like full correction
- single demonstration with no scaling trend

### E2 - Benchmark Integrity

High signal:

- QED-C application-oriented benchmarks
- DARPA QBI or similar independent evaluation
- peer-reviewed benchmark methods
- benchmark circuits with width/depth reporting
- time-to-solution and fidelity reported together

Low signal:

- proprietary single-number metrics without public reproduction
- hand-picked competitor comparisons
- random-circuit supremacy presented as direct business utility
- speedup claims without full classical baseline clarity

### E3 - Hardware Transparency

High signal:

- qubit count, connectivity, gate set, fidelities, coherence, measurement errors,
  reset/mid-circuit measurement, feed-forward, and calibration behavior are
  disclosed.
- datasheets and public docs exist.
- cloud access or independent user access exists.

Low signal:

- press-release-only hardware claims
- no public specs
- no independent access
- claims depend on future hardware rather than current measured behavior

### E4 - Scaling Story

High signal:

- architecture explains wiring, cooling, control, fabrication, networking,
  decoding, and error-correction overhead.
- manufacturing path is credible.
- bottlenecks are named honestly.

Low signal:

- only roadmap dates
- only funding announcements
- no account of control/readout/decoder bottlenecks
- million-qubit claims without subsystem evidence

### E5 - Modality Honesty

High signal:

- annealers are described as annealers.
- analog simulators are described as analog simulators.
- universal gate-model systems are not conflated with special-purpose machines.
- photonic/neutral/trapped/superconducting/topological tradeoffs are stated
  plainly.

Low signal:

- specialized systems marketed as general fault-tolerant computers.
- application demos framed as universal advantage.
- raw physical qubits framed as logical computational capacity.

### E6 - Independent Scrutiny

High signal:

- peer-reviewed papers
- NIST/DARPA/DOE/QED-C context
- public datasets or code
- third-party hardware access

Low signal:

- only company blog or investor deck
- no independent technical paper
- claims not yet reproduced outside the company

## Initial Modality Map

| Modality | Main promise | Main risk |
| --- | --- | --- |
| Superconducting | fast gates, mature fabrication, strong cloud ecosystem | wiring/crosstalk/control overhead and QEC scaling burden |
| Trapped ion | high fidelity, all-to-all connectivity, strong logical/QV evidence | slower gates and scaling modularity |
| Neutral atom | large arrays, reconfigurability, promising logical-qubit path | gate fidelity, loss, transport, and control complexity |
| Photonic | networking/manufacturing/cooling advantages, natural modularity | loss, source/detector/switching overhead, public benchmark gap |
| Topological | huge upside if protected qubits work | evidence burden is very high; claims need independent validation |
| Annealing | practical optimization/sampling niche and deployed systems | not a universal fault-tolerant gate-model computer |

## Initial Watchlist

### Strong Evidence Candidates

- Google Quantum AI: below-threshold surface-code QEC on Willow is a major
  technical signal.
- Quantinuum: trapped-ion quality metrics, quantum volume, and logical/error
  correction work are strong signals.
- IBM: strongest platform/ecosystem/roadmap integration, strong public docs and
  cloud hardware surface.
- Atom/QuEra neutral atom lane: large-array and logical-qubit progress look
  important enough to track closely.

### High-Upside But Evidence-Needs-More Candidates

- PsiQuantum: compelling scale/manufacturing story, but public hardware
  benchmark evidence must catch up to the ambition.
- Xanadu: strong photonic modular/networking story, but needs careful benchmark
  separation between demonstrations and utility-scale fault tolerance.
- Microsoft Majorana/topological: potentially enormous if true, but deserves
  the highest evidence standard because the upside is so large.

### Use-Correctly Candidates

- D-Wave: real annealing platform with useful optimization/sampling angle; judge
  it as annealing, not as a universal gate-model computer.
- Rigetti: useful superconducting competitor data and cloud stack; compare
  against leaders by fidelity, QEC path, and independent benchmarks.
- IonQ: trapped-ion architecture is serious, but proprietary AQ/marketing claims
  should be cross-checked with QED-C/DARPA-style evidence.

## Working Scoring Template

Each organization can be scored 0-3 on:

```text
QEC/logical evidence
benchmark transparency
hardware transparency
scaling credibility
modality honesty
independent scrutiny
```

Suggested classification:

```text
DOING_IT_RIGHT_STRONG_EVIDENCE
DOING_IT_RIGHT_BUT_NEEDS_SCALE
PROMISING_BUT_UNPROVEN
USEFUL_BUT_NARROW
MARKETING_HEAVY_NEEDS_EVIDENCE
WATCH_FOR_OVERCLAIM
```

## Immediate Next Data Tasks

1. Download/snapshot all manifest sources.
2. Extract numeric hardware fields into `hardware_metrics.csv`.
3. Extract claims into `claim_inventory.csv`.
4. Mark claims as `peer_reviewed`, `official_company`, `regulatory`, `third_party`,
   or `marketing`.
5. Score each organization with the template above.
6. Separate universal fault-tolerant computing from annealing, simulation,
   photonic networking, software, and quantum-security claims.
