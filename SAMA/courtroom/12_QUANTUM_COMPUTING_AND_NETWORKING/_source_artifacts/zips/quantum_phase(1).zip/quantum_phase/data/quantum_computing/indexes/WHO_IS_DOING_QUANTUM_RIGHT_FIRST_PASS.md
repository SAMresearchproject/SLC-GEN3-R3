# Who Is Doing Quantum Computing Right - First Pass

Private working folder: `E:\quantum_phase\data\quantum_computing`

This is a first-pass evidence map from the local source harvest. It is not a
final ranking. The scoring target is useful, error-corrected quantum
computation, not raw qubit count or investor excitement.

## Barstool Verdict

The people doing it right are the ones attacking error correction, logical
qubits, benchmarks, and scaling bottlenecks directly.

The people doing it wrong are not necessarily bad companies. The wrong move is
selling raw qubit count, roadmap dates, or special-purpose machines as if that
already means useful universal quantum computing.

## Current Top Signals

| Rank | Organization / lane | Classification | Score / 18 | Why it matters |
| ---: | --- | --- | ---: | --- |
| 1 | IBM Quantum | `DOING_IT_RIGHT_BUT_NEEDS_SCALE` | 17 | Best public ecosystem, roadmap, processor docs, metrics, and platform integration. |
| 2 | Quantinuum | `DOING_IT_RIGHT_STRONG_EVIDENCE` | 16 | Strong trapped-ion quality, logical/error-correction lane, quantum-volume signal. |
| 3 | Google Quantum AI | `DOING_IT_RIGHT_STRONG_EVIDENCE` | 15 | Willow below-threshold QEC is one of the strongest public technical signals in the field. |
| 4 | Atom/Microsoft neutral-atom lane | `DOING_IT_RIGHT_BUT_NEEDS_SCALE` | 14 | Neutral atoms have a credible large-array/logical-qubit scaling lane. |
| 5 | QuEra | `PROMISING_BUT_NEEDS_MORE_PUBLIC_PROOF` | 13 | Neutral-atom direction looks serious, but this corpus needs more hard metrics. |
| 6 | D-Wave | `USEFUL_BUT_NARROW` | 13 | Real annealing hardware; valuable if classified correctly. |
| 7 | IonQ | `SERIOUS_PLATFORM_CROSS_CHECK_MARKETING` | 12 | Serious trapped-ion platform; AQ claims need independent benchmark pressure. |
| 8 | Xanadu | `PROMISING_BUT_NEEDS_BENCHMARK_SEPARATION` | 12 | Photonic modular/networked architecture is interesting; utility-scale claims need careful separation. |
| 9 | PsiQuantum | `PROMISING_BUT_UNPROVEN_AT_HARDWARE_BENCHMARK_LEVEL` | 11 | Strongest manufacturing-scale photonic story, but public benchmark proof lags ambition. |
| 10 | Microsoft topological / Majorana | `HIGH_UPSIDE_HIGHEST_EVIDENCE_BURDEN` | 10 | Potentially massive if validated; evidence burden is unusually high. |
| 11 | Rigetti | `WATCH_AND_COMPARE` | 10 | Useful superconducting competitor lane; not yet a top evidence signal here. |

## What Doing It Right Looks Like

### 1. Error correction first

Google and Quantinuum look serious because the public evidence is not just
more qubits. It is about whether errors can be corrected, suppressed, or used
inside logical computation.

### 2. Benchmarks over slogans

DARPA QBI and QED-C-style application benchmarks are the right pressure.
Any company that only talks in proprietary metrics needs cross-checking.

### 3. Architecture plus bottlenecks

IBM is strong because it documents processors, roadmap, metrics, and the whole
system stack. PsiQuantum is interesting because it has a manufacturing-scale
story, but it needs public hardware benchmark evidence to match the scale of
the promise.

### 4. Modality honesty

D-Wave should not be dismissed, but it should be scored as quantum annealing.
That is useful, but it is not the same claim as a universal fault-tolerant
gate-model quantum computer.

## Strongest Evidence Lanes

### Google Quantum AI

Best signal:

```text
Willow below-threshold surface-code quantum error correction.
```

Why it matters:

Below-threshold QEC means the machine can reduce logical error as the code
distance grows. That is one of the central gates on the road to useful
fault-tolerant quantum computation.

Risk:

The next hard step is moving from memory/QEC demonstration and benchmark wins
to practical logical gates and useful workloads.

### Quantinuum

Best signal:

```text
High-fidelity trapped-ion hardware, H-Series/H2 evidence, quantum-volume record
language, and visible logical/error-correction work.
```

Why it matters:

Trapped ions have excellent fidelity and connectivity. Quantinuum is one of the
cleanest quality-first hardware stories.

Risk:

Scaling and speed remain the major questions.

### IBM Quantum

Best signal:

```text
Roadmap, public docs, Heron processor line, cloud hardware, and metric language.
```

Why it matters:

IBM has the best integrated public platform surface. It is not just one lab
claim; it is a whole stack.

Risk:

The open question is whether the platform turns into fault-tolerant logical
advantage fast enough.

### Neutral Atoms

Best signal:

```text
Large arrays, reconfigurability, long coherence possibilities, and logical-qubit
work through Atom/Microsoft/NIST/QuEra lanes.
```

Why it matters:

Neutral atoms look like one of the most plausible scaling architectures.

Risk:

Need more public end-to-end benchmark evidence, especially with real hardware
and useful logical workloads.

## High-Upside Lanes That Need More Proof

### PsiQuantum

PsiQuantum may be doing the scale problem right by starting from
manufacturing, networking, photonics, and utility-scale architecture. That is
the right kind of ambition.

But the current evidence balance is still:

```text
very strong scale story
less public hardware benchmark proof
```

### Xanadu

Xanadu's photonic modular/networked direction is serious and interesting.
The key is to separate:

```text
photonic demonstration
modular networking
real-time error correction
utility-scale fault-tolerant universal computing
```

Those are connected, but they are not the same milestone.

### Microsoft Topological / Majorana

This is the highest-upside/highest-scrutiny lane. If topological protection is
real and scalable, it changes the game. Because the payoff is huge, the evidence
standard should be even higher.

## The Wrong Moves To Watch For

- Raw physical qubit count treated as useful computational power.
- Annealing marketed like universal gate-model fault tolerance.
- Proprietary metrics presented without QED-C/DARPA-style cross-checks.
- Future roadmap dates presented as current capability.
- Random-circuit or narrow benchmark wins presented as broad practical utility.
- Funding and facility announcements treated like hardware validation.
- Error mitigation language blurred into error correction language.

## Current Data Files

```text
indexes/quantum_computing_sources.csv
indexes/quantum_source_coverage.csv
indexes/quantum_org_scorecard.csv
indexes/QUANTUM_COMPUTING_EVALUATION_RUBRIC.md
indexes/QUANTUM_COMPUTING_DATA_INDEX.md
snapshots/
```

## Next Bite

The next step should be a claim inventory:

```text
claim_inventory.csv
```

Each row should extract one claim, source it, classify it, and grade it:

```text
technical_result
roadmap_claim
benchmark_claim
hardware_spec
marketing_claim
regulatory/risk_disclosure
```

That will let us say who is doing it right with teeth instead of vibes.
