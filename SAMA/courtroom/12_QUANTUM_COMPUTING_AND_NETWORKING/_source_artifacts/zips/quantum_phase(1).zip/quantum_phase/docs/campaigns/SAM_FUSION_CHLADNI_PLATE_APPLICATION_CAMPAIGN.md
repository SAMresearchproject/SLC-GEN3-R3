# SAM Fusion / Chladni Plate Application Campaign

## Purpose

Start a responsible private fusion-technology branch from the existing SAM
particle, Chladni plate, and quantum-phase results.

The core question:

```text
Can SAM identify fusion-favorable shared response geometries before moving to
external nuclear/fusion data?
```

## Starting Inputs

```text
C:/VS/Stam_model-A-v1.0/chladni plate/CH034_SHARED_PLATE_FUSION_DISCOVERY_DEN/
C:/VS/Stam_model-A-v1.0/SAM_CONCEPTUAL_CLOSURE_LEDGER.md
C:/VS/Stam_model-A-v1.0/tests/Substrate/QGA063_TRANSPORTED_RESPONSE_INTERACTION_VERTEX_SURFACE/
C:/VS/Stam_model-A-v1.0/tests/Substrate/QGA064_VERTEX_AMPLITUDE_COUPLING_SELECTOR/
C:/VS/Stam_model-A-v1.0/tests/Substrate/QGA065_LAB_RESPONSE_PLATE_COUPLING_TO_PROBABILITY_SELECTOR/
C:/VS/Stam_model-A-v1.0/tests/Substrate/QGA066_NATIVE_SCATTERING_KERNEL_SELECTOR/
C:/VS/Stam_model-A-v1.0/tests/Substrate/QGA067_SCATTERING_CHANNEL_CONSERVATION_AND_CROSS_SECTION_SELECTOR/
C:/VS/quantum_phase/artifacts/qc001/
C:/VS/quantum_phase/phase4_tables/
```

## Gate Sequence

### FUS001 - Shared Response Closure Metric Freeze

Question:

```text
Can CH034's shared_closure_score, response_burden_delta, and slide_efficiency
be restated in the QGA063-QGA067 interaction language?
```

Output:

```text
fusion_shared_response_metric.csv
```

Success condition:

```text
The fusion toy metric becomes a SAM response-geometry metric, not a visual-only
plate score.
```

Status:

```text
COMPLETE
result_class = FUS001_SHARED_RESPONSE_CLOSURE_METRIC_RESTATED
metric_rows = 10
selected_shared_response_rows = 3
baseline_control_rows_promoted = 0
negative_burden_or_slide_rows_promoted = 0
check_passes = 5/5
wrong_control_passes = 3/3
external_fusion_data_used = false
free_parameters_introduced = 0
next_frontier = FUS002_PRIVATE_A_WINDOW_PULSE_SCAN
```

Result:

```text
PASS. FUS001 restates CH034 shared-plate toy fields as SAM response-geometry
metrics using QGA063-QGA067 without claiming fusion physics.
```

Output:

```text
artifacts/fus001/fusion_shared_response_metric.csv
artifacts/fus001/fusion_shared_response_metric_crosswalk.csv
artifacts/fus001/fusion_qga_interaction_surface.csv
docs/reports/FUS001_PRIVATE_SHARED_RESPONSE_CLOSURE_METRIC_FREEZE.md
```

### FUS002 - A-Window Pulse Scan

Question:

```text
Does the SAM-native A-window around A_SHARE identify a narrow shared-closure
region before destructive reorganization?
```

Required scan bands:

```text
A0
A_SIDE = 1/24
A_SHARE = 1/12
CH034 A_at_min_ramp_separation_mean ~= 0.09050475214827837
CH034 A_at_max_ramp_closure_score_mean ~= 0.12817343039828594
A = 0.20
```

Output:

```text
fusion_a_window_scan.csv
```

Status:

```text
COMPLETE
result_class = FUS002_LOW_A_WINDOW_SELECTED_FOR_NEXT_SCAN
scan_rows = 30
summary_rows = 6
preferred_ramp = A0_TO_0P20
preferred_scenario = clean_separation
preferred_tight_persistence_rate = 0.8
mean_tight_rate_A0_TO_0P20 = 0.46666666666666673
mean_tight_rate_A0_TO_0P99 = 0.26666666666666666
check_passes = 4/4
wrong_control_passes = 3/3
external_fusion_data_used = false
free_parameters_introduced = 0
next_frontier = FUS003_PRIVATE_CARRIER_ENVELOPE_FUSION_CONTROL_SPLIT
```

Result:

```text
PASS. FUS002 selects the low-A A0_TO_0P20 clean_separation lane as the next
fusion application scan region. The A0_TO_0P99 high-A crank-up is rejected as
the preferred next scan.
```

Output:

```text
artifacts/fus002/fusion_a_window_scan.csv
artifacts/fus002/fusion_a_window_summary.csv
docs/reports/FUS002_PRIVATE_A_WINDOW_PULSE_SCAN.md
```

### FUS003 - Carrier / Envelope Fusion Control Split

Question:

```text
Can QC001's carrier/envelope/support split be translated into a fusion control
architecture?
```

Expected structure:

```text
neutral-like protected lane -> shared closure carrier
charged lane               -> steering / readout envelope
8/4 partition lane         -> boundary-stress sensor
material lanes             -> apparatus and isotope support
```

Output:

```text
fusion_carrier_envelope_support_table.csv
```

### FUS004 - Native Fusion Channel Screen

Question:

```text
Which existing SAM composite/isotope rows are closest to shared response
closure under QGA064-QGA067 native kernels?
```

Inputs:

```text
phase4_composite_support_table.csv
phase5_isotope_seed_identity_v1.csv
phase5_numeric_deltaN_binding_mass_v1.csv
QGA067 cross-section candidate summary
```

Output:

```text
fusion_native_channel_screen.csv
```

### FUS005 - Paul Revere Fusion Diagnostic Proposal

Question:

```text
Can pre-resolution boundary stress be monitored as a tuning signal before
final fusion product readout?
```

Output:

```text
fusion_paul_revere_diagnostic_lanes.csv
```

## Handoff Standard

Before this leaves SAM-native work, freeze:

```text
all formulas used
all native constants used
all scanned A bands
all claim boundaries
all external-data exclusions
```

External fusion/nuclear data should enter only after a sealed prediction or
screening manifest exists.
