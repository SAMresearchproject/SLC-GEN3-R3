# SAM QC001-QC0XX Campaign - Particle-Informed Paul Revere Letter

## Launch Pad

This campaign starts from the completed QuantumPhase and particle/isotope stack:

```text
QP012B -> pre-resolution syndrome letter exists
QP014  -> Born-style route weights exist
QP015  -> unresolved interference can bridge to ledger commit
QP016  -> stable self-closure and boundary reorganization modes are selected
QP037  -> particle identity closure is frozen
QP038  -> quantum spaghettification / composite boundary is separated
QP061  -> isotope/element sealed comparison has been opened without mutating predictions
```

The new question is not whether the Paul Revere letter exists. QP012B already
answered that inside the SAM private lane.

The new question is:

```text
Given the particle closure, what physical carrier should carry the
pre-resolution letter, and what physical lane should act only as control,
readout, shielding, or material support?
```

## Core Picture

SAM now separates three things that quantum-computing language often mixes:

```text
unresolved carrier route     -> carries phase/letter before ledger resolution
controlled interaction lane  -> exposes, steers, or reads without being the carrier
material/composite support   -> holds apparatus structure and supplies shielding/isolation
```

The Paul Revere letter can contain:

```text
route family
boundary stress
time to A_SIDE
time to A_SHARE
basin bias
syndrome signal
```

It cannot contain:

```text
final ledger outcome
logical route identity
```

## Campaign Gates

### QC001 - Particle-Informed Paul Revere Carrier Selector

Question:

```text
Which SAM-native particle/route family is the best pre-resolution carrier, and
which families are better understood as control envelope, boundary sensor, or
material support?
```

Inputs:

```text
artifacts/qp012b/qp012b_route_lead_table.csv
artifacts/qp016/qp016_stable_mode_selector_table.csv
artifacts/qp037/qp037_particle_identity_freeze_table.csv
artifacts/qp038/qp038_identity_composite_boundary_table.csv
phase4_tables/phase4_parameter_free_particle_table.csv
phase4_tables/phase4_particle_periodic_matrix.csv
artifacts/qp061/qp061_summary.json
```

Expected output:

```text
primary carrier
control envelope carrier
boundary stress sensor
material/composite support lane
non-primary support lanes
```

Status:

```text
COMPLETE
result_class = QC001_PARTICLE_INFORMED_PAUL_REVERE_CARRIER_SELECTED
primary_letter_carrier = QUBIT-NL-001
primary_letter_particle_family = neutral_lepton_like
control_envelope = QUBIT-CL-001
control_envelope_particle_family = charged_lepton_like
boundary_stress_sensor = QUBIT-UNK-001
support_lanes = 3
external_quantum_hardware_data_used = false
free_parameters_introduced = 0
next_frontier = QC002_PRIVATE_CARRIER_ENVELOPE_SEPARATION_LAW
```

Result:

```text
PASS. QC001 selects the neutral lepton-like unresolved route as the protected
Paul Revere carrier, the charged lepton-like lane as the control/readout
envelope, and the 8/4 boundary route as the basin-stress sensor.
```

### QC002 - Carrier / Envelope Separation Law

Question:

```text
Can SAM separate the protected carrier from the interaction envelope strongly
enough to define a gate primitive?
```

Target readout:

```text
carrier route remains unresolved
control route supplies bounded write pressure
ledger commit is delayed until selected A-resolution
```

Status:

```text
COMPLETE
result_class = QC002_CARRIER_ENVELOPE_SEPARATION_LAW_SELECTED
carrier_route = QUBIT-NL-001
control_envelope_route = QUBIT-CL-001
boundary_sensor_route = QUBIT-UNK-001
carrier_to_envelope_lead_ratio = 107.56674983263241
law_rows = 6
gate_primitives = 5
check_passes = 9/9
wrong_control_passes = 6/6
external_quantum_hardware_data_used = false
free_parameters_introduced = 0
next_frontier = QC003_PRIVATE_PARTICLE_INFORMED_NATIVE_GATE_CATALOG
```

Result:

```text
PASS. QC002 freezes the first QC gate primitive law. The neutral unresolved
lane remains the carrier, the charged lane supplies bounded envelope control,
the 8/4 route reports boundary stress, and QN013 blocks final-answer leakage
before selected write.
```

Output:

```text
artifacts/qc002/qc002_carrier_envelope_separation_law.csv
artifacts/qc002/qc002_gate_primitive_catalog.csv
artifacts/qc002/qc002_gate_boundary_conditions.csv
artifacts/qc002/qc002_pre_write_leakage_firewall.csv
docs/reports/QC002_PRIVATE_CARRIER_ENVELOPE_SEPARATION_LAW.md
```

### QC003 - Particle-Informed Native Gate Catalog

Question:

```text
What native gates follow from carrier/envelope/support separation?
```

Candidate gates:

```text
letter-preserving drift gate
basin-bias steering gate
controlled A-contact gate
delayed-resolution read gate
shielded no-write wait gate
```

Status:

```text
COMPLETE
result_class = QC003_PARTICLE_INFORMED_NATIVE_GATE_CATALOG_SELECTED
native_gates = 5
operation_rows = 20
call_surface_rows = 5
check_passes = 8/8
wrong_control_passes = 6/6
external_quantum_hardware_data_used = false
free_parameters_introduced = 0
next_frontier = QC004_PRIVATE_PAUL_REVERE_READOUT_PROTOCOL
```

Result:

```text
PASS. QC003 converts the QC002 primitive rows into five callable SAM-native
QC gates: shielded no-write wait, drift correction, basin-bias steering,
controlled A-contact, and delayed-resolution read.
```

Output:

```text
artifacts/qc003/qc003_particle_informed_native_gate_catalog.csv
artifacts/qc003/qc003_native_gate_operation_sequence.csv
artifacts/qc003/qc003_gate_call_surface.csv
docs/reports/QC003_PRIVATE_PARTICLE_INFORMED_NATIVE_GATE_CATALOG.md
```

### QC004 - Paul Revere Readout Protocol

Question:

```text
Can a protocol read boundary stress or basin bias before final outcome
resolution without claiming forbidden final-outcome knowledge?
```

Target readout:

```text
letter yes
final outcome no
route identity no
basin pressure yes
```

Status:

```text
COMPLETE
result_class = QC004_PAUL_REVERE_READOUT_PROTOCOL_SELECTED
protocol_rows = 5
allowed_pre_write_observables = 6
blocked_pre_write_observables = 8
sample_events = 6
check_passes = 8/8
wrong_control_passes = 6/6
external_quantum_hardware_data_used = false
free_parameters_introduced = 0
next_frontier = QC005_PRIVATE_MATERIAL_ISOTOPE_SUPPORT_FILTER
```

Result:

```text
PASS. QC004 defines the readout protocol: boundary stress, basin pressure,
timing, and syndrome letters may be read before resolution; final ledger
payloads remain blocked until selected write and hash freeze.
```

Output:

```text
artifacts/qc004/qc004_paul_revere_readout_protocol.csv
artifacts/qc004/qc004_allowed_forbidden_observables.csv
artifacts/qc004/qc004_sample_readout_event_log.csv
docs/reports/QC004_PRIVATE_PAUL_REVERE_READOUT_PROTOCOL.md
```

### QC005 - Material / Isotope Support Filter

Question:

```text
Do the Phase 5 isotope/element results identify material support patterns that
should help isolate the carrier/envelope split?
```

Target readout:

```text
low A-contact support
controlled charged-envelope support
stable composite platform
quantum-spaghettification avoidance band
```

Status:

```text
COMPLETE
result_class = QC005_MATERIAL_ISOTOPE_SUPPORT_FILTER_SELECTED
support_filters = 6
selected_filters = 5
excluded_filters = 1
lane_score_rows = 6
application_rule_rows = 5
check_passes = 8/8
wrong_control_passes = 5/5
external_quantum_hardware_data_used = false
inherited_sealed_isotope_comparison_used = true
free_parameters_introduced = 0
next_frontier = QC_CAMPAIGN_PHASE1_COMPLETE_READY_FOR_REVIEW
```

Result:

```text
PASS. QC005 freezes support filters for the QC lane: use the sealed Z<=96
material band, charged response templates as envelope support only, stable
many-SW composites as scaffold, QP038 shear limits as avoidance rules, and
exclude the superheavy open tail from phase-one baseline support.
```

Output:

```text
artifacts/qc005/qc005_material_isotope_support_filter.csv
artifacts/qc005/qc005_material_lane_scorecard.csv
artifacts/qc005/qc005_qc_application_support_rules.csv
docs/reports/QC005_PRIVATE_MATERIAL_ISOTOPE_SUPPORT_FILTER.md
```

## Phase Posture

This is a forward quantum-computing branch. It does not use external quantum
hardware data as generation input. Hardware data can be used later only as a
comparison lane after native SAM predictions are frozen.

## Phase-One Status

```text
QC001-QC005 complete
phase_one_status = READY_FOR_REVIEW
```
