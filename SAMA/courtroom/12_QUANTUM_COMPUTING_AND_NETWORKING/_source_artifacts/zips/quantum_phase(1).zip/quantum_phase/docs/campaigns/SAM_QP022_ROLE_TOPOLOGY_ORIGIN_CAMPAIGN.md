# SAM QP022 Campaign - Role Topology Origin

Private working folder: `E:\quantum_phase`

License posture: private working material. Sean Brady is originator, author,
and conceptual driver. Codex is co-author and technical collaborator.

## Campaign Status

```text
COMPLETE_PHASE2_QP022_CAMPAIGN
```

This campaign starts after the private QP010-QP021 package survived hostile
review as a scoped bridge package.

Launchpad:

```text
audits/private_hostile_qp010_qp021/AUDIT_VERDICT_POST_RETEST_REVIEW.md
audits/private_hostile_qp010_qp021/ASSESSMENT_POST_RETEST_REVIEW.md
```

## Campaign Purpose

QP017B showed that the QP017 bridge becomes specific when it uses the QP004
route-role topology as a topological selector.

The remaining phase-2 question is upstream:

```text
Can SAM/SUK primitives derive or tightly constrain the QP004 route-role topology?
```

If yes, the bridge improves from:

```text
QP017B uses QP004 topology
```

to:

```text
QP017B uses derived SAM route topology
```

## Guardrails

This is not an audit and not a retest.

```text
test_type = FORWARD_MODEL_BUILD
is_audit_or_retest = False
```

The campaign may read frozen QP004/QP017/QP021 artifacts as comparison or
downstream replay surfaces, but the first derivation attempt must not use QP004
role labels as its selector.

Allowed:

```text
read lower QP artifacts
read QP004 as held-out comparison target
write new QP022 artifacts
write new QP022 reports
```

Forbidden:

```text
modify frozen QP010-QP021 package outputs
modify hostile audit outputs
promote private material to public posture
call comparison to QP004 an independent derivation unless selector inputs are lower-only
```

## Launchpad Facts

Hostile review status:

```text
NO_BLOCKER_FOUND
PRIVATE_SCOPED_BRIDGE_PACKAGE_SURVIVES_HOSTILE_REVIEW
HOSTILE_CERTIFICATION_GRANTED_FOR_SCOPED_PRIVATE_PACKAGE
```

QP017B result:

```text
RT_QP017B_TOPOLOGICAL_ROLE_SELECTOR = PASS
support_challenge_controls_reproducing_full_selector = 0
```

Remaining guard:

```text
QP017 is a topological role bridge, not a direct derivation of all QP004
role/operators from nothing.
```

## Core Hypothesis

The QP004 topology is not arbitrary. It may be recoverable from two lower
surfaces:

```text
QP001 route grammar:
  route names, partitions, native route classes, and exposure ranks

QP003 A_SHARE bounce topology:
  which route contacts become bounce-response write couplings at A_SHARE
```

Expected shape:

```text
CL is the A_SHARE bounce hub.
Neutral role = CL connected to binary neutral return plus neutral identity.
Charged role = CL connected to minus and plus triadic polarity.
Transition role = CL connected to 8+4 route plus owner/color route.
```

## Campaign Gates

### QP022A - Route-Role Topology Inventory

Question:

```text
Do lower artifacts already contain the route nodes, hub, contact pairs, and
lane distinctions needed to reconstruct QP004?
```

Selector inputs:

```text
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp003/qp003_interference_bounce_coupling_table.csv
```

Comparison target:

```text
artifacts/qp004/qp004_phase_role_operator_rules.csv
```

Pass:

```text
derived topology has one CL hub
derived lane endpoint pairs match QP004 required phase pairs exactly
no QP004 role labels are used as selector inputs
```

Boundary:

```text
CL hub is recovered, but one or more lane endpoint groupings require QP004 labels
or an added rule not present in lower artifacts
```

Failure:

```text
CL hub is not recovered or the derived required pairs conflict with QP004
```

### QP022B - CL Hub Origin Rule

Question:

```text
Why is CL the hub rather than merely one connected route?
```

Target:

```text
derive CL hub selection from A_SHARE bounce response and QP001 native class.
```

### QP022C - Lane Separation Rule

Question:

```text
Can neutral, transition, and charged lanes be separated from route grammar alone?
```

Target:

```text
neutral = binary/identity pair
charged = plus/minus triadic polarity pair
transition = 8+4 route plus owner/color route
```

### QP022D - Derived-Topology Replay

Question:

```text
Can QP017B replay using QP022-derived topology instead of imported QP004 topology?
```

Target:

```text
same QP017B selected stable/boundary/charged-carrier result using QP022 outputs.
```

## Desired Campaign Close

```text
QP004 topology becomes derived or tightly constrained from lower SAM/QP
primitives.
QP017B claim guard narrows from "uses QP004 topology" to "uses derived topology."
```

## Completed Gates

### QP022A - Route-Role Topology Inventory

Result:

```text
QP022A_DERIVED_TOPOLOGY_MATCHES_QP004_EXACTLY
derived_hub_route = QUBIT-CL-001
derived_role_families = 3
derived_edges = 6
exact_qp004_rule_matches = 3/3
selector_used_qp004_labels = False
free_parameters_introduced = 0
```

Generated outputs:

```text
artifacts/qp022a/qp022a_summary.json
artifacts/qp022a/qp022a_route_inventory_table.csv
artifacts/qp022a/qp022a_derived_topology_edges.csv
artifacts/qp022a/qp022a_qp004_comparison_table.csv
docs/reports/QP022A_PRIVATE_ROUTE_ROLE_TOPOLOGY_INVENTORY.md
```

### QP022B - CL Hub Origin Rule

Result:

```text
QP022B_CL_HUB_ORIGIN_RULE_SELECTED
selected_hub_route = QUBIT-CL-001
hub_origin_rule_unique = True
selected_matches_qp022a_hub = True
endpoint_routes_covered = 6/6
endpoint_role_families_covered = 3/3
selector_used_qp004_labels = False
free_parameters_introduced = 0
```

Generated outputs:

```text
artifacts/qp022b/qp022b_summary.json
artifacts/qp022b/qp022b_hub_candidate_table.csv
artifacts/qp022b/qp022b_hub_support_edges.csv
docs/reports/QP022B_PRIVATE_CL_HUB_ORIGIN_RULE.md
```

### QP022C - Lane Separation Rule

Result:

```text
QP022C_LANE_SEPARATION_RULE_SELECTED
selected_hub_route = QUBIT-CL-001
derived_lanes = 3
lanes_with_two_endpoints = 3/3
exact_qp004_rule_matches = 3/3
selector_used_qp004_labels = False
free_parameters_introduced = 0
```

Recovered lane grammar:

```text
neutral    = identity-active endpoint plus scalar return endpoint
charged    = minus triadic endpoint plus plus triadic endpoint
transition = 8+4 transition endpoint plus owner/color endpoint
```

Generated outputs:

```text
artifacts/qp022c/qp022c_summary.json
artifacts/qp022c/qp022c_endpoint_lane_table.csv
artifacts/qp022c/qp022c_lane_separation_table.csv
docs/reports/QP022C_PRIVATE_LANE_SEPARATION_RULE.md
```

### QP022D - Derived-Topology Replay

Result:

```text
QP022D_DERIVED_TOPOLOGY_REPLAY_MATCHES_QP017B
selected_hub_route = QUBIT-CL-001
stable_replay_matches = True
boundary_replay_matches = True
charged_replay_matches = True
full_replay_matches = True
selector_used_qp004_labels = False
free_parameters_introduced = 0
```

Replay result:

```text
stable anchor   = QUBIT-NL-001<->QUBIT-NL-001
boundary bridge = QUBIT-NL-001<->QUBIT-UNK-001
charged carrier = QUBIT-CL-001<->QUBIT-TM-001
charged carrier = QUBIT-CL-001<->QUBIT-TP-001
```

Generated outputs:

```text
artifacts/qp022d/qp022d_summary.json
artifacts/qp022d/qp022d_derived_topology_replay_decisions.csv
artifacts/qp022d/qp022d_replay_selection_summary.csv
docs/reports/QP022D_PRIVATE_DERIVED_TOPOLOGY_REPLAY.md
```

## Campaign Close

```text
QP004 topology is now derived/tightly constrained from lower SAM/QP primitives
for the scoped QP017B role-selector use case.

QP017B claim guard narrows from:
  uses QP004 topology

to:
  uses QP022-derived SAM route topology
```

## Follow-On Gate

QP023 has now consumed this campaign close:

```text
QP023_DERIVED_PARTICLE_TABLE_FREEZE_BUILT
particle_table_rows = 12
frozen_mass_surfaces = 4
open_slots = 8
selector_used_qp004_labels = False
legacy_role_operator_column_used_for_selection = False
```

Current next move:

```text
QP024_OPEN_SLOT_FRONTIER_RANKED_NO_NATIVE_PROMOTION
top_stable_frontier = c<->t at 0.6997888706064 A_SIDE
top_charged_frontier = c<->d at 0.34658246814480004 A_SIDE
```

New current next move:

```text
QP025_STABLE_OPEN_REINFORCEMENT_NEAR_A_SIDE
stable_open_fraction_of_A_SIDE = 0.9680235622934329
stable_open_gap_to_A_SIDE = 0.0013323515711069628
charged_open_fraction_of_A_SIDE = 0.44987373432444
```

New current next move:

```text
QP026_STABLE_RESIDUAL_TIGHT_NATIVE_CONTACT
best_native_contact = A0 / (R + 2^D)
fraction_of_gap_closed = 0.9954513667368844
residual_after_best_candidate = 6.060378674501484e-06
```

New current next move:

```text
QP027_ROUTE_EXPOSURE_CRUMB_TIGHT_CONTACT
best_route_bundle = QUBIT-NL-001 + QUBIT-UNK-001 + QUBIT-CL-001
fraction_of_target_closed = 0.9956819669599624
stable_chain_gap_to_A_SIDE = 2.6168915354118916e-08
```

New current next move:

```text
QP028_ULTRA_RESIDUAL_BELOW_ROUTE_EXPOSURE_FLOOR_BOUNDARY
ultra_residual_after_qp027 = 2.6168915354118916e-08
minimum_route_exposure = 4.125668022876614e-08
ultra_residual_fraction_of_minimum_route = 0.6342952270762854
```

New current next move:

```text
QP029_SEALED_BOUNDARY_FLOOR_MATCHES_QP026_NATIVE_CANDIDATE
sealed SAM source = G510I_COSMIC_A_INVENTORY_ACCOUNTING
G510I boundary_inventory = 0.0013262911924324613
QP026 best native contact = A0 / (R + 2^D) = 0.0013262911924324613
absolute_delta_qp026_to_g510i_boundary = 0.0
residual_after_sealed_floor = 6.060378674501484e-06
```

New current next move:

```text
QP030_BOUNDARY_INVENTORY_FLOOR_SELECTED_WITH_LEDGER_COMPLETION_SUPPORT
primary_role = SEALED_BOUNDARY_INVENTORY_FLOOR
secondary_function = LEDGER_CELL_COMPLETION_SUPPORT
blocked_role = ROUTE_CELL_RESIDUAL_QUANTUM
boundary_floor_fraction_of_stable_gap = 0.9954513667368844
ultra_residual_after_route_crumbs = 2.6168915354118916e-08
```

New current next move:

```text
QP031_BOUNDARY_FLOOR_PROPAGATES_STABLE_LANE_TO_ROUTE_FLOOR_LIMIT
single_slot_promotions_after_boundary_floor = 0
prefix_promotions_after_allowed_route_crumbs = 0
lanes_at_route_floor_limit = 1
top_slot_after_boundary_floor = c<->t
top_slot_gap_after_boundary_floor = 0.011182505865634202
top_lane_final_gap_to_A_SIDE = 2.6168915354118916e-08
```

Next frontier:

```text
QP032_PRIVATE_ULTRA_RESIDUAL_WI_MISMATCH_SELECTOR
```

Phase 3 launch result:

```text
QP032_ULTRA_RESIDUAL_SELECTED_AS_WI_MISMATCH_BOUNDARY
W_target = 0.041666666666666664
I_return = 0.04166664049775131
WI_mismatch = 2.6168915354118916e-08
below_whole_route_floor = True
next = QP033_PRIVATE_SLOT_WI_SELF_SUPPORT_TABLE
```

Phase 3 active campaign record:

```text
docs/campaigns/SAM_QP032_QP0XX_PHASE3_WI_CLOSURE_PARTICLE_IDENTITY_CAMPAIGN.md
latest_phase3_gate = QP033_STRONG_SLOT_WI_SELF_SUPPORT_HELD_OPEN
latest_phase3_gate = QP034_LANE_SUPPORT_PARTICLE_IDENTITY_SEPARATED
latest_phase3_gate = QP035_FIXED_POINT_SELECTOR_HELD_OPEN_LOCAL_RETURN_CORRECTION_REQUIRED
latest_phase3_gate = QP036_LOCAL_RETURN_CORRECTION_CONTACT_SELECTED
latest_phase3_gate = QP037_PARTICLE_IDENTITY_FREEZE_ONE_PROMOTION_HELD_OPEN_REST
latest_phase3_gate = QP038_COMPOSITE_STABILITY_QUANTUM_SPAGHETTIFICATION_BOUNDARY_SELECTED
next = QP039_PRIVATE_WI_IDENTITY_TO_COMPOSITE_RETURN_CHANNEL_SELECTOR
```
