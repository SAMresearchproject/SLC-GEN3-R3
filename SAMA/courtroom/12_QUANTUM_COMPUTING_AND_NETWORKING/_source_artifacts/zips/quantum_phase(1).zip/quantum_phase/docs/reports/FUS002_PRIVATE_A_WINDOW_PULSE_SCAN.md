# FUS002 - Private A-Window Pulse Scan

## Result

```text
FUS002_LOW_A_WINDOW_SELECTED_FOR_NEXT_SCAN
```

FUS002 scans existing CH034 A-frequency ramp outputs through the FUS001 shared
response metric frame.

## Main Readout

```text
scan_rows = 30
summary_rows = 6
preferred_ramp = A0_TO_0P20
preferred_scenario = clean_separation
preferred_tight_persistence_rate = 0.8
external_fusion_data_used = False
free_parameters_introduced = 0
claim_status = A_WINDOW_SCREEN_NOT_FUSION_RESULT
```

The useful finding is that the low ramp is cleaner than the high ramp:

```text
A0 -> 0.20 average tight persistence rate = 0.46666666666666673
A0 -> 0.99 average tight persistence rate = 0.26666666666666666
```

## A-Window Summary

| ramp | scenario | tight rate | mean A min separation | A min band | mean A max closure | A max band | preferred |
| --- | --- | ---: | ---: | --- | ---: | --- | --- |
| A0_TO_0P20 | chaos_spray | 0.2 | 0.14725558977493455 | A_SHARE_TO_0P20_REORGANIZATION_WINDOW | 0.121564890354425 | A_SHARE_TO_0P20_REORGANIZATION_WINDOW | False |
| A0_TO_0P20 | clean_separation | 0.8 | 0.05754465867952171 | A_SIDE_TO_A_SHARE_WRITE_CANDIDACY | 0.15398803994461793 | A_SHARE_TO_0P20_REORGANIZATION_WINDOW | True |
| A0_TO_0P20 | test | 0.4 | 0.09050475214827837 | A_SHARE_TO_0P20_REORGANIZATION_WINDOW | 0.12817343039828596 | A_SHARE_TO_0P20_REORGANIZATION_WINDOW | False |
| A0_TO_0P99 | chaos_spray | 0.4 | 0.42567941111135166 | HIGH_A_REORGANIZATION_RISK | 0.5396905219559283 | HIGH_A_REORGANIZATION_RISK | False |
| A0_TO_0P99 | clean_separation | 0.2 | 0.13457257074562215 | A_SHARE_TO_0P20_REORGANIZATION_WINDOW | 0.5509310540110273 | HIGH_A_REORGANIZATION_RISK | False |
| A0_TO_0P99 | test | 0.2 | 0.2155502812650095 | HIGH_A_REORGANIZATION_RISK | 0.6364967367978019 | HIGH_A_REORGANIZATION_RISK | False |

## Checks

| check id | check | pass | detail |
| --- | --- | --- | --- |
| FUS002_CHECK_01 | A0_TO_0P20 average tight persistence exceeds A0_TO_0P99 | True | 0.46666666666666673 > 0.26666666666666666 |
| FUS002_CHECK_02 | clean separation A0_TO_0P20 is best tight persistence lane | True | 0.8 |
| FUS002_CHECK_03 | A_SHARE overlap guard is zero by definition | True | 0.0 |
| FUS002_CHECK_04 | 0.99 ramp is not selected as preferred next scan | True | A0_TO_0P99 |

## Interpretation

FUS002 selects a practical next scan region:

```text
primary window: A0 -> 0.20
best scenario: clean_separation
important band: near A_SHARE, then modestly above it
avoid for next scan: broad A0 -> 0.99 crank-up
```

This does not claim a fusion rate or reactor condition. It says the next SAM
application scan should refine the low-A reorganization window rather than
turning the dial straight toward high-A disruption.

## Next Frontier

```text
FUS003_PRIVATE_CARRIER_ENVELOPE_FUSION_CONTROL_SPLIT
```
