# Phase 4 Particle Table CSV Starts

Generated UTC: 2026-06-08T18:04:00.478102+00:00

Phase 4 freezes the table starting point after QP038:

```text
elementary parameter-free particle rows = 13
composite support rows = 8
composite scaffold rows = 92
element atlas rows = 118
unknown admissible mode rows = 50
```

## CSV Set

```text
phase4_parameter_free_particle_table.csv
phase4_particle_periodic_matrix.csv
phase4_composite_support_table.csv
phase4_composite_scaffold_table.csv
phase4_identity_composite_boundary_table.csv
phase4_a_road_coherence_gate_table.csv
phase4_element_periodic_atlas.csv
phase4_blank_registry.csv
phase4_unknown_mode_candidates.csv
phase4_table_index.csv
phase4_summary.json
```

## Reading

The particle table is the zero-free-parameter elementary surface. The periodic
matrix is PNG-ready. The composite support table is the QGA076 selected support
surface. The scaffold and blank registry tables show the next Phase 4 work.

QP038 adds the key boundary:

```text
single identity closure != many-SW composite support != extended A-road shear
```
