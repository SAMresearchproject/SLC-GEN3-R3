#!/usr/bin/env python3
"""Build Phase 4 CSV table starts from current SAM/QP artifacts."""

from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ART = ROOT / "tests" / "native_prediction_artifacts"
PARTICLES = ROOT / "particles"
COMPOSITES = ROOT / "composites"
QP038 = Path(r"E:\quantum_phase\artifacts\qp038")

OUT = PARTICLES / "phase4_tables"

PARTICLE_CLOSED = PARTICLES / "native_particle_table_closure.csv"
PARTICLE_OPEN = PARTICLES / "native_particle_open_slots.csv"
UNKNOWN_MODES = PARTICLES / "native_particle_unknown_candidates.csv"
ELEMENT_REGISTRY = ART / "sam_element_periodic_registry.csv"
ELEMENT_CONTEXT = ART / "sam_element_periodic_sam_context.csv"
QGA075_MESONS = ART / "qga075_meson_completion_table.csv"
QGA075_BARYONS = ART / "qga075_baryon_completion_table.csv"
QGA076_SUPPORT = ART / "qga076_native_binding_resonance_table.csv"
QP038_BOUNDARY = QP038 / "qp038_identity_composite_boundary_table.csv"
QP038_COHERENCE = QP038 / "qp038_coherence_gate_table.csv"
FREEZE_CORE = ART / "sam_particle_predictor_freeze_v4_1_addendum_2026_06_06" / "sam_particle_predictor_freeze_core_predictions.csv"

NA = "NOT_APPLICABLE"
OPEN = "OPEN_PHASE4"
FILLED = "FILLED_PARAMETER_FREE"


SYMBOL_BY_NATIVE_ID = {
    "SAM-BN-001": "H",
    "SAM-CL-001": "e",
    "SAM-CL-002": "mu",
    "SAM-CL-003": "tau",
    "SAM-TP-001": "u",
    "SAM-TM-001": "d",
    "SAM-TM-002": "s",
    "SAM-TP-002": "c",
    "SAM-TM-003": "b",
    "SAM-TP-003": "t",
    "SAM-NL-001": "nu_e",
    "SAM-NL-002": "nu_mu",
    "SAM-NL-003": "nu_tau",
}

ORDER_BY_SYMBOL = {
    "H": 0,
    "e": 10,
    "mu": 11,
    "tau": 12,
    "nu_e": 20,
    "nu_mu": 21,
    "nu_tau": 22,
    "u": 30,
    "d": 31,
    "s": 32,
    "c": 33,
    "b": 34,
    "t": 35,
}

PERIODIC_SLOTS = {
    "H": ("scalar seed", "seed"),
    "e": ("charged lepton", "GEN1"),
    "mu": ("charged lepton", "GEN2"),
    "tau": ("charged lepton", "GEN3"),
    "nu_e": ("neutral lepton", "GEN1"),
    "nu_mu": ("neutral lepton", "GEN2"),
    "nu_tau": ("neutral lepton", "GEN3"),
    "u": ("triadic +2/3", "GEN1"),
    "c": ("triadic +2/3", "GEN2"),
    "t": ("triadic +2/3", "GEN3"),
    "d": ("triadic -1/3", "GEN1"),
    "s": ("triadic -1/3", "GEN2"),
    "b": ("triadic -1/3", "GEN3"),
}


def read_csv(path: Path) -> list[dict[str, str]]:
    if not path.exists():
        return []
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def clean(value: Any, fallback: str = "") -> str:
    text = str(value if value is not None else "").strip()
    return text if text else fallback


def phase4_grade(mass_status: str) -> str:
    if "AUDIT_GRADE" in mass_status:
        return "AUDIT_GRADE_PARAMETER_FREE"
    if "STRICT" in mass_status or "G616c" in mass_status:
        return "STRICT_PARAMETER_FREE"
    if "NOT_APPLICABLE" in mass_status:
        return "NOT_PARTICLE_MASS_ROW"
    return "PARAMETER_FREE_FILLED"


def grade_from_freeze(row: dict[str, str]) -> str:
    grade = row.get("grade", "").upper()
    if grade == "AUDIT":
        return "AUDIT_GRADE_PARAMETER_FREE"
    if grade == "STRICT":
        return "STRICT_PARAMETER_FREE"
    return "PARAMETER_FREE_FILLED"


def particle_row(source: dict[str, str], source_table: str) -> dict[str, Any] | None:
    native_id = source.get("native_id", "")
    symbol = SYMBOL_BY_NATIVE_ID.get(native_id)
    if symbol is None:
        return None
    mass_status = clean(source.get("mass_status"))
    return {
        "phase4_order": ORDER_BY_SYMBOL[symbol],
        "symbol": symbol,
        "native_id": native_id,
        "native_family": source.get("native_family", ""),
        "generation_or_depth": source.get("native_generation_or_depth", ""),
        "mode_partition": source.get("mode_partition", ""),
        "subchannel_partition": source.get("subchannel_partition", ""),
        "mass_MeV": source.get("mass_native", ""),
        "mass_formula": source.get("mass_native_formula", ""),
        "mass_status": mass_status,
        "parameter_free_grade": phase4_grade(mass_status),
        "free_parameters_used": 0,
        "charge_axis": source.get("Q_native_axis", ""),
        "charge_class": source.get("Q_native_class", ""),
        "spin_native": source.get("spin_native", ""),
        "spin_class": source.get("spin_native_class", ""),
        "color_native": source.get("color_native", ""),
        "color_axis": source.get("color_native_axis", ""),
        "route_family": source.get("route_family", ""),
        "C_A_class": source.get("C_A_class", ""),
        "I_A_class": source.get("I_A_class", ""),
        "ownership_class": source.get("ownership_class", ""),
        "blank_status": FILLED,
        "source_table": source_table,
    }


def build_particle_metadata() -> dict[str, dict[str, Any]]:
    rows_by_symbol: dict[str, dict[str, Any]] = {}
    for row in read_csv(PARTICLE_CLOSED):
        built = particle_row(row, "particles/native_particle_table_closure.csv")
        if built:
            rows_by_symbol[str(built["symbol"])] = built
    for row in read_csv(PARTICLE_OPEN):
        built = particle_row(row, "particles/native_particle_open_slots.csv")
        if built and built["symbol"] not in {"owner_x", "owner_y", "owner_z"}:
            rows_by_symbol[str(built["symbol"])] = built
    return rows_by_symbol


def build_particles() -> list[dict[str, Any]]:
    metadata = build_particle_metadata()
    rows: list[dict[str, Any]] = []
    for freeze in read_csv(FREEZE_CORE):
        symbol = freeze["particle"]
        meta = metadata.get(symbol, {})
        rows.append(
            {
                "phase4_order": ORDER_BY_SYMBOL[symbol],
                "symbol": symbol,
                "native_id": meta.get("native_id", freeze.get("prediction_id", "")),
                "native_family": meta.get("native_family", freeze.get("sector", "")),
                "generation_or_depth": meta.get("generation_or_depth", freeze.get("sector", "")),
                "mode_partition": meta.get("mode_partition", ""),
                "subchannel_partition": meta.get("subchannel_partition", ""),
                "mass_MeV": freeze["derived_mass_MeV"],
                "mass_formula": meta.get("mass_formula", ""),
                "mass_status": f"FROZEN_V4_1_{freeze['grade'].upper()}_PREDICTION",
                "parameter_free_grade": grade_from_freeze(freeze),
                "free_parameters_used": freeze.get("free_parameters", "0"),
                "charge_axis": freeze.get("Q", meta.get("charge_axis", "")),
                "charge_class": meta.get("charge_class", ""),
                "spin_native": freeze.get("spin", meta.get("spin_native", "")),
                "spin_class": meta.get("spin_class", ""),
                "color_native": meta.get("color_native", ""),
                "color_axis": meta.get("color_axis", ""),
                "route_family": meta.get("route_family", ""),
                "C_A_class": meta.get("C_A_class", ""),
                "I_A_class": meta.get("I_A_class", ""),
                "ownership_class": meta.get("ownership_class", ""),
                "blank_status": FILLED,
                "source_table": "tests/native_prediction_artifacts/sam_particle_predictor_freeze_v4_1_addendum_2026_06_06/sam_particle_predictor_freeze_core_predictions.csv",
            }
        )
    rows.sort(key=lambda row: int(row["phase4_order"]))
    return rows


def particle_label(row: dict[str, Any]) -> str:
    return (
        f"{row['symbol']}: m={row['mass_MeV']} MeV; "
        f"Q={row['charge_axis']}; spin={row['spin_native']}; "
        f"{row['parameter_free_grade']}"
    )


def build_periodic_matrix(particle_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_symbol = {row["symbol"]: row for row in particle_rows}
    lanes = [
        "scalar seed",
        "charged lepton",
        "neutral lepton",
        "triadic +2/3",
        "triadic -1/3",
        "native color triad readout",
    ]
    matrix: dict[str, dict[str, Any]] = {
        lane: {
            "lane": lane,
            "seed": NA,
            "GEN1": NA,
            "GEN2": NA,
            "GEN3": NA,
            "phase4_status": FILLED,
            "blank_to_fill": "",
        }
        for lane in lanes
    }
    for symbol, (lane, slot) in PERIODIC_SLOTS.items():
        if symbol in by_symbol:
            matrix[lane][slot] = particle_label(by_symbol[symbol])
    matrix["native color triad readout"]["GEN1"] = "owner_x: native_color_value=3; external_label=NOT_ASSIGNED"
    matrix["native color triad readout"]["GEN2"] = "owner_y: native_color_value=3; external_label=NOT_ASSIGNED"
    matrix["native color triad readout"]["GEN3"] = "owner_z: native_color_value=3; external_label=NOT_ASSIGNED"
    matrix["native color triad readout"]["phase4_status"] = "FILLED_NATIVE_VALUE_EXTERNAL_LABELS_NOT_ASSIGNED"
    matrix["native color triad readout"]["blank_to_fill"] = "None for SAM-native table; external color names intentionally not assigned"
    return [matrix[lane] for lane in lanes]


def build_composite_support() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in read_csv(QGA076_SUPPORT):
        rows.append(
            {
                "composite_id": row.get("composite_id", ""),
                "symbol": row.get("symbol", ""),
                "branch": row.get("branch", ""),
                "constituents": row.get("constituents", ""),
                "constituent_sum_MeV": row.get("constituent_sum_MeV", ""),
                "sam_mass_MeV": row.get("sam_mass_MeV", ""),
                "stability_class": row.get("stability_class", ""),
                "confinement_status": row.get("confinement_status", ""),
                "resonance_status": row.get("resonance_status", ""),
                "mass_readout_status": row.get("mass_readout_status", ""),
                "formula": row.get("formula", ""),
                "free_parameters_used": 0,
                "phase4_status": "FILLED_NATIVE_COMPOSITE_SUPPORT",
                "source": "QGA076_NATIVE_BINDING_CONFINEMENT_RESONANCE_SELECTOR",
            }
        )
    return rows


def build_composite_scaffolds() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in read_csv(QGA075_MESONS):
        mass_status = row.get("mass_readout_status", "") or row.get("mass_prediction_status", "")
        rows.append(
            {
                "scaffold_type": "MESON_Q_ANTI_Q",
                "scaffold_id": row.get("scaffold_id", "") or row.get("slot_id", ""),
                "constituents": row.get("constituents", "") or f"{row.get('left_quark', '')};{row.get('right_antiquark', '')}",
                "charge": row.get("charge", ""),
                "constituent_mass_sum_MeV": row.get("constituent_mass_sum_MeV", ""),
                "identity_status": row.get("identity_status", "") or row.get("fill_status", ""),
                "mass_status": mass_status,
                "selector_needed": row.get("selector_needed", ""),
                "phase4_status": OPEN if "OPEN" in mass_status else "SCAFFOLD_AVAILABLE",
            }
        )
    for row in read_csv(QGA075_BARYONS):
        rows.append(
            {
                "scaffold_type": "BARYON_QQQ",
                "scaffold_id": row.get("slot_id", ""),
                "constituents": row.get("constituents", ""),
                "charge": row.get("charge", ""),
                "constituent_mass_sum_MeV": row.get("constituent_sum_MeV", ""),
                "identity_status": row.get("fill_status", ""),
                "mass_status": row.get("mass_prediction_status", ""),
                "selector_needed": row.get("selector_needed", ""),
                "phase4_status": OPEN if "OPEN" in row.get("mass_prediction_status", "") else "SCAFFOLD_AVAILABLE",
            }
        )
    return rows


def build_element_atlas() -> list[dict[str, Any]]:
    return [
        {
            "atomic_number": row.get("atomic_number", ""),
            "symbol": row.get("symbol", ""),
            "name": row.get("name", ""),
            "period": row.get("period", ""),
            "group": row.get("group", ""),
            "block": row.get("block", ""),
            "category": row.get("category", ""),
            "sam_formation_lane": row.get("sam_formation_lane", ""),
            "sam_context_provenance": row.get("sam_context_provenance", ""),
            "A_local_at_formation": row.get("A_local_at_formation", ""),
            "log_abundance": row.get("log_abundance", ""),
            "regime": row.get("regime", ""),
            "phase4_status": "ELEMENT_SLOT_REGISTERED",
            "blank_to_fill": row.get("next_selector", "NUCLEAR_BINDING_AND_ISOTOPE_A_ROAD_SELECTOR"),
        }
        for row in read_csv(ELEMENT_REGISTRY)
    ]


def build_boundary_rows() -> list[dict[str, Any]]:
    rows = read_csv(QP038_BOUNDARY)
    for row in rows:
        row["phase4_role"] = "QP038_IDENTITY_COMPOSITE_BOUNDARY"
    return rows


def build_coherence_rows() -> list[dict[str, Any]]:
    rows = read_csv(QP038_COHERENCE)
    for row in rows:
        row["phase4_role"] = "A_ROAD_COHERENCE_GATE"
    return rows


def build_blank_registry(
    unknown_rows: list[dict[str, str]],
    scaffolds: list[dict[str, Any]],
    element_rows: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    meson_open = sum(1 for row in scaffolds if row["scaffold_type"] == "MESON_Q_ANTI_Q" and row["phase4_status"] == OPEN)
    baryon_open = sum(1 for row in scaffolds if row["scaffold_type"] == "BARYON_QQQ" and row["phase4_status"] == OPEN)
    element_context = sum(1 for row in element_rows if row.get("A_local_at_formation"))
    return [
        {
            "blank_group": "QP039_return_channel",
            "count": 1,
            "current_status": "NEXT_PHASE4_SELECTOR",
            "selector_needed": "QP039_PRIVATE_WI_IDENTITY_TO_COMPOSITE_RETURN_CHANNEL_SELECTOR",
            "source": "E:/quantum_phase/artifacts/qp038/qp038_summary.json",
            "notes": "Connect frozen W/I identity to many-SW composite return channel.",
        },
        {
            "blank_group": "unknown_subchannel_modes",
            "count": len(unknown_rows),
            "current_status": OPEN,
            "selector_needed": "V4.1 carrier selector for admissible layered partitions",
            "source": "particles/native_particle_unknown_candidates.csv",
            "notes": "Admissible substrate-string partitions without assigned particle carrier.",
        },
        {
            "blank_group": "meson_scaffold_mass_readouts",
            "count": meson_open,
            "current_status": OPEN,
            "selector_needed": "native_binding_confinement_resonance_selector",
            "source": "tests/native_prediction_artifacts/qga075_meson_completion_table.csv",
            "notes": "QGA075 identity scaffolds available; QGA076 selected the first support set.",
        },
        {
            "blank_group": "baryon_scaffold_mass_readouts",
            "count": baryon_open,
            "current_status": OPEN,
            "selector_needed": "QGA076_NATIVE_BINDING_CONFINEMENT_RESONANCE_SELECTOR extensions",
            "source": "tests/native_prediction_artifacts/qga075_baryon_completion_table.csv",
            "notes": "Baryon identity scaffolds available; full family support remains Phase 4 work.",
        },
        {
            "blank_group": "element_isotope_binding_layer",
            "count": len(element_rows),
            "current_status": "ELEMENT_SLOTS_REGISTERED_CONTEXT_PARTIAL",
            "selector_needed": "NUCLEAR_BINDING_AND_ISOTOPE_A_ROAD_SELECTOR",
            "source": "tests/native_prediction_artifacts/sam_element_periodic_registry.csv",
            "notes": f"{element_context} element/context rows currently carry A_local data.",
        },
        {
            "blank_group": "external_color_names",
            "count": 3,
            "current_status": "NOT_ASSIGNED_BY_DESIGN",
            "selector_needed": "NONE_FOR_SAM_NATIVE_TABLE",
            "source": "G676c native triadic color readout",
            "notes": "SAM-native color value is 3; external red/green/blue labels are not a SAM blank.",
        },
    ]


def write_readme(summary: dict[str, Any]) -> None:
    (OUT / "README_PHASE4_TABLES.md").write_text(
        f"""# Phase 4 Particle Table CSV Starts

Generated UTC: {summary['generated_at_utc']}

Phase 4 freezes the table starting point after QP038:

```text
elementary parameter-free particle rows = {summary['particle_rows']}
composite support rows = {summary['composite_support_rows']}
composite scaffold rows = {summary['composite_scaffold_rows']}
element atlas rows = {summary['element_rows']}
unknown admissible mode rows = {summary['unknown_mode_rows']}
```

## CSV Set

```text
phase4_parameter_free_particle_table.csv
phase4_particle_periodic_matrix.csv
phase4_composite_support_table.csv
phase4_composite_scaffold_table.csv
phase4_identity_composite_boundary_table.csv
phase4_a_road_coherence_gate_table.csv
phase4_element_periodic_atlas.csv
phase4_blank_registry.csv
phase4_unknown_mode_candidates.csv
phase4_table_index.csv
phase4_summary.json
```

## Reading

The particle table is the zero-free-parameter elementary surface. The periodic
matrix is PNG-ready. The composite support table is the QGA076 selected support
surface. The scaffold and blank registry tables show the next Phase 4 work.

QP038 adds the key boundary:

```text
single identity closure != many-SW composite support != extended A-road shear
```
""",
        encoding="utf-8",
    )


def main() -> None:
    generated_at = datetime.now(timezone.utc).isoformat()
    particle_rows = build_particles()
    periodic_rows = build_periodic_matrix(particle_rows)
    composite_support = build_composite_support()
    composite_scaffolds = build_composite_scaffolds()
    element_rows = build_element_atlas()
    boundary_rows = build_boundary_rows()
    coherence_rows = build_coherence_rows()
    unknown_rows = read_csv(UNKNOWN_MODES)
    blank_rows = build_blank_registry(unknown_rows, composite_scaffolds, element_rows)

    particle_fields = [
        "phase4_order",
        "symbol",
        "native_id",
        "native_family",
        "generation_or_depth",
        "mode_partition",
        "subchannel_partition",
        "mass_MeV",
        "mass_formula",
        "mass_status",
        "parameter_free_grade",
        "free_parameters_used",
        "charge_axis",
        "charge_class",
        "spin_native",
        "spin_class",
        "color_native",
        "color_axis",
        "route_family",
        "C_A_class",
        "I_A_class",
        "ownership_class",
        "blank_status",
        "source_table",
    ]
    periodic_fields = ["lane", "seed", "GEN1", "GEN2", "GEN3", "phase4_status", "blank_to_fill"]
    support_fields = [
        "composite_id",
        "symbol",
        "branch",
        "constituents",
        "constituent_sum_MeV",
        "sam_mass_MeV",
        "stability_class",
        "confinement_status",
        "resonance_status",
        "mass_readout_status",
        "formula",
        "free_parameters_used",
        "phase4_status",
        "source",
    ]
    scaffold_fields = [
        "scaffold_type",
        "scaffold_id",
        "constituents",
        "charge",
        "constituent_mass_sum_MeV",
        "identity_status",
        "mass_status",
        "selector_needed",
        "phase4_status",
    ]
    element_fields = [
        "atomic_number",
        "symbol",
        "name",
        "period",
        "group",
        "block",
        "category",
        "sam_formation_lane",
        "sam_context_provenance",
        "A_local_at_formation",
        "log_abundance",
        "regime",
        "phase4_status",
        "blank_to_fill",
    ]
    blank_fields = ["blank_group", "count", "current_status", "selector_needed", "source", "notes"]
    index_fields = ["table_file", "rows", "purpose", "png_use"]

    write_csv(OUT / "phase4_parameter_free_particle_table.csv", particle_rows, particle_fields)
    write_csv(OUT / "phase4_particle_periodic_matrix.csv", periodic_rows, periodic_fields)
    write_csv(OUT / "phase4_composite_support_table.csv", composite_support, support_fields)
    write_csv(OUT / "phase4_composite_scaffold_table.csv", composite_scaffolds, scaffold_fields)
    write_csv(OUT / "phase4_identity_composite_boundary_table.csv", boundary_rows, list(boundary_rows[0].keys()) if boundary_rows else [])
    write_csv(OUT / "phase4_a_road_coherence_gate_table.csv", coherence_rows, list(coherence_rows[0].keys()) if coherence_rows else [])
    write_csv(OUT / "phase4_element_periodic_atlas.csv", element_rows, element_fields)
    write_csv(OUT / "phase4_blank_registry.csv", blank_rows, blank_fields)
    write_csv(OUT / "phase4_unknown_mode_candidates.csv", unknown_rows, list(unknown_rows[0].keys()) if unknown_rows else [])

    index_rows = [
        {
            "table_file": "phase4_parameter_free_particle_table.csv",
            "rows": len(particle_rows),
            "purpose": "13 filled elementary particle mass rows",
            "png_use": "main particle fact table",
        },
        {
            "table_file": "phase4_particle_periodic_matrix.csv",
            "rows": len(periodic_rows),
            "purpose": "native lane/generation particle periodic matrix",
            "png_use": "particle periodic table graphic",
        },
        {
            "table_file": "phase4_composite_support_table.csv",
            "rows": len(composite_support),
            "purpose": "selected native composite support and mass readouts",
            "png_use": "composite support snapshot",
        },
        {
            "table_file": "phase4_composite_scaffold_table.csv",
            "rows": len(composite_scaffolds),
            "purpose": "meson and baryon identity scaffolds",
            "png_use": "blank-fill depth map",
        },
        {
            "table_file": "phase4_identity_composite_boundary_table.csv",
            "rows": len(boundary_rows),
            "purpose": "QP038 local identity versus composite support boundary",
            "png_use": "identity/composite separator graphic",
        },
        {
            "table_file": "phase4_a_road_coherence_gate_table.csv",
            "rows": len(coherence_rows),
            "purpose": "quantum spaghettification A-road coherence ladder",
            "png_use": "velocity/A milestone graphic",
        },
        {
            "table_file": "phase4_element_periodic_atlas.csv",
            "rows": len(element_rows),
            "purpose": "118 element registry with SAM context columns",
            "png_use": "chemistry-facing atlas",
        },
        {
            "table_file": "phase4_blank_registry.csv",
            "rows": len(blank_rows),
            "purpose": "clear Phase 4 blanks to fill",
            "png_use": "roadmap/legend",
        },
        {
            "table_file": "phase4_unknown_mode_candidates.csv",
            "rows": len(unknown_rows),
            "purpose": "admissible but unassigned native mode candidates",
            "png_use": "candidate appendix",
        },
    ]
    write_csv(OUT / "phase4_table_index.csv", index_rows, index_fields)

    summary = {
        "artifact": "SAM_PHASE4_PARTICLE_TABLE_STARTS",
        "generated_at_utc": generated_at,
        "source_scope": "REPO_NATIVE_SAM_ARTIFACTS_PLUS_QP038_DOWNSTREAM_BOUNDARY",
        "new_test_run": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "particle_rows": len(particle_rows),
        "periodic_matrix_rows": len(periodic_rows),
        "composite_support_rows": len(composite_support),
        "composite_scaffold_rows": len(composite_scaffolds),
        "element_rows": len(element_rows),
        "unknown_mode_rows": len(unknown_rows),
        "blank_registry_rows": len(blank_rows),
        "phase4_starting_point": "13 elementary particle rows filled; composite and nuclear layers have explicit next selectors",
        "next_selector": "QP039_PRIVATE_WI_IDENTITY_TO_COMPOSITE_RETURN_CHANNEL_SELECTOR",
    }
    write_json(OUT / "phase4_summary.json", summary)
    write_readme(summary)

    print("SAM_PHASE4_PARTICLE_TABLE_STARTS")
    print(f"particle_rows={len(particle_rows)}")
    print(f"periodic_matrix_rows={len(periodic_rows)}")
    print(f"composite_support_rows={len(composite_support)}")
    print(f"composite_scaffold_rows={len(composite_scaffolds)}")
    print(f"element_rows={len(element_rows)}")
    print(f"unknown_mode_rows={len(unknown_rows)}")
    print(f"out={OUT}")


if __name__ == "__main__":
    main()
