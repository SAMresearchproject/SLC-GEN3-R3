#!/usr/bin/env python3
"""Patch Phase 4 table PNG reading notes after visual review."""

from __future__ import annotations

from pathlib import Path

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent


BG = (5, 18, 34)
PANEL = (7, 24, 43)
BORDER = (40, 155, 205)
TEXT = (229, 241, 255)
MUTED = (168, 190, 215)
CYAN = (78, 224, 242)


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = [
        Path(r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf"),
        Path(r"C:\Windows\Fonts\segoeuib.ttf" if bold else r"C:\Windows\Fonts\segoeui.ttf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size)
    return ImageFont.load_default()


def bullet(draw: ImageDraw.ImageDraw, xy: tuple[int, int], text: str, size: int = 21) -> None:
    x, y = xy
    r = max(4, size // 4)
    draw.ellipse((x, y + 5, x + 2 * r, y + 5 + 2 * r), fill=CYAN)
    draw.text((x + 26, y), text, fill=MUTED, font=font(size))


def patch_particle_table() -> None:
    path = ROOT / "phase4_parameter_free_particle_table.png"
    im = Image.open(path).convert("RGB")
    draw = ImageDraw.Draw(im)

    # Replace the lower reading note, which was clipped and overstated strict status.
    box = (110, 1540, 2290, 1688)
    draw.rounded_rectangle(box, radius=20, fill=PANEL, outline=BORDER, width=2)
    draw.text((140, 1573), "Reading the table", fill=TEXT, font=font(29, bold=True))
    bullet(
        draw,
        (142, 1628),
        "Bar length is logarithmic mass within this dataset; charge colors mark native charge sign.",
        size=20,
    )
    bullet(
        draw,
        (142, 1661),
        "All rows are parameter-free: 11 strict, 2 audit-grade. Native color: D = triadic, 1 = single-track.",
        size=20,
    )

    # Clarify that this column is SAM-native color/readout, not an external color name.
    header_box = (1538, 453, 1659, 501)
    draw.rectangle(header_box, fill=(22, 48, 78))
    draw.text((1553, 464), "Native", fill=TEXT, font=font(19, bold=True))
    draw.text((1554, 486), "color", fill=TEXT, font=font(19, bold=True))

    im.save(path)


def patch_scaffold_matrix() -> None:
    path = ROOT / "phase4_composite_scaffold_table.png"
    im = Image.open(path).convert("RGB")
    draw = ImageDraw.Draw(im)

    # Replace the right-hand bullets to distinguish open composite readout from
    # already available constituent-sum support.
    box = (360, 956, 1385, 1032)
    draw.rounded_rectangle(box, radius=8, fill=PANEL)
    bullet(
        draw,
        (370, 962),
        "Phase 4 open means the composite binding/readout selector is still the next layer.",
        size=13,
    )
    bullet(
        draw,
        (370, 987),
        "STRICT marks constituent-sum support; OPEN marks slots awaiting selector.",
        size=13,
    )
    bullet(
        draw,
        (370, 1012),
        "Surface: 36 meson q anti-q scaffolds; 56 baryon qqq scaffolds.",
        size=13,
    )

    im.save(path)


def main() -> None:
    patch_particle_table()
    patch_scaffold_matrix()
    print("updated phase4_parameter_free_particle_table.png")
    print("updated phase4_composite_scaffold_table.png")


if __name__ == "__main__":
    main()
