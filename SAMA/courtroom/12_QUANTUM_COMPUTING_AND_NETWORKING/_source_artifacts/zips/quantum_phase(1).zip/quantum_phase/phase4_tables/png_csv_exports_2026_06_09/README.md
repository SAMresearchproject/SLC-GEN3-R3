# PNG CSV Exports - 2026-06-09

## Purpose

Spreadsheet-ready CSV exports for making updated SAM particle, composite,
element, and isotope PNG tables.

These files are visual/readout exports only. They do not introduce new tests,
new selectors, new external data, or new predictions.

## Source State

```text
source_repo = C:\VS\quantum_phase
export_date = 2026-06-09
source_tables = phase4_tables + artifacts/qp061
public_repo_write = false
new_test_run = false
free_parameters_introduced = 0
```

## Files

See:

```text
sam_png_csv_export_index_2026_06_09.csv
```

Sean's requested PNG set:

```text
phase4_parameter_free_particle_table_2026_06_09.csv
phase4_composite_support_table_2026_06_09.csv
phase4_composite_scaffold_table_2026_06_09.csv
phase4_particle_periodic_matrix_2026_06_09.csv
sam_periodic_table_z001_z118_2026_06_09.csv
```

Main visual tables:

```text
sam_particle_rest_rows_2026_06_09.csv
sam_particle_periodic_matrix_2026_06_09.csv
sam_composite_support_rows_2026_06_09.csv
sam_particle_composite_freeze_rows_2026_06_09.csv
sam_element_primary_roster_2026_06_09.csv
sam_isotope_vault_rows_2026_06_09.csv
sam_qp061_band_summary_2026_06_09.csv
sam_qp061_lane_summary_2026_06_09.csv
sam_phase5_anchor_digest_2026_06_09.csv
```

## Suggested PNG Order

```text
1. sam_particle_periodic_matrix_2026_06_09.csv
2. sam_particle_rest_rows_2026_06_09.csv
3. sam_composite_support_rows_2026_06_09.csv
4. sam_element_primary_roster_2026_06_09.csv
5. sam_qp061_band_summary_2026_06_09.csv
6. sam_phase5_anchor_digest_2026_06_09.csv
```

Use the full isotope vault and composite freeze tables when you want detail
rather than a compact visual.

For the exact requested PNG pass, use:

```text
1. phase4_particle_periodic_matrix_2026_06_09.csv
2. phase4_parameter_free_particle_table_2026_06_09.csv
3. phase4_composite_support_table_2026_06_09.csv
4. phase4_composite_scaffold_table_2026_06_09.csv
5. sam_periodic_table_z001_z118_2026_06_09.csv
```
