#!/usr/bin/env python3
"""Render private Phase 4 tables as PNG snapshots.

This is a presentation renderer only. It does not run a gate or change source
CSV data.
"""

from __future__ import annotations

import csv
import json
import math
from collections import Counter
from pathlib import Path
from typing import Any

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "phase4_tables"
ARTIFACTS = ROOT / "artifacts"

BG = (242, 247, 250)
PANEL = (255, 255, 255)
INK = (23, 34, 49)
MUTED = (85, 101, 119)
GRID = (203, 213, 225)
NAVY = (20, 31, 47)
BLUE = (37, 99, 235)
CYAN = (8, 145, 178)
TEAL = (13, 148, 136)
GREEN = (22, 163, 74)
AMBER = (217, 119, 6)
RED = (220, 38, 38)
PURPLE = (124, 58, 237)
PALE_BLUE = (219, 234, 254)
PALE_TEAL = (204, 251, 241)
PALE_GREEN = (220, 252, 231)
PALE_AMBER = (254, 243, 199)
PALE_RED = (254, 226, 226)
PALE_PURPLE = (237, 233, 254)
PALE_GRAY = (241, 245, 249)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = [
        Path(r"C:\Windows\Fonts\segoeuib.ttf" if bold else r"C:\Windows\Fonts\segoeui.ttf"),
        Path(r"C:\Windows\Fonts\arialbd.ttf" if bold else r"C:\Windows\Fonts\arial.ttf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size)
    return ImageFont.load_default()


F10 = font(10)
F11 = font(11)
F12 = font(12)
F13 = font(13)
F14 = font(14)
F16 = font(16)
F18 = font(18)
F20 = font(20, True)
F24 = font(24, True)
F32 = font(32, True)
F42 = font(42, True)


def text_width(text: str, fnt: ImageFont.ImageFont) -> int:
    box = fnt.getbbox(text)
    return box[2] - box[0]


def wrap_text(text: Any, fnt: ImageFont.ImageFont, max_width: int, max_lines: int | None = None) -> list[str]:
    words = str(text if text is not None else "").replace("_", "_").split()
    if not words:
        return [""]
    lines: list[str] = []
    current = ""
    for word in words:
        trial = word if not current else f"{current} {word}"
        if text_width(trial, fnt) <= max_width:
            current = trial
            continue
        if current:
            lines.append(current)
        current = word
        while text_width(current, fnt) > max_width and len(current) > 4:
            cut = max(4, int(len(current) * max_width / max(text_width(current, fnt), 1)) - 1)
            lines.append(current[:cut])
            current = current[cut:]
    if current:
        lines.append(current)
    if max_lines is not None and len(lines) > max_lines:
        lines = lines[:max_lines]
        lines[-1] = lines[-1].rstrip(". ") + "..."
    return lines


def draw_text_lines(
    draw: ImageDraw.ImageDraw,
    xy: tuple[int, int],
    lines: list[str],
    fnt: ImageFont.ImageFont,
    fill: tuple[int, int, int] = INK,
    line_gap: int = 4,
) -> int:
    x, y = xy
    step = fnt.size + line_gap if hasattr(fnt, "size") else 16
    for line in lines:
        draw.text((x, y), line, fill=fill, font=fnt)
        y += step
    return y


def draw_header(draw: ImageDraw.ImageDraw, title: str, subtitle: str, width: int, tag: str) -> int:
    draw.rectangle((0, 0, width, 118), fill=NAVY)
    draw.text((42, 28), title, fill=(255, 255, 255), font=F42)
    draw.text((44, 82), subtitle, fill=(190, 219, 255), font=F16)
    tag_w = text_width(tag, F14) + 30
    draw.rounded_rectangle((width - tag_w - 42, 38, width - 42, 76), radius=8, fill=(30, 64, 105))
    draw.text((width - tag_w - 27, 48), tag, fill=(219, 234, 254), font=F14)
    return 146


def draw_summary_cards(
    draw: ImageDraw.ImageDraw,
    cards: list[tuple[str, str, tuple[int, int, int]]],
    x: int,
    y: int,
    width: int,
) -> int:
    gap = 16
    card_w = (width - gap * (len(cards) - 1)) // len(cards)
    for i, (label, value, color) in enumerate(cards):
        cx = x + i * (card_w + gap)
        draw.rounded_rectangle((cx, y, cx + card_w, y + 94), radius=12, fill=PANEL, outline=GRID, width=1)
        draw.rectangle((cx, y, cx + 8, y + 94), fill=color)
        draw.text((cx + 22, y + 18), label, fill=MUTED, font=F12)
        draw.text((cx + 22, y + 42), value, fill=INK, font=F24)
    return y + 116


def table_image(
    path: Path,
    title: str,
    subtitle: str,
    tag: str,
    columns: list[tuple[str, str, int]],
    rows: list[dict[str, Any]],
    cards: list[tuple[str, str, tuple[int, int, int]]] | None = None,
    row_palette: dict[str, tuple[int, int, int]] | None = None,
    palette_field: str | None = None,
    max_lines_by_col: dict[str, int] | None = None,
    width: int = 1800,
) -> None:
    max_lines_by_col = max_lines_by_col or {}
    x0 = 42
    y = 146
    table_w = sum(col[2] for col in columns)
    width = max(width, table_w + 84)

    dummy = Image.new("RGB", (width, 500), BG)
    d = ImageDraw.Draw(dummy)
    row_heights: list[int] = []
    for row in rows:
        line_counts = []
        for key, _label, col_w in columns:
            lines = wrap_text(row.get(key, ""), F12, col_w - 18, max_lines_by_col.get(key))
            line_counts.append(len(lines))
        row_heights.append(max(34, max(line_counts) * 17 + 18))

    height = y + 62 + sum(row_heights) + 90 + (116 if cards else 0)
    im = Image.new("RGB", (width, height), BG)
    draw = ImageDraw.Draw(im)
    y = draw_header(draw, title, subtitle, width, tag)
    if cards:
        y = draw_summary_cards(draw, cards, x0, y, width - 84)

    draw.rounded_rectangle((x0, y, x0 + table_w, height - 44), radius=12, fill=PANEL, outline=GRID, width=1)
    header_y = y
    draw.rounded_rectangle((x0, header_y, x0 + table_w, header_y + 46), radius=12, fill=(226, 232, 240))
    cx = x0
    for key, label, col_w in columns:
        draw.text((cx + 10, header_y + 14), label, fill=INK, font=F13)
        cx += col_w
        draw.line((cx, header_y, cx, header_y + 46), fill=GRID)
    y += 46

    for row, row_h in zip(rows, row_heights):
        fill = (255, 255, 255)
        if row_palette and palette_field:
            fill = row_palette.get(str(row.get(palette_field, "")), fill)
        draw.rectangle((x0, y, x0 + table_w, y + row_h), fill=fill)
        draw.line((x0, y + row_h, x0 + table_w, y + row_h), fill=GRID)
        cx = x0
        for key, _label, col_w in columns:
            fnt = F12
            color = INK
            if key in {"classification", "phase4_status", "grade", "blank_status"}:
                fnt = F11
                color = NAVY
            lines = wrap_text(row.get(key, ""), fnt, col_w - 18, max_lines_by_col.get(key))
            draw_text_lines(draw, (cx + 10, y + 10), lines, fnt, color, 3)
            cx += col_w
            draw.line((cx, y, cx, y + row_h), fill=GRID)
        y += row_h

    draw.text((x0, height - 32), "Private quantum_phase render. Generated from private Phase 4 tables.", fill=MUTED, font=F11)
    path.parent.mkdir(parents=True, exist_ok=True)
    im.save(path)


def short_mass(value: str) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if number == 0:
        return "0"
    if abs(number) >= 1000 or abs(number) < 0.001:
        return f"{number:.4e}"
    return f"{number:.6g}"


def render_particle_fact_table(summary: dict[str, Any]) -> None:
    rows = read_csv(TABLES / "phase4_parameter_free_particle_table.csv")
    out = []
    for row in rows:
        out.append(
            {
                "symbol": row["symbol"],
                "native_id": row["native_id"],
                "family": row["native_family"].replace("_", " "),
                "partition": row["subchannel_partition"],
                "mass": short_mass(row["mass_MeV"]),
                "charge": row["charge_axis"],
                "spin": row["spin_native"],
                "native_color": row["color_native"],
                "grade": "AUDIT" if "AUDIT" in row["parameter_free_grade"] else "STRICT",
            }
        )
    table_image(
        TABLES / "phase4_parameter_free_particle_table.png",
        "SAM Phase 4 Particle Table",
        "Parameter-free elementary surface, with QP043 downstream carrier context",
        "latest after QP043",
        [
            ("symbol", "Symbol", 95),
            ("native_id", "Native ID", 145),
            ("family", "Family", 230),
            ("partition", "Partition", 145),
            ("mass", "Mass MeV", 145),
            ("charge", "Charge", 95),
            ("spin", "Spin", 80),
            ("native_color", "Native color", 120),
            ("grade", "Grade", 95),
        ],
        out,
        cards=[
            ("Elementary rows", str(len(rows)), BLUE),
            ("Strict", str(sum(1 for row in out if row["grade"] == "STRICT")), GREEN),
            ("Audit-grade", str(sum(1 for row in out if row["grade"] == "AUDIT")), AMBER),
            ("QP043 exact carrier", "1", PURPLE),
        ],
        row_palette={"STRICT": (246, 255, 250), "AUDIT": (255, 251, 235)},
        palette_field="grade",
        width=1360,
    )


def render_periodic_matrix(summary: dict[str, Any]) -> None:
    rows = read_csv(TABLES / "phase4_particle_periodic_matrix.csv")
    table_image(
        TABLES / "phase4_particle_periodic_matrix.png",
        "SAM Particle Matrix",
        "Filled native lanes by seed and generation",
        "latest after QP043",
        [
            ("lane", "Lane", 190),
            ("seed", "Seed", 265),
            ("GEN1", "GEN1", 345),
            ("GEN2", "GEN2", 345),
            ("GEN3", "GEN3", 345),
            ("phase4_status", "Status", 190),
        ],
        rows,
        cards=[
            ("Matrix lanes", str(len(rows)), BLUE),
            ("Filled lanes", str(sum("FILLED" in row["phase4_status"] for row in rows)), GREEN),
            ("Native color labels", "not assigned", CYAN),
            ("Next table gate", "QP044", PURPLE),
        ],
        row_palette={
            "FILLED_PARAMETER_FREE": PALE_GREEN,
            "FILLED_NATIVE_VALUE_EXTERNAL_LABELS_NOT_ASSIGNED": PALE_BLUE,
        },
        palette_field="phase4_status",
        max_lines_by_col={"seed": 4, "GEN1": 5, "GEN2": 5, "GEN3": 5, "phase4_status": 3},
        width=1800,
    )


def render_composite_support(summary: dict[str, Any]) -> None:
    support = read_csv(TABLES / "phase4_composite_support_table.csv")
    meson_fill = read_csv(ARTIFACTS / "qp041" / "qp041_meson_fill_table.csv")
    meson_binding = read_csv(ARTIFACTS / "qp041c" / "qp041c_meson_binding_readout_table.csv")
    baryon_fill = read_csv(ARTIFACTS / "qp042" / "qp042_baryon_fill_table.csv")
    rows = []
    for row in support:
        rows.append(
            {
                "composite_id": row.get("composite_id", row.get("support_family", "")),
                "branch": row.get("branch", ""),
                "symbol": row.get("symbol", ""),
                "mass": short_mass(row.get("mass_MeV", "")),
                "operator": row.get("operator_class", ""),
                "status": row.get("support_status", row.get("phase4_status", "")),
            }
        )
    table_image(
        TABLES / "phase4_composite_support_table.png",
        "SAM Composite Support",
        "Selected support readouts plus downstream QP041C/QP042 fill counts",
        "latest after QP043",
        [
            ("composite_id", "Composite/support", 260),
            ("branch", "Branch", 110),
            ("symbol", "Symbol", 150),
            ("mass", "Mass MeV", 130),
            ("operator", "Native operator", 390),
            ("status", "Status", 260),
        ],
        rows,
        cards=[
            ("Support rows", str(len(support)), BLUE),
            ("Meson support fills", str(len(meson_fill)), GREEN),
            ("Meson binding coords", str(len(meson_binding)), PURPLE),
            ("Baryon fills", str(len(baryon_fill)), AMBER),
        ],
        max_lines_by_col={"operator": 4, "status": 3},
        width=1400,
    )


def render_scaffold_snapshot(summary: dict[str, Any]) -> None:
    scaffolds = read_csv(TABLES / "phase4_composite_scaffold_table.csv")
    meson_fill = {row["scaffold_id"]: row for row in read_csv(ARTIFACTS / "qp041" / "qp041_meson_fill_table.csv")}
    meson_binding = {row["scaffold_id"]: row for row in read_csv(ARTIFACTS / "qp041c" / "qp041c_meson_binding_readout_table.csv")}
    meson_boundary = {row["scaffold_id"]: row for row in read_csv(ARTIFACTS / "qp041" / "qp041_meson_open_boundary_table.csv")}
    baryon_fill = {row["scaffold_id"]: row for row in read_csv(ARTIFACTS / "qp042" / "qp042_baryon_fill_table.csv")}
    baryon_boundary = read_csv(ARTIFACTS / "qp042" / "qp042_baryon_open_boundary_table.csv")
    q_order = ["u", "d", "s", "c", "b", "t"]
    meson_rows = []
    for left in q_order:
        for right in q_order:
            sid = f"{left}_anti_{right}"
            status = "OPEN"
            mass = ""
            family = ""
            if sid in meson_fill:
                status = "SUPPORT_READOUT"
                mass = short_mass(meson_fill[sid]["sam_mass_MeV"])
                family = meson_fill[sid]["support_family"]
            if sid in meson_binding:
                status = "BINDING_COORD"
                mass = short_mass(meson_binding[sid]["native_binding_readout_MeV"])
                family = meson_binding[sid]["suk055_pair"]
            boundary = meson_boundary.get(sid, {}).get("boundary_class", "")
            meson_rows.append(
                {
                    "scaffold_id": sid,
                    "charge": next((row["charge"] for row in scaffolds if row["scaffold_id"] == sid), ""),
                    "status": status,
                    "mass": mass,
                    "family": family,
                    "boundary": boundary,
                }
            )
    baryon_counts = Counter(row["boundary_class"] for row in baryon_boundary)
    summary_rows = [
        {
            "sector": "Meson q anti-q",
            "total": "36",
            "filled_or_coord": str(len(set(meson_fill) | set(meson_binding))),
            "largest_group": "binding coords: " + str(len(meson_binding)),
            "next_selector": "neutral self / local return / role-axis selectors",
        },
        {
            "sector": "Baryon qqq",
            "total": "56",
            "filled_or_coord": str(len(baryon_fill)),
            "largest_group": "top boundary: " + str(baryon_counts.get("BOUNDARY_TOP_BARYON_ROLE_SCALE_SELECTOR_NEEDED", 0)),
            "next_selector": "strange/charm/bottom/top baryon selectors",
        },
        {
            "sector": "Unknown modes",
            "total": str(summary["unknown_mode_rows"]),
            "filled_or_coord": str(summary["assigned_existing_carrier_rows"]),
            "largest_group": "carrier basins: " + str(summary["candidate_composite_carrier_rows"]),
            "next_selector": "QP044 table refresh",
        },
    ]
    rows = meson_rows + [{"scaffold_id": "", "charge": "", "status": "", "mass": "", "family": "", "boundary": ""}] + [
        {
            "scaffold_id": row["sector"],
            "charge": row["total"],
            "status": row["filled_or_coord"],
            "mass": row["largest_group"],
            "family": row["next_selector"],
            "boundary": "",
        }
        for row in summary_rows
    ]
    table_image(
        TABLES / "phase4_composite_scaffold_table.png",
        "SAM Composite Scaffold Snapshot",
        "Meson grid with QP041/QP041C status, plus baryon and unknown-mode reduction",
        "latest after QP043",
        [
            ("scaffold_id", "Scaffold / sector", 210),
            ("charge", "Q / total", 95),
            ("status", "Latest status", 170),
            ("mass", "Readout / largest group", 230),
            ("family", "Family / next selector", 330),
            ("boundary", "Previous boundary", 390),
        ],
        rows,
        cards=[
            ("Meson slots touched", str(len(set(meson_fill) | set(meson_binding))), GREEN),
            ("Baryon fills", str(len(baryon_fill)), AMBER),
            ("Unknown exact carrier", str(summary["assigned_existing_carrier_rows"]), PURPLE),
            ("Unassigned modes", str(summary["unassigned_boundary_rows"]), RED),
        ],
        row_palette={
            "SUPPORT_READOUT": PALE_GREEN,
            "BINDING_COORD": PALE_PURPLE,
            "OPEN": (255, 255, 255),
        },
        palette_field="status",
        max_lines_by_col={"boundary": 3, "family": 3},
        width=1500,
    )


def render_unknown_assignment(summary: dict[str, Any]) -> None:
    rows = read_csv(ARTIFACTS / "qp043" / "qp043_unknown_mode_assignment_table.csv")
    table_image(
        TABLES / "phase4_qp043_unknown_mode_assignment_table.png",
        "QP043 Unknown Mode Assignment",
        "50 admissible substrate-string modes sorted into carriers, basins, native candidates, or boundaries",
        "private QP043",
        [
            ("native_id", "Mode", 120),
            ("subchannel_partition", "Partition", 170),
            ("classification", "Class", 240),
            ("carrier_family", "Carrier family", 360),
            ("carrier_id", "Carrier ID", 245),
            ("selector_needed", "Selector needed", 350),
        ],
        rows,
        cards=[
            ("Exact carrier", str(summary["assigned_existing_carrier_rows"]), GREEN),
            ("Composite basins", str(summary["candidate_composite_carrier_rows"]), BLUE),
            ("Native candidates", str(summary["candidate_new_native_mode_rows"]), PURPLE),
            ("Unassigned", str(summary["unassigned_boundary_rows"]), RED),
        ],
        row_palette={
            "ASSIGNED_EXISTING_CARRIER": PALE_GREEN,
            "CANDIDATE_COMPOSITE_CARRIER": PALE_BLUE,
            "CANDIDATE_NEW_NATIVE_MODE": PALE_PURPLE,
            "UNASSIGNED_BOUNDARY": PALE_RED,
        },
        palette_field="classification",
        max_lines_by_col={"classification": 3, "carrier_family": 3, "selector_needed": 3},
        width=1600,
    )


def render_carrier_summary(summary: dict[str, Any]) -> None:
    rows = read_csv(ARTIFACTS / "qp043" / "qp043_carrier_family_summary_table.csv")
    table_image(
        TABLES / "phase4_qp043_carrier_family_summary.png",
        "QP043 Carrier Family Summary",
        "The unknown rows now reduce to named carrier families and one selector per basin",
        "private QP043",
        [
            ("classification", "Class", 250),
            ("carrier_family", "Carrier family", 420),
            ("mode_count", "Modes", 90),
            ("example_modes", "Examples", 310),
            ("selector_needed", "Selector needed", 390),
        ],
        rows,
        cards=[
            ("Carrier families", str(len(rows)), BLUE),
            ("Exact assigned modes", summary["exact_assigned_modes"], GREEN),
            ("Unique carrier", summary["unique_existing_carriers_selected"], PURPLE),
            ("Next", summary["next_frontier"].replace("_PRIVATE_", " "), AMBER),
        ],
        row_palette={
            "ASSIGNED_EXISTING_CARRIER": PALE_GREEN,
            "CANDIDATE_COMPOSITE_CARRIER": PALE_BLUE,
            "CANDIDATE_NEW_NATIVE_MODE": PALE_PURPLE,
            "UNASSIGNED_BOUNDARY": PALE_RED,
        },
        palette_field="classification",
        max_lines_by_col={"classification": 3, "carrier_family": 3, "selector_needed": 3, "example_modes": 3},
        width=1560,
    )


def main() -> None:
    summary = read_json(ARTIFACTS / "qp043" / "qp043_summary.json")
    render_particle_fact_table(summary)
    render_periodic_matrix(summary)
    render_composite_support(summary)
    render_scaffold_snapshot(summary)
    render_unknown_assignment(summary)
    render_carrier_summary(summary)
    for path in [
        TABLES / "phase4_parameter_free_particle_table.png",
        TABLES / "phase4_particle_periodic_matrix.png",
        TABLES / "phase4_composite_support_table.png",
        TABLES / "phase4_composite_scaffold_table.png",
        TABLES / "phase4_qp043_unknown_mode_assignment_table.png",
        TABLES / "phase4_qp043_carrier_family_summary.png",
    ]:
        print(path)


if __name__ == "__main__":
    main()
