from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PUBLIC_SAM = Path(r"C:\VS\Stam_model-A-v1.0")

ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

FUS001_DIR = ARTIFACTS / "fus001"

CH034_DIR = PUBLIC_SAM / "chladni plate" / "CH034_SHARED_PLATE_FUSION_DISCOVERY_DEN"
CH034_SUMMARY = CH034_DIR / "CH034_summary.json"
CH034_METRICS = CH034_DIR / "CH034_run_metrics.csv"

QGA063_DIR = PUBLIC_SAM / "tests" / "Substrate" / "QGA063_TRANSPORTED_RESPONSE_INTERACTION_VERTEX_SURFACE"
QGA064_DIR = PUBLIC_SAM / "tests" / "Substrate" / "QGA064_VERTEX_AMPLITUDE_COUPLING_SELECTOR"
QGA065_DIR = PUBLIC_SAM / "tests" / "Substrate" / "QGA065_LAB_RESPONSE_PLATE_COUPLING_TO_PROBABILITY_SELECTOR"
QGA066_DIR = PUBLIC_SAM / "tests" / "Substrate" / "QGA066_NATIVE_SCATTERING_KERNEL_SELECTOR"
QGA067_DIR = PUBLIC_SAM / "tests" / "Substrate" / "QGA067_SCATTERING_CHANNEL_CONSERVATION_AND_CROSS_SECTION_SELECTOR"

QGA063_PAIR = QGA063_DIR / "QGA063_pair_vertex_table.csv"
QGA064_PAIR = QGA064_DIR / "QGA064_pair_coupling_table.csv"
QGA065_SUMMARY = QGA065_DIR / "QGA065_summary.json"
QGA066_SUMMARY = QGA066_DIR / "QGA066_summary.json"
QGA067_SUMMARY = QGA067_DIR / "QGA067_summary.json"
QGA067_CROSS = QGA067_DIR / "QGA067_cross_section_summary.csv"

PREFLIGHT_OUT = FUS001_DIR / "fus001_preflight.md"
INPUT_MANIFEST_OUT = FUS001_DIR / "fus001_input_manifest.csv"
METRIC_OUT = FUS001_DIR / "fusion_shared_response_metric.csv"
CROSSWALK_OUT = FUS001_DIR / "fusion_shared_response_metric_crosswalk.csv"
QGA_SURFACE_OUT = FUS001_DIR / "fusion_qga_interaction_surface.csv"
CHECKS_OUT = FUS001_DIR / "fus001_checks.csv"
WRONG_CONTROLS_OUT = FUS001_DIR / "fus001_wrong_controls.csv"
SUMMARY_OUT = FUS001_DIR / "fus001_summary.json"
NEXT_OUT = FUS001_DIR / "fus001_next_frontier.csv"
REPORT_OUT = REPORTS / "FUS001_PRIVATE_SHARED_RESPONSE_CLOSURE_METRIC_FREEZE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def fnum(value: object, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def write_preflight() -> None:
    FUS001_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# FUS001 Preflight - Shared Response Closure Metric Freeze

## Mode

```text
FORWARD_APPLICATION_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = False
confirmation_or_double_check = False
new_forward_work = True
```

FUS001 does not rerun CH034 or QGA063-QGA067. It reads their existing artifacts
and freezes a first SAM-native fusion application metric.

## Question

```text
Can CH034 shared-plate fusion-toy metrics be restated as response-geometry
metrics in the QGA063-QGA067 interaction language?
```

## Claim Boundary

```text
reactor design = not claimed
net energy = not claimed
fusion rate = not claimed
binding energy = not claimed
external fusion data used = false
```

## Selection Rule

```text
selected shared response metric iff:
  branch == shared_plate
  shared_closure_score > 0
  response_burden_delta > 0
  slide_efficiency > 0
  fusion_candidate_status == FUSION_SLIDE_CANDIDATE
```

Baselines and rows with negative burden/slide remain controls.
""",
        encoding="utf-8",
    )


def input_manifest() -> list[dict[str, object]]:
    return [
        {"source_id": "CH034_SUMMARY", "path": str(CH034_SUMMARY), "role": "shared plate summary"},
        {"source_id": "CH034_METRICS", "path": str(CH034_METRICS), "role": "toy shared response rows"},
        {"source_id": "QGA063_PAIR", "path": str(QGA063_PAIR), "role": "transported response vertex"},
        {"source_id": "QGA064_PAIR", "path": str(QGA064_PAIR), "role": "native pair coupling / overlap"},
        {"source_id": "QGA065_SUMMARY", "path": str(QGA065_SUMMARY), "role": "lab response plate probability law"},
        {"source_id": "QGA066_SUMMARY", "path": str(QGA066_SUMMARY), "role": "native scattering kernel law"},
        {"source_id": "QGA067_SUMMARY", "path": str(QGA067_SUMMARY), "role": "channel-conserved cross-section surface"},
        {"source_id": "QGA067_CROSS", "path": str(QGA067_CROSS), "role": "active and boundary C samples"},
    ]


def selected_metric(row: dict[str, str]) -> bool:
    return (
        row.get("branch") == "shared_plate"
        and fnum(row.get("shared_closure_score")) > 0
        and fnum(row.get("response_burden_delta")) > 0
        and fnum(row.get("slide_efficiency")) > 0
        and row.get("fusion_candidate_status") == "FUSION_SLIDE_CANDIDATE"
    )


def build_metric_rows() -> tuple[list[dict[str, object]], dict[str, object]]:
    ch034_summary = read_json(CH034_SUMMARY)
    metrics = read_csv(CH034_METRICS)
    qga064_pair = read_csv(QGA064_PAIR)[0]
    qga067_summary = read_json(QGA067_SUMMARY)
    selected_c_s_weight = fnum(qga067_summary["selected_c_s_cross_section_weight_C0"])

    rows: list[dict[str, object]] = []
    for raw in metrics:
        closure = fnum(raw["shared_closure_score"])
        burden_delta = fnum(raw["response_burden_delta"])
        slide = fnum(raw["slide_efficiency"])
        burden_gate = 1 if burden_delta > 0 else 0
        slide_gate = 1 if slide > 0 else 0
        closure_component = max(0.0, min(1.0, closure))
        response_geometry_score = closure_component * max(0.0, burden_delta) * max(0.0, slide)
        formal_weighted_response_score = response_geometry_score * selected_c_s_weight
        promoted = selected_metric(raw)

        rows.append(
            {
                "run_index": raw["run_index"],
                "seed": raw["seed"],
                "branch": raw["branch"],
                "phase_relation": raw["phase_relation"],
                "initial_separation": raw["initial_separation"],
                "final_separation": raw["final_separation"],
                "separation_change": raw["separation_change"],
                "closure_error": raw["closure_error"],
                "shared_closure_score": closure,
                "response_burden_initial": raw["response_burden_initial"],
                "response_burden_final": raw["response_burden_final"],
                "response_burden_delta": burden_delta,
                "burden_release_gate": burden_gate,
                "slide_efficiency": slide,
                "slide_gate": slide_gate,
                "ch034_status": raw["fusion_candidate_status"],
                "qga063_vertex": "TRANSPORTED_NATIVE_WEAK_SPLIT_PAIR_VERTEX_READY",
                "qga064_pair_channel_factor": qga064_pair["pair_channel_factor"],
                "qga064_overlap_rule": qga064_pair["response_overlap_rule"],
                "qga064_coupling_C0": qga064_pair["native_pair_coupling_max_C0"],
                "qga064_coupling_C1_24": qga064_pair["native_pair_coupling_mid_C1_24"],
                "qga064_coupling_C1_12": qga064_pair["native_pair_coupling_boundary_C1_12"],
                "qga067_selected_c_s_cross_section_weight_C0": selected_c_s_weight,
                "response_geometry_score": response_geometry_score,
                "formal_weighted_response_score": formal_weighted_response_score,
                "fus001_metric_status": "SHARED_RESPONSE_METRIC_SELECTED" if promoted else "CONTROL_OR_HELD_OPEN",
                "claim_status": "APPLICATION_METRIC_NOT_FUSION_RESULT",
            }
        )

    summary = {
        "ch034_claim_status": ch034_summary.get("claim_status"),
        "ch034_shared_fusion_slide_candidates": ch034_summary.get("shared_fusion_slide_candidates"),
        "ch034_shared_fusion_slide_candidate_rate": ch034_summary.get("shared_fusion_slide_candidate_rate"),
        "selected_c_s_cross_section_weight_C0": selected_c_s_weight,
    }
    return rows, summary


def build_crosswalk_rows() -> list[dict[str, object]]:
    return [
        {
            "ch034_field": "shared_closure_score",
            "fus001_restated_as": "response_geometry_closure_component",
            "qga_anchor": "QGA063 transported response vertex plus QGA064 generator/channel overlap",
            "formula_or_rule": "clamp(shared_closure_score, 0, 1)",
            "claim_boundary": "metric component only",
        },
        {
            "ch034_field": "response_burden_delta",
            "fus001_restated_as": "unresolved_burden_release_gate",
            "qga_anchor": "QGA065 lab response plate probability support",
            "formula_or_rule": "positive response_burden_delta gates burden release",
            "claim_boundary": "does not claim energy yield",
        },
        {
            "ch034_field": "slide_efficiency",
            "fus001_restated_as": "shared_response_slide_gate",
            "qga_anchor": "QGA066 scattering kernel support lane",
            "formula_or_rule": "positive slide_efficiency gates shared response entry",
            "claim_boundary": "does not claim reaction rate",
        },
        {
            "ch034_field": "fusion_candidate_status",
            "fus001_restated_as": "shared_response_metric_status",
            "qga_anchor": "QGA067 channel-conserved active cross-section candidate surface",
            "formula_or_rule": "candidate iff shared branch + closure + burden release + slide gate",
            "claim_boundary": "application metric, not fusion result",
        },
    ]


def build_qga_surface_rows() -> list[dict[str, object]]:
    qga063_pair = read_csv(QGA063_PAIR)[0]
    qga064_pair = read_csv(QGA064_PAIR)[0]
    qga065 = read_json(QGA065_SUMMARY)
    qga066 = read_json(QGA066_SUMMARY)
    qga067 = read_json(QGA067_SUMMARY)
    qga067_cross = read_csv(QGA067_CROSS)
    rows: list[dict[str, object]] = [
        {
            "layer": "QGA063",
            "surface": "transported response interaction vertex",
            "key_law": qga063_pair["transport_gate"],
            "selected_status": qga063_pair["pair_vertex_status"],
            "fusion_role": "defines response-side contact geometry",
        },
        {
            "layer": "QGA064",
            "surface": "native vertex amplitude/coupling",
            "key_law": qga064_pair["response_overlap_rule"],
            "selected_status": qga064_pair["selector_status"],
            "fusion_role": "defines overlap decay toward A_SHARE",
        },
        {
            "layer": "QGA065",
            "surface": "lab response plate probability",
            "key_law": qga065["probability_law"],
            "selected_status": qga065["lab_plate_status"],
            "fusion_role": "turns amplitudes into normalized active coherent weights",
        },
        {
            "layer": "QGA066",
            "surface": "native scattering kernel",
            "key_law": qga066["kernel_law"],
            "selected_status": qga066["scattering_kernel_status"],
            "fusion_role": "separates allowed, suppressed, and forbidden kernel rows",
        },
        {
            "layer": "QGA067",
            "surface": "channel-conserved cross-section candidates",
            "key_law": qga067["cross_section_law"],
            "selected_status": qga067["channel_conservation_status"],
            "fusion_role": "separates conserved channel candidates from support-only rows",
        },
    ]
    for row in qga067_cross:
        rows.append(
            {
                "layer": "QGA067_SAMPLE",
                "surface": row["sample_id"],
                "key_law": f"C={row['C_value']}; selected_c_s_strength={row['selected_c_s_strength_sum']}",
                "selected_status": row["channel_conservation_status"],
                "fusion_role": "active C sample" if "ACTIVE" in row["channel_conservation_status"] else "coherence-boundary no-support guard",
            }
        )
    return rows


def build_checks(metric_rows: list[dict[str, object]], qga_rows: list[dict[str, object]]) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    selected = [row for row in metric_rows if row["fus001_metric_status"] == "SHARED_RESPONSE_METRIC_SELECTED"]
    baseline_selected = [
        row for row in metric_rows if row["branch"] == "baseline_separate" and row["fus001_metric_status"] == "SHARED_RESPONSE_METRIC_SELECTED"
    ]
    negative_selected = [
        row
        for row in metric_rows
        if row["fus001_metric_status"] == "SHARED_RESPONSE_METRIC_SELECTED"
        and (fnum(row["response_burden_delta"]) <= 0 or fnum(row["slide_efficiency"]) <= 0)
    ]
    qga_boundary = [
        row
        for row in qga_rows
        if row["layer"] == "QGA067_SAMPLE" and "COHERENCE_BOUNDARY" in str(row["surface"])
    ]
    boundary_guard_ok = bool(qga_boundary) and all("NO_CROSS_SECTION_SUPPORT" in str(row["selected_status"]) for row in qga_boundary)

    checks = [
        {
            "check_id": "FUS001_CHECK_01",
            "check": "selected rows exist",
            "pass": len(selected) > 0,
            "detail": len(selected),
        },
        {
            "check_id": "FUS001_CHECK_02",
            "check": "all selected rows are shared_plate rows",
            "pass": all(row["branch"] == "shared_plate" for row in selected),
            "detail": len(selected),
        },
        {
            "check_id": "FUS001_CHECK_03",
            "check": "selected rows have positive burden release and slide",
            "pass": len(negative_selected) == 0,
            "detail": len(negative_selected),
        },
        {
            "check_id": "FUS001_CHECK_04",
            "check": "baseline rows remain controls",
            "pass": len(baseline_selected) == 0,
            "detail": len(baseline_selected),
        },
        {
            "check_id": "FUS001_CHECK_05",
            "check": "QGA067 boundary sample has no cross-section support",
            "pass": boundary_guard_ok,
            "detail": "C1_12_COHERENCE_BOUNDARY",
        },
    ]
    wrong_controls = [
        {
            "control_id": "FUS001_WC_01",
            "wrong_control": "baseline separate plate promoted",
            "expected": "0",
            "actual": len(baseline_selected),
            "pass": len(baseline_selected) == 0,
        },
        {
            "control_id": "FUS001_WC_02",
            "wrong_control": "negative burden or slide row promoted",
            "expected": "0",
            "actual": len(negative_selected),
            "pass": len(negative_selected) == 0,
        },
        {
            "control_id": "FUS001_WC_03",
            "wrong_control": "A_SHARE boundary treated as active support",
            "expected": "false",
            "actual": not boundary_guard_ok,
            "pass": boundary_guard_ok,
        },
    ]
    return checks, wrong_controls


def write_report(summary: dict[str, object], metric_rows: list[dict[str, object]], checks: list[dict[str, object]]) -> None:
    selected_rows = [row for row in metric_rows if row["fus001_metric_status"] == "SHARED_RESPONSE_METRIC_SELECTED"]
    selected_lines = "\n".join(
        f"| {row['run_index']} | {row['phase_relation']} | {row['shared_closure_score']} | {row['response_burden_delta']} | {row['slide_efficiency']} | {row['response_geometry_score']} | {row['formal_weighted_response_score']} |"
        for row in selected_rows
    )
    check_lines = "\n".join(
        f"| {row['check_id']} | {row['check']} | {row['pass']} | {row['detail']} |"
        for row in checks
    )
    REPORT_OUT.parent.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# FUS001 - Private Shared Response Closure Metric Freeze

## Result

```text
{summary['result_class']}
```

FUS001 begins the SAM fusion application campaign by translating CH034's
shared-plate toy metrics into the QGA063-QGA067 response-geometry language.

## Main Readout

```text
metric_rows = {summary['metric_rows']}
selected_shared_response_rows = {summary['selected_shared_response_rows']}
baseline_control_rows_promoted = {summary['baseline_control_rows_promoted']}
negative_burden_or_slide_rows_promoted = {summary['negative_burden_or_slide_rows_promoted']}
external_fusion_data_used = {summary['external_fusion_data_used']}
free_parameters_introduced = {summary['free_parameters_introduced']}
claim_status = {summary['claim_status']}
```

The selected application metric is:

```text
response_geometry_score =
  clamp(shared_closure_score, 0, 1)
  * max(0, response_burden_delta)
  * max(0, slide_efficiency)
```

Formal weighting can then carry the selected QGA067 c/s conserved-channel
weight as a downstream marker:

```text
formal_weighted_response_score =
  response_geometry_score * selected_c_s_cross_section_weight_C0
```

This is a screening metric, not a fusion result.

## Selected Rows

| run | phase | closure | burden delta | slide | response geometry score | formal weighted score |
| ---: | --- | ---: | ---: | ---: | ---: | ---: |
{selected_lines}

## Checks

| check id | check | pass | detail |
| --- | --- | --- | --- |
{check_lines}

## Interpretation

FUS001 converts the Chladni shared-plate question into a portable response
geometry metric. The strongest immediate result is that the old toy fields now
have formal places in the SAM interaction chain:

```text
shared_closure_score  -> response geometry closure component
response_burden_delta -> unresolved burden release gate
slide_efficiency      -> shared response entry gate
```

The QGA chain supplies the physics-facing surface:

```text
QGA063 -> transported response-side vertex
QGA064 -> generator/channel/retarded-overlap coupling
QGA065 -> probability plate
QGA066 -> native scattering kernel
QGA067 -> channel-conserved cross-section candidate surface
```

## Claim Boundary

```text
reactor design = not claimed
net energy = not claimed
fusion rate = not claimed
binding energy = not claimed
external fusion data = not used
```

## Next Frontier

```text
FUS002_PRIVATE_A_WINDOW_PULSE_SCAN
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    write_csv(INPUT_MANIFEST_OUT, input_manifest(), ["source_id", "path", "role"])
    metric_rows, source_summary = build_metric_rows()
    crosswalk_rows = build_crosswalk_rows()
    qga_rows = build_qga_surface_rows()
    checks, wrong_controls = build_checks(metric_rows, qga_rows)

    selected_rows = [row for row in metric_rows if row["fus001_metric_status"] == "SHARED_RESPONSE_METRIC_SELECTED"]
    baseline_control_rows_promoted = [
        row for row in metric_rows if row["branch"] == "baseline_separate" and row["fus001_metric_status"] == "SHARED_RESPONSE_METRIC_SELECTED"
    ]
    negative_rows_promoted = [
        row
        for row in metric_rows
        if row["fus001_metric_status"] == "SHARED_RESPONSE_METRIC_SELECTED"
        and (fnum(row["response_burden_delta"]) <= 0 or fnum(row["slide_efficiency"]) <= 0)
    ]
    summary = {
        "artifact": "FUS001_PRIVATE_SHARED_RESPONSE_CLOSURE_METRIC_FREEZE",
        "result_class": "FUS001_SHARED_RESPONSE_CLOSURE_METRIC_RESTATED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_WITH_PUBLIC_SAM_ARTIFACT_IMPORT",
        "test_type": "FORWARD_APPLICATION_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_fusion_data_used": False,
        "external_quantum_hardware_data_used": False,
        "free_parameters_introduced": 0,
        "claim_status": "APPLICATION_METRIC_FREEZE_NOT_FUSION_RESULT",
        "metric_rows": len(metric_rows),
        "selected_shared_response_rows": len(selected_rows),
        "baseline_control_rows_promoted": len(baseline_control_rows_promoted),
        "negative_burden_or_slide_rows_promoted": len(negative_rows_promoted),
        "check_passes": sum(1 for row in checks if row["pass"]),
        "check_total": len(checks),
        "wrong_control_passes": sum(1 for row in wrong_controls if row["pass"]),
        "wrong_control_total": len(wrong_controls),
        "ch034_claim_status": source_summary["ch034_claim_status"],
        "ch034_shared_fusion_slide_candidates": source_summary["ch034_shared_fusion_slide_candidates"],
        "ch034_shared_fusion_slide_candidate_rate": source_summary["ch034_shared_fusion_slide_candidate_rate"],
        "selected_c_s_cross_section_weight_C0": source_summary["selected_c_s_cross_section_weight_C0"],
        "next_frontier": "FUS002_PRIVATE_A_WINDOW_PULSE_SCAN",
    }

    write_csv(
        METRIC_OUT,
        metric_rows,
        [
            "run_index",
            "seed",
            "branch",
            "phase_relation",
            "initial_separation",
            "final_separation",
            "separation_change",
            "closure_error",
            "shared_closure_score",
            "response_burden_initial",
            "response_burden_final",
            "response_burden_delta",
            "burden_release_gate",
            "slide_efficiency",
            "slide_gate",
            "ch034_status",
            "qga063_vertex",
            "qga064_pair_channel_factor",
            "qga064_overlap_rule",
            "qga064_coupling_C0",
            "qga064_coupling_C1_24",
            "qga064_coupling_C1_12",
            "qga067_selected_c_s_cross_section_weight_C0",
            "response_geometry_score",
            "formal_weighted_response_score",
            "fus001_metric_status",
            "claim_status",
        ],
    )
    write_csv(CROSSWALK_OUT, crosswalk_rows, ["ch034_field", "fus001_restated_as", "qga_anchor", "formula_or_rule", "claim_boundary"])
    write_csv(QGA_SURFACE_OUT, qga_rows, ["layer", "surface", "key_law", "selected_status", "fusion_role"])
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])
    write_csv(
        NEXT_OUT,
        [
            {
                "next_test_id": "FUS002",
                "next_test_name": "PRIVATE_A_WINDOW_PULSE_SCAN",
                "requires_explicit_preflight": "true",
                "audit_or_retest": "false",
                "purpose": "Scan native A bands around A_SHARE using the FUS001 shared response metric.",
                "status": "READY",
            }
        ],
        ["next_test_id", "next_test_name", "requires_explicit_preflight", "audit_or_retest", "purpose", "status"],
    )
    write_json(SUMMARY_OUT, summary)
    write_report(summary, metric_rows, checks)


if __name__ == "__main__":
    main()
