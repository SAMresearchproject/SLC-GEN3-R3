from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PUBLIC_SAM = Path(r"C:\VS\Stam_model-A-v1.0")

ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

FUS002_DIR = ARTIFACTS / "fus002"

CH034_DIR = PUBLIC_SAM / "chladni plate" / "CH034_SHARED_PLATE_FUSION_DISCOVERY_DEN"
RAMP_020_DIR = CH034_DIR / "CH034_A_frequency_ramp_runs"
RAMP_099_DIR = CH034_DIR / "CH034_A_frequency_ramp_A0_to_0p99_runs"

RAMP_020_SUMMARY = RAMP_020_DIR / "CH034_A_frequency_ramp_aggregate_summary.json"
RAMP_099_SUMMARY = RAMP_099_DIR / "CH034_A_frequency_ramp_aggregate_summary.json"
RAMP_020_METRICS = RAMP_020_DIR / "CH034_A_frequency_ramp_all_metrics.csv"
RAMP_099_METRICS = RAMP_099_DIR / "CH034_A_frequency_ramp_all_metrics.csv"
FUS001_SUMMARY = ARTIFACTS / "fus001" / "fus001_summary.json"
FUS001_METRIC = ARTIFACTS / "fus001" / "fusion_shared_response_metric.csv"

PREFLIGHT_OUT = FUS002_DIR / "fus002_preflight.md"
INPUT_MANIFEST_OUT = FUS002_DIR / "fus002_input_manifest.csv"
SCAN_OUT = FUS002_DIR / "fusion_a_window_scan.csv"
SUMMARY_TABLE_OUT = FUS002_DIR / "fusion_a_window_summary.csv"
CHECKS_OUT = FUS002_DIR / "fus002_checks.csv"
WRONG_CONTROLS_OUT = FUS002_DIR / "fus002_wrong_controls.csv"
SUMMARY_OUT = FUS002_DIR / "fus002_summary.json"
NEXT_OUT = FUS002_DIR / "fus002_next_frontier.csv"
REPORT_OUT = REPORTS / "FUS002_PRIVATE_A_WINDOW_PULSE_SCAN.md"

A0 = 0.026525823848649224
A_SIDE = 1 / 24
A_SHARE = 1 / 12


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def fnum(value: object, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def write_preflight() -> None:
    FUS002_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# FUS002 Preflight - A-Window Pulse Scan

## Mode

```text
FORWARD_APPLICATION_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = False
confirmation_or_double_check = False
new_forward_work = True
```

FUS002 does not rerun CH034 or FUS001. It reads the existing CH034 A-frequency
ramp artifacts and the FUS001 metric freeze, then classifies native A windows
for shared-response closure screening.

## Question

```text
Does the SAM-native A window around A_SHARE identify a shared-closure region
before destructive high-A reorganization?
```

## Required Bands

```text
A0 = 0.026525823848649224
A_SIDE = 1/24
A_SHARE = 1/12
A = 0.20
A = 0.99
```

No external fusion data and no fitted parameters are used.
""",
        encoding="utf-8",
    )


def input_manifest() -> list[dict[str, object]]:
    return [
        {"source_id": "FUS001_SUMMARY", "path": str(FUS001_SUMMARY), "role": "metric freeze source"},
        {"source_id": "FUS001_METRIC", "path": str(FUS001_METRIC), "role": "selected shared-response metric rows"},
        {"source_id": "RAMP_020_SUMMARY", "path": str(RAMP_020_SUMMARY), "role": "A0 to 0.20 aggregate"},
        {"source_id": "RAMP_020_METRICS", "path": str(RAMP_020_METRICS), "role": "A0 to 0.20 per-run metrics"},
        {"source_id": "RAMP_099_SUMMARY", "path": str(RAMP_099_SUMMARY), "role": "A0 to 0.99 aggregate"},
        {"source_id": "RAMP_099_METRICS", "path": str(RAMP_099_METRICS), "role": "A0 to 0.99 per-run metrics"},
    ]


def a_band(value: float) -> str:
    if value < A_SIDE:
        return "BELOW_A_SIDE_COHERENT_SUPPORT"
    if value < A_SHARE:
        return "A_SIDE_TO_A_SHARE_WRITE_CANDIDACY"
    if value <= 0.20:
        return "A_SHARE_TO_0P20_REORGANIZATION_WINDOW"
    if value < 1:
        return "HIGH_A_REORGANIZATION_RISK"
    return "A1_CONTACT_FAILURE_GUARD"


def overlap(value: float) -> float:
    if value >= A_SHARE:
        return 0.0
    return max(0.0, 1 - value / A_SHARE)


def status_score(status: str) -> int:
    if status == "TIGHT_PERSISTENCE_CANDIDATE":
        return 2
    if status == "ASSISTED_ONLY_CLOSURE":
        return 1
    return 0


def scan_row(row: dict[str, str], ramp_label: str, ramp_end: float) -> dict[str, object]:
    a_min = fnum(row["A_at_min_ramp_separation"])
    a_max = fnum(row["A_at_max_ramp_closure_score"])
    persistence_score = status_score(row["ramp_persistence_status"])
    min_band = a_band(a_min)
    max_band = a_band(a_max)
    if row["ramp_persistence_status"] == "TIGHT_PERSISTENCE_CANDIDATE" and a_min <= 0.20:
        window_status = "NATIVE_A_WINDOW_PERSISTENCE_CANDIDATE"
    elif row["ramp_persistence_status"] == "ASSISTED_ONLY_CLOSURE" and a_min <= 0.20:
        window_status = "ASSISTED_CLOSURE_IN_NATIVE_A_WINDOW"
    elif a_min > 0.20:
        window_status = "HIGH_A_CLOSURE_NOT_PREFERRED"
    else:
        window_status = "NO_NATIVE_A_WINDOW_CLOSURE"
    return {
        "ramp_label": ramp_label,
        "ramp_end": ramp_end,
        "scenario_id": row["scenario_id"],
        "run_index": row["run_index"],
        "seed": row["seed"],
        "phase_relation": row["phase_relation"],
        "ramp_persistence_status": row["ramp_persistence_status"],
        "persistence_score": persistence_score,
        "initial_separation": row["initial_separation"],
        "min_ramp_separation": row["min_ramp_separation"],
        "A_at_min_ramp_separation": a_min,
        "A_min_band": min_band,
        "O_ret_at_A_min": overlap(a_min),
        "max_ramp_closure_score": row["max_ramp_closure_score"],
        "A_at_max_ramp_closure_score": a_max,
        "A_max_band": max_band,
        "O_ret_at_A_max": overlap(a_max),
        "after_ramp_separation": row["after_ramp_separation"],
        "final_release_separation": row["final_release_separation"],
        "burden_drift_after_release": row["burden_drift_after_release"],
        "fus002_window_status": window_status,
        "claim_status": "A_WINDOW_SCREEN_NOT_FUSION_RESULT",
    }


def build_scan() -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    rows_020 = [scan_row(row, "A0_TO_0P20", 0.20) for row in read_csv(RAMP_020_METRICS)]
    rows_099 = [scan_row(row, "A0_TO_0P99", 0.99) for row in read_csv(RAMP_099_METRICS)]
    rows = rows_020 + rows_099

    summary_rows: list[dict[str, object]] = []
    for ramp_label in ["A0_TO_0P20", "A0_TO_0P99"]:
        subset = [row for row in rows if row["ramp_label"] == ramp_label]
        for scenario in sorted({str(row["scenario_id"]) for row in subset}):
            srows = [row for row in subset if row["scenario_id"] == scenario]
            tight = sum(1 for row in srows if row["ramp_persistence_status"] == "TIGHT_PERSISTENCE_CANDIDATE")
            assisted = sum(1 for row in srows if row["ramp_persistence_status"] == "ASSISTED_ONLY_CLOSURE")
            no_closure = sum(1 for row in srows if row["ramp_persistence_status"] == "NO_ASSISTED_CLOSURE")
            mean_a_min = sum(fnum(row["A_at_min_ramp_separation"]) for row in srows) / len(srows)
            mean_a_max = sum(fnum(row["A_at_max_ramp_closure_score"]) for row in srows) / len(srows)
            mean_score = sum(int(row["persistence_score"]) for row in srows) / len(srows)
            summary_rows.append(
                {
                    "ramp_label": ramp_label,
                    "scenario_id": scenario,
                    "rows": len(srows),
                    "tight_persistence_candidates": tight,
                    "assisted_only_closures": assisted,
                    "no_assisted_closures": no_closure,
                    "tight_persistence_rate": tight / len(srows),
                    "mean_persistence_score": mean_score,
                    "mean_A_at_min_ramp_separation": mean_a_min,
                    "mean_A_min_band": a_band(mean_a_min),
                    "mean_A_at_max_ramp_closure_score": mean_a_max,
                    "mean_A_max_band": a_band(mean_a_max),
                    "preferred_for_next_scan": ramp_label == "A0_TO_0P20" and scenario == "clean_separation",
                }
            )
    return rows, summary_rows


def build_checks(summary_rows: list[dict[str, object]]) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    clean_020 = next(row for row in summary_rows if row["ramp_label"] == "A0_TO_0P20" and row["scenario_id"] == "clean_separation")
    clean_099 = next(row for row in summary_rows if row["ramp_label"] == "A0_TO_0P99" and row["scenario_id"] == "clean_separation")
    mean_020 = sum(fnum(row["tight_persistence_rate"]) for row in summary_rows if row["ramp_label"] == "A0_TO_0P20") / 3
    mean_099 = sum(fnum(row["tight_persistence_rate"]) for row in summary_rows if row["ramp_label"] == "A0_TO_0P99") / 3
    checks = [
        {
            "check_id": "FUS002_CHECK_01",
            "check": "A0_TO_0P20 average tight persistence exceeds A0_TO_0P99",
            "pass": mean_020 > mean_099,
            "detail": f"{mean_020} > {mean_099}",
        },
        {
            "check_id": "FUS002_CHECK_02",
            "check": "clean separation A0_TO_0P20 is best tight persistence lane",
            "pass": fnum(clean_020["tight_persistence_rate"]) == max(fnum(row["tight_persistence_rate"]) for row in summary_rows),
            "detail": clean_020["tight_persistence_rate"],
        },
        {
            "check_id": "FUS002_CHECK_03",
            "check": "A_SHARE overlap guard is zero by definition",
            "pass": overlap(A_SHARE) == 0,
            "detail": overlap(A_SHARE),
        },
        {
            "check_id": "FUS002_CHECK_04",
            "check": "0.99 ramp is not selected as preferred next scan",
            "pass": not any(row["preferred_for_next_scan"] for row in summary_rows if row["ramp_label"] == "A0_TO_0P99"),
            "detail": "A0_TO_0P99",
        },
    ]
    wrong_controls = [
        {
            "control_id": "FUS002_WC_01",
            "wrong_control": "high-A 0.99 ramp selected as preferred",
            "expected": "false",
            "actual": any(row["preferred_for_next_scan"] for row in summary_rows if row["ramp_label"] == "A0_TO_0P99"),
            "pass": not any(row["preferred_for_next_scan"] for row in summary_rows if row["ramp_label"] == "A0_TO_0P99"),
        },
        {
            "control_id": "FUS002_WC_02",
            "wrong_control": "A_SHARE keeps active retarded overlap",
            "expected": "0",
            "actual": overlap(A_SHARE),
            "pass": overlap(A_SHARE) == 0,
        },
        {
            "control_id": "FUS002_WC_03",
            "wrong_control": "clean 0.99 beats clean 0.20",
            "expected": "false",
            "actual": fnum(clean_099["tight_persistence_rate"]) > fnum(clean_020["tight_persistence_rate"]),
            "pass": fnum(clean_099["tight_persistence_rate"]) <= fnum(clean_020["tight_persistence_rate"]),
        },
    ]
    return checks, wrong_controls


def write_report(summary: dict[str, object], summary_rows: list[dict[str, object]], checks: list[dict[str, object]]) -> None:
    summary_lines = "\n".join(
        f"| {row['ramp_label']} | {row['scenario_id']} | {row['tight_persistence_rate']} | {row['mean_A_at_min_ramp_separation']} | {row['mean_A_min_band']} | {row['mean_A_at_max_ramp_closure_score']} | {row['mean_A_max_band']} | {row['preferred_for_next_scan']} |"
        for row in summary_rows
    )
    check_lines = "\n".join(
        f"| {row['check_id']} | {row['check']} | {row['pass']} | {row['detail']} |"
        for row in checks
    )
    REPORT_OUT.parent.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# FUS002 - Private A-Window Pulse Scan

## Result

```text
{summary['result_class']}
```

FUS002 scans existing CH034 A-frequency ramp outputs through the FUS001 shared
response metric frame.

## Main Readout

```text
scan_rows = {summary['scan_rows']}
summary_rows = {summary['summary_rows']}
preferred_ramp = {summary['preferred_ramp']}
preferred_scenario = {summary['preferred_scenario']}
preferred_tight_persistence_rate = {summary['preferred_tight_persistence_rate']}
external_fusion_data_used = {summary['external_fusion_data_used']}
free_parameters_introduced = {summary['free_parameters_introduced']}
claim_status = {summary['claim_status']}
```

The useful finding is that the low ramp is cleaner than the high ramp:

```text
A0 -> 0.20 average tight persistence rate = {summary['mean_tight_rate_A0_TO_0P20']}
A0 -> 0.99 average tight persistence rate = {summary['mean_tight_rate_A0_TO_0P99']}
```

## A-Window Summary

| ramp | scenario | tight rate | mean A min separation | A min band | mean A max closure | A max band | preferred |
| --- | --- | ---: | ---: | --- | ---: | --- | --- |
{summary_lines}

## Checks

| check id | check | pass | detail |
| --- | --- | --- | --- |
{check_lines}

## Interpretation

FUS002 selects a practical next scan region:

```text
primary window: A0 -> 0.20
best scenario: clean_separation
important band: near A_SHARE, then modestly above it
avoid for next scan: broad A0 -> 0.99 crank-up
```

This does not claim a fusion rate or reactor condition. It says the next SAM
application scan should refine the low-A reorganization window rather than
turning the dial straight toward high-A disruption.

## Next Frontier

```text
FUS003_PRIVATE_CARRIER_ENVELOPE_FUSION_CONTROL_SPLIT
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    write_csv(INPUT_MANIFEST_OUT, input_manifest(), ["source_id", "path", "role"])
    scan_rows, summary_rows = build_scan()
    checks, wrong_controls = build_checks(summary_rows)

    preferred = next(row for row in summary_rows if row["preferred_for_next_scan"])
    mean_020 = sum(fnum(row["tight_persistence_rate"]) for row in summary_rows if row["ramp_label"] == "A0_TO_0P20") / 3
    mean_099 = sum(fnum(row["tight_persistence_rate"]) for row in summary_rows if row["ramp_label"] == "A0_TO_0P99") / 3
    summary = {
        "artifact": "FUS002_PRIVATE_A_WINDOW_PULSE_SCAN",
        "result_class": "FUS002_LOW_A_WINDOW_SELECTED_FOR_NEXT_SCAN",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_WITH_PUBLIC_SAM_ARTIFACT_IMPORT",
        "test_type": "FORWARD_APPLICATION_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_fusion_data_used": False,
        "free_parameters_introduced": 0,
        "claim_status": "A_WINDOW_SCREEN_NOT_FUSION_RESULT",
        "scan_rows": len(scan_rows),
        "summary_rows": len(summary_rows),
        "preferred_ramp": preferred["ramp_label"],
        "preferred_scenario": preferred["scenario_id"],
        "preferred_tight_persistence_rate": preferred["tight_persistence_rate"],
        "mean_tight_rate_A0_TO_0P20": mean_020,
        "mean_tight_rate_A0_TO_0P99": mean_099,
        "check_passes": sum(1 for row in checks if row["pass"]),
        "check_total": len(checks),
        "wrong_control_passes": sum(1 for row in wrong_controls if row["pass"]),
        "wrong_control_total": len(wrong_controls),
        "next_frontier": "FUS003_PRIVATE_CARRIER_ENVELOPE_FUSION_CONTROL_SPLIT",
    }

    write_csv(
        SCAN_OUT,
        scan_rows,
        [
            "ramp_label",
            "ramp_end",
            "scenario_id",
            "run_index",
            "seed",
            "phase_relation",
            "ramp_persistence_status",
            "persistence_score",
            "initial_separation",
            "min_ramp_separation",
            "A_at_min_ramp_separation",
            "A_min_band",
            "O_ret_at_A_min",
            "max_ramp_closure_score",
            "A_at_max_ramp_closure_score",
            "A_max_band",
            "O_ret_at_A_max",
            "after_ramp_separation",
            "final_release_separation",
            "burden_drift_after_release",
            "fus002_window_status",
            "claim_status",
        ],
    )
    write_csv(
        SUMMARY_TABLE_OUT,
        summary_rows,
        [
            "ramp_label",
            "scenario_id",
            "rows",
            "tight_persistence_candidates",
            "assisted_only_closures",
            "no_assisted_closures",
            "tight_persistence_rate",
            "mean_persistence_score",
            "mean_A_at_min_ramp_separation",
            "mean_A_min_band",
            "mean_A_at_max_ramp_closure_score",
            "mean_A_max_band",
            "preferred_for_next_scan",
        ],
    )
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])
    write_csv(
        NEXT_OUT,
        [
            {
                "next_test_id": "FUS003",
                "next_test_name": "PRIVATE_CARRIER_ENVELOPE_FUSION_CONTROL_SPLIT",
                "requires_explicit_preflight": "true",
                "audit_or_retest": "false",
                "purpose": "Translate QC001 carrier/envelope/support separation into fusion-control architecture.",
                "status": "READY",
            }
        ],
        ["next_test_id", "next_test_name", "requires_explicit_preflight", "audit_or_retest", "purpose", "status"],
    )
    write_json(SUMMARY_OUT, summary)
    write_report(summary, summary_rows, checks)


if __name__ == "__main__":
    main()
