from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QC001_DIR = ARTIFACTS / "qc001"

QP012B_LEADS = ARTIFACTS / "qp012b" / "qp012b_route_lead_table.csv"
QP016_STABLE_MODES = ARTIFACTS / "qp016" / "qp016_stable_mode_selector_table.csv"
QP037_IDENTITIES = ARTIFACTS / "qp037" / "qp037_particle_identity_freeze_table.csv"
QP038_BOUNDARY = ARTIFACTS / "qp038" / "qp038_identity_composite_boundary_table.csv"
QP061_SUMMARY = ARTIFACTS / "qp061" / "qp061_summary.json"
PHASE4_PARTICLES = ROOT / "phase4_tables" / "phase4_parameter_free_particle_table.csv"
PHASE4_MATRIX = ROOT / "phase4_tables" / "phase4_particle_periodic_matrix.csv"

PREFLIGHT_OUT = QC001_DIR / "qc001_preflight.md"
SUMMARY_OUT = QC001_DIR / "qc001_summary.json"
CARRIER_OUT = QC001_DIR / "qc001_particle_informed_carrier_selector.csv"
STACK_OUT = QC001_DIR / "qc001_carrier_envelope_support_stack.csv"
SCHEMA_OUT = QC001_DIR / "qc001_schema.csv"
NEXT_OUT = QC001_DIR / "qc001_next_frontier.csv"
REPORT_OUT = REPORTS / "QC001_PRIVATE_PARTICLE_INFORMED_PAUL_REVERE_CARRIER_SELECTOR.md"


ROUTE_MAP: dict[str, dict[str, str]] = {
    "QUBIT-NL-001": {
        "particle_family": "neutral_lepton_like",
        "carrier_lane": "neutral lepton",
        "qc_role": "PRIMARY_PRE_RESOLUTION_LETTER_CARRIER",
        "qc_reason": "longest Paul Revere lead and QP016 stable self-closure",
    },
    "QUBIT-CL-001": {
        "particle_family": "charged_lepton_like",
        "carrier_lane": "charged lepton",
        "qc_role": "CONTROL_ENVELOPE_AND_READOUT_LANE",
        "qc_reason": "EM-contact lane is controllable but should not be the protected carrier",
    },
    "QUBIT-UNK-001": {
        "particle_family": "unknown_partition_carrier",
        "carrier_lane": "8/4 partition boundary",
        "qc_role": "BOUNDARY_STRESS_SENSOR",
        "qc_reason": "QP016 selects NL<->UNK as boundary reorganization candidate",
    },
    "QUBIT-BN-001": {
        "particle_family": "boundary_neutral",
        "carrier_lane": "scalar seed",
        "qc_role": "CLOCK_OR_SCALAR_RETURN_SUPPORT",
        "qc_reason": "scalar route is closed but not the strongest letter carrier",
    },
    "QUBIT-TP-001": {
        "particle_family": "triadic_plus_channel",
        "carrier_lane": "triadic plus",
        "qc_role": "MATERIAL_PAYLOAD_SUPPORT",
        "qc_reason": "triadic matter lane is better treated as payload/support than fragile carrier",
    },
    "QUBIT-TM-001": {
        "particle_family": "triadic_minus_channel",
        "carrier_lane": "triadic minus",
        "qc_role": "MATERIAL_PAYLOAD_SUPPORT",
        "qc_reason": "triadic matter lane is better treated as payload/support than fragile carrier",
    },
    "QUBIT-COLOR-001": {
        "particle_family": "native_color_triad_readout",
        "carrier_lane": "native color triad readout",
        "qc_role": "INTERNAL_COLOR_SUPPORT_NOT_EXTERNAL_LABEL",
        "qc_reason": "native color is support/readout structure, not an external label carrier",
    },
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def fnum(value: object, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def write_preflight() -> None:
    QC001_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QC001 Preflight - Particle-Informed Paul Revere Carrier Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = False
confirmation_or_double_check = False
new_forward_work = True
```

QC001 does not rerun QP012B, QP016, QP037, QP038, QP061, or the Phase 4
particle tables. It reads their frozen artifacts as inputs and builds a new
quantum-computing carrier selector.

## Question

```text
Which SAM-native particle/route family is the best physical carrier for the
Paul Revere pre-resolution letter?
```

## Selector Inputs

```text
artifacts/qp012b/qp012b_route_lead_table.csv
artifacts/qp016/qp016_stable_mode_selector_table.csv
artifacts/qp037/qp037_particle_identity_freeze_table.csv
artifacts/qp038/qp038_identity_composite_boundary_table.csv
phase4_tables/phase4_parameter_free_particle_table.csv
phase4_tables/phase4_particle_periodic_matrix.csv
artifacts/qp061/qp061_summary.json
```

## Native Separation Rule

```text
letter carrier       = route that maximizes pre-resolution lead while preserving unresolved closure
control envelope     = controllable interaction lane that can expose/read without being the carrier
boundary sensor      = route that reports reorganization pressure without final-outcome leakage
material support     = composite/triadic lane that holds apparatus structure
```

No external quantum hardware data and no fitted weights are used.
""",
        encoding="utf-8",
    )


def particle_family_summary(rows: list[dict[str, str]]) -> dict[str, dict[str, object]]:
    summary: dict[str, dict[str, object]] = {}
    for row in rows:
        family = row.get("native_family", "")
        if not family:
            continue
        bucket = summary.setdefault(
            family,
            {
                "rows": 0,
                "symbols": [],
                "strict_rows": 0,
                "audit_grade_rows": 0,
                "free_parameter_rows": 0,
            },
        )
        bucket["rows"] = int(bucket["rows"]) + 1
        bucket["symbols"] = [*bucket["symbols"], row.get("symbol", "")]
        grade = row.get("parameter_free_grade", "")
        if grade == "STRICT_PARAMETER_FREE":
            bucket["strict_rows"] = int(bucket["strict_rows"]) + 1
        elif grade == "AUDIT_GRADE_PARAMETER_FREE":
            bucket["audit_grade_rows"] = int(bucket["audit_grade_rows"]) + 1
        if row.get("free_parameters_used", "") not in ("", "0", "0.0"):
            bucket["free_parameter_rows"] = int(bucket["free_parameter_rows"]) + 1
    return summary


def stable_mode_lookup(rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    lookup: dict[str, dict[str, str]] = {}
    for row in rows:
        pair = row.get("route_pair", "")
        if pair:
            lookup[pair] = row
    return lookup


def self_mode_for(route_id: str, modes: dict[str, dict[str, str]]) -> dict[str, str] | None:
    pair = f"{route_id}<->{route_id}"
    return modes.get(pair)


def boundary_pair_for(route_id: str, modes: dict[str, dict[str, str]]) -> dict[str, str] | None:
    candidates = [
        row
        for row in modes.values()
        if route_id in (row.get("route_i"), row.get("route_j"))
        and row.get("selector_class") == "BOUNDARY_REORGANIZATION_CANDIDATE"
    ]
    if not candidates:
        return None
    return sorted(candidates, key=lambda row: fnum(row.get("stability_index")), reverse=True)[0]


def closure_status(route_id: str, modes: dict[str, dict[str, str]]) -> tuple[str, str, float]:
    self_row = self_mode_for(route_id, modes)
    if self_row is not None:
        selector = self_row.get("selector_class", "")
        stability = fnum(self_row.get("stability_index"))
        if selector == "STABLE_SELF_CLOSURE_MODE_SELECTED":
            return "STABLE_SELF_CLOSURE_SELECTED", self_row.get("route_pair", ""), stability
    boundary = boundary_pair_for(route_id, modes)
    if boundary is not None:
        return (
            "BOUNDARY_REORGANIZATION_CANDIDATE",
            boundary.get("route_pair", ""),
            fnum(boundary.get("stability_index")),
        )
    if self_row is not None and self_row.get("selector_class", ""):
        return (
            self_row.get("selector_class", ""),
            self_row.get("route_pair", ""),
            fnum(self_row.get("stability_index")),
        )
    return "NO_QP016_SELF_OR_BOUNDARY_SELECTION", "", 0.0


def lead_band(max_lead: float) -> str:
    if max_lead >= 1_000_000:
        return "EXCEPTIONAL_LETTER_WINDOW"
    if max_lead >= 10_000:
        return "LONG_LETTER_WINDOW"
    if max_lead >= 1_000:
        return "USABLE_LETTER_WINDOW"
    if max_lead >= 100:
        return "TIGHT_LETTER_WINDOW"
    return "MINIMAL_LETTER_WINDOW"


def build_carrier_rows() -> list[dict[str, object]]:
    leads = read_csv(QP012B_LEADS)
    modes = stable_mode_lookup(read_csv(QP016_STABLE_MODES))
    family_summary = particle_family_summary(read_csv(PHASE4_PARTICLES))

    rows: list[dict[str, object]] = []
    for lead in sorted(leads, key=lambda row: int(row["QP012B_lead_rank"])):
        route_id = lead["qubit_id"]
        mapping = ROUTE_MAP.get(route_id, {})
        family = mapping.get("particle_family", "unmapped")
        family_info = family_summary.get(family, {})
        closure, closure_pair, stability = closure_status(route_id, modes)
        max_lead = fnum(lead["max_letter_lead_to_A_SHARE_ticks"])
        first_basin = fnum(lead["first_basin_forming_lead_to_A_SHARE_ticks"])
        letter_fraction = fnum(lead["letter_window_fraction"])
        particle_rows = int(family_info.get("rows", 0) or 0)
        strict_rows = int(family_info.get("strict_rows", 0) or 0)
        audit_rows = int(family_info.get("audit_grade_rows", 0) or 0)
        free_param_rows = int(family_info.get("free_parameter_rows", 0) or 0)
        symbols = ";".join(str(item) for item in family_info.get("symbols", []))

        if route_id == "QUBIT-NL-001" and closure == "STABLE_SELF_CLOSURE_SELECTED":
            selector_result = "SELECTED_PRIMARY_LETTER_CARRIER"
        elif route_id == "QUBIT-CL-001":
            selector_result = "SELECTED_CONTROL_ENVELOPE"
        elif route_id == "QUBIT-UNK-001":
            selector_result = "SELECTED_BOUNDARY_STRESS_SENSOR"
        elif mapping.get("qc_role") in {"MATERIAL_PAYLOAD_SUPPORT", "INTERNAL_COLOR_SUPPORT_NOT_EXTERNAL_LABEL"}:
            selector_result = "SUPPORT_NOT_PRIMARY_CARRIER"
        else:
            selector_result = "SECONDARY_SUPPORT_NOT_PRIMARY"

        rows.append(
            {
                "rank": lead["QP012B_lead_rank"],
                "route_id": route_id,
                "route": lead["route"],
                "exposure_family": lead["exposure_family"],
                "particle_family": family,
                "particle_symbols": symbols or "N/A",
                "particle_family_rows": particle_rows,
                "strict_particle_rows": strict_rows,
                "audit_grade_particle_rows": audit_rows,
                "free_parameter_rows": free_param_rows,
                "max_lead_to_A_SHARE_ticks": max_lead,
                "first_basin_lead_to_A_SHARE_ticks": first_basin,
                "letter_window_fraction": letter_fraction,
                "lead_band": lead_band(max_lead),
                "qp016_closure_status": closure,
                "qp016_closure_pair": closure_pair,
                "qp016_stability_index": stability,
                "qc_role": mapping.get("qc_role", "UNMAPPED_SUPPORT"),
                "selector_result": selector_result,
                "native_reason": mapping.get("qc_reason", "unmapped route family"),
                "letter_can_carry": "route_family;boundary_stress;time_to_A_SIDE;time_to_A_SHARE;basin_bias;syndrome_signal",
                "letter_cannot_carry": "final_ledger_outcome;logical_route_identity",
            }
        )
    return rows


def build_stack_rows(carrier_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    by_result = {str(row["selector_result"]): row for row in carrier_rows}
    primary = by_result.get("SELECTED_PRIMARY_LETTER_CARRIER", {})
    control = by_result.get("SELECTED_CONTROL_ENVELOPE", {})
    sensor = by_result.get("SELECTED_BOUNDARY_STRESS_SENSOR", {})
    support_count = sum(1 for row in carrier_rows if row["selector_result"] == "SUPPORT_NOT_PRIMARY_CARRIER")

    return [
        {
            "stack_layer": 1,
            "layer_name": "protected carrier",
            "selected_route": primary.get("route_id", ""),
            "selected_family": primary.get("particle_family", ""),
            "role": "carry unresolved phase and Paul Revere syndrome letter",
            "native_rule": "maximize pre-resolution lead and preserve stable unresolved self-closure",
        },
        {
            "stack_layer": 2,
            "layer_name": "control envelope",
            "selected_route": control.get("route_id", ""),
            "selected_family": control.get("particle_family", ""),
            "role": "supply controlled A-contact for steering and readout",
            "native_rule": "controllable EM-contact lane is envelope, not primary carrier",
        },
        {
            "stack_layer": 3,
            "layer_name": "boundary stress sensor",
            "selected_route": sensor.get("route_id", ""),
            "selected_family": sensor.get("particle_family", ""),
            "role": "report basin/reorganization pressure before final route identity resolves",
            "native_rule": "boundary candidate may report pressure without final outcome leakage",
        },
        {
            "stack_layer": 4,
            "layer_name": "material/composite support",
            "selected_route": "triadic/color/support lanes",
            "selected_family": f"{support_count} support lanes",
            "role": "hold apparatus structure, shielding, and coherence platform",
            "native_rule": "many-SW support is not the same thing as unresolved carrier identity",
        },
    ]


def write_doc(summary: dict[str, object], carrier_rows: list[dict[str, object]], stack_rows: list[dict[str, object]]) -> None:
    carrier_lines = "\n".join(
        "| {rank} | {route_id} | {particle_family} | {lead_band} | {qp016_closure_status} | {qc_role} | {selector_result} |".format(
            **row
        )
        for row in carrier_rows
    )
    stack_lines = "\n".join(
        "| {stack_layer} | {layer_name} | {selected_route} | {selected_family} | {role} |".format(**row)
        for row in stack_rows
    )
    REPORT_OUT.parent.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QC001 - Private Particle-Informed Paul Revere Carrier Selector

## Result

```text
{summary['result_class']}
```

QC001 revisits the QP012B Paul Revere letter after the particle and isotope
closures. The question is no longer only whether a pre-resolution letter can
exist. The question is which SAM-native physical lane should carry it.

## Main Readout

```text
primary_letter_carrier = {summary['primary_letter_carrier']}
control_envelope = {summary['control_envelope']}
boundary_stress_sensor = {summary['boundary_stress_sensor']}
support_lanes = {summary['support_lanes']}
free_parameters_introduced = {summary['free_parameters_introduced']}
```

The selected stack is:

```text
neutral unresolved route      -> protected carrier
charged lepton lane           -> control/readout envelope
8/4 partition boundary route  -> stress / basin sensor
triadic/color/composite lanes -> material support, not primary carrier
```

## Carrier Selector Table

| rank | route | particle family | lead band | QP016 closure | QC role | selector result |
| ---: | --- | --- | --- | --- | --- | --- |
{carrier_lines}

## Carrier / Envelope / Support Stack

| layer | name | route | family | role |
| ---: | --- | --- | --- | --- |
{stack_lines}

## Interpretation

The Paul Revere letter should ride the neutral unresolved lane, not the charged
apparatus lane. The charged lane matters because it can act as a controlled
envelope for steering and readout, but QC001 separates that from the protected
carrier.

This keeps the QP012B restriction intact:

```text
allowed before resolution:
route family, boundary stress, A_SIDE/A_SHARE timing, basin bias, syndrome signal

not allowed before resolution:
final ledger outcome, logical route identity
```

## Why Particles Matter Here

Before particle closure, QP012B could say which route produced the strongest
letter. After particle closure, QC001 can name the physical lane:

```text
QUBIT-NL-001 -> neutral lepton-like unresolved carrier
QUBIT-CL-001 -> charged lepton-like control envelope
QUBIT-UNK-001 -> partition-boundary stress sensor
```

That is the first real bridge from SAM particle work back into the
quantum-computing lane.

## Outputs

```text
artifacts/qc001/qc001_preflight.md
artifacts/qc001/qc001_particle_informed_carrier_selector.csv
artifacts/qc001/qc001_carrier_envelope_support_stack.csv
artifacts/qc001/qc001_schema.csv
artifacts/qc001/qc001_summary.json
artifacts/qc001/qc001_next_frontier.csv
```

## Next Frontier

```text
QC002_PRIVATE_CARRIER_ENVELOPE_SEPARATION_LAW
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()

    carrier_rows = build_carrier_rows()
    stack_rows = build_stack_rows(carrier_rows)

    primary = next(row for row in carrier_rows if row["selector_result"] == "SELECTED_PRIMARY_LETTER_CARRIER")
    control = next(row for row in carrier_rows if row["selector_result"] == "SELECTED_CONTROL_ENVELOPE")
    sensor = next(row for row in carrier_rows if row["selector_result"] == "SELECTED_BOUNDARY_STRESS_SENSOR")
    support_lanes = [row for row in carrier_rows if row["selector_result"] == "SUPPORT_NOT_PRIMARY_CARRIER"]
    qp061 = read_json(QP061_SUMMARY)

    summary = {
        "artifact": "QC001_PRIVATE_PARTICLE_INFORMED_PAUL_REVERE_CARRIER_SELECTOR",
        "result_class": "QC001_PARTICLE_INFORMED_PAUL_REVERE_CARRIER_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_hardware_data_used": False,
        "free_parameters_introduced": 0,
        "primary_letter_carrier": primary["route_id"],
        "primary_letter_particle_family": primary["particle_family"],
        "primary_max_lead_to_A_SHARE_ticks": primary["max_lead_to_A_SHARE_ticks"],
        "primary_closure_status": primary["qp016_closure_status"],
        "control_envelope": control["route_id"],
        "control_envelope_particle_family": control["particle_family"],
        "boundary_stress_sensor": sensor["route_id"],
        "boundary_stress_sensor_family": sensor["particle_family"],
        "support_lanes": len(support_lanes),
        "qp061_prediction_manifest_mutated": qp061.get("prediction_manifest_mutated"),
        "qp061_free_parameters_introduced": qp061.get("free_parameters_introduced"),
        "next_frontier": "QC002_PRIVATE_CARRIER_ENVELOPE_SEPARATION_LAW",
    }

    write_csv(
        CARRIER_OUT,
        carrier_rows,
        [
            "rank",
            "route_id",
            "route",
            "exposure_family",
            "particle_family",
            "particle_symbols",
            "particle_family_rows",
            "strict_particle_rows",
            "audit_grade_particle_rows",
            "free_parameter_rows",
            "max_lead_to_A_SHARE_ticks",
            "first_basin_lead_to_A_SHARE_ticks",
            "letter_window_fraction",
            "lead_band",
            "qp016_closure_status",
            "qp016_closure_pair",
            "qp016_stability_index",
            "qc_role",
            "selector_result",
            "native_reason",
            "letter_can_carry",
            "letter_cannot_carry",
        ],
    )
    write_csv(
        STACK_OUT,
        stack_rows,
        ["stack_layer", "layer_name", "selected_route", "selected_family", "role", "native_rule"],
    )
    write_csv(
        SCHEMA_OUT,
        [
            {
                "field": "selector_result",
                "meaning": "carrier classification emitted by QC001",
                "source": "QP012B lead ranking plus QP016 closure plus Phase 4 particle family mapping",
            },
            {
                "field": "lead_band",
                "meaning": "descriptive band from max lead ticks before A_SHARE",
                "source": "QP012B route lead table",
            },
            {
                "field": "qp016_closure_status",
                "meaning": "stable self-closure, boundary candidate, or transient status",
                "source": "QP016 stable mode selector",
            },
        ],
        ["field", "meaning", "source"],
    )
    write_csv(
        NEXT_OUT,
        [
            {
                "next_test_id": "QC002",
                "next_test_name": "PRIVATE_CARRIER_ENVELOPE_SEPARATION_LAW",
                "requires_explicit_preflight": "true",
                "audit_or_retest": "false",
                "purpose": "Turn QC001 carrier/envelope separation into a native gate primitive without external hardware data.",
                "status": "READY",
            }
        ],
        ["next_test_id", "next_test_name", "requires_explicit_preflight", "audit_or_retest", "purpose", "status"],
    )
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, carrier_rows, stack_rows)


if __name__ == "__main__":
    main()
