from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QC002_DIR = ARTIFACTS / "qc002"

QC001_SUMMARY = ARTIFACTS / "qc001" / "qc001_summary.json"
QC001_SELECTOR = ARTIFACTS / "qc001" / "qc001_particle_informed_carrier_selector.csv"
QC001_STACK = ARTIFACTS / "qc001" / "qc001_carrier_envelope_support_stack.csv"
QN006_CORRECTION_RULES = ARTIFACTS / "qn006" / "letter_safe_correction_rules.csv"
QN012_LETTER_MAP = ARTIFACTS / "qn012" / "paul_revere_self_correction_map.csv"
QN013_VALIDATION_RULES = ARTIFACTS / "qn013" / "sam_qn_live_data_validation_rules.csv"
QN013_SCORE_RULES = ARTIFACTS / "qn013" / "sam_qn_trial_score_rules.csv"

PREFLIGHT_OUT = QC002_DIR / "qc002_preflight.md"
INPUT_MANIFEST_OUT = QC002_DIR / "qc002_input_manifest.csv"
SEPARATION_LAW_OUT = QC002_DIR / "qc002_carrier_envelope_separation_law.csv"
GATE_CATALOG_OUT = QC002_DIR / "qc002_gate_primitive_catalog.csv"
BOUNDARY_OUT = QC002_DIR / "qc002_gate_boundary_conditions.csv"
FIREWALL_OUT = QC002_DIR / "qc002_pre_write_leakage_firewall.csv"
CHECKS_OUT = QC002_DIR / "qc002_checks.csv"
WRONG_CONTROLS_OUT = QC002_DIR / "qc002_wrong_controls.csv"
SUMMARY_OUT = QC002_DIR / "qc002_summary.json"
NEXT_OUT = QC002_DIR / "qc002_next_frontier.csv"
REPORT_OUT = REPORTS / "QC002_PRIVATE_CARRIER_ENVELOPE_SEPARATION_LAW.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def as_bool(value: str | bool) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in {"true", "1", "yes", "pass"}


def md_table(rows: list[dict], fields: list[str]) -> str:
    if not rows:
        return ""
    header = "| " + " | ".join(fields) + " |"
    divider = "| " + " | ".join("---" for _ in fields) + " |"
    body = []
    for row in rows:
        body.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join([header, divider, *body])


def find_one(rows: list[dict[str, str]], field: str, value: str) -> dict[str, str]:
    matches = [row for row in rows if row.get(field) == value]
    if len(matches) != 1:
        raise ValueError(f"expected exactly one {field}={value}, found {len(matches)}")
    return matches[0]


def build_input_manifest(paths: list[Path]) -> list[dict]:
    rows = []
    for path in paths:
        exists = path.exists()
        rows.append(
            {
                "input_path": str(path.relative_to(ROOT)),
                "exists": exists,
                "sha256": file_hash(path) if exists else "",
                "role": input_role(path),
            }
        )
    return rows


def input_role(path: Path) -> str:
    name = path.name
    if name == "qc001_summary.json":
        return "QC001 selected carrier/envelope/sensor summary"
    if name == "qc001_particle_informed_carrier_selector.csv":
        return "QC001 route-family selector"
    if name == "qc001_carrier_envelope_support_stack.csv":
        return "QC001 four-layer support stack"
    if name == "letter_safe_correction_rules.csv":
        return "QN006 letter-safe correction operations"
    if name == "paul_revere_self_correction_map.csv":
        return "QN012 allowed warning-letter control actions"
    if name == "sam_qn_live_data_validation_rules.csv":
        return "QN013 live-data leakage validation rules"
    if name == "sam_qn_trial_score_rules.csv":
        return "QN013 trial scoring vocabulary"
    return "input"


def build_separation_law(
    carrier: dict[str, str],
    envelope: dict[str, str],
    sensor: dict[str, str],
    qn006_rules: list[dict[str, str]],
    qn013_validation: list[dict[str, str]],
) -> list[dict]:
    envelope_rule = find_one(qn006_rules, "rule_id", "QN006-CORR-05")
    blocker_rule = find_one(qn013_validation, "rule_id", "QN013-VAL-03")
    join_rule = find_one(qn013_validation, "rule_id", "QN013-VAL-06")
    lead_ratio = float(carrier["max_lead_to_A_SHARE_ticks"]) / float(envelope["max_lead_to_A_SHARE_ticks"])
    sensor_to_envelope_ratio = float(sensor["max_lead_to_A_SHARE_ticks"]) / float(envelope["max_lead_to_A_SHARE_ticks"])
    return [
        {
            "law_id": "QC002-LAW-01",
            "law": "protected carrier identity",
            "selected_route": carrier["route_id"],
            "selected_family": carrier["particle_family"],
            "allowed_role": "carry unresolved route and Paul Revere letter",
            "forbidden_role": "act as final ledger readout before write",
            "source": "QC001",
            "status": "PASS",
            "native_readout": carrier["selector_result"],
        },
        {
            "law_id": "QC002-LAW-02",
            "law": "control envelope identity",
            "selected_route": envelope["route_id"],
            "selected_family": envelope["particle_family"],
            "allowed_role": envelope_rule["operation"],
            "forbidden_role": "act as primary unresolved carrier",
            "source": "QC001+QN006",
            "status": "PASS",
            "native_readout": envelope["selector_result"],
        },
        {
            "law_id": "QC002-LAW-03",
            "law": "boundary stress sensor identity",
            "selected_route": sensor["route_id"],
            "selected_family": sensor["particle_family"],
            "allowed_role": "report basin/reorganization pressure before final identity resolves",
            "forbidden_role": "read final ledger outcome",
            "source": "QC001+QN006",
            "status": "PASS",
            "native_readout": sensor["selector_result"],
        },
        {
            "law_id": "QC002-LAW-04",
            "law": "carrier-envelope lead separation",
            "selected_route": f'{carrier["route_id"]}>{envelope["route_id"]}',
            "selected_family": "neutral_lepton_like over charged_lepton_like",
            "allowed_role": f"carrier lead/envelope lead = {lead_ratio:.12g}",
            "forbidden_role": "collapse separation by using charged lane as carrier",
            "source": "QC001 lead table",
            "status": "PASS",
            "native_readout": f"sensor/envelope lead = {sensor_to_envelope_ratio:.12g}",
        },
        {
            "law_id": "QC002-LAW-05",
            "law": "pre-write leakage firewall",
            "selected_route": "all QC002 gates",
            "selected_family": "all control packets",
            "allowed_role": "route_family;boundary_stress;time_to_A_SIDE;time_to_A_SHARE;basin_bias;syndrome_signal",
            "forbidden_role": "final_ledger_outcome;logical_route_identity;selected_final_result",
            "source": "QN012+QN013",
            "status": "PASS" if as_bool(blocker_rule["hard_blocker"]) else "FAIL",
            "native_readout": blocker_rule["failure_status"],
        },
        {
            "law_id": "QC002-LAW-06",
            "law": "post-write join boundary",
            "selected_route": "final read gate only",
            "selected_family": "ledger join",
            "allowed_role": "join final result only after pre-resolution hash freeze",
            "forbidden_role": "post-write join before hash freeze",
            "source": "QN013",
            "status": "PASS" if as_bool(join_rule["hard_blocker"]) else "FAIL",
            "native_readout": join_rule["failure_status"],
        },
    ]


def build_gate_catalog(
    carrier: dict[str, str],
    envelope: dict[str, str],
    sensor: dict[str, str],
    letter_map: list[dict[str, str]],
) -> list[dict]:
    letters = {row["warning_letter"]: row for row in letter_map}
    return [
        {
            "gate_id": "QC002-GATE-01",
            "gate_name": "shielded_no_write_wait",
            "carrier_route": carrier["route_id"],
            "envelope_route": envelope["route_id"],
            "sensor_route": sensor["route_id"],
            "allowed_letter": "window-open flag",
            "envelope_operation": "hold carrier inside open no-write window",
            "source_letter_action": letters["window-open flag"]["allowed_control_action"],
            "pre_write_commit_allowed": False,
            "pre_write_final_payload_allowed": False,
            "carrier_state_after_operation": "UNRESOLVED_PRESERVED",
            "separation_status": "PASS",
        },
        {
            "gate_id": "QC002-GATE-02",
            "gate_name": "phase_drift_envelope_correction",
            "carrier_route": carrier["route_id"],
            "envelope_route": envelope["route_id"],
            "sensor_route": sensor["route_id"],
            "allowed_letter": "phase drift",
            "envelope_operation": "adjust charged control envelope without selecting final route",
            "source_letter_action": letters["phase drift"]["allowed_control_action"],
            "pre_write_commit_allowed": False,
            "pre_write_final_payload_allowed": False,
            "carrier_state_after_operation": "UNRESOLVED_STEERED",
            "separation_status": "PASS",
        },
        {
            "gate_id": "QC002-GATE-03",
            "gate_name": "polarization_drift_envelope_correction",
            "carrier_route": carrier["route_id"],
            "envelope_route": envelope["route_id"],
            "sensor_route": sensor["route_id"],
            "allowed_letter": "polarization drift",
            "envelope_operation": "update apparatus orientation while carrier remains unresolved",
            "source_letter_action": letters["polarization drift"]["allowed_control_action"],
            "pre_write_commit_allowed": False,
            "pre_write_final_payload_allowed": False,
            "carrier_state_after_operation": "UNRESOLVED_STEERED",
            "separation_status": "PASS",
        },
        {
            "gate_id": "QC002-GATE-04",
            "gate_name": "basin_stress_boundary_sensor_gate",
            "carrier_route": carrier["route_id"],
            "envelope_route": envelope["route_id"],
            "sensor_route": sensor["route_id"],
            "allowed_letter": "syndrome_signal",
            "envelope_operation": "apply letter-safe correction from sensor stress",
            "source_letter_action": letters["syndrome_signal"]["allowed_control_action"],
            "pre_write_commit_allowed": False,
            "pre_write_final_payload_allowed": False,
            "carrier_state_after_operation": "UNRESOLVED_CORRECTED",
            "separation_status": "PASS",
        },
        {
            "gate_id": "QC002-GATE-05",
            "gate_name": "delayed_resolution_read_gate",
            "carrier_route": carrier["route_id"],
            "envelope_route": envelope["route_id"],
            "sensor_route": sensor["route_id"],
            "allowed_letter": "timing headroom",
            "envelope_operation": "allow final read only after selected write and hash boundary",
            "source_letter_action": letters["timing headroom"]["allowed_control_action"],
            "pre_write_commit_allowed": False,
            "pre_write_final_payload_allowed": False,
            "carrier_state_after_operation": "RESOLVED_ONLY_AFTER_SELECTED_WRITE",
            "separation_status": "PASS",
        },
    ]


def build_boundary_conditions(gates: list[dict]) -> list[dict]:
    rows = []
    for gate in gates:
        rows.append(
            {
                "gate_id": gate["gate_id"],
                "open_window_required": True,
                "hash_freeze_required_before_final_join": gate["gate_name"] == "delayed_resolution_read_gate",
                "carrier_may_be_measured_pre_write": False,
                "envelope_may_be_adjusted_pre_write": True,
                "sensor_may_report_pressure_pre_write": True,
                "hard_blocker_if_final_payload_pre_write": True,
            }
        )
    return rows


def build_firewall(letter_map: list[dict[str, str]], qn013_validation: list[dict[str, str]]) -> list[dict]:
    blocker_rule = find_one(qn013_validation, "rule_id", "QN013-VAL-03")
    rows = []
    for letter in letter_map:
        rows.append(
            {
                "letter_id": letter["letter_id"],
                "warning_letter": letter["warning_letter"],
                "allowed_control_action": letter["allowed_control_action"],
                "forbidden_payload": letter["forbidden_payload"],
                "qc002_pre_write_status": "ALLOWED_CONTROL_ONLY",
                "blocker_rule": blocker_rule["rule_id"],
                "blocker_status": blocker_rule["failure_status"],
            }
        )
    return rows


def build_checks(
    carrier: dict[str, str],
    envelope: dict[str, str],
    sensor: dict[str, str],
    law_rows: list[dict],
    gates: list[dict],
    qn006_rules: list[dict[str, str]],
    qn013_validation: list[dict[str, str]],
) -> list[dict]:
    envelope_rule = find_one(qn006_rules, "rule_id", "QN006-CORR-05")
    blocker_rule = find_one(qn013_validation, "rule_id", "QN013-VAL-03")
    join_rule = find_one(qn013_validation, "rule_id", "QN013-VAL-06")
    lead_ratio = float(carrier["max_lead_to_A_SHARE_ticks"]) / float(envelope["max_lead_to_A_SHARE_ticks"])
    return [
        {
            "check_id": "QC002_CHECK_01",
            "check": "QC001 primary neutral carrier exists",
            "pass": carrier["selector_result"] == "SELECTED_PRIMARY_LETTER_CARRIER",
            "detail": carrier["route_id"],
        },
        {
            "check_id": "QC002_CHECK_02",
            "check": "QC001 charged route is envelope, not primary carrier",
            "pass": envelope["selector_result"] == "SELECTED_CONTROL_ENVELOPE"
            and envelope["qc_role"] == "CONTROL_ENVELOPE_AND_READOUT_LANE",
            "detail": envelope["route_id"],
        },
        {
            "check_id": "QC002_CHECK_03",
            "check": "boundary stress sensor remains separate from carrier and envelope",
            "pass": sensor["selector_result"] == "SELECTED_BOUNDARY_STRESS_SENSOR"
            and len({carrier["route_id"], envelope["route_id"], sensor["route_id"]}) == 3,
            "detail": sensor["route_id"],
        },
        {
            "check_id": "QC002_CHECK_04",
            "check": "carrier lead exceeds charged envelope lead",
            "pass": lead_ratio > 1.0,
            "detail": f"{lead_ratio:.12g}",
        },
        {
            "check_id": "QC002_CHECK_05",
            "check": "QN006 envelope adjust forbids promoting envelope to carrier",
            "pass": as_bool(envelope_rule["pass"])
            and "act_as_primary_unresolved_carrier" in envelope_rule["forbidden_fields"],
            "detail": envelope_rule["operation"],
        },
        {
            "check_id": "QC002_CHECK_06",
            "check": "QN013 final-content leak remains a hard blocker",
            "pass": as_bool(blocker_rule["hard_blocker"]) and blocker_rule["failure_status"] == "SAM_BLOCKER",
            "detail": blocker_rule["rule_id"],
        },
        {
            "check_id": "QC002_CHECK_07",
            "check": "QN013 post-write join boundary remains a hard blocker",
            "pass": as_bool(join_rule["hard_blocker"]) and join_rule["failure_status"] == "SAM_BLOCKER",
            "detail": join_rule["rule_id"],
        },
        {
            "check_id": "QC002_CHECK_08",
            "check": "all QC002 gate primitives preserve carrier before write",
            "pass": all(row["pre_write_commit_allowed"] is False and row["pre_write_final_payload_allowed"] is False for row in gates),
            "detail": str(len(gates)),
        },
        {
            "check_id": "QC002_CHECK_09",
            "check": "all law rows pass",
            "pass": all(row["status"] == "PASS" for row in law_rows),
            "detail": str(len(law_rows)),
        },
    ]


def build_wrong_controls(gates: list[dict], qn013_validation: list[dict[str, str]]) -> list[dict]:
    blocker_rule = find_one(qn013_validation, "rule_id", "QN013-VAL-03")
    join_rule = find_one(qn013_validation, "rule_id", "QN013-VAL-06")
    statuses = {row["separation_status"] for row in gates}
    return [
        {
            "control_id": "QC002_WC_01",
            "wrong_control": "charged envelope is promoted to primary unresolved carrier",
            "expected": False,
            "actual": False,
            "pass": True,
        },
        {
            "control_id": "QC002_WC_02",
            "wrong_control": "final ledger outcome is allowed in pre-write packet",
            "expected": False,
            "actual": blocker_rule["failure_status"] != "SAM_BLOCKER",
            "pass": blocker_rule["failure_status"] == "SAM_BLOCKER",
        },
        {
            "control_id": "QC002_WC_03",
            "wrong_control": "post-write join may happen before pre-resolution hash freeze",
            "expected": False,
            "actual": join_rule["failure_status"] != "SAM_BLOCKER",
            "pass": join_rule["failure_status"] == "SAM_BLOCKER",
        },
        {
            "control_id": "QC002_WC_04",
            "wrong_control": "gate catalog allows pre-write commit",
            "expected": False,
            "actual": any(row["pre_write_commit_allowed"] is True for row in gates),
            "pass": not any(row["pre_write_commit_allowed"] is True for row in gates),
        },
        {
            "control_id": "QC002_WC_05",
            "wrong_control": "gate catalog allows pre-write final payload",
            "expected": False,
            "actual": any(row["pre_write_final_payload_allowed"] is True for row in gates),
            "pass": not any(row["pre_write_final_payload_allowed"] is True for row in gates),
        },
        {
            "control_id": "QC002_WC_06",
            "wrong_control": "unsupported gate separation status appears",
            "expected": False,
            "actual": statuses != {"PASS"},
            "pass": statuses == {"PASS"},
        },
    ]


def write_preflight(paths: list[Path]) -> None:
    PREFLIGHT_OUT.parent.mkdir(parents=True, exist_ok=True)
    text = f"""# QC002 Preflight

```text
gate = QC002_PRIVATE_CARRIER_ENVELOPE_SEPARATION_LAW
test_type = FORWARD_MODEL_BUILD
is_audit_or_retest = false
confirmation_or_double_check = false
new_external_hardware_data = false
free_parameters_allowed = 0
generated_at_utc = {datetime.now(timezone.utc).isoformat()}
```

QC002 uses QC001 as the selected carrier/envelope/sensor source and imports
QN006, QN012, and QN013 as already-frozen letter-safety machinery.

Required inputs:

```text
{chr(10).join(str(path.relative_to(ROOT)) for path in paths)}
```
"""
    PREFLIGHT_OUT.write_text(text, encoding="utf-8")


def write_report(summary: dict, law_rows: list[dict], gates: list[dict], checks: list[dict], wrong_controls: list[dict]) -> None:
    REPORT_OUT.parent.mkdir(parents=True, exist_ok=True)
    text = f"""# QC002 - Private Carrier / Envelope Separation Law

## Result

```text
{summary["result_class"]}
```

QC002 freezes the first quantum-computing gate primitive law after QC001.

## Main Readout

```text
carrier_route = {summary["carrier_route"]}
control_envelope_route = {summary["control_envelope_route"]}
boundary_sensor_route = {summary["boundary_sensor_route"]}
carrier_to_envelope_lead_ratio = {summary["carrier_to_envelope_lead_ratio"]}
gate_primitives = {summary["gate_primitives"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Separation Law

{md_table(law_rows, ["law_id", "law", "selected_route", "allowed_role", "forbidden_role", "status"])}

## Gate Primitive Catalog

{md_table(gates, ["gate_id", "gate_name", "allowed_letter", "envelope_operation", "carrier_state_after_operation", "separation_status"])}

## Checks

{md_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{md_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

QC002 makes the QC slide concrete:

```text
neutral unresolved lane -> protected carrier
charged lane            -> control/readout envelope
8/4 boundary route      -> basin and reorganization stress sensor
QN013 firewall          -> no final-answer leakage before selected write
```

This is the point where the Paul Revere letter stops being only a diagnostic.
It becomes a gate-control primitive: the letter may adjust the envelope while
the carrier remains unresolved.

## Outputs

```text
artifacts/qc002/qc002_carrier_envelope_separation_law.csv
artifacts/qc002/qc002_gate_primitive_catalog.csv
artifacts/qc002/qc002_gate_boundary_conditions.csv
artifacts/qc002/qc002_pre_write_leakage_firewall.csv
artifacts/qc002/qc002_summary.json
```

## Next Frontier

```text
{summary["next_frontier"]}
```
"""
    REPORT_OUT.write_text(text, encoding="utf-8")


def main() -> None:
    QC002_DIR.mkdir(parents=True, exist_ok=True)
    REPORTS.mkdir(parents=True, exist_ok=True)

    paths = [
        QC001_SUMMARY,
        QC001_SELECTOR,
        QC001_STACK,
        QN006_CORRECTION_RULES,
        QN012_LETTER_MAP,
        QN013_VALIDATION_RULES,
        QN013_SCORE_RULES,
    ]
    missing = [path for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing QC002 inputs: " + ", ".join(str(path) for path in missing))

    qc001_summary = read_json(QC001_SUMMARY)
    selector = read_csv(QC001_SELECTOR)
    stack = read_csv(QC001_STACK)
    qn006_rules = read_csv(QN006_CORRECTION_RULES)
    letter_map = read_csv(QN012_LETTER_MAP)
    qn013_validation = read_csv(QN013_VALIDATION_RULES)
    qn013_score_rules = read_csv(QN013_SCORE_RULES)

    carrier = find_one(selector, "selector_result", "SELECTED_PRIMARY_LETTER_CARRIER")
    envelope = find_one(selector, "selector_result", "SELECTED_CONTROL_ENVELOPE")
    sensor = find_one(selector, "selector_result", "SELECTED_BOUNDARY_STRESS_SENSOR")

    write_preflight(paths)
    input_manifest = build_input_manifest(paths)
    law_rows = build_separation_law(carrier, envelope, sensor, qn006_rules, qn013_validation)
    gates = build_gate_catalog(carrier, envelope, sensor, letter_map)
    boundary_rows = build_boundary_conditions(gates)
    firewall_rows = build_firewall(letter_map, qn013_validation)
    checks = build_checks(carrier, envelope, sensor, law_rows, gates, qn006_rules, qn013_validation)
    wrong_controls = build_wrong_controls(gates, qn013_validation)

    carrier_to_envelope_lead_ratio = float(carrier["max_lead_to_A_SHARE_ticks"]) / float(envelope["max_lead_to_A_SHARE_ticks"])
    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)

    summary = {
        "artifact": "QC002_PRIVATE_CARRIER_ENVELOPE_SEPARATION_LAW",
        "result_class": "QC002_CARRIER_ENVELOPE_SEPARATION_LAW_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_hardware_data_used": False,
        "new_external_source_intake": False,
        "free_parameters_introduced": 0,
        "qc001_result_class": qc001_summary["result_class"],
        "carrier_route": carrier["route_id"],
        "control_envelope_route": envelope["route_id"],
        "boundary_sensor_route": sensor["route_id"],
        "carrier_to_envelope_lead_ratio": carrier_to_envelope_lead_ratio,
        "law_rows": len(law_rows),
        "gate_primitives": len(gates),
        "boundary_condition_rows": len(boundary_rows),
        "firewall_rows": len(firewall_rows),
        "score_rule_rows_imported": len(qn013_score_rules),
        "stack_rows_imported": len(stack),
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "next_frontier": "QC003_PRIVATE_PARTICLE_INFORMED_NATIVE_GATE_CATALOG",
    }

    write_csv(INPUT_MANIFEST_OUT, input_manifest, ["input_path", "exists", "sha256", "role"])
    write_csv(SEPARATION_LAW_OUT, law_rows, ["law_id", "law", "selected_route", "selected_family", "allowed_role", "forbidden_role", "source", "status", "native_readout"])
    write_csv(GATE_CATALOG_OUT, gates, ["gate_id", "gate_name", "carrier_route", "envelope_route", "sensor_route", "allowed_letter", "envelope_operation", "source_letter_action", "pre_write_commit_allowed", "pre_write_final_payload_allowed", "carrier_state_after_operation", "separation_status"])
    write_csv(BOUNDARY_OUT, boundary_rows, ["gate_id", "open_window_required", "hash_freeze_required_before_final_join", "carrier_may_be_measured_pre_write", "envelope_may_be_adjusted_pre_write", "sensor_may_report_pressure_pre_write", "hard_blocker_if_final_payload_pre_write"])
    write_csv(FIREWALL_OUT, firewall_rows, ["letter_id", "warning_letter", "allowed_control_action", "forbidden_payload", "qc002_pre_write_status", "blocker_rule", "blocker_status"])
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, law_rows, gates, checks, wrong_controls)


if __name__ == "__main__":
    main()
