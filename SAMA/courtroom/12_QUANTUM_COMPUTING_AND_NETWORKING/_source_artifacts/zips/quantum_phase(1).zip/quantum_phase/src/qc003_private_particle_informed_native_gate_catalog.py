from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QC003_DIR = ARTIFACTS / "qc003"

QC002_SUMMARY = ARTIFACTS / "qc002" / "qc002_summary.json"
QC002_GATES = ARTIFACTS / "qc002" / "qc002_gate_primitive_catalog.csv"
QC002_BOUNDARY = ARTIFACTS / "qc002" / "qc002_gate_boundary_conditions.csv"
QC002_FIREWALL = ARTIFACTS / "qc002" / "qc002_pre_write_leakage_firewall.csv"
QN013_SCORE_RULES = ARTIFACTS / "qn013" / "sam_qn_trial_score_rules.csv"

PREFLIGHT_OUT = QC003_DIR / "qc003_preflight.md"
INPUT_MANIFEST_OUT = QC003_DIR / "qc003_input_manifest.csv"
NATIVE_CATALOG_OUT = QC003_DIR / "qc003_particle_informed_native_gate_catalog.csv"
GATE_OPERATION_OUT = QC003_DIR / "qc003_native_gate_operation_sequence.csv"
CALL_SURFACE_OUT = QC003_DIR / "qc003_gate_call_surface.csv"
CHECKS_OUT = QC003_DIR / "qc003_checks.csv"
WRONG_CONTROLS_OUT = QC003_DIR / "qc003_wrong_controls.csv"
SUMMARY_OUT = QC003_DIR / "qc003_summary.json"
NEXT_OUT = QC003_DIR / "qc003_next_frontier.csv"
REPORT_OUT = REPORTS / "QC003_PRIVATE_PARTICLE_INFORMED_NATIVE_GATE_CATALOG.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def md_table(rows: list[dict], fields: list[str]) -> str:
    header = "| " + " | ".join(fields) + " |"
    divider = "| " + " | ".join("---" for _ in fields) + " |"
    body = ["| " + " | ".join(str(row.get(field, "")) for field in fields) + " |" for row in rows]
    return "\n".join([header, divider, *body])


def truthy(value: object) -> bool:
    return str(value).strip().lower() in {"true", "1", "yes", "pass"}


def build_input_manifest(paths: list[Path]) -> list[dict]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "sha256": file_hash(path) if path.exists() else "",
        }
        for path in paths
    ]


def by_gate(gates: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    return {row["gate_name"]: row for row in gates}


def build_catalog(qc002_summary: dict, gates: list[dict[str, str]], firewall: list[dict[str, str]]) -> list[dict]:
    g = by_gate(gates)
    forbidden_payload = ";".join(sorted({part for row in firewall for part in row["forbidden_payload"].split(";")}))
    carrier = qc002_summary["carrier_route"]
    envelope = qc002_summary["control_envelope_route"]
    sensor = qc002_summary["boundary_sensor_route"]
    return [
        {
            "native_gate_id": "QC003-NG-01",
            "native_gate": "shielded_no_write_wait",
            "source_qc002_gates": "shielded_no_write_wait",
            "carrier_route": carrier,
            "envelope_route": envelope,
            "sensor_route": sensor,
            "allowed_pre_write_letters": "window-open flag",
            "carrier_operation": "preserve unresolved carrier in open no-write window",
            "envelope_operation": g["shielded_no_write_wait"]["envelope_operation"],
            "sensor_operation": "watch window pressure without selecting result",
            "forbidden_payload": forbidden_payload,
            "commit_rule": "NO_COMMIT_PRE_WRITE",
            "native_gate_status": "SELECTED",
        },
        {
            "native_gate_id": "QC003-NG-02",
            "native_gate": "letter_preserving_drift_gate",
            "source_qc002_gates": "phase_drift_envelope_correction;polarization_drift_envelope_correction",
            "carrier_route": carrier,
            "envelope_route": envelope,
            "sensor_route": sensor,
            "allowed_pre_write_letters": "phase drift;polarization drift",
            "carrier_operation": "keep final route unresolved while drift letter corrects envelope",
            "envelope_operation": "phase and polarization compensation",
            "sensor_operation": "report drift as allowed syndrome letter only",
            "forbidden_payload": forbidden_payload,
            "commit_rule": "NO_COMMIT_PRE_WRITE",
            "native_gate_status": "SELECTED",
        },
        {
            "native_gate_id": "QC003-NG-03",
            "native_gate": "basin_bias_steering_gate",
            "source_qc002_gates": "basin_stress_boundary_sensor_gate",
            "carrier_route": carrier,
            "envelope_route": envelope,
            "sensor_route": sensor,
            "allowed_pre_write_letters": "syndrome_signal;basin_bias;boundary_stress",
            "carrier_operation": "steer basin pressure without exposing logical route identity",
            "envelope_operation": g["basin_stress_boundary_sensor_gate"]["envelope_operation"],
            "sensor_operation": "read 8/4 boundary pressure as letter",
            "forbidden_payload": forbidden_payload,
            "commit_rule": "NO_COMMIT_PRE_WRITE",
            "native_gate_status": "SELECTED",
        },
        {
            "native_gate_id": "QC003-NG-04",
            "native_gate": "controlled_A_contact_gate",
            "source_qc002_gates": "shielded_no_write_wait;phase_drift_envelope_correction;polarization_drift_envelope_correction",
            "carrier_route": carrier,
            "envelope_route": envelope,
            "sensor_route": sensor,
            "allowed_pre_write_letters": "window-open flag;phase drift;polarization drift;timing headroom",
            "carrier_operation": "hold unresolved carrier while charged envelope modulates contact pressure",
            "envelope_operation": "bounded A-contact steering and timing control",
            "sensor_operation": "close control when window pressure reaches boundary",
            "forbidden_payload": forbidden_payload,
            "commit_rule": "NO_COMMIT_PRE_WRITE",
            "native_gate_status": "SELECTED",
        },
        {
            "native_gate_id": "QC003-NG-05",
            "native_gate": "delayed_resolution_read_gate",
            "source_qc002_gates": "delayed_resolution_read_gate",
            "carrier_route": carrier,
            "envelope_route": envelope,
            "sensor_route": sensor,
            "allowed_pre_write_letters": "timing headroom",
            "carrier_operation": "remain unresolved until selected write",
            "envelope_operation": g["delayed_resolution_read_gate"]["envelope_operation"],
            "sensor_operation": "confirm hash boundary before final join",
            "forbidden_payload": forbidden_payload,
            "commit_rule": "COMMIT_ALLOWED_ONLY_AFTER_SELECTED_WRITE_AND_HASH_FREEZE",
            "native_gate_status": "SELECTED",
        },
    ]


def build_operations(catalog: list[dict]) -> list[dict]:
    rows = []
    for gate in catalog:
        rows.extend(
            [
                {
                    "native_gate_id": gate["native_gate_id"],
                    "sequence_step": 1,
                    "operation_layer": "carrier",
                    "operation": gate["carrier_operation"],
                    "allowed_before_write": True,
                    "forbidden_before_write": "final measurement of carrier",
                },
                {
                    "native_gate_id": gate["native_gate_id"],
                    "sequence_step": 2,
                    "operation_layer": "sensor",
                    "operation": gate["sensor_operation"],
                    "allowed_before_write": True,
                    "forbidden_before_write": "logical route identity readout",
                },
                {
                    "native_gate_id": gate["native_gate_id"],
                    "sequence_step": 3,
                    "operation_layer": "envelope",
                    "operation": gate["envelope_operation"],
                    "allowed_before_write": True,
                    "forbidden_before_write": "promote envelope to primary carrier",
                },
                {
                    "native_gate_id": gate["native_gate_id"],
                    "sequence_step": 4,
                    "operation_layer": "ledger",
                    "operation": gate["commit_rule"],
                    "allowed_before_write": gate["commit_rule"] == "NO_COMMIT_PRE_WRITE",
                    "forbidden_before_write": "final_ledger_outcome",
                },
            ]
        )
    return rows


def build_call_surface(catalog: list[dict], boundary: list[dict[str, str]]) -> list[dict]:
    boundary_by_id = {row["gate_id"]: row for row in boundary}
    rows = []
    for gate in catalog:
        source_ids = [source for source in gate["source_qc002_gates"].split(";")]
        hash_required = any(
            truthy(boundary_by_id.get(source_to_id(source), {}).get("hash_freeze_required_before_final_join"))
            for source in source_ids
        )
        rows.append(
            {
                "native_gate_id": gate["native_gate_id"],
                "native_gate": gate["native_gate"],
                "call_allowed_when": "pre-resolution window open",
                "required_input": gate["allowed_pre_write_letters"],
                "hard_stop": gate["forbidden_payload"],
                "hash_freeze_required_before_final_join": hash_required,
                "score_if_complete": "PASS",
                "score_if_missing_surface": "PARTIAL",
                "score_if_leakage": "SAM_BLOCKER",
            }
        )
    return rows


def source_to_id(source: str) -> str:
    mapping = {
        "shielded_no_write_wait": "QC002-GATE-01",
        "phase_drift_envelope_correction": "QC002-GATE-02",
        "polarization_drift_envelope_correction": "QC002-GATE-03",
        "basin_stress_boundary_sensor_gate": "QC002-GATE-04",
        "delayed_resolution_read_gate": "QC002-GATE-05",
    }
    return mapping[source]


def build_checks(catalog: list[dict], operations: list[dict], call_surface: list[dict], qc002_summary: dict, score_rules: list[dict]) -> list[dict]:
    statuses = {row["native_gate_status"] for row in catalog}
    score_statuses = {row["status"] for row in score_rules}
    return [
        {"check_id": "QC003_CHECK_01", "check": "QC002 dependency is selected", "pass": qc002_summary["result_class"] == "QC002_CARRIER_ENVELOPE_SEPARATION_LAW_SELECTED", "detail": qc002_summary["result_class"]},
        {"check_id": "QC003_CHECK_02", "check": "five native gates selected", "pass": len(catalog) == 5 and statuses == {"SELECTED"}, "detail": str(len(catalog))},
        {"check_id": "QC003_CHECK_03", "check": "every gate preserves carrier pre-write", "pass": all(row["commit_rule"].startswith("NO_COMMIT") or row["native_gate"] == "delayed_resolution_read_gate" for row in catalog), "detail": "carrier unresolved before write"},
        {"check_id": "QC003_CHECK_04", "check": "controlled A-contact gate is present", "pass": any(row["native_gate"] == "controlled_A_contact_gate" for row in catalog), "detail": "controlled_A_contact_gate"},
        {"check_id": "QC003_CHECK_05", "check": "delayed read requires hash/final boundary", "pass": any(row["native_gate"] == "delayed_resolution_read_gate" and truthy(row["hash_freeze_required_before_final_join"]) for row in call_surface), "detail": "delayed_resolution_read_gate"},
        {"check_id": "QC003_CHECK_06", "check": "operation table has four layers per gate", "pass": len(operations) == 4 * len(catalog), "detail": str(len(operations))},
        {"check_id": "QC003_CHECK_07", "check": "call surface imports QN013 score vocabulary", "pass": {"PASS", "PARTIAL", "SAM_BLOCKER"}.issubset(score_statuses), "detail": ";".join(sorted(score_statuses))},
        {"check_id": "QC003_CHECK_08", "check": "no gate allows final payload before write", "pass": all("final" in row["hard_stop"] or "ledger" in row["hard_stop"] for row in call_surface), "detail": str(len(call_surface))},
    ]


def build_wrong_controls(catalog: list[dict], call_surface: list[dict]) -> list[dict]:
    return [
        {"control_id": "QC003_WC_01", "wrong_control": "native gate catalog omits protected carrier", "expected": False, "actual": any(not row["carrier_route"] for row in catalog), "pass": all(row["carrier_route"] for row in catalog)},
        {"control_id": "QC003_WC_02", "wrong_control": "native gate catalog omits charged envelope", "expected": False, "actual": any(not row["envelope_route"] for row in catalog), "pass": all(row["envelope_route"] for row in catalog)},
        {"control_id": "QC003_WC_03", "wrong_control": "native gate catalog omits boundary sensor", "expected": False, "actual": any(not row["sensor_route"] for row in catalog), "pass": all(row["sensor_route"] for row in catalog)},
        {"control_id": "QC003_WC_04", "wrong_control": "a pre-write call surface scores leakage as pass", "expected": False, "actual": any(row["score_if_leakage"] == "PASS" for row in call_surface), "pass": all(row["score_if_leakage"] == "SAM_BLOCKER" for row in call_surface)},
        {"control_id": "QC003_WC_05", "wrong_control": "controlled A-contact gate is missing", "expected": False, "actual": not any(row["native_gate"] == "controlled_A_contact_gate" for row in catalog), "pass": any(row["native_gate"] == "controlled_A_contact_gate" for row in catalog)},
        {"control_id": "QC003_WC_06", "wrong_control": "unsupported native gate status appears", "expected": False, "actual": any(row["native_gate_status"] != "SELECTED" for row in catalog), "pass": all(row["native_gate_status"] == "SELECTED" for row in catalog)},
    ]


def write_preflight(paths: list[Path]) -> None:
    PREFLIGHT_OUT.parent.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        f"""# QC003 Preflight

```text
gate = QC003_PRIVATE_PARTICLE_INFORMED_NATIVE_GATE_CATALOG
test_type = FORWARD_MODEL_BUILD
is_audit_or_retest = false
confirmation_or_double_check = false
new_external_hardware_data = false
free_parameters_allowed = 0
generated_at_utc = {datetime.now(timezone.utc).isoformat()}
```

QC003 promotes the QC002 primitive rows into a native gate catalog. It does not
rerun QC002 and does not use external hardware data.

```text
{chr(10).join(str(path.relative_to(ROOT)) for path in paths)}
```
""",
        encoding="utf-8",
    )


def write_report(summary: dict, catalog: list[dict], call_surface: list[dict], checks: list[dict], wrong_controls: list[dict]) -> None:
    REPORT_OUT.parent.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QC003 - Particle-Informed Native Gate Catalog

## Result

```text
{summary["result_class"]}
```

## Main Readout

```text
native_gates = {summary["native_gates"]}
operation_rows = {summary["operation_rows"]}
call_surface_rows = {summary["call_surface_rows"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Native Gate Catalog

{md_table(catalog, ["native_gate_id", "native_gate", "allowed_pre_write_letters", "carrier_operation", "envelope_operation", "commit_rule"])}

## Call Surface

{md_table(call_surface, ["native_gate_id", "native_gate", "required_input", "score_if_complete", "score_if_missing_surface", "score_if_leakage"])}

## Checks

{md_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{md_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

QC003 is the callable gate layer. QC002 separated carrier, envelope, and sensor.
QC003 names the gates that can be invoked without opening the protected carrier
early.

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    QC003_DIR.mkdir(parents=True, exist_ok=True)
    paths = [QC002_SUMMARY, QC002_GATES, QC002_BOUNDARY, QC002_FIREWALL, QN013_SCORE_RULES]
    missing = [path for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing QC003 inputs: " + ", ".join(str(path) for path in missing))

    qc002_summary = read_json(QC002_SUMMARY)
    gates = read_csv(QC002_GATES)
    boundary = read_csv(QC002_BOUNDARY)
    firewall = read_csv(QC002_FIREWALL)
    score_rules = read_csv(QN013_SCORE_RULES)

    write_preflight(paths)
    input_manifest = build_input_manifest(paths)
    catalog = build_catalog(qc002_summary, gates, firewall)
    operations = build_operations(catalog)
    call_surface = build_call_surface(catalog, boundary)
    checks = build_checks(catalog, operations, call_surface, qc002_summary, score_rules)
    wrong_controls = build_wrong_controls(catalog, call_surface)

    summary = {
        "artifact": "QC003_PRIVATE_PARTICLE_INFORMED_NATIVE_GATE_CATALOG",
        "result_class": "QC003_PARTICLE_INFORMED_NATIVE_GATE_CATALOG_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_hardware_data_used": False,
        "new_external_source_intake": False,
        "free_parameters_introduced": 0,
        "qc002_result_class": qc002_summary["result_class"],
        "native_gates": len(catalog),
        "operation_rows": len(operations),
        "call_surface_rows": len(call_surface),
        "check_passes": sum(row["pass"] is True for row in checks),
        "check_total": len(checks),
        "wrong_control_passes": sum(row["pass"] is True for row in wrong_controls),
        "wrong_control_total": len(wrong_controls),
        "next_frontier": "QC004_PRIVATE_PAUL_REVERE_READOUT_PROTOCOL",
    }

    write_csv(INPUT_MANIFEST_OUT, input_manifest, ["input_path", "exists", "sha256"])
    write_csv(NATIVE_CATALOG_OUT, catalog, ["native_gate_id", "native_gate", "source_qc002_gates", "carrier_route", "envelope_route", "sensor_route", "allowed_pre_write_letters", "carrier_operation", "envelope_operation", "sensor_operation", "forbidden_payload", "commit_rule", "native_gate_status"])
    write_csv(GATE_OPERATION_OUT, operations, ["native_gate_id", "sequence_step", "operation_layer", "operation", "allowed_before_write", "forbidden_before_write"])
    write_csv(CALL_SURFACE_OUT, call_surface, ["native_gate_id", "native_gate", "call_allowed_when", "required_input", "hard_stop", "hash_freeze_required_before_final_join", "score_if_complete", "score_if_missing_surface", "score_if_leakage"])
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, catalog, call_surface, checks, wrong_controls)


if __name__ == "__main__":
    main()
