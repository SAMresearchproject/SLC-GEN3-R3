from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
QC004_DIR = ARTIFACTS / "qc004"

QC003_SUMMARY = ARTIFACTS / "qc003" / "qc003_summary.json"
QC003_CATALOG = ARTIFACTS / "qc003" / "qc003_particle_informed_native_gate_catalog.csv"
QC003_CALL_SURFACE = ARTIFACTS / "qc003" / "qc003_gate_call_surface.csv"
QC002_FIREWALL = ARTIFACTS / "qc002" / "qc002_pre_write_leakage_firewall.csv"
QN012_LETTER_MAP = ARTIFACTS / "qn012" / "paul_revere_self_correction_map.csv"
QN013_VALIDATION = ARTIFACTS / "qn013" / "sam_qn_live_data_validation_rules.csv"

PREFLIGHT_OUT = QC004_DIR / "qc004_preflight.md"
INPUT_MANIFEST_OUT = QC004_DIR / "qc004_input_manifest.csv"
READOUT_PROTOCOL_OUT = QC004_DIR / "qc004_paul_revere_readout_protocol.csv"
OBSERVABLES_OUT = QC004_DIR / "qc004_allowed_forbidden_observables.csv"
SAMPLE_READOUT_OUT = QC004_DIR / "qc004_sample_readout_event_log.csv"
CHECKS_OUT = QC004_DIR / "qc004_checks.csv"
WRONG_CONTROLS_OUT = QC004_DIR / "qc004_wrong_controls.csv"
SUMMARY_OUT = QC004_DIR / "qc004_summary.json"
NEXT_OUT = QC004_DIR / "qc004_next_frontier.csv"
REPORT_OUT = REPORTS / "QC004_PRIVATE_PAUL_REVERE_READOUT_PROTOCOL.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def md_table(rows: list[dict], fields: list[str]) -> str:
    header = "| " + " | ".join(fields) + " |"
    divider = "| " + " | ".join("---" for _ in fields) + " |"
    body = ["| " + " | ".join(str(row.get(field, "")) for field in fields) + " |" for row in rows]
    return "\n".join([header, divider, *body])


def manifest(paths: list[Path]) -> list[dict]:
    return [{"input_path": str(path.relative_to(ROOT)), "exists": path.exists(), "sha256": file_hash(path) if path.exists() else ""} for path in paths]


def build_observables(letter_map: list[dict[str, str]], validation: list[dict[str, str]]) -> list[dict]:
    hard_blockers = ";".join(row["rule_id"] for row in validation if row.get("hard_blocker") == "True")
    allowed = [
        ("route_family", "allowed letter field", "pre-write"),
        ("boundary_stress", "allowed letter field", "pre-write"),
        ("time_to_A_SIDE", "allowed letter field", "pre-write"),
        ("time_to_A_SHARE", "allowed letter field", "pre-write"),
        ("basin_bias", "allowed letter field", "pre-write"),
        ("syndrome_signal", "allowed letter field", "pre-write"),
    ]
    forbidden = sorted({part for row in letter_map for part in row["forbidden_payload"].split(";")})
    rows = [
        {"observable": name, "observable_class": cls, "timing": timing, "readout_status": "ALLOWED_PRE_WRITE", "hard_blocker_rule": ""}
        for name, cls, timing in allowed
    ]
    rows.extend(
        {"observable": name, "observable_class": "forbidden final content", "timing": "pre-write", "readout_status": "SAM_BLOCKER", "hard_blocker_rule": hard_blockers}
        for name in forbidden
    )
    rows.append({"observable": "selected_final_result", "observable_class": "final ledger content", "timing": "post-write only", "readout_status": "ALLOWED_ONLY_AFTER_SELECTED_WRITE_AND_HASH_FREEZE", "hard_blocker_rule": hard_blockers})
    return rows


def build_protocol(catalog: list[dict[str, str]], call_surface: list[dict[str, str]]) -> list[dict]:
    call_by_gate = {row["native_gate"]: row for row in call_surface}
    rows = []
    for gate in catalog:
        call = call_by_gate[gate["native_gate"]]
        rows.append(
            {
                "protocol_step": len(rows) + 1,
                "native_gate": gate["native_gate"],
                "readout_target": gate["allowed_pre_write_letters"],
                "readout_lane": gate["sensor_route"],
                "control_lane": gate["envelope_route"],
                "protected_lane": gate["carrier_route"],
                "allowed_pre_write_readout": "boundary stress / basin pressure / timing / syndrome only",
                "forbidden_pre_write_readout": call["hard_stop"],
                "post_write_join_rule": "hash freeze required" if call["hash_freeze_required_before_final_join"] == "True" else "no final join at this gate",
                "protocol_status": "SELECTED",
            }
        )
    return rows


def build_sample_events(protocol: list[dict]) -> list[dict]:
    rows = []
    for row in protocol:
        rows.append(
            {
                "event_id": f'QC004-EVT-{int(row["protocol_step"]):02d}',
                "native_gate": row["native_gate"],
                "pre_write_readout_seen": row["readout_target"],
                "control_action_allowed": True,
                "final_payload_seen_pre_write": False,
                "score": "PASS",
            }
        )
    rows.append(
        {
            "event_id": "QC004-EVT-BLOCK",
            "native_gate": "leakage_control",
            "pre_write_readout_seen": "final_ledger_outcome",
            "control_action_allowed": False,
            "final_payload_seen_pre_write": True,
            "score": "SAM_BLOCKER",
        }
    )
    return rows


def checks(protocol: list[dict], observables: list[dict], samples: list[dict], summary: dict) -> list[dict]:
    allowed_count = sum(row["readout_status"] == "ALLOWED_PRE_WRITE" for row in observables)
    blocker_count = sum(row["readout_status"] == "SAM_BLOCKER" for row in observables)
    return [
        {"check_id": "QC004_CHECK_01", "check": "QC003 dependency is selected", "pass": summary["result_class"] == "QC003_PARTICLE_INFORMED_NATIVE_GATE_CATALOG_SELECTED", "detail": summary["result_class"]},
        {"check_id": "QC004_CHECK_02", "check": "all QC003 native gates receive readout protocol rows", "pass": len(protocol) == summary["native_gates"], "detail": str(len(protocol))},
        {"check_id": "QC004_CHECK_03", "check": "allowed pre-write observable set has six SAM letter fields", "pass": allowed_count == 6, "detail": str(allowed_count)},
        {"check_id": "QC004_CHECK_04", "check": "forbidden final payload fields map to SAM_BLOCKER", "pass": blocker_count >= 6, "detail": str(blocker_count)},
        {"check_id": "QC004_CHECK_05", "check": "delayed read gate carries hash freeze rule", "pass": any(row["native_gate"] == "delayed_resolution_read_gate" and row["post_write_join_rule"] == "hash freeze required" for row in protocol), "detail": "delayed_resolution_read_gate"},
        {"check_id": "QC004_CHECK_06", "check": "sample clean events pass", "pass": all(row["score"] == "PASS" for row in samples if row["event_id"] != "QC004-EVT-BLOCK"), "detail": str(len(samples) - 1)},
        {"check_id": "QC004_CHECK_07", "check": "sample leakage event blocks", "pass": any(row["event_id"] == "QC004-EVT-BLOCK" and row["score"] == "SAM_BLOCKER" for row in samples), "detail": "QC004-EVT-BLOCK"},
        {"check_id": "QC004_CHECK_08", "check": "carrier lane is protected in every protocol row", "pass": all(row["protected_lane"] == "QUBIT-NL-001" for row in protocol), "detail": "QUBIT-NL-001"},
    ]


def wrong_controls(protocol: list[dict], samples: list[dict]) -> list[dict]:
    return [
        {"control_id": "QC004_WC_01", "wrong_control": "final payload pre-write is treated as allowed", "expected": False, "actual": any(row["final_payload_seen_pre_write"] == "True" and row["score"] == "PASS" for row in samples), "pass": not any(row["final_payload_seen_pre_write"] == "True" and row["score"] == "PASS" for row in samples)},
        {"control_id": "QC004_WC_02", "wrong_control": "readout protocol omits protected carrier", "expected": False, "actual": any(not row["protected_lane"] for row in protocol), "pass": all(row["protected_lane"] for row in protocol)},
        {"control_id": "QC004_WC_03", "wrong_control": "readout protocol omits control lane", "expected": False, "actual": any(not row["control_lane"] for row in protocol), "pass": all(row["control_lane"] for row in protocol)},
        {"control_id": "QC004_WC_04", "wrong_control": "readout protocol omits sensor lane", "expected": False, "actual": any(not row["readout_lane"] for row in protocol), "pass": all(row["readout_lane"] for row in protocol)},
        {"control_id": "QC004_WC_05", "wrong_control": "delayed read lacks hash-freeze rule", "expected": False, "actual": not any(row["native_gate"] == "delayed_resolution_read_gate" and row["post_write_join_rule"] == "hash freeze required" for row in protocol), "pass": any(row["native_gate"] == "delayed_resolution_read_gate" and row["post_write_join_rule"] == "hash freeze required" for row in protocol)},
        {"control_id": "QC004_WC_06", "wrong_control": "unsupported protocol status appears", "expected": False, "actual": any(row["protocol_status"] != "SELECTED" for row in protocol), "pass": all(row["protocol_status"] == "SELECTED" for row in protocol)},
    ]


def write_report(summary: dict, protocol: list[dict], observables: list[dict], check_rows: list[dict], wc_rows: list[dict]) -> None:
    REPORT_OUT.parent.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QC004 - Paul Revere Readout Protocol

## Result

```text
{summary["result_class"]}
```

## Main Readout

```text
protocol_rows = {summary["protocol_rows"]}
allowed_pre_write_observables = {summary["allowed_pre_write_observables"]}
blocked_pre_write_observables = {summary["blocked_pre_write_observables"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Protocol

{md_table(protocol, ["protocol_step", "native_gate", "readout_target", "allowed_pre_write_readout", "post_write_join_rule", "protocol_status"])}

## Observable Split

{md_table(observables, ["observable", "timing", "readout_status"])}

## Checks

{md_table(check_rows, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{md_table(wc_rows, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    paths = [QC003_SUMMARY, QC003_CATALOG, QC003_CALL_SURFACE, QC002_FIREWALL, QN012_LETTER_MAP, QN013_VALIDATION]
    missing = [path for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing QC004 inputs: " + ", ".join(str(path) for path in missing))
    QC004_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        f"# QC004 Preflight\n\n```text\ngate = QC004_PRIVATE_PAUL_REVERE_READOUT_PROTOCOL\ntest_type = FORWARD_MODEL_BUILD\nis_audit_or_retest = false\nconfirmation_or_double_check = false\nnew_external_hardware_data = false\nfree_parameters_allowed = 0\ngenerated_at_utc = {datetime.now(timezone.utc).isoformat()}\n```\n",
        encoding="utf-8",
    )
    qc003_summary = read_json(QC003_SUMMARY)
    catalog = read_csv(QC003_CATALOG)
    call_surface = read_csv(QC003_CALL_SURFACE)
    letter_map = read_csv(QN012_LETTER_MAP)
    validation = read_csv(QN013_VALIDATION)
    obs = build_observables(letter_map, validation)
    protocol = build_protocol(catalog, call_surface)
    samples = build_sample_events(protocol)
    check_rows = checks(protocol, obs, samples, qc003_summary)
    wc_rows = wrong_controls(protocol, samples)
    summary = {
        "artifact": "QC004_PRIVATE_PAUL_REVERE_READOUT_PROTOCOL",
        "result_class": "QC004_PAUL_REVERE_READOUT_PROTOCOL_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_hardware_data_used": False,
        "new_external_source_intake": False,
        "free_parameters_introduced": 0,
        "qc003_result_class": qc003_summary["result_class"],
        "protocol_rows": len(protocol),
        "allowed_pre_write_observables": sum(row["readout_status"] == "ALLOWED_PRE_WRITE" for row in obs),
        "blocked_pre_write_observables": sum(row["readout_status"] == "SAM_BLOCKER" for row in obs),
        "sample_events": len(samples),
        "check_passes": sum(row["pass"] is True for row in check_rows),
        "check_total": len(check_rows),
        "wrong_control_passes": sum(row["pass"] is True for row in wc_rows),
        "wrong_control_total": len(wc_rows),
        "next_frontier": "QC005_PRIVATE_MATERIAL_ISOTOPE_SUPPORT_FILTER",
    }
    write_csv(INPUT_MANIFEST_OUT, manifest(paths), ["input_path", "exists", "sha256"])
    write_csv(READOUT_PROTOCOL_OUT, protocol, ["protocol_step", "native_gate", "readout_target", "readout_lane", "control_lane", "protected_lane", "allowed_pre_write_readout", "forbidden_pre_write_readout", "post_write_join_rule", "protocol_status"])
    write_csv(OBSERVABLES_OUT, obs, ["observable", "observable_class", "timing", "readout_status", "hard_blocker_rule"])
    write_csv(SAMPLE_READOUT_OUT, samples, ["event_id", "native_gate", "pre_write_readout_seen", "control_action_allowed", "final_payload_seen_pre_write", "score"])
    write_csv(CHECKS_OUT, check_rows, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wc_rows, ["control_id", "wrong_control", "expected", "actual", "pass"])
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, protocol, obs, check_rows, wc_rows)


if __name__ == "__main__":
    main()
