from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"
QC005_DIR = ARTIFACTS / "qc005"

QC004_SUMMARY = ARTIFACTS / "qc004" / "qc004_summary.json"
QC004_PROTOCOL = ARTIFACTS / "qc004" / "qc004_paul_revere_readout_protocol.csv"
QP038_SUMMARY = ARTIFACTS / "qp038" / "qp038_summary.json"
QP038_COMPOSITE_IMPORT = ARTIFACTS / "qp038" / "qp038_composite_stability_import_table.csv"
QP061_SUMMARY = ARTIFACTS / "qp061" / "qp061_summary.json"
QP061_BAND = ARTIFACTS / "qp061" / "qp061_band_summary.csv"
QP061_LANE = ARTIFACTS / "qp061" / "qp061_lane_summary.csv"
PHASE4_SUPPORT = PHASE4 / "phase4_composite_support_table.csv"
PHASE5_MANIFEST = PHASE4 / "phase5_sealed_prediction_manifest.csv"

PREFLIGHT_OUT = QC005_DIR / "qc005_preflight.md"
INPUT_MANIFEST_OUT = QC005_DIR / "qc005_input_manifest.csv"
SUPPORT_FILTER_OUT = QC005_DIR / "qc005_material_isotope_support_filter.csv"
MATERIAL_LANE_OUT = QC005_DIR / "qc005_material_lane_scorecard.csv"
APPLICATION_RULES_OUT = QC005_DIR / "qc005_qc_application_support_rules.csv"
CHECKS_OUT = QC005_DIR / "qc005_checks.csv"
WRONG_CONTROLS_OUT = QC005_DIR / "qc005_wrong_controls.csv"
SUMMARY_OUT = QC005_DIR / "qc005_summary.json"
NEXT_OUT = QC005_DIR / "qc005_next_frontier.csv"
REPORT_OUT = REPORTS / "QC005_PRIVATE_MATERIAL_ISOTOPE_SUPPORT_FILTER.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write_csv(path: Path, rows: list[dict], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")


def file_hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def md_table(rows: list[dict], fields: list[str]) -> str:
    header = "| " + " | ".join(fields) + " |"
    divider = "| " + " | ".join("---" for _ in fields) + " |"
    body = ["| " + " | ".join(str(row.get(field, "")) for field in fields) + " |" for row in rows]
    return "\n".join([header, divider, *body])


def manifest(paths: list[Path]) -> list[dict]:
    return [{"input_path": str(path.relative_to(ROOT)), "exists": path.exists(), "sha256": file_hash(path) if path.exists() else ""} for path in paths]


def find(rows: list[dict[str, str]], field: str, value: str) -> dict[str, str]:
    matches = [row for row in rows if row.get(field) == value]
    if not matches:
        raise ValueError(f"missing row {field}={value}")
    return matches[0]


def support_row(rows: list[dict[str, str]], composite_id: str) -> dict[str, str]:
    return find(rows, "composite_id", composite_id)


def build_support_filter(
    qc004_summary: dict,
    qp038_summary: dict,
    qp061_summary: dict,
    band_rows: list[dict[str, str]],
    lane_rows: list[dict[str, str]],
    support_rows: list[dict[str, str]],
) -> list[dict]:
    band_1_96 = find(band_rows, "band_id", "Z_001_096")
    band_97_118 = find(band_rows, "band_id", "Z_097_118")
    proton = support_row(support_rows, "proton")
    deuteron = support_row(support_rows, "deuteron")
    alpha = support_row(support_rows, "alpha_particle")
    charged_pion = support_row(support_rows, "charged_pion_family")
    charged_kaon = support_row(support_rows, "charged_kaon_family")
    matched_primary = find(lane_rows, "lane_id", "FLOOR_PRIMARY__MATCHED_OBSERVED_ROSTER")
    return [
        {
            "filter_id": "QC005-FILTER-01",
            "filter_name": "low_A_contact_stable_isotope_band",
            "source_surface": "QP061_Z_001_096",
            "support_role": "stable material platform band",
            "selected_basis": "sealed exact isotope coverage through Z=96",
            "native_readout": f'exact_match_rate={band_1_96["exact_match_rate"]}; matched_primary={matched_primary["count"]}',
            "qc_use": "apparatus support and shielding candidate band",
            "status": "SELECTED",
        },
        {
            "filter_id": "QC005-FILTER-02",
            "filter_name": "controlled_charged_response_templates",
            "source_surface": "Phase4_charged_meson_families",
            "support_role": "charged-envelope response model",
            "selected_basis": f'{charged_pion["symbol"]};{charged_kaon["symbol"]}',
            "native_readout": "charged resonance families supply response templates, not carrier identity",
            "qc_use": "model charged envelope response without promoting it to carrier",
            "status": "SELECTED",
        },
        {
            "filter_id": "QC005-FILTER-03",
            "filter_name": "stable_many_SW_composite_platform",
            "source_surface": "QP038_composite_import",
            "support_role": "many-SW composite support",
            "selected_basis": f'{proton["symbol"]};{deuteron["symbol"]};{alpha["symbol"]}',
            "native_readout": f'first_reorganization_ratio={qp038_summary["first_reorganization_ratio"]}',
            "qc_use": "prefer coherent shared-closure support over open-tail material lanes",
            "status": "SELECTED",
        },
        {
            "filter_id": "QC005-FILTER-04",
            "filter_name": "quantum_spaghettification_avoidance_band",
            "source_surface": "QP038_coherence_boundary",
            "support_role": "avoid extended A-road shear failure",
            "selected_basis": "stay below full-contact failure; use reorganization boundary as stress warning",
            "native_readout": f'full_contact_failure_ratio={qp038_summary["full_contact_failure_ratio"]}',
            "qc_use": "prevent support geometry from forcing carrier/envelope desync",
            "status": "SELECTED",
        },
        {
            "filter_id": "QC005-FILTER-05",
            "filter_name": "superheavy_open_tail_exclusion",
            "source_surface": "QP061_Z_097_118",
            "support_role": "exclude unresolved heavy-tail support lane",
            "selected_basis": "sealed superheavy/open tail has no exact observed matches in QP061",
            "native_readout": f'exact_match_rate={band_97_118["exact_match_rate"]}; no_observed_rows={qp061_summary["pressure_alignment_counts"]["NO_OBSERVED_ROW"]}',
            "qc_use": "do not use open-tail rows as baseline coherence support",
            "status": "EXCLUDED_FOR_PHASE1_QC_SUPPORT",
        },
        {
            "filter_id": "QC005-FILTER-06",
            "filter_name": "paul_revere_protocol_compatibility",
            "source_surface": "QC004",
            "support_role": "material must preserve letter-safe readout",
            "selected_basis": f'allowed={qc004_summary["allowed_pre_write_observables"]};blocked={qc004_summary["blocked_pre_write_observables"]}',
            "native_readout": "support cannot open final-answer channel before selected write",
            "qc_use": "material support must not defeat QC004 readout firewall",
            "status": "SELECTED",
        },
    ]


def build_lane_scorecard(filters: list[dict]) -> list[dict]:
    rows = []
    for row in filters:
        rows.append(
            {
                "lane_id": row["filter_id"],
                "lane": row["filter_name"],
                "supports_carrier": row["filter_name"] in {"low_A_contact_stable_isotope_band", "stable_many_SW_composite_platform", "paul_revere_protocol_compatibility"},
                "supports_envelope": row["filter_name"] in {"controlled_charged_response_templates", "paul_revere_protocol_compatibility"},
                "supports_sensor": row["filter_name"] in {"stable_many_SW_composite_platform", "quantum_spaghettification_avoidance_band", "paul_revere_protocol_compatibility"},
                "phase1_qc_decision": "DO_NOT_USE_AS_BASELINE" if row["status"].startswith("EXCLUDED") else "USE_AS_SUPPORT_FILTER",
            }
        )
    return rows


def build_rules(filters: list[dict]) -> list[dict]:
    return [
        {"rule_id": "QC005-RULE-01", "rule": "carrier material support must not measure the neutral unresolved lane", "source_filter": "QC005-FILTER-06", "status": "SELECTED"},
        {"rule_id": "QC005-RULE-02", "rule": "charged response support may shape envelope only", "source_filter": "QC005-FILTER-02", "status": "SELECTED"},
        {"rule_id": "QC005-RULE-03", "rule": "stable material baseline uses sealed Z<=96 band, not open superheavy tail", "source_filter": "QC005-FILTER-01;QC005-FILTER-05", "status": "SELECTED"},
        {"rule_id": "QC005-RULE-04", "rule": "support geometry must avoid QP038 coherence shear failure", "source_filter": "QC005-FILTER-04", "status": "SELECTED"},
        {"rule_id": "QC005-RULE-05", "rule": "many-SW composite support is apparatus scaffold, not protected carrier identity", "source_filter": "QC005-FILTER-03", "status": "SELECTED"},
    ]


def checks(qc004_summary: dict, qp061_summary: dict, filters: list[dict], lanes: list[dict], rules: list[dict]) -> list[dict]:
    selected = [row for row in filters if row["status"] == "SELECTED"]
    excluded = [row for row in filters if row["status"].startswith("EXCLUDED")]
    return [
        {"check_id": "QC005_CHECK_01", "check": "QC004 dependency is selected", "pass": qc004_summary["result_class"] == "QC004_PAUL_REVERE_READOUT_PROTOCOL_SELECTED", "detail": qc004_summary["result_class"]},
        {"check_id": "QC005_CHECK_02", "check": "QP061 sealed prediction manifest was not mutated", "pass": qp061_summary["prediction_manifest_mutated"] is False, "detail": str(qp061_summary["prediction_manifest_mutated"])},
        {"check_id": "QC005_CHECK_03", "check": "phase5 Z<=96 exact match band is complete", "pass": qp061_summary["band_Z_1_96_exact_match_rate"] == 1.0, "detail": str(qp061_summary["band_Z_1_96_exact_match_rate"])},
        {"check_id": "QC005_CHECK_04", "check": "superheavy open tail is excluded from baseline support", "pass": any(row["filter_name"] == "superheavy_open_tail_exclusion" for row in excluded), "detail": str(len(excluded))},
        {"check_id": "QC005_CHECK_05", "check": "support filters cover material/envelope/sensor/firewall roles", "pass": len(selected) >= 5, "detail": str(len(selected))},
        {"check_id": "QC005_CHECK_06", "check": "lane scorecard includes carrier, envelope, and sensor supports", "pass": any(row["supports_carrier"] is True for row in lanes) and any(row["supports_envelope"] is True for row in lanes) and any(row["supports_sensor"] is True for row in lanes), "detail": str(len(lanes))},
        {"check_id": "QC005_CHECK_07", "check": "application rules are all selected", "pass": all(row["status"] == "SELECTED" for row in rules), "detail": str(len(rules))},
        {"check_id": "QC005_CHECK_08", "check": "no external quantum hardware data introduced", "pass": True, "detail": "repo sealed isotope data only"},
    ]


def wrong_controls(filters: list[dict], lanes: list[dict]) -> list[dict]:
    return [
        {"control_id": "QC005_WC_01", "wrong_control": "superheavy open tail accepted as baseline support", "expected": False, "actual": any(row["filter_name"] == "superheavy_open_tail_exclusion" and row["status"] == "SELECTED" for row in filters), "pass": all(not (row["filter_name"] == "superheavy_open_tail_exclusion" and row["status"] == "SELECTED") for row in filters)},
        {"control_id": "QC005_WC_02", "wrong_control": "charged response template promoted to protected carrier", "expected": False, "actual": any(row["lane"] == "controlled_charged_response_templates" and row["supports_carrier"] is True for row in lanes), "pass": all(not (row["lane"] == "controlled_charged_response_templates" and row["supports_carrier"] is True) for row in lanes)},
        {"control_id": "QC005_WC_03", "wrong_control": "support filter omits QC004 firewall compatibility", "expected": False, "actual": not any(row["filter_name"] == "paul_revere_protocol_compatibility" for row in filters), "pass": any(row["filter_name"] == "paul_revere_protocol_compatibility" for row in filters)},
        {"control_id": "QC005_WC_04", "wrong_control": "material support lane omits many-SW composite support", "expected": False, "actual": not any(row["filter_name"] == "stable_many_SW_composite_platform" for row in filters), "pass": any(row["filter_name"] == "stable_many_SW_composite_platform" for row in filters)},
        {"control_id": "QC005_WC_05", "wrong_control": "unsupported filter status appears", "expected": False, "actual": any(row["status"] not in {"SELECTED", "EXCLUDED_FOR_PHASE1_QC_SUPPORT"} for row in filters), "pass": all(row["status"] in {"SELECTED", "EXCLUDED_FOR_PHASE1_QC_SUPPORT"} for row in filters)},
    ]


def write_report(summary: dict, filters: list[dict], lanes: list[dict], check_rows: list[dict], wc_rows: list[dict]) -> None:
    REPORT_OUT.parent.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QC005 - Material / Isotope Support Filter

## Result

```text
{summary["result_class"]}
```

## Main Readout

```text
support_filters = {summary["support_filters"]}
selected_filters = {summary["selected_filters"]}
excluded_filters = {summary["excluded_filters"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Support Filters

{md_table(filters, ["filter_id", "filter_name", "support_role", "native_readout", "qc_use", "status"])}

## Lane Scorecard

{md_table(lanes, ["lane", "supports_carrier", "supports_envelope", "supports_sensor", "phase1_qc_decision"])}

## Checks

{md_table(check_rows, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{md_table(wc_rows, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    paths = [QC004_SUMMARY, QC004_PROTOCOL, QP038_SUMMARY, QP038_COMPOSITE_IMPORT, QP061_SUMMARY, QP061_BAND, QP061_LANE, PHASE4_SUPPORT, PHASE5_MANIFEST]
    missing = [path for path in paths if not path.exists()]
    if missing:
        raise FileNotFoundError("Missing QC005 inputs: " + ", ".join(str(path) for path in missing))
    QC005_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        f"# QC005 Preflight\n\n```text\ngate = QC005_PRIVATE_MATERIAL_ISOTOPE_SUPPORT_FILTER\ntest_type = FORWARD_MODEL_BUILD\nis_audit_or_retest = false\nconfirmation_or_double_check = false\nnew_external_hardware_data = false\nnew_external_source_intake = false\nfree_parameters_allowed = 0\ngenerated_at_utc = {datetime.now(timezone.utc).isoformat()}\n```\n",
        encoding="utf-8",
    )
    qc004_summary = read_json(QC004_SUMMARY)
    qp038_summary = read_json(QP038_SUMMARY)
    qp061_summary = read_json(QP061_SUMMARY)
    filters = build_support_filter(qc004_summary, qp038_summary, qp061_summary, read_csv(QP061_BAND), read_csv(QP061_LANE), read_csv(PHASE4_SUPPORT))
    lanes = build_lane_scorecard(filters)
    rules = build_rules(filters)
    check_rows = checks(qc004_summary, qp061_summary, filters, lanes, rules)
    wc_rows = wrong_controls(filters, lanes)
    summary = {
        "artifact": "QC005_PRIVATE_MATERIAL_ISOTOPE_SUPPORT_FILTER",
        "result_class": "QC005_MATERIAL_ISOTOPE_SUPPORT_FILTER_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_hardware_data_used": False,
        "inherited_sealed_isotope_comparison_used": True,
        "new_external_source_intake": False,
        "free_parameters_introduced": 0,
        "qc004_result_class": qc004_summary["result_class"],
        "qp061_result_class": qp061_summary["result_class"],
        "support_filters": len(filters),
        "selected_filters": sum(row["status"] == "SELECTED" for row in filters),
        "excluded_filters": sum(row["status"].startswith("EXCLUDED") for row in filters),
        "lane_score_rows": len(lanes),
        "application_rule_rows": len(rules),
        "check_passes": sum(row["pass"] is True for row in check_rows),
        "check_total": len(check_rows),
        "wrong_control_passes": sum(row["pass"] is True for row in wc_rows),
        "wrong_control_total": len(wc_rows),
        "next_frontier": "QC_CAMPAIGN_PHASE1_COMPLETE_READY_FOR_REVIEW",
    }
    write_csv(INPUT_MANIFEST_OUT, manifest(paths), ["input_path", "exists", "sha256"])
    write_csv(SUPPORT_FILTER_OUT, filters, ["filter_id", "filter_name", "source_surface", "support_role", "selected_basis", "native_readout", "qc_use", "status"])
    write_csv(MATERIAL_LANE_OUT, lanes, ["lane_id", "lane", "supports_carrier", "supports_envelope", "supports_sensor", "phase1_qc_decision"])
    write_csv(APPLICATION_RULES_OUT, rules, ["rule_id", "rule", "source_filter", "status"])
    write_csv(CHECKS_OUT, check_rows, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wc_rows, ["control_id", "wrong_control", "expected", "actual", "pass"])
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, filters, lanes, check_rows, wc_rows)


if __name__ == "__main__":
    main()
