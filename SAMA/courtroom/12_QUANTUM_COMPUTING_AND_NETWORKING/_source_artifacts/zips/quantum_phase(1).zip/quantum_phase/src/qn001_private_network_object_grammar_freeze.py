from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN001_DIR = ARTIFACTS / "qn001"

QC001_SUMMARY = ARTIFACTS / "qc001" / "qc001_summary.json"
QC001_SELECTOR = ARTIFACTS / "qc001" / "qc001_particle_informed_carrier_selector.csv"
QC001_STACK = ARTIFACTS / "qc001" / "qc001_carrier_envelope_support_stack.csv"
QP012B_SCHEMA = ARTIFACTS / "qp012b" / "qp012b_letter_content_schema.csv"
QP014_PRIORS = ARTIFACTS / "qp014" / "qp014_route_capacity_prior_table.csv"
QP015_COMMITS = ARTIFACTS / "qp015" / "qp015_sample_commit_summary.csv"
QP016_MODES = ARTIFACTS / "qp016" / "qp016_stable_mode_selector_table.csv"
QP038_SUMMARY = ARTIFACTS / "qp038" / "qp038_summary.json"

PREFLIGHT_OUT = QN001_DIR / "qn001_preflight.md"
INPUT_MANIFEST_OUT = QN001_DIR / "qn001_input_manifest.csv"
OBJECTS_OUT = QN001_DIR / "network_object_grammar.csv"
ROLE_STACK_OUT = QN001_DIR / "network_role_stack.csv"
SAFETY_OUT = QN001_DIR / "ledger_safety_rules.csv"
VIABILITY_OUT = QN001_DIR / "network_viability_terms.csv"
CHECKS_OUT = QN001_DIR / "qn001_checks.csv"
WRONG_CONTROLS_OUT = QN001_DIR / "qn001_wrong_controls.csv"
SUMMARY_OUT = QN001_DIR / "qn001_summary.json"
NEXT_OUT = QN001_DIR / "qn001_next_frontier.csv"
REPORT_OUT = REPORTS / "QN001_PRIVATE_NETWORK_OBJECT_GRAMMAR_FREEZE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def allowed_fields(schema_rows: list[dict[str, str]]) -> list[str]:
    return [
        row["letter_field"]
        for row in schema_rows
        if row.get("allowed_before_resolution") == "True"
    ]


def forbidden_fields(schema_rows: list[dict[str, str]]) -> list[str]:
    return [
        row["letter_field"]
        for row in schema_rows
        if row.get("allowed_before_resolution") != "True"
    ]


def by_route(rows: list[dict[str, str]], key: str = "route_id") -> dict[str, dict[str, str]]:
    return {row[key]: row for row in rows if row.get(key)}


def write_preflight() -> None:
    QN001_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN001 Preflight - Private Network Object Grammar Freeze

## Mode

```text
FORWARD_NETWORK_GRAMMAR_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN001 does not rerun QC001 or QP012B-QP016. It imports their frozen outputs and
promotes them into a SAM quantum-network object grammar.

## Question

```text
Can QC001 carrier/envelope/support roles be promoted into a complete SAM
network object grammar?
```

## Success Condition

```text
Every network object has a SAM source, permitted pre-resolution content, and a
forbidden leakage field.
```

No external quantum-network hardware data and no fitted network parameters are
introduced.
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for path in paths:
        rows.append(
            {
                "input_path": str(path.relative_to(ROOT)),
                "exists": path.exists(),
                "source_role": "FROZEN_PRIVATE_ARTIFACT_IMPORT",
            }
        )
    return rows


def build_objects(
    qc_summary: dict[str, object],
    selector_rows: list[dict[str, str]],
    stack_rows: list[dict[str, str]],
    schema_rows: list[dict[str, str]],
    prior_rows: list[dict[str, str]],
) -> list[dict[str, object]]:
    selector = by_route(selector_rows)
    priors = by_route(prior_rows, "qubit_id")
    allowed = ";".join(allowed_fields(schema_rows))
    forbidden = ";".join(forbidden_fields(schema_rows))

    primary = str(qc_summary["primary_letter_carrier"])
    envelope = str(qc_summary["control_envelope"])
    sensor = str(qc_summary["boundary_stress_sensor"])

    stack_by_layer = {row["layer_name"]: row for row in stack_rows}

    objects = [
        {
            "network_object_id": "QN-CARRIER-001",
            "object_name": "protected unresolved carrier",
            "object_class": "UNRESOLVED_CARRIER",
            "selected_route": primary,
            "selected_family": qc_summary["primary_letter_particle_family"],
            "route_capacity_prior": priors[primary]["route_capacity_prior"],
            "source_artifact": "QC001;QP012B;QP014;QP016",
            "permitted_pre_resolution_content": allowed,
            "forbidden_content": forbidden,
            "network_permission": "CARRY_UNRESOLVED_ROUTE_STATE_AND_SYNDROME_LETTER",
            "ledger_safety_guard": 1,
            "native_reason": selector[primary]["native_reason"],
        },
        {
            "network_object_id": "QN-ENVELOPE-001",
            "object_name": "charged control envelope",
            "object_class": "CONTROL_ENVELOPE",
            "selected_route": envelope,
            "selected_family": qc_summary["control_envelope_particle_family"],
            "route_capacity_prior": priors[envelope]["route_capacity_prior"],
            "source_artifact": "QC001;QP012B;QP014",
            "permitted_pre_resolution_content": allowed,
            "forbidden_content": forbidden,
            "network_permission": "STEER_TIME_GATE_AND_READ_BOUNDARY_WITHOUT_BECOMING_CARRIER",
            "ledger_safety_guard": 1,
            "native_reason": selector[envelope]["native_reason"],
        },
        {
            "network_object_id": "QN-SENSOR-001",
            "object_name": "boundary stress sensor",
            "object_class": "BOUNDARY_SENSOR",
            "selected_route": sensor,
            "selected_family": qc_summary["boundary_stress_sensor_family"],
            "route_capacity_prior": priors[sensor]["route_capacity_prior"],
            "source_artifact": "QC001;QP012B;QP014;QP016",
            "permitted_pre_resolution_content": "boundary_stress;time_to_A_SIDE;time_to_A_SHARE;basin_bias;syndrome_signal",
            "forbidden_content": forbidden,
            "network_permission": "REPORT_BASIN_PRESSURE_WITHOUT_FINAL_ROUTE_IDENTITY",
            "ledger_safety_guard": 1,
            "native_reason": selector[sensor]["native_reason"],
        },
        {
            "network_object_id": "QN-LEDGERNODE-001",
            "object_name": "controlled ledger node",
            "object_class": "LEDGER_NODE",
            "selected_route": "LOCAL_NODE_COMPOSITE",
            "selected_family": "node_support",
            "route_capacity_prior": "",
            "source_artifact": "QP015;QP016;QP038",
            "permitted_pre_resolution_content": allowed,
            "forbidden_content": "premature_ledger_commit;" + forbidden,
            "network_permission": "HOLD_HANDOFF_OR_RESOLVE_ONLY_AT_SELECTED_WRITE",
            "ledger_safety_guard": 1,
            "native_reason": "node is the controlled place where unresolved route pressure becomes ledger-visible only when selected",
        },
        {
            "network_object_id": "QN-RELAY-001",
            "object_name": "ledger-safe relay",
            "object_class": "RELAY_REPEATER",
            "selected_route": "CARRIER_PLUS_ENVELOPE_HANDOFF",
            "selected_family": "relay_support",
            "route_capacity_prior": "",
            "source_artifact": "QP012B;QP014;QP015;QC001",
            "permitted_pre_resolution_content": "route_family;boundary_stress;time_to_A_SIDE;time_to_A_SHARE;basin_bias;syndrome_signal",
            "forbidden_content": "clone_final_outcome;copy_logical_route_identity;" + forbidden,
            "network_permission": "TRANSFER_ROUTE_PRESSURE_AND_SYNDROME_STRUCTURE_NOT_FINAL_OUTCOME",
            "ledger_safety_guard": 1,
            "native_reason": "relay preserves the letter and route pressure without copying the final route",
        },
        {
            "network_object_id": "QN-SUPPORT-001",
            "object_name": "material composite support",
            "object_class": "MATERIAL_SUPPORT",
            "selected_route": stack_by_layer["material/composite support"]["selected_route"],
            "selected_family": stack_by_layer["material/composite support"]["selected_family"],
            "route_capacity_prior": "",
            "source_artifact": "QC001;QP038",
            "permitted_pre_resolution_content": "shielding;isolation;geometry_support;coherence_platform",
            "forbidden_content": "act_as_primary_unresolved_carrier;" + forbidden,
            "network_permission": "SUPPORT_APPARATUS_WITHOUT_BECOMING_ROUTE_IDENTITY",
            "ledger_safety_guard": 1,
            "native_reason": stack_by_layer["material/composite support"]["native_rule"],
        },
    ]
    return objects


def build_role_stack(objects: list[dict[str, object]]) -> list[dict[str, object]]:
    order = [
        "QN-CARRIER-001",
        "QN-ENVELOPE-001",
        "QN-SENSOR-001",
        "QN-LEDGERNODE-001",
        "QN-RELAY-001",
        "QN-SUPPORT-001",
    ]
    lookup = {str(row["network_object_id"]): row for row in objects}
    return [
        {
            "stack_layer": idx,
            "network_object_id": object_id,
            "object_name": lookup[object_id]["object_name"],
            "object_class": lookup[object_id]["object_class"],
            "selected_route": lookup[object_id]["selected_route"],
            "role_in_network": lookup[object_id]["network_permission"],
        }
        for idx, object_id in enumerate(order, start=1)
    ]


def build_safety_rules(schema_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for idx, row in enumerate(schema_rows, start=1):
        allowed = row["allowed_before_resolution"] == "True"
        rows.append(
            {
                "rule_id": f"QN001-SAFETY-{idx:02d}",
                "field": row["letter_field"],
                "allowed_before_resolution": allowed,
                "network_action": "MAY_TRANSPORT_AS_LETTER" if allowed else "MUST_NOT_TRANSPORT_AS_PRE_RESOLUTION_FACT",
                "failure_if_violated": "premature_ledger_leak" if not allowed else "",
                "meaning": row["meaning"],
            }
        )
    rows.extend(
        [
            {
                "rule_id": "QN001-SAFETY-09",
                "field": "repeater_copy",
                "allowed_before_resolution": True,
                "network_action": "COPY_SYNDROME_STRUCTURE_ONLY",
                "failure_if_violated": "no_clone_guard_failure",
                "meaning": "relay may preserve route pressure but must not copy final logical route identity",
            },
            {
                "rule_id": "QN001-SAFETY-10",
                "field": "ledger_commit",
                "allowed_before_resolution": False,
                "network_action": "DELAY_UNTIL_SELECTED_WRITE",
                "failure_if_violated": "premature_resolution",
                "meaning": "the network endpoint may resolve only at the selected ledger event",
            },
        ]
    )
    return rows


def build_viability_terms(
    qc_summary: dict[str, object],
    prior_rows: list[dict[str, str]],
    objects: list[dict[str, object]],
) -> list[dict[str, object]]:
    priors = by_route(prior_rows, "qubit_id")
    primary = str(qc_summary["primary_letter_carrier"])
    envelope = str(qc_summary["control_envelope"])
    sensor = str(qc_summary["boundary_stress_sensor"])
    object_lookup = {str(row["network_object_id"]): row for row in objects}
    return [
        {
            "term": "carrier_capacity",
            "source": "QP014 route_capacity_prior",
            "route": primary,
            "value": priors[primary]["route_capacity_prior"],
            "interpretation": "capacity of the unresolved carrier route",
        },
        {
            "term": "segment_survival",
            "source": "QN001 grammar placeholder",
            "route": primary,
            "value": "TO_BE_SCORED_IN_QN002",
            "interpretation": "no-write survival across a link segment",
        },
        {
            "term": "envelope_control",
            "source": "QC001 selected control envelope",
            "route": envelope,
            "value": priors[envelope]["route_capacity_prior"],
            "interpretation": "charged lane support for steering/readout without carrier promotion",
        },
        {
            "term": "boundary_letter_readability",
            "source": "QC001 selected boundary stress sensor",
            "route": sensor,
            "value": priors[sensor]["route_capacity_prior"],
            "interpretation": "availability of stress/basin/timing letter readout",
        },
        {
            "term": "ledger_safety_guard",
            "source": "QN001 ledger safety rules",
            "route": "ALL",
            "value": min(int(row["ledger_safety_guard"]) for row in object_lookup.values()),
            "interpretation": "1 only if final outcome and route identity remain forbidden before resolution",
        },
    ]


def build_checks(objects: list[dict[str, object]], safety_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    object_count = len(objects)
    final_forbidden = all("final_ledger_outcome" in str(row["forbidden_content"]) for row in objects)
    logical_forbidden = all("logical_route_identity" in str(row["forbidden_content"]) for row in objects)
    every_source = all(bool(row["source_artifact"]) for row in objects)
    every_permission = all(bool(row["network_permission"]) for row in objects)
    forbidden_safety_count = sum(not bool(row["allowed_before_resolution"]) for row in safety_rows)
    return [
        {
            "check_id": "QN001_CHECK_01",
            "check": "six network objects frozen",
            "pass": object_count == 6,
            "detail": object_count,
        },
        {
            "check_id": "QN001_CHECK_02",
            "check": "final ledger outcome forbidden on every object",
            "pass": final_forbidden,
            "detail": final_forbidden,
        },
        {
            "check_id": "QN001_CHECK_03",
            "check": "logical route identity forbidden on every object",
            "pass": logical_forbidden,
            "detail": logical_forbidden,
        },
        {
            "check_id": "QN001_CHECK_04",
            "check": "every object has a source artifact and network permission",
            "pass": every_source and every_permission,
            "detail": f"sources={every_source}; permissions={every_permission}",
        },
        {
            "check_id": "QN001_CHECK_05",
            "check": "ledger safety table includes forbidden fields",
            "pass": forbidden_safety_count >= 3,
            "detail": forbidden_safety_count,
        },
    ]


def build_wrong_controls(objects: list[dict[str, object]]) -> list[dict[str, object]]:
    primary = next(row for row in objects if row["network_object_id"] == "QN-CARRIER-001")
    envelope = next(row for row in objects if row["network_object_id"] == "QN-ENVELOPE-001")
    relay = next(row for row in objects if row["network_object_id"] == "QN-RELAY-001")
    return [
        {
            "control_id": "QN001_WC_01",
            "wrong_control": "charged envelope promoted to primary protected carrier",
            "expected": False,
            "actual": envelope["object_class"] == "UNRESOLVED_CARRIER",
            "pass": envelope["object_class"] != "UNRESOLVED_CARRIER",
        },
        {
            "control_id": "QN001_WC_02",
            "wrong_control": "primary carrier allowed to transport final ledger outcome",
            "expected": False,
            "actual": "final_ledger_outcome" in str(primary["permitted_pre_resolution_content"]),
            "pass": "final_ledger_outcome" not in str(primary["permitted_pre_resolution_content"]),
        },
        {
            "control_id": "QN001_WC_03",
            "wrong_control": "relay copies logical route identity",
            "expected": False,
            "actual": "logical_route_identity" in str(relay["permitted_pre_resolution_content"]),
            "pass": "logical_route_identity" not in str(relay["permitted_pre_resolution_content"]),
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    objects: list[dict[str, object]],
    role_stack: list[dict[str, object]],
    safety_rows: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN001 - Private Network Object Grammar Freeze

## Result

```text
{summary["result_class"]}
```

QN001 freezes the first SAM-native quantum-network object grammar.

## Main Readout

```text
network_objects = {summary["network_objects"]}
ledger_safety_rules = {summary["ledger_safety_rules"]}
primary_carrier = {summary["primary_carrier"]}
control_envelope = {summary["control_envelope"]}
boundary_sensor = {summary["boundary_sensor"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
external_quantum_network_data_used = {summary["external_quantum_network_data_used"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Frozen Objects

{markdown_table(objects, ["network_object_id", "object_class", "selected_route", "selected_family", "network_permission"])}

## Role Stack

{markdown_table(role_stack, ["stack_layer", "network_object_id", "object_name", "object_class", "role_in_network"])}

## Ledger Safety

{markdown_table(safety_rows, ["rule_id", "field", "allowed_before_resolution", "network_action"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

The network grammar is:

```text
pre-resolution letters may travel
final ledger outcomes may not
logical route identity may not
```

The protected carrier is the neutral unresolved route from QC001. The charged
lane is the control envelope, not the primary carrier. The 8/4 boundary route is
the stress sensor. Ledger nodes and relays are allowed only if they preserve the
forbidden-outcome boundary.

## Outputs

```text
artifacts/qn001/qn001_preflight.md
artifacts/qn001/qn001_input_manifest.csv
artifacts/qn001/network_object_grammar.csv
artifacts/qn001/network_role_stack.csv
artifacts/qn001/ledger_safety_rules.csv
artifacts/qn001/network_viability_terms.csv
artifacts/qn001/qn001_checks.csv
artifacts/qn001/qn001_wrong_controls.csv
artifacts/qn001/qn001_summary.json
artifacts/qn001/qn001_next_frontier.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = [
        QC001_SUMMARY,
        QC001_SELECTOR,
        QC001_STACK,
        QP012B_SCHEMA,
        QP014_PRIORS,
        QP015_COMMITS,
        QP016_MODES,
        QP038_SUMMARY,
    ]
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])

    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN001 inputs: {missing}")

    qc_summary = read_json(QC001_SUMMARY)
    selector_rows = read_csv(QC001_SELECTOR)
    stack_rows = read_csv(QC001_STACK)
    schema_rows = read_csv(QP012B_SCHEMA)
    prior_rows = read_csv(QP014_PRIORS)
    qp038_summary = read_json(QP038_SUMMARY)

    objects = build_objects(qc_summary, selector_rows, stack_rows, schema_rows, prior_rows)
    role_stack = build_role_stack(objects)
    safety_rows = build_safety_rules(schema_rows)
    viability_rows = build_viability_terms(qc_summary, prior_rows, objects)
    checks = build_checks(objects, safety_rows)
    wrong_controls = build_wrong_controls(objects)

    write_csv(
        OBJECTS_OUT,
        objects,
        [
            "network_object_id",
            "object_name",
            "object_class",
            "selected_route",
            "selected_family",
            "route_capacity_prior",
            "source_artifact",
            "permitted_pre_resolution_content",
            "forbidden_content",
            "network_permission",
            "ledger_safety_guard",
            "native_reason",
        ],
    )
    write_csv(
        ROLE_STACK_OUT,
        role_stack,
        ["stack_layer", "network_object_id", "object_name", "object_class", "selected_route", "role_in_network"],
    )
    write_csv(
        SAFETY_OUT,
        safety_rows,
        ["rule_id", "field", "allowed_before_resolution", "network_action", "failure_if_violated", "meaning"],
    )
    write_csv(VIABILITY_OUT, viability_rows, ["term", "source", "route", "value", "interpretation"])
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])

    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)

    summary = {
        "artifact": "QN001_PRIVATE_NETWORK_OBJECT_GRAMMAR_FREEZE",
        "result_class": "QN001_NETWORK_OBJECT_GRAMMAR_FROZEN",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_NETWORK_GRAMMAR_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": False,
        "free_parameters_introduced": 0,
        "network_objects": len(objects),
        "ledger_safety_rules": len(safety_rows),
        "primary_carrier": qc_summary["primary_letter_carrier"],
        "control_envelope": qc_summary["control_envelope"],
        "boundary_sensor": qc_summary["boundary_stress_sensor"],
        "primary_route_capacity_prior": viability_rows[0]["value"],
        "qp038_boundary_rule": qp038_summary["boundary_rule"],
        "core_network_rule": "pre-resolution letters may travel; final ledger outcomes may not",
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "next_frontier": "QN002_PRIVATE_LINK_SURVIVAL_AND_CONTACT_SUPPRESSION_LAW",
    }
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, objects, role_stack, safety_rows, checks, wrong_controls)


if __name__ == "__main__":
    main()
