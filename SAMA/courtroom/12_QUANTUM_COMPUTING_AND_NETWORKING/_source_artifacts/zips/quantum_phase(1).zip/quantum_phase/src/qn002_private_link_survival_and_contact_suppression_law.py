from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN002_DIR = ARTIFACTS / "qn002"

QN001_SUMMARY = ARTIFACTS / "qn001" / "qn001_summary.json"
QN001_OBJECTS = ARTIFACTS / "qn001" / "network_object_grammar.csv"
QN001_SAFETY = ARTIFACTS / "qn001" / "ledger_safety_rules.csv"
QP013_CONTACT = ARTIFACTS / "qp013" / "qp013_contact_suppression_table.csv"
QP013_WINDOWS = ARTIFACTS / "qp013" / "qp013_route_control_window_table.csv"
QP014_PRIORS = ARTIFACTS / "qp014" / "qp014_route_capacity_prior_table.csv"
QP014_SURFACE = ARTIFACTS / "qp014" / "qp014_probability_surface_table.csv"

PREFLIGHT_OUT = QN002_DIR / "qn002_preflight.md"
INPUT_MANIFEST_OUT = QN002_DIR / "qn002_input_manifest.csv"
SURVIVAL_OUT = QN002_DIR / "sam_link_survival_table.csv"
VIABILITY_OUT = QN002_DIR / "sam_link_viability_score.csv"
FORMULA_OUT = QN002_DIR / "sam_link_score_formula.csv"
CHECKS_OUT = QN002_DIR / "qn002_checks.csv"
WRONG_CONTROLS_OUT = QN002_DIR / "qn002_wrong_controls.csv"
SUMMARY_OUT = QN002_DIR / "qn002_summary.json"
NEXT_OUT = QN002_DIR / "qn002_next_frontier.csv"
REPORT_OUT = REPORTS / "QN002_PRIVATE_LINK_SURVIVAL_AND_CONTACT_SUPPRESSION_LAW.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def fnum(value: object, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def write_preflight() -> None:
    QN002_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN002 Preflight - Private Link Survival And Contact Suppression Law

## Mode

```text
FORWARD_NETWORK_LINK_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN002 does not rerun QN001, QP013, or QP014. It imports their frozen outputs and
builds the first SAM-native quantum-network link survival score.

## Question

```text
Can a network link be scored by no-write survival, A-contact suppression, and
carrier route capacity?
```

## Success Condition

```text
The selected carrier survives as unresolved state across a segment without
requiring final route identity to be known.
```

No external quantum-network hardware data and no fitted link parameters are
introduced.
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "source_role": "FROZEN_PRIVATE_ARTIFACT_IMPORT",
        }
        for path in paths
    ]


def route_lookup(rows: list[dict[str, str]], key: str) -> dict[str, dict[str, str]]:
    return {row[key]: row for row in rows if row.get(key)}


def contact_counts(contact_rows: list[dict[str, str]]) -> dict[str, dict[str, int]]:
    counts: dict[str, dict[str, int]] = {}
    for row in contact_rows:
        route = row["qubit_id"]
        bucket = counts.setdefault(route, {"total": 0, "valid": 0, "active": 0, "too_late": 0})
        bucket["total"] += 1
        if row.get("valid_pre_resolution_letter") == "True":
            bucket["valid"] += 1
        if row.get("control_class") == "ACTIVE_A_CONTACT_SUPPRESSION_WINDOW":
            bucket["active"] += 1
        if row.get("control_class") == "NO_COLLAPSE_WINDOW_CLOSED":
            bucket["too_late"] += 1
    return counts


def build_formula_rows() -> list[dict[str, object]]:
    return [
        {
            "term": "valid_letter_fraction",
            "formula": "valid_pre_resolution_letter_rows / total_contact_rows",
            "source": "QP013 contact suppression table",
            "role": "fraction of sampled contact states where a letter exists before resolution",
        },
        {
            "term": "active_suppression_fraction",
            "formula": "active_suppression_rows / total_contact_rows",
            "source": "QP013 contact suppression table",
            "role": "fraction of sampled contact states with actionable suppression before collapse",
        },
        {
            "term": "headroom_factor",
            "formula": "max_pre_resolution_headroom_to_A_SHARE",
            "source": "QP013 route control window table",
            "role": "how much no-write headroom remains before A_SHARE",
        },
        {
            "term": "suppression_margin_to_A_SIDE",
            "formula": "1 - max_required_suppression_to_restore_A_SIDE / native_theoretical_ceiling_before_A_SHARE",
            "source": "QP013 route control window table",
            "role": "margin left after restoring the route to the A_SIDE guard",
        },
        {
            "term": "segment_survival_score",
            "formula": "valid_letter_fraction * active_suppression_fraction * headroom_factor * suppression_margin_to_A_SIDE * ledger_safety_guard",
            "source": "QN001 + QP013",
            "role": "dimensionless no-write survival of a route segment",
        },
        {
            "term": "link_viability_score",
            "formula": "segment_survival_score * route_capacity_prior",
            "source": "QN001 + QP013 + QP014",
            "role": "dimensionless SAM network link score",
        },
    ]


def build_survival_rows(
    qn_objects: list[dict[str, str]],
    window_rows: list[dict[str, str]],
    prior_rows: list[dict[str, str]],
    counts: dict[str, dict[str, int]],
) -> list[dict[str, object]]:
    windows = route_lookup(window_rows, "qubit_id")
    priors = route_lookup(prior_rows, "qubit_id")
    rows: list[dict[str, object]] = []
    for obj in qn_objects:
        route = obj["selected_route"]
        route_present = route in windows and route in priors
        total = counts.get(route, {}).get("total", 0)
        valid = counts.get(route, {}).get("valid", 0)
        active = counts.get(route, {}).get("active", 0)
        too_late = counts.get(route, {}).get("too_late", 0)
        valid_fraction = valid / total if total else 0.0
        active_fraction = active / total if total else 0.0
        if route_present:
            window = windows[route]
            prior = priors[route]
            route_capacity = fnum(prior["route_capacity_prior"])
            headroom = fnum(window["max_pre_resolution_headroom_to_A_SHARE"])
            required = fnum(window["max_required_suppression_to_restore_A_SIDE"])
            ceiling = fnum(window["native_theoretical_ceiling_before_A_SHARE"])
            suppression_margin = max(0.0, 1.0 - required / ceiling) if ceiling else 0.0
            ledger_guard = int(fnum(obj["ledger_safety_guard"]))
            segment_survival = valid_fraction * active_fraction * headroom * suppression_margin * ledger_guard
            link_score = segment_survival * route_capacity
        else:
            route_capacity = 0.0
            headroom = 0.0
            required = 0.0
            ceiling = 0.0
            suppression_margin = 0.0
            ledger_guard = int(fnum(obj["ledger_safety_guard"]))
            segment_survival = 0.0
            link_score = 0.0

        if obj["network_object_id"] == "QN-CARRIER-001":
            selector_class = "SELECTED_PROTECTED_LINK_CARRIER"
            reading = "primary network link carrier is scored from no-write survival, suppression margin, and route capacity"
        elif obj["object_class"] == "CONTROL_ENVELOPE":
            selector_class = "CONTROL_ENVELOPE_SIDE_BAND_NOT_PRIMARY_LINK"
            reading = "charged lane supports steering/readout but is not the protected link carrier"
        elif obj["object_class"] == "BOUNDARY_SENSOR":
            selector_class = "BOUNDARY_SENSOR_SIDE_BAND"
            reading = "boundary sensor reports basin pressure but is not the main carrier"
        elif route_present:
            selector_class = "SECONDARY_ROUTE_NOT_PRIMARY_LINK"
            reading = "route is scorable but does not outrank the protected carrier"
        else:
            selector_class = "NOT_LINK_SURVIVAL_CANDIDATE"
            reading = "object supports network grammar but lacks a standalone route-survival score in QN002"

        rows.append(
            {
                "network_object_id": obj["network_object_id"],
                "object_class": obj["object_class"],
                "selected_route": route,
                "selected_family": obj["selected_family"],
                "route_present_in_qp013_qp014": route_present,
                "total_contact_rows": total,
                "valid_letter_rows": valid,
                "active_suppression_rows": active,
                "too_late_rows": too_late,
                "valid_letter_fraction": valid_fraction,
                "active_suppression_fraction": active_fraction,
                "headroom_factor": headroom,
                "max_required_suppression_to_restore_A_SIDE": required,
                "native_theoretical_ceiling_before_A_SHARE": ceiling,
                "suppression_margin_to_A_SIDE": suppression_margin,
                "route_capacity_prior": route_capacity,
                "ledger_safety_guard": ledger_guard,
                "segment_survival_score": segment_survival,
                "link_viability_score": link_score,
                "selector_class": selector_class,
                "SAM_reading": reading,
            }
        )

    max_score = max(fnum(row["link_viability_score"]) for row in rows)
    for row in rows:
        row["selected_top_link"] = fnum(row["link_viability_score"]) == max_score and max_score > 0
    return rows


def build_viability_rows(survival_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    candidates = [row for row in survival_rows if fnum(row["link_viability_score"]) > 0]
    ranked = sorted(candidates, key=lambda row: fnum(row["link_viability_score"]), reverse=True)
    rows: list[dict[str, object]] = []
    for rank, row in enumerate(ranked, start=1):
        rows.append(
            {
                "rank": rank,
                "network_object_id": row["network_object_id"],
                "object_class": row["object_class"],
                "selected_route": row["selected_route"],
                "selected_family": row["selected_family"],
                "segment_survival_score": row["segment_survival_score"],
                "route_capacity_prior": row["route_capacity_prior"],
                "link_viability_score": row["link_viability_score"],
                "selected_top_link": row["selected_top_link"],
                "selector_class": row["selector_class"],
            }
        )
    return rows


def build_checks(survival_rows: list[dict[str, object]], viability_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    top = viability_rows[0]
    carrier = next(row for row in survival_rows if row["network_object_id"] == "QN-CARRIER-001")
    forbidden_guard = all("final_ledger_outcome" not in str(row.get("permitted_pre_resolution_content", "")) for row in survival_rows)
    route_rows = sum(bool(row["route_present_in_qp013_qp014"]) for row in survival_rows)
    return [
        {
            "check_id": "QN002_CHECK_01",
            "check": "protected carrier is top scored link",
            "pass": top["network_object_id"] == "QN-CARRIER-001",
            "detail": top["network_object_id"],
        },
        {
            "check_id": "QN002_CHECK_02",
            "check": "carrier has positive no-write segment survival",
            "pass": fnum(carrier["segment_survival_score"]) > 0,
            "detail": carrier["segment_survival_score"],
        },
        {
            "check_id": "QN002_CHECK_03",
            "check": "at least three route-backed network objects are scored",
            "pass": route_rows >= 3,
            "detail": route_rows,
        },
        {
            "check_id": "QN002_CHECK_04",
            "check": "selected top link keeps ledger safety guard",
            "pass": int(fnum(carrier["ledger_safety_guard"])) == 1,
            "detail": carrier["ledger_safety_guard"],
        },
        {
            "check_id": "QN002_CHECK_05",
            "check": "no survival row permits final outcome as pre-resolution content",
            "pass": forbidden_guard,
            "detail": forbidden_guard,
        },
    ]


def build_wrong_controls(survival_rows: list[dict[str, object]], viability_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    top = viability_rows[0]
    envelope = next(row for row in survival_rows if row["network_object_id"] == "QN-ENVELOPE-001")
    support = next(row for row in survival_rows if row["network_object_id"] == "QN-SUPPORT-001")
    carrier = next(row for row in survival_rows if row["network_object_id"] == "QN-CARRIER-001")
    return [
        {
            "control_id": "QN002_WC_01",
            "wrong_control": "charged control envelope outranks protected carrier as link carrier",
            "expected": False,
            "actual": top["network_object_id"] == "QN-ENVELOPE-001",
            "pass": top["network_object_id"] != "QN-ENVELOPE-001",
        },
        {
            "control_id": "QN002_WC_02",
            "wrong_control": "material support becomes primary link carrier",
            "expected": False,
            "actual": top["network_object_id"] == "QN-SUPPORT-001",
            "pass": top["network_object_id"] != "QN-SUPPORT-001",
        },
        {
            "control_id": "QN002_WC_03",
            "wrong_control": "carrier link has zero survival score",
            "expected": False,
            "actual": fnum(carrier["segment_survival_score"]) == 0,
            "pass": fnum(carrier["segment_survival_score"]) > 0,
        },
        {
            "control_id": "QN002_WC_04",
            "wrong_control": "envelope score exceeds carrier score",
            "expected": False,
            "actual": fnum(envelope["link_viability_score"]) > fnum(carrier["link_viability_score"]),
            "pass": fnum(envelope["link_viability_score"]) <= fnum(carrier["link_viability_score"]),
        },
        {
            "control_id": "QN002_WC_05",
            "wrong_control": "support object receives route-backed link score",
            "expected": False,
            "actual": fnum(support["link_viability_score"]) > 0,
            "pass": fnum(support["link_viability_score"]) == 0,
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    survival_rows: list[dict[str, object]],
    viability_rows: list[dict[str, object]],
    formula_rows: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN002 - Private Link Survival And Contact Suppression Law

## Result

```text
{summary["result_class"]}
```

QN002 builds the first SAM-native quantum-network link survival score.

## Main Readout

```text
scored_link_rows = {summary["scored_link_rows"]}
selected_link_object = {summary["selected_link_object"]}
selected_link_route = {summary["selected_link_route"]}
selected_link_viability_score = {summary["selected_link_viability_score"]}
selected_segment_survival_score = {summary["selected_segment_survival_score"]}
selected_route_capacity_prior = {summary["selected_route_capacity_prior"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
external_quantum_network_data_used = {summary["external_quantum_network_data_used"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Formula

{markdown_table(formula_rows, ["term", "formula", "source"])}

## Link Viability Ranking

{markdown_table(viability_rows, ["rank", "network_object_id", "selected_route", "segment_survival_score", "route_capacity_prior", "link_viability_score", "selected_top_link"])}

## Survival Table

{markdown_table(survival_rows, ["network_object_id", "object_class", "selected_route", "route_present_in_qp013_qp014", "segment_survival_score", "link_viability_score", "selector_class"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

The protected network link is not chosen by name. It wins because the neutral
unresolved carrier combines:

```text
high route capacity prior
positive pre-resolution letter window
positive active A-contact suppression window
large no-write headroom to A_SHARE
ledger safety guard = 1
```

The charged lane remains a control envelope, and the boundary route remains a
stress sensor. Both are useful, but neither outranks the protected carrier as
the main unresolved network link.

## Outputs

```text
artifacts/qn002/qn002_preflight.md
artifacts/qn002/qn002_input_manifest.csv
artifacts/qn002/sam_link_survival_table.csv
artifacts/qn002/sam_link_viability_score.csv
artifacts/qn002/sam_link_score_formula.csv
artifacts/qn002/qn002_checks.csv
artifacts/qn002/qn002_wrong_controls.csv
artifacts/qn002/qn002_summary.json
artifacts/qn002/qn002_next_frontier.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = [
        QN001_SUMMARY,
        QN001_OBJECTS,
        QN001_SAFETY,
        QP013_CONTACT,
        QP013_WINDOWS,
        QP014_PRIORS,
        QP014_SURFACE,
    ]
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])
    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN002 inputs: {missing}")

    qn_summary = read_json(QN001_SUMMARY)
    objects = read_csv(QN001_OBJECTS)
    contact_rows = read_csv(QP013_CONTACT)
    window_rows = read_csv(QP013_WINDOWS)
    prior_rows = read_csv(QP014_PRIORS)

    formula_rows = build_formula_rows()
    survival_rows = build_survival_rows(objects, window_rows, prior_rows, contact_counts(contact_rows))
    viability_rows = build_viability_rows(survival_rows)
    checks = build_checks(survival_rows, viability_rows)
    wrong_controls = build_wrong_controls(survival_rows, viability_rows)

    write_csv(
        SURVIVAL_OUT,
        survival_rows,
        [
            "network_object_id",
            "object_class",
            "selected_route",
            "selected_family",
            "route_present_in_qp013_qp014",
            "total_contact_rows",
            "valid_letter_rows",
            "active_suppression_rows",
            "too_late_rows",
            "valid_letter_fraction",
            "active_suppression_fraction",
            "headroom_factor",
            "max_required_suppression_to_restore_A_SIDE",
            "native_theoretical_ceiling_before_A_SHARE",
            "suppression_margin_to_A_SIDE",
            "route_capacity_prior",
            "ledger_safety_guard",
            "segment_survival_score",
            "link_viability_score",
            "selected_top_link",
            "selector_class",
            "SAM_reading",
        ],
    )
    write_csv(
        VIABILITY_OUT,
        viability_rows,
        [
            "rank",
            "network_object_id",
            "object_class",
            "selected_route",
            "selected_family",
            "segment_survival_score",
            "route_capacity_prior",
            "link_viability_score",
            "selected_top_link",
            "selector_class",
        ],
    )
    write_csv(FORMULA_OUT, formula_rows, ["term", "formula", "source", "role"])
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])

    top = viability_rows[0]
    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)

    summary = {
        "artifact": "QN002_PRIVATE_LINK_SURVIVAL_AND_CONTACT_SUPPRESSION_LAW",
        "result_class": "QN002_LINK_SURVIVAL_AND_CONTACT_SUPPRESSION_LAW_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_NETWORK_LINK_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": False,
        "free_parameters_introduced": 0,
        "qn001_result_class": qn_summary["result_class"],
        "network_object_rows": len(survival_rows),
        "scored_link_rows": len(viability_rows),
        "selected_link_object": top["network_object_id"],
        "selected_link_route": top["selected_route"],
        "selected_link_family": top["selected_family"],
        "selected_segment_survival_score": top["segment_survival_score"],
        "selected_route_capacity_prior": top["route_capacity_prior"],
        "selected_link_viability_score": top["link_viability_score"],
        "core_link_rule": "link_viability_score = valid_letter_fraction * active_suppression_fraction * headroom_factor * suppression_margin_to_A_SIDE * ledger_safety_guard * route_capacity_prior",
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "next_frontier": "QN003_PRIVATE_LEDGER_SAFE_RELAY_REPEATER_LAW",
    }
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, survival_rows, viability_rows, formula_rows, checks, wrong_controls)


if __name__ == "__main__":
    main()
