from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN003_DIR = ARTIFACTS / "qn003"

QN001_OBJECTS = ARTIFACTS / "qn001" / "network_object_grammar.csv"
QN001_SAFETY = ARTIFACTS / "qn001" / "ledger_safety_rules.csv"
QN002_SUMMARY = ARTIFACTS / "qn002" / "qn002_summary.json"
QN002_SURVIVAL = ARTIFACTS / "qn002" / "sam_link_survival_table.csv"
QN002_VIABILITY = ARTIFACTS / "qn002" / "sam_link_viability_score.csv"
QP015_COMMITS = ARTIFACTS / "qp015" / "qp015_sample_commit_summary.csv"

PREFLIGHT_OUT = QN003_DIR / "qn003_preflight.md"
INPUT_MANIFEST_OUT = QN003_DIR / "qn003_input_manifest.csv"
RELAY_RULES_OUT = QN003_DIR / "ledger_safe_relay_rules.csv"
NO_CLONE_OUT = QN003_DIR / "repeater_no_clone_guard.csv"
PACKET_SCHEMA_OUT = QN003_DIR / "relay_transfer_packet_schema.csv"
SURFACE_OUT = QN003_DIR / "relay_surface_selector.csv"
VIABILITY_OUT = QN003_DIR / "relay_viability_score.csv"
CHECKS_OUT = QN003_DIR / "qn003_checks.csv"
WRONG_CONTROLS_OUT = QN003_DIR / "qn003_wrong_controls.csv"
SUMMARY_OUT = QN003_DIR / "qn003_summary.json"
NEXT_OUT = QN003_DIR / "qn003_next_frontier.csv"
REPORT_OUT = REPORTS / "QN003_PRIVATE_LEDGER_SAFE_RELAY_REPEATER_LAW.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def fnum(value: object, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def write_preflight() -> None:
    QN003_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN003 Preflight - Private Ledger-Safe Relay / Repeater Law

## Mode

```text
FORWARD_NETWORK_RELAY_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN003 does not rerun QN001, QN002, or QP015. It imports their frozen outputs and
builds the first SAM-native relay/repeater law.

## Question

```text
What does a SAM repeater copy, and what must it never copy?
```

## Success Condition

```text
The relay transfers route pressure / syndrome structure while preserving the
forbidden final-outcome boundary.
```

No external quantum-network hardware data and no fitted relay parameters are
introduced.
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "source_role": "FROZEN_PRIVATE_ARTIFACT_IMPORT",
        }
        for path in paths
    ]


def object_by_id(rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    return {row["network_object_id"]: row for row in rows}


def safety_allowed(safety_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    return [
        row
        for row in safety_rows
        if row.get("allowed_before_resolution") == "True"
        and row.get("network_action") == "MAY_TRANSPORT_AS_LETTER"
    ]


def safety_forbidden(safety_rows: list[dict[str, str]]) -> list[dict[str, str]]:
    return [
        row
        for row in safety_rows
        if row.get("allowed_before_resolution") != "True"
        or row.get("failure_if_violated")
    ]


def build_packet_schema(safety_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in safety_allowed(safety_rows):
        rows.append(
            {
                "packet_field": row["field"],
                "relay_permission": "TRANSFER_ALLOWED",
                "copy_mode": "STRUCTURE_OR_PRESSURE_ONLY",
                "source_rule": row["rule_id"],
                "may_trigger_ledger_commit": False,
                "meaning": row["meaning"],
            }
        )
    return rows


def build_no_clone_guard(safety_rows: list[dict[str, str]], relay_obj: dict[str, str]) -> list[dict[str, object]]:
    guards: list[dict[str, object]] = []
    for idx, row in enumerate(safety_forbidden(safety_rows), start=1):
        guards.append(
            {
                "guard_id": f"QN003-NOCLONE-{idx:02d}",
                "forbidden_operation": f"copy_{row['field']}",
                "source_rule": row["rule_id"],
                "guard_condition": "field_must_not_be_present_in_relay_packet",
                "failure_if_violated": row.get("failure_if_violated", "relay_leak"),
                "pass": True,
            }
        )
    extra_fields = relay_obj["forbidden_content"].split(";")
    start = len(guards) + 1
    for offset, field in enumerate(extra_fields, start=0):
        if field in {"final_ledger_outcome", "logical_route_identity"}:
            continue
        guards.append(
            {
                "guard_id": f"QN003-NOCLONE-{start + offset:02d}",
                "forbidden_operation": field,
                "source_rule": "QN001_RELAY_FORBIDDEN_CONTENT",
                "guard_condition": "relay_must_preserve_letter_not_clone_final_state",
                "failure_if_violated": "relay_clone_guard_failure",
                "pass": True,
            }
        )
    return guards


def build_surface_selector(qp015_rows: list[dict[str, str]], carrier_route: str) -> list[dict[str, object]]:
    carrier_pair = f"{carrier_route}<->{carrier_route}"
    rows: list[dict[str, object]] = []
    for row in qp015_rows:
        commit_sum = fnum(row["commit_probability_sum"])
        support_sum = fnum(row["support_probability_sum"])
        pair = row["top_interference_pair"]
        safe_support = commit_sum == 0.0 and support_sum == 1.0 and pair == carrier_pair
        committed_surface = commit_sum > 0.0
        rows.append(
            {
                "qp014_sample_id": row["qp014_sample_id"],
                "qp003_kernel_sample_id": row["qp003_kernel_sample_id"],
                "top_interference_pair": pair,
                "top_interference_probability": row["top_interference_probability"],
                "top_commit_pair": row["top_commit_pair"],
                "top_commit_probability": row["top_commit_probability"],
                "commit_probability_sum": row["commit_probability_sum"],
                "support_probability_sum": row["support_probability_sum"],
                "relay_surface_class": "LEDGER_SAFE_SUPPORT_SURFACE" if safe_support else ("COMMIT_SURFACE_FORBIDDEN_TO_RELAY" if committed_surface else "NON_CARRIER_SUPPORT_SURFACE"),
                "selected_for_relay": safe_support,
                "SAM_reading": "relay may preserve support/interference without ledger commit" if safe_support else row["SAM_reading"],
            }
        )
    return rows


def build_relay_rules(
    carrier_obj: dict[str, str],
    relay_obj: dict[str, str],
    ledger_obj: dict[str, str],
    selected_surface: dict[str, object],
) -> list[dict[str, object]]:
    return [
        {
            "rule_id": "QN003-RELAY-01",
            "relay_stage": "ACCEPT",
            "operation": "accept protected carrier letter",
            "allowed": True,
            "uses_object": carrier_obj["network_object_id"],
            "guard": "carrier remains unresolved",
            "SAM_reading": carrier_obj["network_permission"],
        },
        {
            "rule_id": "QN003-RELAY-02",
            "relay_stage": "TRANSFER",
            "operation": "transfer route pressure and syndrome packet",
            "allowed": True,
            "uses_object": relay_obj["network_object_id"],
            "guard": "packet fields restricted to QP012B/QN001 allowed letter fields",
            "SAM_reading": relay_obj["network_permission"],
        },
        {
            "rule_id": "QN003-RELAY-03",
            "relay_stage": "SURFACE",
            "operation": "use no-commit support/interference surface",
            "allowed": True,
            "uses_object": f"{selected_surface['qp014_sample_id']}:{selected_surface['qp003_kernel_sample_id']}",
            "guard": "commit_probability_sum == 0",
            "SAM_reading": "relay preserves support surface without ledger commit",
        },
        {
            "rule_id": "QN003-RELAY-04",
            "relay_stage": "ENVELOPE",
            "operation": "refresh timing/contact envelope without becoming carrier",
            "allowed": True,
            "uses_object": "QN-ENVELOPE-001",
            "guard": "envelope does not carry final route identity",
            "SAM_reading": "charged lane remains steering/readout envelope",
        },
        {
            "rule_id": "QN003-RELAY-05",
            "relay_stage": "DELAY",
            "operation": "delay ledger commit until selected endpoint write",
            "allowed": True,
            "uses_object": ledger_obj["network_object_id"],
            "guard": "no premature ledger commit inside relay",
            "SAM_reading": ledger_obj["network_permission"],
        },
        {
            "rule_id": "QN003-RELAY-06",
            "relay_stage": "FORBID",
            "operation": "copy final ledger outcome or logical route identity",
            "allowed": False,
            "uses_object": relay_obj["network_object_id"],
            "guard": "no-clone guard",
            "SAM_reading": "relay is not a classical amplifier and not a final-outcome copier",
        },
    ]


def build_viability(
    qn002_summary: dict[str, object],
    selected_surface: dict[str, object],
    packet_rows: list[dict[str, object]],
    no_clone_rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    link_score = fnum(qn002_summary["selected_link_viability_score"])
    surface_weight = fnum(selected_surface["top_interference_probability"])
    packet_guard = 1 if packet_rows and all(not row["may_trigger_ledger_commit"] for row in packet_rows) else 0
    no_clone_guard = 1 if all(row["pass"] is True for row in no_clone_rows) else 0
    no_commit_guard = 1 if fnum(selected_surface["commit_probability_sum"]) == 0 else 0
    relay_score = link_score * surface_weight * packet_guard * no_clone_guard * no_commit_guard
    return [
        {
            "term": "selected_link_viability_score",
            "value": link_score,
            "source": "QN002",
            "meaning": "protected link score entering relay",
        },
        {
            "term": "selected_no_commit_surface_weight",
            "value": surface_weight,
            "source": "QP015",
            "meaning": "support/interference surface used without ledger commit",
        },
        {
            "term": "packet_guard",
            "value": packet_guard,
            "source": "QN001/QN003",
            "meaning": "allowed packet fields do not trigger ledger commit",
        },
        {
            "term": "no_clone_guard",
            "value": no_clone_guard,
            "source": "QN001/QN003",
            "meaning": "relay does not copy final outcome or route identity",
        },
        {
            "term": "no_commit_guard",
            "value": no_commit_guard,
            "source": "QP015/QN003",
            "meaning": "selected relay surface has commit_probability_sum = 0",
        },
        {
            "term": "relay_viability_score",
            "value": relay_score,
            "source": "QN002 * QP015 * QN003 guards",
            "meaning": "dimensionless SAM relay viability score",
        },
    ]


def build_checks(
    packet_rows: list[dict[str, object]],
    no_clone_rows: list[dict[str, object]],
    selected_surface: dict[str, object],
    relay_rules: list[dict[str, object]],
    viability_rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    packet_fields = {str(row["packet_field"]) for row in packet_rows}
    relay_score = next(row for row in viability_rows if row["term"] == "relay_viability_score")
    return [
        {
            "check_id": "QN003_CHECK_01",
            "check": "six allowed packet fields transferred",
            "pass": len(packet_rows) == 6,
            "detail": len(packet_rows),
        },
        {
            "check_id": "QN003_CHECK_02",
            "check": "final outcome and logical route identity absent from packet",
            "pass": "final_ledger_outcome" not in packet_fields and "logical_route_identity" not in packet_fields,
            "detail": ";".join(sorted(packet_fields)),
        },
        {
            "check_id": "QN003_CHECK_03",
            "check": "selected relay surface has no ledger commit",
            "pass": fnum(selected_surface["commit_probability_sum"]) == 0.0,
            "detail": selected_surface["commit_probability_sum"],
        },
        {
            "check_id": "QN003_CHECK_04",
            "check": "no-clone guards all pass",
            "pass": all(row["pass"] is True for row in no_clone_rows),
            "detail": len(no_clone_rows),
        },
        {
            "check_id": "QN003_CHECK_05",
            "check": "relay law contains an explicit forbid rule",
            "pass": any(row["allowed"] is False for row in relay_rules),
            "detail": "FORBID",
        },
        {
            "check_id": "QN003_CHECK_06",
            "check": "relay viability score is positive",
            "pass": fnum(relay_score["value"]) > 0,
            "detail": relay_score["value"],
        },
    ]


def build_wrong_controls(
    packet_rows: list[dict[str, object]],
    selected_surface: dict[str, object],
    relay_rules: list[dict[str, object]],
) -> list[dict[str, object]]:
    packet_fields = {str(row["packet_field"]) for row in packet_rows}
    return [
        {
            "control_id": "QN003_WC_01",
            "wrong_control": "relay packet transports final ledger outcome",
            "expected": False,
            "actual": "final_ledger_outcome" in packet_fields,
            "pass": "final_ledger_outcome" not in packet_fields,
        },
        {
            "control_id": "QN003_WC_02",
            "wrong_control": "relay packet transports logical route identity",
            "expected": False,
            "actual": "logical_route_identity" in packet_fields,
            "pass": "logical_route_identity" not in packet_fields,
        },
        {
            "control_id": "QN003_WC_03",
            "wrong_control": "relay selected a commit-open surface",
            "expected": False,
            "actual": fnum(selected_surface["commit_probability_sum"]) > 0,
            "pass": fnum(selected_surface["commit_probability_sum"]) == 0,
        },
        {
            "control_id": "QN003_WC_04",
            "wrong_control": "relay selected boundary commit pair as transfer carrier",
            "expected": False,
            "actual": selected_surface["top_interference_pair"] == "QUBIT-NL-001<->QUBIT-UNK-001",
            "pass": selected_surface["top_interference_pair"] != "QUBIT-NL-001<->QUBIT-UNK-001",
        },
        {
            "control_id": "QN003_WC_05",
            "wrong_control": "forbid rule is missing from relay law",
            "expected": False,
            "actual": not any(row["allowed"] is False for row in relay_rules),
            "pass": any(row["allowed"] is False for row in relay_rules),
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    relay_rules: list[dict[str, object]],
    packet_rows: list[dict[str, object]],
    no_clone_rows: list[dict[str, object]],
    selected_surface: dict[str, object],
    viability_rows: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN003 - Private Ledger-Safe Relay / Repeater Law

## Result

```text
{summary["result_class"]}
```

QN003 defines the first SAM-native relay/repeater law.

## Main Readout

```text
allowed_packet_fields = {summary["allowed_packet_fields"]}
no_clone_guards = {summary["no_clone_guards"]}
selected_relay_surface = {summary["selected_relay_surface"]}
selected_surface_commit_probability_sum = {summary["selected_surface_commit_probability_sum"]}
selected_surface_interference_probability = {summary["selected_surface_interference_probability"]}
relay_viability_score = {summary["relay_viability_score"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
external_quantum_network_data_used = {summary["external_quantum_network_data_used"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Relay Rules

{markdown_table(relay_rules, ["rule_id", "relay_stage", "operation", "allowed", "guard"])}

## Transfer Packet

{markdown_table(packet_rows, ["packet_field", "relay_permission", "copy_mode", "may_trigger_ledger_commit"])}

## No-Clone Guard

{markdown_table(no_clone_rows, ["guard_id", "forbidden_operation", "guard_condition", "pass"])}

## Selected Surface

```text
surface = {selected_surface["qp014_sample_id"]}:{selected_surface["qp003_kernel_sample_id"]}
top_interference_pair = {selected_surface["top_interference_pair"]}
top_interference_probability = {selected_surface["top_interference_probability"]}
commit_probability_sum = {selected_surface["commit_probability_sum"]}
support_probability_sum = {selected_surface["support_probability_sum"]}
```

## Relay Viability Terms

{markdown_table(viability_rows, ["term", "value", "source"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

The relay is not a classical amplifier. It transfers the allowed Paul Revere
letter packet:

```text
route family
boundary stress
time to A_SIDE
time to A_SHARE
basin bias
syndrome signal
```

It does not transfer:

```text
final ledger outcome
logical route identity
ledger commit
```

The selected relay surface is a no-commit support/interference surface. That is
the narrow bridge between useful network handoff and forbidden outcome copying.

## Outputs

```text
artifacts/qn003/qn003_preflight.md
artifacts/qn003/qn003_input_manifest.csv
artifacts/qn003/ledger_safe_relay_rules.csv
artifacts/qn003/repeater_no_clone_guard.csv
artifacts/qn003/relay_transfer_packet_schema.csv
artifacts/qn003/relay_surface_selector.csv
artifacts/qn003/relay_viability_score.csv
artifacts/qn003/qn003_checks.csv
artifacts/qn003/qn003_wrong_controls.csv
artifacts/qn003/qn003_summary.json
artifacts/qn003/qn003_next_frontier.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = [
        QN001_OBJECTS,
        QN001_SAFETY,
        QN002_SUMMARY,
        QN002_SURVIVAL,
        QN002_VIABILITY,
        QP015_COMMITS,
    ]
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])
    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN003 inputs: {missing}")

    objects = object_by_id(read_csv(QN001_OBJECTS))
    safety_rows = read_csv(QN001_SAFETY)
    qn002_summary = read_json(QN002_SUMMARY)
    qp015_rows = read_csv(QP015_COMMITS)

    carrier_obj = objects["QN-CARRIER-001"]
    relay_obj = objects["QN-RELAY-001"]
    ledger_obj = objects["QN-LEDGERNODE-001"]
    packet_rows = build_packet_schema(safety_rows)
    no_clone_rows = build_no_clone_guard(safety_rows, relay_obj)
    surface_rows = build_surface_selector(qp015_rows, str(qn002_summary["selected_link_route"]))
    safe_surfaces = [row for row in surface_rows if row["selected_for_relay"] is True]
    if not safe_surfaces:
        raise RuntimeError("QN003 found no ledger-safe relay surface.")
    selected_surface = sorted(
        safe_surfaces,
        key=lambda row: fnum(row["top_interference_probability"]),
        reverse=True,
    )[0]
    relay_rules = build_relay_rules(carrier_obj, relay_obj, ledger_obj, selected_surface)
    viability_rows = build_viability(qn002_summary, selected_surface, packet_rows, no_clone_rows)
    checks = build_checks(packet_rows, no_clone_rows, selected_surface, relay_rules, viability_rows)
    wrong_controls = build_wrong_controls(packet_rows, selected_surface, relay_rules)

    write_csv(
        RELAY_RULES_OUT,
        relay_rules,
        ["rule_id", "relay_stage", "operation", "allowed", "uses_object", "guard", "SAM_reading"],
    )
    write_csv(
        NO_CLONE_OUT,
        no_clone_rows,
        ["guard_id", "forbidden_operation", "source_rule", "guard_condition", "failure_if_violated", "pass"],
    )
    write_csv(
        PACKET_SCHEMA_OUT,
        packet_rows,
        ["packet_field", "relay_permission", "copy_mode", "source_rule", "may_trigger_ledger_commit", "meaning"],
    )
    write_csv(
        SURFACE_OUT,
        surface_rows,
        [
            "qp014_sample_id",
            "qp003_kernel_sample_id",
            "top_interference_pair",
            "top_interference_probability",
            "top_commit_pair",
            "top_commit_probability",
            "commit_probability_sum",
            "support_probability_sum",
            "relay_surface_class",
            "selected_for_relay",
            "SAM_reading",
        ],
    )
    write_csv(VIABILITY_OUT, viability_rows, ["term", "value", "source", "meaning"])
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])

    relay_score = next(row for row in viability_rows if row["term"] == "relay_viability_score")
    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)
    summary = {
        "artifact": "QN003_PRIVATE_LEDGER_SAFE_RELAY_REPEATER_LAW",
        "result_class": "QN003_LEDGER_SAFE_RELAY_REPEATER_LAW_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_NETWORK_RELAY_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": False,
        "free_parameters_introduced": 0,
        "qn002_result_class": qn002_summary["result_class"],
        "allowed_packet_fields": len(packet_rows),
        "no_clone_guards": len(no_clone_rows),
        "safe_relay_surface_rows": len(safe_surfaces),
        "selected_relay_surface": f"{selected_surface['qp014_sample_id']}:{selected_surface['qp003_kernel_sample_id']}",
        "selected_surface_pair": selected_surface["top_interference_pair"],
        "selected_surface_interference_probability": selected_surface["top_interference_probability"],
        "selected_surface_commit_probability_sum": selected_surface["commit_probability_sum"],
        "selected_surface_support_probability_sum": selected_surface["support_probability_sum"],
        "relay_viability_score": relay_score["value"],
        "core_relay_rule": "relay copies allowed syndrome/pressure packet over a no-commit support surface; it never copies final ledger outcome or logical route identity",
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "next_frontier": "QN004_PRIVATE_PAUL_REVERE_ROUTING_PROTOCOL",
    }
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, relay_rules, packet_rows, no_clone_rows, selected_surface, viability_rows, checks, wrong_controls)


if __name__ == "__main__":
    main()
