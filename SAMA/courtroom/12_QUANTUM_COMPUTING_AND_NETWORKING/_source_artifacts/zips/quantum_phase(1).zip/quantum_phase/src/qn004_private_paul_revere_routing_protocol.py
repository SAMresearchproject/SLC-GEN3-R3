from __future__ import annotations

import csv
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN004_DIR = ARTIFACTS / "qn004"

QN001_SAFETY = ARTIFACTS / "qn001" / "ledger_safety_rules.csv"
QN002_SURVIVAL = ARTIFACTS / "qn002" / "sam_link_survival_table.csv"
QN002_VIABILITY = ARTIFACTS / "qn002" / "sam_link_viability_score.csv"
QN003_SUMMARY = ARTIFACTS / "qn003" / "qn003_summary.json"
QN003_PACKET = ARTIFACTS / "qn003" / "relay_transfer_packet_schema.csv"
QN003_RELAY_RULES = ARTIFACTS / "qn003" / "ledger_safe_relay_rules.csv"
QN003_RELAY_VIABILITY = ARTIFACTS / "qn003" / "relay_viability_score.csv"
QP013_CONTACT = ARTIFACTS / "qp013" / "qp013_contact_suppression_table.csv"

PREFLIGHT_OUT = QN004_DIR / "qn004_preflight.md"
INPUT_MANIFEST_OUT = QN004_DIR / "qn004_input_manifest.csv"
PROTOCOL_OUT = QN004_DIR / "paul_revere_routing_protocol.csv"
DECISION_OUT = QN004_DIR / "route_pressure_decision_table.csv"
SAMPLE_OUT = QN004_DIR / "sample_route_selection_summary.csv"
FORMULA_OUT = QN004_DIR / "routing_score_formula.csv"
CHECKS_OUT = QN004_DIR / "qn004_checks.csv"
WRONG_CONTROLS_OUT = QN004_DIR / "qn004_wrong_controls.csv"
SUMMARY_OUT = QN004_DIR / "qn004_summary.json"
NEXT_OUT = QN004_DIR / "qn004_next_frontier.csv"
REPORT_OUT = REPORTS / "QN004_PRIVATE_PAUL_REVERE_ROUTING_PROTOCOL.md"


FORBIDDEN_FIELDS = {"final_ledger_outcome", "logical_route_identity"}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def fnum(value: object, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def write_preflight() -> None:
    QN004_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN004 Preflight - Private Paul Revere Routing Protocol

## Mode

```text
FORWARD_NETWORK_ROUTING_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN004 does not rerun QN001-QN003 or QP013. It imports their frozen outputs and
builds the first SAM-native Paul Revere routing protocol.

## Question

```text
Can boundary letters choose a better route before final ledger resolution
without predicting the final result?
```

## Success Condition

```text
The protocol uses basin stress and timing pressure only. It does not use final
ledger outcome or logical route identity.
```

No external quantum-network hardware data and no fitted routing parameters are
introduced.
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "source_role": "FROZEN_PRIVATE_ARTIFACT_IMPORT",
        }
        for path in paths
    ]


def route_scores_from_qn002(rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    return {row["selected_route"]: row for row in rows if row.get("selected_route")}


def relay_score(rows: list[dict[str, str]]) -> float:
    for row in rows:
        if row["term"] == "relay_viability_score":
            return fnum(row["value"])
    raise KeyError("relay_viability_score missing")


def build_formula_rows() -> list[dict[str, object]]:
    return [
        {
            "term": "valid_letter_gate",
            "formula": "1 if valid_pre_resolution_letter else 0",
            "source": "QP013",
            "role": "blocks routing when the no-collapse letter window is closed",
        },
        {
            "term": "timing_headroom",
            "formula": "pre_resolution_headroom_to_A_SHARE",
            "source": "QP013",
            "role": "allowed time-to-A_SHARE pressure field",
        },
        {
            "term": "boundary_pressure",
            "formula": "1 - pre_resolution_headroom_to_A_SHARE",
            "source": "QP013",
            "role": "allowed basin/timing pressure field used for action class",
        },
        {
            "term": "route_link_viability",
            "formula": "QN002 link_viability_score for route",
            "source": "QN002",
            "role": "route viability from no-write survival and route capacity",
        },
        {
            "term": "relay_viability",
            "formula": "QN003 relay_viability_score",
            "source": "QN003",
            "role": "ledger-safe relay viability over no-commit surface",
        },
        {
            "term": "routing_score",
            "formula": "valid_letter_gate * route_link_viability * relay_viability * timing_headroom",
            "source": "QP013 + QN002 + QN003",
            "role": "dimensionless route decision score using only pre-resolution fields",
        },
    ]


def build_protocol_rows(packet_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    packet_fields = ";".join(row["packet_field"] for row in packet_rows)
    return [
        {
            "step": 1,
            "protocol_stage": "READ_ALLOWED_LETTER",
            "operation": "read Paul Revere packet fields",
            "uses_fields": packet_fields,
            "forbidden_fields": "final_ledger_outcome;logical_route_identity",
            "ledger_commit_allowed": False,
            "SAM_reading": "routing begins from allowed syndrome/pressure fields only",
        },
        {
            "step": 2,
            "protocol_stage": "FILTER_WINDOW",
            "operation": "require valid_pre_resolution_letter",
            "uses_fields": "time_to_A_SHARE;syndrome_signal",
            "forbidden_fields": "final_ledger_outcome;logical_route_identity",
            "ledger_commit_allowed": False,
            "SAM_reading": "closed windows refuse routing rather than guessing the outcome",
        },
        {
            "step": 3,
            "protocol_stage": "SCORE_ROUTE_PRESSURE",
            "operation": "score candidate routes by timing headroom, link viability, and relay viability",
            "uses_fields": "route_family;boundary_stress;time_to_A_SHARE;basin_bias;syndrome_signal",
            "forbidden_fields": "final_ledger_outcome;logical_route_identity",
            "ledger_commit_allowed": False,
            "SAM_reading": "routing score uses pressure and survival, not route identity after resolution",
        },
        {
            "step": 4,
            "protocol_stage": "SELECT_NEXT_HOP",
            "operation": "choose highest open routing score",
            "uses_fields": "routing_score",
            "forbidden_fields": "final_ledger_outcome;logical_route_identity",
            "ledger_commit_allowed": False,
            "SAM_reading": "route choice is a pre-resolution handoff decision",
        },
        {
            "step": 5,
            "protocol_stage": "RELAY_PACKET",
            "operation": "send allowed packet over QN003 no-commit relay surface",
            "uses_fields": packet_fields,
            "forbidden_fields": "final_ledger_outcome;logical_route_identity;ledger_commit",
            "ledger_commit_allowed": False,
            "SAM_reading": "relay moves the letter, not the final answer",
        },
    ]


def action_for(row: dict[str, str]) -> str:
    if row["valid_pre_resolution_letter"] != "True":
        return "WINDOW_CLOSED_DO_NOT_ROUTE"
    if row["control_class"] == "ACTIVE_A_CONTACT_SUPPRESSION_WINDOW":
        return "ACTIVE_ROUTE_AND_SUPPRESS"
    return "PASSIVE_MONITOR_AND_PRESERVE"


def build_decision_rows(
    contact_rows: list[dict[str, str]],
    link_scores: dict[str, dict[str, str]],
    relay_viability: float,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in contact_rows:
        route = row["qubit_id"]
        link = link_scores.get(route)
        route_link_viability = fnum(link["link_viability_score"]) if link else 0.0
        valid_gate = 1 if row["valid_pre_resolution_letter"] == "True" else 0
        timing_headroom = fnum(row["pre_resolution_headroom_to_A_SHARE"])
        boundary_pressure = max(0.0, 1.0 - timing_headroom)
        routing_score = valid_gate * route_link_viability * relay_viability * timing_headroom
        rows.append(
            {
                "sample_id": row["sample_id"],
                "candidate_route": route,
                "route_family": row["exposure_family"],
                "boundary_stress": row["letter_strength_class"],
                "basin_bias": row["basin_bias"],
                "time_to_A_SHARE_ticks": row["ticks_until_A_SHARE"],
                "valid_pre_resolution_letter": row["valid_pre_resolution_letter"],
                "control_class": row["control_class"],
                "recommended_control_surface": row["recommended_control_surface"],
                "timing_headroom": timing_headroom,
                "boundary_pressure": boundary_pressure,
                "route_link_viability": route_link_viability,
                "relay_viability": relay_viability,
                "routing_score": routing_score,
                "routing_action": action_for(row),
                "route_present_in_qn002": link is not None,
                "uses_forbidden_field": False,
                "selected_for_sample": False,
                "SAM_reading": "candidate route scored from pre-resolution letter fields",
            }
        )

    by_sample: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        by_sample[str(row["sample_id"])].append(row)
    for sample_rows in by_sample.values():
        eligible = [row for row in sample_rows if fnum(row["routing_score"]) > 0]
        if not eligible:
            continue
        selected = sorted(eligible, key=lambda row: fnum(row["routing_score"]), reverse=True)[0]
        selected["selected_for_sample"] = True
        selected["SAM_reading"] = "selected next hop from allowed pressure/timing fields"
    return rows


def build_sample_summary(decision_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    by_sample: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in decision_rows:
        by_sample[str(row["sample_id"])].append(row)
    summary: list[dict[str, object]] = []
    for sample_id, rows in by_sample.items():
        selected = [row for row in rows if row["selected_for_sample"] is True]
        if selected:
            chosen = selected[0]
            summary.append(
                {
                    "sample_id": sample_id,
                    "route_decision": "ROUTE_SELECTED",
                    "selected_route": chosen["candidate_route"],
                    "selected_route_family": chosen["route_family"],
                    "selected_routing_score": chosen["routing_score"],
                    "routing_action": chosen["routing_action"],
                    "eligible_candidates": sum(fnum(row["routing_score"]) > 0 for row in rows),
                    "forbidden_fields_used": False,
                }
            )
        else:
            summary.append(
                {
                    "sample_id": sample_id,
                    "route_decision": "NO_ROUTE_WINDOW_CLOSED",
                    "selected_route": "",
                    "selected_route_family": "",
                    "selected_routing_score": 0,
                    "routing_action": "WINDOW_CLOSED_DO_NOT_ROUTE",
                    "eligible_candidates": 0,
                    "forbidden_fields_used": False,
                }
            )
    order = {
        "ONE_T_SW": 1,
        "QUARTER_A_SIDE": 2,
        "HALF_A_SIDE": 3,
        "A_SIDE_BOUNDARY": 4,
        "MID_A_SIDE_TO_A_SHARE": 5,
        "A_SHARE_BOUNDARY": 6,
        "WRITE_MIDPOINT": 7,
    }
    return sorted(summary, key=lambda row: order.get(str(row["sample_id"]), 999))


def build_checks(
    protocol_rows: list[dict[str, object]],
    decision_rows: list[dict[str, object]],
    sample_rows: list[dict[str, object]],
    packet_rows: list[dict[str, str]],
) -> list[dict[str, object]]:
    packet_fields = {row["packet_field"] for row in packet_rows}
    forbidden_in_packet = bool(packet_fields & FORBIDDEN_FIELDS)
    selected = [row for row in sample_rows if row["route_decision"] == "ROUTE_SELECTED"]
    closed = [row for row in sample_rows if row["route_decision"] == "NO_ROUTE_WINDOW_CLOSED"]
    selected_routes = {row["selected_route"] for row in selected}
    protocol_forbidden = any(
        any(field in str(row.get("uses_fields", "")) for field in FORBIDDEN_FIELDS)
        for row in protocol_rows
    )
    decision_forbidden = any(row["uses_forbidden_field"] is True for row in decision_rows)
    return [
        {
            "check_id": "QN004_CHECK_01",
            "check": "packet fields exclude final outcome and logical route identity",
            "pass": not forbidden_in_packet,
            "detail": ";".join(sorted(packet_fields)),
        },
        {
            "check_id": "QN004_CHECK_02",
            "check": "protocol steps do not use forbidden fields",
            "pass": not protocol_forbidden,
            "detail": protocol_forbidden,
        },
        {
            "check_id": "QN004_CHECK_03",
            "check": "decision rows do not use forbidden fields",
            "pass": not decision_forbidden,
            "detail": decision_forbidden,
        },
        {
            "check_id": "QN004_CHECK_04",
            "check": "open samples select protected carrier route",
            "pass": selected_routes == {"QUBIT-NL-001"},
            "detail": ";".join(sorted(selected_routes)),
        },
        {
            "check_id": "QN004_CHECK_05",
            "check": "closed samples refuse routing",
            "pass": len(closed) == 2,
            "detail": len(closed),
        },
        {
            "check_id": "QN004_CHECK_06",
            "check": "at least five pre-resolution route choices are made",
            "pass": len(selected) >= 5,
            "detail": len(selected),
        },
    ]


def build_wrong_controls(protocol_rows: list[dict[str, object]], sample_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    selected = [row for row in sample_rows if row["route_decision"] == "ROUTE_SELECTED"]
    closed_selected = any(row["sample_id"] in {"A_SHARE_BOUNDARY", "WRITE_MIDPOINT"} for row in selected)
    charged_selected = any(row["selected_route"] == "QUBIT-CL-001" for row in selected)
    boundary_selected = any(row["selected_route"] == "QUBIT-UNK-001" for row in selected)
    forbidden_used = any(
        "final_ledger_outcome" in str(row.get("uses_fields", ""))
        or "logical_route_identity" in str(row.get("uses_fields", ""))
        for row in protocol_rows
    )
    return [
        {
            "control_id": "QN004_WC_01",
            "wrong_control": "routing uses final outcome or logical route identity",
            "expected": False,
            "actual": forbidden_used,
            "pass": not forbidden_used,
        },
        {
            "control_id": "QN004_WC_02",
            "wrong_control": "closed A_SHARE/WRITE sample gets routed",
            "expected": False,
            "actual": closed_selected,
            "pass": not closed_selected,
        },
        {
            "control_id": "QN004_WC_03",
            "wrong_control": "charged envelope selected as main route",
            "expected": False,
            "actual": charged_selected,
            "pass": not charged_selected,
        },
        {
            "control_id": "QN004_WC_04",
            "wrong_control": "boundary sensor selected as main route",
            "expected": False,
            "actual": boundary_selected,
            "pass": not boundary_selected,
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    protocol_rows: list[dict[str, object]],
    sample_rows: list[dict[str, object]],
    formula_rows: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN004 - Private Paul Revere Routing Protocol

## Result

```text
{summary["result_class"]}
```

QN004 builds the first SAM-native Paul Revere routing protocol.

## Main Readout

```text
protocol_steps = {summary["protocol_steps"]}
decision_rows = {summary["decision_rows"]}
route_selected_samples = {summary["route_selected_samples"]}
closed_window_samples = {summary["closed_window_samples"]}
selected_route = {summary["selected_route"]}
top_selected_routing_score = {summary["top_selected_routing_score"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
external_quantum_network_data_used = {summary["external_quantum_network_data_used"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Formula

{markdown_table(formula_rows, ["term", "formula", "source"])}

## Protocol

{markdown_table(protocol_rows, ["step", "protocol_stage", "operation", "uses_fields", "ledger_commit_allowed"])}

## Sample Route Selection

{markdown_table(sample_rows, ["sample_id", "route_decision", "selected_route", "selected_routing_score", "routing_action"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

QN004 turns the Paul Revere letter into a routing protocol:

```text
read allowed pressure/timing fields
refuse closed windows
score open routes by link viability, relay viability, and time-to-A_SHARE headroom
select the protected neutral unresolved carrier as next hop
never use final ledger outcome or logical route identity
```

This is routing before resolution: the warning packet moves while the final
ledger result remains sealed.

## Outputs

```text
artifacts/qn004/qn004_preflight.md
artifacts/qn004/qn004_input_manifest.csv
artifacts/qn004/paul_revere_routing_protocol.csv
artifacts/qn004/route_pressure_decision_table.csv
artifacts/qn004/sample_route_selection_summary.csv
artifacts/qn004/routing_score_formula.csv
artifacts/qn004/qn004_checks.csv
artifacts/qn004/qn004_wrong_controls.csv
artifacts/qn004/qn004_summary.json
artifacts/qn004/qn004_next_frontier.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = [
        QN001_SAFETY,
        QN002_SURVIVAL,
        QN002_VIABILITY,
        QN003_SUMMARY,
        QN003_PACKET,
        QN003_RELAY_RULES,
        QN003_RELAY_VIABILITY,
        QP013_CONTACT,
    ]
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])
    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN004 inputs: {missing}")

    packet_rows = read_csv(QN003_PACKET)
    qn003_summary = read_json(QN003_SUMMARY)
    relay_viability = relay_score(read_csv(QN003_RELAY_VIABILITY))
    link_scores = route_scores_from_qn002(read_csv(QN002_VIABILITY))
    contact_rows = read_csv(QP013_CONTACT)

    formula_rows = build_formula_rows()
    protocol_rows = build_protocol_rows(packet_rows)
    decision_rows = build_decision_rows(contact_rows, link_scores, relay_viability)
    sample_rows = build_sample_summary(decision_rows)
    checks = build_checks(protocol_rows, decision_rows, sample_rows, packet_rows)
    wrong_controls = build_wrong_controls(protocol_rows, sample_rows)

    write_csv(
        PROTOCOL_OUT,
        protocol_rows,
        ["step", "protocol_stage", "operation", "uses_fields", "forbidden_fields", "ledger_commit_allowed", "SAM_reading"],
    )
    write_csv(
        DECISION_OUT,
        decision_rows,
        [
            "sample_id",
            "candidate_route",
            "route_family",
            "boundary_stress",
            "basin_bias",
            "time_to_A_SHARE_ticks",
            "valid_pre_resolution_letter",
            "control_class",
            "recommended_control_surface",
            "timing_headroom",
            "boundary_pressure",
            "route_link_viability",
            "relay_viability",
            "routing_score",
            "routing_action",
            "route_present_in_qn002",
            "uses_forbidden_field",
            "selected_for_sample",
            "SAM_reading",
        ],
    )
    write_csv(
        SAMPLE_OUT,
        sample_rows,
        [
            "sample_id",
            "route_decision",
            "selected_route",
            "selected_route_family",
            "selected_routing_score",
            "routing_action",
            "eligible_candidates",
            "forbidden_fields_used",
        ],
    )
    write_csv(FORMULA_OUT, formula_rows, ["term", "formula", "source", "role"])
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])

    selected_samples = [row for row in sample_rows if row["route_decision"] == "ROUTE_SELECTED"]
    closed_samples = [row for row in sample_rows if row["route_decision"] == "NO_ROUTE_WINDOW_CLOSED"]
    top_score = max(fnum(row["selected_routing_score"]) for row in selected_samples)
    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)
    selected_routes = sorted({str(row["selected_route"]) for row in selected_samples})

    summary = {
        "artifact": "QN004_PRIVATE_PAUL_REVERE_ROUTING_PROTOCOL",
        "result_class": "QN004_PAUL_REVERE_ROUTING_PROTOCOL_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_NETWORK_ROUTING_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": False,
        "free_parameters_introduced": 0,
        "qn003_result_class": qn003_summary["result_class"],
        "protocol_steps": len(protocol_rows),
        "decision_rows": len(decision_rows),
        "sample_rows": len(sample_rows),
        "route_selected_samples": len(selected_samples),
        "closed_window_samples": len(closed_samples),
        "selected_route": ";".join(selected_routes),
        "top_selected_routing_score": top_score,
        "core_routing_rule": "routing_score = valid_letter_gate * route_link_viability * relay_viability * timing_headroom",
        "forbidden_fields_used": False,
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "next_frontier": "QN005_PRIVATE_NETWORK_BORN_SURFACE",
    }
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, protocol_rows, sample_rows, formula_rows, checks, wrong_controls)


if __name__ == "__main__":
    main()
