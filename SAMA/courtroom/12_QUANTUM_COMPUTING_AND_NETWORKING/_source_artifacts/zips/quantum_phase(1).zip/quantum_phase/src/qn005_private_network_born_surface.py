from __future__ import annotations

import csv
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN005_DIR = ARTIFACTS / "qn005"

QP014_WEIGHTS = ARTIFACTS / "qp014" / "qp014_route_weight_table.csv"
QP014_PROBABILITY = ARTIFACTS / "qp014" / "qp014_probability_surface_table.csv"
QN002_LINKS = ARTIFACTS / "qn002" / "sam_link_viability_score.csv"
QN003_RELAY = ARTIFACTS / "qn003" / "relay_viability_score.csv"
QN004_DECISIONS = ARTIFACTS / "qn004" / "route_pressure_decision_table.csv"
QN004_SUMMARY = ARTIFACTS / "qn004" / "qn004_summary.json"

PREFLIGHT_OUT = QN005_DIR / "qn005_preflight.md"
INPUT_MANIFEST_OUT = QN005_DIR / "qn005_input_manifest.csv"
ROUTE_SURFACE_OUT = QN005_DIR / "network_route_weight_surface.csv"
MULTI_NODE_OUT = QN005_DIR / "multi_node_probability_surface.csv"
SAMPLE_SUMMARY_OUT = QN005_DIR / "network_born_sample_summary.csv"
FORMULA_OUT = QN005_DIR / "network_born_formula.csv"
CHECKS_OUT = QN005_DIR / "qn005_checks.csv"
WRONG_CONTROLS_OUT = QN005_DIR / "qn005_wrong_controls.csv"
SUMMARY_OUT = QN005_DIR / "qn005_summary.json"
NEXT_OUT = QN005_DIR / "qn005_next_frontier.csv"
REPORT_OUT = REPORTS / "QN005_PRIVATE_NETWORK_BORN_SURFACE.md"

FORBIDDEN_FIELDS = {"final_ledger_outcome", "logical_route_identity", "ledger_commit_result"}
NETWORK_STAGES = ["ORIGIN", "LINK", "RELAY", "ROUTE"]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def fnum(value: object, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def is_true(value: object) -> bool:
    return str(value).strip().lower() == "true"


def write_preflight() -> None:
    QN005_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN005 Preflight - Private Network Born Surface

## Mode

```text
FORWARD_NETWORK_BORN_SURFACE_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN005 does not rerun QP014 or QN001-QN004. It imports frozen outputs and builds
the first SAM-native multi-node network probability surface.

## Question

```text
Can QP014 route weights become a multi-node network probability surface?
```

## Success Condition

```text
The probability surface remains normalized over unresolved route availability
and closes only when the pre-resolution route window closes.
```

No external quantum-network hardware data and no fitted probability parameters
are introduced.
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "source_role": "FROZEN_PRIVATE_ARTIFACT_IMPORT",
        }
        for path in paths
    ]


def relay_score(rows: list[dict[str, str]]) -> float:
    for row in rows:
        if row["term"] == "relay_viability_score":
            return fnum(row["value"])
    raise KeyError("relay_viability_score missing")


def build_formula_rows() -> list[dict[str, object]]:
    return [
        {
            "term": "open_window_gate",
            "formula": "1 if QP014 and QN004 both keep the pre-resolution window open else 0",
            "source": "QP014 + QN004",
            "role": "blocks probability transport after A_SHARE/window closure",
        },
        {
            "term": "route_born_probability",
            "formula": "QP014 latent_probability",
            "source": "QP014",
            "role": "native unresolved route probability before network transport",
        },
        {
            "term": "controlled_route_probability",
            "formula": "QP014 controlled_probability",
            "source": "QP014",
            "role": "write/contact-adjusted diagnostic surface carried beside the latent route surface",
        },
        {
            "term": "segment_survival",
            "formula": "QN002 segment_survival_score",
            "source": "QN002",
            "role": "no-write survival for the network segment",
        },
        {
            "term": "relay_viability",
            "formula": "QN003 relay_viability_score",
            "source": "QN003",
            "role": "ledger-safe relay viability over the no-commit surface",
        },
        {
            "term": "timing_headroom",
            "formula": "QN004 timing_headroom",
            "source": "QN004",
            "role": "Paul Revere route window pressure",
        },
        {
            "term": "network_route_weight",
            "formula": "open_window_gate * route_born_probability * segment_survival * relay_viability * timing_headroom",
            "source": "QP014 + QN002 + QN003 + QN004",
            "role": "unnormalized multi-node unresolved route weight",
        },
        {
            "term": "network_controlled_weight",
            "formula": "open_window_gate * controlled_route_probability * segment_survival * relay_viability * timing_headroom",
            "source": "QP014 + QN002 + QN003 + QN004",
            "role": "unnormalized controlled/write diagnostic route weight",
        },
        {
            "term": "network_probability",
            "formula": "network_route_weight / sum(network_route_weight over network-available unresolved routes)",
            "source": "QN005",
            "role": "normalized network Born surface",
        },
    ]


def link_map(rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    return {row["selected_route"]: row for row in rows}


def decision_map(rows: list[dict[str, str]]) -> dict[tuple[str, str], dict[str, str]]:
    return {(row["sample_id"], row["candidate_route"]): row for row in rows}


def build_route_surface(
    qp014_rows: list[dict[str, str]],
    links: dict[str, dict[str, str]],
    decisions: dict[tuple[str, str], dict[str, str]],
    relay_viability: float,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in qp014_rows:
        sample_id = row["sample_id"]
        route = row["qubit_id"]
        link = links.get(route)
        decision = decisions.get((sample_id, route))
        network_available = link is not None and decision is not None
        qp014_open = is_true(row["valid_pre_resolution_letter"])
        qn004_open = is_true(decision["valid_pre_resolution_letter"]) if decision else False
        open_window_gate = 1 if network_available and qp014_open and qn004_open else 0
        route_probability = fnum(row["latent_probability"])
        controlled_probability = fnum(row["controlled_probability"])
        segment_survival = fnum(link["segment_survival_score"]) if link else 0.0
        timing_headroom = fnum(decision["timing_headroom"]) if decision else 0.0
        network_weight = (
            open_window_gate
            * route_probability
            * segment_survival
            * relay_viability
            * timing_headroom
        )
        network_controlled_weight = (
            open_window_gate
            * controlled_probability
            * segment_survival
            * relay_viability
            * timing_headroom
        )
        rows.append(
            {
                "sample_id": sample_id,
                "qubit_id": route,
                "route": row["route"],
                "exposure_family": row["exposure_family"],
                "network_object_id": link["network_object_id"] if link else "",
                "network_object_class": link["object_class"] if link else "NOT_QN002_NETWORK_OBJECT",
                "network_route_available": network_available,
                "qp014_open_window": qp014_open,
                "qn004_open_window": qn004_open,
                "open_window_gate": open_window_gate,
                "route_born_probability": route_probability,
                "controlled_route_probability": controlled_probability,
                "segment_survival": segment_survival,
                "relay_viability": relay_viability if network_available else 0.0,
                "timing_headroom": timing_headroom,
                "network_route_weight": network_weight,
                "network_controlled_weight": network_controlled_weight,
                "network_probability": 0.0,
                "network_controlled_probability": 0.0,
                "forbidden_fields_used": False,
                "surface_class": "PENDING_NORMALIZATION",
                "SAM_reading": "QP014 route probability carried through network availability",
            }
        )

    by_sample: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        by_sample[str(row["sample_id"])].append(row)
    for sample_rows in by_sample.values():
        total = sum(fnum(row["network_route_weight"]) for row in sample_rows)
        controlled_total = sum(fnum(row["network_controlled_weight"]) for row in sample_rows)
        for row in sample_rows:
            if total > 0 and fnum(row["network_route_weight"]) > 0:
                row["network_probability"] = fnum(row["network_route_weight"]) / total
                row["surface_class"] = "NETWORK_BORN_SURFACE_OPEN"
                row["SAM_reading"] = "normalized unresolved network route probability"
            elif row["network_route_available"]:
                row["surface_class"] = "NETWORK_WINDOW_CLOSED"
                row["SAM_reading"] = "pre-resolution network surface is closed"
            else:
                row["surface_class"] = "SUPPORT_ROUTE_NOT_NETWORK_OBJECT"
                row["SAM_reading"] = "route remains outside the QN002 network object set"
            if controlled_total > 0 and fnum(row["network_controlled_weight"]) > 0:
                row["network_controlled_probability"] = fnum(row["network_controlled_weight"]) / controlled_total
    return rows


def stage_weight(row: dict[str, object], stage: str) -> float:
    if fnum(row["open_window_gate"]) == 0:
        return 0.0
    route_probability = fnum(row["route_born_probability"])
    segment_survival = fnum(row["segment_survival"])
    relay_viability = fnum(row["relay_viability"])
    timing_headroom = fnum(row["timing_headroom"])
    if stage == "ORIGIN":
        return route_probability
    if stage == "LINK":
        return route_probability * segment_survival
    if stage == "RELAY":
        return route_probability * segment_survival * relay_viability
    if stage == "ROUTE":
        return route_probability * segment_survival * relay_viability * timing_headroom
    raise ValueError(stage)


def build_multi_node_surface(route_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in route_rows:
        if row["network_route_available"] is not True:
            continue
        for stage in NETWORK_STAGES:
            rows.append(
                {
                    "sample_id": row["sample_id"],
                    "node_stage": stage,
                    "qubit_id": row["qubit_id"],
                    "network_object_id": row["network_object_id"],
                    "network_object_class": row["network_object_class"],
                    "stage_weight": stage_weight(row, stage),
                    "stage_probability": 0.0,
                    "window_state": "OPEN" if fnum(row["open_window_gate"]) == 1 else "CLOSED",
                    "forbidden_fields_used": False,
                }
            )

    by_sample_stage: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        by_sample_stage[(str(row["sample_id"]), str(row["node_stage"]))].append(row)
    for sample_stage_rows in by_sample_stage.values():
        total = sum(fnum(row["stage_weight"]) for row in sample_stage_rows)
        for row in sample_stage_rows:
            row["stage_probability"] = fnum(row["stage_weight"]) / total if total > 0 else 0.0
    return rows


def build_sample_summary(route_rows: list[dict[str, object]], stage_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    sample_ids = sorted({str(row["sample_id"]) for row in route_rows}, key=sample_order)
    rows: list[dict[str, object]] = []
    for sample_id in sample_ids:
        sample_route_rows = [row for row in route_rows if row["sample_id"] == sample_id]
        sample_stage_rows = [row for row in stage_rows if row["sample_id"] == sample_id]
        open_rows = [row for row in sample_route_rows if fnum(row["network_route_weight"]) > 0]
        probability_sum = sum(fnum(row["network_probability"]) for row in sample_route_rows)
        controlled_probability_sum = sum(fnum(row["network_controlled_probability"]) for row in sample_route_rows)
        route_probability_sum = sum(
            fnum(row["stage_probability"])
            for row in sample_stage_rows
            if row["node_stage"] == "ROUTE"
        )
        stage_normalization_failures = count_stage_failures(sample_stage_rows)
        if open_rows:
            top = sorted(open_rows, key=lambda row: fnum(row["network_probability"]), reverse=True)[0]
            surface_state = "NETWORK_BORN_SURFACE_OPEN"
            top_route = top["qubit_id"]
            top_probability = top["network_probability"]
            top_controlled = sorted(open_rows, key=lambda row: fnum(row["network_controlled_probability"]), reverse=True)[0]
            top_controlled_route = top_controlled["qubit_id"]
            top_controlled_probability = top_controlled["network_controlled_probability"]
        else:
            surface_state = "NETWORK_BORN_SURFACE_CLOSED"
            top_route = ""
            top_probability = 0.0
            top_controlled_route = ""
            top_controlled_probability = 0.0
        rows.append(
            {
                "sample_id": sample_id,
                "surface_state": surface_state,
                "network_available_routes": sum(row["network_route_available"] is True for row in sample_route_rows),
                "open_network_routes": len(open_rows),
                "network_probability_sum": probability_sum,
                "network_controlled_probability_sum": controlled_probability_sum,
                "route_stage_probability_sum": route_probability_sum,
                "stage_normalization_failures": stage_normalization_failures,
                "top_network_route": top_route,
                "top_network_probability": top_probability,
                "top_controlled_network_route": top_controlled_route,
                "top_controlled_network_probability": top_controlled_probability,
                "forbidden_fields_used": False,
            }
        )
    return rows


def sample_order(sample_id: str) -> int:
    order = {
        "ONE_T_SW": 1,
        "QUARTER_A_SIDE": 2,
        "HALF_A_SIDE": 3,
        "A_SIDE_BOUNDARY": 4,
        "MID_A_SIDE_TO_A_SHARE": 5,
        "A_SHARE_BOUNDARY": 6,
        "WRITE_MIDPOINT": 7,
    }
    return order.get(sample_id, 999)


def count_stage_failures(rows: list[dict[str, object]]) -> int:
    failures = 0
    by_stage: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        by_stage[str(row["node_stage"])].append(row)
    for stage_rows in by_stage.values():
        total_weight = sum(fnum(row["stage_weight"]) for row in stage_rows)
        total_prob = sum(fnum(row["stage_probability"]) for row in stage_rows)
        if total_weight > 0 and abs(total_prob - 1.0) > 1e-9:
            failures += 1
        if total_weight == 0 and abs(total_prob) > 1e-12:
            failures += 1
    return failures


def build_checks(
    route_rows: list[dict[str, object]],
    stage_rows: list[dict[str, object]],
    sample_rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    open_samples = [row for row in sample_rows if row["surface_state"] == "NETWORK_BORN_SURFACE_OPEN"]
    closed_samples = [row for row in sample_rows if row["surface_state"] == "NETWORK_BORN_SURFACE_CLOSED"]
    forbidden_used = any(row["forbidden_fields_used"] is True for row in route_rows + stage_rows + sample_rows)
    open_normalized = all(abs(fnum(row["network_probability_sum"]) - 1.0) <= 1e-9 for row in open_samples)
    closed_zero = all(abs(fnum(row["network_probability_sum"])) <= 1e-12 for row in closed_samples)
    route_stage_normalized = all(row["stage_normalization_failures"] == 0 for row in sample_rows)
    top_routes = {row["top_network_route"] for row in open_samples}
    network_candidates = sorted({row["qubit_id"] for row in route_rows if row["network_route_available"] is True})
    return [
        {
            "check_id": "QN005_CHECK_01",
            "check": "open pre-resolution samples normalize to one",
            "pass": open_normalized,
            "detail": ";".join(f'{row["sample_id"]}:{row["network_probability_sum"]}' for row in open_samples),
        },
        {
            "check_id": "QN005_CHECK_02",
            "check": "closed samples carry zero network probability",
            "pass": closed_zero and len(closed_samples) == 2,
            "detail": ";".join(f'{row["sample_id"]}:{row["network_probability_sum"]}' for row in closed_samples),
        },
        {
            "check_id": "QN005_CHECK_03",
            "check": "multi-node stage surfaces normalize or close cleanly",
            "pass": route_stage_normalized,
            "detail": sum(row["stage_normalization_failures"] for row in sample_rows),
        },
        {
            "check_id": "QN005_CHECK_04",
            "check": "protected neutral carrier remains top open route",
            "pass": top_routes == {"QUBIT-NL-001"},
            "detail": ";".join(sorted(top_routes)),
        },
        {
            "check_id": "QN005_CHECK_05",
            "check": "surface uses only QN002 network object routes",
            "pass": network_candidates == ["QUBIT-CL-001", "QUBIT-NL-001", "QUBIT-UNK-001"],
            "detail": ";".join(network_candidates),
        },
        {
            "check_id": "QN005_CHECK_06",
            "check": "forbidden final ledger fields are not used",
            "pass": not forbidden_used,
            "detail": forbidden_used,
        },
    ]


def build_wrong_controls(route_rows: list[dict[str, object]], sample_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    closed_nonzero = any(
        row["surface_state"] == "NETWORK_BORN_SURFACE_CLOSED" and fnum(row["network_probability_sum"]) > 0
        for row in sample_rows
    )
    support_route_nonzero = any(
        row["network_route_available"] is not True and fnum(row["network_route_weight"]) > 0
        for row in route_rows
    )
    charged_top = any(row["top_network_route"] == "QUBIT-CL-001" for row in sample_rows)
    boundary_top = any(row["top_network_route"] == "QUBIT-UNK-001" for row in sample_rows)
    forbidden_used = any(row["forbidden_fields_used"] is True for row in route_rows + sample_rows)
    return [
        {
            "control_id": "QN005_WC_01",
            "wrong_control": "closed A_SHARE/WRITE windows receive network probability",
            "expected": False,
            "actual": closed_nonzero,
            "pass": not closed_nonzero,
        },
        {
            "control_id": "QN005_WC_02",
            "wrong_control": "support-only non-network routes enter the network denominator",
            "expected": False,
            "actual": support_route_nonzero,
            "pass": not support_route_nonzero,
        },
        {
            "control_id": "QN005_WC_03",
            "wrong_control": "charged envelope becomes top network Born carrier",
            "expected": False,
            "actual": charged_top,
            "pass": not charged_top,
        },
        {
            "control_id": "QN005_WC_04",
            "wrong_control": "boundary sensor becomes top network Born carrier",
            "expected": False,
            "actual": boundary_top,
            "pass": not boundary_top,
        },
        {
            "control_id": "QN005_WC_05",
            "wrong_control": "network probability uses final ledger fields",
            "expected": False,
            "actual": forbidden_used,
            "pass": not forbidden_used,
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    formula_rows: list[dict[str, object]],
    sample_rows: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN005 - Private Network Born Surface

## Result

```text
{summary["result_class"]}
```

QN005 carries the QP014 Born-style route surface through the QN002-QN004
network chain.

## Main Readout

```text
network_route_rows = {summary["network_route_rows"]}
multi_node_rows = {summary["multi_node_rows"]}
open_surface_samples = {summary["open_surface_samples"]}
closed_surface_samples = {summary["closed_surface_samples"]}
network_available_routes = {summary["network_available_routes"]}
top_open_route = {summary["top_open_route"]}
top_open_probability = {summary["top_open_probability"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
external_quantum_network_data_used = {summary["external_quantum_network_data_used"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Formula

{markdown_table(formula_rows, ["term", "formula", "source"])}

## Sample Surface Summary

{markdown_table(sample_rows, ["sample_id", "surface_state", "open_network_routes", "network_probability_sum", "top_network_route", "top_network_probability"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

QN005 gives the network a SAM-native Born surface:

```text
start with QP014 latent unresolved route probability
restrict to QN002 network object routes
carry those routes through segment survival, relay viability, and QN004 timing headroom
normalize only over routes still open before A_SHARE
close the surface when the pre-resolution window closes
carry the QP014 controlled/write surface as a secondary diagnostic
```

The result is a route-probability surface for network motion before ledger
resolution.

## Outputs

```text
artifacts/qn005/qn005_preflight.md
artifacts/qn005/qn005_input_manifest.csv
artifacts/qn005/network_route_weight_surface.csv
artifacts/qn005/multi_node_probability_surface.csv
artifacts/qn005/network_born_sample_summary.csv
artifacts/qn005/network_born_formula.csv
artifacts/qn005/qn005_checks.csv
artifacts/qn005/qn005_wrong_controls.csv
artifacts/qn005/qn005_summary.json
artifacts/qn005/qn005_next_frontier.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = [
        QP014_WEIGHTS,
        QP014_PROBABILITY,
        QN002_LINKS,
        QN003_RELAY,
        QN004_DECISIONS,
        QN004_SUMMARY,
    ]
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])
    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN005 inputs: {missing}")

    qp014_rows = read_csv(QP014_WEIGHTS)
    qn004_summary = read_json(QN004_SUMMARY)
    links = link_map(read_csv(QN002_LINKS))
    decisions = decision_map(read_csv(QN004_DECISIONS))
    relay_viability = relay_score(read_csv(QN003_RELAY))

    formula_rows = build_formula_rows()
    route_rows = build_route_surface(qp014_rows, links, decisions, relay_viability)
    stage_rows = build_multi_node_surface(route_rows)
    sample_rows = build_sample_summary(route_rows, stage_rows)
    checks = build_checks(route_rows, stage_rows, sample_rows)
    wrong_controls = build_wrong_controls(route_rows, sample_rows)

    write_csv(
        ROUTE_SURFACE_OUT,
        route_rows,
        [
            "sample_id",
            "qubit_id",
            "route",
            "exposure_family",
            "network_object_id",
            "network_object_class",
            "network_route_available",
            "qp014_open_window",
            "qn004_open_window",
            "open_window_gate",
            "route_born_probability",
            "controlled_route_probability",
            "segment_survival",
            "relay_viability",
            "timing_headroom",
            "network_route_weight",
            "network_controlled_weight",
            "network_probability",
            "network_controlled_probability",
            "forbidden_fields_used",
            "surface_class",
            "SAM_reading",
        ],
    )
    write_csv(
        MULTI_NODE_OUT,
        stage_rows,
        [
            "sample_id",
            "node_stage",
            "qubit_id",
            "network_object_id",
            "network_object_class",
            "stage_weight",
            "stage_probability",
            "window_state",
            "forbidden_fields_used",
        ],
    )
    write_csv(
        SAMPLE_SUMMARY_OUT,
        sample_rows,
        [
            "sample_id",
            "surface_state",
            "network_available_routes",
            "open_network_routes",
            "network_probability_sum",
            "network_controlled_probability_sum",
            "route_stage_probability_sum",
            "stage_normalization_failures",
            "top_network_route",
            "top_network_probability",
            "top_controlled_network_route",
            "top_controlled_network_probability",
            "forbidden_fields_used",
        ],
    )
    write_csv(FORMULA_OUT, formula_rows, ["term", "formula", "source", "role"])
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])

    open_samples = [row for row in sample_rows if row["surface_state"] == "NETWORK_BORN_SURFACE_OPEN"]
    closed_samples = [row for row in sample_rows if row["surface_state"] == "NETWORK_BORN_SURFACE_CLOSED"]
    top_open = sorted(open_samples, key=lambda row: fnum(row["top_network_probability"]), reverse=True)[0]
    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)
    network_available_routes = sorted({row["qubit_id"] for row in route_rows if row["network_route_available"] is True})

    summary = {
        "artifact": "QN005_PRIVATE_NETWORK_BORN_SURFACE",
        "result_class": "QN005_NETWORK_BORN_SURFACE_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_NETWORK_BORN_SURFACE_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": False,
        "free_parameters_introduced": 0,
        "qn004_result_class": qn004_summary["result_class"],
        "network_route_rows": len(route_rows),
        "multi_node_rows": len(stage_rows),
        "open_surface_samples": len(open_samples),
        "closed_surface_samples": len(closed_samples),
        "network_available_routes": ";".join(network_available_routes),
        "top_open_route": top_open["top_network_route"],
        "top_open_probability": top_open["top_network_probability"],
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "forbidden_fields_used": False,
        "next_frontier": "QN006_PRIVATE_ERROR_CORRECTION_AS_LETTER_MANAGEMENT",
    }
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, formula_rows, sample_rows, checks, wrong_controls)


if __name__ == "__main__":
    main()
