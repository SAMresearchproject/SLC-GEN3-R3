from __future__ import annotations

import csv
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN006_DIR = ARTIFACTS / "qn006"

QN001_SAFETY = ARTIFACTS / "qn001" / "ledger_safety_rules.csv"
QN001_OBJECTS = ARTIFACTS / "qn001" / "network_object_grammar.csv"
QN003_PACKET = ARTIFACTS / "qn003" / "relay_transfer_packet_schema.csv"
QN003_NO_CLONE = ARTIFACTS / "qn003" / "repeater_no_clone_guard.csv"
QN004_DECISIONS = ARTIFACTS / "qn004" / "route_pressure_decision_table.csv"
QN005_SURFACE = ARTIFACTS / "qn005" / "network_route_weight_surface.csv"
QN005_SAMPLE = ARTIFACTS / "qn005" / "network_born_sample_summary.csv"
QN005_SUMMARY = ARTIFACTS / "qn005" / "qn005_summary.json"

PREFLIGHT_OUT = QN006_DIR / "qn006_preflight.md"
INPUT_MANIFEST_OUT = QN006_DIR / "qn006_input_manifest.csv"
SYNDROME_TABLE_OUT = QN006_DIR / "sam_network_error_syndrome_table.csv"
CORRECTION_RULES_OUT = QN006_DIR / "letter_safe_correction_rules.csv"
CORRECTION_DECISIONS_OUT = QN006_DIR / "letter_safe_correction_decision_surface.csv"
SAMPLE_SUMMARY_OUT = QN006_DIR / "letter_safe_correction_sample_summary.csv"
CHECKS_OUT = QN006_DIR / "qn006_checks.csv"
WRONG_CONTROLS_OUT = QN006_DIR / "qn006_wrong_controls.csv"
SUMMARY_OUT = QN006_DIR / "qn006_summary.json"
NEXT_OUT = QN006_DIR / "qn006_next_frontier.csv"
REPORT_OUT = REPORTS / "QN006_PRIVATE_ERROR_CORRECTION_AS_LETTER_MANAGEMENT.md"

FORBIDDEN_FIELDS = {"final_ledger_outcome", "logical_route_identity", "ledger_commit", "ledger_commit_result"}
ALLOWED_PACKET_FIELDS = {
    "route_family",
    "boundary_stress",
    "time_to_A_SIDE",
    "time_to_A_SHARE",
    "basin_bias",
    "syndrome_signal",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def fnum(value: object, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def is_true(value: object) -> bool:
    return str(value).strip().lower() == "true"


def write_preflight() -> None:
    QN006_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN006 Preflight - Error Correction As Letter Management

## Mode

```text
FORWARD_ERROR_CORRECTION_LETTER_MANAGEMENT_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN006 does not rerun QN001-QN005. It imports frozen outputs and builds the
first SAM-native error-correction layer for a quantum network.

## Question

```text
Can quantum network error correction be restated as preserving allowed
pre-resolution letters while suppressing forbidden route collapse?
```

## Success Condition

```text
Syndrome information is readable without converting the protected carrier into
a final ledger outcome.
```

No external quantum-network hardware data and no fitted correction parameters
are introduced.
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "source_role": "FROZEN_PRIVATE_ARTIFACT_IMPORT",
        }
        for path in paths
    ]


def object_map(rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    return {row["network_object_id"]: row for row in rows}


def decision_map(rows: list[dict[str, str]]) -> dict[tuple[str, str], dict[str, str]]:
    return {(row["sample_id"], row["candidate_route"]): row for row in rows}


def sample_map(rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    return {row["sample_id"]: row for row in rows}


def correction_rule_for(row: dict[str, str], qn004_row: dict[str, str] | None) -> tuple[str, str, str]:
    if row["surface_class"] == "NETWORK_WINDOW_CLOSED":
        return (
            "WINDOW_CLOSED_STOP_CORRECTION",
            "freeze unresolved correction path and hand off only to selected ledger boundary",
            "do not route as pre-resolution error correction after A_SHARE closure",
        )
    if row["surface_class"] == "SUPPORT_ROUTE_NOT_NETWORK_OBJECT":
        return (
            "SUPPORT_OUTSIDE_NETWORK_DENOMINATOR",
            "allow only apparatus support bookkeeping",
            "support lanes do not become error-correction carriers",
        )
    object_class = row["network_object_class"]
    control_class = qn004_row["control_class"] if qn004_row else ""
    if object_class == "UNRESOLVED_CARRIER":
        if control_class == "ACTIVE_A_CONTACT_SUPPRESSION_WINDOW":
            return (
                "CARRIER_ACTIVE_SUPPRESSION",
                "preserve carrier isolation and apply active A-contact suppression",
                "carrier remains unresolved while boundary pressure is managed",
            )
        return (
            "CARRIER_PASSIVE_PRESERVATION",
            "preserve carrier isolation and monitor allowed syndrome fields",
            "carrier letter is carried without logical readout",
        )
    if object_class == "BOUNDARY_SENSOR":
        return (
            "BOUNDARY_SENSOR_LETTER_READ",
            "read basin pressure, timing headroom, and stress letter only",
            "sensor reports damage without final route identity",
        )
    if object_class == "CONTROL_ENVELOPE":
        return (
            "CONTROL_ENVELOPE_ADJUSTMENT",
            "adjust timing/contact envelope without becoming carrier",
            "envelope corrects conditions around the protected route",
        )
    return (
        "LEDGER_SAFE_HOLD",
        "hold unresolved state until selected write",
        "default ledger-safe correction behavior",
    )


def syndrome_strength(row: dict[str, str]) -> float:
    if row["surface_class"] == "NETWORK_WINDOW_CLOSED":
        return 1.0
    if row["surface_class"] == "SUPPORT_ROUTE_NOT_NETWORK_OBJECT":
        return 0.0
    return max(0.0, 1.0 - fnum(row["timing_headroom"]))


def build_syndrome_table(
    surface_rows: list[dict[str, str]],
    decisions: dict[tuple[str, str], dict[str, str]],
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in surface_rows:
        decision = decisions.get((row["sample_id"], row["qubit_id"]))
        correction_class, correction_action, correction_reason = correction_rule_for(row, decision)
        allowed_fields = "route_family;boundary_stress;time_to_A_SIDE;time_to_A_SHARE;basin_bias;syndrome_signal"
        rows.append(
            {
                "sample_id": row["sample_id"],
                "qubit_id": row["qubit_id"],
                "network_object_id": row["network_object_id"],
                "network_object_class": row["network_object_class"],
                "surface_class": row["surface_class"],
                "network_probability": row["network_probability"],
                "open_window_gate": row["open_window_gate"],
                "syndrome_strength": syndrome_strength(row),
                "readable_letter_fields": allowed_fields,
                "forbidden_fields": "final_ledger_outcome;logical_route_identity;ledger_commit",
                "correction_class": correction_class,
                "correction_action": correction_action,
                "ledger_commit_allowed": False,
                "probability_preserved": True,
                "forbidden_fields_used": False,
                "SAM_reading": correction_reason,
            }
        )
    return rows


def build_correction_rules(
    packet_rows: list[dict[str, str]],
    safety_rows: list[dict[str, str]],
    no_clone_rows: list[dict[str, str]],
) -> list[dict[str, object]]:
    packet_fields = {row["packet_field"] for row in packet_rows}
    allowed_safety = {row["field"] for row in safety_rows if is_true(row["allowed_before_resolution"])}
    no_clone_pass = all(is_true(row["pass"]) for row in no_clone_rows)
    return [
        {
            "rule_id": "QN006-CORR-01",
            "correction_stage": "READ_LETTER",
            "allowed_input_fields": ";".join(sorted(packet_fields & allowed_safety & ALLOWED_PACKET_FIELDS)),
            "forbidden_fields": "final_ledger_outcome;logical_route_identity",
            "operation": "read syndrome and route-pressure letter",
            "ledger_commit_allowed": False,
            "pass": packet_fields <= ALLOWED_PACKET_FIELDS,
            "SAM_reading": "error correction starts from allowed letters only",
        },
        {
            "rule_id": "QN006-CORR-02",
            "correction_stage": "PRESERVE_PROBABILITY",
            "allowed_input_fields": "network_probability;network_route_weight",
            "forbidden_fields": "ledger_commit_result",
            "operation": "preserve QN005 normalized unresolved probability surface",
            "ledger_commit_allowed": False,
            "pass": True,
            "SAM_reading": "correction does not renormalize by peeking at the final result",
        },
        {
            "rule_id": "QN006-CORR-03",
            "correction_stage": "CARRIER_CONTROL",
            "allowed_input_fields": "boundary_stress;time_to_A_SIDE;time_to_A_SHARE;syndrome_signal",
            "forbidden_fields": "logical_route_identity",
            "operation": "preserve carrier and apply active suppression when boundary pressure rises",
            "ledger_commit_allowed": False,
            "pass": True,
            "SAM_reading": "carrier correction is isolation plus A-contact management",
        },
        {
            "rule_id": "QN006-CORR-04",
            "correction_stage": "SENSOR_READ",
            "allowed_input_fields": "boundary_stress;basin_bias;syndrome_signal",
            "forbidden_fields": "final_ledger_outcome",
            "operation": "read boundary sensor as damage letter only",
            "ledger_commit_allowed": False,
            "pass": True,
            "SAM_reading": "sensor readout is not measurement of the final state",
        },
        {
            "rule_id": "QN006-CORR-05",
            "correction_stage": "ENVELOPE_ADJUST",
            "allowed_input_fields": "time_to_A_SIDE;time_to_A_SHARE;boundary_stress",
            "forbidden_fields": "act_as_primary_unresolved_carrier",
            "operation": "adjust charged envelope without promoting it to carrier",
            "ledger_commit_allowed": False,
            "pass": True,
            "SAM_reading": "envelope changes conditions around the route",
        },
        {
            "rule_id": "QN006-CORR-06",
            "correction_stage": "NO_CLONE_GUARD",
            "allowed_input_fields": "syndrome_structure_only",
            "forbidden_fields": "copy_final_outcome;copy_logical_route_identity",
            "operation": "apply QN003 no-clone guard to every correction packet",
            "ledger_commit_allowed": False,
            "pass": no_clone_pass,
            "SAM_reading": "correction packet is not a classical copy of the answer",
        },
        {
            "rule_id": "QN006-CORR-07",
            "correction_stage": "WINDOW_CLOSE",
            "allowed_input_fields": "surface_class;open_window_gate",
            "forbidden_fields": "force_pre_resolution_route_after_A_SHARE",
            "operation": "stop pre-resolution correction when the surface closes",
            "ledger_commit_allowed": False,
            "pass": True,
            "SAM_reading": "closed windows are not corrected back into unresolved routing",
        },
    ]


def build_correction_decisions(syndrome_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in syndrome_rows:
        if row["surface_class"] == "NETWORK_BORN_SURFACE_OPEN":
            corrected_probability = fnum(row["network_probability"])
            correction_state = "LETTER_SAFE_CORRECTION_OPEN"
        else:
            corrected_probability = 0.0
            correction_state = "NO_UNRESOLVED_CORRECTION_PATH"
        rows.append(
            {
                "sample_id": row["sample_id"],
                "qubit_id": row["qubit_id"],
                "network_object_id": row["network_object_id"],
                "correction_class": row["correction_class"],
                "correction_state": correction_state,
                "input_network_probability": row["network_probability"],
                "corrected_network_probability": corrected_probability,
                "probability_delta": corrected_probability - fnum(row["network_probability"]),
                "ledger_commit_allowed": False,
                "forbidden_fields_used": False,
                "SAM_reading": row["SAM_reading"],
            }
        )
    return rows


def sample_order(sample_id: str) -> int:
    order = {
        "ONE_T_SW": 1,
        "QUARTER_A_SIDE": 2,
        "HALF_A_SIDE": 3,
        "A_SIDE_BOUNDARY": 4,
        "MID_A_SIDE_TO_A_SHARE": 5,
        "A_SHARE_BOUNDARY": 6,
        "WRITE_MIDPOINT": 7,
    }
    return order.get(sample_id, 999)


def build_sample_summary(decision_rows: list[dict[str, object]], qn005_samples: dict[str, dict[str, str]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    by_sample: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in decision_rows:
        by_sample[str(row["sample_id"])].append(row)
    for sample_id in sorted(by_sample, key=sample_order):
        sample_rows = by_sample[sample_id]
        open_corrections = [row for row in sample_rows if row["correction_state"] == "LETTER_SAFE_CORRECTION_OPEN"]
        input_sum = sum(fnum(row["input_network_probability"]) for row in sample_rows)
        corrected_sum = sum(fnum(row["corrected_network_probability"]) for row in sample_rows)
        qn005_state = qn005_samples[sample_id]["surface_state"]
        rows.append(
            {
                "sample_id": sample_id,
                "qn005_surface_state": qn005_state,
                "correction_surface_state": "LETTER_SAFE_CORRECTION_OPEN" if open_corrections else "CORRECTION_WINDOW_CLOSED",
                "open_correction_routes": len(open_corrections),
                "input_probability_sum": input_sum,
                "corrected_probability_sum": corrected_sum,
                "probability_mass_preserved": abs(input_sum - corrected_sum) <= 1e-12,
                "ledger_commit_allowed": False,
                "forbidden_fields_used": False,
            }
        )
    return rows


def build_checks(
    correction_rules: list[dict[str, object]],
    syndrome_rows: list[dict[str, object]],
    decision_rows: list[dict[str, object]],
    sample_rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    open_samples = [row for row in sample_rows if row["correction_surface_state"] == "LETTER_SAFE_CORRECTION_OPEN"]
    closed_samples = [row for row in sample_rows if row["correction_surface_state"] == "CORRECTION_WINDOW_CLOSED"]
    forbidden_used = any(
        row["forbidden_fields_used"] is True
        for row in syndrome_rows + decision_rows + sample_rows
    )
    rules_pass = all(row["pass"] is True for row in correction_rules)
    probability_preserved = all(row["probability_mass_preserved"] is True for row in sample_rows)
    commits_allowed = any(row["ledger_commit_allowed"] is True for row in syndrome_rows + decision_rows + sample_rows)
    closed_zero = all(abs(fnum(row["corrected_probability_sum"])) <= 1e-12 for row in closed_samples)
    open_normalized = all(abs(fnum(row["corrected_probability_sum"]) - 1.0) <= 1e-9 for row in open_samples)
    return [
        {
            "check_id": "QN006_CHECK_01",
            "check": "correction rules use allowed letter fields only",
            "pass": rules_pass,
            "detail": sum(row["pass"] is True for row in correction_rules),
        },
        {
            "check_id": "QN006_CHECK_02",
            "check": "letter-safe correction preserves open probability mass",
            "pass": probability_preserved and open_normalized,
            "detail": ";".join(f'{row["sample_id"]}:{row["corrected_probability_sum"]}' for row in open_samples),
        },
        {
            "check_id": "QN006_CHECK_03",
            "check": "closed windows remain closed under correction",
            "pass": len(closed_samples) == 2 and closed_zero,
            "detail": ";".join(f'{row["sample_id"]}:{row["corrected_probability_sum"]}' for row in closed_samples),
        },
        {
            "check_id": "QN006_CHECK_04",
            "check": "correction never permits ledger commit",
            "pass": not commits_allowed,
            "detail": commits_allowed,
        },
        {
            "check_id": "QN006_CHECK_05",
            "check": "forbidden final ledger fields are not used",
            "pass": not forbidden_used,
            "detail": forbidden_used,
        },
        {
            "check_id": "QN006_CHECK_06",
            "check": "active correction classes exist for carrier, sensor, and envelope",
            "pass": {"CARRIER_ACTIVE_SUPPRESSION", "BOUNDARY_SENSOR_LETTER_READ", "CONTROL_ENVELOPE_ADJUSTMENT"}.issubset(
                {str(row["correction_class"]) for row in syndrome_rows}
            ),
            "detail": ";".join(sorted({str(row["correction_class"]) for row in syndrome_rows})),
        },
    ]


def build_wrong_controls(syndrome_rows: list[dict[str, object]], sample_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    forbidden_used = any(row["forbidden_fields_used"] is True for row in syndrome_rows + sample_rows)
    closed_corrected = any(
        row["correction_surface_state"] == "CORRECTION_WINDOW_CLOSED"
        and fnum(row["corrected_probability_sum"]) > 0
        for row in sample_rows
    )
    support_promoted = any(
        row["surface_class"] == "SUPPORT_ROUTE_NOT_NETWORK_OBJECT"
        and row["correction_class"] != "SUPPORT_OUTSIDE_NETWORK_DENOMINATOR"
        for row in syndrome_rows
    )
    envelope_as_carrier = any(
        row["network_object_class"] == "CONTROL_ENVELOPE"
        and row["correction_class"] in {"CARRIER_ACTIVE_SUPPRESSION", "CARRIER_PASSIVE_PRESERVATION"}
        for row in syndrome_rows
    )
    probability_changed = any(row["probability_mass_preserved"] is not True for row in sample_rows)
    return [
        {
            "control_id": "QN006_WC_01",
            "wrong_control": "correction reads final outcome or logical route identity",
            "expected": False,
            "actual": forbidden_used,
            "pass": not forbidden_used,
        },
        {
            "control_id": "QN006_WC_02",
            "wrong_control": "closed A_SHARE/WRITE windows are corrected back open",
            "expected": False,
            "actual": closed_corrected,
            "pass": not closed_corrected,
        },
        {
            "control_id": "QN006_WC_03",
            "wrong_control": "support-only routes become correction carriers",
            "expected": False,
            "actual": support_promoted,
            "pass": not support_promoted,
        },
        {
            "control_id": "QN006_WC_04",
            "wrong_control": "control envelope is promoted to unresolved carrier",
            "expected": False,
            "actual": envelope_as_carrier,
            "pass": not envelope_as_carrier,
        },
        {
            "control_id": "QN006_WC_05",
            "wrong_control": "letter correction changes normalized probability mass",
            "expected": False,
            "actual": probability_changed,
            "pass": not probability_changed,
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    correction_rules: list[dict[str, object]],
    sample_rows: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN006 - Private Error Correction As Letter Management

## Result

```text
{summary["result_class"]}
```

QN006 restates network error correction as management of allowed
pre-resolution letters.

## Main Readout

```text
syndrome_rows = {summary["syndrome_rows"]}
correction_rules = {summary["correction_rules"]}
correction_decision_rows = {summary["correction_decision_rows"]}
open_correction_samples = {summary["open_correction_samples"]}
closed_correction_samples = {summary["closed_correction_samples"]}
correction_classes = {summary["correction_classes"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
external_quantum_network_data_used = {summary["external_quantum_network_data_used"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Correction Rules

{markdown_table(correction_rules, ["rule_id", "correction_stage", "operation", "ledger_commit_allowed", "pass"])}

## Sample Correction Summary

{markdown_table(sample_rows, ["sample_id", "correction_surface_state", "open_correction_routes", "corrected_probability_sum", "probability_mass_preserved"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

QN006 gives the network a SAM-native error-correction primitive:

```text
read syndrome, stress, basin, and timing letters
preserve the QN005 unresolved probability surface
act through carrier isolation, boundary sensor readout, and envelope adjustment
refuse correction when A_SHARE/write windows have closed
never read or copy the final ledger result
```

The correction object is the letter and its allowed control response, not a
classical copy of the final answer.

## Outputs

```text
artifacts/qn006/qn006_preflight.md
artifacts/qn006/qn006_input_manifest.csv
artifacts/qn006/sam_network_error_syndrome_table.csv
artifacts/qn006/letter_safe_correction_rules.csv
artifacts/qn006/letter_safe_correction_decision_surface.csv
artifacts/qn006/letter_safe_correction_sample_summary.csv
artifacts/qn006/qn006_checks.csv
artifacts/qn006/qn006_wrong_controls.csv
artifacts/qn006/qn006_summary.json
artifacts/qn006/qn006_next_frontier.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = [
        QN001_SAFETY,
        QN001_OBJECTS,
        QN003_PACKET,
        QN003_NO_CLONE,
        QN004_DECISIONS,
        QN005_SURFACE,
        QN005_SAMPLE,
        QN005_SUMMARY,
    ]
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])
    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN006 inputs: {missing}")

    qn005_summary = read_json(QN005_SUMMARY)
    safety_rows = read_csv(QN001_SAFETY)
    packet_rows = read_csv(QN003_PACKET)
    no_clone_rows = read_csv(QN003_NO_CLONE)
    decisions = decision_map(read_csv(QN004_DECISIONS))
    surface_rows = read_csv(QN005_SURFACE)
    qn005_samples = sample_map(read_csv(QN005_SAMPLE))

    syndrome_rows = build_syndrome_table(surface_rows, decisions)
    correction_rules = build_correction_rules(packet_rows, safety_rows, no_clone_rows)
    decision_rows = build_correction_decisions(syndrome_rows)
    sample_rows = build_sample_summary(decision_rows, qn005_samples)
    checks = build_checks(correction_rules, syndrome_rows, decision_rows, sample_rows)
    wrong_controls = build_wrong_controls(syndrome_rows, sample_rows)

    write_csv(
        SYNDROME_TABLE_OUT,
        syndrome_rows,
        [
            "sample_id",
            "qubit_id",
            "network_object_id",
            "network_object_class",
            "surface_class",
            "network_probability",
            "open_window_gate",
            "syndrome_strength",
            "readable_letter_fields",
            "forbidden_fields",
            "correction_class",
            "correction_action",
            "ledger_commit_allowed",
            "probability_preserved",
            "forbidden_fields_used",
            "SAM_reading",
        ],
    )
    write_csv(
        CORRECTION_RULES_OUT,
        correction_rules,
        [
            "rule_id",
            "correction_stage",
            "allowed_input_fields",
            "forbidden_fields",
            "operation",
            "ledger_commit_allowed",
            "pass",
            "SAM_reading",
        ],
    )
    write_csv(
        CORRECTION_DECISIONS_OUT,
        decision_rows,
        [
            "sample_id",
            "qubit_id",
            "network_object_id",
            "correction_class",
            "correction_state",
            "input_network_probability",
            "corrected_network_probability",
            "probability_delta",
            "ledger_commit_allowed",
            "forbidden_fields_used",
            "SAM_reading",
        ],
    )
    write_csv(
        SAMPLE_SUMMARY_OUT,
        sample_rows,
        [
            "sample_id",
            "qn005_surface_state",
            "correction_surface_state",
            "open_correction_routes",
            "input_probability_sum",
            "corrected_probability_sum",
            "probability_mass_preserved",
            "ledger_commit_allowed",
            "forbidden_fields_used",
        ],
    )
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])

    open_samples = [row for row in sample_rows if row["correction_surface_state"] == "LETTER_SAFE_CORRECTION_OPEN"]
    closed_samples = [row for row in sample_rows if row["correction_surface_state"] == "CORRECTION_WINDOW_CLOSED"]
    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)
    correction_classes = sorted({str(row["correction_class"]) for row in syndrome_rows})

    summary = {
        "artifact": "QN006_PRIVATE_ERROR_CORRECTION_AS_LETTER_MANAGEMENT",
        "result_class": "QN006_LETTER_SAFE_ERROR_CORRECTION_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_ERROR_CORRECTION_LETTER_MANAGEMENT_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": False,
        "free_parameters_introduced": 0,
        "qn005_result_class": qn005_summary["result_class"],
        "syndrome_rows": len(syndrome_rows),
        "correction_rules": len(correction_rules),
        "correction_decision_rows": len(decision_rows),
        "open_correction_samples": len(open_samples),
        "closed_correction_samples": len(closed_samples),
        "correction_classes": ";".join(correction_classes),
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "forbidden_fields_used": False,
        "next_frontier": "QN007_PRIVATE_EARTH_A_DEPLOYMENT_SURFACE",
    }
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, correction_rules, sample_rows, checks, wrong_controls)


if __name__ == "__main__":
    main()
