from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN007_DIR = ARTIFACTS / "qn007"

CORE_SUMMARY = ARTIFACTS / "core" / "phase_field_engine_summary.json"
CORE_SAFE_WINDOWS = ARTIFACTS / "core" / "phase_safe_window_table.csv"
QN001_OBJECTS = ARTIFACTS / "qn001" / "network_object_grammar.csv"
QN006_SYNDROME = ARTIFACTS / "qn006" / "sam_network_error_syndrome_table.csv"
QN006_RULES = ARTIFACTS / "qn006" / "letter_safe_correction_rules.csv"
QN006_SUMMARY = ARTIFACTS / "qn006" / "qn006_summary.json"

PREFLIGHT_OUT = QN007_DIR / "qn007_preflight.md"
INPUT_MANIFEST_OUT = QN007_DIR / "qn007_input_manifest.csv"
EARTH_A_SURFACE_OUT = QN007_DIR / "earth_a_network_control_surface.csv"
HARDWARE_REQUIREMENTS_OUT = QN007_DIR / "carrier_envelope_hardware_requirements.csv"
THRESHOLD_GAP_OUT = QN007_DIR / "earth_a_threshold_gap_table.csv"
DEPLOYMENT_DECISIONS_OUT = QN007_DIR / "earth_a_deployment_decision_surface.csv"
CHECKS_OUT = QN007_DIR / "qn007_checks.csv"
WRONG_CONTROLS_OUT = QN007_DIR / "qn007_wrong_controls.csv"
SUMMARY_OUT = QN007_DIR / "qn007_summary.json"
NEXT_OUT = QN007_DIR / "qn007_next_frontier.csv"
REPORT_OUT = REPORTS / "QN007_PRIVATE_EARTH_A_DEPLOYMENT_SURFACE.md"

# Sealed public SAM local-A result, imported as a frozen value only. This is not
# external quantum-network hardware data and does not tune QN behavior.
A_EARTH_SURFACE = 1.390657777567e-09
A_EARTH_SOURCE = "G371/G373_SEALED_SAM_EARTH_SURFACE_A"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def fnum(value: object, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def write_preflight() -> None:
    QN007_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN007 Preflight - Earth-A Deployment Surface

## Mode

```text
FORWARD_EARTH_A_DEPLOYMENT_SURFACE_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN007 does not rerun QN001-QN006. It imports frozen outputs and separates
literal Earth gravitational A from apparatus-supplied network controls.

## Question

```text
At Earth A, which network controls must be supplied by apparatus rather than
literal gravitational A?
```

## Success Condition

```text
The campaign separates fixed Earth A from engineered A-contact, shielding,
cooling, timing, and geometry controls.
```

No external quantum-network hardware data and no fitted deployment parameters
are introduced.
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "source_role": "FROZEN_PRIVATE_ARTIFACT_IMPORT",
        }
        for path in paths
    ] + [
        {
            "input_path": A_EARTH_SOURCE,
            "exists": True,
            "source_role": "SEALED_PUBLIC_SAM_VALUE_IMPORT_READ_ONLY",
        }
    ]


def threshold_value(summary: dict[str, object], name: str) -> float:
    for row in summary["thresholds"]:
        if row["name"] == name:
            return float(row["value"])
    raise KeyError(name)


def safe_window_value(rows: list[dict[str, str]], route_id: str, field: str) -> float:
    for row in rows:
        if row["route_id"] == route_id:
            return fnum(row[field])
    return 0.0


def build_threshold_gap_rows(core_summary: dict[str, object], safe_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    thresholds = [
        ("A_SIDE", threshold_value(core_summary, "A_SIDE")),
        ("A_SHARE", threshold_value(core_summary, "A_SHARE")),
        ("A_ALPHA_H_D", threshold_value(core_summary, "A_ALPHA_H_D")),
        ("A_HORIZON", threshold_value(core_summary, "A_HORIZON")),
    ]
    rows: list[dict[str, object]] = []
    for name, value in thresholds:
        rows.append(
            {
                "threshold": name,
                "threshold_A": value,
                "earth_surface_A": A_EARTH_SURFACE,
                "earth_fraction_of_threshold": A_EARTH_SURFACE / value,
                "threshold_to_earth_ratio": value / A_EARTH_SURFACE,
                "literal_earth_A_reaches_threshold": A_EARTH_SURFACE >= value,
                "SAM_reading": "literal Earth A is a fixed weak-field floor, not the QN control engine",
            }
        )
    lab_rate = safe_window_value(safe_rows, "CL_LANE__earth_surface", "A_exposure_rate")
    rows.append(
        {
            "threshold": "PRIVATE_CORE_CL_LANE_EARTH_SURFACE_EXPOSURE_RATE",
            "threshold_A": lab_rate,
            "earth_surface_A": A_EARTH_SURFACE,
            "earth_fraction_of_threshold": A_EARTH_SURFACE / lab_rate if lab_rate else 0.0,
            "threshold_to_earth_ratio": lab_rate / A_EARTH_SURFACE if A_EARTH_SURFACE else 0.0,
            "literal_earth_A_reaches_threshold": A_EARTH_SURFACE >= lab_rate,
            "SAM_reading": "private core lab exposure lane is an engineered environment lane, not literal Earth gravitational A",
        }
    )
    return rows


def build_control_surface(
    objects: list[dict[str, str]],
    syndrome_rows: list[dict[str, str]],
    gap_rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    correction_classes = sorted({row["correction_class"] for row in syndrome_rows})
    active_classes = [row for row in correction_classes if row not in {"SUPPORT_OUTSIDE_NETWORK_DENOMINATOR", "WINDOW_CLOSED_STOP_CORRECTION"}]
    earth_a_reaches_a_side = any(row["threshold"] == "A_SIDE" and row["literal_earth_A_reaches_threshold"] for row in gap_rows)
    base_rows = [
        {
            "control_id": "QN007-CTRL-00",
            "control_surface": "LITERAL_EARTH_A_BASELINE",
            "network_object_id": "EARTH_BACKGROUND",
            "network_object_class": "FIXED_A_FLOOR",
            "supplied_by": "EARTH_GRAVITATIONAL_A",
            "literal_earth_A": A_EARTH_SURFACE,
            "apparatus_required": False,
            "can_literal_earth_A_supply_control": False,
            "control_role": "fixed weak-field floor / clock-rate context",
            "source": A_EARTH_SOURCE,
            "SAM_reading": "Earth A is present, but far below the route-control thresholds",
        }
    ]
    object_rows = []
    for obj in objects:
        object_id = obj["network_object_id"]
        object_class = obj["object_class"]
        if object_class == "UNRESOLVED_CARRIER":
            control_role = "carrier isolation and no-write preservation"
            apparatus = "isolation; shielding; timing discipline; no-logical-readout routing"
        elif object_class == "CONTROL_ENVELOPE":
            control_role = "controlled A-contact and timing envelope"
            apparatus = "field control; pulse timing; shielding; envelope shaping"
        elif object_class == "BOUNDARY_SENSOR":
            control_role = "allowed stress/basin/timing letter readout"
            apparatus = "syndrome sensor; boundary-pressure readout; basin/timing monitor"
        elif object_class == "LEDGER_NODE":
            control_role = "selected write endpoint and commit delay"
            apparatus = "ledger-safe endpoint; delayed commit gate; route handoff logic"
        elif object_class == "RELAY_REPEATER":
            control_role = "letter-safe relay with no-clone guard"
            apparatus = "relay protocol; packet guard; no-commit support surface"
        else:
            control_role = "support geometry and environmental conditioning"
            apparatus = "geometry support; cooling; vibration isolation; platform shielding"
        object_rows.append(
            {
                "control_id": f"QN007-CTRL-{len(object_rows) + 1:02d}",
                "control_surface": apparatus,
                "network_object_id": object_id,
                "network_object_class": object_class,
                "supplied_by": "APPARATUS_ENGINEERED_CONTROL",
                "literal_earth_A": A_EARTH_SURFACE,
                "apparatus_required": True,
                "can_literal_earth_A_supply_control": earth_a_reaches_a_side,
                "control_role": control_role,
                "source": obj["source_artifact"],
                "SAM_reading": "deployment control is supplied by apparatus while Earth A remains background",
            }
        )
    base_rows.extend(object_rows)
    base_rows.append(
        {
            "control_id": "QN007-CTRL-99",
            "control_surface": ";".join(active_classes),
            "network_object_id": "QN006_CORRECTION_LAYER",
            "network_object_class": "REAL_TIME_LETTER_CORRECTION",
            "supplied_by": "APPARATUS_PLUS_QN_PROTOCOL",
            "literal_earth_A": A_EARTH_SURFACE,
            "apparatus_required": True,
            "can_literal_earth_A_supply_control": earth_a_reaches_a_side,
            "control_role": "real-time correction before A_SHARE closure",
            "source": "QN006",
            "SAM_reading": "correction uses live letters; Earth A alone cannot perform the correction",
        }
    )
    return base_rows


def build_hardware_requirements(control_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    rows = []
    for row in control_rows:
        if row["network_object_id"] == "EARTH_BACKGROUND":
            continue
        requirement_class = "REQUIRED_APPARATUS_CONTROL" if row["apparatus_required"] else "FIXED_BACKGROUND"
        rows.append(
            {
                "requirement_id": row["control_id"].replace("CTRL", "REQ"),
                "network_object_id": row["network_object_id"],
                "network_object_class": row["network_object_class"],
                "requirement_class": requirement_class,
                "requirement": row["control_surface"],
                "SAM_function": row["control_role"],
                "literal_earth_A_role": "fixed background A floor only",
                "engineered_control_role": row["control_surface"],
                "hardware_rate_claim": False,
                "commercial_protocol_claim": False,
            }
        )
    return rows


def build_deployment_decisions(control_rows: list[dict[str, object]], correction_rules: list[dict[str, str]]) -> list[dict[str, object]]:
    rows = []
    for row in control_rows:
        if row["network_object_id"] == "EARTH_BACKGROUND":
            decision = "BACKGROUND_ONLY"
            deployment_action = "record Earth A for clock/background context"
        elif row["apparatus_required"]:
            decision = "APPARATUS_REQUIRED"
            deployment_action = "supply engineered control surface before live QN deployment"
        else:
            decision = "NO_APPARATUS_REQUIRED"
            deployment_action = "none"
        rows.append(
            {
                "decision_id": row["control_id"].replace("CTRL", "DEPLOY"),
                "network_object_id": row["network_object_id"],
                "deployment_decision": decision,
                "deployment_action": deployment_action,
                "literal_earth_A_sufficient": row["can_literal_earth_A_supply_control"],
                "ledger_commit_allowed": False,
                "uses_external_hardware_data": False,
                "forbidden_fields_used": False,
            }
        )
    rows.append(
        {
            "decision_id": "QN007-DEPLOY-RULES",
            "network_object_id": "QN006_RULE_SET",
            "deployment_decision": "LETTER_SAFE_RULES_REQUIRED",
            "deployment_action": f'preserve {sum(str(rule["pass"]).lower() == "true" for rule in correction_rules)} correction rules',
            "literal_earth_A_sufficient": False,
            "ledger_commit_allowed": False,
            "uses_external_hardware_data": False,
            "forbidden_fields_used": False,
        }
    )
    return rows


def build_checks(
    gap_rows: list[dict[str, object]],
    control_rows: list[dict[str, object]],
    req_rows: list[dict[str, object]],
    decisions: list[dict[str, object]],
) -> list[dict[str, object]]:
    a_side_gap = next(row for row in gap_rows if row["threshold"] == "A_SIDE")
    a_share_gap = next(row for row in gap_rows if row["threshold"] == "A_SHARE")
    active_controls = [row for row in control_rows if row["network_object_id"] not in {"EARTH_BACKGROUND"}]
    all_active_need_apparatus = all(row["apparatus_required"] is True for row in active_controls)
    separated_classes = {"UNRESOLVED_CARRIER", "CONTROL_ENVELOPE", "BOUNDARY_SENSOR"}.issubset(
        {str(row["network_object_class"]) for row in control_rows}
    )
    no_external = not any(row["uses_external_hardware_data"] is True for row in decisions)
    no_commit = not any(row["ledger_commit_allowed"] is True for row in decisions)
    no_claims = not any(row["hardware_rate_claim"] is True or row["commercial_protocol_claim"] is True for row in req_rows)
    return [
        {
            "check_id": "QN007_CHECK_01",
            "check": "literal Earth A is below A_SIDE",
            "pass": a_side_gap["earth_fraction_of_threshold"] < 1.0,
            "detail": a_side_gap["earth_fraction_of_threshold"],
        },
        {
            "check_id": "QN007_CHECK_02",
            "check": "literal Earth A is below A_SHARE",
            "pass": a_share_gap["earth_fraction_of_threshold"] < 1.0,
            "detail": a_share_gap["earth_fraction_of_threshold"],
        },
        {
            "check_id": "QN007_CHECK_03",
            "check": "active network controls are apparatus supplied",
            "pass": all_active_need_apparatus,
            "detail": sum(row["apparatus_required"] is True for row in active_controls),
        },
        {
            "check_id": "QN007_CHECK_04",
            "check": "carrier, envelope, and sensor controls remain separated",
            "pass": separated_classes,
            "detail": ";".join(sorted({str(row["network_object_class"]) for row in control_rows})),
        },
        {
            "check_id": "QN007_CHECK_05",
            "check": "deployment decisions do not permit ledger commit",
            "pass": no_commit,
            "detail": no_commit,
        },
        {
            "check_id": "QN007_CHECK_06",
            "check": "no external quantum-network hardware data is used",
            "pass": no_external and no_claims,
            "detail": f"external={not no_external};claims={not no_claims}",
        },
    ]


def build_wrong_controls(gap_rows: list[dict[str, object]], control_rows: list[dict[str, object]], decisions: list[dict[str, object]]) -> list[dict[str, object]]:
    a_side_gap = next(row for row in gap_rows if row["threshold"] == "A_SIDE")
    earth_controls_active = any(
        row["network_object_id"] != "EARTH_BACKGROUND" and row["supplied_by"] == "EARTH_GRAVITATIONAL_A"
        for row in control_rows
    )
    envelope_promoted = any(
        row["network_object_class"] == "CONTROL_ENVELOPE" and "carrier isolation" in str(row["control_role"])
        for row in control_rows
    )
    external_used = any(row["uses_external_hardware_data"] is True for row in decisions)
    commit_allowed = any(row["ledger_commit_allowed"] is True for row in decisions)
    return [
        {
            "control_id": "QN007_WC_01",
            "wrong_control": "literal Earth A is treated as enough to reach A_SIDE",
            "expected": False,
            "actual": a_side_gap["literal_earth_A_reaches_threshold"],
            "pass": not a_side_gap["literal_earth_A_reaches_threshold"],
        },
        {
            "control_id": "QN007_WC_02",
            "wrong_control": "active QN controls are supplied by Earth gravity alone",
            "expected": False,
            "actual": earth_controls_active,
            "pass": not earth_controls_active,
        },
        {
            "control_id": "QN007_WC_03",
            "wrong_control": "control envelope is promoted to carrier role",
            "expected": False,
            "actual": envelope_promoted,
            "pass": not envelope_promoted,
        },
        {
            "control_id": "QN007_WC_04",
            "wrong_control": "external hardware benchmark data is used",
            "expected": False,
            "actual": external_used,
            "pass": not external_used,
        },
        {
            "control_id": "QN007_WC_05",
            "wrong_control": "deployment surface permits ledger commit",
            "expected": False,
            "actual": commit_allowed,
            "pass": not commit_allowed,
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    gap_rows: list[dict[str, object]],
    control_rows: list[dict[str, object]],
    req_rows: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN007 - Private Earth-A Deployment Surface

## Result

```text
{summary["result_class"]}
```

QN007 separates literal Earth gravitational A from engineered QN controls.

## Main Readout

```text
earth_surface_A = {summary["earth_surface_A"]}
earth_fraction_of_A_SIDE = {summary["earth_fraction_of_A_SIDE"]}
earth_fraction_of_A_SHARE = {summary["earth_fraction_of_A_SHARE"]}
control_surface_rows = {summary["control_surface_rows"]}
hardware_requirement_rows = {summary["hardware_requirement_rows"]}
apparatus_required_controls = {summary["apparatus_required_controls"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
external_quantum_network_data_used = {summary["external_quantum_network_data_used"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Threshold Gap

{markdown_table(gap_rows, ["threshold", "threshold_A", "earth_surface_A", "earth_fraction_of_threshold", "literal_earth_A_reaches_threshold"])}

## Control Surface

{markdown_table(control_rows, ["control_id", "network_object_id", "network_object_class", "supplied_by", "apparatus_required", "control_role"])}

## Hardware Requirements

{markdown_table(req_rows, ["requirement_id", "network_object_id", "requirement_class", "SAM_function"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

QN007 says the Earth lab starts with a real but weak A floor:

```text
Earth A is background context
carrier isolation is apparatus
control envelope is apparatus
boundary sensing is apparatus
ledger-safe relay logic is protocol/apparatus
closed windows remain closed
```

So the network does not wait for literal gravitational Earth A to create the
route-control condition. Earth A gives the background write-rate environment;
the live QN controls are engineered.

## Outputs

```text
artifacts/qn007/qn007_preflight.md
artifacts/qn007/qn007_input_manifest.csv
artifacts/qn007/earth_a_network_control_surface.csv
artifacts/qn007/carrier_envelope_hardware_requirements.csv
artifacts/qn007/earth_a_threshold_gap_table.csv
artifacts/qn007/earth_a_deployment_decision_surface.csv
artifacts/qn007/qn007_checks.csv
artifacts/qn007/qn007_wrong_controls.csv
artifacts/qn007/qn007_summary.json
artifacts/qn007/qn007_next_frontier.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = [
        CORE_SUMMARY,
        CORE_SAFE_WINDOWS,
        QN001_OBJECTS,
        QN006_SYNDROME,
        QN006_RULES,
        QN006_SUMMARY,
    ]
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])
    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN007 inputs: {missing}")

    core_summary = read_json(CORE_SUMMARY)
    safe_rows = read_csv(CORE_SAFE_WINDOWS)
    objects = read_csv(QN001_OBJECTS)
    syndrome_rows = read_csv(QN006_SYNDROME)
    correction_rules = read_csv(QN006_RULES)
    qn006_summary = read_json(QN006_SUMMARY)

    gap_rows = build_threshold_gap_rows(core_summary, safe_rows)
    control_rows = build_control_surface(objects, syndrome_rows, gap_rows)
    req_rows = build_hardware_requirements(control_rows)
    decision_rows = build_deployment_decisions(control_rows, correction_rules)
    checks = build_checks(gap_rows, control_rows, req_rows, decision_rows)
    wrong_controls = build_wrong_controls(gap_rows, control_rows, decision_rows)

    write_csv(
        THRESHOLD_GAP_OUT,
        gap_rows,
        [
            "threshold",
            "threshold_A",
            "earth_surface_A",
            "earth_fraction_of_threshold",
            "threshold_to_earth_ratio",
            "literal_earth_A_reaches_threshold",
            "SAM_reading",
        ],
    )
    write_csv(
        EARTH_A_SURFACE_OUT,
        control_rows,
        [
            "control_id",
            "control_surface",
            "network_object_id",
            "network_object_class",
            "supplied_by",
            "literal_earth_A",
            "apparatus_required",
            "can_literal_earth_A_supply_control",
            "control_role",
            "source",
            "SAM_reading",
        ],
    )
    write_csv(
        HARDWARE_REQUIREMENTS_OUT,
        req_rows,
        [
            "requirement_id",
            "network_object_id",
            "network_object_class",
            "requirement_class",
            "requirement",
            "SAM_function",
            "literal_earth_A_role",
            "engineered_control_role",
            "hardware_rate_claim",
            "commercial_protocol_claim",
        ],
    )
    write_csv(
        DEPLOYMENT_DECISIONS_OUT,
        decision_rows,
        [
            "decision_id",
            "network_object_id",
            "deployment_decision",
            "deployment_action",
            "literal_earth_A_sufficient",
            "ledger_commit_allowed",
            "uses_external_hardware_data",
            "forbidden_fields_used",
        ],
    )
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])

    a_side_gap = next(row for row in gap_rows if row["threshold"] == "A_SIDE")
    a_share_gap = next(row for row in gap_rows if row["threshold"] == "A_SHARE")
    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)
    apparatus_required = sum(row["apparatus_required"] is True for row in control_rows)

    summary = {
        "artifact": "QN007_PRIVATE_EARTH_A_DEPLOYMENT_SURFACE",
        "result_class": "QN007_EARTH_A_DEPLOYMENT_SURFACE_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_WITH_SEALED_PUBLIC_SAM_EARTH_A_IMPORT",
        "test_type": "FORWARD_EARTH_A_DEPLOYMENT_SURFACE_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": False,
        "free_parameters_introduced": 0,
        "qn006_result_class": qn006_summary["result_class"],
        "earth_surface_A": A_EARTH_SURFACE,
        "earth_A_source": A_EARTH_SOURCE,
        "earth_fraction_of_A_SIDE": a_side_gap["earth_fraction_of_threshold"],
        "earth_fraction_of_A_SHARE": a_share_gap["earth_fraction_of_threshold"],
        "control_surface_rows": len(control_rows),
        "hardware_requirement_rows": len(req_rows),
        "deployment_decision_rows": len(decision_rows),
        "apparatus_required_controls": apparatus_required,
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "forbidden_fields_used": False,
        "next_frontier": "QN008_PRIVATE_SEALED_LAB_BENCHMARK_MANIFEST",
    }
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, gap_rows, control_rows, req_rows, checks, wrong_controls)


if __name__ == "__main__":
    main()
