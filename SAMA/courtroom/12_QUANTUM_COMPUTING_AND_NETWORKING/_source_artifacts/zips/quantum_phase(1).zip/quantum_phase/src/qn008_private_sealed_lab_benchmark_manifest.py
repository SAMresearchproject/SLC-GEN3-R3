from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN008_DIR = ARTIFACTS / "qn008"

SUMMARY_PATHS = [ARTIFACTS / f"qn{i:03d}" / f"qn{i:03d}_summary.json" for i in range(1, 8)]
REPORT_PATHS = [
    REPORTS / "QN001_PRIVATE_NETWORK_OBJECT_GRAMMAR_FREEZE.md",
    REPORTS / "QN002_PRIVATE_LINK_SURVIVAL_AND_CONTACT_SUPPRESSION_LAW.md",
    REPORTS / "QN003_PRIVATE_LEDGER_SAFE_RELAY_REPEATER_LAW.md",
    REPORTS / "QN004_PRIVATE_PAUL_REVERE_ROUTING_PROTOCOL.md",
    REPORTS / "QN005_PRIVATE_NETWORK_BORN_SURFACE.md",
    REPORTS / "QN006_PRIVATE_ERROR_CORRECTION_AS_LETTER_MANAGEMENT.md",
    REPORTS / "QN007_PRIVATE_EARTH_A_DEPLOYMENT_SURFACE.md",
]

PREFLIGHT_OUT = QN008_DIR / "qn008_preflight.md"
INPUT_MANIFEST_OUT = QN008_DIR / "qn008_input_manifest.csv"
BENCHMARK_MANIFEST_OUT = QN008_DIR / "sealed_quantum_network_benchmark_manifest.csv"
FORMULA_FREEZE_OUT = QN008_DIR / "sealed_quantum_network_formula_freeze.csv"
ARTIFACT_HASH_OUT = QN008_DIR / "sealed_qn_artifact_hash_manifest.csv"
EXCLUSION_OUT = QN008_DIR / "external_comparison_exclusion_record.md"
CHECKS_OUT = QN008_DIR / "qn008_checks.csv"
WRONG_CONTROLS_OUT = QN008_DIR / "qn008_wrong_controls.csv"
SUMMARY_OUT = QN008_DIR / "qn008_summary.json"
NEXT_OUT = QN008_DIR / "qn008_next_frontier.csv"
REPORT_OUT = REPORTS / "QN008_PRIVATE_SEALED_LAB_BENCHMARK_MANIFEST.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_preflight() -> None:
    QN008_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN008 Preflight - Sealed Lab Benchmark Manifest

## Mode

```text
FORWARD_SEALED_BENCHMARK_MANIFEST_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN008 does not rerun QN001-QN007 and does not compare to external hardware
benchmarks. It freezes the internal quantum-network chain before any external
benchmark comparison enters the branch.

## Question

```text
Can SAM freeze quantum-network predictions before external quantum-network
hardware comparison?
```

## Success Condition

```text
All formulas, constants, roles, and forbidden leakage claims are frozen before
external benchmark data enters the branch.
```
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "source_role": "FROZEN_QN_PHASE1_INPUT",
        }
        for path in paths
    ]


def build_benchmark_manifest(summaries: list[dict[str, object]]) -> list[dict[str, object]]:
    by_artifact = {str(row["artifact"]): row for row in summaries}
    qn001 = by_artifact["QN001_PRIVATE_NETWORK_OBJECT_GRAMMAR_FREEZE"]
    qn002 = by_artifact["QN002_PRIVATE_LINK_SURVIVAL_AND_CONTACT_SUPPRESSION_LAW"]
    qn003 = by_artifact["QN003_PRIVATE_LEDGER_SAFE_RELAY_REPEATER_LAW"]
    qn004 = by_artifact["QN004_PRIVATE_PAUL_REVERE_ROUTING_PROTOCOL"]
    qn005 = by_artifact["QN005_PRIVATE_NETWORK_BORN_SURFACE"]
    qn006 = by_artifact["QN006_PRIVATE_ERROR_CORRECTION_AS_LETTER_MANAGEMENT"]
    qn007 = by_artifact["QN007_PRIVATE_EARTH_A_DEPLOYMENT_SURFACE"]
    return [
        {
            "benchmark_id": "QN-BENCH-001",
            "sealed_object": "network_object_grammar",
            "sealed_value": f'carrier={qn001["primary_carrier"]}; envelope={qn001["control_envelope"]}; sensor={qn001["boundary_sensor"]}',
            "source_gate": "QN001",
            "external_data_allowed_before_manifest": False,
            "benchmark_use_after_manifest": "compare object roles against candidate hardware role map",
        },
        {
            "benchmark_id": "QN-BENCH-002",
            "sealed_object": "link_survival_and_viability",
            "sealed_value": f'link={qn002["selected_link_object"]}; route={qn002["selected_link_route"]}; score={qn002["selected_link_viability_score"]}',
            "source_gate": "QN002",
            "external_data_allowed_before_manifest": False,
            "benchmark_use_after_manifest": "compare link requirements to candidate carrier platform",
        },
        {
            "benchmark_id": "QN-BENCH-003",
            "sealed_object": "ledger_safe_relay",
            "sealed_value": f'surface={qn003["selected_relay_surface"]}; relay_score={qn003["relay_viability_score"]}',
            "source_gate": "QN003",
            "external_data_allowed_before_manifest": False,
            "benchmark_use_after_manifest": "compare relay behavior against no-clone/no-commit constraints",
        },
        {
            "benchmark_id": "QN-BENCH-004",
            "sealed_object": "paul_revere_routing",
            "sealed_value": f'route={qn004["selected_route"]}; top_score={qn004["top_selected_routing_score"]}; closed={qn004["closed_window_samples"]}',
            "source_gate": "QN004",
            "external_data_allowed_before_manifest": False,
            "benchmark_use_after_manifest": "compare real-time routing controls to pre-resolution letter fields",
        },
        {
            "benchmark_id": "QN-BENCH-005",
            "sealed_object": "network_born_surface",
            "sealed_value": f'top_route={qn005["top_open_route"]}; top_probability={qn005["top_open_probability"]}; open={qn005["open_surface_samples"]}; closed={qn005["closed_surface_samples"]}',
            "source_gate": "QN005",
            "external_data_allowed_before_manifest": False,
            "benchmark_use_after_manifest": "compare observed route stability to sealed network probability surface",
        },
        {
            "benchmark_id": "QN-BENCH-006",
            "sealed_object": "letter_safe_error_correction",
            "sealed_value": f'rules={qn006["correction_rules"]}; open={qn006["open_correction_samples"]}; closed={qn006["closed_correction_samples"]}',
            "source_gate": "QN006",
            "external_data_allowed_before_manifest": False,
            "benchmark_use_after_manifest": "compare error correction to letter-safe syndrome management",
        },
        {
            "benchmark_id": "QN-BENCH-007",
            "sealed_object": "earth_a_deployment_surface",
            "sealed_value": f'earth_A={qn007["earth_surface_A"]}; A_SIDE_fraction={qn007["earth_fraction_of_A_SIDE"]}; apparatus_controls={qn007["apparatus_required_controls"]}',
            "source_gate": "QN007",
            "external_data_allowed_before_manifest": False,
            "benchmark_use_after_manifest": "compare deployment requirements to apparatus-supplied controls",
        },
        {
            "benchmark_id": "QN-BENCH-008",
            "sealed_object": "forbidden_leakage_invariant",
            "sealed_value": "final_ledger_outcome/logical_route_identity forbidden before selected write",
            "source_gate": "QN001-QN007",
            "external_data_allowed_before_manifest": False,
            "benchmark_use_after_manifest": "screen candidate protocols for premature final-outcome leakage",
        },
    ]


def build_formula_freeze(summaries: list[dict[str, object]]) -> list[dict[str, object]]:
    rows = []
    for summary in summaries:
        artifact = str(summary["artifact"])
        gate = artifact.split("_")[0]
        for key in [
            "core_network_rule",
            "core_link_rule",
            "core_relay_rule",
            "core_routing_rule",
        ]:
            if key in summary:
                rows.append(
                    {
                        "gate": gate,
                        "formula_or_rule_id": key,
                        "frozen_formula_or_rule": summary[key],
                        "external_data_allowed_before_manifest": False,
                    }
                )
    rows.extend(
        [
            {
                "gate": "QN005",
                "formula_or_rule_id": "network_probability",
                "frozen_formula_or_rule": "network_route_weight / sum(network_route_weight over network-available unresolved routes)",
                "external_data_allowed_before_manifest": False,
            },
            {
                "gate": "QN006",
                "formula_or_rule_id": "letter_safe_correction",
                "frozen_formula_or_rule": "read allowed letters; preserve QN005 probability surface; act through carrier/sensor/envelope controls",
                "external_data_allowed_before_manifest": False,
            },
            {
                "gate": "QN007",
                "formula_or_rule_id": "earth_A_deployment_split",
                "frozen_formula_or_rule": "literal Earth A is background; live QN control is apparatus/protocol supplied",
                "external_data_allowed_before_manifest": False,
            },
        ]
    )
    return rows


def build_hash_manifest(paths: list[Path]) -> list[dict[str, object]]:
    rows = []
    for path in paths:
        rows.append(
            {
                "sealed_path": str(path.relative_to(ROOT)),
                "sha256": sha256(path),
                "sealed_for_external_comparison": True,
            }
        )
    return rows


def build_checks(
    summaries: list[dict[str, object]],
    benchmark_rows: list[dict[str, object]],
    formula_rows: list[dict[str, object]],
    hash_rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    external_count = sum(row["external_quantum_network_data_used"] is True for row in summaries)
    free_param_total = sum(int(row["free_parameters_introduced"]) for row in summaries)
    check_total = sum(int(row["check_total"]) for row in summaries)
    check_passes = sum(int(row["check_passes"]) for row in summaries)
    wrong_total = sum(int(row["wrong_control_total"]) for row in summaries)
    wrong_passes = sum(int(row["wrong_control_passes"]) for row in summaries)
    all_bench_frozen = all(row["external_data_allowed_before_manifest"] is False for row in benchmark_rows)
    all_formula_frozen = all(row["external_data_allowed_before_manifest"] is False for row in formula_rows)
    all_hashes_present = all(len(str(row["sha256"])) == 64 for row in hash_rows)
    return [
        {
            "check_id": "QN008_CHECK_01",
            "check": "all QN001-QN007 gates report no external quantum-network data",
            "pass": external_count == 0,
            "detail": external_count,
        },
        {
            "check_id": "QN008_CHECK_02",
            "check": "all QN001-QN007 gates report zero free parameters",
            "pass": free_param_total == 0,
            "detail": free_param_total,
        },
        {
            "check_id": "QN008_CHECK_03",
            "check": "all internal gate checks passed before freeze",
            "pass": check_passes == check_total,
            "detail": f"{check_passes}/{check_total}",
        },
        {
            "check_id": "QN008_CHECK_04",
            "check": "all wrong controls passed before freeze",
            "pass": wrong_passes == wrong_total,
            "detail": f"{wrong_passes}/{wrong_total}",
        },
        {
            "check_id": "QN008_CHECK_05",
            "check": "benchmark rows exclude external data before manifest",
            "pass": all_bench_frozen,
            "detail": len(benchmark_rows),
        },
        {
            "check_id": "QN008_CHECK_06",
            "check": "formula/rule freeze excludes external data before manifest",
            "pass": all_formula_frozen,
            "detail": len(formula_rows),
        },
        {
            "check_id": "QN008_CHECK_07",
            "check": "sealed source hashes are present",
            "pass": all_hashes_present,
            "detail": len(hash_rows),
        },
    ]


def build_wrong_controls(summaries: list[dict[str, object]], benchmark_rows: list[dict[str, object]], formula_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    external_used = any(row["external_quantum_network_data_used"] is True for row in summaries)
    free_params = sum(int(row["free_parameters_introduced"]) for row in summaries) > 0
    pre_manifest_external_allowed = any(row["external_data_allowed_before_manifest"] is True for row in benchmark_rows + formula_rows)
    leak_invariant_missing = not any(row["sealed_object"] == "forbidden_leakage_invariant" for row in benchmark_rows)
    hardware_claim = any("hardware rate" in str(row["benchmark_use_after_manifest"]).lower() for row in benchmark_rows)
    return [
        {
            "control_id": "QN008_WC_01",
            "wrong_control": "external benchmark data entered before freeze",
            "expected": False,
            "actual": external_used or pre_manifest_external_allowed,
            "pass": not (external_used or pre_manifest_external_allowed),
        },
        {
            "control_id": "QN008_WC_02",
            "wrong_control": "free deployment/probability parameters were introduced",
            "expected": False,
            "actual": free_params,
            "pass": not free_params,
        },
        {
            "control_id": "QN008_WC_03",
            "wrong_control": "forbidden leakage invariant is absent from benchmark manifest",
            "expected": False,
            "actual": leak_invariant_missing,
            "pass": not leak_invariant_missing,
        },
        {
            "control_id": "QN008_WC_04",
            "wrong_control": "manifest freezes hardware-rate/commercial performance claim",
            "expected": False,
            "actual": hardware_claim,
            "pass": not hardware_claim,
        },
    ]


def write_exclusion_record(summary: dict[str, object], benchmark_rows: list[dict[str, object]], hash_rows: list[dict[str, object]]) -> None:
    EXCLUSION_OUT.write_text(
        f"""# External Comparison Exclusion Record - QN008

## Status

```text
{summary["result_class"]}
```

QN008 freezes the internal SAM quantum-network package before external
quantum-network benchmark comparison.

## Exclusion Rule

```text
No external quantum-network hardware data, rate records, distance records,
commercial protocol performance claims, or platform-specific benchmark values
enter QN001-QN008.
```

External comparison may begin only after this manifest.

## Frozen Benchmark Objects

```text
benchmark_rows = {len(benchmark_rows)}
sealed_hash_rows = {len(hash_rows)}
gate_check_passes = {summary["gate_check_passes"]}/{summary["gate_check_total"]}
wrong_control_passes = {summary["gate_wrong_control_passes"]}/{summary["gate_wrong_control_total"]}
```

## Allowed Later Comparison Questions

```text
Does a candidate platform preserve unresolved carrier state?
Can it transport allowed syndrome/stress/timing letters without final-outcome leakage?
Can it perform real-time correction before the A_SHARE/write window closes?
Can it separate carrier, envelope, sensor, relay, ledger node, and support roles?
Does its deployment supply apparatus controls rather than relying on literal Earth A?
```

## Sealed Source Hashes

See:

```text
artifacts/qn008/sealed_qn_artifact_hash_manifest.csv
```
""",
        encoding="utf-8",
    )


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    benchmark_rows: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN008 - Private Sealed Lab Benchmark Manifest

## Result

```text
{summary["result_class"]}
```

QN008 seals the QN001-QN007 quantum-network package before external comparison.

## Main Readout

```text
gates_sealed = {summary["gates_sealed"]}
benchmark_manifest_rows = {summary["benchmark_manifest_rows"]}
formula_freeze_rows = {summary["formula_freeze_rows"]}
sealed_hash_rows = {summary["sealed_hash_rows"]}
gate_check_passes = {summary["gate_check_passes"]}/{summary["gate_check_total"]}
gate_wrong_control_passes = {summary["gate_wrong_control_passes"]}/{summary["gate_wrong_control_total"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
external_quantum_network_data_used = {summary["external_quantum_network_data_used"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Benchmark Manifest

{markdown_table(benchmark_rows, ["benchmark_id", "sealed_object", "sealed_value", "source_gate"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

QN008 freezes the quantum-network phase-1 package:

```text
QN001 object grammar
QN002 link survival
QN003 ledger-safe relay
QN004 Paul Revere routing
QN005 network Born surface
QN006 real-time letter-safe correction
QN007 Earth-A deployment split
```

The package is now sealed for later external benchmark comparison.

## Outputs

```text
artifacts/qn008/qn008_preflight.md
artifacts/qn008/qn008_input_manifest.csv
artifacts/qn008/sealed_quantum_network_benchmark_manifest.csv
artifacts/qn008/sealed_quantum_network_formula_freeze.csv
artifacts/qn008/sealed_qn_artifact_hash_manifest.csv
artifacts/qn008/external_comparison_exclusion_record.md
artifacts/qn008/qn008_checks.csv
artifacts/qn008/qn008_wrong_controls.csv
artifacts/qn008/qn008_summary.json
artifacts/qn008/qn008_next_frontier.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = SUMMARY_PATHS + REPORT_PATHS
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])
    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN008 inputs: {missing}")

    summaries = [read_json(path) for path in SUMMARY_PATHS]
    benchmark_rows = build_benchmark_manifest(summaries)
    formula_rows = build_formula_freeze(summaries)
    hash_rows = build_hash_manifest(input_paths)
    checks = build_checks(summaries, benchmark_rows, formula_rows, hash_rows)
    wrong_controls = build_wrong_controls(summaries, benchmark_rows, formula_rows)

    gate_check_total = sum(int(row["check_total"]) for row in summaries)
    gate_check_passes = sum(int(row["check_passes"]) for row in summaries)
    gate_wrong_total = sum(int(row["wrong_control_total"]) for row in summaries)
    gate_wrong_passes = sum(int(row["wrong_control_passes"]) for row in summaries)
    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)

    summary = {
        "artifact": "QN008_PRIVATE_SEALED_LAB_BENCHMARK_MANIFEST",
        "result_class": "QN008_SEALED_LAB_BENCHMARK_MANIFEST_FROZEN",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_SEALED_BENCHMARK_MANIFEST_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": False,
        "free_parameters_introduced": 0,
        "gates_sealed": len(summaries),
        "benchmark_manifest_rows": len(benchmark_rows),
        "formula_freeze_rows": len(formula_rows),
        "sealed_hash_rows": len(hash_rows),
        "gate_check_passes": gate_check_passes,
        "gate_check_total": gate_check_total,
        "gate_wrong_control_passes": gate_wrong_passes,
        "gate_wrong_control_total": gate_wrong_total,
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "forbidden_fields_used": False,
        "next_frontier": "QN_PHASE1_PRIVATE_PACKAGE_READY_FOR_EXTERNAL_BENCHMARK_REVIEW",
    }
    write_csv(
        BENCHMARK_MANIFEST_OUT,
        benchmark_rows,
        [
            "benchmark_id",
            "sealed_object",
            "sealed_value",
            "source_gate",
            "external_data_allowed_before_manifest",
            "benchmark_use_after_manifest",
        ],
    )
    write_csv(
        FORMULA_FREEZE_OUT,
        formula_rows,
        ["gate", "formula_or_rule_id", "frozen_formula_or_rule", "external_data_allowed_before_manifest"],
    )
    write_csv(ARTIFACT_HASH_OUT, hash_rows, ["sealed_path", "sha256", "sealed_for_external_comparison"])
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_exclusion_record(summary, benchmark_rows, hash_rows)
    write_report(summary, benchmark_rows, checks, wrong_controls)


if __name__ == "__main__":
    main()
