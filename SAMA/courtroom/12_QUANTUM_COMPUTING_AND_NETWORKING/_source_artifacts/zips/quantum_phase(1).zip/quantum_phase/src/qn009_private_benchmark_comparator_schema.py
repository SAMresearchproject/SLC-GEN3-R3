from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN009_DIR = ARTIFACTS / "qn009"

QN008_SUMMARY = ARTIFACTS / "qn008" / "qn008_summary.json"
QN008_BENCHMARK_MANIFEST = ARTIFACTS / "qn008" / "sealed_quantum_network_benchmark_manifest.csv"
QN008_FORMULA_FREEZE = ARTIFACTS / "qn008" / "sealed_quantum_network_formula_freeze.csv"
QN008_HASH_MANIFEST = ARTIFACTS / "qn008" / "sealed_qn_artifact_hash_manifest.csv"
QN008_EXCLUSION = ARTIFACTS / "qn008" / "external_comparison_exclusion_record.md"
QN001_OBJECTS = ARTIFACTS / "qn001" / "network_object_grammar.csv"
QN006_CORRECTION_RULES = ARTIFACTS / "qn006" / "letter_safe_correction_rules.csv"
QN007_REQUIREMENTS = ARTIFACTS / "qn007" / "carrier_envelope_hardware_requirements.csv"

PREFLIGHT_OUT = QN009_DIR / "qn009_preflight.md"
INPUT_MANIFEST_OUT = QN009_DIR / "qn009_input_manifest.csv"
CANDIDATE_ROLE_TEMPLATE_OUT = QN009_DIR / "candidate_hardware_role_map_template.csv"
CANDIDATE_EVIDENCE_TEMPLATE_OUT = QN009_DIR / "candidate_benchmark_evidence_template.csv"
SCORING_RULES_OUT = QN009_DIR / "sam_qn_benchmark_scoring_rules.csv"
LEAKAGE_SCREEN_OUT = QN009_DIR / "forbidden_leakage_screen.csv"
COMPARATOR_OUTPUT_SCHEMA_OUT = QN009_DIR / "sam_qn_comparator_output_schema.csv"
CHECKS_OUT = QN009_DIR / "qn009_checks.csv"
WRONG_CONTROLS_OUT = QN009_DIR / "qn009_wrong_controls.csv"
SUMMARY_OUT = QN009_DIR / "qn009_summary.json"
NEXT_OUT = QN009_DIR / "qn009_next_frontier.csv"
REPORT_OUT = REPORTS / "QN009_PRIVATE_BENCHMARK_COMPARATOR_SCHEMA.md"


STATUS_VOCABULARY = [
    {
        "status": "SAM_MATCH",
        "meaning": "candidate reports all required comparator fields and no leakage blockers for this sealed SAM object",
        "rank_score": "",
    },
    {
        "status": "SAM_PARTIAL",
        "meaning": "candidate reports a compatible mechanism but leaves one or more required fields incomplete",
        "rank_score": "",
    },
    {
        "status": "SAM_MISS",
        "meaning": "candidate reports a mechanism that does not satisfy the sealed SAM object",
        "rank_score": "",
    },
    {
        "status": "SAM_BLOCKER",
        "meaning": "candidate reports premature final-outcome access, cloning of route identity, or incompatible ledger behavior",
        "rank_score": "",
    },
    {
        "status": "NOT_REPORTED",
        "meaning": "candidate does not report enough information for this sealed SAM object",
        "rank_score": "",
    },
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def is_true(value: object) -> bool:
    return str(value).strip().lower() == "true"


def write_preflight() -> None:
    QN009_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN009 Preflight - Benchmark Comparator Schema

## Mode

```text
FORWARD_BENCHMARK_COMPARATOR_SCHEMA_BUILD
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN009 does not rerun QN001-QN008 and does not import external hardware data.
It converts the sealed QN008 benchmark manifest into a comparator schema for
later approved external review.

## Question

```text
Can SAM define the candidate-hardware comparison grammar before any candidate
hardware data enters the branch?
```

## Success Condition

```text
All benchmark rows, role maps, leakage blockers, and comparison statuses are
frozen with no platform claims, no ranking weights, and no external data.
```
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "source_role": "FROZEN_PRIVATE_ARTIFACT_IMPORT",
        }
        for path in paths
    ]


def build_candidate_role_template(
    objects: list[dict[str, str]],
    requirements: list[dict[str, str]],
) -> list[dict[str, object]]:
    requirement_by_object = {row["network_object_id"]: row for row in requirements}
    rows: list[dict[str, object]] = []
    for obj in objects:
        requirement = requirement_by_object.get(obj["network_object_id"], {})
        rows.append(
            {
                "candidate_id": "QN010_CANDIDATE_ID",
                "candidate_platform": "QN010_REQUIRED",
                "sam_network_object_id": obj["network_object_id"],
                "sam_object_class": obj["object_class"],
                "sam_selected_route": obj["selected_route"],
                "sam_selected_family": obj["selected_family"],
                "sam_permission": obj["network_permission"],
                "permitted_pre_resolution_content": obj["permitted_pre_resolution_content"],
                "forbidden_content": obj["forbidden_content"],
                "required_candidate_mechanism": requirement.get("engineered_control_role", "QN010_REQUIRED"),
                "candidate_mechanism_reported": "QN010_REQUIRED",
                "candidate_evidence_reference": "QN010_REQUIRED",
                "candidate_role_status": "QN010_COMPARATOR_OUTPUT",
                "external_data_allowed_in_qn009": False,
            }
        )
    rows.append(
        {
            "candidate_id": "QN010_CANDIDATE_ID",
            "candidate_platform": "QN010_REQUIRED",
            "sam_network_object_id": "QN006_CORRECTION_LAYER",
            "sam_object_class": "REAL_TIME_LETTER_CORRECTION",
            "sam_selected_route": "LETTER_SAFE_SYNDROME_LAYER",
            "sam_selected_family": "allowed_pre_resolution_letters",
            "sam_permission": "READ_ALLOWED_LETTERS_WITHOUT_FINAL_ROUTE_IDENTITY",
            "permitted_pre_resolution_content": "route_family;boundary_stress;time_to_A_SIDE;time_to_A_SHARE;basin_bias;syndrome_signal",
            "forbidden_content": "final_ledger_outcome;logical_route_identity;ledger_commit_result",
            "required_candidate_mechanism": "real-time syndrome management before write closure",
            "candidate_mechanism_reported": "QN010_REQUIRED",
            "candidate_evidence_reference": "QN010_REQUIRED",
            "candidate_role_status": "QN010_COMPARATOR_OUTPUT",
            "external_data_allowed_in_qn009": False,
        }
    )
    return rows


def rule_for_benchmark(row: dict[str, str]) -> dict[str, object]:
    benchmark_id = row["benchmark_id"]
    sealed_object = row["sealed_object"]
    base = {
        "rule_id": f"{benchmark_id}-RULE",
        "benchmark_id": benchmark_id,
        "sealed_object": sealed_object,
        "sealed_value": row["sealed_value"],
        "status_vocabulary": "SAM_MATCH;SAM_PARTIAL;SAM_MISS;SAM_BLOCKER;NOT_REPORTED",
        "weight_scheme": "NONE_REQUIRED_BINARY_BLOCKER",
        "numeric_rank_score": "",
        "external_data_allowed_in_qn009": False,
    }
    if sealed_object == "network_object_grammar":
        base.update(
            {
                "required_candidate_fields": "carrier_role;control_envelope_role;boundary_sensor_role",
                "sam_match_condition": "candidate maps distinct mechanisms to carrier=QUBIT-NL-001, envelope=QUBIT-CL-001, sensor=QUBIT-UNK-001",
                "sam_partial_condition": "candidate supplies carrier plus at least one separate control/sensor role",
                "sam_blocker_condition": "candidate collapses carrier, final outcome, and control readout into one early ledger read",
            }
        )
    elif sealed_object == "link_survival_and_viability":
        base.update(
            {
                "required_candidate_fields": "carrier_isolation;active_suppression;timing_headroom;route_capacity_evidence",
                "sam_match_condition": "candidate reports protected carrier transport with active contact suppression and timing headroom",
                "sam_partial_condition": "candidate reports carrier isolation but incomplete suppression or timing evidence",
                "sam_blocker_condition": "candidate requires reading final route identity to maintain link",
            }
        )
    elif sealed_object == "ledger_safe_relay":
        base.update(
            {
                "required_candidate_fields": "relay_packet_fields;no_clone_guard;no_commit_support_surface",
                "sam_match_condition": "candidate relays allowed syndrome/pressure letters without copying final outcome or route identity",
                "sam_partial_condition": "candidate reports relay behavior but no complete no-clone/no-commit guard",
                "sam_blocker_condition": "candidate copies final outcome, clones route identity, or commits during relay",
            }
        )
    elif sealed_object == "paul_revere_routing":
        base.update(
            {
                "required_candidate_fields": "pre_resolution_letter;timing_lead;closed_window_stop_rule",
                "sam_match_condition": "candidate routes warning letters before write closure and stops once the window closes",
                "sam_partial_condition": "candidate has pre-resolution signaling but lacks a closed-window stop rule",
                "sam_blocker_condition": "candidate transmits selected final result before physical resolution",
            }
        )
    elif sealed_object == "network_born_surface":
        base.update(
            {
                "required_candidate_fields": "route_stability_surface;carrier_topology;open_closed_window_behavior",
                "sam_match_condition": "candidate route stability favors protected unresolved carrier and normalizes only over open routes",
                "sam_partial_condition": "candidate preserves unresolved route probability but lacks full open/closed window accounting",
                "sam_blocker_condition": "candidate normalizes by peeking at final ledger outcome",
            }
        )
    elif sealed_object == "letter_safe_error_correction":
        base.update(
            {
                "required_candidate_fields": "allowed_syndrome_fields;correction_latency;probability_preservation;forbidden_field_guard",
                "sam_match_condition": "candidate corrects allowed letters in real time while preserving unresolved probability surface",
                "sam_partial_condition": "candidate has syndrome correction but incomplete probability-preservation evidence",
                "sam_blocker_condition": "candidate error correction reads logical route identity or ledger commit result",
            }
        )
    elif sealed_object == "earth_a_deployment_surface":
        base.update(
            {
                "required_candidate_fields": "apparatus_controls;shielding;cooling;timing;geometry_support",
                "sam_match_condition": "candidate supplies apparatus controls rather than relying on literal Earth A",
                "sam_partial_condition": "candidate supplies some required controls but leaves one apparatus lane unresolved",
                "sam_blocker_condition": "candidate claims literal Earth gravitational A is sufficient control engine",
            }
        )
    elif sealed_object == "forbidden_leakage_invariant":
        base.update(
            {
                "required_candidate_fields": "final_outcome_access_policy;logical_route_identity_policy;pre_write_commit_policy",
                "sam_match_condition": "candidate explicitly forbids final outcome and logical route identity before selected write",
                "sam_partial_condition": "candidate forbids final outcome but does not document route identity policy",
                "sam_blocker_condition": "candidate permits final ledger outcome or logical route identity before selected write",
            }
        )
    else:
        base.update(
            {
                "required_candidate_fields": "QN010_REQUIRED",
                "sam_match_condition": "candidate satisfies sealed SAM object",
                "sam_partial_condition": "candidate partially satisfies sealed SAM object",
                "sam_blocker_condition": "candidate violates sealed SAM object",
            }
        )
    return base


def build_scoring_rules(benchmark_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    return [rule_for_benchmark(row) for row in benchmark_rows]


def build_candidate_evidence_template(benchmark_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in benchmark_rows:
        rows.append(
            {
                "candidate_id": "QN010_CANDIDATE_ID",
                "candidate_platform": "QN010_REQUIRED",
                "benchmark_id": row["benchmark_id"],
                "sealed_object": row["sealed_object"],
                "candidate_claim_summary": "QN010_REQUIRED",
                "candidate_evidence_reference": "QN010_REQUIRED",
                "candidate_observed_value": "QN010_REQUIRED",
                "candidate_comparator_status": "QN010_COMPARATOR_OUTPUT",
                "blocker_triggered": "QN010_COMPARATOR_OUTPUT",
                "external_data_allowed_in_qn009": False,
            }
        )
    return rows


def split_semicolon(value: str) -> list[str]:
    return [part.strip() for part in value.split(";") if part.strip()]


def build_leakage_screen(
    objects: list[dict[str, str]],
    correction_rules: list[dict[str, str]],
    benchmark_rows: list[dict[str, str]],
) -> list[dict[str, object]]:
    screen_terms: dict[str, dict[str, object]] = {}
    for obj in objects:
        for item in split_semicolon(obj["forbidden_content"]):
            screen_terms[item] = {
                "forbidden_item": item,
                "source": "QN001_NETWORK_OBJECT_GRAMMAR",
                "candidate_question": f"Does the candidate expose {item} before selected write?",
                "blocker_condition": f"{item} is read, copied, transmitted, or used as a control variable before selected write",
                "allowed_alternative": "transport allowed syndrome, pressure, timing, route-family, or basin-bias letters only",
            }
    for rule in correction_rules:
        for item in split_semicolon(rule["forbidden_fields"]):
            screen_terms.setdefault(
                item,
                {
                    "forbidden_item": item,
                    "source": "QN006_LETTER_SAFE_CORRECTION",
                    "candidate_question": f"Does correction logic use {item}?",
                    "blocker_condition": f"{item} is required for real-time correction",
                    "allowed_alternative": "use allowed syndrome fields and preserve unresolved probability surface",
                },
            )
    if any(row["sealed_object"] == "forbidden_leakage_invariant" for row in benchmark_rows):
        screen_terms.setdefault(
            "premature_selected_write",
            {
                "forbidden_item": "premature_selected_write",
                "source": "QN008_FORBIDDEN_LEAKAGE_INVARIANT",
                "candidate_question": "Does the candidate select the final write before physical resolution?",
                "blocker_condition": "selected write is declared before the pre-resolution window closes by SAM rules",
                "allowed_alternative": "carry Paul Revere letters until selected physical resolution",
            },
        )
    rows = []
    for idx, term in enumerate(sorted(screen_terms.values(), key=lambda row: str(row["forbidden_item"])), start=1):
        rows.append(
            {
                "screen_id": f"QN009-LEAK-{idx:02d}",
                **term,
                "comparator_status_if_triggered": "SAM_BLOCKER",
                "external_data_allowed_in_qn009": False,
            }
        )
    return rows


def build_output_schema() -> list[dict[str, object]]:
    rows = []
    for column, role, required in [
        ("candidate_id", "stable candidate identifier assigned in QN010", True),
        ("candidate_platform", "candidate hardware/protocol name assigned in QN010", True),
        ("benchmark_id", "sealed benchmark id from QN008", True),
        ("sealed_object", "sealed SAM object being compared", True),
        ("candidate_evidence_reference", "source pointer admitted only after QN010 preflight", True),
        ("candidate_observed_value", "reported platform/protocol behavior admitted only after QN010 preflight", True),
        ("candidate_comparator_status", "one of SAM_MATCH/SAM_PARTIAL/SAM_MISS/SAM_BLOCKER/NOT_REPORTED", True),
        ("blocker_triggered", "true when forbidden leakage screen is triggered", True),
        ("sam_reading", "short SAM-native interpretation of the candidate comparison", True),
    ]:
        rows.append(
            {
                "column_name": column,
                "role": role,
                "required_in_qn010": required,
                "allowed_values": "STATUS_VOCABULARY" if column == "candidate_comparator_status" else "",
                "external_data_allowed_in_qn009": False,
            }
        )
    return rows


def build_checks(
    qn008_summary: dict[str, object],
    benchmark_rows: list[dict[str, str]],
    scoring_rules: list[dict[str, object]],
    role_template: list[dict[str, object]],
    evidence_template: list[dict[str, object]],
    leakage_screen: list[dict[str, object]],
    output_schema: list[dict[str, object]],
) -> list[dict[str, object]]:
    benchmark_ids = {row["benchmark_id"] for row in benchmark_rows}
    rule_ids = {row["benchmark_id"] for row in scoring_rules}
    no_external = all(
        row.get("external_data_allowed_in_qn009") is False
        for rows in [scoring_rules, role_template, evidence_template, leakage_screen, output_schema]
        for row in rows
    )
    no_weights = all(row["weight_scheme"] == "NONE_REQUIRED_BINARY_BLOCKER" and row["numeric_rank_score"] == "" for row in scoring_rules)
    status_complete = {row["status"] for row in STATUS_VOCABULARY} == {
        "SAM_MATCH",
        "SAM_PARTIAL",
        "SAM_MISS",
        "SAM_BLOCKER",
        "NOT_REPORTED",
    }
    leakage_has_final = any("final_ledger_outcome" in str(row["forbidden_item"]) for row in leakage_screen)
    return [
        {
            "check_id": "QN009_CHECK_01",
            "check": "QN008 package is frozen before comparator schema",
            "pass": qn008_summary["result_class"] == "QN008_SEALED_LAB_BENCHMARK_MANIFEST_FROZEN",
            "detail": qn008_summary["result_class"],
        },
        {
            "check_id": "QN009_CHECK_02",
            "check": "all QN008 benchmark rows are covered by scoring rules",
            "pass": benchmark_ids == rule_ids,
            "detail": f"{len(rule_ids)}/{len(benchmark_ids)}",
        },
        {
            "check_id": "QN009_CHECK_03",
            "check": "candidate templates contain placeholders only",
            "pass": all("QN010" in row["candidate_id"] for row in role_template + evidence_template),
            "detail": len(role_template) + len(evidence_template),
        },
        {
            "check_id": "QN009_CHECK_04",
            "check": "comparator introduces no ranking weights or fitted scores",
            "pass": no_weights,
            "detail": "NONE_REQUIRED_BINARY_BLOCKER",
        },
        {
            "check_id": "QN009_CHECK_05",
            "check": "forbidden leakage screen includes final ledger outcome",
            "pass": leakage_has_final,
            "detail": len(leakage_screen),
        },
        {
            "check_id": "QN009_CHECK_06",
            "check": "status vocabulary is closed before external comparison",
            "pass": status_complete,
            "detail": ";".join(row["status"] for row in STATUS_VOCABULARY),
        },
        {
            "check_id": "QN009_CHECK_07",
            "check": "no external hardware data is admitted in QN009 schema",
            "pass": no_external,
            "detail": "templates_only",
        },
    ]


def build_wrong_controls(
    scoring_rules: list[dict[str, object]],
    role_template: list[dict[str, object]],
    evidence_template: list[dict[str, object]],
    leakage_screen: list[dict[str, object]],
) -> list[dict[str, object]]:
    non_placeholder_candidate = any(
        "QN010" not in str(row["candidate_id"]) or "QN010" not in str(row["candidate_platform"])
        for row in role_template + evidence_template
    )
    numeric_weight_used = any(str(row["numeric_rank_score"]).strip() for row in scoring_rules)
    ranking_claim = any("rank" in str(row["sam_match_condition"]).lower() for row in scoring_rules)
    final_allowed = any(
        "final_ledger_outcome" in str(row["forbidden_item"]) and str(row["comparator_status_if_triggered"]) != "SAM_BLOCKER"
        for row in leakage_screen
    )
    external_allowed = any(
        row.get("external_data_allowed_in_qn009") is True
        for rows in [scoring_rules, role_template, evidence_template, leakage_screen]
        for row in rows
    )
    return [
        {
            "control_id": "QN009_WC_01",
            "wrong_control": "real candidate hardware data enters QN009",
            "expected": False,
            "actual": non_placeholder_candidate or external_allowed,
            "pass": not (non_placeholder_candidate or external_allowed),
        },
        {
            "control_id": "QN009_WC_02",
            "wrong_control": "weighted ranking score is introduced before external comparison",
            "expected": False,
            "actual": numeric_weight_used or ranking_claim,
            "pass": not (numeric_weight_used or ranking_claim),
        },
        {
            "control_id": "QN009_WC_03",
            "wrong_control": "final ledger outcome can pass leakage screen",
            "expected": False,
            "actual": final_allowed,
            "pass": not final_allowed,
        },
        {
            "control_id": "QN009_WC_04",
            "wrong_control": "scoring schema omits blocker state",
            "expected": False,
            "actual": "SAM_BLOCKER" not in {row["status"] for row in STATUS_VOCABULARY},
            "pass": "SAM_BLOCKER" in {row["status"] for row in STATUS_VOCABULARY},
        },
        {
            "control_id": "QN009_WC_05",
            "wrong_control": "candidate evidence template already declares comparator outputs",
            "expected": False,
            "actual": any(row["candidate_comparator_status"] != "QN010_COMPARATOR_OUTPUT" for row in evidence_template),
            "pass": all(row["candidate_comparator_status"] == "QN010_COMPARATOR_OUTPUT" for row in evidence_template),
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    scoring_rules: list[dict[str, object]],
    leakage_screen: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN009 - Private Benchmark Comparator Schema

## Result

```text
{summary["result_class"]}
```

QN009 freezes the SAM quantum-network comparator grammar before candidate
hardware or protocol data enters the branch.

## Main Readout

```text
benchmark_rows_imported = {summary["benchmark_rows_imported"]}
scoring_rule_rows = {summary["scoring_rule_rows"]}
candidate_role_template_rows = {summary["candidate_role_template_rows"]}
candidate_evidence_template_rows = {summary["candidate_evidence_template_rows"]}
forbidden_leakage_screen_rows = {summary["forbidden_leakage_screen_rows"]}
status_vocabulary_rows = {summary["status_vocabulary_rows"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
external_quantum_network_data_used = {summary["external_quantum_network_data_used"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Comparator Rule Surface

{markdown_table(scoring_rules, ["benchmark_id", "sealed_object", "required_candidate_fields", "sam_match_condition", "sam_blocker_condition"])}

## Forbidden Leakage Screen

{markdown_table(leakage_screen, ["screen_id", "forbidden_item", "source", "comparator_status_if_triggered"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

QN009 turns the sealed QN008 package into a comparison interface:

```text
candidate roles are mapped to sealed SAM network objects
candidate evidence is collected per sealed benchmark object
comparison status is closed before external data enters
forbidden leakage is a blocker, not a soft penalty
no ranking weights or fitted platform scores are introduced
```

The result is a ready shell for QN010 approved external comparison.

## Outputs

```text
artifacts/qn009/qn009_preflight.md
artifacts/qn009/qn009_input_manifest.csv
artifacts/qn009/candidate_hardware_role_map_template.csv
artifacts/qn009/candidate_benchmark_evidence_template.csv
artifacts/qn009/sam_qn_benchmark_scoring_rules.csv
artifacts/qn009/forbidden_leakage_screen.csv
artifacts/qn009/sam_qn_comparator_output_schema.csv
artifacts/qn009/qn009_checks.csv
artifacts/qn009/qn009_wrong_controls.csv
artifacts/qn009/qn009_summary.json
artifacts/qn009/qn009_next_frontier.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = [
        QN008_SUMMARY,
        QN008_BENCHMARK_MANIFEST,
        QN008_FORMULA_FREEZE,
        QN008_HASH_MANIFEST,
        QN008_EXCLUSION,
        QN001_OBJECTS,
        QN006_CORRECTION_RULES,
        QN007_REQUIREMENTS,
    ]
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])
    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN009 inputs: {missing}")

    qn008_summary = read_json(QN008_SUMMARY)
    benchmark_rows = read_csv(QN008_BENCHMARK_MANIFEST)
    formula_rows = read_csv(QN008_FORMULA_FREEZE)
    hash_rows = read_csv(QN008_HASH_MANIFEST)
    objects = read_csv(QN001_OBJECTS)
    correction_rules = read_csv(QN006_CORRECTION_RULES)
    requirements = read_csv(QN007_REQUIREMENTS)

    role_template = build_candidate_role_template(objects, requirements)
    evidence_template = build_candidate_evidence_template(benchmark_rows)
    scoring_rules = build_scoring_rules(benchmark_rows)
    leakage_screen = build_leakage_screen(objects, correction_rules, benchmark_rows)
    output_schema = build_output_schema()
    checks = build_checks(
        qn008_summary,
        benchmark_rows,
        scoring_rules,
        role_template,
        evidence_template,
        leakage_screen,
        output_schema,
    )
    wrong_controls = build_wrong_controls(scoring_rules, role_template, evidence_template, leakage_screen)

    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)
    all_qn008_inputs_external_frozen = all(not is_true(row["external_data_allowed_before_manifest"]) for row in benchmark_rows + formula_rows)
    all_hashes_present = all(len(row["sha256"]) == 64 for row in hash_rows)

    summary = {
        "artifact": "QN009_PRIVATE_BENCHMARK_COMPARATOR_SCHEMA",
        "result_class": "QN009_BENCHMARK_COMPARATOR_SCHEMA_FROZEN",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_BENCHMARK_COMPARATOR_SCHEMA_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": False,
        "free_parameters_introduced": 0,
        "qn008_result_class": qn008_summary["result_class"],
        "benchmark_rows_imported": len(benchmark_rows),
        "formula_freeze_rows_imported": len(formula_rows),
        "hash_rows_imported": len(hash_rows),
        "sealed_hashes_present": all_hashes_present,
        "candidate_role_template_rows": len(role_template),
        "candidate_evidence_template_rows": len(evidence_template),
        "scoring_rule_rows": len(scoring_rules),
        "forbidden_leakage_screen_rows": len(leakage_screen),
        "comparator_output_schema_rows": len(output_schema),
        "status_vocabulary_rows": len(STATUS_VOCABULARY),
        "all_qn008_inputs_external_frozen": all_qn008_inputs_external_frozen,
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "forbidden_fields_used": False,
        "next_frontier": "QN010_PRIVATE_APPROVED_EXTERNAL_BENCHMARK_COMPARISON_REQUIRES_PREFLIGHT",
    }

    write_csv(
        CANDIDATE_ROLE_TEMPLATE_OUT,
        role_template,
        [
            "candidate_id",
            "candidate_platform",
            "sam_network_object_id",
            "sam_object_class",
            "sam_selected_route",
            "sam_selected_family",
            "sam_permission",
            "permitted_pre_resolution_content",
            "forbidden_content",
            "required_candidate_mechanism",
            "candidate_mechanism_reported",
            "candidate_evidence_reference",
            "candidate_role_status",
            "external_data_allowed_in_qn009",
        ],
    )
    write_csv(
        CANDIDATE_EVIDENCE_TEMPLATE_OUT,
        evidence_template,
        [
            "candidate_id",
            "candidate_platform",
            "benchmark_id",
            "sealed_object",
            "candidate_claim_summary",
            "candidate_evidence_reference",
            "candidate_observed_value",
            "candidate_comparator_status",
            "blocker_triggered",
            "external_data_allowed_in_qn009",
        ],
    )
    write_csv(
        SCORING_RULES_OUT,
        scoring_rules,
        [
            "rule_id",
            "benchmark_id",
            "sealed_object",
            "sealed_value",
            "required_candidate_fields",
            "sam_match_condition",
            "sam_partial_condition",
            "sam_blocker_condition",
            "status_vocabulary",
            "weight_scheme",
            "numeric_rank_score",
            "external_data_allowed_in_qn009",
        ],
    )
    write_csv(
        LEAKAGE_SCREEN_OUT,
        leakage_screen,
        [
            "screen_id",
            "forbidden_item",
            "source",
            "candidate_question",
            "blocker_condition",
            "allowed_alternative",
            "comparator_status_if_triggered",
            "external_data_allowed_in_qn009",
        ],
    )
    write_csv(
        COMPARATOR_OUTPUT_SCHEMA_OUT,
        output_schema,
        ["column_name", "role", "required_in_qn010", "allowed_values", "external_data_allowed_in_qn009"],
    )
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, scoring_rules, leakage_screen, checks, wrong_controls)


if __name__ == "__main__":
    main()
