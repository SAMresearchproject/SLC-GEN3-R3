from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN010_DIR = ARTIFACTS / "qn010"

QN009_SUMMARY = ARTIFACTS / "qn009" / "qn009_summary.json"
QN009_SCORING_RULES = ARTIFACTS / "qn009" / "sam_qn_benchmark_scoring_rules.csv"
QN009_ROLE_TEMPLATE = ARTIFACTS / "qn009" / "candidate_hardware_role_map_template.csv"
QN009_EVIDENCE_TEMPLATE = ARTIFACTS / "qn009" / "candidate_benchmark_evidence_template.csv"
QN009_LEAKAGE_SCREEN = ARTIFACTS / "qn009" / "forbidden_leakage_screen.csv"

PREFLIGHT_OUT = QN010_DIR / "qn010_preflight.md"
INPUT_MANIFEST_OUT = QN010_DIR / "qn010_input_manifest.csv"
EXTERNAL_SOURCE_MANIFEST_OUT = QN010_DIR / "external_quantum_network_source_manifest.csv"
CANDIDATE_FACTS_OUT = QN010_DIR / "candidate_platform_fact_table.csv"
CANDIDATE_COMPARISON_OUT = QN010_DIR / "candidate_benchmark_comparison.csv"
CANDIDATE_SUMMARY_OUT = QN010_DIR / "candidate_alignment_summary.csv"
CHECKS_OUT = QN010_DIR / "qn010_checks.csv"
WRONG_CONTROLS_OUT = QN010_DIR / "qn010_wrong_controls.csv"
SUMMARY_OUT = QN010_DIR / "qn010_summary.json"
NEXT_OUT = QN010_DIR / "qn010_next_frontier.csv"
REPORT_OUT = REPORTS / "QN010_PRIVATE_APPROVED_EXTERNAL_BENCHMARK_COMPARISON.md"


SOURCE_ROWS = [
    {
        "source_id": "SRC-DOE-QN-001",
        "source_name": "DOE Explains Quantum Networks",
        "source_url": "https://www.energy.gov/science/doe-explainsquantum-networks",
        "source_type": "government_overview",
        "external_fact_used": "quantum networks use photons, superposition, no-cloning, entanglement, repeaters, flying-qubit routing, and error correction goals",
    },
    {
        "source_id": "SRC-NIST-ION-001",
        "source_name": "NIST Quantum Networking with Trapped Ions in Optical Cavities",
        "source_url": "https://www.nist.gov/programs-projects/quantum-networking-trapped-ions-optical-cavities",
        "source_type": "government_research_program",
        "external_fact_used": "trapped-ion stationary qubits coupled to 1550 nm flying photons for remote entanglement and entanglement swapping",
    },
    {
        "source_id": "SRC-NIST-TECH-001",
        "source_name": "NIST Technologies for Quantum Networks",
        "source_url": "https://www.nist.gov/pml/productsservices/quantum-networks-nist/technologies-quantum-networks",
        "source_type": "government_technology_map",
        "external_fact_used": "quantum network architectures require switches, repeaters, modular processors, frequency converters, photons, and different material systems",
    },
    {
        "source_id": "SRC-RFC9340-001",
        "source_name": "RFC 9340 Architectural Principles for a Quantum Internet",
        "source_url": "https://www.rfc-editor.org/rfc/rfc9340.html",
        "source_type": "standards_architecture",
        "external_fact_used": "quantum network end nodes, quantum links, Bell-pair connectivity, entanglement swapping, repeaters, transduction, and heterogeneous platforms",
    },
    {
        "source_id": "SRC-QUTECH-001",
        "source_name": "QuTech Quantum Internet Milestones",
        "source_url": "https://qutech.nl/research-engineering/quantum-internet/quantum-internet-milestones/",
        "source_type": "research_program_milestones",
        "external_fact_used": "multi-node quantum network connecting three quantum processors and link-layer protocol development",
    },
    {
        "source_id": "SRC-QUNNECT-CISCO-001",
        "source_name": "Qunnect and Cisco Metro-Scale Entanglement Swapping",
        "source_url": "https://www.qunnect.inc/press-releases/2026-02-18",
        "source_type": "company_press_release",
        "external_fact_used": "deployed-fiber entanglement swapping, Carina entangled-photon system, Cisco orchestration, room-temperature endpoints, automated polarization compensation",
    },
    {
        "source_id": "SRC-IONQ-001",
        "source_name": "IonQ Photonic Interconnect Milestone",
        "source_url": "https://www.ionq.com/news/ionq-achieves-key-photonic-interconnect-milestone-demonstrating-networked-quantum-systems-using-entanglement",
        "source_type": "company_press_release",
        "external_fact_used": "two independent trapped-ion systems photonically interconnected using photons to enable entanglement while preserving coherence",
    },
    {
        "source_id": "SRC-AWS-REPEATER-001",
        "source_name": "AWS Illustrated Introduction to Quantum Networks and Quantum Repeaters",
        "source_url": "https://aws.amazon.com/blogs/quantum-computing/an-illustrated-introduction-to-quantum-networks-and-quantum-repeaters/",
        "source_type": "company_research_explainer",
        "external_fact_used": "repeaters use quantum memories to catch/store photons without measuring them and entanglement swapping extends links; large-scale repeaters remain in development",
    },
]


CANDIDATE_FACTS = [
    {
        "candidate_id": "QN010-CAND-001",
        "candidate_platform": "Qunnect_Cisco_metro_photonic_entanglement_swap",
        "candidate_family": "DEPLOYED_PHOTONIC_ENTANGLEMENT_NETWORK",
        "source_ids": "SRC-QUNNECT-CISCO-001;SRC-DOE-QN-001;SRC-RFC9340-001",
        "carrier_mechanism": "entangled photons over deployed commercial fiber",
        "stationary_or_support_mechanism": "room-temperature endpoints; central hub; commercial fiber; Carina source; Cisco orchestration",
        "relay_or_routing_mechanism": "entanglement swapping with automated orchestration and polarization compensation",
        "reported_controls": "independent entanglement sources; automatic polarization compensation; software orchestration; deployed-fiber operation",
        "reported_limitation": "final-outcome policy and SAM open/closed write-window behavior not reported in SAM terms",
    },
    {
        "candidate_id": "QN010-CAND-002",
        "candidate_platform": "NIST_trapped_ion_photonic_repeater_node",
        "candidate_family": "STATIONARY_ION_PLUS_FLYING_PHOTON_NODE",
        "source_ids": "SRC-NIST-ION-001;SRC-NIST-TECH-001;SRC-DOE-QN-001;SRC-RFC9340-001",
        "carrier_mechanism": "1550 nm optical photons as flying qubits",
        "stationary_or_support_mechanism": "trapped ions as stationary qubits with long coherence and high-fidelity control/readout",
        "relay_or_routing_mechanism": "repeater-node entanglement swapping architecture",
        "reported_controls": "cavity-integrated ion trap; coherent photon conversion; local multi-qubit preservation and manipulation",
        "reported_limitation": "research program; full deployed benchmark and SAM real-time correction policy not reported",
    },
    {
        "candidate_id": "QN010-CAND-003",
        "candidate_platform": "QuTech_multi_node_quantum_internet_stack",
        "candidate_family": "MULTI_NODE_PROCESSOR_ENTANGLEMENT_NETWORK",
        "source_ids": "SRC-QUTECH-001;SRC-RFC9340-001;SRC-DOE-QN-001",
        "carrier_mechanism": "entanglement between fiber-connected quantum nodes",
        "stationary_or_support_mechanism": "quantum processors as network nodes",
        "relay_or_routing_mechanism": "multi-node quantum network and link-layer protocol work",
        "reported_controls": "network stack design; link-layer protocol; multi-node entanglement milestones",
        "reported_limitation": "full long-distance repeater, Born-surface behavior, and SAM leakage policy not reported",
    },
    {
        "candidate_id": "QN010-CAND-004",
        "candidate_platform": "IonQ_trapped_ion_photonic_interconnect",
        "candidate_family": "MODULAR_TRAPPED_ION_PHOTONIC_INTERCONNECT",
        "source_ids": "SRC-IONQ-001;SRC-DOE-QN-001;SRC-RFC9340-001",
        "carrier_mechanism": "photonic interconnect between trapped-ion systems",
        "stationary_or_support_mechanism": "two independent trapped-ion quantum systems",
        "relay_or_routing_mechanism": "generation, transmission, and detection of photons enabling entanglement",
        "reported_controls": "coherence-preserving photonic link between commercial quantum systems",
        "reported_limitation": "two-system interconnect milestone; repeater, routing, and correction layers not yet reported",
    },
    {
        "candidate_id": "QN010-CAND-005",
        "candidate_platform": "AWS_memory_repeater_architecture",
        "candidate_family": "MEMORY_ASSISTED_REPEATER_RESEARCH",
        "source_ids": "SRC-AWS-REPEATER-001;SRC-DOE-QN-001;SRC-RFC9340-001",
        "carrier_mechanism": "photons whose quantum information is caught by repeater memories",
        "stationary_or_support_mechanism": "quantum memories and solid-state qubits in repeater stations",
        "relay_or_routing_mechanism": "entanglement swapping chain with stored qubits",
        "reported_controls": "store without measuring; continue attempts on failed links; swap after links establish entanglement",
        "reported_limitation": "large-scale quantum repeaters are still in development",
    },
]


COMPARISON_STATUSES = {
    "QN010-CAND-001": {
        "QN-BENCH-001": ("SAM_MATCH", "photonic carrier, stabilization/control layer, hub/endpoints, and orchestration provide separated network roles", "SRC-QUNNECT-CISCO-001"),
        "QN-BENCH-002": ("SAM_MATCH", "deployed-fiber entanglement swapping reports active polarization compensation and high-fidelity link behavior", "SRC-QUNNECT-CISCO-001"),
        "QN-BENCH-003": ("SAM_MATCH", "entanglement swapping over deployed fiber directly matches relay-style extension", "SRC-QUNNECT-CISCO-001;SRC-RFC9340-001"),
        "QN-BENCH-004": ("SAM_PARTIAL", "software orchestration is reported, but SAM pre-resolution letter timing and closed-window stop rule are not reported", "SRC-QUNNECT-CISCO-001"),
        "QN-BENCH-005": ("SAM_PARTIAL", "route stability evidence exists through fidelity/stabilization, but SAM open/closed Born window accounting is not reported", "SRC-QUNNECT-CISCO-001"),
        "QN-BENCH-006": ("SAM_PARTIAL", "polarization compensation is active correction, but SAM letter-safe probability-preserving correction is not reported", "SRC-QUNNECT-CISCO-001"),
        "QN-BENCH-007": ("SAM_MATCH", "apparatus supplies controls through sources, compensation, software orchestration, endpoints, and hub geometry", "SRC-QUNNECT-CISCO-001"),
        "QN-BENCH-008": ("SAM_PARTIAL", "quantum-network no-cloning background applies, but explicit SAM final-outcome policy is not reported", "SRC-DOE-QN-001"),
    },
    "QN010-CAND-002": {
        "QN-BENCH-001": ("SAM_MATCH", "stationary trapped ions plus 1550 nm flying photons map cleanly to node/carrier separation", "SRC-NIST-ION-001"),
        "QN-BENCH-002": ("SAM_PARTIAL", "NIST reports fiber survival constraints and coherent interfaces, but not a deployed comparator benchmark", "SRC-NIST-ION-001"),
        "QN-BENCH-003": ("SAM_MATCH", "the node is explicitly designed for preserving/manipulating local states needed for entanglement swapping", "SRC-NIST-ION-001"),
        "QN-BENCH-004": ("NOT_REPORTED", "pre-resolution routing letters and closed-window stop behavior are not reported", "SRC-NIST-ION-001"),
        "QN-BENCH-005": ("NOT_REPORTED", "no SAM-style route probability surface is reported", "SRC-NIST-ION-001"),
        "QN-BENCH-006": ("SAM_PARTIAL", "high-fidelity control/readout and state preservation support correction, but SAM letter-safe correction is not reported", "SRC-NIST-ION-001"),
        "QN-BENCH-007": ("SAM_MATCH", "apparatus clearly supplies traps, cavities, conversion, timing, and optical controls", "SRC-NIST-ION-001"),
        "QN-BENCH-008": ("SAM_PARTIAL", "no-cloning and measurement-disturbance constraints apply generally, but explicit SAM leakage policy is not reported", "SRC-DOE-QN-001"),
    },
    "QN010-CAND-003": {
        "QN-BENCH-001": ("SAM_PARTIAL", "multi-node processors and entanglement links supply nodes/carrier behavior, but SAM role triad is not explicit", "SRC-QUTECH-001"),
        "QN-BENCH-002": ("SAM_PARTIAL", "fiber-connected entanglement milestones exist, but no QN009 link-survival fields are fully reported", "SRC-QUTECH-001"),
        "QN-BENCH-003": ("SAM_PARTIAL", "multi-node network supports relay direction, but full repeater behavior is a separate milestone", "SRC-QUTECH-001"),
        "QN-BENCH-004": ("SAM_MATCH", "link-layer protocol work maps strongly to making entanglement a defined network service", "SRC-QUTECH-001"),
        "QN-BENCH-005": ("NOT_REPORTED", "no SAM-style network Born surface is reported", "SRC-QUTECH-001"),
        "QN-BENCH-006": ("NOT_REPORTED", "SAM letter-safe correction fields are not reported", "SRC-QUTECH-001"),
        "QN-BENCH-007": ("SAM_PARTIAL", "hardware and software stack controls are reported at architecture level", "SRC-QUTECH-001"),
        "QN-BENCH-008": ("SAM_PARTIAL", "quantum-network no-cloning background applies, but explicit SAM final-outcome policy is not reported", "SRC-DOE-QN-001"),
    },
    "QN010-CAND-004": {
        "QN-BENCH-001": ("SAM_MATCH", "two trapped-ion systems connected photonically map to separated stationary nodes and flying carrier", "SRC-IONQ-001"),
        "QN-BENCH-002": ("SAM_PARTIAL", "photonic generation/transmission/detection and coherence preservation are reported, but not full QN009 link controls", "SRC-IONQ-001"),
        "QN-BENCH-003": ("NOT_REPORTED", "repeater or entanglement-swapping relay behavior is not reported for this milestone", "SRC-IONQ-001"),
        "QN-BENCH-004": ("NOT_REPORTED", "routing protocol and closed-window behavior are not reported", "SRC-IONQ-001"),
        "QN-BENCH-005": ("NOT_REPORTED", "SAM-style route probability surface is not reported", "SRC-IONQ-001"),
        "QN-BENCH-006": ("NOT_REPORTED", "letter-safe real-time correction is not reported", "SRC-IONQ-001"),
        "QN-BENCH-007": ("SAM_PARTIAL", "apparatus controls are implied by trapped-ion and photonic interconnect hardware, but deployment lanes are not detailed", "SRC-IONQ-001"),
        "QN-BENCH-008": ("SAM_PARTIAL", "coherence preservation is reported, but explicit SAM leakage policy is not reported", "SRC-IONQ-001"),
    },
    "QN010-CAND-005": {
        "QN-BENCH-001": ("SAM_PARTIAL", "photons plus quantum memories/repeater stations map to carrier/support roles but not full candidate implementation", "SRC-AWS-REPEATER-001"),
        "QN-BENCH-002": ("SAM_PARTIAL", "repeaters improve long-link generation rate, but large-scale operational evidence is still in development", "SRC-AWS-REPEATER-001"),
        "QN-BENCH-003": ("SAM_MATCH", "quantum memories catch/store photons without measuring and entanglement swaps deliver long-distance entanglement", "SRC-AWS-REPEATER-001"),
        "QN-BENCH-004": ("SAM_PARTIAL", "repeaters continue failed-link attempts while others store entanglement, but Paul Revere routing fields are not explicit", "SRC-AWS-REPEATER-001"),
        "QN-BENCH-005": ("NOT_REPORTED", "no SAM-style network Born surface is reported", "SRC-AWS-REPEATER-001"),
        "QN-BENCH-006": ("SAM_PARTIAL", "store-without-measuring behavior supports letter-safe correction direction, but correction protocol is not reported", "SRC-AWS-REPEATER-001"),
        "QN-BENCH-007": ("SAM_PARTIAL", "apparatus/repeater controls are part of the architecture, but deployment surface is research-stage", "SRC-AWS-REPEATER-001"),
        "QN-BENCH-008": ("SAM_PARTIAL", "storing without measuring supports leakage discipline, but explicit SAM final-outcome policy is not reported", "SRC-AWS-REPEATER-001"),
    },
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QN010_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN010 Preflight - Approved External Benchmark Comparison

## Mode

```text
FORWARD_APPROVED_EXTERNAL_BENCHMARK_COMPARISON
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
external_data_allowed = true
```

QN010 does not rerun QN001-QN009. QN009 already froze the comparator schema.
QN010 is the first gate where external quantum-network platform facts enter,
and every external fact must be source-manifested before comparison.

## Question

```text
Which current quantum-network platform families line up best with the sealed
SAM QN001-QN009 comparator?
```

## Success Condition

```text
Every candidate comparison row cites external source IDs, uses the frozen
QN009 status vocabulary, triggers SAM_BLOCKER for forbidden leakage if present,
and introduces no fitted platform weights.
```
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "source_role": "FROZEN_QN009_INPUT",
        }
        for path in paths
    ]


def add_retrieval_metadata(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    retrieved = datetime.now(timezone.utc).isoformat()
    return [{**row, "retrieved_at_utc": retrieved} for row in rows]


def build_comparison_rows(candidates: list[dict[str, object]], scoring_rules: list[dict[str, str]]) -> list[dict[str, object]]:
    rule_by_benchmark = {row["benchmark_id"]: row for row in scoring_rules}
    rows: list[dict[str, object]] = []
    for candidate in candidates:
        statuses = COMPARISON_STATUSES[candidate["candidate_id"]]
        for benchmark_id in sorted(rule_by_benchmark):
            rule = rule_by_benchmark[benchmark_id]
            status, reading, source_ids = statuses[benchmark_id]
            rows.append(
                {
                    "candidate_id": candidate["candidate_id"],
                    "candidate_platform": candidate["candidate_platform"],
                    "candidate_family": candidate["candidate_family"],
                    "benchmark_id": benchmark_id,
                    "sealed_object": rule["sealed_object"],
                    "candidate_comparator_status": status,
                    "blocker_triggered": status == "SAM_BLOCKER",
                    "source_ids": source_ids,
                    "sam_reading": reading,
                    "status_basis": rule["sam_match_condition"] if status == "SAM_MATCH" else rule["sam_partial_condition"] if status == "SAM_PARTIAL" else rule["sam_blocker_condition"] if status == "SAM_BLOCKER" else "candidate source does not report this sealed SAM field",
                    "fitted_weight_or_score_used": False,
                }
            )
    return rows


def build_candidate_summary(comparison_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    by_candidate: dict[str, list[dict[str, object]]] = {}
    for row in comparison_rows:
        by_candidate.setdefault(str(row["candidate_id"]), []).append(row)
    for candidate in CANDIDATE_FACTS:
        candidate_rows = by_candidate[candidate["candidate_id"]]
        counts = {status: sum(row["candidate_comparator_status"] == status for row in candidate_rows) for status in ["SAM_MATCH", "SAM_PARTIAL", "SAM_MISS", "SAM_BLOCKER", "NOT_REPORTED"]}
        if counts["SAM_BLOCKER"]:
            alignment_class = "BLOCKED_BY_LEAKAGE_OR_LEDGER_RULE"
        elif counts["SAM_MATCH"] >= 4:
            alignment_class = "STRONGEST_QN010_ALIGNMENT"
        elif counts["SAM_MATCH"] >= 2:
            alignment_class = "PROMISING_PARTIAL_ALIGNMENT"
        elif counts["SAM_PARTIAL"] >= 4:
            alignment_class = "ARCHITECTURE_DIRECTION_ALIGNMENT"
        else:
            alignment_class = "LOW_REPORTED_ALIGNMENT"
        rows.append(
            {
                "candidate_id": candidate["candidate_id"],
                "candidate_platform": candidate["candidate_platform"],
                "candidate_family": candidate["candidate_family"],
                "match_count": counts["SAM_MATCH"],
                "partial_count": counts["SAM_PARTIAL"],
                "miss_count": counts["SAM_MISS"],
                "blocker_count": counts["SAM_BLOCKER"],
                "not_reported_count": counts["NOT_REPORTED"],
                "alignment_class": alignment_class,
                "source_ids": candidate["source_ids"],
                "SAM_reading": "photonic entanglement with separated apparatus controls is the clearest current external alignment" if alignment_class == "STRONGEST_QN010_ALIGNMENT" else "candidate contributes a useful subset of the sealed QN comparator",
            }
        )
    return sorted(
        rows,
        key=lambda row: (
            int(row["blocker_count"]),
            -int(row["match_count"]),
            -int(row["partial_count"]),
            int(row["not_reported_count"]),
            str(row["candidate_id"]),
        ),
    )


def source_ids_available(rows: list[dict[str, object]], source_rows: list[dict[str, object]]) -> bool:
    source_ids = {row["source_id"] for row in source_rows}
    for row in rows:
        for source_id in str(row["source_ids"]).split(";"):
            if source_id and source_id not in source_ids:
                return False
    return True


def build_checks(
    qn009_summary: dict[str, object],
    source_rows: list[dict[str, object]],
    comparison_rows: list[dict[str, object]],
    summary_rows: list[dict[str, object]],
    scoring_rules: list[dict[str, str]],
    leakage_rows: list[dict[str, str]],
) -> list[dict[str, object]]:
    valid_statuses = {"SAM_MATCH", "SAM_PARTIAL", "SAM_MISS", "SAM_BLOCKER", "NOT_REPORTED"}
    all_source_refs_available = source_ids_available(comparison_rows, source_rows) and source_ids_available(summary_rows, source_rows)
    all_statuses_valid = all(row["candidate_comparator_status"] in valid_statuses for row in comparison_rows)
    all_benchmarks_covered = all(
        {row["benchmark_id"] for row in comparison_rows if row["candidate_id"] == candidate["candidate_id"]}
        == {rule["benchmark_id"] for rule in scoring_rules}
        for candidate in CANDIDATE_FACTS
    )
    no_fitted_weights = all(row["fitted_weight_or_score_used"] is False for row in comparison_rows)
    leakage_items = {row["forbidden_item"] for row in leakage_rows}
    final_leak_screened = "final_ledger_outcome" in leakage_items and "logical_route_identity" in leakage_items
    return [
        {
            "check_id": "QN010_CHECK_01",
            "check": "QN009 comparator schema is frozen before external comparison",
            "pass": qn009_summary["result_class"] == "QN009_BENCHMARK_COMPARATOR_SCHEMA_FROZEN",
            "detail": qn009_summary["result_class"],
        },
        {
            "check_id": "QN010_CHECK_02",
            "check": "every candidate covers every sealed benchmark row",
            "pass": all_benchmarks_covered,
            "detail": f"{len(comparison_rows)} rows",
        },
        {
            "check_id": "QN010_CHECK_03",
            "check": "every comparison row cites known external source IDs",
            "pass": all_source_refs_available,
            "detail": f"{len(source_rows)} sources",
        },
        {
            "check_id": "QN010_CHECK_04",
            "check": "only frozen QN009 status vocabulary is used",
            "pass": all_statuses_valid,
            "detail": ";".join(sorted(valid_statuses)),
        },
        {
            "check_id": "QN010_CHECK_05",
            "check": "no fitted ranking weights or platform scores are introduced",
            "pass": no_fitted_weights,
            "detail": "count statuses only",
        },
        {
            "check_id": "QN010_CHECK_06",
            "check": "forbidden leakage screen remains active in external comparison",
            "pass": final_leak_screened,
            "detail": f"{len(leakage_rows)} leakage rows",
        },
        {
            "check_id": "QN010_CHECK_07",
            "check": "at least one candidate reaches strongest alignment without blockers",
            "pass": any(row["alignment_class"] == "STRONGEST_QN010_ALIGNMENT" and int(row["blocker_count"]) == 0 for row in summary_rows),
            "detail": ";".join(row["candidate_id"] for row in summary_rows if row["alignment_class"] == "STRONGEST_QN010_ALIGNMENT"),
        },
    ]


def build_wrong_controls(
    comparison_rows: list[dict[str, object]],
    source_rows: list[dict[str, object]],
    qn009_summary: dict[str, object],
) -> list[dict[str, object]]:
    source_urls_present = all(str(row["source_url"]).startswith("https://") for row in source_rows)
    external_before_qn009 = qn009_summary["external_quantum_network_data_used"] is True
    unsupported_matches = any(row["candidate_comparator_status"] == "SAM_MATCH" and not str(row["source_ids"]).strip() for row in comparison_rows)
    blocker_without_blocker_status = any(row["blocker_triggered"] is True and row["candidate_comparator_status"] != "SAM_BLOCKER" for row in comparison_rows)
    fitted_score = any(row["fitted_weight_or_score_used"] is True for row in comparison_rows)
    return [
        {
            "control_id": "QN010_WC_01",
            "wrong_control": "external platform data entered before QN009 freeze",
            "expected": False,
            "actual": external_before_qn009,
            "pass": not external_before_qn009,
        },
        {
            "control_id": "QN010_WC_02",
            "wrong_control": "external source lacks URL provenance",
            "expected": False,
            "actual": not source_urls_present,
            "pass": source_urls_present,
        },
        {
            "control_id": "QN010_WC_03",
            "wrong_control": "SAM_MATCH status is assigned without external source support",
            "expected": False,
            "actual": unsupported_matches,
            "pass": not unsupported_matches,
        },
        {
            "control_id": "QN010_WC_04",
            "wrong_control": "leakage blocker does not force SAM_BLOCKER",
            "expected": False,
            "actual": blocker_without_blocker_status,
            "pass": not blocker_without_blocker_status,
        },
        {
            "control_id": "QN010_WC_05",
            "wrong_control": "fitted numerical platform score is introduced",
            "expected": False,
            "actual": fitted_score,
            "pass": not fitted_score,
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    candidate_summary: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN010 - Private Approved External Benchmark Comparison

## Result

```text
{summary["result_class"]}
```

QN010 is the first SAM quantum-network gate that admits external platform
facts after the QN009 comparator schema freeze.

## Main Readout

```text
candidate_platforms = {summary["candidate_platforms"]}
external_sources_used = {summary["external_sources_used"]}
comparison_rows = {summary["comparison_rows"]}
strongest_candidate = {summary["strongest_candidate"]}
strongest_candidate_match_count = {summary["strongest_candidate_match_count"]}
strongest_candidate_partial_count = {summary["strongest_candidate_partial_count"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
external_quantum_network_data_used = {summary["external_quantum_network_data_used"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Candidate Alignment Summary

{markdown_table(candidate_summary, ["candidate_id", "candidate_platform", "match_count", "partial_count", "blocker_count", "not_reported_count", "alignment_class"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

The first external comparison lands where SAM expected:

```text
best current alignment is photonic entanglement over fiber with separated
apparatus controls, relay/orchestration behavior, and no-cloning/measurement
discipline.
```

Qunnect/Cisco-style deployed photonic entanglement swapping is the strongest
QN010 alignment because it simultaneously supplies a flying photonic carrier,
deployed fiber, entanglement swapping, active stabilization, and apparatus
orchestration. Trapped-ion photonic nodes and memory-assisted repeater
architectures are strong supporting lanes because they supply the stationary
node/repeater side of the same SAM network picture.

## Outputs

```text
artifacts/qn010/qn010_preflight.md
artifacts/qn010/qn010_input_manifest.csv
artifacts/qn010/external_quantum_network_source_manifest.csv
artifacts/qn010/candidate_platform_fact_table.csv
artifacts/qn010/candidate_benchmark_comparison.csv
artifacts/qn010/candidate_alignment_summary.csv
artifacts/qn010/qn010_checks.csv
artifacts/qn010/qn010_wrong_controls.csv
artifacts/qn010/qn010_summary.json
artifacts/qn010/qn010_next_frontier.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = [
        QN009_SUMMARY,
        QN009_SCORING_RULES,
        QN009_ROLE_TEMPLATE,
        QN009_EVIDENCE_TEMPLATE,
        QN009_LEAKAGE_SCREEN,
    ]
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])
    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN010 inputs: {missing}")

    qn009_summary = read_json(QN009_SUMMARY)
    scoring_rules = read_csv(QN009_SCORING_RULES)
    leakage_rows = read_csv(QN009_LEAKAGE_SCREEN)
    source_rows = add_retrieval_metadata(SOURCE_ROWS)
    candidate_facts = add_retrieval_metadata(CANDIDATE_FACTS)
    comparison_rows = build_comparison_rows(candidate_facts, scoring_rules)
    candidate_summary = build_candidate_summary(comparison_rows)
    checks = build_checks(qn009_summary, source_rows, comparison_rows, candidate_summary, scoring_rules, leakage_rows)
    wrong_controls = build_wrong_controls(comparison_rows, source_rows, qn009_summary)
    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)
    strongest = candidate_summary[0]

    summary = {
        "artifact": "QN010_PRIVATE_APPROVED_EXTERNAL_BENCHMARK_COMPARISON",
        "result_class": "QN010_EXTERNAL_BENCHMARK_COMPARISON_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_PLUS_APPROVED_EXTERNAL_QN_SOURCES",
        "test_type": "FORWARD_APPROVED_EXTERNAL_BENCHMARK_COMPARISON",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": True,
        "external_data_allowed_by": "QN009_BENCHMARK_COMPARATOR_SCHEMA_FROZEN",
        "free_parameters_introduced": 0,
        "qn009_result_class": qn009_summary["result_class"],
        "candidate_platforms": len(candidate_facts),
        "external_sources_used": len(source_rows),
        "comparison_rows": len(comparison_rows),
        "candidate_summary_rows": len(candidate_summary),
        "strongest_candidate": strongest["candidate_platform"],
        "strongest_candidate_id": strongest["candidate_id"],
        "strongest_candidate_match_count": strongest["match_count"],
        "strongest_candidate_partial_count": strongest["partial_count"],
        "strongest_candidate_blocker_count": strongest["blocker_count"],
        "status_method": "count frozen status vocabulary; no fitted platform weights",
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "forbidden_fields_used": False,
        "next_frontier": "QN011_PRIVATE_PLATFORM_REQUIREMENT_TO_EXPERIMENTAL_PROTOCOL_TRANSLATION",
    }

    write_csv(
        EXTERNAL_SOURCE_MANIFEST_OUT,
        source_rows,
        ["source_id", "source_name", "source_url", "source_type", "external_fact_used", "retrieved_at_utc"],
    )
    write_csv(
        CANDIDATE_FACTS_OUT,
        candidate_facts,
        [
            "candidate_id",
            "candidate_platform",
            "candidate_family",
            "source_ids",
            "carrier_mechanism",
            "stationary_or_support_mechanism",
            "relay_or_routing_mechanism",
            "reported_controls",
            "reported_limitation",
            "retrieved_at_utc",
        ],
    )
    write_csv(
        CANDIDATE_COMPARISON_OUT,
        comparison_rows,
        [
            "candidate_id",
            "candidate_platform",
            "candidate_family",
            "benchmark_id",
            "sealed_object",
            "candidate_comparator_status",
            "blocker_triggered",
            "source_ids",
            "sam_reading",
            "status_basis",
            "fitted_weight_or_score_used",
        ],
    )
    write_csv(
        CANDIDATE_SUMMARY_OUT,
        candidate_summary,
        [
            "candidate_id",
            "candidate_platform",
            "candidate_family",
            "match_count",
            "partial_count",
            "miss_count",
            "blocker_count",
            "not_reported_count",
            "alignment_class",
            "source_ids",
            "SAM_reading",
        ],
    )
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, candidate_summary, checks, wrong_controls)


if __name__ == "__main__":
    main()
