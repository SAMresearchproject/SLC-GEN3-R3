from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN011_DIR = ARTIFACTS / "qn011"

QN010_SUMMARY = ARTIFACTS / "qn010" / "qn010_summary.json"
QN010_ALIGNMENT = ARTIFACTS / "qn010" / "candidate_alignment_summary.csv"
QN010_COMPARISON = ARTIFACTS / "qn010" / "candidate_benchmark_comparison.csv"
QN010_SOURCE_MANIFEST = ARTIFACTS / "qn010" / "external_quantum_network_source_manifest.csv"
QN009_SCORING_RULES = ARTIFACTS / "qn009" / "sam_qn_benchmark_scoring_rules.csv"
QN009_LEAKAGE_SCREEN = ARTIFACTS / "qn009" / "forbidden_leakage_screen.csv"
QN007_REQUIREMENTS = ARTIFACTS / "qn007" / "carrier_envelope_hardware_requirements.csv"

PREFLIGHT_OUT = QN011_DIR / "qn011_preflight.md"
INPUT_MANIFEST_OUT = QN011_DIR / "qn011_input_manifest.csv"
PROTOCOL_REQUIREMENTS_OUT = QN011_DIR / "sam_qn_protocol_requirement_translation.csv"
EXPERIMENT_STEPS_OUT = QN011_DIR / "sam_qn_experimental_protocol_steps.csv"
OBSERVABLES_OUT = QN011_DIR / "sam_qn_protocol_observable_table.csv"
SUCCESS_CRITERIA_OUT = QN011_DIR / "sam_qn_protocol_success_criteria.csv"
MILESTONE_LADDER_OUT = QN011_DIR / "sam_qn_experimental_milestone_ladder.csv"
CHECKS_OUT = QN011_DIR / "qn011_checks.csv"
WRONG_CONTROLS_OUT = QN011_DIR / "qn011_wrong_controls.csv"
SUMMARY_OUT = QN011_DIR / "qn011_summary.json"
NEXT_OUT = QN011_DIR / "qn011_next_frontier.csv"
REPORT_OUT = REPORTS / "QN011_PRIVATE_PLATFORM_REQUIREMENT_TO_EXPERIMENTAL_PROTOCOL_TRANSLATION.md"


PROTOCOL_TRANSLATIONS = {
    "network_object_grammar": {
        "protocol_requirement": "separate flying carrier, control envelope, boundary sensor, relay, ledger node, and material support",
        "apparatus_translation": "use entangled photons over fiber as carrier; keep active stabilization/control separate from final-outcome readout; expose hub/endpoints as ledger-safe nodes",
        "allowed_observables": "carrier arrival timing; polarization drift; phase drift; link health; source synchronization; endpoint readiness",
        "forbidden_observables": "final_ledger_outcome;logical_route_identity;premature_selected_write",
        "protocol_step": "Map physical apparatus roles to SAM network objects before trial data collection.",
        "success_criterion": "A candidate trial log can identify each SAM role without using final outcome labels.",
    },
    "link_survival_and_viability": {
        "protocol_requirement": "demonstrate protected carrier transport with active suppression and timing headroom",
        "apparatus_translation": "run fiber entanglement trials with active compensation and record allowed link-health letters before endpoint resolution",
        "allowed_observables": "loss window; polarization compensation command; timing headroom; source readiness; detector readiness",
        "forbidden_observables": "logical_route_identity;final_ledger_outcome",
        "protocol_step": "Record pre-resolution link-survival letters and active compensation actions for each trial.",
        "success_criterion": "Carrier-preservation decisions are explainable from allowed link letters only.",
    },
    "ledger_safe_relay": {
        "protocol_requirement": "relay or swap entanglement without copying final outcome or route identity",
        "apparatus_translation": "treat entanglement swapping as relay handoff; log relay packet fields and no-commit guard state",
        "allowed_observables": "swap attempt time; relay readiness; Bell-state analyzer status class; packet guard state",
        "forbidden_observables": "copy_final_outcome;clone_final_outcome;copy_logical_route_identity;premature_ledger_commit",
        "protocol_step": "Perform relay/swap handoff while logging only syndrome/pressure/timing packets before final endpoint readout.",
        "success_criterion": "Relay records do not contain endpoint final outcomes or selected route identity before write closure.",
    },
    "paul_revere_routing": {
        "protocol_requirement": "route pre-resolution warning letters and stop route forcing when write window closes",
        "apparatus_translation": "use orchestration events as Paul Revere letters: readiness, drift, timing, and failure warnings; never route selected final results",
        "allowed_observables": "pre-resolution warning; source clock; compensation need; failed-link notice; window-open flag",
        "forbidden_observables": "selected_final_result;force_pre_resolution_route_after_A_SHARE",
        "protocol_step": "Maintain a live warning-letter channel that can change apparatus controls before final measurement.",
        "success_criterion": "The warning channel changes controls without carrying final result content.",
    },
    "network_born_surface": {
        "protocol_requirement": "measure route-stability surface over open routes without conditioning on final ledger outcome",
        "apparatus_translation": "freeze open-route windows first, count carrier survival/stability by route class, and keep final-result analysis downstream",
        "allowed_observables": "open_window_gate; route class; carrier survival; link stability; route drop reason",
        "forbidden_observables": "final_ledger_outcome;ledger_commit_result",
        "protocol_step": "Build a blinded route-stability table from pre-resolution route classes before final-result labels are joined.",
        "success_criterion": "The route-stability surface is computed from open-window route records only.",
    },
    "letter_safe_error_correction": {
        "protocol_requirement": "correct allowed letters in real time while preserving unresolved probability surface",
        "apparatus_translation": "apply compensation from drift/timing/syndrome letters; keep probability accounting independent of final measurement results",
        "allowed_observables": "syndrome_signal; boundary_stress; time_to_A_SIDE; time_to_A_SHARE; compensation action",
        "forbidden_observables": "logical_route_identity;ledger_commit_result;final_ledger_outcome",
        "protocol_step": "Apply and log active correction commands driven only by allowed letters.",
        "success_criterion": "Correction commands are reproducible from allowed letters and do not require endpoint final outcomes.",
    },
    "earth_a_deployment_surface": {
        "protocol_requirement": "supply apparatus controls rather than relying on literal Earth A",
        "apparatus_translation": "document shielding, cooling, stabilization, timing discipline, geometry, endpoints, source, and orchestration controls",
        "allowed_observables": "temperature class; shielding state; timing lock; geometry state; compensation state; endpoint readiness",
        "forbidden_observables": "literal_Earth_A_as_control_engine",
        "protocol_step": "Document every engineered control lane that replaces literal Earth-A control.",
        "success_criterion": "Every active control requirement has an apparatus-supplied mechanism.",
    },
    "forbidden_leakage_invariant": {
        "protocol_requirement": "prove final outcome and logical route identity are inaccessible to control logic before selected write",
        "apparatus_translation": "separate pre-resolution control logs from final measurement logs and hash/freeze their join boundary",
        "allowed_observables": "log timestamp; allowed letter fields; control command; final-log join hash after selected write",
        "forbidden_observables": "final_ledger_outcome;logical_route_identity;premature_selected_write",
        "protocol_step": "Enforce a log-separation boundary between control channel and final measurement channel.",
        "success_criterion": "No pre-resolution control row contains final outcome, logical identity, or selected-write fields.",
    },
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QN011_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN011 Preflight - Platform Requirement to Experimental Protocol Translation

## Mode

```text
FORWARD_PLATFORM_REQUIREMENT_TO_PROTOCOL_TRANSLATION
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN011 does not rerun QN001-QN010. It translates the QN010 selected external
alignment into an experimental protocol surface. It uses the already approved
QN010 source-manifested external facts and introduces no new external source
intake.

## Question

```text
What experimental protocol would test the strongest QN010 photonic-entanglement
alignment under the sealed SAM QN rules?
```

## Success Condition

```text
Every sealed benchmark object becomes a protocol requirement, every requirement
defines allowed and forbidden observables, and forbidden final-outcome leakage
remains a hard blocker.
```
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "source_role": "FROZEN_QN010_OR_QN009_INPUT",
        }
        for path in paths
    ]


def split_semicolon(value: str) -> list[str]:
    return [part.strip() for part in value.split(";") if part.strip()]


def strongest_candidate(alignment_rows: list[dict[str, str]]) -> dict[str, str]:
    for row in alignment_rows:
        if row["alignment_class"] == "STRONGEST_QN010_ALIGNMENT":
            return row
    return sorted(alignment_rows, key=lambda row: (-int(row["match_count"]), -int(row["partial_count"]), int(row["blocker_count"])))[0]


def build_requirement_translation(
    strongest: dict[str, str],
    comparison_rows: list[dict[str, str]],
    scoring_rules: list[dict[str, str]],
) -> list[dict[str, object]]:
    rule_by_object = {row["sealed_object"]: row for row in scoring_rules}
    candidate_rows = [row for row in comparison_rows if row["candidate_id"] == strongest["candidate_id"]]
    rows: list[dict[str, object]] = []
    for idx, row in enumerate(candidate_rows, start=1):
        sealed_object = row["sealed_object"]
        translation = PROTOCOL_TRANSLATIONS[sealed_object]
        rule = rule_by_object[sealed_object]
        rows.append(
            {
                "requirement_id": f"QN011-REQ-{idx:02d}",
                "candidate_id": strongest["candidate_id"],
                "candidate_platform": strongest["candidate_platform"],
                "benchmark_id": row["benchmark_id"],
                "sealed_object": sealed_object,
                "qn010_status": row["candidate_comparator_status"],
                "required_candidate_fields": rule["required_candidate_fields"],
                "protocol_requirement": translation["protocol_requirement"],
                "apparatus_translation": translation["apparatus_translation"],
                "allowed_observables": translation["allowed_observables"],
                "forbidden_observables": translation["forbidden_observables"],
                "success_criterion": translation["success_criterion"],
                "source_ids": row["source_ids"],
                "free_parameter_introduced": False,
                "SAM_reading": row["sam_reading"],
            }
        )
    return rows


def build_protocol_steps(requirement_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for idx, requirement in enumerate(requirement_rows, start=1):
        translation = PROTOCOL_TRANSLATIONS[str(requirement["sealed_object"])]
        rows.append(
            {
                "step_id": f"QN011-STEP-{idx:02d}",
                "requirement_id": requirement["requirement_id"],
                "phase": "PREPARE" if idx <= 2 else "RELAY" if idx <= 4 else "MEASURE_SURFACE" if idx <= 6 else "VALIDATE",
                "protocol_action": translation["protocol_step"],
                "allowed_input_channel": translation["allowed_observables"],
                "blocked_input_channel": translation["forbidden_observables"],
                "expected_artifact": "trial_role_map" if idx == 1 else "pre_resolution_trial_log" if idx < 7 else "leakage_screen_report",
                "must_precede_final_measurement_join": True,
            }
        )
    rows.append(
        {
            "step_id": "QN011-STEP-09",
            "requirement_id": "QN011-FINAL-JOIN",
            "phase": "POST_WRITE_JOIN",
            "protocol_action": "Join final measurement logs only after pre-resolution control logs are frozen.",
            "allowed_input_channel": "post_write_final_measurement; frozen_pre_resolution_hash",
            "blocked_input_channel": "control_before_write_using_final_outcome",
            "expected_artifact": "post_write_join_manifest",
            "must_precede_final_measurement_join": False,
        }
    )
    return rows


def build_observable_rows(requirement_rows: list[dict[str, object]], leakage_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for requirement in requirement_rows:
        for observable in split_semicolon(str(requirement["allowed_observables"])):
            rows.append(
                {
                    "observable_id": f"QN011-OBS-{len(rows)+1:02d}",
                    "requirement_id": requirement["requirement_id"],
                    "observable": observable,
                    "observable_class": "ALLOWED_PRE_RESOLUTION_LETTER",
                    "used_for_control_before_write": True,
                    "allowed_before_selected_write": True,
                    "blocker_if_seen_before_write": False,
                }
            )
        for observable in split_semicolon(str(requirement["forbidden_observables"])):
            rows.append(
                {
                    "observable_id": f"QN011-OBS-{len(rows)+1:02d}",
                    "requirement_id": requirement["requirement_id"],
                    "observable": observable,
                    "observable_class": "FORBIDDEN_LEDGER_CONTENT",
                    "used_for_control_before_write": False,
                    "allowed_before_selected_write": False,
                    "blocker_if_seen_before_write": True,
                }
            )
    leakage_items = {row["forbidden_item"] for row in leakage_rows}
    for item in sorted(leakage_items - {str(row["observable"]) for row in rows}):
        rows.append(
            {
                "observable_id": f"QN011-OBS-{len(rows)+1:02d}",
                "requirement_id": "QN009_LEAKAGE_SCREEN_IMPORT",
                "observable": item,
                "observable_class": "FORBIDDEN_LEDGER_CONTENT",
                "used_for_control_before_write": False,
                "allowed_before_selected_write": False,
                "blocker_if_seen_before_write": True,
            }
        )
    return rows


def build_success_criteria(requirement_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for requirement in requirement_rows:
        status = str(requirement["qn010_status"])
        rows.append(
            {
                "criterion_id": f"QN011-CRIT-{len(rows)+1:02d}",
                "requirement_id": requirement["requirement_id"],
                "sealed_object": requirement["sealed_object"],
                "minimum_protocol_evidence": requirement["success_criterion"],
                "qn010_status_to_advance": status,
                "advance_if": "field protocol can supply missing SAM details" if status == "SAM_PARTIAL" else "evidence preserves QN010 match without leakage",
                "failure_if": "forbidden observable appears in pre-resolution control log",
                "numeric_threshold_or_fit": "",
            }
        )
    rows.append(
        {
            "criterion_id": f"QN011-CRIT-{len(rows)+1:02d}",
            "requirement_id": "QN011-GLOBAL",
            "sealed_object": "global_leakage_boundary",
            "minimum_protocol_evidence": "pre-resolution control logs are hash-frozen before final measurement logs are joined",
            "qn010_status_to_advance": "ALL_NON_BLOCKED",
            "advance_if": "all pre-resolution rows avoid final outcome and logical route identity",
            "failure_if": "any control row uses final outcome, logical route identity, selected write, or ledger commit result",
            "numeric_threshold_or_fit": "",
        }
    )
    return rows


def build_milestone_ladder(strongest: dict[str, str], requirement_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    partials = [row for row in requirement_rows if row["qn010_status"] == "SAM_PARTIAL"]
    return [
        {
            "milestone_id": "QN011-MILE-01",
            "candidate_platform": strongest["candidate_platform"],
            "milestone": "role-separated trial log",
            "target": "carrier/envelope/sensor/relay/ledger/support roles are labeled before trial analysis",
            "unlocks": "network_object_grammar protocol readiness",
            "depends_on": "QN011-REQ-01",
        },
        {
            "milestone_id": "QN011-MILE-02",
            "candidate_platform": strongest["candidate_platform"],
            "milestone": "allowed-letter correction log",
            "target": "active compensation is driven by allowed letters only",
            "unlocks": "letter-safe error correction protocol readiness",
            "depends_on": "QN011-REQ-06",
        },
        {
            "milestone_id": "QN011-MILE-03",
            "candidate_platform": strongest["candidate_platform"],
            "milestone": "blinded route-stability surface",
            "target": "open-route survival/stability is computed before final-outcome labels join",
            "unlocks": "network Born surface protocol readiness",
            "depends_on": "QN011-REQ-05",
        },
        {
            "milestone_id": "QN011-MILE-04",
            "candidate_platform": strongest["candidate_platform"],
            "milestone": "closed-window stop rule",
            "target": "orchestration stops pre-resolution route forcing once write window is closed",
            "unlocks": "Paul Revere routing protocol readiness",
            "depends_on": "QN011-REQ-04",
        },
        {
            "milestone_id": "QN011-MILE-05",
            "candidate_platform": strongest["candidate_platform"],
            "milestone": "leakage firewall",
            "target": "pre-resolution control logs contain zero final-outcome or logical-route fields",
            "unlocks": "external SAM network protocol comparison",
            "depends_on": "QN011-REQ-08",
        },
        {
            "milestone_id": "QN011-MILE-99",
            "candidate_platform": strongest["candidate_platform"],
            "milestone": "partial-to-match closure inventory",
            "target": f"{len(partials)} QN010 partial rows are converted into explicit protocol tests",
            "unlocks": "QN012 live protocol scorecard",
            "depends_on": ";".join(str(row["requirement_id"]) for row in partials),
        },
    ]


def source_ids_available(rows: list[dict[str, object]], source_rows: list[dict[str, str]]) -> bool:
    source_ids = {row["source_id"] for row in source_rows}
    for row in rows:
        for source_id in split_semicolon(str(row.get("source_ids", ""))):
            if source_id not in source_ids:
                return False
    return True


def build_checks(
    qn010_summary: dict[str, object],
    requirement_rows: list[dict[str, object]],
    step_rows: list[dict[str, object]],
    observable_rows: list[dict[str, object]],
    criteria_rows: list[dict[str, object]],
    milestone_rows: list[dict[str, object]],
    source_rows: list[dict[str, str]],
) -> list[dict[str, object]]:
    sealed_objects = {row["sealed_object"] for row in requirement_rows}
    blockers = [row for row in observable_rows if row["blocker_if_seen_before_write"] is True]
    allowed = [row for row in observable_rows if row["allowed_before_selected_write"] is True]
    no_numeric_fit = all(not str(row["numeric_threshold_or_fit"]).strip() for row in criteria_rows)
    global_leakage = any(row["requirement_id"] == "QN011-GLOBAL" for row in criteria_rows)
    partial_closure = any(row["milestone_id"] == "QN011-MILE-99" and "QN011-REQ-04" in str(row["depends_on"]) for row in milestone_rows)
    return [
        {
            "check_id": "QN011_CHECK_01",
            "check": "QN010 selected external comparison before protocol translation",
            "pass": qn010_summary["result_class"] == "QN010_EXTERNAL_BENCHMARK_COMPARISON_SELECTED",
            "detail": qn010_summary["strongest_candidate"],
        },
        {
            "check_id": "QN011_CHECK_02",
            "check": "all eight sealed benchmark objects become protocol requirements",
            "pass": len(sealed_objects) == 8 and len(requirement_rows) == 8,
            "detail": len(requirement_rows),
        },
        {
            "check_id": "QN011_CHECK_03",
            "check": "every protocol requirement cites approved QN010 source IDs",
            "pass": source_ids_available(requirement_rows, source_rows),
            "detail": len(source_rows),
        },
        {
            "check_id": "QN011_CHECK_04",
            "check": "allowed and forbidden observable lanes are separated",
            "pass": len(allowed) > 0 and len(blockers) > 0 and not any(row["allowed_before_selected_write"] is True and row["blocker_if_seen_before_write"] is True for row in observable_rows),
            "detail": f"allowed={len(allowed)};blocked={len(blockers)}",
        },
        {
            "check_id": "QN011_CHECK_05",
            "check": "no numeric fit or performance threshold is introduced",
            "pass": no_numeric_fit,
            "detail": "protocol criteria only",
        },
        {
            "check_id": "QN011_CHECK_06",
            "check": "global leakage firewall is explicit",
            "pass": global_leakage,
            "detail": "QN011-GLOBAL",
        },
        {
            "check_id": "QN011_CHECK_07",
            "check": "QN010 partial rows are converted into closure milestones",
            "pass": partial_closure,
            "detail": len(milestone_rows),
        },
        {
            "check_id": "QN011_CHECK_08",
            "check": "protocol sequence includes pre-write and post-write phases",
            "pass": any(row["must_precede_final_measurement_join"] is True for row in step_rows) and any(row["must_precede_final_measurement_join"] is False for row in step_rows),
            "detail": len(step_rows),
        },
    ]


def build_wrong_controls(
    qn010_summary: dict[str, object],
    requirement_rows: list[dict[str, object]],
    observable_rows: list[dict[str, object]],
    criteria_rows: list[dict[str, object]],
    step_rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    strongest_blocked = int(qn010_summary["strongest_candidate_blocker_count"]) > 0
    final_allowed = any(row["observable"] in {"final_ledger_outcome", "logical_route_identity"} and row["allowed_before_selected_write"] is True for row in observable_rows)
    fit_present = any(str(row["numeric_threshold_or_fit"]).strip() for row in criteria_rows)
    source_missing = any(not str(row["source_ids"]).strip() for row in requirement_rows)
    final_join_before_control = any(row["phase"] == "POST_WRITE_JOIN" and row["must_precede_final_measurement_join"] is True for row in step_rows)
    return [
        {
            "control_id": "QN011_WC_01",
            "wrong_control": "strongest platform has QN010 leakage blocker",
            "expected": False,
            "actual": strongest_blocked,
            "pass": not strongest_blocked,
        },
        {
            "control_id": "QN011_WC_02",
            "wrong_control": "final outcome or route identity is allowed before write",
            "expected": False,
            "actual": final_allowed,
            "pass": not final_allowed,
        },
        {
            "control_id": "QN011_WC_03",
            "wrong_control": "protocol introduces fitted numerical threshold",
            "expected": False,
            "actual": fit_present,
            "pass": not fit_present,
        },
        {
            "control_id": "QN011_WC_04",
            "wrong_control": "protocol requirement lacks QN010 source provenance",
            "expected": False,
            "actual": source_missing,
            "pass": not source_missing,
        },
        {
            "control_id": "QN011_WC_05",
            "wrong_control": "post-write final join occurs before control-log freeze",
            "expected": False,
            "actual": final_join_before_control,
            "pass": not final_join_before_control,
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    requirement_rows: list[dict[str, object]],
    milestone_rows: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN011 - Private Platform Requirement to Experimental Protocol Translation

## Result

```text
{summary["result_class"]}
```

QN011 translates the strongest QN010 external alignment into a SAM-native
experimental protocol package.

## Main Readout

```text
selected_candidate = {summary["selected_candidate"]}
protocol_requirement_rows = {summary["protocol_requirement_rows"]}
experimental_step_rows = {summary["experimental_step_rows"]}
observable_rows = {summary["observable_rows"]}
forbidden_observable_rows = {summary["forbidden_observable_rows"]}
success_criteria_rows = {summary["success_criteria_rows"]}
milestone_rows = {summary["milestone_rows"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Requirement Translation

{markdown_table(requirement_rows, ["requirement_id", "sealed_object", "qn010_status", "protocol_requirement", "success_criterion"])}

## Milestone Ladder

{markdown_table(milestone_rows, ["milestone_id", "milestone", "target", "unlocks"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

QN011 turns the strongest QN010 lane into a practical experimental shape:

```text
use deployed photonic entanglement swapping as the carrier/relay lane
separate apparatus control from final-outcome readout
record allowed warning letters before write closure
compute route stability before final-result labels join
apply correction from allowed letters only
freeze the final measurement join as a post-write operation
```

This gives QN012 a concrete live scorecard target rather than a broad platform
comparison.

## Outputs

```text
artifacts/qn011/qn011_preflight.md
artifacts/qn011/qn011_input_manifest.csv
artifacts/qn011/sam_qn_protocol_requirement_translation.csv
artifacts/qn011/sam_qn_experimental_protocol_steps.csv
artifacts/qn011/sam_qn_protocol_observable_table.csv
artifacts/qn011/sam_qn_protocol_success_criteria.csv
artifacts/qn011/sam_qn_experimental_milestone_ladder.csv
artifacts/qn011/qn011_checks.csv
artifacts/qn011/qn011_wrong_controls.csv
artifacts/qn011/qn011_summary.json
artifacts/qn011/qn011_next_frontier.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = [
        QN010_SUMMARY,
        QN010_ALIGNMENT,
        QN010_COMPARISON,
        QN010_SOURCE_MANIFEST,
        QN009_SCORING_RULES,
        QN009_LEAKAGE_SCREEN,
        QN007_REQUIREMENTS,
    ]
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])
    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN011 inputs: {missing}")

    qn010_summary = read_json(QN010_SUMMARY)
    alignment_rows = read_csv(QN010_ALIGNMENT)
    comparison_rows = read_csv(QN010_COMPARISON)
    source_rows = read_csv(QN010_SOURCE_MANIFEST)
    scoring_rules = read_csv(QN009_SCORING_RULES)
    leakage_rows = read_csv(QN009_LEAKAGE_SCREEN)
    strongest = strongest_candidate(alignment_rows)

    requirement_rows = build_requirement_translation(strongest, comparison_rows, scoring_rules)
    step_rows = build_protocol_steps(requirement_rows)
    observable_rows = build_observable_rows(requirement_rows, leakage_rows)
    criteria_rows = build_success_criteria(requirement_rows)
    milestone_rows = build_milestone_ladder(strongest, requirement_rows)
    checks = build_checks(qn010_summary, requirement_rows, step_rows, observable_rows, criteria_rows, milestone_rows, source_rows)
    wrong_controls = build_wrong_controls(qn010_summary, requirement_rows, observable_rows, criteria_rows, step_rows)
    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)
    forbidden_observable_rows = sum(row["blocker_if_seen_before_write"] is True for row in observable_rows)

    summary = {
        "artifact": "QN011_PRIVATE_PLATFORM_REQUIREMENT_TO_EXPERIMENTAL_PROTOCOL_TRANSLATION",
        "result_class": "QN011_EXPERIMENTAL_PROTOCOL_TRANSLATION_SELECTED",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_PLUS_QN010_APPROVED_EXTERNAL_SOURCES",
        "test_type": "FORWARD_PLATFORM_REQUIREMENT_TO_PROTOCOL_TRANSLATION",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": True,
        "external_data_allowed_by": "QN010_EXTERNAL_BENCHMARK_COMPARISON_SELECTED",
        "new_external_source_intake": False,
        "free_parameters_introduced": 0,
        "qn010_result_class": qn010_summary["result_class"],
        "selected_candidate": strongest["candidate_platform"],
        "selected_candidate_id": strongest["candidate_id"],
        "selected_candidate_alignment_class": strongest["alignment_class"],
        "protocol_requirement_rows": len(requirement_rows),
        "experimental_step_rows": len(step_rows),
        "observable_rows": len(observable_rows),
        "forbidden_observable_rows": forbidden_observable_rows,
        "success_criteria_rows": len(criteria_rows),
        "milestone_rows": len(milestone_rows),
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "forbidden_fields_used": False,
        "next_frontier": "QN012_PRIVATE_LIVE_PROTOCOL_SCORECARD_AND_DATA_PACKAGE",
    }

    write_csv(
        PROTOCOL_REQUIREMENTS_OUT,
        requirement_rows,
        [
            "requirement_id",
            "candidate_id",
            "candidate_platform",
            "benchmark_id",
            "sealed_object",
            "qn010_status",
            "required_candidate_fields",
            "protocol_requirement",
            "apparatus_translation",
            "allowed_observables",
            "forbidden_observables",
            "success_criterion",
            "source_ids",
            "free_parameter_introduced",
            "SAM_reading",
        ],
    )
    write_csv(
        EXPERIMENT_STEPS_OUT,
        step_rows,
        [
            "step_id",
            "requirement_id",
            "phase",
            "protocol_action",
            "allowed_input_channel",
            "blocked_input_channel",
            "expected_artifact",
            "must_precede_final_measurement_join",
        ],
    )
    write_csv(
        OBSERVABLES_OUT,
        observable_rows,
        [
            "observable_id",
            "requirement_id",
            "observable",
            "observable_class",
            "used_for_control_before_write",
            "allowed_before_selected_write",
            "blocker_if_seen_before_write",
        ],
    )
    write_csv(
        SUCCESS_CRITERIA_OUT,
        criteria_rows,
        [
            "criterion_id",
            "requirement_id",
            "sealed_object",
            "minimum_protocol_evidence",
            "qn010_status_to_advance",
            "advance_if",
            "failure_if",
            "numeric_threshold_or_fit",
        ],
    )
    write_csv(
        MILESTONE_LADDER_OUT,
        milestone_rows,
        ["milestone_id", "candidate_platform", "milestone", "target", "unlocks", "depends_on"],
    )
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, requirement_rows, milestone_rows, checks, wrong_controls)


if __name__ == "__main__":
    main()
