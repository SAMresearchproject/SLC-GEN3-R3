from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN012_DIR = ARTIFACTS / "qn012"

QN011_SUMMARY = ARTIFACTS / "qn011" / "qn011_summary.json"
QN011_REQUIREMENTS = ARTIFACTS / "qn011" / "sam_qn_protocol_requirement_translation.csv"
QN011_STEPS = ARTIFACTS / "qn011" / "sam_qn_experimental_protocol_steps.csv"
QN011_OBSERVABLES = ARTIFACTS / "qn011" / "sam_qn_protocol_observable_table.csv"
QN011_CRITERIA = ARTIFACTS / "qn011" / "sam_qn_protocol_success_criteria.csv"
QN011_MILESTONES = ARTIFACTS / "qn011" / "sam_qn_experimental_milestone_ladder.csv"

PREFLIGHT_OUT = QN012_DIR / "qn012_preflight.md"
INPUT_MANIFEST_OUT = QN012_DIR / "qn012_input_manifest.csv"
TRIAL_ROLE_MAP_OUT = QN012_DIR / "trial_role_map_template.csv"
PRE_RESOLUTION_LOG_OUT = QN012_DIR / "pre_resolution_trial_log_template.csv"
PAUL_REVERE_MAP_OUT = QN012_DIR / "paul_revere_self_correction_map.csv"
CORRECTION_LOG_OUT = QN012_DIR / "allowed_letter_correction_log_template.csv"
ROUTE_STABILITY_OUT = QN012_DIR / "route_stability_surface_input_template.csv"
LEAKAGE_FIREWALL_OUT = QN012_DIR / "leakage_firewall_report_template.csv"
POST_WRITE_JOIN_OUT = QN012_DIR / "post_write_join_manifest_template.csv"
LIVE_SCORECARD_OUT = QN012_DIR / "sam_qn_live_protocol_scorecard.csv"
DATA_PACKAGE_MANIFEST_OUT = QN012_DIR / "sam_qn_live_data_package_manifest.csv"
CHECKS_OUT = QN012_DIR / "qn012_checks.csv"
WRONG_CONTROLS_OUT = QN012_DIR / "qn012_wrong_controls.csv"
SUMMARY_OUT = QN012_DIR / "qn012_summary.json"
NEXT_OUT = QN012_DIR / "qn012_next_frontier.csv"
REPORT_OUT = REPORTS / "QN012_PRIVATE_LIVE_PROTOCOL_SCORECARD_DATA_PACKAGE.md"


ROLE_ROWS = [
    ("UNRESOLVED_CARRIER", "entangled photon carrier over fiber", "carrier arrival timing;link health;route class", "final_ledger_outcome;logical_route_identity"),
    ("CONTROL_ENVELOPE", "active stabilization, timing, and compensation controls", "polarization drift;phase drift;compensation need;control command", "act_as_primary_unresolved_carrier;final_ledger_outcome"),
    ("BOUNDARY_SENSOR", "allowed warning-letter sensor layer", "boundary_stress;syndrome_signal;window-open flag;failed-link notice", "final_ledger_outcome;logical_route_identity"),
    ("RELAY_REPEATER", "entanglement swap or relay handoff apparatus", "swap attempt time;relay readiness;packet guard state", "copy_final_outcome;copy_logical_route_identity;premature_ledger_commit"),
    ("LEDGER_NODE", "endpoint/final measurement node with delayed join", "endpoint readiness;post_write_final_measurement", "premature_selected_write;ledger_commit_result_before_write"),
    ("MATERIAL_SUPPORT", "fiber, source, hub, shielding, timing, and geometry support", "temperature class;shielding state;timing lock;geometry state", "literal_Earth_A_as_control_engine"),
]

PAUL_REVERE_ROWS = [
    {
        "letter_id": "PR-LETTER-01",
        "warning_letter": "polarization drift",
        "allowed_control_action": "update polarization compensation command",
        "expected_self_correction_effect": "preserve carrier link before endpoint resolution",
        "forbidden_payload": "final_ledger_outcome;logical_route_identity",
    },
    {
        "letter_id": "PR-LETTER-02",
        "warning_letter": "phase drift",
        "allowed_control_action": "adjust phase stabilization envelope",
        "expected_self_correction_effect": "reduce route instability without selecting final result",
        "forbidden_payload": "selected_final_result;ledger_commit_result",
    },
    {
        "letter_id": "PR-LETTER-03",
        "warning_letter": "timing headroom",
        "allowed_control_action": "delay, advance, or hold relay attempt inside open window",
        "expected_self_correction_effect": "keep Paul Revere letter ahead of write closure",
        "forbidden_payload": "force_pre_resolution_route_after_A_SHARE",
    },
    {
        "letter_id": "PR-LETTER-04",
        "warning_letter": "failed-link notice",
        "allowed_control_action": "retry source/link preparation while other open links remain guarded",
        "expected_self_correction_effect": "repair route opportunity without copying final outcome",
        "forbidden_payload": "clone_final_outcome;copy_logical_route_identity",
    },
    {
        "letter_id": "PR-LETTER-05",
        "warning_letter": "window-open flag",
        "allowed_control_action": "permit active correction only while pre-resolution window is open",
        "expected_self_correction_effect": "stop route forcing when write window closes",
        "forbidden_payload": "premature_selected_write;selected_final_result",
    },
    {
        "letter_id": "PR-LETTER-06",
        "warning_letter": "syndrome_signal",
        "allowed_control_action": "apply letter-safe correction command",
        "expected_self_correction_effect": "correct apparatus state from allowed syndrome content",
        "forbidden_payload": "final_ledger_outcome;logical_route_identity",
    },
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QN012_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN012 Preflight - Live Protocol Scorecard and Data Package

## Mode

```text
FORWARD_LIVE_PROTOCOL_SCORECARD_DATA_PACKAGE
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN012 does not rerun QN001-QN011. It converts QN011 protocol requirements into
blank live-data templates, a scorecard, and a Paul Revere self-correction map.
It introduces no new external source intake and no fitted performance scores.

## Question

```text
Can SAM produce a live lab data package for testing self-correction by
pre-resolution Paul Revere letters?
```

## Success Condition

```text
The package separates pre-write control logs from post-write final measurement
logs, maps warning letters to allowed correction actions, and blocks final
outcome or logical route identity before selected write.
```
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "source_role": "FROZEN_QN011_INPUT",
        }
        for path in paths
    ]


def split_semicolon(value: str) -> list[str]:
    return [part.strip() for part in value.split(";") if part.strip()]


def build_trial_role_map(requirements: list[dict[str, str]]) -> list[dict[str, object]]:
    candidate = requirements[0]["candidate_platform"]
    rows = []
    for idx, (role, physical, allowed, forbidden) in enumerate(ROLE_ROWS, start=1):
        rows.append(
            {
                "role_map_id": f"QN012-ROLE-{idx:02d}",
                "candidate_platform": candidate,
                "sam_role": role,
                "physical_component_required": physical,
                "allowed_pre_write_letters": allowed,
                "forbidden_pre_write_content": forbidden,
                "trial_log_field_prefix": role.lower(),
                "required_before_trial_scoring": True,
            }
        )
    return rows


def build_pre_resolution_log_template(steps: list[dict[str, str]]) -> list[dict[str, object]]:
    rows = []
    for step in steps:
        if step["must_precede_final_measurement_join"].lower() != "true":
            continue
        rows.append(
            {
                "template_row_id": f"QN012-PRELOG-{len(rows)+1:02d}",
                "trial_id": "TRIAL_ID_REQUIRED",
                "pre_write_timestamp": "REQUIRED",
                "step_id": step["step_id"],
                "requirement_id": step["requirement_id"],
                "allowed_letter_channel": step["allowed_input_channel"],
                "observed_letter_value": "LAB_SUPPLIED_ALLOWED_VALUE",
                "control_command": "LAB_SUPPLIED_OR_NONE",
                "window_open_flag": "LAB_SUPPLIED_TRUE_FALSE",
                "pre_resolution_hash_input": "HASH_THIS_ROW_BEFORE_FINAL_JOIN",
                "final_ledger_outcome": "FORBIDDEN_BEFORE_WRITE",
                "logical_route_identity": "FORBIDDEN_BEFORE_WRITE",
                "selected_final_result": "FORBIDDEN_BEFORE_WRITE",
            }
        )
    return rows


def build_correction_log_template() -> list[dict[str, object]]:
    rows = []
    for letter in PAUL_REVERE_ROWS:
        rows.append(
            {
                "correction_row_id": f"QN012-CORR-{len(rows)+1:02d}",
                "trial_id": "TRIAL_ID_REQUIRED",
                "letter_id": letter["letter_id"],
                "warning_letter": letter["warning_letter"],
                "allowed_control_action": letter["allowed_control_action"],
                "actual_control_action": "LAB_SUPPLIED",
                "action_timestamp": "REQUIRED",
                "window_open_flag": "LAB_SUPPLIED_TRUE_FALSE",
                "used_final_outcome": False,
                "used_logical_route_identity": False,
                "forbidden_payload": letter["forbidden_payload"],
            }
        )
    return rows


def build_route_stability_template() -> list[dict[str, object]]:
    route_classes = [
        ("QUBIT-NL-001", "protected photonic carrier route"),
        ("QUBIT-CL-001", "control-envelope lane"),
        ("QUBIT-UNK-001", "boundary-sensor lane"),
        ("ROUTE-DROP", "closed or failed route"),
    ]
    rows = []
    for route_id, route_desc in route_classes:
        rows.append(
            {
                "surface_row_id": f"QN012-SURF-{len(rows)+1:02d}",
                "trial_id": "TRIAL_ID_REQUIRED",
                "route_class": route_id,
                "route_description": route_desc,
                "open_window_gate": "LAB_SUPPLIED_TRUE_FALSE",
                "carrier_survival": "LAB_SUPPLIED_TRUE_FALSE",
                "link_stability": "LAB_SUPPLIED_ALLOWED_VALUE",
                "route_drop_reason": "LAB_SUPPLIED_OR_NONE",
                "pre_final_label_join": True,
                "final_ledger_outcome": "JOIN_ONLY_AFTER_PRELOG_HASH",
                "logical_route_identity": "JOIN_ONLY_AFTER_PRELOG_HASH",
            }
        )
    return rows


def build_leakage_firewall_template(observables: list[dict[str, str]]) -> list[dict[str, object]]:
    forbidden = sorted({row["observable"] for row in observables if row["blocker_if_seen_before_write"].lower() == "true"})
    rows = []
    for item in forbidden:
        rows.append(
            {
                "firewall_row_id": f"QN012-LEAK-{len(rows)+1:02d}",
                "forbidden_item": item,
                "allowed_pre_write_count": 0,
                "observed_pre_write_count": "LAB_SUPPLIED_COUNT",
                "blocker_if_observed": True,
                "scorecard_status_if_observed": "SAM_BLOCKER",
                "allowed_after_write": item not in {"act_as_primary_unresolved_carrier", "force_pre_resolution_route_after_A_SHARE", "literal_Earth_A_as_control_engine"},
            }
        )
    return rows


def build_post_write_join_template() -> list[dict[str, object]]:
    return [
        {
            "join_manifest_id": "QN012-JOIN-01",
            "trial_id": "TRIAL_ID_REQUIRED",
            "pre_resolution_trial_log_hash": "REQUIRED_HASH",
            "pre_resolution_log_frozen_before_join": True,
            "final_measurement_log_id": "LAB_SUPPLIED_AFTER_WRITE",
            "selected_write_timestamp": "LAB_SUPPLIED_AFTER_WRITE",
            "join_timestamp": "LAB_SUPPLIED_AFTER_WRITE",
            "join_after_selected_write": "LAB_SUPPLIED_TRUE_FALSE",
            "pre_write_final_leakage_count": 0,
            "post_write_join_allowed": True,
        }
    ]


def build_live_scorecard(requirements: list[dict[str, str]], milestones: list[dict[str, str]]) -> list[dict[str, object]]:
    rows = []
    for req in requirements:
        rows.append(
            {
                "scorecard_id": f"QN012-SCORE-{len(rows)+1:02d}",
                "scorecard_target": req["requirement_id"],
                "target_type": "REQUIREMENT",
                "sealed_object": req["sealed_object"],
                "required_evidence_artifact": artifact_for_requirement(req["sealed_object"]),
                "pass_condition": req["success_criterion"],
                "partial_condition": "evidence exists but one allowed-letter or post-write boundary field is incomplete",
                "blocker_condition": "forbidden pre-write ledger content appears",
                "status_values": "PASS;PARTIAL;NOT_READY;SAM_BLOCKER",
                "numeric_weight_or_fit": "",
            }
        )
    for milestone in milestones:
        rows.append(
            {
                "scorecard_id": f"QN012-SCORE-{len(rows)+1:02d}",
                "scorecard_target": milestone["milestone_id"],
                "target_type": "MILESTONE",
                "sealed_object": milestone["milestone"],
                "required_evidence_artifact": artifact_for_milestone(milestone["milestone_id"]),
                "pass_condition": milestone["target"],
                "partial_condition": "milestone has evidence but cannot yet close all dependent requirements",
                "blocker_condition": "forbidden pre-write ledger content appears",
                "status_values": "PASS;PARTIAL;NOT_READY;SAM_BLOCKER",
                "numeric_weight_or_fit": "",
            }
        )
    return rows


def artifact_for_requirement(sealed_object: str) -> str:
    mapping = {
        "network_object_grammar": "trial_role_map_template.csv",
        "link_survival_and_viability": "pre_resolution_trial_log_template.csv",
        "ledger_safe_relay": "pre_resolution_trial_log_template.csv",
        "paul_revere_routing": "paul_revere_self_correction_map.csv;allowed_letter_correction_log_template.csv",
        "network_born_surface": "route_stability_surface_input_template.csv",
        "letter_safe_error_correction": "allowed_letter_correction_log_template.csv",
        "earth_a_deployment_surface": "trial_role_map_template.csv",
        "forbidden_leakage_invariant": "leakage_firewall_report_template.csv;post_write_join_manifest_template.csv",
    }
    return mapping[sealed_object]


def artifact_for_milestone(milestone_id: str) -> str:
    mapping = {
        "QN011-MILE-01": "trial_role_map_template.csv",
        "QN011-MILE-02": "allowed_letter_correction_log_template.csv",
        "QN011-MILE-03": "route_stability_surface_input_template.csv",
        "QN011-MILE-04": "paul_revere_self_correction_map.csv",
        "QN011-MILE-05": "leakage_firewall_report_template.csv",
        "QN011-MILE-99": "sam_qn_live_protocol_scorecard.csv",
    }
    return mapping.get(milestone_id, "sam_qn_live_protocol_scorecard.csv")


def build_data_package_manifest() -> list[dict[str, object]]:
    rows = []
    for filename, role, required in [
        ("trial_role_map_template.csv", "map physical lab apparatus to SAM roles", True),
        ("pre_resolution_trial_log_template.csv", "capture allowed warning letters before final write", True),
        ("paul_revere_self_correction_map.csv", "map warning letters to allowed self-correction actions", True),
        ("allowed_letter_correction_log_template.csv", "record actual corrections driven by warning letters", True),
        ("route_stability_surface_input_template.csv", "build blinded route-stability surface before final labels join", True),
        ("leakage_firewall_report_template.csv", "prove forbidden final content is absent before write", True),
        ("post_write_join_manifest_template.csv", "join final logs only after pre-resolution hash freeze", True),
        ("sam_qn_live_protocol_scorecard.csv", "score PASS/PARTIAL/NOT_READY/SAM_BLOCKER without fitted weights", True),
    ]:
        rows.append(
            {
                "package_file": filename,
                "role": role,
                "required_for_qn012": required,
                "contains_external_live_data_now": False,
                "allowed_to_receive_live_lab_data_in_qn013": True,
            }
        )
    return rows


def build_checks(
    qn011_summary: dict[str, object],
    role_rows: list[dict[str, object]],
    prelog_rows: list[dict[str, object]],
    paul_rows: list[dict[str, object]],
    correction_rows: list[dict[str, object]],
    route_rows: list[dict[str, object]],
    leak_rows: list[dict[str, object]],
    join_rows: list[dict[str, object]],
    scorecard_rows: list[dict[str, object]],
    package_rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    self_correction_letters = {row["warning_letter"] for row in paul_rows}
    blocker_payload_declared = all(str(row["forbidden_payload"]).strip() for row in paul_rows)
    prelog_blocks_final = all(
        row["final_ledger_outcome"] == "FORBIDDEN_BEFORE_WRITE" and row["logical_route_identity"] == "FORBIDDEN_BEFORE_WRITE"
        for row in prelog_rows
    )
    no_score_weights = all(not str(row["numeric_weight_or_fit"]).strip() for row in scorecard_rows)
    leak_zero = all(int(row["allowed_pre_write_count"]) == 0 and row["scorecard_status_if_observed"] == "SAM_BLOCKER" for row in leak_rows)
    post_join_safe = all(row["pre_resolution_log_frozen_before_join"] is True and row["post_write_join_allowed"] is True for row in join_rows)
    package_complete = all(row["required_for_qn012"] is True for row in package_rows) and len(package_rows) == 8
    return [
        {
            "check_id": "QN012_CHECK_01",
            "check": "QN011 protocol translation selected before scorecard package",
            "pass": qn011_summary["result_class"] == "QN011_EXPERIMENTAL_PROTOCOL_TRANSLATION_SELECTED",
            "detail": qn011_summary["selected_candidate"],
        },
        {
            "check_id": "QN012_CHECK_02",
            "check": "trial role map covers all six SAM apparatus roles",
            "pass": len(role_rows) == 6,
            "detail": len(role_rows),
        },
        {
            "check_id": "QN012_CHECK_03",
            "check": "Paul Revere self-correction map has multiple allowed warning letters",
            "pass": len(self_correction_letters) >= 5 and blocker_payload_declared,
            "detail": ";".join(sorted(self_correction_letters)),
        },
        {
            "check_id": "QN012_CHECK_04",
            "check": "pre-resolution log template blocks final outcome and route identity",
            "pass": prelog_blocks_final,
            "detail": len(prelog_rows),
        },
        {
            "check_id": "QN012_CHECK_05",
            "check": "route-stability template stays blinded before final label join",
            "pass": all(row["pre_final_label_join"] is True for row in route_rows),
            "detail": len(route_rows),
        },
        {
            "check_id": "QN012_CHECK_06",
            "check": "leakage firewall makes forbidden fields hard blockers",
            "pass": leak_zero,
            "detail": len(leak_rows),
        },
        {
            "check_id": "QN012_CHECK_07",
            "check": "post-write join requires pre-resolution hash freeze",
            "pass": post_join_safe,
            "detail": len(join_rows),
        },
        {
            "check_id": "QN012_CHECK_08",
            "check": "scorecard introduces no fitted weights or performance scores",
            "pass": no_score_weights,
            "detail": len(scorecard_rows),
        },
        {
            "check_id": "QN012_CHECK_09",
            "check": "data package manifest contains all required template files",
            "pass": package_complete,
            "detail": len(package_rows),
        },
    ]


def build_wrong_controls(
    prelog_rows: list[dict[str, object]],
    paul_rows: list[dict[str, object]],
    leak_rows: list[dict[str, object]],
    join_rows: list[dict[str, object]],
    scorecard_rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    paul_carries_answer = any("final_ledger_outcome" in str(row["warning_letter"]) or "logical_route_identity" in str(row["warning_letter"]) for row in paul_rows)
    prelog_allows_final = any(row["final_ledger_outcome"] != "FORBIDDEN_BEFORE_WRITE" for row in prelog_rows)
    leakage_soft = any(row["scorecard_status_if_observed"] != "SAM_BLOCKER" for row in leak_rows)
    final_join_without_hash = any(row["pre_resolution_log_frozen_before_join"] is not True for row in join_rows)
    weighted_score = any(str(row["numeric_weight_or_fit"]).strip() for row in scorecard_rows)
    return [
        {
            "control_id": "QN012_WC_01",
            "wrong_control": "Paul Revere letter carries final answer",
            "expected": False,
            "actual": paul_carries_answer,
            "pass": not paul_carries_answer,
        },
        {
            "control_id": "QN012_WC_02",
            "wrong_control": "pre-resolution trial log allows final outcome",
            "expected": False,
            "actual": prelog_allows_final,
            "pass": not prelog_allows_final,
        },
        {
            "control_id": "QN012_WC_03",
            "wrong_control": "leakage firewall treats forbidden content as soft penalty",
            "expected": False,
            "actual": leakage_soft,
            "pass": not leakage_soft,
        },
        {
            "control_id": "QN012_WC_04",
            "wrong_control": "post-write join does not require pre-resolution hash",
            "expected": False,
            "actual": final_join_without_hash,
            "pass": not final_join_without_hash,
        },
        {
            "control_id": "QN012_WC_05",
            "wrong_control": "live scorecard introduces fitted numeric ranking",
            "expected": False,
            "actual": weighted_score,
            "pass": not weighted_score,
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    paul_rows: list[dict[str, object]],
    package_rows: list[dict[str, object]],
    scorecard_rows: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN012 - Private Live Protocol Scorecard and Data Package

## Result

```text
{summary["result_class"]}
```

QN012 converts QN011 into a live lab scorecard and blank data package for
testing self-correction by pre-resolution Paul Revere letters.

## Main Readout

```text
data_package_files = {summary["data_package_files"]}
trial_role_rows = {summary["trial_role_rows"]}
pre_resolution_log_rows = {summary["pre_resolution_log_rows"]}
paul_revere_letter_rows = {summary["paul_revere_letter_rows"]}
route_stability_rows = {summary["route_stability_rows"]}
leakage_firewall_rows = {summary["leakage_firewall_rows"]}
scorecard_rows = {summary["scorecard_rows"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Paul Revere Self-Correction Map

{markdown_table(paul_rows, ["letter_id", "warning_letter", "allowed_control_action", "expected_self_correction_effect", "forbidden_payload"])}

## Data Package

{markdown_table(package_rows, ["package_file", "role", "required_for_qn012"])}

## Scorecard Surface

{markdown_table(scorecard_rows[:8], ["scorecard_id", "scorecard_target", "target_type", "required_evidence_artifact", "pass_condition"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

QN012 is the bite:

```text
the network can self-correct from Paul Revere letters
the letter is allowed to steer apparatus controls
the letter is forbidden from carrying the final answer
the pre-resolution log freezes before the final measurement log joins
```

The package is ready for a lab-facing QN013 live-data ingestion pass.

## Outputs

```text
artifacts/qn012/trial_role_map_template.csv
artifacts/qn012/pre_resolution_trial_log_template.csv
artifacts/qn012/paul_revere_self_correction_map.csv
artifacts/qn012/allowed_letter_correction_log_template.csv
artifacts/qn012/route_stability_surface_input_template.csv
artifacts/qn012/leakage_firewall_report_template.csv
artifacts/qn012/post_write_join_manifest_template.csv
artifacts/qn012/sam_qn_live_protocol_scorecard.csv
artifacts/qn012/sam_qn_live_data_package_manifest.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = [
        QN011_SUMMARY,
        QN011_REQUIREMENTS,
        QN011_STEPS,
        QN011_OBSERVABLES,
        QN011_CRITERIA,
        QN011_MILESTONES,
    ]
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])
    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN012 inputs: {missing}")

    qn011_summary = read_json(QN011_SUMMARY)
    requirements = read_csv(QN011_REQUIREMENTS)
    steps = read_csv(QN011_STEPS)
    observables = read_csv(QN011_OBSERVABLES)
    milestones = read_csv(QN011_MILESTONES)

    role_rows = build_trial_role_map(requirements)
    prelog_rows = build_pre_resolution_log_template(steps)
    correction_rows = build_correction_log_template()
    route_rows = build_route_stability_template()
    leak_rows = build_leakage_firewall_template(observables)
    join_rows = build_post_write_join_template()
    scorecard_rows = build_live_scorecard(requirements, milestones)
    package_rows = build_data_package_manifest()
    checks = build_checks(
        qn011_summary,
        role_rows,
        prelog_rows,
        PAUL_REVERE_ROWS,
        correction_rows,
        route_rows,
        leak_rows,
        join_rows,
        scorecard_rows,
        package_rows,
    )
    wrong_controls = build_wrong_controls(prelog_rows, PAUL_REVERE_ROWS, leak_rows, join_rows, scorecard_rows)
    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)

    summary = {
        "artifact": "QN012_PRIVATE_LIVE_PROTOCOL_SCORECARD_AND_DATA_PACKAGE",
        "result_class": "QN012_LIVE_PROTOCOL_SCORECARD_DATA_PACKAGE_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY_QN011_DERIVED",
        "test_type": "FORWARD_LIVE_PROTOCOL_SCORECARD_DATA_PACKAGE",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": True,
        "external_data_allowed_by": "QN010_APPROVED_SOURCE_MANIFEST_IMPORTED_THROUGH_QN011",
        "new_external_source_intake": False,
        "free_parameters_introduced": 0,
        "qn011_result_class": qn011_summary["result_class"],
        "selected_candidate": qn011_summary["selected_candidate"],
        "data_package_files": len(package_rows),
        "trial_role_rows": len(role_rows),
        "pre_resolution_log_rows": len(prelog_rows),
        "paul_revere_letter_rows": len(PAUL_REVERE_ROWS),
        "correction_log_rows": len(correction_rows),
        "route_stability_rows": len(route_rows),
        "leakage_firewall_rows": len(leak_rows),
        "post_write_join_rows": len(join_rows),
        "scorecard_rows": len(scorecard_rows),
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "forbidden_fields_used": False,
        "next_frontier": "QN013_PRIVATE_LIVE_DATA_INGESTION_AND_SCORING_PROTOCOL",
    }

    write_csv(
        TRIAL_ROLE_MAP_OUT,
        role_rows,
        [
            "role_map_id",
            "candidate_platform",
            "sam_role",
            "physical_component_required",
            "allowed_pre_write_letters",
            "forbidden_pre_write_content",
            "trial_log_field_prefix",
            "required_before_trial_scoring",
        ],
    )
    write_csv(
        PRE_RESOLUTION_LOG_OUT,
        prelog_rows,
        [
            "template_row_id",
            "trial_id",
            "pre_write_timestamp",
            "step_id",
            "requirement_id",
            "allowed_letter_channel",
            "observed_letter_value",
            "control_command",
            "window_open_flag",
            "pre_resolution_hash_input",
            "final_ledger_outcome",
            "logical_route_identity",
            "selected_final_result",
        ],
    )
    write_csv(
        PAUL_REVERE_MAP_OUT,
        PAUL_REVERE_ROWS,
        ["letter_id", "warning_letter", "allowed_control_action", "expected_self_correction_effect", "forbidden_payload"],
    )
    write_csv(
        CORRECTION_LOG_OUT,
        correction_rows,
        [
            "correction_row_id",
            "trial_id",
            "letter_id",
            "warning_letter",
            "allowed_control_action",
            "actual_control_action",
            "action_timestamp",
            "window_open_flag",
            "used_final_outcome",
            "used_logical_route_identity",
            "forbidden_payload",
        ],
    )
    write_csv(
        ROUTE_STABILITY_OUT,
        route_rows,
        [
            "surface_row_id",
            "trial_id",
            "route_class",
            "route_description",
            "open_window_gate",
            "carrier_survival",
            "link_stability",
            "route_drop_reason",
            "pre_final_label_join",
            "final_ledger_outcome",
            "logical_route_identity",
        ],
    )
    write_csv(
        LEAKAGE_FIREWALL_OUT,
        leak_rows,
        [
            "firewall_row_id",
            "forbidden_item",
            "allowed_pre_write_count",
            "observed_pre_write_count",
            "blocker_if_observed",
            "scorecard_status_if_observed",
            "allowed_after_write",
        ],
    )
    write_csv(
        POST_WRITE_JOIN_OUT,
        join_rows,
        [
            "join_manifest_id",
            "trial_id",
            "pre_resolution_trial_log_hash",
            "pre_resolution_log_frozen_before_join",
            "final_measurement_log_id",
            "selected_write_timestamp",
            "join_timestamp",
            "join_after_selected_write",
            "pre_write_final_leakage_count",
            "post_write_join_allowed",
        ],
    )
    write_csv(
        LIVE_SCORECARD_OUT,
        scorecard_rows,
        [
            "scorecard_id",
            "scorecard_target",
            "target_type",
            "sealed_object",
            "required_evidence_artifact",
            "pass_condition",
            "partial_condition",
            "blocker_condition",
            "status_values",
            "numeric_weight_or_fit",
        ],
    )
    write_csv(
        DATA_PACKAGE_MANIFEST_OUT,
        package_rows,
        ["package_file", "role", "required_for_qn012", "contains_external_live_data_now", "allowed_to_receive_live_lab_data_in_qn013"],
    )
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, PAUL_REVERE_ROWS, package_rows, scorecard_rows, checks, wrong_controls)


if __name__ == "__main__":
    main()
