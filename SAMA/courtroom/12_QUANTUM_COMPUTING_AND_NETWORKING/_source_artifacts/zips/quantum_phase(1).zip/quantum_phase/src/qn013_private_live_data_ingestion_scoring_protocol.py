from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QN013_DIR = ARTIFACTS / "qn013"

QN012_SUMMARY = ARTIFACTS / "qn012" / "qn012_summary.json"
QN012_PACKAGE = ARTIFACTS / "qn012" / "sam_qn_live_data_package_manifest.csv"
QN012_SCORECARD = ARTIFACTS / "qn012" / "sam_qn_live_protocol_scorecard.csv"
QN012_PRELOG_TEMPLATE = ARTIFACTS / "qn012" / "pre_resolution_trial_log_template.csv"
QN012_CORRECTION_TEMPLATE = ARTIFACTS / "qn012" / "allowed_letter_correction_log_template.csv"
QN012_ROUTE_TEMPLATE = ARTIFACTS / "qn012" / "route_stability_surface_input_template.csv"
QN012_LEAK_TEMPLATE = ARTIFACTS / "qn012" / "leakage_firewall_report_template.csv"
QN012_JOIN_TEMPLATE = ARTIFACTS / "qn012" / "post_write_join_manifest_template.csv"

PREFLIGHT_OUT = QN013_DIR / "qn013_preflight.md"
INPUT_MANIFEST_OUT = QN013_DIR / "qn013_input_manifest.csv"
INGESTION_SCHEMA_OUT = QN013_DIR / "sam_qn_ingestion_schema.csv"
VALIDATION_RULES_OUT = QN013_DIR / "sam_qn_live_data_validation_rules.csv"
TRIAL_SCORE_RULES_OUT = QN013_DIR / "sam_qn_trial_score_rules.csv"
DEMO_PRELOG_OUT = QN013_DIR / "sam_qn_ingestion_demo_pre_resolution_log.csv"
DEMO_CORRECTION_OUT = QN013_DIR / "sam_qn_ingestion_demo_correction_log.csv"
DEMO_ROUTE_OUT = QN013_DIR / "sam_qn_ingestion_demo_route_surface.csv"
DEMO_LEAK_OUT = QN013_DIR / "sam_qn_ingestion_demo_leakage_report.csv"
DEMO_JOIN_OUT = QN013_DIR / "sam_qn_ingestion_demo_post_write_join.csv"
DEMO_SCORECARD_OUT = QN013_DIR / "sam_qn_ingestion_demo_scorecard.csv"
TRIAL_SCORE_OUTPUT_TEMPLATE_OUT = QN013_DIR / "sam_qn_trial_score_output_template.csv"
CHECKS_OUT = QN013_DIR / "qn013_checks.csv"
WRONG_CONTROLS_OUT = QN013_DIR / "qn013_wrong_controls.csv"
SUMMARY_OUT = QN013_DIR / "qn013_summary.json"
NEXT_OUT = QN013_DIR / "qn013_next_frontier.csv"
REPORT_OUT = REPORTS / "QN013_PRIVATE_LIVE_DATA_INGESTION_SCORING_PROTOCOL.md"


TRIALS = [
    {
        "trial_id": "DEMO-PASS-001",
        "trial_class": "CLEAN_SELF_CORRECTION",
        "letters": "polarization drift;window-open flag;syndrome_signal",
        "control_actions": "update polarization compensation command;apply letter-safe correction command",
        "window_open": True,
        "final_leak_count": 0,
        "missing_required_count": 0,
        "route_surface_ready": True,
        "post_write_join_after_hash": True,
        "expected_status": "PASS",
    },
    {
        "trial_id": "DEMO-PARTIAL-001",
        "trial_class": "PARTIAL_ROUTE_SURFACE",
        "letters": "timing headroom;failed-link notice",
        "control_actions": "hold relay attempt inside open window;retry source/link preparation",
        "window_open": True,
        "final_leak_count": 0,
        "missing_required_count": 1,
        "route_surface_ready": False,
        "post_write_join_after_hash": True,
        "expected_status": "PARTIAL",
    },
    {
        "trial_id": "DEMO-BLOCK-001",
        "trial_class": "FORBIDDEN_EARLY_FINAL_ANSWER",
        "letters": "polarization drift;final_ledger_outcome",
        "control_actions": "update polarization compensation command from final outcome",
        "window_open": True,
        "final_leak_count": 1,
        "missing_required_count": 0,
        "route_surface_ready": True,
        "post_write_join_after_hash": False,
        "expected_status": "SAM_BLOCKER",
    },
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QN013_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QN013 Preflight - Live Data Ingestion and Scoring Protocol

## Mode

```text
FORWARD_LIVE_DATA_INGESTION_SCORING_PROTOCOL
```

## Test Rule Declaration

```text
is_audit_or_retest = false
confirmation_or_double_check = false
new_forward_work = true
```

QN013 does not rerun QN001-QN012. It builds the live ingestion/scoring engine
for the QN012 blank data package. Demo rows are synthetic protocol fixtures
used to prove the scorer mechanics; they are not external benchmark data.

## Question

```text
Can SAM ingest a filled QN012-style data package and score self-correction by
Paul Revere letters without reading the final answer before write?
```

## Success Condition

```text
The scorer returns PASS/PARTIAL/NOT_READY/SAM_BLOCKER from package validity,
temporal order, self-correction evidence, route-surface readiness, and leakage
firewall rules.
```
""",
        encoding="utf-8",
    )


def build_input_manifest(paths: list[Path]) -> list[dict[str, object]]:
    return [
        {
            "input_path": str(path.relative_to(ROOT)),
            "exists": path.exists(),
            "source_role": "FROZEN_QN012_INPUT",
        }
        for path in paths
    ]


def hash_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def build_ingestion_schema(package_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    rows = []
    for row in package_rows:
        rows.append(
            {
                "schema_id": f"QN013-SCHEMA-{len(rows)+1:02d}",
                "package_file": row["package_file"],
                "required_for_ingestion": row["required_for_qn012"],
                "live_data_allowed": row["allowed_to_receive_live_lab_data_in_qn013"],
                "validation_mode": "template_columns_plus_trial_id" if "template" in row["package_file"] else "scorecard_status_columns",
                "ingestion_status_if_missing": "NOT_READY",
            }
        )
    return rows


def build_validation_rules() -> list[dict[str, object]]:
    return [
        {
            "rule_id": "QN013-VAL-01",
            "rule": "required package file is present",
            "failure_status": "NOT_READY",
            "hard_blocker": False,
        },
        {
            "rule_id": "QN013-VAL-02",
            "rule": "pre-resolution rows contain trial_id, timestamp, allowed letter value, control command, and hash input",
            "failure_status": "NOT_READY",
            "hard_blocker": False,
        },
        {
            "rule_id": "QN013-VAL-03",
            "rule": "pre-resolution rows do not contain final_ledger_outcome, logical_route_identity, or selected_final_result",
            "failure_status": "SAM_BLOCKER",
            "hard_blocker": True,
        },
        {
            "rule_id": "QN013-VAL-04",
            "rule": "Paul Revere warning letter maps to an allowed control action",
            "failure_status": "PARTIAL",
            "hard_blocker": False,
        },
        {
            "rule_id": "QN013-VAL-05",
            "rule": "route-stability rows are computed before final-label join",
            "failure_status": "PARTIAL",
            "hard_blocker": False,
        },
        {
            "rule_id": "QN013-VAL-06",
            "rule": "post-write join occurs only after pre-resolution hash freeze",
            "failure_status": "SAM_BLOCKER",
            "hard_blocker": True,
        },
    ]


def build_score_rules() -> list[dict[str, object]]:
    return [
        {
            "status": "PASS",
            "condition": "package complete; no leakage; self-correction observed; route surface ready; post-write join after hash",
            "meaning": "trial behaves like SAM Paul Revere self-correction",
        },
        {
            "status": "PARTIAL",
            "condition": "no leakage, but one non-blocking surface or evidence field is incomplete",
            "meaning": "trial is usable but does not close all protocol targets",
        },
        {
            "status": "NOT_READY",
            "condition": "required package files or required trial fields are missing before scoring",
            "meaning": "trial cannot yet be scored",
        },
        {
            "status": "SAM_BLOCKER",
            "condition": "forbidden final content appears before write or post-write join happens before hash freeze",
            "meaning": "trial violates SAM leakage boundary",
        },
    ]


def build_demo_prelog() -> list[dict[str, object]]:
    rows = []
    for trial in TRIALS:
        rows.append(
            {
                "trial_id": trial["trial_id"],
                "pre_write_timestamp": "T-001",
                "observed_warning_letters": trial["letters"],
                "control_command": trial["control_actions"],
                "window_open_flag": trial["window_open"],
                "pre_resolution_hash": hash_text(trial["trial_id"] + trial["letters"] + trial["control_actions"]),
                "final_ledger_outcome": "LEAKED_FINAL" if trial["final_leak_count"] else "",
                "logical_route_identity": "LEAKED_ROUTE" if trial["final_leak_count"] else "",
                "selected_final_result": "LEAKED_SELECTION" if trial["final_leak_count"] else "",
            }
        )
    return rows


def build_demo_correction_log() -> list[dict[str, object]]:
    rows = []
    for trial in TRIALS:
        rows.append(
            {
                "trial_id": trial["trial_id"],
                "observed_warning_letters": trial["letters"],
                "actual_control_action": trial["control_actions"],
                "used_final_outcome": trial["final_leak_count"] > 0,
                "used_logical_route_identity": trial["final_leak_count"] > 0,
                "self_correction_observed": trial["final_leak_count"] == 0 and bool(trial["control_actions"]),
            }
        )
    return rows


def build_demo_route_surface() -> list[dict[str, object]]:
    rows = []
    for trial in TRIALS:
        rows.append(
            {
                "trial_id": trial["trial_id"],
                "open_window_gate": trial["window_open"],
                "route_class": "QUBIT-NL-001" if trial["route_surface_ready"] else "ROUTE-DROP",
                "carrier_survival": trial["route_surface_ready"],
                "link_stability": "READY" if trial["route_surface_ready"] else "INCOMPLETE",
                "pre_final_label_join": trial["route_surface_ready"],
                "route_surface_ready": trial["route_surface_ready"],
            }
        )
    return rows


def build_demo_leakage_report() -> list[dict[str, object]]:
    rows = []
    for trial in TRIALS:
        rows.append(
            {
                "trial_id": trial["trial_id"],
                "pre_write_final_leakage_count": trial["final_leak_count"],
                "final_ledger_outcome_seen_pre_write": trial["final_leak_count"] > 0,
                "logical_route_identity_seen_pre_write": trial["final_leak_count"] > 0,
                "scorecard_status_if_observed": "SAM_BLOCKER" if trial["final_leak_count"] else "PASS",
            }
        )
    return rows


def build_demo_join_manifest(prelog_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    prelog_by_trial = {row["trial_id"]: row for row in prelog_rows}
    rows = []
    for trial in TRIALS:
        rows.append(
            {
                "trial_id": trial["trial_id"],
                "pre_resolution_trial_log_hash": prelog_by_trial[trial["trial_id"]]["pre_resolution_hash"],
                "pre_resolution_log_frozen_before_join": trial["post_write_join_after_hash"],
                "join_after_selected_write": trial["post_write_join_after_hash"],
                "pre_write_final_leakage_count": trial["final_leak_count"],
                "post_write_join_allowed": trial["post_write_join_after_hash"] and trial["final_leak_count"] == 0,
            }
        )
    return rows


def score_trial(
    trial: dict[str, object],
    correction: dict[str, object],
    route: dict[str, object],
    leakage: dict[str, object],
    join: dict[str, object],
) -> tuple[str, str]:
    if int(leakage["pre_write_final_leakage_count"]) > 0:
        return "SAM_BLOCKER", "forbidden final content appeared before selected write"
    if str(join["pre_resolution_log_frozen_before_join"]).lower() != "true":
        return "SAM_BLOCKER", "post-write join occurred before pre-resolution hash freeze"
    if int(trial["missing_required_count"]) > 0:
        return "PARTIAL", "one required live package field is missing"
    if str(correction["self_correction_observed"]).lower() != "true":
        return "PARTIAL", "allowed warning letter did not produce a logged correction"
    if str(route["route_surface_ready"]).lower() != "true":
        return "PARTIAL", "route surface is not ready before final-label join"
    return "PASS", "self-correction by allowed Paul Revere letters with clean leakage boundary"


def build_demo_scorecard(
    corrections: list[dict[str, object]],
    routes: list[dict[str, object]],
    leaks: list[dict[str, object]],
    joins: list[dict[str, object]],
) -> list[dict[str, object]]:
    corrections_by_trial = {row["trial_id"]: row for row in corrections}
    routes_by_trial = {row["trial_id"]: row for row in routes}
    leaks_by_trial = {row["trial_id"]: row for row in leaks}
    joins_by_trial = {row["trial_id"]: row for row in joins}
    rows = []
    for trial in TRIALS:
        status, reason = score_trial(
            trial,
            corrections_by_trial[trial["trial_id"]],
            routes_by_trial[trial["trial_id"]],
            leaks_by_trial[trial["trial_id"]],
            joins_by_trial[trial["trial_id"]],
        )
        rows.append(
            {
                "trial_id": trial["trial_id"],
                "trial_class": trial["trial_class"],
                "expected_status": trial["expected_status"],
                "scored_status": status,
                "score_reason": reason,
                "self_correction_observed": corrections_by_trial[trial["trial_id"]]["self_correction_observed"],
                "route_surface_ready": routes_by_trial[trial["trial_id"]]["route_surface_ready"],
                "pre_write_final_leakage_count": leaks_by_trial[trial["trial_id"]]["pre_write_final_leakage_count"],
                "post_write_join_after_hash": joins_by_trial[trial["trial_id"]]["pre_resolution_log_frozen_before_join"],
                "score_matches_expected": status == trial["expected_status"],
            }
        )
    return rows


def build_output_template() -> list[dict[str, object]]:
    return [
        {
            "trial_id": "LIVE_TRIAL_ID",
            "scored_status": "PASS_OR_PARTIAL_OR_NOT_READY_OR_SAM_BLOCKER",
            "score_reason": "SCORER_OUTPUT",
            "self_correction_observed": "TRUE_FALSE",
            "route_surface_ready": "TRUE_FALSE",
            "pre_write_final_leakage_count": "INTEGER",
            "post_write_join_after_hash": "TRUE_FALSE",
        }
    ]


def build_checks(
    qn012_summary: dict[str, object],
    schema_rows: list[dict[str, object]],
    score_rows: list[dict[str, object]],
    prelog_rows: list[dict[str, object]],
    correction_rows: list[dict[str, object]],
    route_rows: list[dict[str, object]],
    leak_rows: list[dict[str, object]],
    join_rows: list[dict[str, object]],
) -> list[dict[str, object]]:
    expected_statuses = {row["expected_status"] for row in score_rows}
    scored_statuses = {row["scored_status"] for row in score_rows}
    all_expected = all(row["score_matches_expected"] is True for row in score_rows)
    blocker_row = next(row for row in score_rows if row["scored_status"] == "SAM_BLOCKER")
    pass_row = next(row for row in score_rows if row["scored_status"] == "PASS")
    prelog_hashes = all(str(row["pre_resolution_hash"]) for row in prelog_rows)
    schema_complete = len(schema_rows) == int(qn012_summary["data_package_files"])
    return [
        {
            "check_id": "QN013_CHECK_01",
            "check": "QN012 live data package exists before scorer",
            "pass": qn012_summary["result_class"] == "QN012_LIVE_PROTOCOL_SCORECARD_DATA_PACKAGE_BUILT",
            "detail": qn012_summary["selected_candidate"],
        },
        {
            "check_id": "QN013_CHECK_02",
            "check": "ingestion schema covers every QN012 package file",
            "pass": schema_complete,
            "detail": len(schema_rows),
        },
        {
            "check_id": "QN013_CHECK_03",
            "check": "demo scorer produces PASS/PARTIAL/SAM_BLOCKER coverage",
            "pass": {"PASS", "PARTIAL", "SAM_BLOCKER"}.issubset(scored_statuses),
            "detail": ";".join(sorted(scored_statuses)),
        },
        {
            "check_id": "QN013_CHECK_04",
            "check": "demo scored statuses match expected fixture statuses",
            "pass": all_expected,
            "detail": ";".join(sorted(expected_statuses)),
        },
        {
            "check_id": "QN013_CHECK_05",
            "check": "self-correction pass trial has no final leakage and has correction",
            "pass": pass_row["self_correction_observed"] is True and int(pass_row["pre_write_final_leakage_count"]) == 0,
            "detail": pass_row["trial_id"],
        },
        {
            "check_id": "QN013_CHECK_06",
            "check": "forbidden early final answer becomes SAM_BLOCKER",
            "pass": blocker_row["trial_id"] == "DEMO-BLOCK-001",
            "detail": blocker_row["score_reason"],
        },
        {
            "check_id": "QN013_CHECK_07",
            "check": "pre-resolution rows carry hashes before final join",
            "pass": prelog_hashes and all(str(row["pre_resolution_log_frozen_before_join"]).lower() in {"true", "false"} for row in join_rows),
            "detail": len(prelog_rows),
        },
        {
            "check_id": "QN013_CHECK_08",
            "check": "route and correction demo tables cover all trials",
            "pass": len(correction_rows) == len(route_rows) == len(leak_rows) == len(join_rows) == len(TRIALS),
            "detail": len(TRIALS),
        },
    ]


def build_wrong_controls(score_rows: list[dict[str, object]], prelog_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    blocked_trial_passed = any(row["trial_id"] == "DEMO-BLOCK-001" and row["scored_status"] != "SAM_BLOCKER" for row in score_rows)
    pass_trial_blocked = any(row["trial_id"] == "DEMO-PASS-001" and row["scored_status"] != "PASS" for row in score_rows)
    partial_trial_passed = any(row["trial_id"] == "DEMO-PARTIAL-001" and row["scored_status"] == "PASS" for row in score_rows)
    missing_hash = any(not str(row["pre_resolution_hash"]) for row in prelog_rows)
    unsupported_status = any(row["scored_status"] not in {"PASS", "PARTIAL", "NOT_READY", "SAM_BLOCKER"} for row in score_rows)
    return [
        {
            "control_id": "QN013_WC_01",
            "wrong_control": "leakage trial is scored as non-blocker",
            "expected": False,
            "actual": blocked_trial_passed,
            "pass": not blocked_trial_passed,
        },
        {
            "control_id": "QN013_WC_02",
            "wrong_control": "clean self-correction trial does not pass",
            "expected": False,
            "actual": pass_trial_blocked,
            "pass": not pass_trial_blocked,
        },
        {
            "control_id": "QN013_WC_03",
            "wrong_control": "partial route-surface trial is scored as full pass",
            "expected": False,
            "actual": partial_trial_passed,
            "pass": not partial_trial_passed,
        },
        {
            "control_id": "QN013_WC_04",
            "wrong_control": "pre-resolution hash is missing",
            "expected": False,
            "actual": missing_hash,
            "pass": not missing_hash,
        },
        {
            "control_id": "QN013_WC_05",
            "wrong_control": "unsupported score status appears",
            "expected": False,
            "actual": unsupported_status,
            "pass": not unsupported_status,
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str]) -> str:
    lines = [
        "| " + " | ".join(fields) + " |",
        "| " + " | ".join("---" for _ in fields) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(
    summary: dict[str, object],
    score_rows: list[dict[str, object]],
    validation_rows: list[dict[str, object]],
    checks: list[dict[str, object]],
    wrong_controls: list[dict[str, object]],
) -> None:
    REPORTS.mkdir(parents=True, exist_ok=True)
    REPORT_OUT.write_text(
        f"""# QN013 - Private Live Data Ingestion and Scoring Protocol

## Result

```text
{summary["result_class"]}
```

QN013 builds the scorer for QN012-style lab data.

## Main Readout

```text
demo_trials = {summary["demo_trials"]}
pass_trials = {summary["pass_trials"]}
partial_trials = {summary["partial_trials"]}
blocker_trials = {summary["blocker_trials"]}
validation_rule_rows = {summary["validation_rule_rows"]}
score_rule_rows = {summary["score_rule_rows"]}
check_passes = {summary["check_passes"]}/{summary["check_total"]}
wrong_control_passes = {summary["wrong_control_passes"]}/{summary["wrong_control_total"]}
free_parameters_introduced = {summary["free_parameters_introduced"]}
```

## Demo Scorecard

{markdown_table(score_rows, ["trial_id", "trial_class", "expected_status", "scored_status", "score_reason"])}

## Validation Rules

{markdown_table(validation_rows, ["rule_id", "rule", "failure_status", "hard_blocker"])}

## Checks

{markdown_table(checks, ["check_id", "check", "pass", "detail"])}

## Wrong Controls

{markdown_table(wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])}

## Interpretation

QN013 makes the Paul Revere idea executable:

```text
PASS means a warning letter changed apparatus controls without carrying the answer
PARTIAL means the trial is clean but one live evidence surface is incomplete
SAM_BLOCKER means the final answer leaked into the pre-write channel
```

## Outputs

```text
artifacts/qn013/sam_qn_ingestion_schema.csv
artifacts/qn013/sam_qn_live_data_validation_rules.csv
artifacts/qn013/sam_qn_trial_score_rules.csv
artifacts/qn013/sam_qn_ingestion_demo_scorecard.csv
artifacts/qn013/sam_qn_trial_score_output_template.csv
```

## Next Frontier

```text
{summary["next_frontier"]}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    input_paths = [
        QN012_SUMMARY,
        QN012_PACKAGE,
        QN012_SCORECARD,
        QN012_PRELOG_TEMPLATE,
        QN012_CORRECTION_TEMPLATE,
        QN012_ROUTE_TEMPLATE,
        QN012_LEAK_TEMPLATE,
        QN012_JOIN_TEMPLATE,
    ]
    manifest = build_input_manifest(input_paths)
    write_csv(INPUT_MANIFEST_OUT, manifest, ["input_path", "exists", "source_role"])
    if not all(row["exists"] for row in manifest):
        missing = [row["input_path"] for row in manifest if not row["exists"]]
        raise FileNotFoundError(f"Missing QN013 inputs: {missing}")

    qn012_summary = read_json(QN012_SUMMARY)
    package_rows = read_csv(QN012_PACKAGE)

    ingestion_schema = build_ingestion_schema(package_rows)
    validation_rules = build_validation_rules()
    score_rules = build_score_rules()
    demo_prelog = build_demo_prelog()
    demo_corrections = build_demo_correction_log()
    demo_routes = build_demo_route_surface()
    demo_leaks = build_demo_leakage_report()
    demo_join = build_demo_join_manifest(demo_prelog)
    demo_scorecard = build_demo_scorecard(demo_corrections, demo_routes, demo_leaks, demo_join)
    output_template = build_output_template()
    checks = build_checks(
        qn012_summary,
        ingestion_schema,
        demo_scorecard,
        demo_prelog,
        demo_corrections,
        demo_routes,
        demo_leaks,
        demo_join,
    )
    wrong_controls = build_wrong_controls(demo_scorecard, demo_prelog)
    check_passes = sum(row["pass"] is True for row in checks)
    wrong_control_passes = sum(row["pass"] is True for row in wrong_controls)
    pass_trials = sum(row["scored_status"] == "PASS" for row in demo_scorecard)
    partial_trials = sum(row["scored_status"] == "PARTIAL" for row in demo_scorecard)
    not_ready_trials = sum(row["scored_status"] == "NOT_READY" for row in demo_scorecard)
    blocker_trials = sum(row["scored_status"] == "SAM_BLOCKER" for row in demo_scorecard)

    summary = {
        "artifact": "QN013_PRIVATE_LIVE_DATA_INGESTION_AND_SCORING_PROTOCOL",
        "result_class": "QN013_LIVE_DATA_INGESTION_SCORING_PROTOCOL_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY_QN012_DERIVED",
        "test_type": "FORWARD_LIVE_DATA_INGESTION_SCORING_PROTOCOL",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_quantum_network_data_used": True,
        "external_data_allowed_by": "QN010_APPROVED_SOURCE_MANIFEST_IMPORTED_THROUGH_QN012",
        "new_external_source_intake": False,
        "demo_data_only": True,
        "free_parameters_introduced": 0,
        "qn012_result_class": qn012_summary["result_class"],
        "ingestion_schema_rows": len(ingestion_schema),
        "validation_rule_rows": len(validation_rules),
        "score_rule_rows": len(score_rules),
        "demo_trials": len(demo_scorecard),
        "pass_trials": pass_trials,
        "partial_trials": partial_trials,
        "not_ready_trials": not_ready_trials,
        "blocker_trials": blocker_trials,
        "check_passes": check_passes,
        "check_total": len(checks),
        "wrong_control_passes": wrong_control_passes,
        "wrong_control_total": len(wrong_controls),
        "forbidden_fields_used": False,
        "next_frontier": "QN014_PRIVATE_LAB_HANDOFF_PACKET_AND_EXTERNAL_TRIAL_READINESS",
    }

    write_csv(INGESTION_SCHEMA_OUT, ingestion_schema, ["schema_id", "package_file", "required_for_ingestion", "live_data_allowed", "validation_mode", "ingestion_status_if_missing"])
    write_csv(VALIDATION_RULES_OUT, validation_rules, ["rule_id", "rule", "failure_status", "hard_blocker"])
    write_csv(TRIAL_SCORE_RULES_OUT, score_rules, ["status", "condition", "meaning"])
    write_csv(DEMO_PRELOG_OUT, demo_prelog, ["trial_id", "pre_write_timestamp", "observed_warning_letters", "control_command", "window_open_flag", "pre_resolution_hash", "final_ledger_outcome", "logical_route_identity", "selected_final_result"])
    write_csv(DEMO_CORRECTION_OUT, demo_corrections, ["trial_id", "observed_warning_letters", "actual_control_action", "used_final_outcome", "used_logical_route_identity", "self_correction_observed"])
    write_csv(DEMO_ROUTE_OUT, demo_routes, ["trial_id", "open_window_gate", "route_class", "carrier_survival", "link_stability", "pre_final_label_join", "route_surface_ready"])
    write_csv(DEMO_LEAK_OUT, demo_leaks, ["trial_id", "pre_write_final_leakage_count", "final_ledger_outcome_seen_pre_write", "logical_route_identity_seen_pre_write", "scorecard_status_if_observed"])
    write_csv(DEMO_JOIN_OUT, demo_join, ["trial_id", "pre_resolution_trial_log_hash", "pre_resolution_log_frozen_before_join", "join_after_selected_write", "pre_write_final_leakage_count", "post_write_join_allowed"])
    write_csv(DEMO_SCORECARD_OUT, demo_scorecard, ["trial_id", "trial_class", "expected_status", "scored_status", "score_reason", "self_correction_observed", "route_surface_ready", "pre_write_final_leakage_count", "post_write_join_after_hash", "score_matches_expected"])
    write_csv(TRIAL_SCORE_OUTPUT_TEMPLATE_OUT, output_template, ["trial_id", "scored_status", "score_reason", "self_correction_observed", "route_surface_ready", "pre_write_final_leakage_count", "post_write_join_after_hash"])
    write_csv(CHECKS_OUT, checks, ["check_id", "check", "pass", "detail"])
    write_csv(WRONG_CONTROLS_OUT, wrong_controls, ["control_id", "wrong_control", "expected", "actual", "pass"])
    write_json(SUMMARY_OUT, summary)
    write_csv(NEXT_OUT, [{"next_frontier": summary["next_frontier"]}], ["next_frontier"])
    write_report(summary, demo_scorecard, validation_rules, checks, wrong_controls)


if __name__ == "__main__":
    main()
