from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SUMMARY_IN = ROOT / "phase_field_engine_summary.json"
QUBIT_IN = ROOT / "qubit_engineering_table.csv"

SUMMARY_OUT = ROOT / "qp001_phase_functional_summary.json"
TRANSITIONS_OUT = ROOT / "qp001_threshold_transition_law.csv"
QUBIT_OUT = ROOT / "qp001_qubit_phase_functional_table.csv"
SAMPLE_OUT = ROOT / "qp001_route_evolution_samples.csv"
NEXT_OUT = ROOT / "qp001_next_frontier.csv"
DOC_OUT = ROOT / "QP001_PRIVATE_PHASE_FUNCTIONAL_BRIDGE.md"


@dataclass(frozen=True)
class Thresholds:
    a_side: float
    a_share: float
    a_d_block: float
    a_alpha_h_sq: float
    a_alpha_h_d: float
    a_horizon: float


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fmt(value: float) -> str:
    return f"{value:.12g}"


def load_thresholds(summary: dict[str, object]) -> Thresholds:
    by_name = {row["name"]: row["value"] for row in summary["thresholds"]}
    return Thresholds(
        a_side=float(by_name["A_SIDE"]),
        a_share=float(by_name["A_SHARE"]),
        a_d_block=float(by_name["A_D_BLOCK"]),
        a_alpha_h_sq=float(by_name["A_ALPHA_H_SQ"]),
        a_alpha_h_d=float(by_name["A_ALPHA_H_D"]),
        a_horizon=float(by_name["A_HORIZON"]),
    )


def state_class(a_route: float, th: Thresholds) -> str:
    if a_route < th.a_side:
        return "PRE_WRITE_PHASE"
    if a_route < th.a_share:
        return "REORGANIZATION_ONSET"
    if a_route < th.a_d_block:
        return "INTERACTION_WRITE"
    if a_route < th.a_alpha_h_sq:
        return "MEASUREMENT_WRITE"
    if a_route < th.a_alpha_h_d:
        return "BOUNDARY_QG_ROUTE"
    return "POST_WRITE_CLASSICAL"


def clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def write_accessibility(a_route: float, th: Thresholds) -> float:
    """0 below half-write, 1 by first full share."""

    return clamp01((a_route - th.a_side) / (th.a_share - th.a_side))


def qg_competition(a_route: float, th: Thresholds) -> float:
    """0 before alpha_H^2 share, 1 by the WRITE midpoint."""

    return clamp01((a_route - th.a_alpha_h_sq) / (th.a_alpha_h_d - th.a_alpha_h_sq))


def phase_coherence(a_route: float, th: Thresholds) -> float:
    """Native phase availability under the threshold ladder."""

    return 1.0 - max(write_accessibility(a_route, th), qg_competition(a_route, th))


def ledger_status(a_route: float, th: Thresholds) -> str:
    if a_route < th.a_side:
        return "NO_LEDGER_WRITE_ACCESS"
    if a_route < th.a_share:
        return "WRITE_CANDIDATE_NOT_FORCED"
    if a_route < th.a_alpha_h_d:
        return "LEDGER_WRITE_ACCESSIBLE_BY_A_RESOLUTION"
    return "LEDGER_WRITE_COMMITTED_CLASSICAL"


def ticks_to(target: float, rate_per_tick: float) -> float:
    if rate_per_tick <= 0:
        return float("inf")
    return target / rate_per_tick


def build_transition_rows(th: Thresholds) -> list[dict[str, object]]:
    points = [
        ("A_0", 0.0, "phase-route start"),
        ("A_SIDE", th.a_side, "half-write quantum; first write candidacy"),
        ("A_SHARE", th.a_share, "first full sub-channel share; A-resolution can write"),
        ("A_D_BLOCK", th.a_d_block, "one D-block occupied"),
        ("A_ALPHA_H_SQ", th.a_alpha_h_sq, "alpha_H^2 route; QG boundary begins"),
        ("A_ALPHA_H_D", th.a_alpha_h_d, "WRITE midpoint; classical ledger commitment"),
        ("A_HORIZON", th.a_horizon, "substrate saturation; no independent phase route"),
    ]
    rows = []
    for name, value, meaning in points:
        rows.append(
            {
                "threshold": name,
                "A_route": value,
                "state_class": state_class(value, th),
                "write_accessibility": write_accessibility(value, th),
                "phase_coherence": phase_coherence(value, th),
                "qg_competition": qg_competition(value, th),
                "ledger_status": ledger_status(value, th),
                "meaning": meaning,
            }
        )
    return rows


def build_qubit_rows(qubit_rows: list[dict[str, str]], th: Thresholds, t_sw: float) -> list[dict[str, object]]:
    out = []
    for row in qubit_rows:
        rate = float(row["A_exposure_rate_per_t_SW"])
        t_side = ticks_to(th.a_side, rate)
        t_share = ticks_to(th.a_share, rate)
        t_d_block = ticks_to(th.a_d_block, rate)
        t_midpoint = ticks_to(th.a_alpha_h_d, rate)
        out.append(
            {
                "qubit_id": row["qubit_id"],
                "qubit_native_route": row["qubit_native_route"],
                "subchannel_partition": row["subchannel_partition"],
                "Q_native_class": row["Q_native_class"],
                "A_exposure_per_t_SW": rate,
                "ticks_to_A_SIDE": t_side,
                "ticks_to_A_SHARE": t_share,
                "ticks_to_A_D_BLOCK": t_d_block,
                "ticks_to_WRITE_MIDPOINT": t_midpoint,
                "seconds_to_A_SHARE": t_share * t_sw,
                "phase_rank_basis": t_share,
                "QP001_state_at_one_t_SW": state_class(rate, th),
                "QP001_write_accessibility_at_one_t_SW": write_accessibility(rate, th),
                "QP001_phase_coherence_at_one_t_SW": phase_coherence(rate, th),
                "QP001_ledger_status_at_one_t_SW": ledger_status(rate, th),
                "recommended_mode": row["recommended_mode"],
            }
        )
    out.sort(key=lambda item: float(item["phase_rank_basis"]), reverse=True)
    for index, row in enumerate(out, start=1):
        row["QP001_phase_safety_rank"] = index
    return out


def build_sample_rows(qubit_rows: list[dict[str, object]], th: Thresholds) -> list[dict[str, object]]:
    samples = [
        ("N0", 0.0),
        ("N_A_SIDE", th.a_side),
        ("N_A_SHARE", th.a_share),
        ("N_A_D_BLOCK", th.a_d_block),
        ("N_A_ALPHA_H_SQ", th.a_alpha_h_sq),
        ("N_WRITE_MIDPOINT", th.a_alpha_h_d),
    ]
    rows = []
    for qrow in qubit_rows:
        rate = float(qrow["A_exposure_per_t_SW"])
        for sample_id, a_target in samples:
            ticks = ticks_to(a_target, rate)
            a_route = rate * ticks if ticks != float("inf") else 0.0
            rows.append(
                {
                    "qubit_id": qrow["qubit_id"],
                    "sample_id": sample_id,
                    "ticks": ticks,
                    "A_route": a_route,
                    "state_class": state_class(a_route, th),
                    "write_accessibility": write_accessibility(a_route, th),
                    "phase_coherence": phase_coherence(a_route, th),
                    "qg_competition": qg_competition(a_route, th),
                    "ledger_status": ledger_status(a_route, th),
                }
            )
    return rows


def render_doc(summary: dict[str, object], transition_rows: list[dict[str, object]], qubit_rows: list[dict[str, object]]) -> str:
    top = qubit_rows[:4]
    lines = [
        "# QP001 - Private Phase Functional Bridge",
        "",
        "Location: `D:\\quantum_phase`",
        "",
        "## Verdict",
        "",
        "`QP001_PRIVATE_PHASE_FUNCTIONAL_BRIDGE_BUILT`",
        "",
        "QP001 turns the private phase-field threshold ladder into an accumulated-A route law.",
        "",
        "```text",
        "A_route[N+1] = A_route[N] + epsilon_route",
        "epsilon_route = A_exposure_per_t_SW",
        "state = state_class(A_route)",
        "write_accessibility = clamp((A_route - A_SIDE) / (A_SHARE - A_SIDE), 0, 1)",
        "qg_competition = clamp((A_route - A_ALPHA_H_SQ) / (A_ALPHA_H_D - A_ALPHA_H_SQ), 0, 1)",
        "phase_coherence = 1 - max(write_accessibility, qg_competition)",
        "```",
        "",
        "## Main Read",
        "",
        "The private ladder now behaves as a route functional. Below `A_SIDE = 1/24`,",
        "there is no ledger-write access. Between `A_SIDE` and `A_SHARE = 1/12`,",
        "write candidacy turns on. At and above `A_SHARE`, A-resolution can write.",
        "The per-route QG competition band begins at `A_ALPHA_H_SQ = 1/3` and",
        "reaches the WRITE midpoint at `A_ALPHA_H_D = 1/2`.",
        "",
        "## Phase Safety Leaders",
        "",
        "| Rank | Qubit | Route | ticks to A_SHARE | state at one t_SW |",
        "| ---: | --- | --- | ---: | --- |",
    ]
    for row in top:
        lines.append(
            "| {rank} | {qid} | {route} | {ticks} | {state} |".format(
                rank=row["QP001_phase_safety_rank"],
                qid=row["qubit_id"],
                route=row["qubit_native_route"],
                ticks=fmt(float(row["ticks_to_A_SHARE"])),
                state=row["QP001_state_at_one_t_SW"],
            )
        )
    lines.extend(
        [
            "",
            "## Outputs",
            "",
            "```text",
            "qp001_threshold_transition_law.csv",
            "qp001_qubit_phase_functional_table.csv",
            "qp001_route_evolution_samples.csv",
            "qp001_phase_functional_summary.json",
            "qp001_next_frontier.csv",
            "```",
            "",
            "## Next Frontier",
            "",
            "`QP002_PRIVATE_GAMMA_RES_PHASE_WRITE_SELECTOR`",
            "",
            "QP002 should use this functional to build the write selector:",
            "`Gamma_res^phase(A_route, X_contact, X_environment)`. That is the point",
            "where unresolved route evolution becomes a private, testable resolution",
            "law instead of only a threshold ladder.",
            "",
            f"Generated at UTC: `{summary['generated_at_utc']}`",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    summary_in = json.loads(SUMMARY_IN.read_text(encoding="utf-8-sig"))
    thresholds = load_thresholds(summary_in)
    t_sw = float(summary_in["constants"]["T_SW_s"])
    qubit_in = read_csv(QUBIT_IN)

    transition_rows = build_transition_rows(thresholds)
    qubit_rows = build_qubit_rows(qubit_in, thresholds, t_sw)
    sample_rows = build_sample_rows(qubit_rows, thresholds)
    next_rows = [
        {
            "frontier": "QP002_PRIVATE_GAMMA_RES_PHASE_WRITE_SELECTOR",
            "why_next": (
                "QP001 defines accumulated A_route, state class, write accessibility, "
                "QG competition, and phase coherence. QP002 should turn those into "
                "Gamma_res^phase with contact/environment gates."
            ),
            "input_surface": "qp001_qubit_phase_functional_table.csv",
            "target_output": "private Gamma_res phase/write selector",
        }
    ]
    summary = {
        "artifact": "QP001_PRIVATE_PHASE_FUNCTIONAL_BRIDGE",
        "result_class": "QP001_PRIVATE_PHASE_FUNCTIONAL_BRIDGE_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_D_DRIVE_QUANTUM_PHASE_ONLY",
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "route_functional": {
            "A_route_update": "A_route[N+1] = A_route[N] + A_exposure_per_t_SW",
            "write_accessibility": "clamp((A_route - A_SIDE)/(A_SHARE - A_SIDE), 0, 1)",
            "qg_competition": "clamp((A_route - A_ALPHA_H_SQ)/(A_ALPHA_H_D - A_ALPHA_H_SQ), 0, 1)",
            "phase_coherence": "1 - max(write_accessibility, qg_competition)",
        },
        "transition_rows": len(transition_rows),
        "qubit_rows": len(qubit_rows),
        "sample_rows": len(sample_rows),
        "top_phase_safe_qubit": qubit_rows[0]["qubit_id"],
        "top_phase_safe_ticks_to_A_SHARE": qubit_rows[0]["ticks_to_A_SHARE"],
        "write_onset_threshold": thresholds.a_side,
        "write_access_threshold": thresholds.a_share,
        "qg_boundary_start": thresholds.a_alpha_h_sq,
        "write_midpoint": thresholds.a_alpha_h_d,
        "next_frontier": "QP002_PRIVATE_GAMMA_RES_PHASE_WRITE_SELECTOR",
    }

    write_csv(
        TRANSITIONS_OUT,
        transition_rows,
        [
            "threshold",
            "A_route",
            "state_class",
            "write_accessibility",
            "phase_coherence",
            "qg_competition",
            "ledger_status",
            "meaning",
        ],
    )
    write_csv(
        QUBIT_OUT,
        qubit_rows,
        [
            "QP001_phase_safety_rank",
            "qubit_id",
            "qubit_native_route",
            "subchannel_partition",
            "Q_native_class",
            "A_exposure_per_t_SW",
            "ticks_to_A_SIDE",
            "ticks_to_A_SHARE",
            "ticks_to_A_D_BLOCK",
            "ticks_to_WRITE_MIDPOINT",
            "seconds_to_A_SHARE",
            "phase_rank_basis",
            "QP001_state_at_one_t_SW",
            "QP001_write_accessibility_at_one_t_SW",
            "QP001_phase_coherence_at_one_t_SW",
            "QP001_ledger_status_at_one_t_SW",
            "recommended_mode",
        ],
    )
    write_csv(
        SAMPLE_OUT,
        sample_rows,
        [
            "qubit_id",
            "sample_id",
            "ticks",
            "A_route",
            "state_class",
            "write_accessibility",
            "phase_coherence",
            "qg_competition",
            "ledger_status",
        ],
    )
    write_csv(NEXT_OUT, next_rows, ["frontier", "why_next", "input_surface", "target_output"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    DOC_OUT.write_text(render_doc(summary, transition_rows, qubit_rows), encoding="utf-8")

    print(summary["result_class"])
    print(f"transition_rows={summary['transition_rows']}")
    print(f"qubit_rows={summary['qubit_rows']}")
    print(f"sample_rows={summary['sample_rows']}")
    print(f"top_phase_safe_qubit={summary['top_phase_safe_qubit']}")
    print(f"top_phase_safe_ticks_to_A_SHARE={fmt(float(summary['top_phase_safe_ticks_to_A_SHARE']))}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
