from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
QP001_SUMMARY = ROOT / "qp001_phase_functional_summary.json"
QP001_QUBITS = ROOT / "qp001_qubit_phase_functional_table.csv"
QP001_SAMPLES = ROOT / "qp001_route_evolution_samples.csv"

SUMMARY_OUT = ROOT / "qp002_gamma_res_phase_selector_summary.json"
SELECTOR_OUT = ROOT / "qp002_gamma_res_phase_selector_table.csv"
SCENARIOS_OUT = ROOT / "qp002_resolution_scenarios.csv"
NEXT_OUT = ROOT / "qp002_next_frontier.csv"
DOC_OUT = ROOT / "QP002_PRIVATE_GAMMA_RES_PHASE_WRITE_SELECTOR.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fmt(value: float) -> str:
    return f"{value:.12g}"


def fnum(value: Any) -> float:
    return float(str(value).strip())


def clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def resolution_scenarios() -> list[dict[str, Any]]:
    return [
        {
            "scenario": "FREE_UNRESOLVED_ROUTE",
            "X_resolution": 0.0,
            "X_environment": 0.0,
            "X_contact": 0.0,
            "meaning": "route evolves as phase; no write gate is offered",
        },
        {
            "scenario": "ENVIRONMENT_RESOLUTION",
            "X_resolution": 1.0,
            "X_environment": 1.0,
            "X_contact": 0.0,
            "meaning": "environmental A exposure offers resolution without a deliberate measurement channel",
        },
        {
            "scenario": "CONTACT_RESOLUTION",
            "X_resolution": 1.0,
            "X_environment": 0.0,
            "X_contact": 1.0,
            "meaning": "direct interaction/contact offers resolution",
        },
        {
            "scenario": "MEASUREMENT_RESOLUTION",
            "X_resolution": 1.0,
            "X_environment": 0.0,
            "X_contact": 1.0,
            "meaning": "measurement is treated as an A-resolution channel, not as human observation",
        },
    ]


def gamma_res_phase(
    *,
    x_resolution: float,
    write_accessibility: float,
    qg_competition: float,
    a_route: float,
    write_midpoint: float,
) -> float:
    if a_route >= write_midpoint:
        return 1.0
    return clamp01(x_resolution * write_accessibility + qg_competition * (1.0 - write_accessibility))


def selector_status(gamma: float, a_route: float, write_onset: float, write_access: float, write_midpoint: float) -> str:
    if a_route < write_onset:
        return "PHASE_ONLY_NO_WRITE_ACCESS"
    if a_route < write_access:
        return "WRITE_CANDIDATE_REQUIRES_RESOLUTION"
    if a_route < write_midpoint and gamma <= 0:
        return "WRITE_ACCESSIBLE_BUT_UNRESOLVED"
    if a_route < write_midpoint:
        return "GAMMA_RES_PHASE_WRITE_SELECTED"
    return "CLASSICAL_LEDGER_COMMITTED"


def build_selector_rows(
    samples: list[dict[str, str]],
    scenarios: list[dict[str, Any]],
    thresholds: dict[str, float],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for sample in samples:
        a_route = fnum(sample["A_route"])
        write_accessibility = fnum(sample["write_accessibility"])
        qg_competition = fnum(sample["qg_competition"])
        phase_coherence = fnum(sample["phase_coherence"])
        for scenario in scenarios:
            gamma = gamma_res_phase(
                x_resolution=fnum(scenario["X_resolution"]),
                write_accessibility=write_accessibility,
                qg_competition=qg_competition,
                a_route=a_route,
                write_midpoint=thresholds["write_midpoint"],
            )
            rows.append(
                {
                    "selector_id": f"QP002_SEL_{len(rows) + 1:04d}",
                    "qubit_id": sample["qubit_id"],
                    "sample_id": sample["sample_id"],
                    "scenario": scenario["scenario"],
                    "A_route": a_route,
                    "state_class": sample["state_class"],
                    "X_resolution": scenario["X_resolution"],
                    "write_accessibility": write_accessibility,
                    "phase_coherence": phase_coherence,
                    "qg_competition": qg_competition,
                    "Gamma_res_phase": gamma,
                    "selector_status": selector_status(
                        gamma,
                        a_route,
                        thresholds["write_onset_threshold"],
                        thresholds["write_access_threshold"],
                        thresholds["write_midpoint"],
                    ),
                    "ledger_read": sample["ledger_status"],
                }
            )
    return rows


def render_doc(summary: dict[str, Any], rows: list[dict[str, Any]]) -> str:
    selected = summary["selected_write_rows"]
    forced = summary["forced_classical_rows"]
    blocked = summary["phase_only_rows"]
    lines = [
        "# QP002 - Private Gamma Res Phase Write Selector",
        "",
        "Location: `D:\\quantum_phase`",
        "",
        "## Verdict",
        "",
        "`QP002_PRIVATE_GAMMA_RES_PHASE_WRITE_SELECTOR_BUILT`",
        "",
        "QP002 converts the QP001 accumulated-A route functional into a private",
        "`Gamma_res^phase` selector.",
        "",
        "```text",
        "Gamma_res^phase = 1                                  if A_route >= A_WRITE_MIDPOINT",
        "Gamma_res^phase = clamp(X_resolution * W_A + Q_A*(1-W_A), 0, 1) otherwise",
        "W_A = write_accessibility(A_route)",
        "Q_A = qg_competition(A_route)",
        "```",
        "",
        "## Main Read",
        "",
        "Phase does not collapse because a person looks. A route resolves when an",
        "A-resolution channel is available and the accumulated route has enough",
        "native write accessibility. Below `A_SIDE`, the selector has no write",
        "access. At `A_SHARE`, resolution can write. At the WRITE midpoint, the",
        "ledger is classical regardless of the scenario.",
        "",
        "## Counts",
        "",
        "```text",
        f"selector rows = {summary['selector_rows']}",
        f"phase-only rows = {blocked}",
        f"selected phase-write rows = {selected}",
        f"forced classical rows = {forced}",
        f"free parameters introduced = {summary['free_parameters_introduced']}",
        "```",
        "",
        "## Next Frontier",
        "",
        "`QP003_PRIVATE_INTERFERENCE_AND_BOUNCE_PHASE_COUPLING`",
        "",
        "QP003 should use `Gamma_res^phase` to model two unresolved route packets",
        "meeting: interference below write access, bounce/response near write access,",
        "and committed ledger structure after resolution.",
        "",
        f"Generated at UTC: `{summary['generated_at_utc']}`",
        "",
    ]
    return "\n".join(lines)


def main() -> None:
    qp001 = json.loads(QP001_SUMMARY.read_text(encoding="utf-8-sig"))
    samples = read_csv(QP001_SAMPLES)
    qubits = read_csv(QP001_QUBITS)
    scenarios = resolution_scenarios()
    thresholds = {
        "write_onset_threshold": fnum(qp001["write_onset_threshold"]),
        "write_access_threshold": fnum(qp001["write_access_threshold"]),
        "qg_boundary_start": fnum(qp001["qg_boundary_start"]),
        "write_midpoint": fnum(qp001["write_midpoint"]),
    }
    selector_rows = build_selector_rows(samples, scenarios, thresholds)
    status_counts: dict[str, int] = {}
    for row in selector_rows:
        status_counts[row["selector_status"]] = status_counts.get(row["selector_status"], 0) + 1

    selected_rows = status_counts.get("GAMMA_RES_PHASE_WRITE_SELECTED", 0)
    forced_rows = status_counts.get("CLASSICAL_LEDGER_COMMITTED", 0)
    phase_only_rows = status_counts.get("PHASE_ONLY_NO_WRITE_ACCESS", 0)
    no_resolution_selected = [
        row
        for row in selector_rows
        if row["scenario"] == "FREE_UNRESOLVED_ROUTE"
        and row["selector_status"] == "GAMMA_RES_PHASE_WRITE_SELECTED"
    ]
    below_side_selected = [
        row
        for row in selector_rows
        if fnum(row["A_route"]) < thresholds["write_onset_threshold"]
        and row["Gamma_res_phase"] > 0
    ]

    summary = {
        "artifact": "QP002_PRIVATE_GAMMA_RES_PHASE_WRITE_SELECTOR",
        "result_class": "QP002_PRIVATE_GAMMA_RES_PHASE_WRITE_SELECTOR_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_D_DRIVE_QUANTUM_PHASE_ONLY",
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "qubit_rows": len(qubits),
        "sample_rows": len(samples),
        "scenario_rows": len(scenarios),
        "selector_rows": len(selector_rows),
        "selector_status_counts": status_counts,
        "phase_only_rows": phase_only_rows,
        "selected_write_rows": selected_rows,
        "forced_classical_rows": forced_rows,
        "no_resolution_selected_rows": len(no_resolution_selected),
        "below_A_SIDE_selected_rows": len(below_side_selected),
        "Gamma_res_phase_formula": "clamp(X_resolution*W_A + Q_A*(1-W_A),0,1), forced to 1 at A_route >= A_WRITE_MIDPOINT",
        "next_frontier": "QP003_PRIVATE_INTERFERENCE_AND_BOUNCE_PHASE_COUPLING",
    }
    next_rows = [
        {
            "frontier": summary["next_frontier"],
            "why_next": (
                "QP002 defines when an unresolved phase route becomes a Gamma_res "
                "write. QP003 should model what happens when two unresolved route "
                "packets meet before, during, and after write access."
            ),
            "input_surface": "qp002_gamma_res_phase_selector_table.csv",
            "target_output": "private interference/bounce phase coupling surface",
        }
    ]

    write_csv(
        SCENARIOS_OUT,
        scenarios,
        ["scenario", "X_resolution", "X_environment", "X_contact", "meaning"],
    )
    write_csv(
        SELECTOR_OUT,
        selector_rows,
        [
            "selector_id",
            "qubit_id",
            "sample_id",
            "scenario",
            "A_route",
            "state_class",
            "X_resolution",
            "write_accessibility",
            "phase_coherence",
            "qg_competition",
            "Gamma_res_phase",
            "selector_status",
            "ledger_read",
        ],
    )
    write_csv(NEXT_OUT, next_rows, ["frontier", "why_next", "input_surface", "target_output"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    DOC_OUT.write_text(render_doc(summary, selector_rows), encoding="utf-8")

    print(summary["result_class"])
    print(f"selector_rows={summary['selector_rows']}")
    print(f"selected_write_rows={summary['selected_write_rows']}")
    print(f"forced_classical_rows={summary['forced_classical_rows']}")
    print(f"no_resolution_selected_rows={summary['no_resolution_selected_rows']}")
    print(f"below_A_SIDE_selected_rows={summary['below_A_SIDE_selected_rows']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
