from __future__ import annotations

import csv
import json
import math
from datetime import datetime, timezone
from itertools import combinations_with_replacement
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
QP001_QUBITS = ROOT / "qp001_qubit_phase_functional_table.csv"
QP002_SELECTOR = ROOT / "qp002_gamma_res_phase_selector_table.csv"

SUMMARY_OUT = ROOT / "qp003_interference_bounce_summary.json"
COUPLING_OUT = ROOT / "qp003_interference_bounce_coupling_table.csv"
PAIR_RANK_OUT = ROOT / "qp003_pair_rank_table.csv"
NEXT_OUT = ROOT / "qp003_next_frontier.csv"
DOC_OUT = ROOT / "QP003_PRIVATE_INTERFERENCE_BOUNCE_PHASE_COUPLING.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fnum(value: Any) -> float:
    return float(str(value).strip())


def fmt(value: float) -> str:
    return f"{value:.12g}"


def contact_rows(rows: list[dict[str, str]]) -> dict[tuple[str, str], dict[str, str]]:
    return {
        (row["qubit_id"], row["sample_id"]): row
        for row in rows
        if row["scenario"] == "CONTACT_RESOLUTION"
    }


def coupling_status(gamma_i: float, gamma_j: float, interference: float, bounce: float) -> str:
    if gamma_i >= 1.0 and gamma_j >= 1.0:
        return "COMMITTED_LEDGER_INTERSECTION"
    if bounce > 0:
        return "BOUNCE_RESPONSE_WRITE_COUPLING"
    if interference > 0:
        return "UNRESOLVED_INTERFERENCE_COUPLING"
    return "NO_COUPLING"


def build_coupling_rows(qubits: list[dict[str, str]], selector_index: dict[tuple[str, str], dict[str, str]]) -> list[dict[str, Any]]:
    qubit_ids = [row["qubit_id"] for row in qubits]
    sample_ids = ["N0", "N_A_SIDE", "N_A_SHARE", "N_A_D_BLOCK", "N_A_ALPHA_H_SQ", "N_WRITE_MIDPOINT"]
    rows: list[dict[str, Any]] = []
    for left, right in combinations_with_replacement(qubit_ids, 2):
        for sample_id in sample_ids:
            li = selector_index[(left, sample_id)]
            rj = selector_index[(right, sample_id)]
            phase_i = fnum(li["phase_coherence"])
            phase_j = fnum(rj["phase_coherence"])
            gamma_i = fnum(li["Gamma_res_phase"])
            gamma_j = fnum(rj["Gamma_res_phase"])
            write_i = fnum(li["write_accessibility"])
            write_j = fnum(rj["write_accessibility"])
            interference = phase_i * phase_j * (1.0 - max(gamma_i, gamma_j))
            bounce = math.sqrt(gamma_i * gamma_j) * math.sqrt(write_i * write_j)
            ledger_intersection = min(gamma_i, gamma_j)
            support_strength = interference + bounce + ledger_intersection
            rows.append(
                {
                    "coupling_id": f"QP003_COUP_{len(rows) + 1:04d}",
                    "route_i": left,
                    "route_j": right,
                    "sample_id": sample_id,
                    "A_route_i": li["A_route"],
                    "A_route_j": rj["A_route"],
                    "state_i": li["state_class"],
                    "state_j": rj["state_class"],
                    "Gamma_i": gamma_i,
                    "Gamma_j": gamma_j,
                    "phase_i": phase_i,
                    "phase_j": phase_j,
                    "interference_strength": interference,
                    "bounce_response_strength": bounce,
                    "ledger_intersection_strength": ledger_intersection,
                    "total_support_strength": support_strength,
                    "coupling_status": coupling_status(gamma_i, gamma_j, interference, bounce),
                }
            )
    return rows


def build_pair_rank_rows(coupling_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    pair_map: dict[tuple[str, str], dict[str, float]] = {}
    for row in coupling_rows:
        key = (row["route_i"], row["route_j"])
        current = pair_map.setdefault(
            key,
            {
                "max_interference_strength": 0.0,
                "max_bounce_response_strength": 0.0,
                "max_ledger_intersection_strength": 0.0,
                "max_total_support_strength": 0.0,
            },
        )
        current["max_interference_strength"] = max(
            current["max_interference_strength"], fnum(row["interference_strength"])
        )
        current["max_bounce_response_strength"] = max(
            current["max_bounce_response_strength"], fnum(row["bounce_response_strength"])
        )
        current["max_ledger_intersection_strength"] = max(
            current["max_ledger_intersection_strength"], fnum(row["ledger_intersection_strength"])
        )
        current["max_total_support_strength"] = max(
            current["max_total_support_strength"], fnum(row["total_support_strength"])
        )
    out = []
    for (left, right), values in pair_map.items():
        if values["max_bounce_response_strength"] > 0:
            top_mode = "BOUNCE_RESPONSE_AVAILABLE"
        elif values["max_interference_strength"] > 0:
            top_mode = "INTERFERENCE_ONLY"
        else:
            top_mode = "NO_PRIVATE_COUPLING"
        out.append(
            {
                "route_pair": f"{left}<->{right}",
                **values,
                "top_mode": top_mode,
            }
        )
    out.sort(
        key=lambda row: (
            -fnum(row["max_bounce_response_strength"]),
            -fnum(row["max_interference_strength"]),
            row["route_pair"],
        )
    )
    for index, row in enumerate(out, start=1):
        row["rank"] = index
    return out


def render_doc(summary: dict[str, Any], pair_rows: list[dict[str, Any]]) -> str:
    top = pair_rows[:6]
    lines = [
        "# QP003 - Private Interference / Bounce Phase Coupling",
        "",
        "Location: `D:\\quantum_phase`",
        "",
        "## Verdict",
        "",
        "`QP003_PRIVATE_INTERFERENCE_BOUNCE_PHASE_COUPLING_BUILT`",
        "",
        "QP003 applies the private `Gamma_res^phase` selector to two-route meetings.",
        "",
        "```text",
        "interference = phase_i * phase_j * (1 - max(Gamma_i, Gamma_j))",
        "bounce      = sqrt(Gamma_i * Gamma_j) * sqrt(W_i * W_j)",
        "ledger      = min(Gamma_i, Gamma_j)",
        "support     = interference + bounce + ledger",
        "```",
        "",
        "## Main Read",
        "",
        "Below write access, route packets couple as unresolved interference. Once",
        "A-resolution selects write access, the same meeting becomes bounce/response.",
        "At the WRITE midpoint, the coupling is no longer phase-like; it is ledger",
        "intersection.",
        "",
        "## Counts",
        "",
        "```text",
        f"coupling rows = {summary['coupling_rows']}",
        f"route pairs = {summary['route_pairs']}",
        f"unresolved interference rows = {summary['status_counts'].get('UNRESOLVED_INTERFERENCE_COUPLING', 0)}",
        f"bounce response rows = {summary['status_counts'].get('BOUNCE_RESPONSE_WRITE_COUPLING', 0)}",
        f"committed ledger rows = {summary['status_counts'].get('COMMITTED_LEDGER_INTERSECTION', 0)}",
        "```",
        "",
        "## Top Coupling Pairs",
        "",
        "| Rank | Pair | Max bounce | Max interference | Top mode |",
        "| ---: | --- | ---: | ---: | --- |",
    ]
    for row in top:
        lines.append(
            "| {rank} | {pair} | {bounce} | {interference} | {mode} |".format(
                rank=row["rank"],
                pair=row["route_pair"],
                bounce=fmt(fnum(row["max_bounce_response_strength"])),
                interference=fmt(fnum(row["max_interference_strength"])),
                mode=row["top_mode"],
            )
        )
    lines.extend(
        [
            "",
            "## Next Frontier",
            "",
            "`QP004_PRIVATE_PHASE_TO_PARTICLE_ROLE_OPERATOR_BRIDGE`",
            "",
            "QP004 should test whether the phase/bounce coupling classes align with",
            "SUK055 heavy composite role-operator targets without copying private",
            "data back into the public repo.",
            "",
            f"Generated at UTC: `{summary['generated_at_utc']}`",
            "",
        ]
    )
    return "\n".join(lines)


def main() -> None:
    qubits = read_csv(QP001_QUBITS)
    selector_rows = read_csv(QP002_SELECTOR)
    selector_index = contact_rows(selector_rows)
    coupling_rows = build_coupling_rows(qubits, selector_index)
    pair_rows = build_pair_rank_rows(coupling_rows)
    status_counts: dict[str, int] = {}
    for row in coupling_rows:
        status_counts[row["coupling_status"]] = status_counts.get(row["coupling_status"], 0) + 1

    summary = {
        "artifact": "QP003_PRIVATE_INTERFERENCE_BOUNCE_PHASE_COUPLING",
        "result_class": "QP003_PRIVATE_INTERFERENCE_BOUNCE_PHASE_COUPLING_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_D_DRIVE_QUANTUM_PHASE_ONLY",
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "qubit_rows": len(qubits),
        "coupling_rows": len(coupling_rows),
        "route_pairs": len(pair_rows),
        "status_counts": status_counts,
        "top_bounce_pair": pair_rows[0]["route_pair"],
        "top_bounce_strength": pair_rows[0]["max_bounce_response_strength"],
        "next_frontier": "QP004_PRIVATE_PHASE_TO_PARTICLE_ROLE_OPERATOR_BRIDGE",
    }
    next_rows = [
        {
            "frontier": summary["next_frontier"],
            "why_next": (
                "QP003 defines private interference/bounce/ledger-intersection "
                "coupling classes. QP004 should compare those classes to the "
                "SUK055 heavy composite role-operator targets without moving "
                "private quantum-phase artifacts into the public repo."
            ),
            "input_surface": "qp003_pair_rank_table.csv",
            "target_output": "private phase-to-particle role-operator bridge",
        }
    ]

    write_csv(
        COUPLING_OUT,
        coupling_rows,
        [
            "coupling_id",
            "route_i",
            "route_j",
            "sample_id",
            "A_route_i",
            "A_route_j",
            "state_i",
            "state_j",
            "Gamma_i",
            "Gamma_j",
            "phase_i",
            "phase_j",
            "interference_strength",
            "bounce_response_strength",
            "ledger_intersection_strength",
            "total_support_strength",
            "coupling_status",
        ],
    )
    write_csv(
        PAIR_RANK_OUT,
        pair_rows,
        [
            "rank",
            "route_pair",
            "max_interference_strength",
            "max_bounce_response_strength",
            "max_ledger_intersection_strength",
            "max_total_support_strength",
            "top_mode",
        ],
    )
    write_csv(NEXT_OUT, next_rows, ["frontier", "why_next", "input_surface", "target_output"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    DOC_OUT.write_text(render_doc(summary, pair_rows), encoding="utf-8")

    print(summary["result_class"])
    print(f"coupling_rows={summary['coupling_rows']}")
    print(f"route_pairs={summary['route_pairs']}")
    print(f"status_counts={summary['status_counts']}")
    print(f"top_bounce_pair={summary['top_bounce_pair']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
