from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
PUBLIC_ROOT = Path(r"C:\VS\Stam_model-A-v1.0")
SUK055_FRONTIER = PUBLIC_ROOT / "tests" / "Campaigns" / "SAM_UNIFICATION_KERNEL_GATE" / "SUK055_operator_readout_frontier.csv"
QP003_COUPLING = ROOT / "qp003_interference_bounce_coupling_table.csv"
QP001_QUBITS = ROOT / "qp001_qubit_phase_functional_table.csv"

SUMMARY_OUT = ROOT / "qp004_phase_to_particle_role_operator_summary.json"
BRIDGE_OUT = ROOT / "qp004_phase_to_particle_role_operator_bridge.csv"
ROLE_RULES_OUT = ROOT / "qp004_phase_role_operator_rules.csv"
NEXT_OUT = ROOT / "qp004_next_frontier.csv"
DOC_OUT = ROOT / "QP004_PRIVATE_PHASE_TO_PARTICLE_ROLE_OPERATOR_BRIDGE.md"


ROLE_RULES = {
    "CHARGED_HEAVY_MESON_ROLE_OPERATOR_TARGET": {
        "required_phase_pairs": [
            ("QUBIT-CL-001", "QUBIT-TM-001"),
            ("QUBIT-CL-001", "QUBIT-TP-001"),
        ],
        "role_operator": "DUAL_POLARITY_CHARGED_HEAVY_ROLE_OPERATOR",
        "why": "charged oriented slots require both minus and plus triadic polarity bounce lanes",
    },
    "NEUTRAL_HEAVY_MESON_MIXING_ROLE_OPERATOR_TARGET": {
        "required_phase_pairs": [
            ("QUBIT-CL-001", "QUBIT-BN-001"),
            ("QUBIT-CL-001", "QUBIT-NL-001"),
        ],
        "role_operator": "NEUTRAL_BINARY_MIXING_ROLE_OPERATOR",
        "why": "neutral mixing requires binary neutral return plus neutral identity write contact",
    },
    "TRANSITION_COUPLED_HEAVY_MESON_ROLE_OPERATOR_TARGET": {
        "required_phase_pairs": [
            ("QUBIT-CL-001", "QUBIT-UNK-001"),
            ("QUBIT-CL-001", "QUBIT-COLOR-001"),
        ],
        "role_operator": "TRANSITION_COLOR_COUPLED_ROLE_OPERATOR",
        "why": "transition-coupled targets require the 8+4 transition route and owner-triad color contact",
    },
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def pair_key(left: str, right: str) -> str:
    return "<->".join(sorted([left, right]))


def build_bounce_pairs(couplings: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    pairs: dict[str, dict[str, str]] = {}
    for row in couplings:
        if row["coupling_status"] != "BOUNCE_RESPONSE_WRITE_COUPLING":
            continue
        pairs[pair_key(row["route_i"], row["route_j"])] = row
    return pairs


def route_labels(qubits: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    return {row["qubit_id"]: row for row in qubits}


def score_role(rule: dict[str, Any], bounce_pairs: dict[str, dict[str, str]]) -> tuple[int, int, list[str], list[str], float]:
    required = rule["required_phase_pairs"]
    available: list[str] = []
    missing: list[str] = []
    strengths: list[float] = []
    for left, right in required:
        key = pair_key(left, right)
        if key in bounce_pairs:
            available.append(key)
            strengths.append(float(bounce_pairs[key]["bounce_response_strength"]))
        else:
            missing.append(key)
    score = len(available)
    total = len(required)
    min_strength = min(strengths) if strengths else 0.0
    return score, total, available, missing, min_strength


def result_status(score: int, total: int) -> str:
    if score == total:
        return "PHASE_ROLE_OPERATOR_AVAILABLE"
    if score:
        return "PARTIAL_PHASE_ROLE_OPERATOR_AVAILABLE"
    return "NO_PHASE_ROLE_OPERATOR_AVAILABLE"


def main() -> None:
    for path in [SUK055_FRONTIER, QP003_COUPLING, QP001_QUBITS]:
        if not path.exists():
            raise FileNotFoundError(path)

    frontier = read_csv(SUK055_FRONTIER)
    couplings = read_csv(QP003_COUPLING)
    qubits = read_csv(QP001_QUBITS)

    bounce_pairs = build_bounce_pairs(couplings)
    labels = route_labels(qubits)
    bridge_rows: list[dict[str, Any]] = []

    for row in frontier:
        target_route = row["target_route"]
        rule = ROLE_RULES[target_route]
        score, total, available, missing, min_strength = score_role(rule, bounce_pairs)
        bridge_rows.append(
            {
                "frontier_id": row["frontier_id"],
                "suk055_pair": row["pair"],
                "suk055_target_route": target_route,
                "charge_classes": row["charge_classes"],
                "constituent_sum_MeV": row["constituent_sum_MeV"],
                "mass_coordinate_grade": row["mass_coordinate_grade"],
                "phase_role_operator": rule["role_operator"],
                "phase_role_operator_status": result_status(score, total),
                "required_phase_pairs": ";".join(pair_key(left, right) for left, right in rule["required_phase_pairs"]),
                "available_bounce_pairs": ";".join(available),
                "missing_bounce_pairs": ";".join(missing),
                "role_support_score": score,
                "role_support_total": total,
                "min_available_bounce_strength": f"{min_strength:.12g}",
                "role_rule_basis": rule["why"],
            }
        )

    role_rule_rows: list[dict[str, Any]] = []
    for target_route, rule in ROLE_RULES.items():
        phase_pair_labels = []
        for left, right in rule["required_phase_pairs"]:
            left_label = labels[left]["qubit_native_route"]
            right_label = labels[right]["qubit_native_route"]
            phase_pair_labels.append(f"{left_label}<->{right_label}")
        score, total, available, missing, min_strength = score_role(rule, bounce_pairs)
        role_rule_rows.append(
            {
                "suk055_target_route": target_route,
                "phase_role_operator": rule["role_operator"],
                "required_phase_pairs": ";".join(pair_key(left, right) for left, right in rule["required_phase_pairs"]),
                "required_phase_pair_labels": ";".join(phase_pair_labels),
                "available_bounce_pairs": ";".join(available),
                "missing_bounce_pairs": ";".join(missing),
                "rule_status": result_status(score, total),
                "min_available_bounce_strength": f"{min_strength:.12g}",
                "rule_basis": rule["why"],
            }
        )

    status_counts: dict[str, int] = {}
    role_counts: dict[str, int] = {}
    for row in bridge_rows:
        status_counts[row["phase_role_operator_status"]] = status_counts.get(row["phase_role_operator_status"], 0) + 1
        role_counts[row["phase_role_operator"]] = role_counts.get(row["phase_role_operator"], 0) + 1

    all_targets_have_operator = all(row["phase_role_operator_status"] == "PHASE_ROLE_OPERATOR_AVAILABLE" for row in bridge_rows)
    summary = {
        "artifact": "QP004_PRIVATE_PHASE_TO_PARTICLE_ROLE_OPERATOR_BRIDGE",
        "result_class": "QP004_PRIVATE_PHASE_ROLE_OPERATOR_BRIDGE_BUILT"
        if all_targets_have_operator
        else "QP004_PRIVATE_PHASE_ROLE_OPERATOR_BRIDGE_PARTIAL",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_D_DRIVE_READS_PUBLIC_SUK055_OUTPUT_ONLY",
        "writes_public_repo": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "suk055_frontier_rows": len(frontier),
        "qp003_bounce_pairs_used": len(bounce_pairs),
        "phase_role_rules": len(ROLE_RULES),
        "status_counts": status_counts,
        "role_operator_counts": role_counts,
        "all_suk055_targets_have_private_phase_role_operator": all_targets_have_operator,
        "next_frontier": "QP005_PRIVATE_NATIVE_COMPOSITE_INTERACTION_STRENGTH_LAW",
    }

    write_csv(
        BRIDGE_OUT,
        bridge_rows,
        [
            "frontier_id",
            "suk055_pair",
            "suk055_target_route",
            "charge_classes",
            "constituent_sum_MeV",
            "mass_coordinate_grade",
            "phase_role_operator",
            "phase_role_operator_status",
            "required_phase_pairs",
            "available_bounce_pairs",
            "missing_bounce_pairs",
            "role_support_score",
            "role_support_total",
            "min_available_bounce_strength",
            "role_rule_basis",
        ],
    )
    write_csv(
        ROLE_RULES_OUT,
        role_rule_rows,
        [
            "suk055_target_route",
            "phase_role_operator",
            "required_phase_pairs",
            "required_phase_pair_labels",
            "available_bounce_pairs",
            "missing_bounce_pairs",
            "rule_status",
            "min_available_bounce_strength",
            "rule_basis",
        ],
    )
    write_csv(
        NEXT_OUT,
        [
            {
                "frontier": "QP005_PRIVATE_NATIVE_COMPOSITE_INTERACTION_STRENGTH_LAW",
                "why_next": "QP004 connects SUK055 heavy composite role classes to private phase-bounce operator classes. QP005 should turn role availability into a native strength law using only bounce strength, ledger intersection, charge class, and constituent mass coordinates already present in SUK055.",
                "input_surface": "qp004_phase_to_particle_role_operator_bridge.csv",
                "target_output": "private composite interaction strength law",
            }
        ],
        ["frontier", "why_next", "input_surface", "target_output"],
    )
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    top_lines = "\n".join(
        f"| {row['suk055_pair']} | {row['phase_role_operator']} | {row['phase_role_operator_status']} | {row['available_bounce_pairs']} |"
        for row in bridge_rows
    )
    DOC_OUT.write_text(
        f"""# QP004 - Private Phase To Particle Role Operator Bridge

Location: `D:\\quantum_phase`

## Verdict

`{summary['result_class']}`

QP004 reads the public SUK055 heavy-composite frontier from the private side and
matches each SUK055 target route to SAM-native private phase/bounce operators.
It does not write to the public repo.

## Main Read

The universal A_SHARE bounce anchor is `QUBIT-CL-001`. It couples at 1/12 to:

- neutral identity / binary return lanes
- both triadic polarity lanes
- the 8+4 transition lane
- the owner-triad color lane

That supplies native role-operator support for all 12 SUK055 heavy-composite
targets.

## Role Rules

| SUK055 target | Private phase role operator | Status |
| --- | --- | --- |
"""
        + "\n".join(
            f"| {row['suk055_target_route']} | {row['phase_role_operator']} | {row['rule_status']} |"
            for row in role_rule_rows
        )
        + f"""

## SUK055 Bridge Rows

| SUK055 pair | Phase role operator | Status | Available bounce pairs |
| --- | --- | --- | --- |
{top_lines}

## Counts

```text
SUK055 frontier rows = {summary['suk055_frontier_rows']}
QP003 bounce pairs used = {summary['qp003_bounce_pairs_used']}
phase role rules = {summary['phase_role_rules']}
status counts = {summary['status_counts']}
```

## Next Frontier

`{summary['next_frontier']}`

QP005 should turn role availability into a native composite interaction-strength
law using only private bounce strength, ledger intersection, charge class, and
the constituent mass coordinates already present in SUK055.

Generated at UTC: `{summary['generated_at_utc']}`
""",
        encoding="utf-8",
    )

    print(summary["result_class"])
    print(f"suk055_frontier_rows={summary['suk055_frontier_rows']}")
    print(f"qp003_bounce_pairs_used={summary['qp003_bounce_pairs_used']}")
    print(f"status_counts={summary['status_counts']}")
    print(f"all_targets_have_operator={summary['all_suk055_targets_have_private_phase_role_operator']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
