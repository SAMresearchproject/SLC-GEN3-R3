from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
PUBLIC_ROOT = Path(r"C:\VS\Stam_model-A-v1.0")
SUK055_SLOTS = PUBLIC_ROOT / "tests" / "Campaigns" / "SAM_UNIFICATION_KERNEL_GATE" / "SUK055_oriented_slot_mass_coordinate_table.csv"
QP004_BRIDGE = ROOT / "qp004_phase_to_particle_role_operator_bridge.csv"

SUMMARY_OUT = ROOT / "qp005_native_composite_interaction_strength_summary.json"
STRENGTH_OUT = ROOT / "qp005_native_composite_interaction_strength_table.csv"
NEXT_OUT = ROOT / "qp005_next_frontier.csv"
DOC_OUT = ROOT / "QP005_PRIVATE_NATIVE_COMPOSITE_INTERACTION_STRENGTH_LAW.md"

A_SHARE = 1.0 / 12.0
WRITE_MIDPOINT = 1.0 / 2.0


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fnum(value: Any) -> float:
    return float(str(value).strip())


def fmt(value: float) -> str:
    return f"{value:.12g}"


def first_slot_by_pair(rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    slots: dict[str, dict[str, str]] = {}
    for row in rows:
        slots.setdefault(row["candidate_pair"], row)
    return slots


def closure_class(native_strength: float) -> str:
    if native_strength >= WRITE_MIDPOINT:
        return "WRITE_MIDPOINT_BALANCED_CLOSURE"
    if native_strength >= A_SHARE:
        return "A_SHARE_SCALE_ASYMMETRIC_CLOSURE"
    return "SUB_A_SHARE_ASYMMETRIC_CLOSURE"


def main() -> None:
    for path in [SUK055_SLOTS, QP004_BRIDGE]:
        if not path.exists():
            raise FileNotFoundError(path)

    slots = first_slot_by_pair(read_csv(SUK055_SLOTS))
    bridge_rows = read_csv(QP004_BRIDGE)

    rows: list[dict[str, Any]] = []
    for bridge in bridge_rows:
        pair = bridge["suk055_pair"]
        slot = slots[pair]
        m_a = fnum(slot["constituent_a_mass_MeV"])
        m_b = fnum(slot["constituent_b_mass_MeV"])
        total = m_a + m_b
        mass_asymmetry = abs(m_a - m_b) / total
        mass_balance = 4.0 * m_a * m_b / (total * total)
        phase_role_strength = (
            fnum(bridge["role_support_score"])
            / fnum(bridge["role_support_total"])
            * fnum(bridge["min_available_bounce_strength"])
        )
        native_strength = phase_role_strength * mass_balance
        interaction_mass_coordinate = total * native_strength
        asymmetry_mass_coordinate = total * mass_asymmetry
        identity_residual = mass_balance + mass_asymmetry * mass_asymmetry - 1.0
        rows.append(
            {
                "suk055_pair": pair,
                "particle_a": slot["particle"],
                "particle_b": slot["antiparticle_base"],
                "charge_class": bridge["charge_classes"],
                "phase_role_operator": bridge["phase_role_operator"],
                "constituent_a_mass_MeV": fmt(m_a),
                "constituent_b_mass_MeV": fmt(m_b),
                "constituent_sum_MeV": fmt(total),
                "mass_asymmetry": fmt(mass_asymmetry),
                "symmetric_pair_balance": fmt(mass_balance),
                "phase_role_strength": fmt(phase_role_strength),
                "native_interaction_strength": fmt(native_strength),
                "interaction_mass_coordinate_MeV": fmt(interaction_mass_coordinate),
                "asymmetry_mass_coordinate_MeV": fmt(asymmetry_mass_coordinate),
                "native_closure_class": closure_class(native_strength),
                "balance_identity_residual": fmt(identity_residual),
                "available_bounce_pairs": bridge["available_bounce_pairs"],
                "mass_coordinate_grade": bridge["mass_coordinate_grade"],
            }
        )

    rows.sort(key=lambda row: fnum(row["native_interaction_strength"]), reverse=True)
    for index, row in enumerate(rows, start=1):
        row["strength_rank"] = index

    class_counts: dict[str, int] = {}
    role_counts: dict[str, int] = {}
    strongest = rows[0]
    weakest = rows[-1]
    for row in rows:
        class_counts[row["native_closure_class"]] = class_counts.get(row["native_closure_class"], 0) + 1
        role_counts[row["phase_role_operator"]] = role_counts.get(row["phase_role_operator"], 0) + 1

    summary = {
        "artifact": "QP005_PRIVATE_NATIVE_COMPOSITE_INTERACTION_STRENGTH_LAW",
        "result_class": "QP005_PRIVATE_NATIVE_COMPOSITE_INTERACTION_STRENGTH_LAW_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_D_DRIVE_READS_PUBLIC_SUK055_SLOT_COORDINATES_ONLY",
        "writes_public_repo": False,
        "uses_observed_composite_masses": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "law": "native_interaction_strength = phase_role_strength * 4*m_a*m_b/(m_a+m_b)^2",
        "native_thresholds_used": {"A_SHARE": A_SHARE, "WRITE_MIDPOINT": WRITE_MIDPOINT},
        "rows": len(rows),
        "closure_class_counts": class_counts,
        "role_operator_counts": role_counts,
        "strongest_pair": strongest["suk055_pair"],
        "strongest_native_interaction_strength": strongest["native_interaction_strength"],
        "strongest_interaction_mass_coordinate_MeV": strongest["interaction_mass_coordinate_MeV"],
        "weakest_pair": weakest["suk055_pair"],
        "weakest_native_interaction_strength": weakest["native_interaction_strength"],
        "max_balance_identity_abs_residual": max(abs(fnum(row["balance_identity_residual"])) for row in rows),
        "next_frontier": "QP006_PRIVATE_HEAVY_COMPOSITE_SLOT_PRIORITY_TABLE",
    }

    write_csv(
        STRENGTH_OUT,
        rows,
        [
            "strength_rank",
            "suk055_pair",
            "particle_a",
            "particle_b",
            "charge_class",
            "phase_role_operator",
            "constituent_a_mass_MeV",
            "constituent_b_mass_MeV",
            "constituent_sum_MeV",
            "mass_asymmetry",
            "symmetric_pair_balance",
            "phase_role_strength",
            "native_interaction_strength",
            "interaction_mass_coordinate_MeV",
            "asymmetry_mass_coordinate_MeV",
            "native_closure_class",
            "balance_identity_residual",
            "available_bounce_pairs",
            "mass_coordinate_grade",
        ],
    )
    write_csv(
        NEXT_OUT,
        [
            {
                "frontier": "QP006_PRIVATE_HEAVY_COMPOSITE_SLOT_PRIORITY_TABLE",
                "why_next": "QP005 supplies a native strength law for SUK055 heavy-composite candidates. QP006 should use this to rank which blank particle-table slots are most natural SAM-native completions before any external observed-mass comparison.",
                "input_surface": "qp005_native_composite_interaction_strength_table.csv",
                "target_output": "private heavy composite slot priority table",
            }
        ],
        ["frontier", "why_next", "input_surface", "target_output"],
    )
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    table_lines = "\n".join(
        f"| {row['strength_rank']} | {row['suk055_pair']} | {row['phase_role_operator']} | {row['native_interaction_strength']} | {row['native_closure_class']} |"
        for row in rows
    )
    DOC_OUT.write_text(
        f"""# QP005 - Private Native Composite Interaction Strength Law

Location: `D:\\quantum_phase`

## Verdict

`{summary['result_class']}`

QP005 turns the QP004 role-operator bridge into a dimensionless native
interaction-strength coordinate.

```text
native_interaction_strength = phase_role_strength * 4*m_a*m_b/(m_a+m_b)^2
```

The pair-balance term is the no-parameter symmetric closure coordinate. It is
equal to `1 - mass_asymmetry^2`, so it measures how well two transported
response packets can close together rather than how heavy the pair is.

## Main Read

The strongest private heavy-composite closure in the SUK055 target set is
`{summary['strongest_pair']}` with native strength
`{summary['strongest_native_interaction_strength']}`.

## Ranked Strength Table

| Rank | Pair | Phase role operator | Native strength | Closure class |
| ---: | --- | --- | ---: | --- |
{table_lines}

## Counts

```text
rows = {summary['rows']}
closure class counts = {summary['closure_class_counts']}
role operator counts = {summary['role_operator_counts']}
max balance identity abs residual = {summary['max_balance_identity_abs_residual']}
```

## Next Frontier

`{summary['next_frontier']}`

QP006 should turn this into a private blank-slot priority table before any
external observed-mass comparison.

Generated at UTC: `{summary['generated_at_utc']}`
""",
        encoding="utf-8",
    )

    print(summary["result_class"])
    print(f"rows={summary['rows']}")
    print(f"closure_class_counts={summary['closure_class_counts']}")
    print(f"strongest_pair={summary['strongest_pair']}")
    print(f"strongest_native_interaction_strength={summary['strongest_native_interaction_strength']}")
    print(f"weakest_pair={summary['weakest_pair']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
