from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
PUBLIC_ROOT = Path(r"C:\VS\Stam_model-A-v1.0")
SUK055_SLOTS = PUBLIC_ROOT / "tests" / "Campaigns" / "SAM_UNIFICATION_KERNEL_GATE" / "SUK055_oriented_slot_mass_coordinate_table.csv"
QGA075_DEPTH = PUBLIC_ROOT / "tests" / "native_prediction_artifacts" / "qga075_slot_completion_matrix.csv"
QP005_STRENGTH = ROOT / "qp005_native_composite_interaction_strength_table.csv"

SUMMARY_OUT = ROOT / "qp006_heavy_composite_slot_priority_summary.json"
PRIORITY_OUT = ROOT / "qp006_heavy_composite_slot_priority_table.csv"
NEXT_OUT = ROOT / "qp006_next_frontier.csv"
DOC_OUT = ROOT / "QP006_PRIVATE_HEAVY_COMPOSITE_SLOT_PRIORITY_TABLE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def slot_index(rows: list[dict[str, str]]) -> dict[str, list[dict[str, str]]]:
    by_pair: dict[str, list[dict[str, str]]] = {}
    for row in rows:
        by_pair.setdefault(row["candidate_pair"], []).append(row)
    return by_pair


def priority_class(closure_class: str) -> tuple[str, str]:
    if closure_class == "WRITE_MIDPOINT_BALANCED_CLOSURE":
        return (
            "P1_ROLE_LOCK_FIRST",
            "balanced write-midpoint closure; first private heavy-composite role-lock candidate",
        )
    if closure_class == "A_SHARE_SCALE_ASYMMETRIC_CLOSURE":
        return (
            "P2_A_SHARE_ROLE_CANDIDATE",
            "clears A-share-scale closure; candidate for next role-operator completion",
        )
    return (
        "P3_SCAFFOLD_HELD_OPEN",
        "constituent scaffold exists but private native strength remains below A-share scale",
    )


def main() -> None:
    for path in [SUK055_SLOTS, QGA075_DEPTH, QP005_STRENGTH]:
        if not path.exists():
            raise FileNotFoundError(path)

    slots_by_pair = slot_index(read_csv(SUK055_SLOTS))
    qga075_depth_rows = read_csv(QGA075_DEPTH)
    strength_rows = read_csv(QP005_STRENGTH)
    d2_depth = next(row for row in qga075_depth_rows if row["depth_id"] == "D2")

    rows: list[dict[str, Any]] = []
    for row in strength_rows:
        pclass, why = priority_class(row["native_closure_class"])
        slots = slots_by_pair[row["suk055_pair"]]
        oriented_symbols = ";".join(slot["symbol"] for slot in slots)
        oriented_slot_ids = ";".join(slot["slot_id"] for slot in slots)
        slot_charges = ";".join(sorted({slot["slot_charge"] for slot in slots}))
        rows.append(
            {
                "priority_rank": row["strength_rank"],
                "priority_class": pclass,
                "suk055_pair": row["suk055_pair"],
                "oriented_slot_ids": oriented_slot_ids,
                "oriented_symbols": oriented_symbols,
                "slot_charges": slot_charges,
                "charge_class": row["charge_class"],
                "phase_role_operator": row["phase_role_operator"],
                "native_interaction_strength": row["native_interaction_strength"],
                "native_closure_class": row["native_closure_class"],
                "interaction_mass_coordinate_MeV": row["interaction_mass_coordinate_MeV"],
                "constituent_sum_MeV": row["constituent_sum_MeV"],
                "qga075_depth_id": d2_depth["depth_id"],
                "qga075_slot_class": d2_depth["slot_class"],
                "qga075_filled_depth": d2_depth["filled_depth"],
                "private_slot_action": why,
                "external_observed_mass_status": "NOT_USED",
            }
        )

    class_counts: dict[str, int] = {}
    for row in rows:
        class_counts[row["priority_class"]] = class_counts.get(row["priority_class"], 0) + 1

    summary = {
        "artifact": "QP006_PRIVATE_HEAVY_COMPOSITE_SLOT_PRIORITY_TABLE",
        "result_class": "QP006_PRIVATE_HEAVY_COMPOSITE_SLOT_PRIORITY_TABLE_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_D_DRIVE_READS_PUBLIC_SUK055_AND_QGA075_OUTPUTS_ONLY",
        "writes_public_repo": False,
        "uses_observed_composite_masses": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "priority_rows": len(rows),
        "priority_class_counts": class_counts,
        "top_priority_pair": rows[0]["suk055_pair"],
        "top_priority_oriented_symbols": rows[0]["oriented_symbols"],
        "top_priority_native_strength": rows[0]["native_interaction_strength"],
        "a_share_or_better_rows": sum(1 for row in rows if row["priority_class"] != "P3_SCAFFOLD_HELD_OPEN"),
        "next_frontier": "QP007_PRIVATE_ROLE_OPERATOR_MASS_CLOSURE_TRIAL",
    }

    write_csv(
        PRIORITY_OUT,
        rows,
        [
            "priority_rank",
            "priority_class",
            "suk055_pair",
            "oriented_slot_ids",
            "oriented_symbols",
            "slot_charges",
            "charge_class",
            "phase_role_operator",
            "native_interaction_strength",
            "native_closure_class",
            "interaction_mass_coordinate_MeV",
            "constituent_sum_MeV",
            "qga075_depth_id",
            "qga075_slot_class",
            "qga075_filled_depth",
            "private_slot_action",
            "external_observed_mass_status",
        ],
    )
    write_csv(
        NEXT_OUT,
        [
            {
                "frontier": "QP007_PRIVATE_ROLE_OPERATOR_MASS_CLOSURE_TRIAL",
                "why_next": "QP006 ranks heavy meson blank-slot priorities without external observed masses. QP007 should attempt a private mass-closure readout for the P1/P2 slots using only constituent sum, interaction mass coordinate, and SAM-native role class.",
                "input_surface": "qp006_heavy_composite_slot_priority_table.csv",
                "target_output": "private role-operator mass closure trial",
            }
        ],
        ["frontier", "why_next", "input_surface", "target_output"],
    )
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    table_lines = "\n".join(
        f"| {row['priority_rank']} | {row['suk055_pair']} | {row['oriented_symbols']} | {row['priority_class']} | {row['native_interaction_strength']} |"
        for row in rows
    )
    DOC_OUT.write_text(
        f"""# QP006 - Private Heavy Composite Slot Priority Table

Location: `D:\\quantum_phase`

## Verdict

`{summary['result_class']}`

QP006 turns the QP005 native strength law into a private priority table for
heavy q/anti-q scaffold slots. It reads the public SUK055 and QGA075 outputs
from the private side and does not use observed composite masses.

## Main Read

The first role-lock target is `{summary['top_priority_pair']}`
(`{summary['top_priority_oriented_symbols']}`), with native strength
`{summary['top_priority_native_strength']}`.

Rows at P1/P2 are the slots that clear A-share scale or better before any
external comparison.

## Priority Table

| Rank | Pair | Oriented symbols | Priority | Native strength |
| ---: | --- | --- | --- | ---: |
{table_lines}

## Counts

```text
priority rows = {summary['priority_rows']}
priority class counts = {summary['priority_class_counts']}
A-share or better rows = {summary['a_share_or_better_rows']}
```

## Next Frontier

`{summary['next_frontier']}`

QP007 should attempt a private mass-closure readout for the P1/P2 rows using
only constituent sum, interaction mass coordinate, and SAM-native role class.

Generated at UTC: `{summary['generated_at_utc']}`
""",
        encoding="utf-8",
    )

    print(summary["result_class"])
    print(f"priority_rows={summary['priority_rows']}")
    print(f"priority_class_counts={summary['priority_class_counts']}")
    print(f"top_priority_pair={summary['top_priority_pair']}")
    print(f"a_share_or_better_rows={summary['a_share_or_better_rows']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
