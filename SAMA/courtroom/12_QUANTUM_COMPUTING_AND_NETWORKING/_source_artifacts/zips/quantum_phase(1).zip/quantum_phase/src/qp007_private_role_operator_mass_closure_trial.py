from __future__ import annotations

import csv
import json
import math
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
PUBLIC_ROOT = Path(r"C:\VS\Stam_model-A-v1.0")
if str(PUBLIC_ROOT) not in sys.path:
    sys.path.insert(0, str(PUBLIC_ROOT))

from sam.constants import A0, A_HALF, A_SHARE, MEV_TO_KG, M_LAMBDA, N0, SLOT_DEN  # noqa: E402
from sam.mass import ROLE_OPERATORS, mass_mev_for_role  # noqa: E402


QP006_PRIORITY = ROOT / "qp006_heavy_composite_slot_priority_table.csv"

SUMMARY_OUT = ROOT / "qp007_role_operator_mass_closure_summary.json"
TRIAL_OUT = ROOT / "qp007_role_operator_mass_closure_trial_table.csv"
NEXT_OUT = ROOT / "qp007_next_frontier.csv"
DOC_OUT = ROOT / "QP007_PRIVATE_ROLE_OPERATOR_MASS_CLOSURE_TRIAL.md"

ROLE_SEEDS = {
    "DUAL_POLARITY_CHARGED_HEAVY_ROLE_OPERATOR": "charged_kaon_D_b_square",
    "NEUTRAL_BINARY_MIXING_ROLE_OPERATOR": "neutral_kaon_color_complement",
    "TRANSITION_COLOR_COUPLED_ROLE_OPERATOR": "charged_kaon_D_b_square",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fnum(value: Any) -> float:
    return float(str(value).strip())


def fmt(value: float) -> str:
    return f"{value:.12g}"


def required_shift_for_mass(role: str, mass_mev: float) -> float:
    op = ROLE_OPERATORS[role]
    r_bounce = A_HALF * op.q / SLOT_DEN
    numerator = A0 * A0 * op.k * M_LAMBDA
    denominator = mass_mev * MEV_TO_KG * (1.0 + r_bounce)
    return math.log2(numerator / denominator) - N0


def contact_class(delta: float) -> str:
    abs_delta = abs(delta)
    if abs_delta <= A_SHARE:
        return "INTEGER_SHIFT_A_SHARE_CONTACT"
    if abs_delta <= 0.5:
        return "INTEGER_SHIFT_HALF_WINDOW_CONTACT"
    return "INTEGER_SHIFT_OPEN"


def surface_rows(priority: dict[str, str]) -> list[tuple[str, float]]:
    constituent_sum = fnum(priority["constituent_sum_MeV"])
    interaction = fnum(priority["interaction_mass_coordinate_MeV"])
    complement = max(constituent_sum - interaction, 0.0)
    return [
        ("CONSTITUENT_SUM_SURFACE", constituent_sum),
        ("INTERACTION_COORDINATE_SURFACE", interaction),
        ("CLOSURE_COMPLEMENT_SURFACE", complement),
    ]


def main() -> None:
    if not QP006_PRIORITY.exists():
        raise FileNotFoundError(QP006_PRIORITY)

    priority_rows = [
        row
        for row in read_csv(QP006_PRIORITY)
        if row["priority_class"] in {"P1_ROLE_LOCK_FIRST", "P2_A_SHARE_ROLE_CANDIDATE"}
    ]

    trial_rows: list[dict[str, Any]] = []
    for priority in priority_rows:
        seed_role = ROLE_SEEDS[priority["phase_role_operator"]]
        seed_mass = mass_mev_for_role(seed_role)
        op = ROLE_OPERATORS[seed_role]
        for surface_name, surface_mass in surface_rows(priority):
            shift_eff = required_shift_for_mass(seed_role, surface_mass)
            nearest = round(shift_eff)
            delta = shift_eff - nearest
            trial_rows.append(
                {
                    "priority_rank": priority["priority_rank"],
                    "suk055_pair": priority["suk055_pair"],
                    "oriented_symbols": priority["oriented_symbols"],
                    "priority_class": priority["priority_class"],
                    "phase_role_operator": priority["phase_role_operator"],
                    "seed_role_operator": seed_role,
                    "seed_k": op.k,
                    "seed_shift": op.shift,
                    "seed_q": op.q,
                    "seed_mass_MeV": fmt(seed_mass),
                    "surface_name": surface_name,
                    "surface_mass_MeV": fmt(surface_mass),
                    "required_effective_shift": fmt(shift_eff),
                    "nearest_integer_shift": nearest,
                    "integer_shift_delta": fmt(delta),
                    "integer_shift_contact_class": contact_class(delta),
                    "observed_composite_mass_used": "false",
                }
            )

    trial_rows.sort(
        key=lambda row: (
            abs(fnum(row["integer_shift_delta"])),
            int(row["priority_rank"]),
            row["surface_name"],
        )
    )

    class_counts: dict[str, int] = {}
    surface_counts: dict[str, int] = {}
    for row in trial_rows:
        class_counts[row["integer_shift_contact_class"]] = class_counts.get(row["integer_shift_contact_class"], 0) + 1
        surface_counts[row["surface_name"]] = surface_counts.get(row["surface_name"], 0) + 1

    best = trial_rows[0]
    a_share_contacts = [
        row for row in trial_rows if row["integer_shift_contact_class"] == "INTEGER_SHIFT_A_SHARE_CONTACT"
    ]
    summary = {
        "artifact": "QP007_PRIVATE_ROLE_OPERATOR_MASS_CLOSURE_TRIAL",
        "result_class": "QP007_PRIVATE_ROLE_OPERATOR_MASS_CLOSURE_TRIAL_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_D_DRIVE_READS_QP006_AND_PUBLIC_SAM_ROLE_OPERATORS_ONLY",
        "writes_public_repo": False,
        "uses_observed_composite_masses": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "priority_rows_used": len(priority_rows),
        "trial_rows": len(trial_rows),
        "contact_class_counts": class_counts,
        "surface_counts": surface_counts,
        "best_pair": best["suk055_pair"],
        "best_surface": best["surface_name"],
        "best_seed_role_operator": best["seed_role_operator"],
        "best_required_effective_shift": best["required_effective_shift"],
        "best_integer_shift_delta": best["integer_shift_delta"],
        "a_share_integer_contacts": len(a_share_contacts),
        "a_share_contact_pairs": sorted({row["suk055_pair"] for row in a_share_contacts}),
        "next_frontier": "QP008_PRIVATE_HEAVY_ROLE_SHIFT_SELECTOR",
    }

    write_csv(
        TRIAL_OUT,
        trial_rows,
        [
            "priority_rank",
            "suk055_pair",
            "oriented_symbols",
            "priority_class",
            "phase_role_operator",
            "seed_role_operator",
            "seed_k",
            "seed_shift",
            "seed_q",
            "seed_mass_MeV",
            "surface_name",
            "surface_mass_MeV",
            "required_effective_shift",
            "nearest_integer_shift",
            "integer_shift_delta",
            "integer_shift_contact_class",
            "observed_composite_mass_used",
        ],
    )
    write_csv(
        NEXT_OUT,
        [
            {
                "frontier": "QP008_PRIVATE_HEAVY_ROLE_SHIFT_SELECTOR",
                "why_next": "QP007 converts P1/P2 heavy slots into required native role-operator shifts without observed masses. QP008 should select among the internal surfaces and integer shifts using only SAM-native route class, charge class, and A-share contact.",
                "input_surface": "qp007_role_operator_mass_closure_trial_table.csv",
                "target_output": "private heavy role shift selector",
            }
        ],
        ["frontier", "why_next", "input_surface", "target_output"],
    )
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    table_lines = "\n".join(
        f"| {row['suk055_pair']} | {row['surface_name']} | {row['seed_role_operator']} | {row['required_effective_shift']} | {row['integer_shift_delta']} | {row['integer_shift_contact_class']} |"
        for row in trial_rows
    )
    DOC_OUT.write_text(
        f"""# QP007 - Private Role Operator Mass Closure Trial

Location: `D:\\quantum_phase`

## Verdict

`{summary['result_class']}`

QP007 takes the P1/P2 rows from QP006 and asks what native integer shift would
be required if an existing QGA076 meson role operator is used as the seed. It
does not use observed composite masses.

## Main Read

Best internal contact:

```text
pair = {summary['best_pair']}
surface = {summary['best_surface']}
seed role = {summary['best_seed_role_operator']}
required effective shift = {summary['best_required_effective_shift']}
integer shift delta = {summary['best_integer_shift_delta']}
```

A-share integer contacts found: `{summary['a_share_integer_contacts']}`

## Trial Table

| Pair | Surface | Seed role | Required shift | Delta | Contact class |
| --- | --- | --- | ---: | ---: | --- |
{table_lines}

## Counts

```text
priority rows used = {summary['priority_rows_used']}
trial rows = {summary['trial_rows']}
contact class counts = {summary['contact_class_counts']}
surface counts = {summary['surface_counts']}
```

## Next Frontier

`{summary['next_frontier']}`

QP008 should select among the internal surfaces and integer shifts using only
SAM-native route class, charge class, and A-share contact.

Generated at UTC: `{summary['generated_at_utc']}`
""",
        encoding="utf-8",
    )

    print(summary["result_class"])
    print(f"priority_rows_used={summary['priority_rows_used']}")
    print(f"trial_rows={summary['trial_rows']}")
    print(f"contact_class_counts={summary['contact_class_counts']}")
    print(f"best_pair={summary['best_pair']}")
    print(f"best_surface={summary['best_surface']}")
    print(f"a_share_integer_contacts={summary['a_share_integer_contacts']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
