from __future__ import annotations

import csv
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
PUBLIC_ROOT = Path(r"C:\VS\Stam_model-A-v1.0")
if str(PUBLIC_ROOT) not in sys.path:
    sys.path.insert(0, str(PUBLIC_ROOT))

from sam.constants import A0, A_HALF, MEV_TO_KG, M_LAMBDA, N0, SLOT_DEN  # noqa: E402
from sam.mass import ROLE_OPERATORS  # noqa: E402


QP007_TRIAL = ROOT / "qp007_role_operator_mass_closure_trial_table.csv"

SUMMARY_OUT = ROOT / "qp008_heavy_role_shift_selector_summary.json"
SELECTED_OUT = ROOT / "qp008_heavy_role_shift_selector_table.csv"
NEXT_OUT = ROOT / "qp008_next_frontier.csv"
DOC_OUT = ROOT / "QP008_PRIVATE_HEAVY_ROLE_SHIFT_SELECTOR.md"

ROLE_SURFACE_SELECTOR = {
    "DUAL_POLARITY_CHARGED_HEAVY_ROLE_OPERATOR": {
        "selected_surface": "INTERACTION_COORDINATE_SURFACE",
        "basis": "dual polarity routes select the direct transported-response interaction coordinate",
    },
    "NEUTRAL_BINARY_MIXING_ROLE_OPERATOR": {
        "selected_surface": "CLOSURE_COMPLEMENT_SURFACE",
        "basis": "neutral binary mixing selects the remaining closure complement after the interaction split",
    },
    "TRANSITION_COLOR_COUPLED_ROLE_OPERATOR": {
        "selected_surface": "CLOSURE_COMPLEMENT_SURFACE",
        "basis": "8+4 transition/color coupling selects the residual reorganization complement",
    },
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fnum(value: Any) -> float:
    return float(str(value).strip())


def fmt(value: float) -> str:
    return f"{value:.12g}"


def role_mass_at_shift(role: str, shift: int) -> float:
    op = ROLE_OPERATORS[role]
    r_bounce = A_HALF * op.q / SLOT_DEN
    lam = A0 * A0 * op.k / (2.0 ** (N0 + shift)) / (1.0 + r_bounce)
    return lam * M_LAMBDA / MEV_TO_KG


def main() -> None:
    if not QP007_TRIAL.exists():
        raise FileNotFoundError(QP007_TRIAL)

    trials = read_csv(QP007_TRIAL)
    selected_rows: list[dict[str, Any]] = []
    for trial in trials:
        selector = ROLE_SURFACE_SELECTOR[trial["phase_role_operator"]]
        if trial["surface_name"] != selector["selected_surface"]:
            continue
        if trial["integer_shift_contact_class"] != "INTEGER_SHIFT_A_SHARE_CONTACT":
            continue
        shift = int(trial["nearest_integer_shift"])
        readout_mass = role_mass_at_shift(trial["seed_role_operator"], shift)
        target_surface = fnum(trial["surface_mass_MeV"])
        selected_rows.append(
            {
                "selected_rank": "",
                "suk055_pair": trial["suk055_pair"],
                "oriented_symbols": trial["oriented_symbols"],
                "priority_class": trial["priority_class"],
                "phase_role_operator": trial["phase_role_operator"],
                "selected_surface": trial["surface_name"],
                "surface_selector_basis": selector["basis"],
                "seed_role_operator": trial["seed_role_operator"],
                "selected_integer_shift": shift,
                "required_effective_shift": trial["required_effective_shift"],
                "integer_shift_delta": trial["integer_shift_delta"],
                "selected_mass_readout_MeV": fmt(readout_mass),
                "target_internal_surface_MeV": trial["surface_mass_MeV"],
                "readout_to_surface_ratio": fmt(readout_mass / target_surface if target_surface else 0.0),
                "absolute_surface_delta_MeV": fmt(readout_mass - target_surface),
                "integer_shift_contact_class": trial["integer_shift_contact_class"],
                "observed_composite_mass_used": "false",
            }
        )

    selected_rows.sort(key=lambda row: (abs(fnum(row["integer_shift_delta"])), row["suk055_pair"]))
    for index, row in enumerate(selected_rows, start=1):
        row["selected_rank"] = index

    role_counts: dict[str, int] = {}
    shift_counts: dict[str, int] = {}
    for row in selected_rows:
        role_counts[row["phase_role_operator"]] = role_counts.get(row["phase_role_operator"], 0) + 1
        key = str(row["selected_integer_shift"])
        shift_counts[key] = shift_counts.get(key, 0) + 1

    summary = {
        "artifact": "QP008_PRIVATE_HEAVY_ROLE_SHIFT_SELECTOR",
        "result_class": "QP008_PRIVATE_HEAVY_ROLE_SHIFT_SELECTOR_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_D_DRIVE_READS_QP007_AND_PUBLIC_SAM_ROLE_OPERATORS_ONLY",
        "writes_public_repo": False,
        "uses_observed_composite_masses": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "candidate_trials_read": len(trials),
        "selected_rows": len(selected_rows),
        "role_counts": role_counts,
        "selected_integer_shift_counts": shift_counts,
        "selected_pairs": [row["suk055_pair"] for row in selected_rows],
        "best_pair": selected_rows[0]["suk055_pair"] if selected_rows else "",
        "best_selected_mass_readout_MeV": selected_rows[0]["selected_mass_readout_MeV"] if selected_rows else "",
        "next_frontier": "QP009_PRIVATE_HEAVY_COMPOSITE_EXTERNAL_COMPARISON_SEALED_OPTION",
    }

    write_csv(
        SELECTED_OUT,
        selected_rows,
        [
            "selected_rank",
            "suk055_pair",
            "oriented_symbols",
            "priority_class",
            "phase_role_operator",
            "selected_surface",
            "surface_selector_basis",
            "seed_role_operator",
            "selected_integer_shift",
            "required_effective_shift",
            "integer_shift_delta",
            "selected_mass_readout_MeV",
            "target_internal_surface_MeV",
            "readout_to_surface_ratio",
            "absolute_surface_delta_MeV",
            "integer_shift_contact_class",
            "observed_composite_mass_used",
        ],
    )
    write_csv(
        NEXT_OUT,
        [
            {
                "frontier": "QP009_PRIVATE_HEAVY_COMPOSITE_EXTERNAL_COMPARISON_SEALED_OPTION",
                "why_next": "QP008 emits private selected heavy-composite mass readouts without observed composite masses. QP009 can either stop here and seal the private prediction table, or compare selected rows to external observed masses on a secure machine.",
                "input_surface": "qp008_heavy_role_shift_selector_table.csv",
                "target_output": "sealed private heavy-composite prediction table or external comparison",
            }
        ],
        ["frontier", "why_next", "input_surface", "target_output"],
    )
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    table_lines = "\n".join(
        f"| {row['selected_rank']} | {row['suk055_pair']} | {row['selected_surface']} | {row['seed_role_operator']} | {row['selected_integer_shift']} | {row['selected_mass_readout_MeV']} |"
        for row in selected_rows
    )
    DOC_OUT.write_text(
        f"""# QP008 - Private Heavy Role Shift Selector

Location: `D:\\quantum_phase`

## Verdict

`{summary['result_class']}`

QP008 selects the A-share contact surface for each P1/P2 phase-role class and
emits the nearest native integer-shift mass readout. It does not use observed
composite masses.

## Main Read

Selected rows: `{summary['selected_rows']}`

Selected pairs:

```text
{', '.join(summary['selected_pairs'])}
```

## Selected Readouts

| Rank | Pair | Selected surface | Seed role | Shift | Selected mass MeV |
| ---: | --- | --- | --- | ---: | ---: |
{table_lines}

## Counts

```text
candidate trials read = {summary['candidate_trials_read']}
selected rows = {summary['selected_rows']}
role counts = {summary['role_counts']}
selected integer shift counts = {summary['selected_integer_shift_counts']}
```

## Next Frontier

`{summary['next_frontier']}`

At this point there are two clean options: seal the private prediction table,
or run an external comparison only on the secure machine.

Generated at UTC: `{summary['generated_at_utc']}`
""",
        encoding="utf-8",
    )

    print(summary["result_class"])
    print(f"candidate_trials_read={summary['candidate_trials_read']}")
    print(f"selected_rows={summary['selected_rows']}")
    print(f"selected_pairs={summary['selected_pairs']}")
    print(f"best_pair={summary['best_pair']}")
    print(f"best_selected_mass_readout_MeV={summary['best_selected_mass_readout_MeV']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
