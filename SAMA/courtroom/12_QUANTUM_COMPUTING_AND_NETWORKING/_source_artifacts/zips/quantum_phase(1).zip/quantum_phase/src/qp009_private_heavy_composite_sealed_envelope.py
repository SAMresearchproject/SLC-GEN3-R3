from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parent
SOURCE_FILES = [
    ROOT / "qp008_heavy_role_shift_selector_table.csv",
    ROOT / "qp008_heavy_role_shift_selector_summary.json",
    ROOT / "QP008_PRIVATE_HEAVY_ROLE_SHIFT_SELECTOR.md",
]

SUMMARY_OUT = ROOT / "qp009_private_heavy_composite_sealed_envelope_summary.json"
MANIFEST_OUT = ROOT / "qp009_private_heavy_composite_sealed_manifest.csv"
DOC_OUT = ROOT / "QP009_PRIVATE_HEAVY_COMPOSITE_SEALED_ENVELOPE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    for path in SOURCE_FILES:
        if not path.exists():
            raise FileNotFoundError(path)

    generated_at = datetime.now(timezone.utc).isoformat()
    selected_rows = read_csv(SOURCE_FILES[0])
    manifest_rows = [
        {
            "sealed_file": path.name,
            "relative_path": str(path.relative_to(ROOT)),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
            "sealed_at_utc": generated_at,
        }
        for path in SOURCE_FILES
    ]

    prediction_rows = [
        {
            "suk055_pair": row["suk055_pair"],
            "oriented_symbols": row["oriented_symbols"],
            "phase_role_operator": row["phase_role_operator"],
            "selected_surface": row["selected_surface"],
            "seed_role_operator": row["seed_role_operator"],
            "selected_integer_shift": row["selected_integer_shift"],
            "selected_mass_readout_MeV": row["selected_mass_readout_MeV"],
        }
        for row in selected_rows
    ]

    summary = {
        "artifact": "QP009_PRIVATE_HEAVY_COMPOSITE_SEALED_ENVELOPE",
        "result_class": "QP009_PRIVATE_HEAVY_COMPOSITE_PREDICTION_TABLE_SEALED",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_D_DRIVE_ONLY",
        "writes_public_repo": False,
        "uses_observed_composite_masses": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "sealed_files": len(manifest_rows),
        "sealed_prediction_rows": len(prediction_rows),
        "sealed_predictions": prediction_rows,
        "external_comparison_status": "DEFERRED_TO_SECURE_MACHINE",
    }

    write_csv(MANIFEST_OUT, manifest_rows, ["sealed_file", "relative_path", "bytes", "sha256", "sealed_at_utc"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")

    manifest_lines = "\n".join(
        f"| {row['sealed_file']} | {row['bytes']} | `{row['sha256']}` |"
        for row in manifest_rows
    )
    prediction_lines = "\n".join(
        f"| {row['suk055_pair']} | {row['oriented_symbols']} | {row['selected_surface']} | {row['selected_integer_shift']} | {row['selected_mass_readout_MeV']} |"
        for row in prediction_rows
    )
    DOC_OUT.write_text(
        f"""# QP009 - Private Heavy Composite Sealed Envelope

Location: `D:\\quantum_phase`

## Verdict

`{summary['result_class']}`

The QP008 private heavy-composite prediction table is sealed for transfer to a
secure machine. No observed composite masses or external comparison data were
used.

## Sealed Predictions

| Pair | Oriented symbols | Selected surface | Shift | Selected mass MeV |
| --- | --- | --- | ---: | ---: |
{prediction_lines}

## File Manifest

| File | Bytes | SHA-256 |
| --- | ---: | --- |
{manifest_lines}

## Status

```text
sealed prediction rows = {summary['sealed_prediction_rows']}
external comparison status = {summary['external_comparison_status']}
sealed at UTC = {summary['generated_at_utc']}
```
""",
        encoding="utf-8",
    )

    print(summary["result_class"])
    print(f"sealed_prediction_rows={summary['sealed_prediction_rows']}")
    print(f"sealed_files={summary['sealed_files']}")
    print(f"external_comparison_status={summary['external_comparison_status']}")


if __name__ == "__main__":
    main()
