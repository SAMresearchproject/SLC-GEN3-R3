from __future__ import annotations

import csv
import json
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SUMMARY_IN = ROOT / "phase_field_engine_summary.json"
QUBIT_IN = ROOT / "qubit_engineering_table.csv"
SCORECARD_IN = ROOT / "data" / "quantum_computing" / "indexes" / "quantum_org_scorecard.csv"

SUMMARY_OUT = ROOT / "qp010_protected_route_boundary_summary.json"
CONTACT_OUT = ROOT / "qp010_contact_channel_table.csv"
PROTECTION_OUT = ROOT / "qp010_qubit_protection_table.csv"
MODALITY_OUT = ROOT / "qp010_modality_alignment_table.csv"
LEDGER_CELL_OUT = ROOT / "qp010_ledger_cell_mapping.csv"
NEXT_OUT = ROOT / "qp010_next_frontier.csv"
DOC_OUT = ROOT / "QP010_PRIVATE_PROTECTED_ROUTE_BOUNDARY_LAW.md"


@dataclass(frozen=True)
class Thresholds:
    a_side: float
    a_share: float
    a_d_block: float
    a_alpha_h_sq: float
    a_alpha_h_d: float
    a_horizon: float
    t_sw_s: float


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fmt(value: float) -> str:
    if value == float("inf"):
        return "inf"
    return f"{value:.12g}"


def load_thresholds(summary: dict[str, object]) -> Thresholds:
    by_name = {row["name"]: float(row["value"]) for row in summary["thresholds"]}
    return Thresholds(
        a_side=by_name["A_SIDE"],
        a_share=by_name["A_SHARE"],
        a_d_block=by_name["A_D_BLOCK"],
        a_alpha_h_sq=by_name["A_ALPHA_H_SQ"],
        a_alpha_h_d=by_name["A_ALPHA_H_D"],
        a_horizon=by_name["A_HORIZON"],
        t_sw_s=float(summary["constants"]["T_SW_s"]),
    )


def ticks_to(target: float, rate: float) -> float:
    if rate <= 0:
        return float("inf")
    return target / rate


def clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def one_tick_cell_integrity(rate: float, th: Thresholds) -> float:
    return 1.0 - clamp01(rate / th.a_side)


def write_candidacy(rate: float, th: Thresholds) -> float:
    return clamp01((rate - th.a_side) / (th.a_share - th.a_side))


def route_protection_status(rate: float, th: Thresholds) -> str:
    if rate < th.a_side:
        return "PROTECTED_UNRESOLVED_ROUTE"
    if rate < th.a_share:
        return "LEAKING_WRITE_CANDIDATE"
    if rate < th.a_alpha_h_d:
        return "WRITE_ACCESSIBLE_UNSTABLE"
    return "CLASSICAL_LEDGER_PRESSURE"


def exposure_family(row: dict[str, str]) -> str:
    blob = " ".join(
        [
            row.get("dominant_A_exposure", ""),
            row.get("recommended_mode", ""),
            row.get("structural_advantage", ""),
        ]
    ).lower()
    if "weak" in blob:
        return "WEAK_CONTACT_LIMITED"
    if "no_charge" in blob or "neutral" in blob or "minimal" in blob:
        return "NEUTRAL_LOW_CONTACT"
    if "em" in blob or "charged" in blob:
        return "EM_CONTACT_LIMITED"
    if "support" in blob or "lattice" in blob:
        return "SUPPORT_COUPLED"
    if "partition" in blob or "triadic" in blob:
        return "PARTITION_OCCUPANCY_COUPLED"
    return "UNKNOWN_CONTACT_FAMILY"


def contact_channel_rows(th: Thresholds) -> list[dict[str, object]]:
    return [
        {
            "channel": "ambient_A_contact",
            "SAM_quantity": "Gamma_leak_base",
            "route_effect": "adds unresolved A leakage per t_SW",
            "protection_rule": "A_leak(N)=N*Gamma_leak must remain below A_SIDE",
            "first_boundary": "A_SIDE=1/24",
        },
        {
            "channel": "thermal_write_noise",
            "SAM_quantity": "uncontrolled contact density",
            "route_effect": "raises Gamma_leak and shortens protected window",
            "protection_rule": "cooling suppresses uncontrolled route writes",
            "first_boundary": "A_SIDE=1/24",
        },
        {
            "channel": "collision_exposure",
            "SAM_quantity": "contact events",
            "route_effect": "environment can write without human observation",
            "protection_rule": "vacuum/isolation lowers collision-driven leakage",
            "first_boundary": "A_SHARE=1/12",
        },
        {
            "channel": "controlled_drive",
            "SAM_quantity": "selected Gamma_res",
            "route_effect": "intentional route steering without uncontrolled leakage",
            "protection_rule": "control must stay below premature write except at read/write step",
            "first_boundary": "A_SHARE=1/12",
        },
        {
            "channel": "measurement_readout",
            "SAM_quantity": "forced A-resolution",
            "route_effect": "commits ledger state when write access is selected",
            "protection_rule": "measurement is a resolution event, not human awareness",
            "first_boundary": "A_SHARE=1/12",
        },
        {
            "channel": "ledger_cell_boundary",
            "SAM_quantity": "inside route / outside leakage boundary",
            "route_effect": "protects the inside unresolved route from outside-frame contact",
            "protection_rule": "decoherence is leakage through the cell boundary",
            "first_boundary": "A_SIDE=1/24",
        },
    ]


def build_qubit_protection_rows(qubit_rows: list[dict[str, str]], th: Thresholds) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in qubit_rows:
        rate = float(row["A_exposure_rate_per_t_SW"])
        ticks_side = ticks_to(th.a_side, rate)
        ticks_share = ticks_to(th.a_share, rate)
        ticks_midpoint = ticks_to(th.a_alpha_h_d, rate)
        seconds_side = ticks_side * th.t_sw_s
        seconds_share = ticks_share * th.t_sw_s
        rows.append(
            {
                "qubit_id": row["qubit_id"],
                "route": row["qubit_native_route"],
                "partition": row["subchannel_partition"],
                "Q_native_class": row["Q_native_class"],
                "exposure_family": exposure_family(row),
                "Gamma_leak_per_t_SW": rate,
                "cell_integrity_one_t_SW": one_tick_cell_integrity(rate, th),
                "write_candidacy_one_t_SW": write_candidacy(rate, th),
                "ticks_to_A_SIDE": ticks_side,
                "ticks_to_A_SHARE": ticks_share,
                "ticks_to_WRITE_MIDPOINT": ticks_midpoint,
                "seconds_to_A_SIDE": seconds_side,
                "seconds_to_A_SHARE": seconds_share,
                "protection_margin_to_A_SIDE": ticks_side,
                "protection_status": route_protection_status(rate, th),
                "recommended_mode": row["recommended_mode"],
                "structural_advantage": row["structural_advantage"],
            }
        )
    rows.sort(key=lambda item: float(item["protection_margin_to_A_SIDE"]), reverse=True)
    for rank, row in enumerate(rows, start=1):
        row["QP010_protection_rank"] = rank
    return rows


def build_modality_rows(score_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in score_rows:
        modality = row["primary_modality"]
        if modality in {"trapped ion", "neutral atom"}:
            sam_fit = "DIRECT_ROUTE_ISOLATION_FIT"
            cell_reading = "physical particles isolated inside engineered ledger cells"
        elif modality == "superconducting":
            sam_fit = "ENGINEERED_MACRO_PHASE_CELL_FIT"
            cell_reading = "collective circuit phase protected by cold boundary engineering"
        elif modality == "photonic":
            sam_fit = "LOW_CONTACT_ROUTE_FIT_WITH_LOSS_BOUNDARY"
            cell_reading = "route travels with low matter contact but boundary loss is hard"
        elif modality == "topological":
            sam_fit = "HIGH_UPSIDE_BOUNDARY_PROTECTION_CANDIDATE"
            cell_reading = "would protect unresolved route by topology if validated"
        else:
            sam_fit = "SPECIALIZED_ROUTE_FIT"
            cell_reading = "useful clue but not broad protected-route model"
        rows.append(
            {
                "organization": row["organization"],
                "primary_modality": modality,
                "classification": row["classification"],
                "score_18": row["total_18"],
                "SAM_protected_route_fit": sam_fit,
                "ledger_cell_reading": cell_reading,
                "best_signal": row["best_signal"],
                "main_risk": row["main_risk"],
            }
        )
    rows.sort(key=lambda item: int(item["score_18"]), reverse=True)
    return rows


def ledger_cell_mapping_rows() -> list[dict[str, object]]:
    return [
        {
            "SAM_cell_element": "inside_unresolved_route",
            "quantum_phase_reading": "protected qubit/logical route packet",
            "failure_mode": "premature write",
            "control_goal": "preserve coherence until selected Gamma_res",
        },
        {
            "SAM_cell_element": "cell_boundary",
            "quantum_phase_reading": "isolation, vacuum, shielding, cryogenic boundary, trap boundary",
            "failure_mode": "ledger leakage",
            "control_goal": "minimize uncontrolled A-contact",
        },
        {
            "SAM_cell_element": "outside_frame",
            "quantum_phase_reading": "thermal bath, stray fields, collisions, readout hardware",
            "failure_mode": "uncontrolled A-resolution",
            "control_goal": "couple only through deliberate control/readout channels",
        },
        {
            "SAM_cell_element": "boundary_syndrome",
            "quantum_phase_reading": "error syndrome without logical identity collapse",
            "failure_mode": "measuring logical route instead of boundary damage",
            "control_goal": "write damage information while preserving route identity",
        },
    ]


def render_doc(
    summary: dict[str, object],
    protection_rows: list[dict[str, object]],
    modality_rows: list[dict[str, object]],
) -> str:
    top = protection_rows[:5]
    top_lines = "\n".join(
        "| {rank} | {qubit} | {family} | {ticks} | {status} |".format(
            rank=row["QP010_protection_rank"],
            qubit=row["qubit_id"],
            family=row["exposure_family"],
            ticks=fmt(float(row["ticks_to_A_SIDE"])),
            status=row["protection_status"],
        )
        for row in top
    )
    modality_top = "\n".join(
        "| {org} | {modality} | {fit} | {score} |".format(
            org=row["organization"],
            modality=row["primary_modality"],
            fit=row["SAM_protected_route_fit"],
            score=row["score_18"],
        )
        for row in modality_rows[:5]
    )
    return f"""# QP010 - Private Protected Route Boundary Law

## Verdict

`{summary['result_class']}`

QP010 turns quantum-computing protection evidence into a SAM-native unresolved
route law:

```text
A_leak(N) = N * Gamma_leak
protected route: A_leak < A_SIDE = 1/24
write candidate: A_SIDE <= A_leak < A_SHARE = 1/12
resolution accessible: A_leak >= A_SHARE
```

## Main Read

The ledger-cell picture sharpens the quantum phase lane:

```text
qubit = protected unresolved route inside a ledger cell
decoherence = uncontrolled A leakage through the cell boundary
measurement = selected A-resolution
QEC syndrome = boundary damage write without logical route collapse
```

No free parameters were introduced. QP010 uses the existing route exposure
rates from the private phase-field table and the existing R=12 thresholds.

## Protection Leaders

| Rank | Qubit | Exposure Family | ticks to A_SIDE | Status |
| ---: | --- | --- | ---: | --- |
{top_lines}

## Modality Alignment

| Organization | Modality | SAM Fit | Score |
| --- | --- | --- | ---: |
{modality_top}

## Outputs

```text
qp010_contact_channel_table.csv
qp010_qubit_protection_table.csv
qp010_modality_alignment_table.csv
qp010_ledger_cell_mapping.csv
qp010_protected_route_boundary_summary.json
qp010_next_frontier.csv
```

## Next Frontier

`QP011_PRIVATE_DECOHERENCE_LEDGER_LEAKAGE_MODEL`

QP011 should turn this boundary law into a decoherence model:

```text
decoherence rate = uncontrolled ledger leakage rate
logical survival = protected route weight left before Gamma_res selection
```

Generated at UTC: `{summary['generated_at_utc']}`
"""


def main() -> int:
    summary_in = json.loads(SUMMARY_IN.read_text(encoding="utf-8"))
    th = load_thresholds(summary_in)
    qubit_rows = read_csv(QUBIT_IN)
    score_rows = read_csv(SCORECARD_IN) if SCORECARD_IN.exists() else []

    contact_rows = contact_channel_rows(th)
    protection_rows = build_qubit_protection_rows(qubit_rows, th)
    modality_rows = build_modality_rows(score_rows)
    ledger_rows = ledger_cell_mapping_rows()
    next_rows = [
        {
            "next_frontier": "QP011_PRIVATE_DECOHERENCE_LEDGER_LEAKAGE_MODEL",
            "why_next": "QP010 defines protected-route leakage thresholds; QP011 should model decoherence as uncontrolled ledger leakage over time.",
            "input_surface": "qp010_qubit_protection_table.csv",
            "target_output": "decoherence survival / leakage model",
        }
    ]

    summary = {
        "artifact": "QP010_PRIVATE_PROTECTED_ROUTE_BOUNDARY_LAW",
        "result_class": "QP010_PRIVATE_PROTECTED_ROUTE_BOUNDARY_LAW_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "external_data_used": bool(score_rows),
        "free_parameters_introduced": 0,
        "thresholds": {
            "A_SIDE": th.a_side,
            "A_SHARE": th.a_share,
            "A_WRITE_MIDPOINT": th.a_alpha_h_d,
        },
        "law": "A_leak(N)=N*Gamma_leak; protected if A_leak<A_SIDE; write-candidate at A_SIDE; resolution-accessible at A_SHARE",
        "qubit_rows": len(protection_rows),
        "contact_rows": len(contact_rows),
        "modality_rows": len(modality_rows),
        "ledger_cell_rows": len(ledger_rows),
        "top_protected_route": protection_rows[0]["qubit_id"],
        "top_ticks_to_A_SIDE": protection_rows[0]["ticks_to_A_SIDE"],
        "top_ticks_to_A_SHARE": protection_rows[0]["ticks_to_A_SHARE"],
        "status_counts": {
            status: sum(1 for row in protection_rows if row["protection_status"] == status)
            for status in sorted({row["protection_status"] for row in protection_rows})
        },
        "next_frontier": "QP011_PRIVATE_DECOHERENCE_LEDGER_LEAKAGE_MODEL",
    }

    write_csv(
        CONTACT_OUT,
        contact_rows,
        ["channel", "SAM_quantity", "route_effect", "protection_rule", "first_boundary"],
    )
    write_csv(
        PROTECTION_OUT,
        protection_rows,
        [
            "QP010_protection_rank",
            "qubit_id",
            "route",
            "partition",
            "Q_native_class",
            "exposure_family",
            "Gamma_leak_per_t_SW",
            "cell_integrity_one_t_SW",
            "write_candidacy_one_t_SW",
            "ticks_to_A_SIDE",
            "ticks_to_A_SHARE",
            "ticks_to_WRITE_MIDPOINT",
            "seconds_to_A_SIDE",
            "seconds_to_A_SHARE",
            "protection_margin_to_A_SIDE",
            "protection_status",
            "recommended_mode",
            "structural_advantage",
        ],
    )
    write_csv(
        MODALITY_OUT,
        modality_rows,
        [
            "organization",
            "primary_modality",
            "classification",
            "score_18",
            "SAM_protected_route_fit",
            "ledger_cell_reading",
            "best_signal",
            "main_risk",
        ],
    )
    write_csv(
        LEDGER_CELL_OUT,
        ledger_rows,
        ["SAM_cell_element", "quantum_phase_reading", "failure_mode", "control_goal"],
    )
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "input_surface", "target_output"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    DOC_OUT.write_text(render_doc(summary, protection_rows, modality_rows), encoding="utf-8")

    print(summary["result_class"])
    print(f"top_protected_route={summary['top_protected_route']}")
    print(f"top_ticks_to_A_SIDE={fmt(float(summary['top_ticks_to_A_SIDE']))}")
    print(f"top_ticks_to_A_SHARE={fmt(float(summary['top_ticks_to_A_SHARE']))}")
    print(f"status_counts={summary['status_counts']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
