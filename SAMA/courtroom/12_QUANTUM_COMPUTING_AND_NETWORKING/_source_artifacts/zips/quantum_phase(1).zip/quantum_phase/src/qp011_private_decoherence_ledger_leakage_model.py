from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
QP010_IN = ROOT / "qp010_qubit_protection_table.csv"
QP010_SUMMARY_IN = ROOT / "qp010_protected_route_boundary_summary.json"

SUMMARY_OUT = ROOT / "qp011_summary.json"
WINDOWS_OUT = ROOT / "qp011_route_leakage_windows.csv"
SURVIVAL_OUT = ROOT / "qp011_decoherence_survival_table.csv"
CLASS_OUT = ROOT / "qp011_decoherence_class_table.csv"
NEXT_OUT = ROOT / "qp011_next_frontier.csv"
DOC_OUT = ROOT / "QP011_PRIVATE_DECOHERENCE_LEDGER_LEAKAGE_MODEL.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fmt(value: float) -> str:
    if value == float("inf"):
        return "inf"
    return f"{value:.12g}"


def clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def ledger_status(a_leak: float, a_side: float, a_share: float, a_midpoint: float) -> str:
    eps = 1e-12
    if a_leak < a_side - eps:
        return "PROTECTED_ROUTE_LEAKING_BELOW_HALF_WRITE"
    if a_leak < a_share - eps:
        return "DECOHERED_WRITE_CANDIDATE_NOT_SELECTED"
    if a_leak < a_midpoint - eps:
        return "UNCONTROLLED_WRITE_ACCESSIBLE"
    return "CLASSICAL_LEDGER_PRESSURE"


def leakage_metrics(n_ticks: float, gamma_leak: float, a_side: float, a_share: float, a_midpoint: float) -> dict[str, object]:
    a_leak = n_ticks * gamma_leak
    protected_survival = clamp01(1.0 - (a_leak / a_side))
    share_survival = clamp01(1.0 - (a_leak / a_share))
    decoherence_pressure = clamp01(a_leak / a_side)
    write_pressure = clamp01((a_leak - a_side) / (a_share - a_side))
    resolution_access = clamp01(a_leak / a_share)
    return {
        "N_ticks": n_ticks,
        "A_leak": a_leak,
        "protected_cell_survival": protected_survival,
        "share_survival": share_survival,
        "decoherence_pressure": decoherence_pressure,
        "write_pressure": write_pressure,
        "resolution_access": resolution_access,
        "ledger_status": ledger_status(a_leak, a_side, a_share, a_midpoint),
    }


def sample_points(row: dict[str, str]) -> list[tuple[str, float]]:
    ticks_side = float(row["ticks_to_A_SIDE"])
    ticks_share = float(row["ticks_to_A_SHARE"])
    ticks_midpoint = float(row["ticks_to_WRITE_MIDPOINT"])
    return [
        ("ONE_T_SW", 1.0),
        ("QUARTER_A_SIDE", 0.25 * ticks_side),
        ("HALF_A_SIDE", 0.5 * ticks_side),
        ("A_SIDE_BOUNDARY", ticks_side),
        ("MID_A_SIDE_TO_A_SHARE", 0.5 * (ticks_side + ticks_share)),
        ("A_SHARE_BOUNDARY", ticks_share),
        ("WRITE_MIDPOINT", ticks_midpoint),
    ]


def build_window_rows(qp010_rows: list[dict[str, str]], a_side: float, a_share: float, a_midpoint: float) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in qp010_rows:
        gamma = float(row["Gamma_leak_per_t_SW"])
        ticks_side = a_side / gamma
        ticks_share = a_share / gamma
        ticks_midpoint = a_midpoint / gamma
        protected_window = ticks_side
        candidate_window = ticks_share - ticks_side
        rows.append(
            {
                "QP011_decoherence_rank": 0,
                "qubit_id": row["qubit_id"],
                "route": row["route"],
                "partition": row["partition"],
                "Q_native_class": row["Q_native_class"],
                "exposure_family": row["exposure_family"],
                "Gamma_leak_per_t_SW": gamma,
                "ticks_to_A_SIDE": ticks_side,
                "ticks_to_A_SHARE": ticks_share,
                "ticks_to_WRITE_MIDPOINT": ticks_midpoint,
                "protected_window_ticks": protected_window,
                "write_candidate_window_ticks": candidate_window,
                "protected_to_candidate_ratio": protected_window / candidate_window if candidate_window else float("inf"),
                "one_tick_protected_survival": clamp01(1.0 - gamma / a_side),
                "one_tick_decoherence_pressure": clamp01(gamma / a_side),
                "one_tick_write_pressure": clamp01((gamma - a_side) / (a_share - a_side)),
                "decoherence_model_status": "DECOHERENCE_BEFORE_WRITE_ACCESS",
            }
        )
    rows.sort(key=lambda item: float(item["protected_window_ticks"]), reverse=True)
    for rank, row in enumerate(rows, start=1):
        row["QP011_decoherence_rank"] = rank
    return rows


def build_survival_rows(qp010_rows: list[dict[str, str]], a_side: float, a_share: float, a_midpoint: float) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in qp010_rows:
        gamma = float(row["Gamma_leak_per_t_SW"])
        for sample_id, n_ticks in sample_points(row):
            metrics = leakage_metrics(n_ticks, gamma, a_side, a_share, a_midpoint)
            rows.append(
                {
                    "qubit_id": row["qubit_id"],
                    "sample_id": sample_id,
                    "N_ticks": metrics["N_ticks"],
                    "Gamma_leak_per_t_SW": gamma,
                    "A_leak": metrics["A_leak"],
                    "protected_cell_survival": metrics["protected_cell_survival"],
                    "share_survival": metrics["share_survival"],
                    "decoherence_pressure": metrics["decoherence_pressure"],
                    "write_pressure": metrics["write_pressure"],
                    "resolution_access": metrics["resolution_access"],
                    "ledger_status": metrics["ledger_status"],
                }
            )
    return rows


def build_class_rows() -> list[dict[str, object]]:
    return [
        {
            "class": "PROTECTED_ROUTE_LEAKING_BELOW_HALF_WRITE",
            "A_range": "0 <= A_leak < A_SIDE",
            "SAM_reading": "unresolved route still protected but leakage is accumulating",
            "measurement_required": False,
            "human_observation_required": False,
        },
        {
            "class": "DECOHERED_WRITE_CANDIDATE_NOT_SELECTED",
            "A_range": "A_SIDE <= A_leak < A_SHARE",
            "SAM_reading": "protected cell boundary has leaked; write candidacy exists before selected resolution",
            "measurement_required": False,
            "human_observation_required": False,
        },
        {
            "class": "UNCONTROLLED_WRITE_ACCESSIBLE",
            "A_range": "A_SHARE <= A_leak < WRITE_MIDPOINT",
            "SAM_reading": "environmental leakage alone has reached write-accessible scale",
            "measurement_required": False,
            "human_observation_required": False,
        },
        {
            "class": "CLASSICAL_LEDGER_PRESSURE",
            "A_range": "A_leak >= WRITE_MIDPOINT",
            "SAM_reading": "route is under classical ledger pressure from leakage/write accumulation",
            "measurement_required": False,
            "human_observation_required": False,
        },
    ]


def render_doc(summary: dict[str, object], window_rows: list[dict[str, object]]) -> str:
    leaders = "\n".join(
        "| {rank} | {qubit} | {family} | {side} | {survival} |".format(
            rank=row["QP011_decoherence_rank"],
            qubit=row["qubit_id"],
            family=row["exposure_family"],
            side=fmt(float(row["ticks_to_A_SIDE"])),
            survival=fmt(float(row["one_tick_protected_survival"])),
        )
        for row in window_rows[:5]
    )
    return f"""# QP011 - Private Decoherence Ledger Leakage Model

## Verdict

`{summary['result_class']}`

QP011 turns QP010's protected-route law into a decoherence model:

```text
A_leak(N) = N * Gamma_leak
protected_cell_survival = clamp(1 - A_leak/A_SIDE, 0, 1)
share_survival = clamp(1 - A_leak/A_SHARE, 0, 1)
decoherence_pressure = clamp(A_leak/A_SIDE, 0, 1)
write_pressure = clamp((A_leak - A_SIDE)/(A_SHARE - A_SIDE), 0, 1)
```

## Main Read

Decoherence is uncontrolled ledger leakage through the route cell boundary.
It does not require human observation, and it begins before selected write.

```text
A_SIDE = {summary['thresholds']['A_SIDE']}
A_SHARE = {summary['thresholds']['A_SHARE']}
WRITE midpoint = {summary['thresholds']['A_WRITE_MIDPOINT']}
```

The strongest protected route remains:

```text
{summary['top_decoherence_protected_route']}
ticks to A_SIDE = {summary['top_ticks_to_A_SIDE']}
ticks to A_SHARE = {summary['top_ticks_to_A_SHARE']}
```

Fastest leakage route:

```text
{summary['fastest_leak_route']}
ticks to A_SIDE = {summary['fastest_ticks_to_A_SIDE']}
```

## Protection Leaders

| Rank | Qubit | Exposure Family | ticks to A_SIDE | one-tick survival |
| ---: | --- | --- | ---: | ---: |
{leaders}

## Meaning

QP011 separates three things that often get blurred:

```text
leakage = uncontrolled A contact through the cell boundary
decoherence = loss of protected unresolved-route survival
measurement = selected Gamma_res write access
```

So decoherence can happen without measurement:

```text
environment contact -> A_leak accumulates -> protected route survival drops
```

## Outputs

```text
qp011_route_leakage_windows.csv
qp011_decoherence_survival_table.csv
qp011_decoherence_class_table.csv
qp011_summary.json
qp011_next_frontier.csv
```

## Next Frontier

`QP012_PRIVATE_SYNDROME_WRITE_WITHOUT_LOGICAL_ROUTE_COLLAPSE`

QP012 should use the leakage model to show how a syndrome write can record
boundary damage while the protected logical route identity remains unresolved.

Generated at UTC: `{summary['generated_at_utc']}`
"""


def main() -> int:
    qp010_summary = json.loads(QP010_SUMMARY_IN.read_text(encoding="utf-8"))
    thresholds = qp010_summary["thresholds"]
    a_side = float(thresholds["A_SIDE"])
    a_share = float(thresholds["A_SHARE"])
    a_midpoint = float(thresholds["A_WRITE_MIDPOINT"])
    qp010_rows = read_csv(QP010_IN)

    window_rows = build_window_rows(qp010_rows, a_side, a_share, a_midpoint)
    survival_rows = build_survival_rows(qp010_rows, a_side, a_share, a_midpoint)
    class_rows = build_class_rows()
    next_rows = [
        {
            "next_frontier": "QP012_PRIVATE_SYNDROME_WRITE_WITHOUT_LOGICAL_ROUTE_COLLAPSE",
            "why_next": "QP011 defines uncontrolled leakage and decoherence pressure; QP012 should separate boundary syndrome write from logical route identity collapse.",
            "input_surface": "qp011_decoherence_survival_table.csv",
            "target_output": "syndrome/logical access separation model",
        }
    ]

    status_counts = {
        status: sum(1 for row in survival_rows if row["ledger_status"] == status)
        for status in sorted({row["ledger_status"] for row in survival_rows})
    }
    one_tick_protected = sum(
        1
        for row in survival_rows
        if row["sample_id"] == "ONE_T_SW"
        and row["ledger_status"] == "PROTECTED_ROUTE_LEAKING_BELOW_HALF_WRITE"
    )
    top = window_rows[0]
    fastest = window_rows[-1]
    summary = {
        "artifact": "QP011_PRIVATE_DECOHERENCE_LEDGER_LEAKAGE_MODEL",
        "result_class": "QP011_PRIVATE_DECOHERENCE_LEDGER_LEAKAGE_MODEL_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "thresholds": {
            "A_SIDE": a_side,
            "A_SHARE": a_share,
            "A_WRITE_MIDPOINT": a_midpoint,
        },
        "law": "A_leak(N)=N*Gamma_leak; protected_cell_survival=clamp(1-A_leak/A_SIDE,0,1); write_pressure=clamp((A_leak-A_SIDE)/(A_SHARE-A_SIDE),0,1)",
        "qubit_rows": len(qp010_rows),
        "window_rows": len(window_rows),
        "survival_rows": len(survival_rows),
        "class_rows": len(class_rows),
        "one_tick_protected_routes": one_tick_protected,
        "status_counts": status_counts,
        "top_decoherence_protected_route": top["qubit_id"],
        "top_ticks_to_A_SIDE": top["ticks_to_A_SIDE"],
        "top_ticks_to_A_SHARE": top["ticks_to_A_SHARE"],
        "fastest_leak_route": fastest["qubit_id"],
        "fastest_ticks_to_A_SIDE": fastest["ticks_to_A_SIDE"],
        "protection_window_ratio_top_to_fastest": float(top["ticks_to_A_SIDE"]) / float(fastest["ticks_to_A_SIDE"]),
        "core_interpretation": "decoherence is uncontrolled A leakage through the protected route cell boundary before selected Gamma_res write access",
        "next_frontier": "QP012_PRIVATE_SYNDROME_WRITE_WITHOUT_LOGICAL_ROUTE_COLLAPSE",
    }

    write_csv(
        WINDOWS_OUT,
        window_rows,
        [
            "QP011_decoherence_rank",
            "qubit_id",
            "route",
            "partition",
            "Q_native_class",
            "exposure_family",
            "Gamma_leak_per_t_SW",
            "ticks_to_A_SIDE",
            "ticks_to_A_SHARE",
            "ticks_to_WRITE_MIDPOINT",
            "protected_window_ticks",
            "write_candidate_window_ticks",
            "protected_to_candidate_ratio",
            "one_tick_protected_survival",
            "one_tick_decoherence_pressure",
            "one_tick_write_pressure",
            "decoherence_model_status",
        ],
    )
    write_csv(
        SURVIVAL_OUT,
        survival_rows,
        [
            "qubit_id",
            "sample_id",
            "N_ticks",
            "Gamma_leak_per_t_SW",
            "A_leak",
            "protected_cell_survival",
            "share_survival",
            "decoherence_pressure",
            "write_pressure",
            "resolution_access",
            "ledger_status",
        ],
    )
    write_csv(
        CLASS_OUT,
        class_rows,
        ["class", "A_range", "SAM_reading", "measurement_required", "human_observation_required"],
    )
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "input_surface", "target_output"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    DOC_OUT.write_text(render_doc(summary, window_rows), encoding="utf-8")

    print(summary["result_class"])
    print(f"top_decoherence_protected_route={summary['top_decoherence_protected_route']}")
    print(f"top_ticks_to_A_SIDE={fmt(float(summary['top_ticks_to_A_SIDE']))}")
    print(f"fastest_leak_route={summary['fastest_leak_route']}")
    print(f"fastest_ticks_to_A_SIDE={fmt(float(summary['fastest_ticks_to_A_SIDE']))}")
    print(f"one_tick_protected_routes={summary['one_tick_protected_routes']}/{summary['qubit_rows']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
