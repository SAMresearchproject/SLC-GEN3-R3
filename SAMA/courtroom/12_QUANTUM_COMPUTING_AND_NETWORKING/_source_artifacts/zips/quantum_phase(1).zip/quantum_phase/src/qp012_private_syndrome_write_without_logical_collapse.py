from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parent
QP011_SURVIVAL_IN = ROOT / "qp011_decoherence_survival_table.csv"
QP011_WINDOWS_IN = ROOT / "qp011_route_leakage_windows.csv"
QP011_SUMMARY_IN = ROOT / "qp011_summary.json"

SUMMARY_OUT = ROOT / "qp012_summary.json"
MODES_OUT = ROOT / "qp012_readout_mode_table.csv"
SEPARATION_OUT = ROOT / "qp012_syndrome_logical_separation_table.csv"
WINDOW_OUT = ROOT / "qp012_qec_window_table.csv"
NEXT_OUT = ROOT / "qp012_next_frontier.csv"
DOC_OUT = ROOT / "QP012_PRIVATE_SYNDROME_WRITE_WITHOUT_LOGICAL_ROUTE_COLLAPSE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fmt(value: float) -> str:
    return f"{value:.12g}"


def readout_modes() -> list[dict[str, object]]:
    return [
        {
            "mode": "NO_READ",
            "syndrome_probe": 0,
            "logical_probe": 0,
            "SAM_reading": "no boundary damage write and no logical route read",
        },
        {
            "mode": "SYNDROME_ONLY",
            "syndrome_probe": 1,
            "logical_probe": 0,
            "SAM_reading": "write boundary damage information while hiding logical route identity",
        },
        {
            "mode": "LOGICAL_ROUTE_READ",
            "syndrome_probe": 0,
            "logical_probe": 1,
            "SAM_reading": "read the protected route identity; collapse risk starts at write candidacy",
        },
        {
            "mode": "MIXED_SYNDROME_AND_LOGICAL_READ",
            "syndrome_probe": 1,
            "logical_probe": 1,
            "SAM_reading": "boundary read contaminated by logical route access",
        },
    ]


def classify_access(sample: dict[str, str], mode: dict[str, object], a_share: float) -> dict[str, object]:
    a_leak = float(sample["A_leak"])
    decoherence_pressure = float(sample["decoherence_pressure"])
    write_pressure = float(sample["write_pressure"])
    resolution_access = float(sample["resolution_access"])
    share_survival = float(sample["share_survival"])
    syndrome_probe = int(mode["syndrome_probe"])
    logical_probe = int(mode["logical_probe"])

    syndrome_signal = syndrome_probe * decoherence_pressure
    syndrome_write = syndrome_signal > 0.0
    logical_identity_read = logical_probe > 0
    uncontrolled_write_accessible = a_leak >= a_share - 1e-12
    logical_collapse = logical_identity_read and (write_pressure > 0.0 or uncontrolled_write_accessible)
    no_collapse_syndrome = (
        syndrome_write
        and not logical_identity_read
        and not uncontrolled_write_accessible
        and share_survival > 0.0
    )

    if mode["mode"] == "NO_READ":
        status = "NO_SYNDROME_NO_LOGICAL_WRITE"
    elif no_collapse_syndrome:
        status = "SYNDROME_WRITE_WITHOUT_LOGICAL_COLLAPSE"
    elif syndrome_write and not logical_identity_read and uncontrolled_write_accessible:
        status = "SYNDROME_TOO_LATE_UNCONTROLLED_WRITE_ACCESSIBLE"
    elif logical_collapse:
        status = "LOGICAL_ROUTE_COLLAPSE"
    elif logical_identity_read:
        status = "LOGICAL_PROBE_BELOW_WRITE_CANDIDACY"
    else:
        status = "BOUNDARY_READ_NO_DAMAGE_SIGNAL"

    return {
        "syndrome_signal": syndrome_signal,
        "syndrome_write": syndrome_write,
        "logical_identity_read": logical_identity_read,
        "logical_collapse": logical_collapse,
        "uncontrolled_write_accessible": uncontrolled_write_accessible,
        "share_survival_after_syndrome": share_survival if no_collapse_syndrome else 0.0,
        "syndrome_without_collapse": no_collapse_syndrome,
        "status": status,
        "loophole_reading": (
            "BOUNDARY_DAMAGE_WRITE_SIDE_CHANNEL"
            if no_collapse_syndrome
            else "NO_QEC_SIDE_CHANNEL"
        ),
    }


def build_separation_rows(samples: list[dict[str, str]], a_share: float) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for sample in samples:
        for mode in readout_modes():
            access = classify_access(sample, mode, a_share)
            rows.append(
                {
                    "qubit_id": sample["qubit_id"],
                    "sample_id": sample["sample_id"],
                    "mode": mode["mode"],
                    "N_ticks": sample["N_ticks"],
                    "A_leak": sample["A_leak"],
                    "decoherence_pressure": sample["decoherence_pressure"],
                    "write_pressure": sample["write_pressure"],
                    "resolution_access": sample["resolution_access"],
                    "share_survival": sample["share_survival"],
                    "syndrome_probe": mode["syndrome_probe"],
                    "logical_probe": mode["logical_probe"],
                    "syndrome_signal": access["syndrome_signal"],
                    "syndrome_write": access["syndrome_write"],
                    "logical_identity_read": access["logical_identity_read"],
                    "logical_collapse": access["logical_collapse"],
                    "uncontrolled_write_accessible": access["uncontrolled_write_accessible"],
                    "share_survival_after_syndrome": access["share_survival_after_syndrome"],
                    "syndrome_without_collapse": access["syndrome_without_collapse"],
                    "status": access["status"],
                    "loophole_reading": access["loophole_reading"],
                }
            )
    return rows


def build_window_rows(windows: list[dict[str, str]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in windows:
        ticks_to_share = float(row["ticks_to_A_SHARE"])
        ticks_to_side = float(row["ticks_to_A_SIDE"])
        rows.append(
            {
                "qubit_id": row["qubit_id"],
                "route": row["route"],
                "exposure_family": row["exposure_family"],
                "Gamma_leak_per_t_SW": row["Gamma_leak_per_t_SW"],
                "syndrome_without_collapse_window_ticks": ticks_to_share,
                "protected_subwindow_ticks": ticks_to_side,
                "decohered_candidate_subwindow_ticks": ticks_to_share - ticks_to_side,
                "window_split_ratio": (ticks_to_share - ticks_to_side) / ticks_to_share,
                "QP012_window_rank": 0,
                "SAM_reading": "syndrome-only access can write boundary damage until A_SHARE makes uncontrolled write accessible",
            }
        )
    rows.sort(key=lambda item: float(item["syndrome_without_collapse_window_ticks"]), reverse=True)
    for rank, row in enumerate(rows, start=1):
        row["QP012_window_rank"] = rank
    return rows


def render_doc(summary: dict[str, object], window_rows: list[dict[str, object]]) -> str:
    top_lines = "\n".join(
        "| {rank} | {qubit} | {family} | {window} |".format(
            rank=row["QP012_window_rank"],
            qubit=row["qubit_id"],
            family=row["exposure_family"],
            window=fmt(float(row["syndrome_without_collapse_window_ticks"])),
        )
        for row in window_rows[:5]
    )
    return f"""# QP012 - Private Syndrome Write Without Logical Route Collapse

## Verdict

`{summary['result_class']}`

QP012 identifies the SAM side-channel used by quantum error correction:

```text
syndrome write = boundary damage information
logical collapse = route identity write
```

The loophole is real in the SAM accounting:

```text
boundary damage can be written while logical route identity remains hidden
```

## Core Rule

```text
allowed syndrome-only write:
  syndrome_probe = 1
  logical_probe = 0
  A_leak < A_SHARE
  share_survival > 0

collapse route:
  logical_probe = 1
  and write_pressure > 0 or A_leak >= A_SHARE
```

## Main Read

```text
syndrome-without-collapse rows = {summary['syndrome_without_collapse_rows']}
logical-collapse rows = {summary['logical_collapse_rows']}
too-late syndrome rows = {summary['too_late_syndrome_rows']}
```

Top no-collapse window:

```text
{summary['top_window_route']}
ticks = {summary['top_syndrome_without_collapse_window_ticks']}
```

Fastest closing window:

```text
{summary['fastest_window_route']}
ticks = {summary['fastest_syndrome_without_collapse_window_ticks']}
```

## Window Leaders

| Rank | Qubit | Exposure Family | syndrome/no-collapse window ticks |
| ---: | --- | --- | ---: |
{top_lines}

## Meaning

QP012 is the measurement loophole in SAM form:

```text
physical interaction can write boundary damage
without writing the protected route identity
```

That is why measurement-like operations can occur during error correction
without collapsing the logical route. The write is real, but it is typed:

```text
boundary syndrome write != logical route write
```

## Outputs

```text
qp012_readout_mode_table.csv
qp012_syndrome_logical_separation_table.csv
qp012_qec_window_table.csv
qp012_summary.json
qp012_next_frontier.csv
```

## Next Frontier

`QP013_PRIVATE_A_CONTACT_SUPPRESSION_TABLE`

QP013 should map cooling, vacuum, shielding, traps, photonics, and QEC to the
specific SAM leakage channels they suppress or control.

Generated at UTC: `{summary['generated_at_utc']}`
"""


def main() -> int:
    qp011_summary = json.loads(QP011_SUMMARY_IN.read_text(encoding="utf-8"))
    thresholds = qp011_summary["thresholds"]
    a_share = float(thresholds["A_SHARE"])
    samples = read_csv(QP011_SURVIVAL_IN)
    windows = read_csv(QP011_WINDOWS_IN)

    modes = readout_modes()
    separation_rows = build_separation_rows(samples, a_share)
    window_rows = build_window_rows(windows)
    next_rows = [
        {
            "next_frontier": "QP013_PRIVATE_A_CONTACT_SUPPRESSION_TABLE",
            "why_next": "QP012 identifies the syndrome side-channel; QP013 should map hardware protection strategies to specific leakage-channel suppression.",
            "input_surface": "qp012_syndrome_logical_separation_table.csv",
            "target_output": "A-contact suppression map",
        }
    ]

    status_counts = {
        status: sum(1 for row in separation_rows if row["status"] == status)
        for status in sorted({row["status"] for row in separation_rows})
    }
    syndrome_without_collapse = sum(
        1 for row in separation_rows if row["syndrome_without_collapse"] is True
    )
    logical_collapse = sum(
        1 for row in separation_rows if row["logical_collapse"] is True
    )
    too_late = sum(
        1 for row in separation_rows if row["status"] == "SYNDROME_TOO_LATE_UNCONTROLLED_WRITE_ACCESSIBLE"
    )
    top = window_rows[0]
    fastest = window_rows[-1]
    summary = {
        "artifact": "QP012_PRIVATE_SYNDROME_WRITE_WITHOUT_LOGICAL_ROUTE_COLLAPSE",
        "result_class": "QP012_PRIVATE_SYNDROME_WRITE_WITHOUT_LOGICAL_ROUTE_COLLAPSE_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "thresholds": thresholds,
        "rule": "syndrome-only write is allowed when syndrome_probe=1, logical_probe=0, A_leak<A_SHARE, and share_survival>0",
        "mode_rows": len(modes),
        "separation_rows": len(separation_rows),
        "window_rows": len(window_rows),
        "syndrome_without_collapse_rows": syndrome_without_collapse,
        "logical_collapse_rows": logical_collapse,
        "too_late_syndrome_rows": too_late,
        "status_counts": status_counts,
        "top_window_route": top["qubit_id"],
        "top_syndrome_without_collapse_window_ticks": top["syndrome_without_collapse_window_ticks"],
        "fastest_window_route": fastest["qubit_id"],
        "fastest_syndrome_without_collapse_window_ticks": fastest["syndrome_without_collapse_window_ticks"],
        "core_interpretation": "QEC side-channel: write boundary damage without writing protected logical route identity",
        "next_frontier": "QP013_PRIVATE_A_CONTACT_SUPPRESSION_TABLE",
    }

    write_csv(
        MODES_OUT,
        modes,
        ["mode", "syndrome_probe", "logical_probe", "SAM_reading"],
    )
    write_csv(
        SEPARATION_OUT,
        separation_rows,
        [
            "qubit_id",
            "sample_id",
            "mode",
            "N_ticks",
            "A_leak",
            "decoherence_pressure",
            "write_pressure",
            "resolution_access",
            "share_survival",
            "syndrome_probe",
            "logical_probe",
            "syndrome_signal",
            "syndrome_write",
            "logical_identity_read",
            "logical_collapse",
            "uncontrolled_write_accessible",
            "share_survival_after_syndrome",
            "syndrome_without_collapse",
            "status",
            "loophole_reading",
        ],
    )
    write_csv(
        WINDOW_OUT,
        window_rows,
        [
            "QP012_window_rank",
            "qubit_id",
            "route",
            "exposure_family",
            "Gamma_leak_per_t_SW",
            "syndrome_without_collapse_window_ticks",
            "protected_subwindow_ticks",
            "decohered_candidate_subwindow_ticks",
            "window_split_ratio",
            "SAM_reading",
        ],
    )
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "input_surface", "target_output"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    DOC_OUT.write_text(render_doc(summary, window_rows), encoding="utf-8")

    print(summary["result_class"])
    print(f"syndrome_without_collapse_rows={summary['syndrome_without_collapse_rows']}")
    print(f"logical_collapse_rows={summary['logical_collapse_rows']}")
    print(f"top_window_route={summary['top_window_route']}")
    print(f"top_window_ticks={fmt(float(summary['top_syndrome_without_collapse_window_ticks']))}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
