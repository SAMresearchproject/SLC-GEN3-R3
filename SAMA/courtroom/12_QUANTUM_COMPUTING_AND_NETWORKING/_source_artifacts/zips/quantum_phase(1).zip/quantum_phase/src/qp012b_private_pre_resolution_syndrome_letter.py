from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
QP012_DIR = ARTIFACTS / "qp012"
QP012B_DIR = ARTIFACTS / "qp012b"

QP012_SEPARATION_IN = QP012_DIR / "qp012_syndrome_logical_separation_table.csv"
QP012_WINDOW_IN = QP012_DIR / "qp012_qec_window_table.csv"
QP012_SUMMARY_IN = QP012_DIR / "qp012_summary.json"

SUMMARY_OUT = QP012B_DIR / "qp012b_summary.json"
LETTER_OUT = QP012B_DIR / "qp012b_syndrome_letter_table.csv"
ROUTE_LEAD_OUT = QP012B_DIR / "qp012b_route_lead_table.csv"
SCHEMA_OUT = QP012B_DIR / "qp012b_letter_content_schema.csv"
NEXT_OUT = QP012B_DIR / "qp012b_next_frontier.csv"
DOC_OUT = REPORTS / "QP012B_PRIVATE_PRE_RESOLUTION_SYNDROME_LETTER.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fmt(value: float) -> str:
    return f"{value:.12g}"


def bool_str(value: object) -> bool:
    return str(value).strip().lower() == "true"


def content_schema_rows() -> list[dict[str, object]]:
    return [
        {
            "letter_field": "route_family",
            "allowed_before_resolution": True,
            "meaning": "which route family / exposure family is under boundary stress",
        },
        {
            "letter_field": "boundary_stress",
            "allowed_before_resolution": True,
            "meaning": "how much leakage has reached the route-cell boundary",
        },
        {
            "letter_field": "time_to_A_SIDE",
            "allowed_before_resolution": True,
            "meaning": "how far from half-write boundary breach",
        },
        {
            "letter_field": "time_to_A_SHARE",
            "allowed_before_resolution": True,
            "meaning": "how far from uncontrolled write accessibility",
        },
        {
            "letter_field": "basin_bias",
            "allowed_before_resolution": True,
            "meaning": "which resolution basin is becoming favored by pressure",
        },
        {
            "letter_field": "syndrome_signal",
            "allowed_before_resolution": True,
            "meaning": "boundary damage signal strength",
        },
        {
            "letter_field": "final_ledger_outcome",
            "allowed_before_resolution": False,
            "meaning": "not known until logical route write / Gamma_res selection",
        },
        {
            "letter_field": "logical_route_identity",
            "allowed_before_resolution": False,
            "meaning": "withheld by syndrome-only access; reading it risks collapse",
        },
    ]


def basin_reading(a_leak: float, a_side: float, a_share: float) -> str:
    if a_leak < a_side - 1e-12:
        return "PROTECTED_ROUTE_DAMAGE_WARNING"
    if a_leak < a_share - 1e-12:
        return "WRITE_CANDIDACY_BASIN_FORMING"
    return "RESOLUTION_ACCESSIBLE_TOO_LATE"


def letter_strength_class(decoherence_pressure: float, write_pressure: float) -> str:
    if write_pressure > 0.0:
        return "BASIN_FORMING_LETTER"
    if decoherence_pressure >= 1.0:
        return "BOUNDARY_BREACH_LETTER"
    if decoherence_pressure > 0.0:
        return "EARLY_BOUNDARY_STRESS_LETTER"
    return "NO_LETTER"


def build_letter_rows(
    separation_rows: list[dict[str, str]],
    window_by_qubit: dict[str, dict[str, str]],
    a_side: float,
    a_share: float,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in separation_rows:
        if row["mode"] != "SYNDROME_ONLY":
            continue
        qubit_id = row["qubit_id"]
        window = window_by_qubit[qubit_id]
        n_ticks = float(row["N_ticks"])
        a_leak = float(row["A_leak"])
        decoherence_pressure = float(row["decoherence_pressure"])
        write_pressure = float(row["write_pressure"])
        resolution_access = float(row["resolution_access"])
        ticks_to_side = float(window["protected_subwindow_ticks"])
        ticks_to_share = float(window["syndrome_without_collapse_window_ticks"])
        lead_to_side = max(ticks_to_side - n_ticks, 0.0)
        lead_to_share = max(ticks_to_share - n_ticks, 0.0)
        valid_letter = bool_str(row["syndrome_without_collapse"])
        rows.append(
            {
                "qubit_id": qubit_id,
                "sample_id": row["sample_id"],
                "route": window["route"],
                "exposure_family": window["exposure_family"],
                "N_ticks": n_ticks,
                "A_leak": a_leak,
                "syndrome_signal": row["syndrome_signal"],
                "boundary_stress": decoherence_pressure,
                "write_pressure": write_pressure,
                "resolution_access": resolution_access,
                "ticks_until_A_SIDE": lead_to_side,
                "ticks_until_A_SHARE": lead_to_share,
                "letter_precedes_resolution": valid_letter and lead_to_share > 0.0,
                "valid_pre_resolution_letter": valid_letter,
                "basin_bias": basin_reading(a_leak, a_side, a_share),
                "letter_strength_class": letter_strength_class(decoherence_pressure, write_pressure),
                "can_report_route_family": valid_letter,
                "can_report_boundary_stress": valid_letter,
                "can_report_basin_bias": valid_letter,
                "final_ledger_outcome_known": False,
                "logical_route_identity_known": False,
                "SAM_reading": (
                    "boundary letter precedes logical resolution"
                    if valid_letter
                    else "letter too late or no syndrome side-channel"
                ),
            }
        )
    return rows


def build_route_lead_rows(letter_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    by_qubit: dict[str, list[dict[str, object]]] = {}
    for row in letter_rows:
        by_qubit.setdefault(str(row["qubit_id"]), []).append(row)

    out: list[dict[str, object]] = []
    for qubit_id, rows in by_qubit.items():
        valid = [row for row in rows if row["valid_pre_resolution_letter"] is True]
        first = min(valid, key=lambda row: float(row["N_ticks"])) if valid else None
        max_lead = max((float(row["ticks_until_A_SHARE"]) for row in valid), default=0.0)
        basin_rows = [row for row in valid if row["basin_bias"] == "WRITE_CANDIDACY_BASIN_FORMING"]
        first_basin = min(basin_rows, key=lambda row: float(row["N_ticks"])) if basin_rows else None
        total_window = max((float(row["N_ticks"]) + float(row["ticks_until_A_SHARE"]) for row in rows), default=0.0)
        out.append(
            {
                "qubit_id": qubit_id,
                "route": rows[0]["route"],
                "exposure_family": rows[0]["exposure_family"],
                "first_letter_tick": first["N_ticks"] if first else "",
                "first_letter_lead_to_A_SHARE_ticks": first["ticks_until_A_SHARE"] if first else "",
                "max_letter_lead_to_A_SHARE_ticks": max_lead,
                "first_basin_forming_tick": first_basin["N_ticks"] if first_basin else "",
                "first_basin_forming_lead_to_A_SHARE_ticks": (
                    first_basin["ticks_until_A_SHARE"] if first_basin else ""
                ),
                "total_no_collapse_window_ticks": total_window,
                "letter_window_fraction": max_lead / total_window if total_window else 0.0,
                "QP012B_lead_rank": 0,
                "SAM_reading": "Paul Revere letter: boundary information precedes final logical write",
            }
        )
    out.sort(key=lambda row: float(row["max_letter_lead_to_A_SHARE_ticks"]), reverse=True)
    for rank, row in enumerate(out, start=1):
        row["QP012B_lead_rank"] = rank
    return out


def render_doc(summary: dict[str, object], lead_rows: list[dict[str, object]]) -> str:
    top_lines = "\n".join(
        "| {rank} | {qubit} | {family} | {lead} | {basin} |".format(
            rank=row["QP012B_lead_rank"],
            qubit=row["qubit_id"],
            family=row["exposure_family"],
            lead=fmt(float(row["max_letter_lead_to_A_SHARE_ticks"])),
            basin=(
                fmt(float(row["first_basin_forming_lead_to_A_SHARE_ticks"]))
                if row["first_basin_forming_lead_to_A_SHARE_ticks"] != ""
                else "n/a"
            ),
        )
        for row in lead_rows[:5]
    )
    return f"""# QP012B - Private Pre-Resolution Syndrome Letter

## Verdict

`{summary['result_class']}`

QP012B turns the Paul Revere image into a SAM side-channel law:

```text
the boundary letter can arrive before the logical route resolves
```

The letter can contain:

```text
route family
boundary stress
time to A_SIDE
time to A_SHARE
basin bias
syndrome signal
```

The letter cannot contain:

```text
final ledger outcome
logical route identity
```

## Main Read

```text
valid pre-resolution letters = {summary['valid_pre_resolution_letters']}
letters that precede A_SHARE = {summary['letters_preceding_resolution']}
basin-forming letters = {summary['basin_forming_letters']}
final outcomes known = {summary['final_outcomes_known']}
logical identities known = {summary['logical_identities_known']}
```

Top lead route:

```text
{summary['top_lead_route']}
max lead to A_SHARE = {summary['top_max_letter_lead_to_A_SHARE_ticks']} ticks
```

## Lead Leaders

| Rank | Qubit | Exposure Family | max lead to A_SHARE | first basin-forming lead |
| ---: | --- | --- | ---: | ---: |
{top_lines}

## Meaning

This is not prediction of the final future. It is pre-resolution boundary
information:

```text
syndrome signal -> route pressure -> basin forming -> later logical write
```

So the loophole is:

```text
SAM can know where resolution pressure is forming
before the protected route identity is written.
```

## Outputs

```text
qp012b_syndrome_letter_table.csv
qp012b_route_lead_table.csv
qp012b_letter_content_schema.csv
qp012b_summary.json
qp012b_next_frontier.csv
```

## Next Frontier

`QP013_PRIVATE_A_CONTACT_SUPPRESSION_TABLE`

QP013 should map how cooling, vacuum, shielding, traps, photonics, and QEC
change the letter/leakage channel by suppressing or controlling A-contact.

Generated at UTC: `{summary['generated_at_utc']}`
"""


def main() -> int:
    qp012_summary = json.loads(QP012_SUMMARY_IN.read_text(encoding="utf-8"))
    thresholds = qp012_summary["thresholds"]
    a_side = float(thresholds["A_SIDE"])
    a_share = float(thresholds["A_SHARE"])
    separation_rows = read_csv(QP012_SEPARATION_IN)
    window_rows = read_csv(QP012_WINDOW_IN)
    window_by_qubit = {row["qubit_id"]: row for row in window_rows}

    letter_rows = build_letter_rows(separation_rows, window_by_qubit, a_side, a_share)
    lead_rows = build_route_lead_rows(letter_rows)
    schema_rows = content_schema_rows()
    next_rows = [
        {
            "next_frontier": "QP013_PRIVATE_A_CONTACT_SUPPRESSION_TABLE",
            "why_next": "QP012B identifies pre-resolution boundary letters; QP013 should map how physical protection strategies suppress or control the leakage channels that generate those letters.",
            "input_surface": "qp012b_syndrome_letter_table.csv",
            "target_output": "A-contact suppression and controlled-letter channel map",
        }
    ]

    valid_letters = sum(1 for row in letter_rows if row["valid_pre_resolution_letter"] is True)
    preceding = sum(1 for row in letter_rows if row["letter_precedes_resolution"] is True)
    basin = sum(1 for row in letter_rows if row["basin_bias"] == "WRITE_CANDIDACY_BASIN_FORMING")
    final_known = sum(1 for row in letter_rows if row["final_ledger_outcome_known"] is True)
    identities_known = sum(1 for row in letter_rows if row["logical_route_identity_known"] is True)
    top = lead_rows[0]
    summary = {
        "artifact": "QP012B_PRIVATE_PRE_RESOLUTION_SYNDROME_LETTER",
        "result_class": "QP012B_PRIVATE_PRE_RESOLUTION_SYNDROME_LETTER_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "thresholds": thresholds,
        "rule": "pre-resolution letter is valid when syndrome-only signal exists, A_leak<A_SHARE, and logical_probe=0",
        "letter_rows": len(letter_rows),
        "lead_rows": len(lead_rows),
        "schema_rows": len(schema_rows),
        "valid_pre_resolution_letters": valid_letters,
        "letters_preceding_resolution": preceding,
        "basin_forming_letters": basin,
        "final_outcomes_known": final_known,
        "logical_identities_known": identities_known,
        "top_lead_route": top["qubit_id"],
        "top_max_letter_lead_to_A_SHARE_ticks": top["max_letter_lead_to_A_SHARE_ticks"],
        "top_first_basin_forming_lead_to_A_SHARE_ticks": top["first_basin_forming_lead_to_A_SHARE_ticks"],
        "core_interpretation": "the syndrome letter reports boundary pressure and basin bias before logical route identity or final ledger outcome is written",
        "next_frontier": "QP013_PRIVATE_A_CONTACT_SUPPRESSION_TABLE",
    }

    write_csv(
        LETTER_OUT,
        letter_rows,
        [
            "qubit_id",
            "sample_id",
            "route",
            "exposure_family",
            "N_ticks",
            "A_leak",
            "syndrome_signal",
            "boundary_stress",
            "write_pressure",
            "resolution_access",
            "ticks_until_A_SIDE",
            "ticks_until_A_SHARE",
            "letter_precedes_resolution",
            "valid_pre_resolution_letter",
            "basin_bias",
            "letter_strength_class",
            "can_report_route_family",
            "can_report_boundary_stress",
            "can_report_basin_bias",
            "final_ledger_outcome_known",
            "logical_route_identity_known",
            "SAM_reading",
        ],
    )
    write_csv(
        ROUTE_LEAD_OUT,
        lead_rows,
        [
            "QP012B_lead_rank",
            "qubit_id",
            "route",
            "exposure_family",
            "first_letter_tick",
            "first_letter_lead_to_A_SHARE_ticks",
            "max_letter_lead_to_A_SHARE_ticks",
            "first_basin_forming_tick",
            "first_basin_forming_lead_to_A_SHARE_ticks",
            "total_no_collapse_window_ticks",
            "letter_window_fraction",
            "SAM_reading",
        ],
    )
    write_csv(
        SCHEMA_OUT,
        schema_rows,
        ["letter_field", "allowed_before_resolution", "meaning"],
    )
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "input_surface", "target_output"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    DOC_OUT.write_text(render_doc(summary, lead_rows), encoding="utf-8")

    print(summary["result_class"])
    print(f"valid_pre_resolution_letters={summary['valid_pre_resolution_letters']}")
    print(f"letters_preceding_resolution={summary['letters_preceding_resolution']}")
    print(f"basin_forming_letters={summary['basin_forming_letters']}")
    print(f"final_outcomes_known={summary['final_outcomes_known']}")
    print(f"top_lead_route={summary['top_lead_route']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
