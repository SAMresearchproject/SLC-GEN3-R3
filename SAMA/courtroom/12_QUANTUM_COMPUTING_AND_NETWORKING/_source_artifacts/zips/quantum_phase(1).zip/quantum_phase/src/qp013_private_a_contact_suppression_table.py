from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
QP010_DIR = ARTIFACTS / "qp010"
QP012B_DIR = ARTIFACTS / "qp012b"
QP013_DIR = ARTIFACTS / "qp013"

QP010_CONTACT_IN = QP010_DIR / "qp010_contact_channel_table.csv"
QP012B_LETTER_IN = QP012B_DIR / "qp012b_syndrome_letter_table.csv"
QP012B_LEAD_IN = QP012B_DIR / "qp012b_route_lead_table.csv"
QP012B_SUMMARY_IN = QP012B_DIR / "qp012b_summary.json"

SUMMARY_OUT = QP013_DIR / "qp013_summary.json"
SUPPRESSION_OUT = QP013_DIR / "qp013_contact_suppression_table.csv"
ROUTE_CONTROL_OUT = QP013_DIR / "qp013_route_control_window_table.csv"
STRATEGY_OUT = QP013_DIR / "qp013_suppression_strategy_table.csv"
NEXT_OUT = QP013_DIR / "qp013_next_frontier.csv"
DOC_OUT = REPORTS / "QP013_PRIVATE_A_CONTACT_SUPPRESSION_TABLE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fmt(value: float) -> str:
    if value == float("inf"):
        return "inf"
    return f"{value:.12g}"


def bool_str(value: object) -> bool:
    return str(value).strip().lower() == "true"


def clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def required_suppression_to(target_a: float, current_a: float) -> float:
    if current_a <= 0.0 or current_a <= target_a:
        return 0.0
    return clamp01(1.0 - target_a / current_a)


def contact_control_class(a_leak: float, valid_letter: bool, a_side: float, a_share: float) -> str:
    if not valid_letter and a_leak >= a_share - 1e-12:
        return "NO_COLLAPSE_WINDOW_CLOSED"
    if a_leak < a_side - 1e-12:
        return "PASSIVE_SYNDROME_MONITORING"
    if a_leak < a_share - 1e-12:
        return "ACTIVE_A_CONTACT_SUPPRESSION_WINDOW"
    return "RESOLUTION_ACCESSIBLE_TOO_LATE"


def recommended_surface(exposure_family: str, basin_bias: str) -> str:
    if basin_bias == "WRITE_CANDIDACY_BASIN_FORMING":
        prefix = "syndrome-triggered active suppression"
    else:
        prefix = "passive boundary monitoring"

    if exposure_family == "WEAK_CONTACT_LIMITED":
        return f"{prefix}; preserve weak-contact isolation and avoid logical readout"
    if exposure_family == "EM_CONTACT_LIMITED":
        return f"{prefix}; reduce uncontrolled EM contact with shielding/cooling/control discipline"
    if exposure_family == "PARTITION_OCCUPANCY_COUPLED":
        return f"{prefix}; balance partition occupancy and suppress cross-partition leakage"
    if exposure_family == "SUPPORT_COUPLED":
        return f"{prefix}; isolate support/lattice boundary before it becomes the write path"
    return f"{prefix}; lower uncontrolled ambient A-contact"


def build_contact_suppression_rows(
    letter_rows: list[dict[str, str]],
    a_side: float,
    a_share: float,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in letter_rows:
        a_leak = float(row["A_leak"])
        valid_letter = bool_str(row["valid_pre_resolution_letter"])
        required_to_side = required_suppression_to(a_side, a_leak)
        required_to_share = required_suppression_to(a_share, a_leak)
        class_name = contact_control_class(a_leak, valid_letter, a_side, a_share)
        suppressed_to_side = a_leak * (1.0 - required_to_side)
        rows.append(
            {
                "qubit_id": row["qubit_id"],
                "sample_id": row["sample_id"],
                "route": row["route"],
                "exposure_family": row["exposure_family"],
                "N_ticks": row["N_ticks"],
                "A_leak": a_leak,
                "basin_bias": row["basin_bias"],
                "letter_strength_class": row["letter_strength_class"],
                "valid_pre_resolution_letter": valid_letter,
                "ticks_until_A_SHARE": row["ticks_until_A_SHARE"],
                "required_suppression_to_restore_A_SIDE": required_to_side,
                "required_suppression_to_remain_below_A_SHARE": required_to_share,
                "A_after_required_side_suppression": suppressed_to_side,
                "pre_resolution_headroom_to_A_SHARE": clamp01((a_share - a_leak) / a_share),
                "control_class": class_name,
                "recommended_control_surface": recommended_surface(row["exposure_family"], row["basin_bias"]),
                "SAM_reading": (
                    "letter gives actionable suppression time before logical collapse"
                    if class_name == "ACTIVE_A_CONTACT_SUPPRESSION_WINDOW"
                    else "letter is monitor-only or the no-collapse window has closed"
                ),
            }
        )
    return rows


def build_route_control_rows(
    suppression_rows: list[dict[str, object]],
    lead_rows: list[dict[str, str]],
    a_side: float,
    a_share: float,
) -> list[dict[str, object]]:
    lead_by_qubit = {row["qubit_id"]: row for row in lead_rows}
    by_qubit: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in suppression_rows:
        by_qubit[str(row["qubit_id"])].append(row)

    rows: list[dict[str, object]] = []
    for qubit_id, items in by_qubit.items():
        valid = [row for row in items if row["valid_pre_resolution_letter"] is True]
        active = [row for row in valid if row["control_class"] == "ACTIVE_A_CONTACT_SUPPRESSION_WINDOW"]
        monitor = [row for row in valid if row["control_class"] == "PASSIVE_SYNDROME_MONITORING"]
        too_late = [row for row in items if row["control_class"] in {"NO_COLLAPSE_WINDOW_CLOSED", "RESOLUTION_ACCESSIBLE_TOO_LATE"}]
        max_req = max(
            (float(row["required_suppression_to_restore_A_SIDE"]) for row in active),
            default=0.0,
        )
        max_headroom = max((float(row["pre_resolution_headroom_to_A_SHARE"]) for row in valid), default=0.0)
        first_active = min(active, key=lambda row: float(row["N_ticks"])) if active else None
        lead = lead_by_qubit.get(qubit_id, {})
        rows.append(
            {
                "qubit_id": qubit_id,
                "route": items[0]["route"],
                "exposure_family": items[0]["exposure_family"],
                "valid_letter_rows": len(valid),
                "monitor_only_rows": len(monitor),
                "active_suppression_rows": len(active),
                "too_late_rows": len(too_late),
                "max_required_suppression_to_restore_A_SIDE": max_req,
                "native_theoretical_ceiling_before_A_SHARE": 1.0 - a_side / a_share,
                "max_pre_resolution_headroom_to_A_SHARE": max_headroom,
                "first_active_suppression_tick": first_active["N_ticks"] if first_active else "",
                "first_active_lead_to_A_SHARE_ticks": first_active["ticks_until_A_SHARE"] if first_active else "",
                "max_letter_lead_to_A_SHARE_ticks": lead.get("max_letter_lead_to_A_SHARE_ticks", ""),
                "first_basin_forming_lead_to_A_SHARE_ticks": lead.get(
                    "first_basin_forming_lead_to_A_SHARE_ticks",
                    "",
                ),
                "QP013_control_rank": 0,
                "SAM_reading": (
                    "pre-resolution letter supports active contact suppression"
                    if active
                    else "route is monitor-only in current samples"
                ),
            }
        )
    rows.sort(
        key=lambda row: (
            int(row["active_suppression_rows"]),
            float(row["max_letter_lead_to_A_SHARE_ticks"] or 0.0),
        ),
        reverse=True,
    )
    for rank, row in enumerate(rows, start=1):
        row["QP013_control_rank"] = rank
    return rows


def build_strategy_rows(contact_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    channel_readings = {
        "ambient_A_contact": (
            "shielding / distance / field quieting",
            "lowers background Gamma_leak without selecting logical route identity",
        ),
        "thermal_write_noise": (
            "cooling",
            "reduces uncontrolled write density before A_SIDE is reached",
        ),
        "collision_exposure": (
            "vacuum / isolation",
            "removes physical contact events that can resolve A without observation",
        ),
        "controlled_drive": (
            "shaped control pulses",
            "keeps selected Gamma_res separate from uncontrolled leakage",
        ),
        "measurement_readout": (
            "delayed logical readout",
            "avoids converting the syndrome letter into a route-identity write",
        ),
        "ledger_cell_boundary": (
            "trap / lattice / topology / cell geometry",
            "defines where leakage is allowed to report syndrome without collapse",
        ),
    }
    rows: list[dict[str, object]] = []
    for row in contact_rows:
        channel = row["channel"]
        control, effect = channel_readings.get(
            channel,
            ("generic isolation", "lowers uncontrolled A-contact"),
        )
        rows.append(
            {
                "channel": channel,
                "control_surface": control,
                "SAM_quantity": row["SAM_quantity"],
                "route_effect": row["route_effect"],
                "suppression_effect": effect,
                "first_boundary": row["first_boundary"],
                "QP013_role": (
                    "SUPPRESS"
                    if channel != "measurement_readout"
                    else "DELAY_UNTIL_SELECTED_RESOLUTION"
                ),
            }
        )
    return rows


def render_doc(
    summary: dict[str, object],
    route_rows: list[dict[str, object]],
    class_counts: Counter[str],
) -> str:
    top_lines = "\n".join(
        "| {rank} | {qubit} | {family} | {active} | {req} | {lead} |".format(
            rank=row["QP013_control_rank"],
            qubit=row["qubit_id"],
            family=row["exposure_family"],
            active=row["active_suppression_rows"],
            req=fmt(float(row["max_required_suppression_to_restore_A_SIDE"])),
            lead=fmt(float(row["max_letter_lead_to_A_SHARE_ticks"] or 0.0)),
        )
        for row in route_rows[:7]
    )
    class_lines = "\n".join(
        f"{name} = {count}" for name, count in sorted(class_counts.items())
    )
    return f"""# QP013 - Private A-Contact Suppression Table

## Verdict

`{summary['result_class']}`

QP013 converts the pre-resolution syndrome letter into a contact-control law:

```text
required suppression to restore A_SIDE = 1 - A_SIDE / A_leak
```

The letter does not need the final logical outcome. It needs to report enough
boundary pressure to say:

```text
this route is approaching uncontrolled write access
reduce contact before A_SHARE
```

## Main Read

```text
contact rows = {summary['contact_rows']}
active suppression rows = {summary['active_suppression_rows']}
passive monitor rows = {summary['passive_monitor_rows']}
too-late rows = {summary['too_late_rows']}
max sampled required suppression = {summary['max_sampled_required_suppression_to_restore_A_SIDE']}
native ceiling before A_SHARE = {summary['native_theoretical_ceiling_before_A_SHARE']}
```

Control-class counts:

```text
{class_lines}
```

## Control Leaders

| Rank | Qubit | Exposure Family | active rows | max required suppression | max letter lead |
| ---: | --- | --- | ---: | ---: | ---: |
{top_lines}

## Meaning

Cooling, vacuum, shielding, traps, isolation, and syndrome-only QEC all point to
the same SAM action:

```text
reduce uncontrolled A-contact
preserve the unresolved route
delay logical route identity write until selected resolution
```

QP013 sharpens the loophole:

```text
the system can receive a warning letter before collapse
and use it to suppress the contact channel that would cause collapse
```

## Outputs

```text
qp013_contact_suppression_table.csv
qp013_route_control_window_table.csv
qp013_suppression_strategy_table.csv
qp013_summary.json
qp013_next_frontier.csv
```

## Next Frontier

`QP014_PRIVATE_BORN_RULE_ROUTE_WEIGHT_BRIDGE`

QP014 should use the protected route window, suppression-adjusted contact, and
Gamma_res access to turn unresolved route strength into normalized route
weights.

Generated at UTC: `{summary['generated_at_utc']}`
"""


def main() -> int:
    qp012b_summary = json.loads(QP012B_SUMMARY_IN.read_text(encoding="utf-8"))
    thresholds = qp012b_summary["thresholds"]
    a_side = float(thresholds["A_SIDE"])
    a_share = float(thresholds["A_SHARE"])

    contact_rows = read_csv(QP010_CONTACT_IN)
    letter_rows = read_csv(QP012B_LETTER_IN)
    lead_rows = read_csv(QP012B_LEAD_IN)

    suppression_rows = build_contact_suppression_rows(letter_rows, a_side, a_share)
    route_rows = build_route_control_rows(suppression_rows, lead_rows, a_side, a_share)
    strategy_rows = build_strategy_rows(contact_rows)
    next_rows = [
        {
            "next_frontier": "QP014_PRIVATE_BORN_RULE_ROUTE_WEIGHT_BRIDGE",
            "why_next": "QP013 gives suppression-adjustable unresolved-route survival; QP014 should normalize route strengths into Born-style weights.",
            "input_surface": "qp013_contact_suppression_table.csv",
            "target_output": "route_weight_i and P_i = weight_i / sum(weight_all)",
        }
    ]

    class_counts = Counter(str(row["control_class"]) for row in suppression_rows)
    active_rows = [
        row
        for row in suppression_rows
        if row["control_class"] == "ACTIVE_A_CONTACT_SUPPRESSION_WINDOW"
    ]
    passive_rows = [
        row
        for row in suppression_rows
        if row["control_class"] == "PASSIVE_SYNDROME_MONITORING"
    ]
    too_late_rows = [
        row
        for row in suppression_rows
        if row["control_class"] in {"NO_COLLAPSE_WINDOW_CLOSED", "RESOLUTION_ACCESSIBLE_TOO_LATE"}
    ]
    max_sampled_req = max(
        (float(row["required_suppression_to_restore_A_SIDE"]) for row in active_rows),
        default=0.0,
    )
    native_ceiling = 1.0 - a_side / a_share
    top = route_rows[0]
    summary = {
        "artifact": "QP013_PRIVATE_A_CONTACT_SUPPRESSION_TABLE",
        "result_class": "QP013_PRIVATE_A_CONTACT_SUPPRESSION_TABLE_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "thresholds": thresholds,
        "law": "required_suppression_to_restore_A_SIDE = max(0, 1 - A_SIDE/A_leak)",
        "contact_rows": len(suppression_rows),
        "route_control_rows": len(route_rows),
        "strategy_rows": len(strategy_rows),
        "active_suppression_rows": len(active_rows),
        "passive_monitor_rows": len(passive_rows),
        "too_late_rows": len(too_late_rows),
        "control_class_counts": dict(class_counts),
        "max_sampled_required_suppression_to_restore_A_SIDE": max_sampled_req,
        "native_theoretical_ceiling_before_A_SHARE": native_ceiling,
        "top_control_route": top["qubit_id"],
        "top_control_route_family": top["exposure_family"],
        "top_control_route_active_rows": top["active_suppression_rows"],
        "top_control_route_max_letter_lead_to_A_SHARE_ticks": top["max_letter_lead_to_A_SHARE_ticks"],
        "core_interpretation": "pre-resolution syndrome letters can trigger contact suppression before logical route identity is written",
        "next_frontier": "QP014_PRIVATE_BORN_RULE_ROUTE_WEIGHT_BRIDGE",
    }

    write_csv(
        SUPPRESSION_OUT,
        suppression_rows,
        [
            "qubit_id",
            "sample_id",
            "route",
            "exposure_family",
            "N_ticks",
            "A_leak",
            "basin_bias",
            "letter_strength_class",
            "valid_pre_resolution_letter",
            "ticks_until_A_SHARE",
            "required_suppression_to_restore_A_SIDE",
            "required_suppression_to_remain_below_A_SHARE",
            "A_after_required_side_suppression",
            "pre_resolution_headroom_to_A_SHARE",
            "control_class",
            "recommended_control_surface",
            "SAM_reading",
        ],
    )
    write_csv(
        ROUTE_CONTROL_OUT,
        route_rows,
        [
            "QP013_control_rank",
            "qubit_id",
            "route",
            "exposure_family",
            "valid_letter_rows",
            "monitor_only_rows",
            "active_suppression_rows",
            "too_late_rows",
            "max_required_suppression_to_restore_A_SIDE",
            "native_theoretical_ceiling_before_A_SHARE",
            "max_pre_resolution_headroom_to_A_SHARE",
            "first_active_suppression_tick",
            "first_active_lead_to_A_SHARE_ticks",
            "max_letter_lead_to_A_SHARE_ticks",
            "first_basin_forming_lead_to_A_SHARE_ticks",
            "SAM_reading",
        ],
    )
    write_csv(
        STRATEGY_OUT,
        strategy_rows,
        [
            "channel",
            "control_surface",
            "SAM_quantity",
            "route_effect",
            "suppression_effect",
            "first_boundary",
            "QP013_role",
        ],
    )
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "input_surface", "target_output"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    DOC_OUT.write_text(render_doc(summary, route_rows, class_counts), encoding="utf-8")

    print(summary["result_class"])
    print(f"active_suppression_rows={summary['active_suppression_rows']}")
    print(f"passive_monitor_rows={summary['passive_monitor_rows']}")
    print(f"too_late_rows={summary['too_late_rows']}")
    print(f"max_sampled_required_suppression={summary['max_sampled_required_suppression_to_restore_A_SIDE']}")
    print(f"native_ceiling_before_A_SHARE={summary['native_theoretical_ceiling_before_A_SHARE']}")
    print(f"top_control_route={summary['top_control_route']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
