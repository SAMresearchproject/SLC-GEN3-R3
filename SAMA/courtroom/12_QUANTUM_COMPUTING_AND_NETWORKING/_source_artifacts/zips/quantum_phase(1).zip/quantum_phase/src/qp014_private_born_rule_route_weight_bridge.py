from __future__ import annotations

import csv
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
QP013_DIR = ARTIFACTS / "qp013"
QP014_DIR = ARTIFACTS / "qp014"

QP013_CONTACT_IN = QP013_DIR / "qp013_contact_suppression_table.csv"
QP013_ROUTE_IN = QP013_DIR / "qp013_route_control_window_table.csv"
QP013_SUMMARY_IN = QP013_DIR / "qp013_summary.json"

SUMMARY_OUT = QP014_DIR / "qp014_summary.json"
ROUTE_PRIOR_OUT = QP014_DIR / "qp014_route_capacity_prior_table.csv"
WEIGHT_OUT = QP014_DIR / "qp014_route_weight_table.csv"
SURFACE_OUT = QP014_DIR / "qp014_probability_surface_table.csv"
SCHEMA_OUT = QP014_DIR / "qp014_born_bridge_schema.csv"
NEXT_OUT = QP014_DIR / "qp014_next_frontier.csv"
DOC_OUT = REPORTS / "QP014_PRIVATE_BORN_RULE_ROUTE_WEIGHT_BRIDGE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fmt(value: float) -> str:
    if value == float("inf"):
        return "inf"
    return f"{value:.12g}"


def clamp01(value: float) -> float:
    return max(0.0, min(1.0, value))


def normalized(rows: list[dict[str, object]], key: str, out_key: str) -> list[dict[str, object]]:
    total = sum(float(row[key]) for row in rows)
    for row in rows:
        row[out_key] = float(row[key]) / total if total > 0.0 else 0.0
    return rows


def build_route_prior_rows(route_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in route_rows:
        max_lead = float(row["max_letter_lead_to_A_SHARE_ticks"])
        first_active_lead = float(row["first_active_lead_to_A_SHARE_ticks"])
        rows.append(
            {
                "qubit_id": row["qubit_id"],
                "route": row["route"],
                "exposure_family": row["exposure_family"],
                "max_letter_lead_to_A_SHARE_ticks": max_lead,
                "first_active_lead_to_A_SHARE_ticks": first_active_lead,
                "active_suppression_rows": row["active_suppression_rows"],
                "route_capacity_raw": max_lead,
                "route_capacity_prior": 0.0,
                "QP014_prior_rank": 0,
                "SAM_reading": "route prior is derived from pre-resolution lead capacity, not assigned by label",
            }
        )
    normalized(rows, "route_capacity_raw", "route_capacity_prior")
    rows.sort(key=lambda item: float(item["route_capacity_prior"]), reverse=True)
    for rank, row in enumerate(rows, start=1):
        row["QP014_prior_rank"] = rank
    return rows


def surface_terms(a_value: float, a_share: float) -> dict[str, float]:
    access = clamp01(a_value / a_share)
    survival = clamp01(1.0 - a_value / a_share)
    return {
        "coherence_survival": survival,
        "write_access": access,
        "unresolved_route_strength": survival,
        "write_surface_strength": survival * access,
    }


def build_weight_rows(
    contact_rows: list[dict[str, str]],
    prior_by_qubit: dict[str, dict[str, object]],
    a_side: float,
    a_share: float,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in contact_rows:
        qubit_id = row["qubit_id"]
        prior = prior_by_qubit[qubit_id]
        route_prior = float(prior["route_capacity_prior"])
        a_leak = float(row["A_leak"])
        controlled_a = float(row["A_after_required_side_suppression"])
        terms = surface_terms(a_leak, a_share)
        controlled_terms = surface_terms(controlled_a, a_share)
        valid_pre_resolution = str(row["valid_pre_resolution_letter"]).strip().lower() == "true"
        gamma_res_latent = 1.0 if valid_pre_resolution else 0.0
        gamma_res_write_surface = terms["write_access"] if valid_pre_resolution else 0.0
        gamma_res_controlled = controlled_terms["write_access"] if valid_pre_resolution else 0.0

        latent_weight = route_prior * terms["unresolved_route_strength"] * gamma_res_latent
        write_surface_weight = route_prior * terms["write_surface_strength"] * gamma_res_latent
        controlled_weight = (
            route_prior * controlled_terms["write_surface_strength"]
            if valid_pre_resolution
            else 0.0
        )

        rows.append(
            {
                "qubit_id": qubit_id,
                "sample_id": row["sample_id"],
                "route": row["route"],
                "exposure_family": row["exposure_family"],
                "N_ticks": row["N_ticks"],
                "A_leak": a_leak,
                "A_controlled": controlled_a,
                "route_capacity_prior": route_prior,
                "valid_pre_resolution_letter": valid_pre_resolution,
                "control_class": row["control_class"],
                "required_suppression_to_restore_A_SIDE": row["required_suppression_to_restore_A_SIDE"],
                "coherence_survival": terms["coherence_survival"],
                "write_access": terms["write_access"],
                "Gamma_res_latent": gamma_res_latent,
                "Gamma_res_write_surface": gamma_res_write_surface,
                "latent_route_weight": latent_weight,
                "write_surface_weight": write_surface_weight,
                "controlled_coherence_survival": controlled_terms["coherence_survival"],
                "controlled_write_access": controlled_terms["write_access"],
                "Gamma_res_controlled_surface": gamma_res_controlled,
                "controlled_route_weight": controlled_weight,
                "latent_probability": 0.0,
                "write_surface_probability": 0.0,
                "controlled_probability": 0.0,
                "SAM_reading": (
                    "Born-style weight exists before ledger write as normalized route strength"
                    if valid_pre_resolution
                    else "route has crossed out of the no-collapse probability surface"
                ),
            }
        )
    return rows


def normalize_by_sample(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    groups: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        groups[str(row["sample_id"])].append(row)

    out: list[dict[str, object]] = []
    for sample_id, sample_rows in groups.items():
        normalized(sample_rows, "latent_route_weight", "latent_probability")
        normalized(sample_rows, "write_surface_weight", "write_surface_probability")
        normalized(sample_rows, "controlled_route_weight", "controlled_probability")
        for row in sample_rows:
            out.append(row)
    out.sort(key=lambda row: (str(row["sample_id"]), -float(row["controlled_probability"])))
    return out


def build_probability_surface_rows(weight_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    by_sample: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in weight_rows:
        by_sample[str(row["sample_id"])].append(row)

    rows: list[dict[str, object]] = []
    for sample_id, sample_rows in by_sample.items():
        valid = [row for row in sample_rows if row["valid_pre_resolution_letter"] is True]
        top_latent = max(sample_rows, key=lambda row: float(row["latent_probability"]))
        top_write = max(sample_rows, key=lambda row: float(row["write_surface_probability"]))
        top_control = max(sample_rows, key=lambda row: float(row["controlled_probability"]))
        rows.append(
            {
                "sample_id": sample_id,
                "valid_probability_routes": len(valid),
                "latent_probability_sum": sum(float(row["latent_probability"]) for row in sample_rows),
                "write_surface_probability_sum": sum(float(row["write_surface_probability"]) for row in sample_rows),
                "controlled_probability_sum": sum(float(row["controlled_probability"]) for row in sample_rows),
                "top_latent_route": top_latent["qubit_id"],
                "top_latent_probability": top_latent["latent_probability"],
                "top_write_surface_route": top_write["qubit_id"],
                "top_write_surface_probability": top_write["write_surface_probability"],
                "top_controlled_route": top_control["qubit_id"],
                "top_controlled_probability": top_control["controlled_probability"],
                "SAM_reading": (
                    "normalized unresolved route probability surface"
                    if valid
                    else "no pre-resolution probability surface remains open"
                ),
            }
        )
    order = {
        "ONE_T_SW": 1,
        "QUARTER_A_SIDE": 2,
        "HALF_A_SIDE": 3,
        "A_SIDE_BOUNDARY": 4,
        "MID_A_SIDE_TO_A_SHARE": 5,
        "A_SHARE_BOUNDARY": 6,
        "WRITE_MIDPOINT": 7,
    }
    rows.sort(key=lambda row: order.get(str(row["sample_id"]), 999))
    return rows


def schema_rows() -> list[dict[str, object]]:
    return [
        {
            "quantity": "route_capacity_prior",
            "definition": "max_letter_lead_to_A_SHARE_i / sum(max_letter_lead_to_A_SHARE_all)",
            "role": "native route capacity before resolution",
        },
        {
            "quantity": "coherence_survival",
            "definition": "1 - A_leak/A_SHARE",
            "role": "unresolved route still available before ledger write",
        },
        {
            "quantity": "write_access",
            "definition": "A_leak/A_SHARE",
            "role": "how close the route is to write accessibility",
        },
        {
            "quantity": "latent_route_weight",
            "definition": "route_capacity_prior * coherence_survival * Gamma_res_latent",
            "role": "probability surface before write access dominates",
        },
        {
            "quantity": "write_surface_weight",
            "definition": "route_capacity_prior * coherence_survival * write_access * Gamma_res_latent",
            "role": "Born-style route weight on the write-access surface",
        },
        {
            "quantity": "P_i",
            "definition": "weight_i / sum(weight_all)",
            "role": "normalized route probability",
        },
        {
            "quantity": "controlled_route_weight",
            "definition": "same weight law after QP013 A-contact suppression",
            "role": "probability surface after pre-resolution contact control",
        },
    ]


def render_doc(
    summary: dict[str, object],
    prior_rows: list[dict[str, object]],
    surface_rows: list[dict[str, object]],
) -> str:
    prior_lines = "\n".join(
        "| {rank} | {qubit} | {family} | {prior} | {lead} |".format(
            rank=row["QP014_prior_rank"],
            qubit=row["qubit_id"],
            family=row["exposure_family"],
            prior=fmt(float(row["route_capacity_prior"])),
            lead=fmt(float(row["max_letter_lead_to_A_SHARE_ticks"])),
        )
        for row in prior_rows[:7]
    )
    surface_lines = "\n".join(
        "| {sample} | {routes} | {top} | {p} | {psum} |".format(
            sample=row["sample_id"],
            routes=row["valid_probability_routes"],
            top=row["top_controlled_route"],
            p=fmt(float(row["top_controlled_probability"])),
            psum=fmt(float(row["controlled_probability_sum"])),
        )
        for row in surface_rows
    )
    return f"""# QP014 - Private Born Rule Route-Weight Bridge

## Verdict

`{summary['result_class']}`

QP014 builds the first private SAM Born-style route bridge:

```text
latent_weight_i = route_capacity_prior_i * coherence_survival_i
write_weight_i = latent_weight_i * write_access_i
P_i = weight_i / sum(weight_all)
```

The probability surface exists before the final ledger outcome. Resolution does
not create the route weights; it selects which weighted surface becomes
ledger-visible.

## Main Read

```text
route priors = {summary['route_prior_rows']}
route weight rows = {summary['route_weight_rows']}
probability surfaces = {summary['probability_surface_rows']}
normalization failures = {summary['normalization_failures']}
free parameters introduced = {summary['free_parameters_introduced']}
top route prior = {summary['top_route_prior_qubit']} at {summary['top_route_prior_value']}
```

## Route-Capacity Priors

| Rank | Qubit | Exposure Family | route capacity prior | max letter lead |
| ---: | --- | --- | ---: | ---: |
{prior_lines}

## Probability Surfaces

| Sample | open routes | top controlled route | top controlled P | P sum |
| --- | ---: | --- | ---: | ---: |
{surface_lines}

## Meaning

The SAM reading is compact:

```text
probability = normalized unresolved route strength
```

There are three useful surfaces:

```text
latent surface     = which routes remain coherently available
write surface      = which available routes are close to write access
controlled surface = the write surface after QP013 A-contact suppression
```

The QP013 contact letter changes the probability surface by preserving route
coherence before the logical route identity is written.

## Outputs

```text
qp014_route_capacity_prior_table.csv
qp014_route_weight_table.csv
qp014_probability_surface_table.csv
qp014_born_bridge_schema.csv
qp014_summary.json
qp014_next_frontier.csv
```

## Next Frontier

`QP015_PRIVATE_INTERFERENCE_TO_LEDGER_COMMIT_BRIDGE`

QP015 should use QP014's route weights with QP003's interference/bounce table
to ask how two unresolved weighted routes become one committed ledger
intersection.

Generated at UTC: `{summary['generated_at_utc']}`
"""


def main() -> int:
    qp013_summary = json.loads(QP013_SUMMARY_IN.read_text(encoding="utf-8"))
    thresholds = qp013_summary["thresholds"]
    a_side = float(thresholds["A_SIDE"])
    a_share = float(thresholds["A_SHARE"])

    contact_rows = read_csv(QP013_CONTACT_IN)
    route_rows = read_csv(QP013_ROUTE_IN)
    prior_rows = build_route_prior_rows(route_rows)
    prior_by_qubit = {str(row["qubit_id"]): row for row in prior_rows}
    weight_rows = build_weight_rows(contact_rows, prior_by_qubit, a_side, a_share)
    weight_rows = normalize_by_sample(weight_rows)
    surface_rows = build_probability_surface_rows(weight_rows)
    schema = schema_rows()
    next_rows = [
        {
            "next_frontier": "QP015_PRIVATE_INTERFERENCE_TO_LEDGER_COMMIT_BRIDGE",
            "why_next": "QP014 gives normalized unresolved route weights; QP015 should connect weighted routes to interference/bounce and final ledger commitment.",
            "input_surface": "qp014_route_weight_table.csv plus qp003_interference_bounce_coupling_table.csv",
            "target_output": "weighted interference to committed ledger intersection bridge",
        }
    ]

    normalization_failures = 0
    for row in surface_rows:
        if int(row["valid_probability_routes"]) > 0:
            for key in [
                "latent_probability_sum",
                "write_surface_probability_sum",
                "controlled_probability_sum",
            ]:
                if abs(float(row[key]) - 1.0) > 1e-9:
                    normalization_failures += 1

    top_prior = prior_rows[0]
    summary = {
        "artifact": "QP014_PRIVATE_BORN_RULE_ROUTE_WEIGHT_BRIDGE",
        "result_class": "QP014_PRIVATE_BORN_RULE_ROUTE_WEIGHT_BRIDGE_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "thresholds": thresholds,
        "law": "latent_weight_i = route_capacity_prior_i * coherence_survival_i; write_weight_i = latent_weight_i * write_access_i; P_i = weight_i / sum(weight_all)",
        "route_prior_rows": len(prior_rows),
        "route_weight_rows": len(weight_rows),
        "probability_surface_rows": len(surface_rows),
        "schema_rows": len(schema),
        "normalization_failures": normalization_failures,
        "top_route_prior_qubit": top_prior["qubit_id"],
        "top_route_prior_value": top_prior["route_capacity_prior"],
        "top_route_prior_family": top_prior["exposure_family"],
        "core_interpretation": "Born-style probability is normalized unresolved route strength before ledger resolution",
        "next_frontier": "QP015_PRIVATE_INTERFERENCE_TO_LEDGER_COMMIT_BRIDGE",
    }

    write_csv(
        ROUTE_PRIOR_OUT,
        prior_rows,
        [
            "QP014_prior_rank",
            "qubit_id",
            "route",
            "exposure_family",
            "max_letter_lead_to_A_SHARE_ticks",
            "first_active_lead_to_A_SHARE_ticks",
            "active_suppression_rows",
            "route_capacity_raw",
            "route_capacity_prior",
            "SAM_reading",
        ],
    )
    write_csv(
        WEIGHT_OUT,
        weight_rows,
        [
            "qubit_id",
            "sample_id",
            "route",
            "exposure_family",
            "N_ticks",
            "A_leak",
            "A_controlled",
            "route_capacity_prior",
            "valid_pre_resolution_letter",
            "control_class",
            "required_suppression_to_restore_A_SIDE",
            "coherence_survival",
            "write_access",
            "Gamma_res_latent",
            "Gamma_res_write_surface",
            "latent_route_weight",
            "write_surface_weight",
            "controlled_coherence_survival",
            "controlled_write_access",
            "Gamma_res_controlled_surface",
            "controlled_route_weight",
            "latent_probability",
            "write_surface_probability",
            "controlled_probability",
            "SAM_reading",
        ],
    )
    write_csv(
        SURFACE_OUT,
        surface_rows,
        [
            "sample_id",
            "valid_probability_routes",
            "latent_probability_sum",
            "write_surface_probability_sum",
            "controlled_probability_sum",
            "top_latent_route",
            "top_latent_probability",
            "top_write_surface_route",
            "top_write_surface_probability",
            "top_controlled_route",
            "top_controlled_probability",
            "SAM_reading",
        ],
    )
    write_csv(SCHEMA_OUT, schema, ["quantity", "definition", "role"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "input_surface", "target_output"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    DOC_OUT.write_text(render_doc(summary, prior_rows, surface_rows), encoding="utf-8")

    print(summary["result_class"])
    print(f"route_prior_rows={summary['route_prior_rows']}")
    print(f"route_weight_rows={summary['route_weight_rows']}")
    print(f"probability_surface_rows={summary['probability_surface_rows']}")
    print(f"normalization_failures={summary['normalization_failures']}")
    print(f"top_route_prior={summary['top_route_prior_qubit']}:{summary['top_route_prior_value']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
