from __future__ import annotations

import csv
import json
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
QP003_DIR = ARTIFACTS / "qp003"
QP014_DIR = ARTIFACTS / "qp014"
QP015_DIR = ARTIFACTS / "qp015"
EPS = 1e-15

QP003_COUPLING_IN = QP003_DIR / "qp003_interference_bounce_coupling_table.csv"
QP003_SUMMARY_IN = QP003_DIR / "qp003_interference_bounce_summary.json"
QP014_WEIGHT_IN = QP014_DIR / "qp014_route_weight_table.csv"
QP014_SURFACE_IN = QP014_DIR / "qp014_probability_surface_table.csv"
QP014_SUMMARY_IN = QP014_DIR / "qp014_summary.json"

SUMMARY_OUT = QP015_DIR / "qp015_summary.json"
PAIR_BRIDGE_OUT = QP015_DIR / "qp015_interference_commit_bridge_table.csv"
SAMPLE_SUMMARY_OUT = QP015_DIR / "qp015_sample_commit_summary.csv"
SCHEMA_OUT = QP015_DIR / "qp015_commit_bridge_schema.csv"
NEXT_OUT = QP015_DIR / "qp015_next_frontier.csv"
DOC_OUT = REPORTS / "QP015_PRIVATE_INTERFERENCE_TO_LEDGER_COMMIT_BRIDGE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fmt(value: float) -> str:
    return f"{value:.12g}"


def pair_factor(route_i: str, route_j: str) -> float:
    return 1.0 if route_i == route_j else 2.0


def pair_key(route_i: str, route_j: str) -> str:
    return f"{route_i}<->{route_j}"


def load_route_probabilities(weight_rows: list[dict[str, str]]) -> dict[str, dict[str, dict[str, float]]]:
    by_sample: dict[str, dict[str, dict[str, float]]] = defaultdict(dict)
    for row in weight_rows:
        by_sample[row["sample_id"]][row["qubit_id"]] = {
            "latent_probability": float(row["latent_probability"]),
            "write_surface_probability": float(row["write_surface_probability"]),
            "controlled_probability": float(row["controlled_probability"]),
            "route_capacity_prior": float(row["route_capacity_prior"]),
            "coherence_survival": float(row["coherence_survival"]),
            "write_access": float(row["write_access"]),
        }
    return by_sample


def build_bridge_rows(
    coupling_rows: list[dict[str, str]],
    route_prob_by_sample: dict[str, dict[str, dict[str, float]]],
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for qp014_sample, route_probs in route_prob_by_sample.items():
        for coupling in coupling_rows:
            route_i = coupling["route_i"]
            route_j = coupling["route_j"]
            probs_i = route_probs[route_i]
            probs_j = route_probs[route_j]
            factor = pair_factor(route_i, route_j)
            latent_pair_probability = (
                factor * probs_i["latent_probability"] * probs_j["latent_probability"]
            )
            write_pair_probability = (
                factor
                * probs_i["write_surface_probability"]
                * probs_j["write_surface_probability"]
            )
            controlled_pair_probability = (
                factor
                * probs_i["controlled_probability"]
                * probs_j["controlled_probability"]
            )
            interference_kernel = float(coupling["interference_strength"])
            bounce_kernel = float(coupling["bounce_response_strength"])
            ledger_kernel = float(coupling["ledger_intersection_strength"])
            total_support_kernel = float(coupling["total_support_strength"])

            interference_weight = latent_pair_probability * interference_kernel
            bounce_weight = controlled_pair_probability * bounce_kernel
            commit_weight = controlled_pair_probability * bounce_kernel * ledger_kernel
            support_weight = controlled_pair_probability * total_support_kernel

            rows.append(
                {
                    "qp014_sample_id": qp014_sample,
                    "qp003_kernel_sample_id": coupling["sample_id"],
                    "route_i": route_i,
                    "route_j": route_j,
                    "route_pair": pair_key(route_i, route_j),
                    "pair_factor": factor,
                    "state_i": coupling["state_i"],
                    "state_j": coupling["state_j"],
                    "coupling_status": coupling["coupling_status"],
                    "interference_kernel": interference_kernel,
                    "bounce_kernel": bounce_kernel,
                    "ledger_kernel": ledger_kernel,
                    "total_support_kernel": total_support_kernel,
                    "latent_pair_probability": latent_pair_probability,
                    "write_pair_probability": write_pair_probability,
                    "controlled_pair_probability": controlled_pair_probability,
                    "interference_bridge_weight": interference_weight,
                    "bounce_bridge_weight": bounce_weight,
                    "commit_bridge_weight": commit_weight,
                    "support_bridge_weight": support_weight,
                    "interference_bridge_probability": 0.0,
                    "bounce_bridge_probability": 0.0,
                    "commit_bridge_probability": 0.0,
                    "support_bridge_probability": 0.0,
                    "SAM_reading": (
                        "weighted unresolved routes become a ledger-intersection candidate"
                        if commit_weight > 0.0
                        else "weighted unresolved routes remain interference/support before commit"
                    ),
                }
            )
    return rows


def normalize_bridge_rows(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    groups: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        groups[(str(row["qp014_sample_id"]), str(row["qp003_kernel_sample_id"]))].append(row)

    for group_rows in groups.values():
        for weight_key, probability_key in [
            ("interference_bridge_weight", "interference_bridge_probability"),
            ("bounce_bridge_weight", "bounce_bridge_probability"),
            ("commit_bridge_weight", "commit_bridge_probability"),
            ("support_bridge_weight", "support_bridge_probability"),
        ]:
            total = sum(float(row[weight_key]) for row in group_rows)
            for row in group_rows:
                row[probability_key] = float(row[weight_key]) / total if total > EPS else 0.0
    rows.sort(
        key=lambda row: (
            str(row["qp014_sample_id"]),
            str(row["qp003_kernel_sample_id"]),
            -float(row["commit_bridge_probability"]),
            -float(row["interference_bridge_probability"]),
        )
    )
    return rows


def build_sample_summary(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    groups: dict[tuple[str, str], list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        groups[(str(row["qp014_sample_id"]), str(row["qp003_kernel_sample_id"]))].append(row)

    out: list[dict[str, object]] = []
    for (qp014_sample, kernel_sample), group_rows in groups.items():
        top_interference = max(group_rows, key=lambda row: float(row["interference_bridge_probability"]))
        top_bounce = max(group_rows, key=lambda row: float(row["bounce_bridge_probability"]))
        top_commit = max(group_rows, key=lambda row: float(row["commit_bridge_probability"]))
        interference_sum = sum(float(row["interference_bridge_probability"]) for row in group_rows)
        bounce_sum = sum(float(row["bounce_bridge_probability"]) for row in group_rows)
        commit_sum = sum(float(row["commit_bridge_probability"]) for row in group_rows)
        support_sum = sum(float(row["support_bridge_probability"]) for row in group_rows)
        out.append(
            {
                "qp014_sample_id": qp014_sample,
                "qp003_kernel_sample_id": kernel_sample,
                "pair_rows": len(group_rows),
                "interference_probability_sum": interference_sum,
                "bounce_probability_sum": bounce_sum,
                "commit_probability_sum": commit_sum,
                "support_probability_sum": support_sum,
                "top_interference_pair": top_interference["route_pair"],
                "top_interference_probability": top_interference["interference_bridge_probability"],
                "top_bounce_pair": top_bounce["route_pair"],
                "top_bounce_probability": top_bounce["bounce_bridge_probability"],
                "top_commit_pair": top_commit["route_pair"],
                "top_commit_probability": top_commit["commit_bridge_probability"],
                "SAM_reading": (
                    "ledger commit surface is open"
                    if commit_sum > 0.0
                    else "interference/support surface without ledger commit"
                ),
            }
        )
    order = {
        "ONE_T_SW": 1,
        "QUARTER_A_SIDE": 2,
        "HALF_A_SIDE": 3,
        "A_SIDE_BOUNDARY": 4,
        "MID_A_SIDE_TO_A_SHARE": 5,
        "A_SHARE_BOUNDARY": 6,
        "WRITE_MIDPOINT": 7,
    }
    out.sort(key=lambda row: (order.get(str(row["qp014_sample_id"]), 999), str(row["qp003_kernel_sample_id"])))
    return out


def normalization_failures(sample_rows: list[dict[str, object]]) -> int:
    failures = 0
    for row in sample_rows:
        for key in [
            "interference_probability_sum",
            "bounce_probability_sum",
            "commit_probability_sum",
            "support_probability_sum",
        ]:
            value = float(row[key])
            if value != 0.0 and abs(value - 1.0) > 1e-9:
                failures += 1
    return failures


def schema_rows() -> list[dict[str, object]]:
    return [
        {
            "quantity": "pair_probability",
            "definition": "P_ij = P_i^2 for self-pair; P_ij = 2*P_i*P_j for mixed pair",
            "role": "unordered pair probability from QP014 route weights",
        },
        {
            "quantity": "interference_bridge_weight",
            "definition": "latent_pair_probability * QP003 interference_kernel",
            "role": "unresolved pair support before ledger commit",
        },
        {
            "quantity": "bounce_bridge_weight",
            "definition": "controlled_pair_probability * QP003 bounce_kernel",
            "role": "response channel available at write/commit",
        },
        {
            "quantity": "commit_bridge_weight",
            "definition": "controlled_pair_probability * bounce_kernel * ledger_kernel",
            "role": "weighted candidate for committed ledger intersection",
        },
        {
            "quantity": "commit_bridge_probability",
            "definition": "commit_bridge_weight / sum(commit_bridge_weight_all_pairs)",
            "role": "normalized ledger-intersection probability",
        },
    ]


def render_doc(
    summary: dict[str, object],
    sample_rows: list[dict[str, object]],
    bridge_rows: list[dict[str, object]],
) -> str:
    commit_rows = [
        row
        for row in sample_rows
        if row["qp014_sample_id"] in {"A_SIDE_BOUNDARY", "MID_A_SIDE_TO_A_SHARE"}
        and row["qp003_kernel_sample_id"] == "N_A_SHARE"
    ]
    commit_lines = "\n".join(
        "| {sample} | {pair} | {prob} | {sumv} |".format(
            sample=row["qp014_sample_id"],
            pair=row["top_commit_pair"],
            prob=fmt(float(row["top_commit_probability"])),
            sumv=fmt(float(row["commit_probability_sum"])),
        )
        for row in commit_rows
    )
    top_rows = sorted(
        [
            row
            for row in bridge_rows
            if row["qp014_sample_id"] == "MID_A_SIDE_TO_A_SHARE"
            and row["qp003_kernel_sample_id"] == "N_A_SHARE"
        ],
        key=lambda row: float(row["commit_bridge_probability"]),
        reverse=True,
    )[:7]
    top_lines = "\n".join(
        "| {sample} | {pair} | {prob} | {weight} |".format(
            sample=row["qp014_sample_id"],
            pair=row["route_pair"],
            prob=fmt(float(row["commit_bridge_probability"])),
            weight=fmt(float(row["commit_bridge_weight"])),
        )
        for row in top_rows
    )
    return f"""# QP015 - Private Interference To Ledger Commit Bridge

## Verdict

`{summary['result_class']}`

QP015 connects QP014 route probabilities to QP003 interference/bounce kernels:

```text
P_ij = P_i^2              for self-pairs
P_ij = 2 * P_i * P_j      for mixed pairs
commit_weight_ij = P_ij * bounce_kernel_ij * ledger_kernel_ij
P_commit_ij = commit_weight_ij / sum(commit_weight_all_pairs)
```

## Main Read

```text
bridge rows = {summary['bridge_rows']}
sample summary rows = {summary['sample_summary_rows']}
normalization failures = {summary['normalization_failures']}
top latest-open commit pair = {summary['top_latest_open_commit_pair']}
top latest-open commit probability = {summary['top_latest_open_commit_probability']}
free parameters introduced = {summary['free_parameters_introduced']}
```

## Commit Surface

| QP014 sample | top commit pair through N_A_SHARE | top commit P | P sum |
| --- | --- | ---: | ---: |
{commit_lines}

## Latest Open N_A_SHARE Commit Rows

| QP014 sample | pair | commit P | commit weight |
| --- | --- | ---: | ---: |
{top_lines}

## Meaning

QP014 supplied the unresolved route probability surface. QP003 supplied the
interference, bounce, and ledger kernels. QP015 shows how those combine into a
ledger-intersection probability:

```text
unresolved probability
-> pair probability
-> bounce response
-> committed ledger intersection candidate
```

The probability surface exists before commit. The bounce/ledger kernel decides
when that surface can become a written intersection.

## Outputs

```text
qp015_interference_commit_bridge_table.csv
qp015_sample_commit_summary.csv
qp015_commit_bridge_schema.csv
qp015_summary.json
qp015_next_frontier.csv
```

## Next Frontier

`QP016_PRIVATE_LEDGER_COMMIT_TO_STABLE_MODE_SELECTOR`

QP016 should ask which committed intersections become stable matter-like modes
rather than transient writes.

Generated at UTC: `{summary['generated_at_utc']}`
"""


def main() -> int:
    QP015_DIR.mkdir(parents=True, exist_ok=True)
    qp003_summary = json.loads(QP003_SUMMARY_IN.read_text(encoding="utf-8"))
    qp014_summary = json.loads(QP014_SUMMARY_IN.read_text(encoding="utf-8"))
    coupling_rows = read_csv(QP003_COUPLING_IN)
    weight_rows = read_csv(QP014_WEIGHT_IN)
    surface_rows_in = read_csv(QP014_SURFACE_IN)
    route_prob_by_sample = load_route_probabilities(weight_rows)

    bridge_rows = normalize_bridge_rows(build_bridge_rows(coupling_rows, route_prob_by_sample))
    sample_rows = build_sample_summary(bridge_rows)
    schema = schema_rows()
    next_rows = [
        {
            "next_frontier": "QP016_PRIVATE_LEDGER_COMMIT_TO_STABLE_MODE_SELECTOR",
            "why_next": "QP015 bridges weighted unresolved routes to committed ledger intersections; QP016 should identify which committed intersections remain stable modes.",
            "input_surface": "qp015_interference_commit_bridge_table.csv",
            "target_output": "stable mode selector for committed intersections",
        }
    ]

    latest_open_commit_rows = [
        row
        for row in sample_rows
        if row["qp014_sample_id"] == "MID_A_SIDE_TO_A_SHARE"
        and row["qp003_kernel_sample_id"] == "N_A_SHARE"
    ]
    latest_open = latest_open_commit_rows[0]
    summary = {
        "artifact": "QP015_PRIVATE_INTERFERENCE_TO_LEDGER_COMMIT_BRIDGE",
        "result_class": "QP015_PRIVATE_INTERFERENCE_TO_LEDGER_COMMIT_BRIDGE_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "inputs": {
            "qp003": qp003_summary["artifact"],
            "qp014": qp014_summary["artifact"],
        },
        "law": "P_ij = P_i^2 for self-pairs, P_ij = 2*P_i*P_j for mixed pairs; commit_weight_ij = P_ij*bounce_kernel_ij*ledger_kernel_ij",
        "qp014_probability_surfaces": len(surface_rows_in),
        "bridge_rows": len(bridge_rows),
        "sample_summary_rows": len(sample_rows),
        "schema_rows": len(schema),
        "normalization_failures": normalization_failures(sample_rows),
        "top_latest_open_commit_pair": latest_open["top_commit_pair"],
        "top_latest_open_commit_probability": latest_open["top_commit_probability"],
        "top_latest_open_commit_kernel": latest_open["qp003_kernel_sample_id"],
        "core_interpretation": "unresolved route probability becomes ledger-intersection probability when the bounce/write kernel opens",
        "next_frontier": "QP016_PRIVATE_LEDGER_COMMIT_TO_STABLE_MODE_SELECTOR",
    }

    write_csv(
        PAIR_BRIDGE_OUT,
        bridge_rows,
        [
            "qp014_sample_id",
            "qp003_kernel_sample_id",
            "route_i",
            "route_j",
            "route_pair",
            "pair_factor",
            "state_i",
            "state_j",
            "coupling_status",
            "interference_kernel",
            "bounce_kernel",
            "ledger_kernel",
            "total_support_kernel",
            "latent_pair_probability",
            "write_pair_probability",
            "controlled_pair_probability",
            "interference_bridge_weight",
            "bounce_bridge_weight",
            "commit_bridge_weight",
            "support_bridge_weight",
            "interference_bridge_probability",
            "bounce_bridge_probability",
            "commit_bridge_probability",
            "support_bridge_probability",
            "SAM_reading",
        ],
    )
    write_csv(
        SAMPLE_SUMMARY_OUT,
        sample_rows,
        [
            "qp014_sample_id",
            "qp003_kernel_sample_id",
            "pair_rows",
            "interference_probability_sum",
            "bounce_probability_sum",
            "commit_probability_sum",
            "support_probability_sum",
            "top_interference_pair",
            "top_interference_probability",
            "top_bounce_pair",
            "top_bounce_probability",
            "top_commit_pair",
            "top_commit_probability",
            "SAM_reading",
        ],
    )
    write_csv(SCHEMA_OUT, schema, ["quantity", "definition", "role"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "input_surface", "target_output"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    DOC_OUT.write_text(render_doc(summary, sample_rows, bridge_rows), encoding="utf-8")

    print(summary["result_class"])
    print(f"bridge_rows={summary['bridge_rows']}")
    print(f"sample_summary_rows={summary['sample_summary_rows']}")
    print(f"normalization_failures={summary['normalization_failures']}")
    print(f"top_latest_open_commit_pair={summary['top_latest_open_commit_pair']}")
    print(f"top_latest_open_commit_probability={summary['top_latest_open_commit_probability']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
