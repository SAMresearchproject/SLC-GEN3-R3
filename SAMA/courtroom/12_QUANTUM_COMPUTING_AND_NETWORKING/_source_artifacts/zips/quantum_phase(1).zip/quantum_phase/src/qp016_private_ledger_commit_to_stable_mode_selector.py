from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
QP014_DIR = ARTIFACTS / "qp014"
QP015_DIR = ARTIFACTS / "qp015"
QP016_DIR = ARTIFACTS / "qp016"

QP014_SUMMARY_IN = QP014_DIR / "qp014_summary.json"
QP015_BRIDGE_IN = QP015_DIR / "qp015_interference_commit_bridge_table.csv"
QP015_SUMMARY_IN = QP015_DIR / "qp015_summary.json"

SUMMARY_OUT = QP016_DIR / "qp016_summary.json"
SELECTOR_OUT = QP016_DIR / "qp016_stable_mode_selector_table.csv"
FAMILY_OUT = QP016_DIR / "qp016_mode_family_summary.csv"
SCHEMA_OUT = QP016_DIR / "qp016_stability_selector_schema.csv"
NEXT_OUT = QP016_DIR / "qp016_next_frontier.csv"
DOC_OUT = REPORTS / "QP016_PRIVATE_LEDGER_COMMIT_TO_STABLE_MODE_SELECTOR.md"

STRUCTURED_OPEN_SAMPLES = [
    "QUARTER_A_SIDE",
    "HALF_A_SIDE",
    "A_SIDE_BOUNDARY",
    "MID_A_SIDE_TO_A_SHARE",
]
COMMIT_KERNEL_SAMPLES = [
    "N_A_SHARE",
    "N_A_D_BLOCK",
    "N_A_ALPHA_H_SQ",
    "N_WRITE_MIDPOINT",
]
LATEST_OPEN_SAMPLE = "MID_A_SIDE_TO_A_SHARE"
FIRST_COMMIT_KERNEL = "N_A_SHARE"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fmt(value: float) -> str:
    return f"{value:.12g}"


def split_pair(route_pair: str) -> tuple[str, str]:
    left, right = route_pair.split("<->", 1)
    return left, right


def classify_pair(
    route_pair: str,
    latest_commit_probability: float,
    native_persistence_fraction: float,
    a_side: float,
    a_share: float,
) -> str:
    left, right = split_pair(route_pair)
    self_closure = left == right
    persistent = native_persistence_fraction >= 1.0
    if self_closure and latest_commit_probability >= a_share and persistent:
        return "STABLE_SELF_CLOSURE_MODE_SELECTED"
    if latest_commit_probability >= a_side and persistent:
        return "BOUNDARY_REORGANIZATION_CANDIDATE"
    if latest_commit_probability > 0.0:
        return "TRANSIENT_COMMIT_TAIL"
    return "NO_OPEN_COMMIT_SURFACE"


def build_selector_rows(
    bridge_rows: list[dict[str, str]],
    a_side: float,
    a_share: float,
) -> list[dict[str, object]]:
    pairs = sorted({row["route_pair"] for row in bridge_rows})
    rows: list[dict[str, object]] = []
    expected_native_persistence = len(STRUCTURED_OPEN_SAMPLES) * len(COMMIT_KERNEL_SAMPLES)
    for route_pair in pairs:
        left, right = split_pair(route_pair)
        pair_rows = [row for row in bridge_rows if row["route_pair"] == route_pair]
        latest_rows = [
            row
            for row in pair_rows
            if row["qp014_sample_id"] == LATEST_OPEN_SAMPLE
            and row["qp003_kernel_sample_id"] == FIRST_COMMIT_KERNEL
        ]
        latest = latest_rows[0]
        latest_commit_probability = float(latest["commit_bridge_probability"])
        structured_commit_rows = [
            row
            for row in pair_rows
            if row["qp014_sample_id"] in STRUCTURED_OPEN_SAMPLES
            and row["qp003_kernel_sample_id"] in COMMIT_KERNEL_SAMPLES
        ]
        native_persistent_rows = [
            row
            for row in structured_commit_rows
            if float(row["commit_bridge_probability"]) >= a_side
        ]
        selected_persistent_rows = [
            row
            for row in structured_commit_rows
            if float(row["commit_bridge_probability"]) >= a_share
        ]
        self_closure = left == right
        pair_structure = "SELF_CLOSURE" if self_closure else "MIXED_ROUTE_INTERSECTION"
        native_persistence_fraction = (
            len(native_persistent_rows) / expected_native_persistence
            if expected_native_persistence
            else 0.0
        )
        selected_persistence_fraction = (
            len(selected_persistent_rows) / expected_native_persistence
            if expected_native_persistence
            else 0.0
        )
        selector_class = classify_pair(
            route_pair,
            latest_commit_probability,
            native_persistence_fraction,
            a_side,
            a_share,
        )
        stability_index = (
            latest_commit_probability
            * native_persistence_fraction
            * (1.0 if self_closure else 0.5)
        )
        rows.append(
            {
                "route_pair": route_pair,
                "route_i": left,
                "route_j": right,
                "pair_structure": pair_structure,
                "latest_open_sample": LATEST_OPEN_SAMPLE,
                "first_commit_kernel": FIRST_COMMIT_KERNEL,
                "latest_commit_probability": latest_commit_probability,
                "latest_commit_weight": latest["commit_bridge_weight"],
                "native_boundary_threshold_A_SIDE": a_side,
                "stable_threshold_A_SHARE": a_share,
                "structured_commit_rows": len(structured_commit_rows),
                "native_persistent_rows_at_or_above_A_SIDE": len(native_persistent_rows),
                "selected_persistent_rows_at_or_above_A_SHARE": len(selected_persistent_rows),
                "native_persistence_fraction": native_persistence_fraction,
                "selected_persistence_fraction": selected_persistence_fraction,
                "self_closure": self_closure,
                "stability_index": stability_index,
                "selector_class": selector_class,
                "QP016_rank": 0,
                "SAM_reading": (
                    "stable matter-like closure selected"
                    if selector_class == "STABLE_SELF_CLOSURE_MODE_SELECTED"
                    else "committed intersection is candidate or transient, not selected stable closure"
                ),
            }
        )
    rows.sort(key=lambda row: float(row["stability_index"]), reverse=True)
    for rank, row in enumerate(rows, start=1):
        row["QP016_rank"] = rank
    return rows


def build_family_rows(selector_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    counts = Counter(str(row["selector_class"]) for row in selector_rows)
    structure_counts = Counter(str(row["pair_structure"]) for row in selector_rows)
    rows: list[dict[str, object]] = []
    for name, count in sorted(counts.items()):
        rows.append(
            {
                "summary_type": "selector_class",
                "name": name,
                "count": count,
                "SAM_reading": "classification count across committed route pairs",
            }
        )
    for name, count in sorted(structure_counts.items()):
        rows.append(
            {
                "summary_type": "pair_structure",
                "name": name,
                "count": count,
                "SAM_reading": "pair-structure count across committed route pairs",
            }
        )
    return rows


def schema_rows() -> list[dict[str, object]]:
    return [
        {
            "quantity": "latest_commit_probability",
            "definition": "QP015 commit_bridge_probability at MID_A_SIDE_TO_A_SHARE through N_A_SHARE",
            "role": "latest open committed-intersection strength",
        },
        {
            "quantity": "native_persistence_fraction",
            "definition": "fraction of structured open commit rows with P_commit >= A_SIDE",
            "role": "persistence above native boundary-candidate strength",
        },
        {
            "quantity": "selected_persistence_fraction",
            "definition": "fraction of structured open commit rows with P_commit >= A_SHARE",
            "role": "persistence above stable selected-mode strength",
        },
        {
            "quantity": "STABLE_SELF_CLOSURE_MODE_SELECTED",
            "definition": "self-pair, latest P_commit >= A_SHARE, native_persistence_fraction = 1",
            "role": "stable matter-like closure selector",
        },
        {
            "quantity": "BOUNDARY_REORGANIZATION_CANDIDATE",
            "definition": "latest P_commit >= A_SIDE with persistence, but not self-closure selected",
            "role": "asymmetric or mixed transition route",
        },
        {
            "quantity": "TRANSIENT_COMMIT_TAIL",
            "definition": "latest P_commit below A_SIDE",
            "role": "committed but not stable enough to retain mode identity",
        },
    ]


def render_doc(summary: dict[str, object], selector_rows: list[dict[str, object]]) -> str:
    top_lines = "\n".join(
        "| {rank} | {pair} | {cls} | {prob} | {persist} | {idx} |".format(
            rank=row["QP016_rank"],
            pair=row["route_pair"],
            cls=row["selector_class"],
            prob=fmt(float(row["latest_commit_probability"])),
            persist=fmt(float(row["native_persistence_fraction"])),
            idx=fmt(float(row["stability_index"])),
        )
        for row in selector_rows[:10]
    )
    selected = [
        row
        for row in selector_rows
        if row["selector_class"] == "STABLE_SELF_CLOSURE_MODE_SELECTED"
    ]
    candidates = [
        row
        for row in selector_rows
        if row["selector_class"] == "BOUNDARY_REORGANIZATION_CANDIDATE"
    ]
    selected_block = "\n".join(
        f"{row['route_pair']}  P_commit={fmt(float(row['latest_commit_probability']))}"
        for row in selected
    ) or "none"
    candidate_block = "\n".join(
        f"{row['route_pair']}  P_commit={fmt(float(row['latest_commit_probability']))}"
        for row in candidates
    ) or "none"
    return f"""# QP016 - Private Ledger Commit To Stable Mode Selector

## Verdict

`{summary['result_class']}`

QP016 asks which committed ledger intersections survive as stable modes.

Selector law:

```text
stable selected mode:
  self-pair
  latest P_commit >= A_SHARE
  persistence across structured commit rows >= A_SIDE

boundary reorganization candidate:
  latest P_commit >= A_SIDE
  persistence across structured commit rows >= A_SIDE
  but not selected self-closure

transient commit tail:
  latest P_commit < A_SIDE
```

No new thresholds are introduced:

```text
A_SIDE = {summary['thresholds']['A_SIDE']}
A_SHARE = {summary['thresholds']['A_SHARE']}
```

## Main Read

```text
route pairs = {summary['route_pairs']}
stable selected modes = {summary['stable_selected_modes']}
boundary reorganization candidates = {summary['boundary_reorganization_candidates']}
transient commit tails = {summary['transient_commit_tails']}
top stable mode = {summary['top_stable_mode_pair']}
top stable mode probability = {summary['top_stable_mode_probability']}
free parameters introduced = {summary['free_parameters_introduced']}
```

## Selected Stable Mode

```text
{selected_block}
```

## Boundary Reorganization Candidates

```text
{candidate_block}
```

## Top Selector Rows

| Rank | Pair | Selector Class | latest P_commit | native persistence | stability index |
| ---: | --- | --- | ---: | ---: | ---: |
{top_lines}

## Meaning

QP015 said a ledger intersection can be committed. QP016 adds the next filter:

```text
commit is not enough
stable mode requires self-closure plus native-strength persistence
```

That produces a clean split:

```text
stable closure mode
boundary/asymmetric reorganization candidate
transient commit tail
```

## Outputs

```text
qp016_stable_mode_selector_table.csv
qp016_mode_family_summary.csv
qp016_stability_selector_schema.csv
qp016_summary.json
qp016_next_frontier.csv
```

## Next Frontier

`QP017_PRIVATE_STABLE_MODE_TO_ROLE_OPERATOR_BRIDGE`

QP017 should connect selected stable modes and boundary reorganization
candidates back to the phase role/operator lane.

Generated at UTC: `{summary['generated_at_utc']}`
"""


def main() -> int:
    QP016_DIR.mkdir(parents=True, exist_ok=True)
    qp014_summary = json.loads(QP014_SUMMARY_IN.read_text(encoding="utf-8"))
    qp015_summary = json.loads(QP015_SUMMARY_IN.read_text(encoding="utf-8"))
    thresholds = qp014_summary["thresholds"]
    a_side = float(thresholds["A_SIDE"])
    a_share = float(thresholds["A_SHARE"])
    bridge_rows = read_csv(QP015_BRIDGE_IN)

    selector_rows = build_selector_rows(bridge_rows, a_side, a_share)
    family_rows = build_family_rows(selector_rows)
    schema = schema_rows()
    next_rows = [
        {
            "next_frontier": "QP017_PRIVATE_STABLE_MODE_TO_ROLE_OPERATOR_BRIDGE",
            "why_next": "QP016 selects stable committed modes; QP017 should map those stable modes into the existing phase role/operator lane.",
            "input_surface": "qp016_stable_mode_selector_table.csv",
            "target_output": "stable mode to phase role/operator bridge",
        }
    ]

    stable = [
        row
        for row in selector_rows
        if row["selector_class"] == "STABLE_SELF_CLOSURE_MODE_SELECTED"
    ]
    candidates = [
        row
        for row in selector_rows
        if row["selector_class"] == "BOUNDARY_REORGANIZATION_CANDIDATE"
    ]
    transient = [
        row
        for row in selector_rows
        if row["selector_class"] == "TRANSIENT_COMMIT_TAIL"
    ]
    top_stable = stable[0] if stable else selector_rows[0]
    summary = {
        "artifact": "QP016_PRIVATE_LEDGER_COMMIT_TO_STABLE_MODE_SELECTOR",
        "result_class": "QP016_PRIVATE_LEDGER_COMMIT_TO_STABLE_MODE_SELECTOR_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "inputs": {
            "qp015": qp015_summary["artifact"],
            "qp014_thresholds": qp014_summary["artifact"],
        },
        "thresholds": thresholds,
        "law": "stable self-closure requires latest P_commit >= A_SHARE and persistence across structured commit rows >= A_SIDE; mixed P_commit >= A_SIDE is boundary reorganization candidate",
        "route_pairs": len(selector_rows),
        "stable_selected_modes": len(stable),
        "boundary_reorganization_candidates": len(candidates),
        "transient_commit_tails": len(transient),
        "family_rows": len(family_rows),
        "schema_rows": len(schema),
        "top_stable_mode_pair": top_stable["route_pair"],
        "top_stable_mode_probability": top_stable["latest_commit_probability"],
        "top_stable_mode_stability_index": top_stable["stability_index"],
        "core_interpretation": "not every committed intersection is stable; stable mode selection requires self-closure plus native-strength persistence",
        "next_frontier": "QP017_PRIVATE_STABLE_MODE_TO_ROLE_OPERATOR_BRIDGE",
    }

    write_csv(
        SELECTOR_OUT,
        selector_rows,
        [
            "QP016_rank",
            "route_pair",
            "route_i",
            "route_j",
            "pair_structure",
            "latest_open_sample",
            "first_commit_kernel",
            "latest_commit_probability",
            "latest_commit_weight",
            "native_boundary_threshold_A_SIDE",
            "stable_threshold_A_SHARE",
            "structured_commit_rows",
            "native_persistent_rows_at_or_above_A_SIDE",
            "selected_persistent_rows_at_or_above_A_SHARE",
            "native_persistence_fraction",
            "selected_persistence_fraction",
            "self_closure",
            "stability_index",
            "selector_class",
            "SAM_reading",
        ],
    )
    write_csv(FAMILY_OUT, family_rows, ["summary_type", "name", "count", "SAM_reading"])
    write_csv(SCHEMA_OUT, schema, ["quantity", "definition", "role"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "input_surface", "target_output"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    DOC_OUT.write_text(render_doc(summary, selector_rows), encoding="utf-8")

    print(summary["result_class"])
    print(f"route_pairs={summary['route_pairs']}")
    print(f"stable_selected_modes={summary['stable_selected_modes']}")
    print(f"boundary_reorganization_candidates={summary['boundary_reorganization_candidates']}")
    print(f"transient_commit_tails={summary['transient_commit_tails']}")
    print(f"top_stable_mode_pair={summary['top_stable_mode_pair']}")
    print(f"top_stable_mode_probability={summary['top_stable_mode_probability']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
