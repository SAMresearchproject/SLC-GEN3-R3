from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
QP004_DIR = ARTIFACTS / "qp004"
QP016_DIR = ARTIFACTS / "qp016"
QP017_DIR = ARTIFACTS / "qp017"

QP004_ROLE_IN = QP004_DIR / "qp004_phase_to_particle_role_operator_bridge.csv"
QP004_SUMMARY_IN = QP004_DIR / "qp004_phase_to_particle_role_operator_summary.json"
QP016_SELECTOR_IN = QP016_DIR / "qp016_stable_mode_selector_table.csv"
QP016_SUMMARY_IN = QP016_DIR / "qp016_summary.json"

SUMMARY_OUT = QP017_DIR / "qp017_summary.json"
BRIDGE_OUT = QP017_DIR / "qp017_stable_mode_role_operator_bridge.csv"
SUPPORT_OUT = QP017_DIR / "qp017_role_operator_support_summary.csv"
SCHEMA_OUT = QP017_DIR / "qp017_role_bridge_schema.csv"
NEXT_OUT = QP017_DIR / "qp017_next_frontier.csv"
DOC_OUT = REPORTS / "QP017_PRIVATE_STABLE_MODE_TO_ROLE_OPERATOR_BRIDGE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fmt(value: float) -> str:
    return f"{value:.12g}"


def normalize_pair(pair: str) -> str:
    left, right = pair.split("<->", 1)
    return "<->".join(sorted([left, right]))


def split_pair(pair: str) -> tuple[str, str]:
    left, right = pair.split("<->", 1)
    return left, right


def split_required_pairs(value: str) -> list[str]:
    return [normalize_pair(item.strip()) for item in value.split(";") if item.strip()]


def build_role_indexes(role_rows: list[dict[str, str]]) -> tuple[dict[str, list[dict[str, str]]], dict[str, list[dict[str, str]]]]:
    by_pair: dict[str, list[dict[str, str]]] = defaultdict(list)
    by_route: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in role_rows:
        for pair in split_required_pairs(row["required_phase_pairs"]):
            by_pair[pair].append(row)
            left, right = split_pair(pair)
            by_route[left].append(row)
            by_route[right].append(row)
    return by_pair, by_route


def unique_join(values: list[str]) -> str:
    return ";".join(sorted(set(item for item in values if item)))


def role_names(rows: list[dict[str, str]]) -> list[str]:
    return [row["phase_role_operator"] for row in rows]


def target_pairs(rows: list[dict[str, str]]) -> list[str]:
    return [row["suk055_pair"] for row in rows]


def classify_bridge(
    selector_class: str,
    pair_structure: str,
    direct_roles: list[dict[str, str]],
    common_roles: list[dict[str, str]],
    route_i_roles: list[dict[str, str]],
    route_j_roles: list[dict[str, str]],
) -> tuple[str, str]:
    if selector_class == "STABLE_SELF_CLOSURE_MODE_SELECTED":
        if route_i_roles or route_j_roles:
            return (
                "STABLE_ROLE_ANCHOR_PROMOTED",
                "selected stable self-closure anchors existing role/operator lane",
            )
        return ("STABLE_MODE_WITHOUT_ROLE_OPERATOR", "selected stable mode has no current QP004 role contact")
    if selector_class == "BOUNDARY_REORGANIZATION_CANDIDATE":
        if direct_roles:
            return ("DIRECT_REORGANIZATION_ROLE_CONTACT", "boundary candidate is also a direct QP004 role contact")
        if common_roles:
            return ("SHARED_ROLE_FAMILY_REORGANIZATION", "boundary candidate shares a QP004 role family")
        if route_i_roles and route_j_roles:
            return ("CROSS_ROLE_BOUNDARY_REORGANIZATION", "boundary candidate bridges two role/operator neighborhoods")
        if route_i_roles or route_j_roles:
            return ("ONE_SIDED_ROLE_BOUNDARY_REORGANIZATION", "boundary candidate touches one role/operator neighborhood")
        return ("UNMAPPED_BOUNDARY_REORGANIZATION", "boundary candidate has no current QP004 role contact")
    if direct_roles:
        return ("TRANSIENT_DIRECT_ROLE_CONTACT_REJECTED", "direct QP004 role contact exists but QP016 rejects stability")
    if pair_structure == "SELF_CLOSURE":
        return ("TRANSIENT_SELF_CLOSURE_REJECTED", "self-closure exists but falls below native stability")
    return ("TRANSIENT_ROLE_TAIL_REJECTED", "committed pair remains a transient tail")


def build_bridge_rows(
    selector_rows: list[dict[str, str]],
    by_pair: dict[str, list[dict[str, str]]],
    by_route: dict[str, list[dict[str, str]]],
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in selector_rows:
        route_pair = normalize_pair(row["route_pair"])
        route_i = row["route_i"]
        route_j = row["route_j"]
        direct_roles = by_pair.get(route_pair, [])
        route_i_roles = by_route.get(route_i, [])
        route_j_roles = by_route.get(route_j, [])
        common_role_names = sorted(set(role_names(route_i_roles)).intersection(role_names(route_j_roles)))
        common_roles = [
            role
            for role in route_i_roles + route_j_roles
            if role["phase_role_operator"] in common_role_names
        ]
        bridge_class, bridge_reading = classify_bridge(
            row["selector_class"],
            row["pair_structure"],
            direct_roles,
            common_roles,
            route_i_roles,
            route_j_roles,
        )
        role_operator_bridge_strength = float(row["stability_index"])
        if row["selector_class"] == "BOUNDARY_REORGANIZATION_CANDIDATE":
            role_operator_bridge_strength *= 0.5
        rows.append(
            {
                "QP017_rank": row["QP016_rank"],
                "route_pair": row["route_pair"],
                "route_i": route_i,
                "route_j": route_j,
                "qp016_selector_class": row["selector_class"],
                "qp016_pair_structure": row["pair_structure"],
                "latest_commit_probability": row["latest_commit_probability"],
                "stability_index": row["stability_index"],
                "direct_qp004_role_operators": unique_join(role_names(direct_roles)),
                "direct_suk055_targets": unique_join(target_pairs(direct_roles)),
                "route_i_role_operators": unique_join(role_names(route_i_roles)),
                "route_j_role_operators": unique_join(role_names(route_j_roles)),
                "shared_role_operators": unique_join(common_role_names),
                "role_bridge_class": bridge_class,
                "role_operator_bridge_strength": role_operator_bridge_strength,
                "promote_to_role_lane": bridge_class in {
                    "STABLE_ROLE_ANCHOR_PROMOTED",
                    "DIRECT_REORGANIZATION_ROLE_CONTACT",
                    "SHARED_ROLE_FAMILY_REORGANIZATION",
                    "CROSS_ROLE_BOUNDARY_REORGANIZATION",
                    "ONE_SIDED_ROLE_BOUNDARY_REORGANIZATION",
                },
                "SAM_reading": bridge_reading,
            }
        )
    rows.sort(
        key=lambda item: (
            0 if item["promote_to_role_lane"] else 1,
            -float(item["role_operator_bridge_strength"]),
            int(item["QP017_rank"]),
        )
    )
    for rank, row in enumerate(rows, start=1):
        row["QP017_rank"] = rank
    return rows


def build_support_rows(bridge_rows: list[dict[str, object]]) -> list[dict[str, object]]:
    class_counts = Counter(str(row["role_bridge_class"]) for row in bridge_rows)
    promoted = [row for row in bridge_rows if row["promote_to_role_lane"] is True]
    rows: list[dict[str, object]] = []
    for name, count in sorted(class_counts.items()):
        rows.append(
            {
                "summary_type": "role_bridge_class",
                "name": name,
                "count": count,
                "SAM_reading": "role bridge class count across QP016 route pairs",
            }
        )
    rows.append(
        {
            "summary_type": "promotion_count",
            "name": "PROMOTED_TO_ROLE_LANE",
            "count": len(promoted),
            "SAM_reading": "stable/candidate rows that bridge into the role/operator lane",
        }
    )
    return rows


def schema_rows() -> list[dict[str, object]]:
    return [
        {
            "quantity": "direct_qp004_role_operators",
            "definition": "QP004 roles whose required_phase_pairs include the QP016 route pair exactly",
            "role": "direct role/operator contact",
        },
        {
            "quantity": "STABLE_ROLE_ANCHOR_PROMOTED",
            "definition": "QP016 stable self-closure touches existing QP004 role neighborhoods",
            "role": "stable anchor promoted into role/operator lane",
        },
        {
            "quantity": "CROSS_ROLE_BOUNDARY_REORGANIZATION",
            "definition": "QP016 boundary candidate connects routes that each touch role/operator neighborhoods",
            "role": "transition/asymmetric bridge candidate",
        },
        {
            "quantity": "TRANSIENT_DIRECT_ROLE_CONTACT_REJECTED",
            "definition": "QP004 direct contact exists but QP016 selector rejects stability",
            "role": "do not promote old direct role rule without current stable-mode support",
        },
        {
            "quantity": "role_operator_bridge_strength",
            "definition": "QP016 stability_index, halved for boundary reorganization candidates",
            "role": "ordered bridge strength from selected/candidate modes",
        },
    ]


def render_doc(summary: dict[str, object], bridge_rows: list[dict[str, object]]) -> str:
    promoted = [row for row in bridge_rows if row["promote_to_role_lane"] is True]
    promoted_lines = "\n".join(
        "| {rank} | {pair} | {cls} | {roles} | {strength} |".format(
            rank=row["QP017_rank"],
            pair=row["route_pair"],
            cls=row["role_bridge_class"],
            roles=row["direct_qp004_role_operators"] or row["shared_role_operators"] or "anchor/cross-role",
            strength=fmt(float(row["role_operator_bridge_strength"])),
        )
        for row in promoted
    )
    top_lines = "\n".join(
        "| {rank} | {pair} | {selector} | {bridge} | {promote} |".format(
            rank=row["QP017_rank"],
            pair=row["route_pair"],
            selector=row["qp016_selector_class"],
            bridge=row["role_bridge_class"],
            promote=row["promote_to_role_lane"],
        )
        for row in bridge_rows[:10]
    )
    return f"""# QP017 - Private Stable Mode To Role Operator Bridge

## Verdict

`{summary['result_class']}`

QP017 maps QP016's selected stable mode and boundary reorganization candidate
back into the QP004 phase role/operator lane.

Core rule:

```text
selected stable self-closure -> role anchor if it touches existing QP004 role neighborhoods
boundary candidate -> role bridge if it connects role/operator neighborhoods
transient tails -> no role promotion
```

## Main Read

```text
route-pair rows = {summary['bridge_rows']}
role-lane promotions = {summary['role_lane_promotions']}
stable role anchors = {summary['stable_role_anchors']}
boundary role bridges = {summary['boundary_role_bridges']}
transient rejections = {summary['transient_role_rejections']}
free parameters introduced = {summary['free_parameters_introduced']}
```

## Promoted Rows

| Rank | Pair | Bridge Class | Role Surface | Bridge Strength |
| ---: | --- | --- | --- | ---: |
{promoted_lines}

## Top Bridge Rows

| Rank | Pair | QP016 Class | Role Bridge Class | Promote |
| ---: | --- | --- | --- | --- |
{top_lines}

## Meaning

The stable mode promotes as a neutral identity anchor:

```text
QUBIT-NL-001<->QUBIT-NL-001
```

The boundary reorganization candidate bridges the neutral identity lane and the
unknown asymmetric lane:

```text
QUBIT-NL-001<->QUBIT-UNK-001
```

So QP017 preserves the split QP016 found:

```text
stable closure anchor
boundary/asymmetric reorganization bridge
transient tails rejected from role promotion
```

## Outputs

```text
qp017_stable_mode_role_operator_bridge.csv
qp017_role_operator_support_summary.csv
qp017_role_bridge_schema.csv
qp017_summary.json
qp017_next_frontier.csv
```

## Next Frontier

`QP018_PRIVATE_ROLE_BRIDGE_TO_PARTICLE_SLOT_SELECTOR`

QP018 should use the promoted stable anchor and boundary reorganization bridge
to select which particle slots are reachable without promoting transient tails.

Generated at UTC: `{summary['generated_at_utc']}`
"""


def main() -> int:
    QP017_DIR.mkdir(parents=True, exist_ok=True)
    qp004_summary = json.loads(QP004_SUMMARY_IN.read_text(encoding="utf-8"))
    qp016_summary = json.loads(QP016_SUMMARY_IN.read_text(encoding="utf-8"))
    role_rows = read_csv(QP004_ROLE_IN)
    selector_rows = read_csv(QP016_SELECTOR_IN)
    by_pair, by_route = build_role_indexes(role_rows)

    bridge_rows = build_bridge_rows(selector_rows, by_pair, by_route)
    support_rows = build_support_rows(bridge_rows)
    schema = schema_rows()
    next_rows = [
        {
            "next_frontier": "QP018_PRIVATE_ROLE_BRIDGE_TO_PARTICLE_SLOT_SELECTOR",
            "why_next": "QP017 identifies which stable/candidate modes can promote into the role lane; QP018 should select reachable particle slots from those promoted bridges.",
            "input_surface": "qp017_stable_mode_role_operator_bridge.csv",
            "target_output": "role bridge to particle slot selector",
        }
    ]

    promoted = [row for row in bridge_rows if row["promote_to_role_lane"] is True]
    stable_anchors = [row for row in bridge_rows if row["role_bridge_class"] == "STABLE_ROLE_ANCHOR_PROMOTED"]
    boundary_bridges = [
        row
        for row in bridge_rows
        if "REORGANIZATION" in str(row["role_bridge_class"])
        and row["promote_to_role_lane"] is True
    ]
    transient_rejections = [row for row in bridge_rows if row["promote_to_role_lane"] is False]
    top_promoted = promoted[0] if promoted else bridge_rows[0]
    summary = {
        "artifact": "QP017_PRIVATE_STABLE_MODE_TO_ROLE_OPERATOR_BRIDGE",
        "result_class": "QP017_PRIVATE_STABLE_MODE_TO_ROLE_OPERATOR_BRIDGE_BUILT",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "inputs": {
            "qp016": qp016_summary["artifact"],
            "qp004": qp004_summary["artifact"],
        },
        "law": "stable selected modes promote as role anchors; boundary candidates promote as role bridges; transient tails are rejected from role promotion",
        "bridge_rows": len(bridge_rows),
        "role_lane_promotions": len(promoted),
        "stable_role_anchors": len(stable_anchors),
        "boundary_role_bridges": len(boundary_bridges),
        "transient_role_rejections": len(transient_rejections),
        "support_rows": len(support_rows),
        "schema_rows": len(schema),
        "top_promoted_pair": top_promoted["route_pair"],
        "top_promoted_bridge_class": top_promoted["role_bridge_class"],
        "top_promoted_bridge_strength": top_promoted["role_operator_bridge_strength"],
        "core_interpretation": "QP016 stable/candidate modes can bridge into QP004 role/operator space without promoting transient tails",
        "next_frontier": "QP018_PRIVATE_ROLE_BRIDGE_TO_PARTICLE_SLOT_SELECTOR",
    }

    write_csv(
        BRIDGE_OUT,
        bridge_rows,
        [
            "QP017_rank",
            "route_pair",
            "route_i",
            "route_j",
            "qp016_selector_class",
            "qp016_pair_structure",
            "latest_commit_probability",
            "stability_index",
            "direct_qp004_role_operators",
            "direct_suk055_targets",
            "route_i_role_operators",
            "route_j_role_operators",
            "shared_role_operators",
            "role_bridge_class",
            "role_operator_bridge_strength",
            "promote_to_role_lane",
            "SAM_reading",
        ],
    )
    write_csv(SUPPORT_OUT, support_rows, ["summary_type", "name", "count", "SAM_reading"])
    write_csv(SCHEMA_OUT, schema, ["quantity", "definition", "role"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "input_surface", "target_output"])
    SUMMARY_OUT.write_text(json.dumps(summary, indent=2), encoding="utf-8")
    DOC_OUT.write_text(render_doc(summary, bridge_rows), encoding="utf-8")

    print(summary["result_class"])
    print(f"bridge_rows={summary['bridge_rows']}")
    print(f"role_lane_promotions={summary['role_lane_promotions']}")
    print(f"stable_role_anchors={summary['stable_role_anchors']}")
    print(f"boundary_role_bridges={summary['boundary_role_bridges']}")
    print(f"transient_role_rejections={summary['transient_role_rejections']}")
    print(f"top_promoted_pair={summary['top_promoted_pair']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
