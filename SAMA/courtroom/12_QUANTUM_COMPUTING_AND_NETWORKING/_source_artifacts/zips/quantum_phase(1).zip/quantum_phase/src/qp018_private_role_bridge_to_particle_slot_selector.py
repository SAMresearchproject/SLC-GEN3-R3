from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP006_DIR = ARTIFACTS / "qp006"
QP008_DIR = ARTIFACTS / "qp008"
QP017_DIR = ARTIFACTS / "qp017"
QP018_DIR = ARTIFACTS / "qp018"

QP006_SLOTS_IN = QP006_DIR / "qp006_heavy_composite_slot_priority_table.csv"
QP006_SUMMARY_IN = QP006_DIR / "qp006_heavy_composite_slot_priority_summary.json"
QP008_SELECTED_IN = QP008_DIR / "qp008_heavy_role_shift_selector_table.csv"
QP008_SUMMARY_IN = QP008_DIR / "qp008_heavy_role_shift_selector_summary.json"
QP017_BRIDGE_IN = QP017_DIR / "qp017_stable_mode_role_operator_bridge.csv"
QP017_SUMMARY_IN = QP017_DIR / "qp017_summary.json"

SUMMARY_OUT = QP018_DIR / "qp018_summary.json"
SELECTOR_OUT = QP018_DIR / "qp018_role_bridge_particle_slot_selector.csv"
FAMILY_OUT = QP018_DIR / "qp018_slot_family_summary.csv"
SCHEMA_OUT = QP018_DIR / "qp018_schema.csv"
NEXT_OUT = QP018_DIR / "qp018_next_frontier.csv"
DOC_OUT = REPORTS / "QP018_PRIVATE_ROLE_BRIDGE_TO_PARTICLE_SLOT_SELECTOR.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def split_roles(value: str) -> list[str]:
    return [item.strip() for item in value.split(";") if item.strip()]


def fmt(value: float) -> str:
    return f"{value:.12g}"


def bool_text(value: bool) -> str:
    return "True" if value else "False"


def role_bridge_sets(bridge_rows: list[dict[str, str]]) -> tuple[set[str], set[str], dict[str, float], dict[str, str]]:
    anchor_roles: set[str] = set()
    boundary_roles: set[str] = set()
    role_strength: dict[str, float] = {}
    role_source: dict[str, str] = {}

    for row in bridge_rows:
        if row["promote_to_role_lane"] != "True":
            continue
        roles = set()
        for field in (
            "direct_qp004_role_operators",
            "route_i_role_operators",
            "route_j_role_operators",
            "shared_role_operators",
        ):
            roles.update(split_roles(row[field]))
        strength = float(row["role_operator_bridge_strength"])
        if row["role_bridge_class"] == "STABLE_ROLE_ANCHOR_PROMOTED":
            for role in roles:
                anchor_roles.add(role)
                if strength >= role_strength.get(role, -1.0):
                    role_strength[role] = strength
                    role_source[role] = row["route_pair"]
        elif "REORGANIZATION" in row["role_bridge_class"]:
            for role in roles:
                boundary_roles.add(role)
                if role not in role_strength:
                    role_strength[role] = strength
                    role_source[role] = row["route_pair"]

    return anchor_roles, boundary_roles, role_strength, role_source


def classify_slot(
    role: str,
    selected_by_qp008: bool,
    anchor_roles: set[str],
    boundary_only_roles: set[str],
    promoted_roles: set[str],
) -> tuple[str, bool, str]:
    if role in anchor_roles and selected_by_qp008:
        return (
            "STABLE_ANCHOR_SLOT_SELECTED",
            True,
            "QP017 stable role anchor reaches an existing QP008 selected particle slot",
        )
    if role in boundary_only_roles and selected_by_qp008:
        return (
            "BOUNDARY_REORGANIZATION_SLOT_SELECTED",
            True,
            "QP017 boundary bridge reaches an existing QP008 selected particle slot",
        )
    if role in promoted_roles:
        return (
            "ROLE_FAMILY_REACHABLE_HELD_OPEN",
            False,
            "QP017 reaches the role family but QP008 did not select this slot",
        )
    if selected_by_qp008:
        return (
            "QP008_SELECTED_OUTSIDE_QP017_BRIDGE",
            False,
            "QP008 selected this slot, while QP017's current role bridge does not promote its role family",
        )
    return (
        "NOT_REACHED_BY_QP017_BRIDGE",
        False,
        "current QP017 promoted role surfaces do not reach this slot",
    )


def build_selector_rows(
    slot_rows: list[dict[str, str]],
    selected_rows: list[dict[str, str]],
    bridge_rows: list[dict[str, str]],
) -> tuple[list[dict[str, object]], dict[str, object]]:
    selected_by_pair = {row["suk055_pair"]: row for row in selected_rows}
    anchor_roles, boundary_roles, role_strength, role_source = role_bridge_sets(bridge_rows)
    boundary_only_roles = boundary_roles - anchor_roles
    promoted_roles = anchor_roles | boundary_roles

    rows: list[dict[str, object]] = []
    for row in slot_rows:
        pair = row["suk055_pair"]
        role = row["phase_role_operator"]
        selected_row = selected_by_pair.get(pair)
        selected_by_qp008 = selected_row is not None
        selector_class, promoted, reading = classify_slot(
            role,
            selected_by_qp008,
            anchor_roles,
            boundary_only_roles,
            promoted_roles,
        )
        bridge_strength = role_strength.get(role, 0.0)
        native_strength = float(row["native_interaction_strength"])
        selector_score = native_strength * bridge_strength
        rows.append(
            {
                "QP018_rank": 0,
                "suk055_pair": pair,
                "oriented_slot_ids": row["oriented_slot_ids"],
                "oriented_symbols": row["oriented_symbols"],
                "slot_charges": row["slot_charges"],
                "charge_class": row["charge_class"],
                "phase_role_operator": role,
                "qp017_role_surface": (
                    "STABLE_ROLE_ANCHOR"
                    if role in anchor_roles
                    else "BOUNDARY_ROLE_BRIDGE"
                    if role in boundary_only_roles
                    else "OUTSIDE_QP017_PROMOTED_SURFACE"
                ),
                "qp017_source_pair": role_source.get(role, ""),
                "qp017_bridge_strength": bridge_strength,
                "native_interaction_strength": native_strength,
                "slot_selector_score": selector_score,
                "qp006_priority_class": row["priority_class"],
                "qp006_native_closure_class": row["native_closure_class"],
                "qp008_selected": selected_by_qp008,
                "qp008_selected_surface": selected_row["selected_surface"] if selected_row else "",
                "qp008_selected_mass_readout_MeV": selected_row["selected_mass_readout_MeV"] if selected_row else "",
                "qp008_integer_shift_contact_class": selected_row["integer_shift_contact_class"] if selected_row else "",
                "QP018_selector_class": selector_class,
                "promote_to_particle_slot_lane": promoted,
                "SAM_reading": reading,
            }
        )

    rows.sort(
        key=lambda item: (
            0 if item["promote_to_particle_slot_lane"] else 1,
            -float(item["slot_selector_score"]),
            int(str(item["qp006_priority_class"])[1]) if str(item["qp006_priority_class"]).startswith("P") else 9,
            item["suk055_pair"],
        )
    )
    for index, row in enumerate(rows, start=1):
        row["QP018_rank"] = index

    support = {
        "anchor_roles": sorted(anchor_roles),
        "boundary_roles": sorted(boundary_roles),
        "boundary_only_roles": sorted(boundary_only_roles),
        "promoted_roles": sorted(promoted_roles),
    }
    return rows, support


def build_family_rows(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    grouped: dict[str, list[dict[str, object]]] = {}
    for row in rows:
        grouped.setdefault(str(row["phase_role_operator"]), []).append(row)

    family_rows: list[dict[str, object]] = []
    for role, role_rows in sorted(grouped.items()):
        family_rows.append(
            {
                "phase_role_operator": role,
                "slot_rows": len(role_rows),
                "promoted_slots": sum(1 for row in role_rows if row["promote_to_particle_slot_lane"]),
                "qp008_selected_slots": sum(1 for row in role_rows if row["qp008_selected"]),
                "qp017_role_surface": role_rows[0]["qp017_role_surface"],
                "max_slot_selector_score": max(float(row["slot_selector_score"]) for row in role_rows),
                "top_slot": max(role_rows, key=lambda row: float(row["slot_selector_score"]))["suk055_pair"],
            }
        )
    return family_rows


def build_schema_rows() -> list[dict[str, str]]:
    return [
        {
            "quantity": "STABLE_ANCHOR_SLOT_SELECTED",
            "definition": "QP017 stable role anchor reaches a QP008 selected slot",
            "role": "first particle-slot anchor promotion",
        },
        {
            "quantity": "BOUNDARY_REORGANIZATION_SLOT_SELECTED",
            "definition": "QP017 boundary role bridge reaches a QP008 selected slot",
            "role": "asymmetric/reorganization slot promotion",
        },
        {
            "quantity": "ROLE_FAMILY_REACHABLE_HELD_OPEN",
            "definition": "QP017 reaches the role family while QP008 leaves the specific slot unselected",
            "role": "reachable family, not promoted as a selected slot",
        },
        {
            "quantity": "slot_selector_score",
            "definition": "native_interaction_strength times the relevant QP017 bridge strength",
            "role": "ranking surface for the QP017 to particle-slot bridge",
        },
        {
            "quantity": "QP008_SELECTED_OUTSIDE_QP017_BRIDGE",
            "definition": "QP008 selected a slot whose role family is outside QP017's current promoted surfaces",
            "role": "kept as existing private slot evidence outside this gate",
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str], headers: list[str]) -> str:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row[field]) for field in fields) + " |")
    return "\n".join(lines)


def write_report(summary: dict[str, object], selector_rows: list[dict[str, object]], family_rows: list[dict[str, object]]) -> None:
    promoted = [row for row in selector_rows if row["promote_to_particle_slot_lane"]]
    top_rows = selector_rows[:10]

    promoted_table = markdown_table(
        [
            {
                "rank": row["QP018_rank"],
                "pair": row["suk055_pair"],
                "role": row["phase_role_operator"],
                "selector": row["QP018_selector_class"],
                "score": fmt(float(row["slot_selector_score"])),
            }
            for row in promoted
        ],
        ["rank", "pair", "role", "selector", "score"],
        ["Rank", "Pair", "Role", "Selector Class", "Score"],
    )
    top_table = markdown_table(
        [
            {
                "rank": row["QP018_rank"],
                "pair": row["suk055_pair"],
                "role": row["phase_role_operator"],
                "surface": row["qp017_role_surface"],
                "selector": row["QP018_selector_class"],
                "promote": row["promote_to_particle_slot_lane"],
            }
            for row in top_rows
        ],
        ["rank", "pair", "role", "surface", "selector", "promote"],
        ["Rank", "Pair", "Role", "QP017 Surface", "Selector Class", "Promote"],
    )
    family_table = markdown_table(
        [
            {
                "role": row["phase_role_operator"],
                "surface": row["qp017_role_surface"],
                "slots": row["slot_rows"],
                "promoted": row["promoted_slots"],
                "top": row["top_slot"],
            }
            for row in family_rows
        ],
        ["role", "surface", "slots", "promoted", "top"],
        ["Role", "QP017 Surface", "Slots", "Promoted", "Top Slot"],
    )

    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP018 - Private Role Bridge To Particle Slot Selector

## Verdict

`{summary['result_class']}`

QP018 applies QP017's promoted role surfaces to the existing private particle
slot tables from QP006 and QP008.

Core rule:

```text
stable role anchor + QP008 selected slot -> stable particle-slot promotion
boundary role bridge + QP008 selected slot -> reorganization particle-slot promotion
reachable role family + no QP008 selection -> held open
selected slot outside QP017 bridge -> preserved outside this gate
```

## Main Read

```text
slot rows = {summary['slot_rows']}
qp017 reachable role-family slots = {summary['qp017_reachable_role_family_slots']}
particle slot promotions = {summary['particle_slot_promotions']}
stable anchor slot promotions = {summary['stable_anchor_slot_promotions']}
boundary reorganization slot promotions = {summary['boundary_reorganization_slot_promotions']}
held-open reachable slots = {summary['held_open_reachable_slots']}
free parameters introduced = {summary['free_parameters_introduced']}
```

## Promoted Particle Slots

{promoted_table}

## Top Selector Rows

{top_table}

## Role Family Summary

{family_table}

## Meaning

QP018 turns the QP017 bridge into a particle-slot selector.

The first stable anchor slot is:

```text
{summary['top_promoted_slot']}
```

The boundary/reorganization slot is:

```text
{summary['top_boundary_slot']}
```

This gives QP018 a clean next surface:

```text
stable neutral anchor slot
asymmetric transition/reorganization slot
reachable but held-open role families
selected charged slots preserved outside the QP017 bridge
```

## Outputs

```text
qp018_role_bridge_particle_slot_selector.csv
qp018_slot_family_summary.csv
qp018_schema.csv
qp018_summary.json
qp018_next_frontier.csv
```

## Next Frontier

`QP019_PRIVATE_PARTICLE_SLOT_TO_NATIVE_MASS_SURFACE_BRIDGE`

QP019 should use the QP018 selected slot pair to connect the stable anchor and
boundary/reorganization slot to native mass-surface readouts.

Generated at UTC: `{summary['generated_at_utc']}`
""",
        encoding="utf-8",
    )


def main() -> int:
    generated_at = datetime.now(timezone.utc).isoformat()
    slot_rows = read_csv(QP006_SLOTS_IN)
    selected_rows = read_csv(QP008_SELECTED_IN)
    bridge_rows = read_csv(QP017_BRIDGE_IN)
    qp006_summary = read_json(QP006_SUMMARY_IN)
    qp008_summary = read_json(QP008_SUMMARY_IN)
    qp017_summary = read_json(QP017_SUMMARY_IN)

    selector_rows, support = build_selector_rows(slot_rows, selected_rows, bridge_rows)
    family_rows = build_family_rows(selector_rows)
    schema_rows = build_schema_rows()

    promoted = [row for row in selector_rows if row["promote_to_particle_slot_lane"]]
    stable_promoted = [row for row in promoted if row["QP018_selector_class"] == "STABLE_ANCHOR_SLOT_SELECTED"]
    boundary_promoted = [
        row for row in promoted if row["QP018_selector_class"] == "BOUNDARY_REORGANIZATION_SLOT_SELECTED"
    ]
    held_open = [row for row in selector_rows if row["QP018_selector_class"] == "ROLE_FAMILY_REACHABLE_HELD_OPEN"]
    qp008_outside = [
        row for row in selector_rows if row["QP018_selector_class"] == "QP008_SELECTED_OUTSIDE_QP017_BRIDGE"
    ]

    class_counts = Counter(str(row["QP018_selector_class"]) for row in selector_rows)
    surface_counts = Counter(str(row["qp017_role_surface"]) for row in selector_rows)

    top_promoted = max(promoted, key=lambda row: float(row["slot_selector_score"])) if promoted else {}
    top_boundary = max(boundary_promoted, key=lambda row: float(row["slot_selector_score"])) if boundary_promoted else {}

    summary = {
        "artifact": "QP018_PRIVATE_ROLE_BRIDGE_TO_PARTICLE_SLOT_SELECTOR",
        "result_class": "QP018_PRIVATE_ROLE_BRIDGE_TO_PARTICLE_SLOT_SELECTOR_BUILT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "inputs": {
            "qp017": qp017_summary["artifact"],
            "qp006": qp006_summary["artifact"],
            "qp008": qp008_summary["artifact"],
        },
        "law": "QP017 promoted role surfaces select existing QP006/QP008 particle slots without promoting transient tails",
        "slot_rows": len(selector_rows),
        "qp017_reachable_role_family_slots": sum(
            1 for row in selector_rows if row["qp017_role_surface"] != "OUTSIDE_QP017_PROMOTED_SURFACE"
        ),
        "particle_slot_promotions": len(promoted),
        "stable_anchor_slot_promotions": len(stable_promoted),
        "boundary_reorganization_slot_promotions": len(boundary_promoted),
        "held_open_reachable_slots": len(held_open),
        "qp008_selected_outside_qp017_bridge": len(qp008_outside),
        "selector_class_counts": dict(class_counts),
        "qp017_surface_counts": dict(surface_counts),
        "anchor_roles": support["anchor_roles"],
        "boundary_roles": support["boundary_roles"],
        "top_promoted_slot": top_promoted.get("suk055_pair", ""),
        "top_promoted_slot_selector_class": top_promoted.get("QP018_selector_class", ""),
        "top_promoted_slot_score": top_promoted.get("slot_selector_score", 0.0),
        "top_boundary_slot": top_boundary.get("suk055_pair", ""),
        "top_boundary_slot_score": top_boundary.get("slot_selector_score", 0.0),
        "core_interpretation": "QP017 promotes b<->s as the stable neutral slot and c<->s as the boundary/reorganization slot",
        "next_frontier": "QP019_PRIVATE_PARTICLE_SLOT_TO_NATIVE_MASS_SURFACE_BRIDGE",
    }

    selector_fields = [
        "QP018_rank",
        "suk055_pair",
        "oriented_slot_ids",
        "oriented_symbols",
        "slot_charges",
        "charge_class",
        "phase_role_operator",
        "qp017_role_surface",
        "qp017_source_pair",
        "qp017_bridge_strength",
        "native_interaction_strength",
        "slot_selector_score",
        "qp006_priority_class",
        "qp006_native_closure_class",
        "qp008_selected",
        "qp008_selected_surface",
        "qp008_selected_mass_readout_MeV",
        "qp008_integer_shift_contact_class",
        "QP018_selector_class",
        "promote_to_particle_slot_lane",
        "SAM_reading",
    ]
    family_fields = [
        "phase_role_operator",
        "slot_rows",
        "promoted_slots",
        "qp008_selected_slots",
        "qp017_role_surface",
        "max_slot_selector_score",
        "top_slot",
    ]
    schema_fields = ["quantity", "definition", "role"]
    next_fields = ["next_frontier", "why_next", "input_surface", "target_output"]

    write_csv(SELECTOR_OUT, selector_rows, selector_fields)
    write_csv(FAMILY_OUT, family_rows, family_fields)
    write_csv(SCHEMA_OUT, schema_rows, schema_fields)
    write_csv(
        NEXT_OUT,
        [
            {
                "next_frontier": "QP019_PRIVATE_PARTICLE_SLOT_TO_NATIVE_MASS_SURFACE_BRIDGE",
                "why_next": "QP018 identifies the stable anchor and boundary/reorganization particle slots; QP019 should connect those selected slots to native mass-surface readouts.",
                "input_surface": "qp018_role_bridge_particle_slot_selector.csv",
                "target_output": "particle slot to native mass surface bridge",
            }
        ],
        next_fields,
    )
    write_json(SUMMARY_OUT, summary)
    write_report(summary, selector_rows, family_rows)

    print(summary["result_class"])
    print(f"slot_rows={summary['slot_rows']}")
    print(f"particle_slot_promotions={summary['particle_slot_promotions']}")
    print(f"stable_anchor_slot_promotions={summary['stable_anchor_slot_promotions']}")
    print(f"boundary_reorganization_slot_promotions={summary['boundary_reorganization_slot_promotions']}")
    print(f"top_promoted_slot={summary['top_promoted_slot']}")
    print(f"top_boundary_slot={summary['top_boundary_slot']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
