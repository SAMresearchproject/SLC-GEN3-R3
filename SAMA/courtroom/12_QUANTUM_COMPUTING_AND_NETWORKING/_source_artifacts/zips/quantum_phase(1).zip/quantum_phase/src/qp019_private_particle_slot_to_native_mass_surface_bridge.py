from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP007_DIR = ARTIFACTS / "qp007"
QP008_DIR = ARTIFACTS / "qp008"
QP018_DIR = ARTIFACTS / "qp018"
QP019_DIR = ARTIFACTS / "qp019"

QP007_TRIALS_IN = QP007_DIR / "qp007_role_operator_mass_closure_trial_table.csv"
QP007_SUMMARY_IN = QP007_DIR / "qp007_role_operator_mass_closure_summary.json"
QP008_SELECTED_IN = QP008_DIR / "qp008_heavy_role_shift_selector_table.csv"
QP008_SUMMARY_IN = QP008_DIR / "qp008_heavy_role_shift_selector_summary.json"
QP018_SELECTOR_IN = QP018_DIR / "qp018_role_bridge_particle_slot_selector.csv"
QP018_SUMMARY_IN = QP018_DIR / "qp018_summary.json"

SUMMARY_OUT = QP019_DIR / "qp019_summary.json"
BRIDGE_OUT = QP019_DIR / "qp019_particle_slot_native_mass_surface_bridge.csv"
SURFACE_OUT = QP019_DIR / "qp019_mass_surface_summary.csv"
SCHEMA_OUT = QP019_DIR / "qp019_schema.csv"
NEXT_OUT = QP019_DIR / "qp019_next_frontier.csv"
DOC_OUT = REPORTS / "QP019_PRIVATE_PARTICLE_SLOT_TO_NATIVE_MASS_SURFACE_BRIDGE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def fmt(value: float) -> str:
    return f"{value:.12g}"


def index_qp008(rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    return {row["suk055_pair"]: row for row in rows}


def index_qp007(rows: list[dict[str, str]]) -> dict[tuple[str, str], dict[str, str]]:
    return {(row["suk055_pair"], row["surface_name"]): row for row in rows}


def classify_bridge(row: dict[str, str], selected: dict[str, str] | None, trial: dict[str, str] | None) -> tuple[str, bool, str]:
    promoted = row["promote_to_particle_slot_lane"] == "True"
    if promoted and selected and trial:
        if row["QP018_selector_class"] == "STABLE_ANCHOR_SLOT_SELECTED":
            return (
                "STABLE_ANCHOR_MASS_SURFACE_BRIDGED",
                True,
                "stable particle-slot anchor carries a native mass-surface readout",
            )
        if row["QP018_selector_class"] == "BOUNDARY_REORGANIZATION_SLOT_SELECTED":
            return (
                "BOUNDARY_REORGANIZATION_MASS_SURFACE_BRIDGED",
                True,
                "boundary/reorganization particle slot carries a native mass-surface readout",
            )
        return (
            "PROMOTED_SLOT_MASS_SURFACE_BRIDGED",
            True,
            "promoted particle slot carries a native mass-surface readout",
        )
    if promoted and not selected:
        return (
            "PROMOTED_SLOT_NEEDS_MASS_SELECTOR",
            False,
            "particle slot promoted but no selected QP008 mass surface exists",
        )
    if row["QP018_selector_class"] == "ROLE_FAMILY_REACHABLE_HELD_OPEN":
        return (
            "REACHABLE_SLOT_HELD_OPEN_NO_MASS_READOUT",
            False,
            "role family is reachable but QP018 did not promote the slot to mass readout",
        )
    if row["QP018_selector_class"] == "QP008_SELECTED_OUTSIDE_QP017_BRIDGE" and selected and trial:
        return (
            "MASS_SURFACE_EXISTS_OUTSIDE_QP017_BRIDGE",
            False,
            "QP008 mass surface exists, but this slot is outside the QP017 promoted bridge",
        )
    return (
        "NOT_SELECTED_FOR_NATIVE_MASS_SURFACE",
        False,
        "slot is not reached by the QP017/QP018 promoted chain",
    )


def build_bridge_rows(
    selector_rows: list[dict[str, str]],
    qp008_by_pair: dict[str, dict[str, str]],
    qp007_by_pair_surface: dict[tuple[str, str], dict[str, str]],
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in selector_rows:
        pair = row["suk055_pair"]
        selected = qp008_by_pair.get(pair)
        selected_surface = selected["selected_surface"] if selected else ""
        trial = qp007_by_pair_surface.get((pair, selected_surface)) if selected else None
        bridge_class, promoted, reading = classify_bridge(row, selected, trial)

        slot_selector_score = float(row["slot_selector_score"])
        selected_mass = float(selected["selected_mass_readout_MeV"]) if selected else 0.0
        target_surface = float(selected["target_internal_surface_MeV"]) if selected else 0.0
        absolute_delta = float(selected["absolute_surface_delta_MeV"]) if selected else 0.0
        readout_ratio = float(selected["readout_to_surface_ratio"]) if selected else 0.0
        integer_shift_delta = float(selected["integer_shift_delta"]) if selected else 0.0
        contact_tightness = max(0.0, 1.0 - abs(integer_shift_delta)) if selected else 0.0
        mass_surface_bridge_score = slot_selector_score * contact_tightness

        rows.append(
            {
                "QP019_rank": 0,
                "suk055_pair": pair,
                "oriented_symbols": row["oriented_symbols"],
                "phase_role_operator": row["phase_role_operator"],
                "qp018_selector_class": row["QP018_selector_class"],
                "qp017_role_surface": row["qp017_role_surface"],
                "qp017_source_pair": row["qp017_source_pair"],
                "slot_selector_score": slot_selector_score,
                "selected_surface": selected_surface,
                "surface_selector_basis": selected["surface_selector_basis"] if selected else "",
                "seed_role_operator": selected["seed_role_operator"] if selected else "",
                "selected_integer_shift": selected["selected_integer_shift"] if selected else "",
                "required_effective_shift": selected["required_effective_shift"] if selected else "",
                "integer_shift_delta": integer_shift_delta if selected else "",
                "integer_shift_contact_class": selected["integer_shift_contact_class"] if selected else "",
                "selected_mass_readout_MeV": selected_mass if selected else "",
                "target_internal_surface_MeV": target_surface if selected else "",
                "readout_to_surface_ratio": readout_ratio if selected else "",
                "absolute_surface_delta_MeV": absolute_delta if selected else "",
                "qp007_surface_mass_MeV": trial["surface_mass_MeV"] if trial else "",
                "qp007_observed_composite_mass_used": trial["observed_composite_mass_used"] if trial else "",
                "contact_tightness": contact_tightness,
                "mass_surface_bridge_score": mass_surface_bridge_score,
                "QP019_bridge_class": bridge_class,
                "promote_to_native_mass_surface": promoted,
                "SAM_reading": reading,
            }
        )

    rows.sort(
        key=lambda item: (
            0 if item["promote_to_native_mass_surface"] else 1,
            -float(item["mass_surface_bridge_score"]),
            item["suk055_pair"],
        )
    )
    for index, row in enumerate(rows, start=1):
        row["QP019_rank"] = index
    return rows


def build_surface_rows(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    groups: dict[str, list[dict[str, object]]] = {}
    for row in rows:
        surface = str(row["selected_surface"] or "NO_SELECTED_SURFACE")
        groups.setdefault(surface, []).append(row)

    output: list[dict[str, object]] = []
    for surface, group in sorted(groups.items()):
        output.append(
            {
                "selected_surface": surface,
                "rows": len(group),
                "promoted_mass_surfaces": sum(1 for row in group if row["promote_to_native_mass_surface"]),
                "max_mass_surface_bridge_score": max(float(row["mass_surface_bridge_score"]) for row in group),
                "top_pair": max(group, key=lambda row: float(row["mass_surface_bridge_score"]))["suk055_pair"],
            }
        )
    return output


def build_schema_rows() -> list[dict[str, str]]:
    return [
        {
            "quantity": "STABLE_ANCHOR_MASS_SURFACE_BRIDGED",
            "definition": "QP018 stable anchor slot has a selected QP008 mass readout and matching QP007 native surface",
            "role": "stable slot to native mass bridge",
        },
        {
            "quantity": "BOUNDARY_REORGANIZATION_MASS_SURFACE_BRIDGED",
            "definition": "QP018 boundary/reorganization slot has a selected QP008 mass readout and matching QP007 native surface",
            "role": "transition/reorganization slot to native mass bridge",
        },
        {
            "quantity": "contact_tightness",
            "definition": "max(0, 1 - absolute integer_shift_delta)",
            "role": "integer-contact closeness inherited from QP007/QP008",
        },
        {
            "quantity": "mass_surface_bridge_score",
            "definition": "QP018 slot_selector_score times contact_tightness",
            "role": "ordering surface for selected slot to mass readout",
        },
        {
            "quantity": "MASS_SURFACE_EXISTS_OUTSIDE_QP017_BRIDGE",
            "definition": "QP008 selected mass readout exists but QP018 did not promote the slot",
            "role": "preserved outside-bridge particle evidence",
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str], headers: list[str]) -> str:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row[field]) for field in fields) + " |")
    return "\n".join(lines)


def write_report(summary: dict[str, object], bridge_rows: list[dict[str, object]], surface_rows: list[dict[str, object]]) -> None:
    promoted = [row for row in bridge_rows if row["promote_to_native_mass_surface"]]
    promoted_table = markdown_table(
        [
            {
                "rank": row["QP019_rank"],
                "pair": row["suk055_pair"],
                "surface": row["selected_surface"],
                "mass": fmt(float(row["selected_mass_readout_MeV"])),
                "class": row["QP019_bridge_class"],
                "score": fmt(float(row["mass_surface_bridge_score"])),
            }
            for row in promoted
        ],
        ["rank", "pair", "surface", "mass", "class", "score"],
        ["Rank", "Pair", "Surface", "Readout MeV", "Bridge Class", "Score"],
    )
    top_table = markdown_table(
        [
            {
                "rank": row["QP019_rank"],
                "pair": row["suk055_pair"],
                "qp018": row["qp018_selector_class"],
                "surface": row["selected_surface"] or "none",
                "class": row["QP019_bridge_class"],
                "promote": row["promote_to_native_mass_surface"],
            }
            for row in bridge_rows[:10]
        ],
        ["rank", "pair", "qp018", "surface", "class", "promote"],
        ["Rank", "Pair", "QP018 Class", "Surface", "QP019 Class", "Promote"],
    )
    surface_table = markdown_table(
        [
            {
                "surface": row["selected_surface"],
                "rows": row["rows"],
                "promoted": row["promoted_mass_surfaces"],
                "top": row["top_pair"],
            }
            for row in surface_rows
        ],
        ["surface", "rows", "promoted", "top"],
        ["Surface", "Rows", "Promoted", "Top Pair"],
    )

    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP019 - Private Particle Slot To Native Mass Surface Bridge

## Verdict

`{summary['result_class']}`

QP019 connects the QP018-promoted particle slots to native mass-surface
readouts already selected by QP007/QP008.

Core rule:

```text
QP018 promoted slot
-> QP008 selected surface
-> matching QP007 native mass surface
-> QP019 mass-surface bridge
```

## Main Read

```text
slot rows = {summary['slot_rows']}
promoted native mass surfaces = {summary['promoted_native_mass_surfaces']}
stable anchor mass bridges = {summary['stable_anchor_mass_bridges']}
boundary reorganization mass bridges = {summary['boundary_reorganization_mass_bridges']}
outside-bridge selected mass surfaces = {summary['outside_bridge_selected_mass_surfaces']}
roadblock = {summary['roadblock']}
free parameters introduced = {summary['free_parameters_introduced']}
```

## Promoted Mass Surfaces

{promoted_table}

## Top Bridge Rows

{top_table}

## Surface Summary

{surface_table}

## Meaning

QP019 is not a roadblock. Both QP018-promoted particle slots reach native
mass-surface readouts:

```text
stable neutral slot:
  {summary['stable_anchor_pair']} -> {summary['stable_anchor_mass_readout_MeV']} MeV

boundary/reorganization slot:
  {summary['boundary_pair']} -> {summary['boundary_mass_readout_MeV']} MeV
```

This closes the immediate bridge:

```text
unresolved route
-> stable mode
-> role/operator
-> particle slot
-> native mass surface
```

## Outputs

```text
qp019_particle_slot_native_mass_surface_bridge.csv
qp019_mass_surface_summary.csv
qp019_schema.csv
qp019_summary.json
qp019_next_frontier.csv
```

## Next Frontier

`QP020_PRIVATE_QP_TO_PARTICLE_BRIDGE_READINESS_PACKAGE`

QP020 should freeze the private technical package and decide whether this arc is
ready for package/preprint planning or needs another private gate.

Generated at UTC: `{summary['generated_at_utc']}`
""",
        encoding="utf-8",
    )


def main() -> int:
    generated_at = datetime.now(timezone.utc).isoformat()
    selector_rows = read_csv(QP018_SELECTOR_IN)
    qp007_rows = read_csv(QP007_TRIALS_IN)
    qp008_rows = read_csv(QP008_SELECTED_IN)
    qp018_summary = read_json(QP018_SUMMARY_IN)
    qp007_summary = read_json(QP007_SUMMARY_IN)
    qp008_summary = read_json(QP008_SUMMARY_IN)

    bridge_rows = build_bridge_rows(selector_rows, index_qp008(qp008_rows), index_qp007(qp007_rows))
    surface_rows = build_surface_rows(bridge_rows)
    schema_rows = build_schema_rows()

    promoted = [row for row in bridge_rows if row["promote_to_native_mass_surface"]]
    stable = [row for row in promoted if row["QP019_bridge_class"] == "STABLE_ANCHOR_MASS_SURFACE_BRIDGED"]
    boundary = [row for row in promoted if row["QP019_bridge_class"] == "BOUNDARY_REORGANIZATION_MASS_SURFACE_BRIDGED"]
    outside = [row for row in bridge_rows if row["QP019_bridge_class"] == "MASS_SURFACE_EXISTS_OUTSIDE_QP017_BRIDGE"]
    class_counts = Counter(str(row["QP019_bridge_class"]) for row in bridge_rows)

    roadblock = not (len(stable) >= 1 and len(boundary) >= 1)
    stable_top = max(stable, key=lambda row: float(row["mass_surface_bridge_score"])) if stable else {}
    boundary_top = max(boundary, key=lambda row: float(row["mass_surface_bridge_score"])) if boundary else {}

    summary = {
        "artifact": "QP019_PRIVATE_PARTICLE_SLOT_TO_NATIVE_MASS_SURFACE_BRIDGE",
        "result_class": "QP019_PRIVATE_PARTICLE_SLOT_TO_NATIVE_MASS_SURFACE_BRIDGE_BUILT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "inputs": {
            "qp018": qp018_summary["artifact"],
            "qp007": qp007_summary["artifact"],
            "qp008": qp008_summary["artifact"],
        },
        "law": "QP018-promoted slots carry existing QP008 selected surfaces into QP007 native mass-surface readouts",
        "slot_rows": len(bridge_rows),
        "promoted_native_mass_surfaces": len(promoted),
        "stable_anchor_mass_bridges": len(stable),
        "boundary_reorganization_mass_bridges": len(boundary),
        "outside_bridge_selected_mass_surfaces": len(outside),
        "selector_class_counts": dict(class_counts),
        "roadblock": roadblock,
        "stable_anchor_pair": stable_top.get("suk055_pair", ""),
        "stable_anchor_mass_readout_MeV": stable_top.get("selected_mass_readout_MeV", ""),
        "stable_anchor_surface": stable_top.get("selected_surface", ""),
        "boundary_pair": boundary_top.get("suk055_pair", ""),
        "boundary_mass_readout_MeV": boundary_top.get("selected_mass_readout_MeV", ""),
        "boundary_surface": boundary_top.get("selected_surface", ""),
        "core_interpretation": "QP019 bridges b<->s and c<->s from QP018 particle slots into native mass-surface readouts",
        "next_frontier": "QP020_PRIVATE_QP_TO_PARTICLE_BRIDGE_READINESS_PACKAGE",
    }

    bridge_fields = [
        "QP019_rank",
        "suk055_pair",
        "oriented_symbols",
        "phase_role_operator",
        "qp018_selector_class",
        "qp017_role_surface",
        "qp017_source_pair",
        "slot_selector_score",
        "selected_surface",
        "surface_selector_basis",
        "seed_role_operator",
        "selected_integer_shift",
        "required_effective_shift",
        "integer_shift_delta",
        "integer_shift_contact_class",
        "selected_mass_readout_MeV",
        "target_internal_surface_MeV",
        "readout_to_surface_ratio",
        "absolute_surface_delta_MeV",
        "qp007_surface_mass_MeV",
        "qp007_observed_composite_mass_used",
        "contact_tightness",
        "mass_surface_bridge_score",
        "QP019_bridge_class",
        "promote_to_native_mass_surface",
        "SAM_reading",
    ]
    surface_fields = ["selected_surface", "rows", "promoted_mass_surfaces", "max_mass_surface_bridge_score", "top_pair"]
    schema_fields = ["quantity", "definition", "role"]
    next_fields = ["next_frontier", "why_next", "input_surface", "target_output"]

    write_csv(BRIDGE_OUT, bridge_rows, bridge_fields)
    write_csv(SURFACE_OUT, surface_rows, surface_fields)
    write_csv(SCHEMA_OUT, schema_rows, schema_fields)
    write_csv(
        NEXT_OUT,
        [
            {
                "next_frontier": "QP020_PRIVATE_QP_TO_PARTICLE_BRIDGE_READINESS_PACKAGE",
                "why_next": "QP019 is not a roadblock; QP020 should freeze the private QP-to-particle bridge and produce a package/preprint readiness verdict.",
                "input_surface": "qp019_particle_slot_native_mass_surface_bridge.csv",
                "target_output": "private QP to particle bridge readiness package",
            }
        ],
        next_fields,
    )
    write_json(SUMMARY_OUT, summary)
    write_report(summary, bridge_rows, surface_rows)

    print(summary["result_class"])
    print(f"promoted_native_mass_surfaces={summary['promoted_native_mass_surfaces']}")
    print(f"stable_anchor_mass_bridges={summary['stable_anchor_mass_bridges']}")
    print(f"boundary_reorganization_mass_bridges={summary['boundary_reorganization_mass_bridges']}")
    print(f"roadblock={summary['roadblock']}")
    print(f"stable_anchor_pair={summary['stable_anchor_pair']}")
    print(f"boundary_pair={summary['boundary_pair']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
