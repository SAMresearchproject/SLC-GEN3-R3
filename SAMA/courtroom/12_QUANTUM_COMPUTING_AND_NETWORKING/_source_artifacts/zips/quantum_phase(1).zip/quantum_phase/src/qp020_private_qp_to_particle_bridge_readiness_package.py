from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP020_DIR = ARTIFACTS / "qp020"

SUMMARY_PATHS = {
    "QP010": ARTIFACTS / "qp010" / "qp010_protected_route_boundary_summary.json",
    "QP011": ARTIFACTS / "qp011" / "qp011_summary.json",
    "QP012": ARTIFACTS / "qp012" / "qp012_summary.json",
    "QP012B": ARTIFACTS / "qp012b" / "qp012b_summary.json",
    "QP013": ARTIFACTS / "qp013" / "qp013_summary.json",
    "QP014": ARTIFACTS / "qp014" / "qp014_summary.json",
    "QP015": ARTIFACTS / "qp015" / "qp015_summary.json",
    "QP016": ARTIFACTS / "qp016" / "qp016_summary.json",
    "QP017": ARTIFACTS / "qp017" / "qp017_summary.json",
    "QP018": ARTIFACTS / "qp018" / "qp018_summary.json",
    "QP019": ARTIFACTS / "qp019" / "qp019_summary.json",
}

QP019_BRIDGE_IN = ARTIFACTS / "qp019" / "qp019_particle_slot_native_mass_surface_bridge.csv"

SUMMARY_OUT = QP020_DIR / "qp020_readiness_summary.json"
CHAIN_OUT = QP020_DIR / "qp020_bridge_chain_table.csv"
OPEN_OUT = QP020_DIR / "qp020_open_items.csv"
MANIFEST_OUT = QP020_DIR / "qp020_package_manifest.csv"
NEXT_OUT = QP020_DIR / "qp020_next_frontier.csv"
DOC_OUT = REPORTS / "QP020_PRIVATE_QP_TO_PARTICLE_BRIDGE_READINESS_PACKAGE.md"


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fmt(value: object) -> str:
    if isinstance(value, float):
        return f"{value:.12g}"
    return str(value)


def build_chain_rows(summaries: dict[str, dict[str, object]]) -> list[dict[str, object]]:
    return [
        {
            "gate": "QP010",
            "bridge_step": "protected route boundary law",
            "artifact": summaries["QP010"]["artifact"],
            "main_output": summaries["QP010"]["top_protected_route"],
            "free_parameters_introduced": summaries["QP010"]["free_parameters_introduced"],
            "external_data_used": summaries["QP010"].get("external_data_used", False),
            "chain_role": "QC clue launch pad for protected unresolved route grammar",
        },
        {
            "gate": "QP011",
            "bridge_step": "decoherence as ledger leakage",
            "artifact": summaries["QP011"]["artifact"],
            "main_output": summaries["QP011"]["top_decoherence_protected_route"],
            "free_parameters_introduced": summaries["QP011"]["free_parameters_introduced"],
            "external_data_used": summaries["QP011"].get("external_data_used", False),
            "chain_role": "uncontrolled A leakage explains route damage before selected write",
        },
        {
            "gate": "QP012-QP012B",
            "bridge_step": "syndrome/pre-resolution letter",
            "artifact": summaries["QP012"]["artifact"] + " + " + summaries["QP012B"]["artifact"],
            "main_output": summaries["QP012B"]["top_lead_route"],
            "free_parameters_introduced": int(summaries["QP012"]["free_parameters_introduced"])
            + int(summaries["QP012B"]["free_parameters_introduced"]),
            "external_data_used": summaries["QP012"].get("external_data_used", False)
            or summaries["QP012B"].get("external_data_used", False),
            "chain_role": "boundary write can precede logical route resolution",
        },
        {
            "gate": "QP013",
            "bridge_step": "A-contact suppression",
            "artifact": summaries["QP013"]["artifact"],
            "main_output": summaries["QP013"]["top_control_route"],
            "free_parameters_introduced": summaries["QP013"]["free_parameters_introduced"],
            "external_data_used": summaries["QP013"].get("external_data_used", False),
            "chain_role": "control channels preserve unresolved route behavior",
        },
        {
            "gate": "QP014",
            "bridge_step": "Born-style route weights",
            "artifact": summaries["QP014"]["artifact"],
            "main_output": summaries["QP014"]["top_route_prior_qubit"],
            "free_parameters_introduced": summaries["QP014"]["free_parameters_introduced"],
            "external_data_used": summaries["QP014"].get("external_data_used", False),
            "chain_role": "probability becomes normalized unresolved route strength",
        },
        {
            "gate": "QP015",
            "bridge_step": "interference to ledger commit",
            "artifact": summaries["QP015"]["artifact"],
            "main_output": summaries["QP015"]["top_latest_open_commit_pair"],
            "free_parameters_introduced": summaries["QP015"]["free_parameters_introduced"],
            "external_data_used": summaries["QP015"].get("external_data_used", False),
            "chain_role": "route probability becomes ledger-intersection probability",
        },
        {
            "gate": "QP016",
            "bridge_step": "stable mode selector",
            "artifact": summaries["QP016"]["artifact"],
            "main_output": summaries["QP016"]["top_stable_mode_pair"],
            "free_parameters_introduced": summaries["QP016"]["free_parameters_introduced"],
            "external_data_used": summaries["QP016"].get("external_data_used", False),
            "chain_role": "stable closure and boundary reorganization split out of commit field",
        },
        {
            "gate": "QP017",
            "bridge_step": "role/operator bridge",
            "artifact": summaries["QP017"]["artifact"],
            "main_output": summaries["QP017"]["top_promoted_pair"],
            "free_parameters_introduced": summaries["QP017"]["free_parameters_introduced"],
            "external_data_used": summaries["QP017"].get("external_data_used", False),
            "chain_role": "stable/boundary modes promote into particle role/operator lanes",
        },
        {
            "gate": "QP018",
            "bridge_step": "particle-slot selector",
            "artifact": summaries["QP018"]["artifact"],
            "main_output": summaries["QP018"]["top_promoted_slot"] + " and " + summaries["QP018"]["top_boundary_slot"],
            "free_parameters_introduced": summaries["QP018"]["free_parameters_introduced"],
            "external_data_used": summaries["QP018"].get("external_data_used", False),
            "chain_role": "role/operator bridge selects particle slots",
        },
        {
            "gate": "QP019",
            "bridge_step": "native mass-surface bridge",
            "artifact": summaries["QP019"]["artifact"],
            "main_output": summaries["QP019"]["stable_anchor_pair"] + " and " + summaries["QP019"]["boundary_pair"],
            "free_parameters_introduced": summaries["QP019"]["free_parameters_introduced"],
            "external_data_used": summaries["QP019"].get("external_data_used", False),
            "chain_role": "selected particle slots carry native mass-surface readouts",
        },
    ]


def build_open_rows() -> list[dict[str, str]]:
    return [
        {
            "item": "charged role/operator lane",
            "status": "OPEN_OUTSIDE_QP017_QP019_BRIDGE",
            "why_it_matters": "QP008 contains charged selected mass surfaces, but QP017-QP019 did not promote the dual-polarity charged lane.",
            "suggested_next_action": "Hold for a targeted QP021 charged-lane bridge only after private package review.",
        },
        {
            "item": "held-open neutral slots",
            "status": "OPEN_HELD_SURFACE",
            "why_it_matters": "QP018 marks four reachable neutral-family slots as held open without selected mass readouts.",
            "suggested_next_action": "Keep in the package as reachable-but-unpromoted evidence.",
        },
        {
            "item": "QP010 external clue provenance",
            "status": "DOCUMENTED_CLUE_INPUT",
            "why_it_matters": "QP010 used quantum-computing clue data; QP011-QP019 then proceed internally with zero new free parameters.",
            "suggested_next_action": "Preserve the distinction in any private package or preprint shell.",
        },
        {
            "item": "public release posture",
            "status": "HOLD_PRIVATE",
            "why_it_matters": "The chain is strong enough to freeze privately, but packaging should precede any public flag staking.",
            "suggested_next_action": "Create a private review bundle before drafting a public preprint.",
        },
    ]


def build_manifest_rows() -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for gate in ("qp010", "qp011", "qp012", "qp012b", "qp013", "qp014", "qp015", "qp016", "qp017", "qp018", "qp019", "qp020"):
        artifact_dir = ARTIFACTS / gate
        if artifact_dir.exists():
            for path in sorted(artifact_dir.iterdir()):
                if path.is_file():
                    rows.append(
                        {
                            "package_section": "artifacts",
                            "relative_path": str(path.relative_to(ROOT)),
                            "included": "True",
                        }
                    )
    for path in sorted(REPORTS.glob("QP0*_PRIVATE_*.md")):
        rows.append(
            {
                "package_section": "reports",
                "relative_path": str(path.relative_to(ROOT)),
                "included": "True",
            }
        )
    return rows


def markdown_table(rows: list[dict[str, object]], fields: list[str], headers: list[str]) -> str:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(fmt(row[field]) for field in fields) + " |")
    return "\n".join(lines)


def write_report(summary: dict[str, object], chain_rows: list[dict[str, object]], open_rows: list[dict[str, str]]) -> None:
    chain_table = markdown_table(
        chain_rows,
        ["gate", "bridge_step", "main_output", "free_parameters_introduced", "external_data_used"],
        ["Gate", "Bridge Step", "Main Output", "Free Params", "External Data"],
    )
    open_table = markdown_table(
        open_rows,
        ["item", "status", "suggested_next_action"],
        ["Item", "Status", "Suggested Next Action"],
    )

    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP020 - Private QP To Particle Bridge Readiness Package

## Verdict

`{summary['result_class']}`

Readiness class:

```text
{summary['readiness_class']}
```

QP020 freezes the private QP-to-particle bridge chain for review.

## Stop Rule

```text
continuous bridge from protected route to native mass surface = {summary['continuous_bridge_to_mass_surface']}
QP019 roadblock = {summary['qp019_roadblock']}
free parameters introduced across QP010-QP019 = {summary['total_free_parameters_introduced']}
bridge gates after QP010 using external data = {summary['post_qp010_external_data_gates']}
private freeze recommended = {summary['private_freeze_recommended']}
```

## Chain Table

{chain_table}

## Current Closed Surface

```text
protected unresolved route
-> decoherence / leakage
-> syndrome boundary write
-> pre-resolution route letter
-> A-contact suppression
-> Born-style route weights
-> interference / ledger commit
-> stable mode selector
-> role/operator bridge
-> particle-slot selector
-> native mass-surface bridge
```

Current selected mass surfaces:

```text
stable neutral slot:
  {summary['stable_anchor_pair']} -> {summary['stable_anchor_mass_readout_MeV']} MeV

boundary/reorganization slot:
  {summary['boundary_pair']} -> {summary['boundary_mass_readout_MeV']} MeV
```

## Open Items

{open_table}

## Package Verdict

```text
private package: ready to freeze for review
public preprint: hold until private review
next work: either package review or targeted QP021 charged-lane bridge
```

## Outputs

```text
qp020_bridge_chain_table.csv
qp020_open_items.csv
qp020_package_manifest.csv
qp020_readiness_summary.json
qp020_next_frontier.csv
```

Generated at UTC: `{summary['generated_at_utc']}`
""",
        encoding="utf-8",
    )


def main() -> int:
    generated_at = datetime.now(timezone.utc).isoformat()
    summaries = {gate: read_json(path) for gate, path in SUMMARY_PATHS.items()}
    qp019_bridge_rows = read_csv(QP019_BRIDGE_IN)

    chain_rows = build_chain_rows(summaries)
    open_rows = build_open_rows()
    manifest_rows = build_manifest_rows()

    total_free_params = sum(int(row["free_parameters_introduced"]) for row in chain_rows)
    external_gates = [row["gate"] for row in chain_rows if row["external_data_used"] is True]
    post_qp010_external = [gate for gate in external_gates if gate != "QP010"]
    promoted_mass_rows = [
        row for row in qp019_bridge_rows if row["promote_to_native_mass_surface"] == "True"
    ]
    continuous_bridge = (
        summaries["QP016"]["stable_selected_modes"] >= 1
        and summaries["QP016"]["boundary_reorganization_candidates"] >= 1
        and summaries["QP017"]["role_lane_promotions"] >= 2
        and summaries["QP018"]["particle_slot_promotions"] >= 2
        and summaries["QP019"]["promoted_native_mass_surfaces"] >= 2
        and summaries["QP019"]["roadblock"] is False
    )
    private_freeze = continuous_bridge and total_free_params == 0 and not post_qp010_external

    summary = {
        "artifact": "QP020_PRIVATE_QP_TO_PARTICLE_BRIDGE_READINESS_PACKAGE",
        "result_class": "QP020_PRIVATE_QP_TO_PARTICLE_BRIDGE_READINESS_PACKAGE_BUILT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_PACKAGE_SYNTHESIS",
        "is_audit_or_retest": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "readiness_class": "PRIVATE_PACKAGE_READY_FOR_REVIEW_FREEZE"
        if private_freeze
        else "PRIVATE_PACKAGE_NEEDS_ANOTHER_GATE",
        "continuous_bridge_to_mass_surface": continuous_bridge,
        "private_freeze_recommended": private_freeze,
        "public_preprint_posture": "HOLD_UNTIL_PRIVATE_PACKAGE_REVIEW",
        "qp019_roadblock": summaries["QP019"]["roadblock"],
        "total_free_parameters_introduced": total_free_params,
        "external_data_gates": external_gates,
        "post_qp010_external_data_gates": post_qp010_external,
        "chain_rows": len(chain_rows),
        "package_manifest_rows": len(manifest_rows),
        "promoted_mass_surface_rows": len(promoted_mass_rows),
        "stable_anchor_pair": summaries["QP019"]["stable_anchor_pair"],
        "stable_anchor_mass_readout_MeV": summaries["QP019"]["stable_anchor_mass_readout_MeV"],
        "boundary_pair": summaries["QP019"]["boundary_pair"],
        "boundary_mass_readout_MeV": summaries["QP019"]["boundary_mass_readout_MeV"],
        "recommended_next_action": "freeze private package and review before public preprint planning",
        "optional_next_gate": "QP021_PRIVATE_CHARGED_LANE_BRIDGE"
        if private_freeze
        else "QP020A_PRIVATE_PACKAGE_GAP_RESOLUTION",
    }

    chain_fields = [
        "gate",
        "bridge_step",
        "artifact",
        "main_output",
        "free_parameters_introduced",
        "external_data_used",
        "chain_role",
    ]
    open_fields = ["item", "status", "why_it_matters", "suggested_next_action"]
    manifest_fields = ["package_section", "relative_path", "included"]
    next_fields = ["next_frontier", "why_next", "input_surface", "target_output"]

    write_csv(CHAIN_OUT, chain_rows, chain_fields)
    write_csv(OPEN_OUT, open_rows, open_fields)
    write_csv(MANIFEST_OUT, manifest_rows, manifest_fields)
    write_csv(
        NEXT_OUT,
        [
            {
                "next_frontier": summary["optional_next_gate"],
                "why_next": summary["recommended_next_action"],
                "input_surface": "qp020_readiness_summary.json",
                "target_output": "private review decision or targeted charged-lane bridge",
            }
        ],
        next_fields,
    )
    write_json(SUMMARY_OUT, summary)
    write_report(summary, chain_rows, open_rows)

    print(summary["result_class"])
    print(f"readiness_class={summary['readiness_class']}")
    print(f"continuous_bridge_to_mass_surface={summary['continuous_bridge_to_mass_surface']}")
    print(f"private_freeze_recommended={summary['private_freeze_recommended']}")
    print(f"public_preprint_posture={summary['public_preprint_posture']}")
    print(f"optional_next_gate={summary['optional_next_gate']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
