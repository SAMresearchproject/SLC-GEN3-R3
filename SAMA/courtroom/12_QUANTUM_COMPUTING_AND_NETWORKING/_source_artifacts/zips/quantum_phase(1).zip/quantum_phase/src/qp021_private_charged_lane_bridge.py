from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP004_DIR = ARTIFACTS / "qp004"
QP017_DIR = ARTIFACTS / "qp017"
QP019_DIR = ARTIFACTS / "qp019"
QP020_DIR = ARTIFACTS / "qp020"
QP021_DIR = ARTIFACTS / "qp021"

QP004_ROLE_IN = QP004_DIR / "qp004_phase_to_particle_role_operator_bridge.csv"
QP017_BRIDGE_IN = QP017_DIR / "qp017_stable_mode_role_operator_bridge.csv"
QP019_MASS_IN = QP019_DIR / "qp019_particle_slot_native_mass_surface_bridge.csv"
QP020_SUMMARY_IN = QP020_DIR / "qp020_readiness_summary.json"

SUMMARY_OUT = QP021_DIR / "qp021_summary.json"
ROUTE_OUT = QP021_DIR / "qp021_charged_route_support.csv"
MASS_OUT = QP021_DIR / "qp021_charged_particle_mass_bridge.csv"
FREEZE_OUT = QP021_DIR / "qp021_freeze_decision.csv"
SCHEMA_OUT = QP021_DIR / "qp021_schema.csv"
DOC_OUT = REPORTS / "QP021_PRIVATE_CHARGED_LANE_BRIDGE.md"


CHARGED_ROLE = "DUAL_POLARITY_CHARGED_HEAVY_ROLE_OPERATOR"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def normalize_pair(pair: str) -> str:
    left, right = pair.split("<->", 1)
    return "<->".join(sorted([left, right]))


def split_pairs(value: str) -> list[str]:
    return [normalize_pair(item.strip()) for item in value.split(";") if item.strip()]


def fmt(value: object) -> str:
    if isinstance(value, float):
        return f"{value:.12g}"
    return str(value)


def charged_required_pairs(role_rows: list[dict[str, str]]) -> list[str]:
    pairs: set[str] = set()
    for row in role_rows:
        if row["phase_role_operator"] == CHARGED_ROLE:
            pairs.update(split_pairs(row["required_phase_pairs"]))
    return sorted(pairs)


def build_route_rows(required_pairs: list[str], qp017_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    by_pair = {normalize_pair(row["route_pair"]): row for row in qp017_rows}
    rows: list[dict[str, object]] = []
    for pair in required_pairs:
        row = by_pair.get(pair)
        direct_role_match = row is not None and CHARGED_ROLE in row["direct_qp004_role_operators"]
        carrier_contact = row is not None and row["role_bridge_class"] == "TRANSIENT_DIRECT_ROLE_CONTACT_REJECTED"
        status = (
            "CHARGED_CARRIER_CONTACT_AVAILABLE"
            if direct_role_match and carrier_contact
            else "CHARGED_CARRIER_CONTACT_MISSING"
            if row is None
            else "CHARGED_CARRIER_CONTACT_NOT_IN_REQUIRED_CLASS"
        )
        rows.append(
            {
                "required_route_pair": pair,
                "qp017_row_found": row is not None,
                "qp017_selector_class": row["qp016_selector_class"] if row else "",
                "qp017_role_bridge_class": row["role_bridge_class"] if row else "",
                "direct_role_operators": row["direct_qp004_role_operators"] if row else "",
                "route_i_roles": row["route_i_role_operators"] if row else "",
                "route_j_roles": row["route_j_role_operators"] if row else "",
                "carrier_contact_available": direct_role_match and carrier_contact,
                "charged_route_status": status,
                "SAM_reading": (
                    "charged lane requires transient paired direct contacts, not a neutral stable self-closure"
                    if direct_role_match and carrier_contact
                    else "charged carrier requirement is not currently complete"
                ),
            }
        )
    return rows


def build_mass_rows(qp019_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for row in qp019_rows:
        if row["phase_role_operator"] != CHARGED_ROLE:
            continue
        selected_mass_exists = row["QP019_bridge_class"] == "MASS_SURFACE_EXISTS_OUTSIDE_QP017_BRIDGE"
        reachable_mass = selected_mass_exists and row["selected_mass_readout_MeV"] != ""
        charged_status = (
            "CHARGED_SELECTED_MASS_SURFACE_AVAILABLE"
            if reachable_mass
            else "CHARGED_SLOT_UNSELECTED_NO_MASS_SURFACE"
        )
        rows.append(
            {
                "suk055_pair": row["suk055_pair"],
                "oriented_symbols": row["oriented_symbols"],
                "qp018_selector_class": row["qp018_selector_class"],
                "qp019_bridge_class": row["QP019_bridge_class"],
                "selected_surface": row["selected_surface"],
                "selected_mass_readout_MeV": row["selected_mass_readout_MeV"],
                "integer_shift_contact_class": row["integer_shift_contact_class"],
                "contact_tightness": row["contact_tightness"],
                "selected_charged_mass_surface": reachable_mass,
                "charged_mass_status": charged_status,
                "SAM_reading": (
                    "selected charged mass surface exists outside the neutral/boundary QP017 bridge"
                    if reachable_mass
                    else "charged scaffold remains unselected in the current particle slot lane"
                ),
            }
        )
    rows.sort(
        key=lambda item: (
            0 if item["selected_charged_mass_surface"] else 1,
            -float(item["contact_tightness"] or 0),
            item["suk055_pair"],
        )
    )
    return rows


def decide_result(route_rows: list[dict[str, object]], mass_rows: list[dict[str, object]]) -> tuple[str, str, bool]:
    required_route_count = len(route_rows)
    supported_routes = sum(1 for row in route_rows if row["carrier_contact_available"] is True)
    selected_mass_count = sum(1 for row in mass_rows if row["selected_charged_mass_surface"] is True)
    if supported_routes == required_route_count and selected_mass_count >= 2:
        return (
            "SUCCESS_CHARGED_PARALLEL_CARRIER_BRIDGE",
            "QP021_PRIVATE_CHARGED_LANE_BRIDGE_BUILT",
            True,
        )
    if supported_routes == required_route_count or selected_mass_count >= 1:
        return (
            "BOUNDARY_CHARGED_LANE_PHASE2_START",
            "QP021_PRIVATE_CHARGED_LANE_BOUNDARY_FOR_PHASE2",
            False,
        )
    return (
        "FAIL_CHARGED_LANE_NOT_SUPPORTED",
        "QP021_PRIVATE_CHARGED_LANE_BRIDGE_FAILED",
        False,
    )


def build_schema_rows() -> list[dict[str, str]]:
    return [
        {
            "quantity": "SUCCESS_CHARGED_PARALLEL_CARRIER_BRIDGE",
            "definition": "both required charged carrier contacts are present and at least two selected charged mass surfaces exist",
            "role": "success; freeze package with charged lane documented",
        },
        {
            "quantity": "BOUNDARY_CHARGED_LANE_PHASE2_START",
            "definition": "route support or mass support is partial, but not enough to freeze as closed",
            "role": "phase 2 starting point",
        },
        {
            "quantity": "CHARGED_CARRIER_CONTACT_AVAILABLE",
            "definition": "QP017 contains a required charged direct role contact as a transient carrier",
            "role": "charged lane route support",
        },
        {
            "quantity": "CHARGED_SELECTED_MASS_SURFACE_AVAILABLE",
            "definition": "QP019 contains a selected charged mass surface outside the QP017 neutral/boundary bridge",
            "role": "charged lane mass support",
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str], headers: list[str]) -> str:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(fmt(row[field]) for field in fields) + " |")
    return "\n".join(lines)


def write_report(summary: dict[str, object], route_rows: list[dict[str, object]], mass_rows: list[dict[str, object]]) -> None:
    route_table = markdown_table(
        route_rows,
        ["required_route_pair", "qp017_role_bridge_class", "carrier_contact_available"],
        ["Required Pair", "QP017 Class", "Carrier Contact"],
    )
    mass_table = markdown_table(
        [
            row
            for row in mass_rows
            if row["selected_charged_mass_surface"] is True
        ],
        ["suk055_pair", "selected_surface", "selected_mass_readout_MeV", "charged_mass_status"],
        ["Pair", "Surface", "Readout MeV", "Status"],
    )

    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP021 - Private Charged Lane Bridge

## Verdict

`{summary['result_class']}`

Charged lane status:

```text
{summary['charged_lane_status']}
```

QP021 tests the open charged role/operator lane left by QP020.

Core rule:

```text
charged lane requires paired transient direct role contacts:
  QUBIT-CL-001<->QUBIT-TM-001
  QUBIT-CL-001<->QUBIT-TP-001

and selected charged mass surfaces:
  b<->c
  b<->t
```

## Main Read

```text
required charged route contacts = {summary['required_charged_route_contacts']}
supported charged route contacts = {summary['supported_charged_route_contacts']}
selected charged mass surfaces = {summary['selected_charged_mass_surfaces']}
charged lane success = {summary['charged_lane_success']}
private freeze recommended = {summary['private_freeze_recommended']}
free parameters introduced = {summary['free_parameters_introduced']}
```

## Route Support

{route_table}

## Selected Charged Mass Surfaces

{mass_table}

## Meaning

QP021 succeeds as a charged parallel-carrier bridge.

The charged lane is not promoted by the neutral stable anchor or the
NL/UNK boundary bridge. It travels through a paired transient direct-contact
carrier:

```text
CL<->TM
CL<->TP
```

That carrier links to selected charged mass surfaces already present in QP019:

```text
b<->c -> {summary['charged_mass_readouts'].get('b<->c', '')} MeV
b<->t -> {summary['charged_mass_readouts'].get('b<->t', '')} MeV
```

## Freeze Decision

```text
private package: freeze after QP021
phase 2: optional, not required before freeze
public posture: hold private
```

Generated at UTC: `{summary['generated_at_utc']}`
""",
        encoding="utf-8",
    )


def main() -> int:
    generated_at = datetime.now(timezone.utc).isoformat()
    qp004_rows = read_csv(QP004_ROLE_IN)
    qp017_rows = read_csv(QP017_BRIDGE_IN)
    qp019_rows = read_csv(QP019_MASS_IN)
    qp020_summary = read_json(QP020_SUMMARY_IN)

    required_pairs = charged_required_pairs(qp004_rows)
    route_rows = build_route_rows(required_pairs, qp017_rows)
    mass_rows = build_mass_rows(qp019_rows)
    charged_lane_status, result_class, success = decide_result(route_rows, mass_rows)
    selected_mass_rows = [row for row in mass_rows if row["selected_charged_mass_surface"] is True]
    charged_mass_readouts = {
        row["suk055_pair"]: row["selected_mass_readout_MeV"]
        for row in selected_mass_rows
    }
    selected_pair_counts = Counter(row["charged_mass_status"] for row in mass_rows)

    summary = {
        "artifact": "QP021_PRIVATE_CHARGED_LANE_BRIDGE",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "inputs": {
            "qp004": "QP004_PRIVATE_PHASE_TO_PARTICLE_ROLE_OPERATOR_BRIDGE",
            "qp017": "QP017_PRIVATE_STABLE_MODE_TO_ROLE_OPERATOR_BRIDGE",
            "qp019": "QP019_PRIVATE_PARTICLE_SLOT_TO_NATIVE_MASS_SURFACE_BRIDGE",
            "qp020": qp020_summary["artifact"],
        },
        "law": "charged lane closes through paired transient direct role contacts plus selected charged mass surfaces",
        "charged_lane_status": charged_lane_status,
        "required_charged_route_contacts": len(route_rows),
        "supported_charged_route_contacts": sum(
            1 for row in route_rows if row["carrier_contact_available"] is True
        ),
        "selected_charged_mass_surfaces": len(selected_mass_rows),
        "charged_mass_surface_counts": dict(selected_pair_counts),
        "charged_lane_success": success,
        "private_freeze_recommended": success,
        "phase2_start_required": charged_lane_status == "BOUNDARY_CHARGED_LANE_PHASE2_START",
        "failure_stop": charged_lane_status == "FAIL_CHARGED_LANE_NOT_SUPPORTED",
        "charged_mass_readouts": charged_mass_readouts,
        "package_posture": "FREEZE_AND_DOCUMENT"
        if success
        else "PHASE2_START"
        if charged_lane_status == "BOUNDARY_CHARGED_LANE_PHASE2_START"
        else "STOP_FOR_FAILURE_REVIEW",
        "core_interpretation": "charged lane is a parallel transient-carrier bridge, not a neutral stable-anchor bridge",
        "next_frontier": "PRIVATE_FREEZE_AND_HOSTILE_AUDIT"
        if success
        else "PHASE2_CHARGED_LANE_START"
        if charged_lane_status == "BOUNDARY_CHARGED_LANE_PHASE2_START"
        else "STOP",
    }

    route_fields = [
        "required_route_pair",
        "qp017_row_found",
        "qp017_selector_class",
        "qp017_role_bridge_class",
        "direct_role_operators",
        "route_i_roles",
        "route_j_roles",
        "carrier_contact_available",
        "charged_route_status",
        "SAM_reading",
    ]
    mass_fields = [
        "suk055_pair",
        "oriented_symbols",
        "qp018_selector_class",
        "qp019_bridge_class",
        "selected_surface",
        "selected_mass_readout_MeV",
        "integer_shift_contact_class",
        "contact_tightness",
        "selected_charged_mass_surface",
        "charged_mass_status",
        "SAM_reading",
    ]
    freeze_fields = ["decision", "value", "note"]
    schema_fields = ["quantity", "definition", "role"]

    write_csv(ROUTE_OUT, route_rows, route_fields)
    write_csv(MASS_OUT, mass_rows, mass_fields)
    write_csv(
        FREEZE_OUT,
        [
            {
                "decision": "package_posture",
                "value": summary["package_posture"],
                "note": "success freezes and documents; boundary becomes phase 2; failure stops",
            },
            {
                "decision": "next_frontier",
                "value": summary["next_frontier"],
                "note": "private repo only",
            },
        ],
        freeze_fields,
    )
    write_csv(SCHEMA_OUT, build_schema_rows(), schema_fields)
    write_json(SUMMARY_OUT, summary)
    write_report(summary, route_rows, mass_rows)

    print(summary["result_class"])
    print(f"charged_lane_status={summary['charged_lane_status']}")
    print(f"supported_charged_route_contacts={summary['supported_charged_route_contacts']}/{summary['required_charged_route_contacts']}")
    print(f"selected_charged_mass_surfaces={summary['selected_charged_mass_surfaces']}")
    print(f"package_posture={summary['package_posture']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
