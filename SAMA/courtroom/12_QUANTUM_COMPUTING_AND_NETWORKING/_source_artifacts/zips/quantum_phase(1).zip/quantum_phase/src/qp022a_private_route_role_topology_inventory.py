from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP001_DIR = ARTIFACTS / "qp001"
QP003_DIR = ARTIFACTS / "qp003"
QP004_DIR = ARTIFACTS / "qp004"
QP022A_DIR = ARTIFACTS / "qp022a"

QP001_ROUTES = QP001_DIR / "qp001_qubit_phase_functional_table.csv"
QP003_COUPLING = QP003_DIR / "qp003_interference_bounce_coupling_table.csv"
QP004_RULES = QP004_DIR / "qp004_phase_role_operator_rules.csv"

SUMMARY_OUT = QP022A_DIR / "qp022a_summary.json"
ROUTE_OUT = QP022A_DIR / "qp022a_route_inventory_table.csv"
EDGE_OUT = QP022A_DIR / "qp022a_derived_topology_edges.csv"
COMPARISON_OUT = QP022A_DIR / "qp022a_qp004_comparison_table.csv"
SCHEMA_OUT = QP022A_DIR / "qp022a_schema.csv"
NEXT_OUT = QP022A_DIR / "qp022a_next_frontier.csv"
DOC_OUT = REPORTS / "QP022A_PRIVATE_ROUTE_ROLE_TOPOLOGY_INVENTORY.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def pair_key(left: str, right: str) -> str:
    return "<->".join(sorted([left, right]))


def split_pairs(value: str) -> list[str]:
    return [pair_key(*item.strip().split("<->", 1)) for item in value.split(";") if item.strip()]


def fnum(value: object) -> float:
    return float(str(value).strip())


def fmt(value: float) -> str:
    return f"{value:.12g}"


def lower_route_family(row: dict[str, str]) -> tuple[str, str]:
    native_route = row["qubit_native_route"].lower()
    native_class = row["Q_native_class"].lower()

    if "integer_winding_neg_full" in native_class:
        return "HUB_CANDIDATE", "integer winding negative/full A-share route class"
    if "neutral_identity" in native_class or "outer_binary" in native_route:
        return "NEUTRAL_BINARY_IDENTITY_ENDPOINT", "neutral identity / outer-binary route grammar"
    if "triadic_screen_minus" in native_class:
        return "CHARGED_TRIADIC_MINUS_ENDPOINT", "triadic minus polarity route grammar"
    if "triadic_screen_plus" in native_class:
        return "CHARGED_TRIADIC_PLUS_ENDPOINT", "triadic plus polarity route grammar"
    if "binary_split__8_4" in native_route or "unknown_subchannel_mode" in native_class:
        return "TRANSITION_8_4_ENDPOINT", "8+4 transition route grammar"
    if "owner_triad" in native_route or "owner_axis" in native_class:
        return "TRANSITION_OWNER_COLOR_ENDPOINT", "owner/color route grammar"
    return "UNCLASSIFIED_ENDPOINT", "no lower route-family rule matched"


def bounce_pairs(coupling_rows: list[dict[str, str]]) -> set[str]:
    return {
        pair_key(row["route_i"], row["route_j"])
        for row in coupling_rows
        if row["coupling_status"] == "BOUNCE_RESPONSE_WRITE_COUPLING"
        and row["sample_id"] == "N_A_SHARE"
    }


def hub_from_bounce_topology(pairs: set[str]) -> tuple[str, list[dict[str, object]]]:
    partners: dict[str, set[str]] = defaultdict(set)
    for pair in pairs:
        left, right = pair.split("<->", 1)
        partners[left].add(right)
        partners[right].add(left)
    rows = [
        {
            "route": route,
            "a_share_bounce_degree": len(route_partners),
            "a_share_bounce_partners": ";".join(sorted(route_partners)),
            "has_self_bounce": route in route_partners,
        }
        for route, route_partners in sorted(partners.items())
    ]
    rows.sort(key=lambda row: (-int(row["a_share_bounce_degree"]), row["route"]))
    return str(rows[0]["route"]), rows


def role_family_from_endpoint(endpoint_family: str) -> str:
    if endpoint_family in {"NEUTRAL_BINARY_IDENTITY_ENDPOINT"}:
        return "DERIVED_NEUTRAL_BINARY_MIXING_TOPOLOGY"
    if endpoint_family in {"CHARGED_TRIADIC_MINUS_ENDPOINT", "CHARGED_TRIADIC_PLUS_ENDPOINT"}:
        return "DERIVED_DUAL_POLARITY_CHARGED_TOPOLOGY"
    if endpoint_family in {"TRANSITION_8_4_ENDPOINT", "TRANSITION_OWNER_COLOR_ENDPOINT"}:
        return "DERIVED_TRANSITION_COLOR_COUPLED_TOPOLOGY"
    return "DERIVED_UNCLASSIFIED_TOPOLOGY"


def qp004_rule_index(qp004_rows: list[dict[str, str]]) -> dict[frozenset[str], dict[str, str]]:
    index: dict[frozenset[str], dict[str, str]] = {}
    for row in qp004_rows:
        index[frozenset(split_pairs(row["required_phase_pairs"]))] = row
    return index


def build_schema_rows() -> list[dict[str, str]]:
    return [
        {
            "quantity": "DERIVED_TOPOLOGY_MATCHES_QP004_EXACTLY",
            "definition": "lower-only route grammar plus A-share bounce topology reconstructs all QP004 required phase-pair sets",
            "role": "pass class",
        },
        {
            "quantity": "DERIVED_TOPOLOGY_BOUNDARY_PARTIAL",
            "definition": "hub or some endpoint families are recovered, but at least one QP004 role-pair set is not reconstructed",
            "role": "boundary class",
        },
        {
            "quantity": "DERIVED_TOPOLOGY_CONFLICTS_WITH_QP004",
            "definition": "derived hub or edge family conflicts with QP004 required pair topology",
            "role": "failure class",
        },
        {
            "quantity": "support_challenge",
            "definition": "comparison checks QP004 only after lower-only derivation, not as selector input",
            "role": "provenance guard",
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str], headers: list[str]) -> str:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(summary: dict[str, object], comparison_rows: list[dict[str, object]], edge_rows: list[dict[str, object]]) -> None:
    comparison_table = markdown_table(
        comparison_rows,
        [
            "derived_role_family",
            "derived_required_phase_pairs",
            "matched_qp004_role_operator",
            "exact_qp004_pair_match",
        ],
        ["Derived Family", "Derived Pairs", "Matched QP004 Operator", "Exact Match"],
    )
    edge_table = markdown_table(
        edge_rows,
        ["derived_role_family", "route_pair", "endpoint_family", "a_share_bounce_available"],
        ["Derived Family", "Route Pair", "Endpoint Family", "A-share Bounce"],
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP022A - Private Route-Role Topology Inventory

## Verdict

`{summary['result_class']}`

QP022A starts phase 2 from the hostile-audit launchpad. It asks whether QP004's
route-role topology can be reconstructed from lower artifacts before QP004 role
labels are read.

## Selector Inputs

```text
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp003/qp003_interference_bounce_coupling_table.csv
```

## Comparison Target

```text
artifacts/qp004/qp004_phase_role_operator_rules.csv
```

QP004 is used only after the lower-only topology is derived.

## Main Result

```text
derived_hub_route = {summary['derived_hub_route']}
derived_role_families = {summary['derived_role_families']}
exact_qp004_rule_matches = {summary['exact_qp004_rule_matches']}/{summary['qp004_rule_count']}
selector_used_qp004_labels = {summary['selector_used_qp004_labels']}
free_parameters_introduced = {summary['free_parameters_introduced']}
```

## Derived Edges

{edge_table}

## QP004 Comparison

{comparison_table}

## Meaning

The lower phase route grammar plus A-share bounce topology recovers the same
CL-centered role topology that QP017B used as its audited selector.

This does not yet derive the full downstream particle table. It does move the
QP017B topology input upstream: QP004's required edge topology is recovered as
a lower SAM/QP structure rather than only imported as a bridge table.

## Next Frontier

`{summary['next_frontier']}`

Generated at UTC: `{summary['generated_at_utc']}`
""",
        encoding="utf-8",
    )


def main() -> int:
    generated_at = datetime.now(timezone.utc).isoformat()
    for path in [QP001_ROUTES, QP003_COUPLING, QP004_RULES]:
        if not path.exists():
            raise FileNotFoundError(path)

    route_rows_in = read_csv(QP001_ROUTES)
    coupling_rows = read_csv(QP003_COUPLING)
    qp004_rows = read_csv(QP004_RULES)

    a_share_pairs = bounce_pairs(coupling_rows)
    hub_route, hub_rows = hub_from_bounce_topology(a_share_pairs)
    qp004_index = qp004_rule_index(qp004_rows)

    endpoint_rows: list[dict[str, object]] = []
    derived_by_family: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in route_rows_in:
        family, reason = lower_route_family(row)
        hub_pair = pair_key(hub_route, row["qubit_id"])
        is_hub = row["qubit_id"] == hub_route
        role_family = role_family_from_endpoint(family)
        endpoint = {
            "route": row["qubit_id"],
            "qubit_native_route": row["qubit_native_route"],
            "Q_native_class": row["Q_native_class"],
            "A_exposure_per_t_SW": row["A_exposure_per_t_SW"],
            "ticks_to_A_SHARE": row["ticks_to_A_SHARE"],
            "derived_route_family": family,
            "derived_family_reason": reason,
            "derived_hub_route": hub_route,
            "is_derived_hub": is_hub,
            "hub_pair": "" if is_hub else hub_pair,
            "a_share_bounce_to_hub": False if is_hub else hub_pair in a_share_pairs,
            "derived_role_family": "" if is_hub else role_family,
        }
        endpoint_rows.append(endpoint)
        if not is_hub and role_family != "DERIVED_UNCLASSIFIED_TOPOLOGY":
            derived_by_family[role_family].append(endpoint)

    edge_rows: list[dict[str, object]] = []
    comparison_rows: list[dict[str, object]] = []
    matched_qp004_keys: set[frozenset[str]] = set()
    unmatched_derived_families: list[str] = []

    for family in sorted(derived_by_family):
        endpoints = sorted(derived_by_family[family], key=lambda item: str(item["route"]))
        pairs = [str(endpoint["hub_pair"]) for endpoint in endpoints]
        pairset = frozenset(pairs)
        matched = qp004_index.get(pairset)
        exact_match = matched is not None
        if exact_match:
            matched_qp004_keys.add(pairset)
        else:
            unmatched_derived_families.append(family)
        for endpoint in endpoints:
            edge_rows.append(
                {
                    "derived_role_family": family,
                    "hub_route": hub_route,
                    "endpoint_route": endpoint["route"],
                    "endpoint_family": endpoint["derived_route_family"],
                    "endpoint_reason": endpoint["derived_family_reason"],
                    "route_pair": endpoint["hub_pair"],
                    "a_share_bounce_available": endpoint["a_share_bounce_to_hub"],
                    "matched_qp004_role_operator": matched["phase_role_operator"] if matched else "",
                }
            )
        comparison_rows.append(
            {
                "derived_role_family": family,
                "derived_required_phase_pairs": ";".join(sorted(pairs)),
                "matched_qp004_target_route": matched["suk055_target_route"] if matched else "",
                "matched_qp004_role_operator": matched["phase_role_operator"] if matched else "",
                "matched_qp004_required_phase_pairs": matched["required_phase_pairs"] if matched else "",
                "exact_qp004_pair_match": exact_match,
                "pair_delta": "" if exact_match else "NO_EXACT_QP004_RULE_MATCH",
            }
        )

    qp004_rule_count = len(qp004_index)
    exact_matches = len(matched_qp004_keys)
    all_edges_have_bounce = all(row["a_share_bounce_available"] is True for row in edge_rows)
    one_hub_recovered = len(hub_rows) == len(route_rows_in) and hub_rows[0]["route"] == hub_route
    recovered_all_qp004 = exact_matches == qp004_rule_count and not unmatched_derived_families
    if one_hub_recovered and all_edges_have_bounce and recovered_all_qp004:
        result_class = "QP022A_DERIVED_TOPOLOGY_MATCHES_QP004_EXACTLY"
    elif one_hub_recovered and exact_matches:
        result_class = "QP022A_DERIVED_TOPOLOGY_BOUNDARY_PARTIAL"
    else:
        result_class = "QP022A_DERIVED_TOPOLOGY_CONFLICTS_WITH_QP004"

    route_inventory_rows = []
    hub_degree_by_route = {row["route"]: row for row in hub_rows}
    for endpoint in sorted(endpoint_rows, key=lambda item: int(next(row["QP001_phase_safety_rank"] for row in route_rows_in if row["qubit_id"] == item["route"]))):
        degree = hub_degree_by_route.get(str(endpoint["route"]), {})
        route_inventory_rows.append(
            {
                **endpoint,
                "a_share_bounce_degree": degree.get("a_share_bounce_degree", 0),
                "a_share_bounce_partners": degree.get("a_share_bounce_partners", ""),
            }
        )

    family_counts = Counter(row["derived_role_family"] for row in edge_rows)
    summary = {
        "artifact": "QP022A_PRIVATE_ROUTE_ROLE_TOPOLOGY_INVENTORY",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp001/qp001_qubit_phase_functional_table.csv",
            "artifacts/qp003/qp003_interference_bounce_coupling_table.csv",
        ],
        "comparison_only_inputs": [
            "artifacts/qp004/qp004_phase_role_operator_rules.csv",
        ],
        "selector_used_qp004_labels": False,
        "derived_hub_route": hub_route,
        "a_share_bounce_pairs": len(a_share_pairs),
        "derived_edges": len(edge_rows),
        "derived_role_families": len(derived_by_family),
        "derived_role_family_counts": dict(family_counts),
        "qp004_rule_count": qp004_rule_count,
        "exact_qp004_rule_matches": exact_matches,
        "unmatched_derived_families": unmatched_derived_families,
        "unmatched_qp004_rules": [
            ";".join(sorted(key))
            for key in qp004_index
            if key not in matched_qp004_keys
        ],
        "all_derived_edges_have_a_share_bounce": all_edges_have_bounce,
        "one_hub_recovered": one_hub_recovered,
        "topology_recovered_without_qp004_labels": result_class == "QP022A_DERIVED_TOPOLOGY_MATCHES_QP004_EXACTLY",
        "next_frontier": "QP022B_PRIVATE_CL_HUB_ORIGIN_RULE",
    }

    route_fields = [
        "route",
        "qubit_native_route",
        "Q_native_class",
        "A_exposure_per_t_SW",
        "ticks_to_A_SHARE",
        "derived_route_family",
        "derived_family_reason",
        "derived_hub_route",
        "is_derived_hub",
        "hub_pair",
        "a_share_bounce_to_hub",
        "derived_role_family",
        "a_share_bounce_degree",
        "a_share_bounce_partners",
    ]
    edge_fields = [
        "derived_role_family",
        "hub_route",
        "endpoint_route",
        "endpoint_family",
        "endpoint_reason",
        "route_pair",
        "a_share_bounce_available",
        "matched_qp004_role_operator",
    ]
    comparison_fields = [
        "derived_role_family",
        "derived_required_phase_pairs",
        "matched_qp004_target_route",
        "matched_qp004_role_operator",
        "matched_qp004_required_phase_pairs",
        "exact_qp004_pair_match",
        "pair_delta",
    ]

    write_csv(ROUTE_OUT, route_inventory_rows, route_fields)
    write_csv(EDGE_OUT, edge_rows, edge_fields)
    write_csv(COMPARISON_OUT, comparison_rows, comparison_fields)
    write_csv(SCHEMA_OUT, build_schema_rows(), ["quantity", "definition", "role"])
    write_csv(
        NEXT_OUT,
        [
            {
                "frontier": summary["next_frontier"],
                "why_next": "QP022A recovered the role topology from lower route grammar and A-share bounce topology. QP022B should isolate the CL hub origin rule so the hub is not merely observed from degree count.",
                "input_surface": "qp022a_route_inventory_table.csv;qp022a_derived_topology_edges.csv",
                "target_output": "private CL hub origin rule",
            }
        ],
        ["frontier", "why_next", "input_surface", "target_output"],
    )
    write_json(SUMMARY_OUT, summary)
    write_report(summary, comparison_rows, edge_rows)

    print(summary["result_class"])
    print(f"derived_hub_route={summary['derived_hub_route']}")
    print(f"derived_role_families={summary['derived_role_families']}")
    print(f"derived_edges={summary['derived_edges']}")
    print(f"exact_qp004_rule_matches={summary['exact_qp004_rule_matches']}/{summary['qp004_rule_count']}")
    print(f"all_derived_edges_have_a_share_bounce={summary['all_derived_edges_have_a_share_bounce']}")
    print(f"selector_used_qp004_labels={summary['selector_used_qp004_labels']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
