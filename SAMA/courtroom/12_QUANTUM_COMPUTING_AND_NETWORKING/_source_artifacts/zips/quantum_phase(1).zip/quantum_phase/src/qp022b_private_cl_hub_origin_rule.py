from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP001_ROUTES = ARTIFACTS / "qp001" / "qp001_qubit_phase_functional_table.csv"
QP003_COUPLING = ARTIFACTS / "qp003" / "qp003_interference_bounce_coupling_table.csv"
QP022A_INVENTORY = ARTIFACTS / "qp022a" / "qp022a_route_inventory_table.csv"
QP022A_SUMMARY = ARTIFACTS / "qp022a" / "qp022a_summary.json"

QP022B_DIR = ARTIFACTS / "qp022b"
PREFLIGHT_OUT = QP022B_DIR / "qp022b_preflight.md"
SUMMARY_OUT = QP022B_DIR / "qp022b_summary.json"
HUB_OUT = QP022B_DIR / "qp022b_hub_candidate_table.csv"
SUPPORT_OUT = QP022B_DIR / "qp022b_hub_support_edges.csv"
SCHEMA_OUT = QP022B_DIR / "qp022b_schema.csv"
NEXT_OUT = QP022B_DIR / "qp022b_next_frontier.csv"
DOC_OUT = REPORTS / "QP022B_PRIVATE_CL_HUB_ORIGIN_RULE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def pair_key(left: str, right: str) -> str:
    return "<->".join(sorted([left, right]))


def fnum(value: object) -> float:
    return float(str(value).strip())


def route_state_in_pair(row: dict[str, str], route: str) -> str:
    if row["route_i"] == route:
        return row["state_i"]
    if row["route_j"] == route:
        return row["state_j"]
    return ""


def partner_in_pair(row: dict[str, str], route: str) -> str:
    if row["route_i"] == route:
        return row["route_j"]
    if row["route_j"] == route:
        return row["route_i"]
    return ""


def is_hub_native_class(row: dict[str, str]) -> bool:
    return (
        row["Q_native_class"] == "INTEGER_WINDING_NEG_FULL"
        and "alpha_H^2*D" in row["qubit_native_route"]
        and row["subchannel_partition"] == "(12,)"
    )


def write_preflight() -> None:
    QP022B_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP022B Preflight - CL Hub Origin Rule

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

## Question

```text
Can the QUBIT-CL-001 hub be selected from lower route grammar and A-share
bounce topology rather than only observed as graph degree?
```

## Selector Inputs

```text
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp003/qp003_interference_bounce_coupling_table.csv
artifacts/qp022a/qp022a_route_inventory_table.csv
```

QP022A is allowed because it is the lower-derived route-family inventory from
the previous Phase 2 gate. QP004 is not a selector input.

## Pass

```text
exactly one route satisfies all hub-origin conditions:
  native negative/full integer-winding route
  reorganization onset at A_SHARE
  A-share bounce contact to every non-hub route family
  all QP022A derived endpoint families are covered
```

## Boundary

```text
CL is selected but uniqueness or endpoint coverage depends on an ambiguous rule.
```

## Failure

```text
CL is not selected or multiple routes satisfy the same hub-origin rule.
```
""",
        encoding="utf-8",
    )


def schema_rows() -> list[dict[str, str]]:
    return [
        {
            "quantity": "QP022B_CL_HUB_ORIGIN_RULE_SELECTED",
            "definition": "exactly one route satisfies native hub class, A-share reorganization onset, and full endpoint-family bounce coverage",
            "role": "pass class",
        },
        {
            "quantity": "HUB_NATIVE_CLASS",
            "definition": "INTEGER_WINDING_NEG_FULL on single_block__alpha_H^2*D__integer_winding with partition (12,)",
            "role": "lower route grammar condition",
        },
        {
            "quantity": "A_SHARE_REORGANIZATION_CENTER",
            "definition": "route appears at N_A_SHARE as REORGANIZATION_ONSET while coupled endpoints are write-accessible",
            "role": "dynamic hub condition",
        },
        {
            "quantity": "ENDPOINT_FAMILY_COVERAGE",
            "definition": "route has A-share bounce support to all non-hub QP022A endpoint routes/families",
            "role": "topological coverage condition",
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str], headers: list[str]) -> str:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(summary: dict[str, object], hub_rows: list[dict[str, object]], support_rows: list[dict[str, object]]) -> None:
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    hub_table = markdown_table(
        hub_rows,
        [
            "route",
            "hub_native_class",
            "has_reorganization_onset_at_A_SHARE",
            "endpoint_routes_covered",
            "endpoint_role_families_covered",
            "hub_origin_selected",
        ],
        ["Route", "Native Hub Class", "A-share Reorg", "Endpoint Routes", "Role Families", "Selected"],
    )
    support_table = markdown_table(
        support_rows,
        [
            "hub_route",
            "endpoint_route",
            "endpoint_family",
            "derived_role_family",
            "route_pair",
            "a_share_bounce_available",
        ],
        ["Hub", "Endpoint", "Endpoint Family", "Role Family", "Pair", "Bounce"],
    )
    DOC_OUT.write_text(
        f"""# QP022B - Private CL Hub Origin Rule

## Verdict

`{summary['result_class']}`

QP022B asks why `QUBIT-CL-001` is the hub recovered by QP022A.

## Selector Inputs

```text
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp003/qp003_interference_bounce_coupling_table.csv
artifacts/qp022a/qp022a_route_inventory_table.csv
```

No QP004 role labels are used as selector inputs.

## Main Result

```text
selected_hub_route = {summary['selected_hub_route']}
hub_origin_rule_unique = {summary['hub_origin_rule_unique']}
selected_hub_endpoint_routes_covered = {summary['selected_hub_endpoint_routes_covered']}
selected_hub_endpoint_role_families_covered = {summary['selected_hub_endpoint_role_families_covered']}
selector_used_qp004_labels = {summary['selector_used_qp004_labels']}
free_parameters_introduced = {summary['free_parameters_introduced']}
```

## Hub Candidate Table

{hub_table}

## Selected Hub Support

{support_table}

## Meaning

`QUBIT-CL-001` is selected because it is the only route that is both:

```text
INTEGER_WINDING_NEG_FULL on the alpha_H^2*D single-block route
and
the A-share reorganization center with bounce contact to every endpoint family.
```

This moves the CL hub from observed graph fact to a lower SAM/QP rule.

## Next Frontier

`{summary['next_frontier']}`

Generated at UTC: `{summary['generated_at_utc']}`
""",
        encoding="utf-8",
    )


def main() -> int:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    for path in [QP001_ROUTES, QP003_COUPLING, QP022A_INVENTORY, QP022A_SUMMARY]:
        if not path.exists():
            raise FileNotFoundError(path)

    route_rows = read_csv(QP001_ROUTES)
    coupling_rows = read_csv(QP003_COUPLING)
    inventory_rows = read_csv(QP022A_INVENTORY)
    qp022a_summary = read_json(QP022A_SUMMARY)

    endpoint_rows = [
        row for row in inventory_rows
        if row["is_derived_hub"] == "False" and row["derived_role_family"]
    ]
    endpoint_routes = {row["route"] for row in endpoint_rows}
    endpoint_role_families = {row["derived_role_family"] for row in endpoint_rows}
    endpoint_families = {row["derived_route_family"] for row in endpoint_rows}

    a_share_bounce_rows = [
        row for row in coupling_rows
        if row["sample_id"] == "N_A_SHARE"
        and row["coupling_status"] == "BOUNCE_RESPONSE_WRITE_COUPLING"
    ]
    bounce_by_route: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in a_share_bounce_rows:
        bounce_by_route[row["route_i"]].append(row)
        if row["route_j"] != row["route_i"]:
            bounce_by_route[row["route_j"]].append(row)

    inventory_by_route = {row["route"]: row for row in inventory_rows}
    route_by_id = {row["qubit_id"]: row for row in route_rows}
    hub_candidate_rows: list[dict[str, object]] = []
    support_rows: list[dict[str, object]] = []
    selected_hubs: list[str] = []

    for route_id, route_row in sorted(route_by_id.items()):
        route_bounce_rows = bounce_by_route.get(route_id, [])
        partners = {
            partner_in_pair(row, route_id)
            for row in route_bounce_rows
            if partner_in_pair(row, route_id)
        }
        covered_endpoint_routes = sorted(partners.intersection(endpoint_routes))
        covered_role_families = sorted({
            inventory_by_route[route]["derived_role_family"]
            for route in covered_endpoint_routes
            if inventory_by_route[route]["derived_role_family"]
        })
        covered_endpoint_families = sorted({
            inventory_by_route[route]["derived_route_family"]
            for route in covered_endpoint_routes
        })
        states_at_a_share = sorted({
            route_state_in_pair(row, route_id)
            for row in route_bounce_rows
            if route_state_in_pair(row, route_id)
        })
        partner_states = sorted({
            route_state_in_pair(row, partner_in_pair(row, route_id))
            for row in route_bounce_rows
            if partner_in_pair(row, route_id) != route_id
        })
        hub_native_class = is_hub_native_class(route_row)
        has_reorg = "REORGANIZATION_ONSET" in states_at_a_share
        covers_all_routes = endpoint_routes.issubset(partners)
        covers_all_role_families = endpoint_role_families.issubset(set(covered_role_families))
        covers_all_endpoint_families = endpoint_families.issubset(set(covered_endpoint_families))
        selected = (
            hub_native_class
            and has_reorg
            and covers_all_routes
            and covers_all_role_families
            and covers_all_endpoint_families
        )
        if selected:
            selected_hubs.append(route_id)
            for endpoint in sorted(endpoint_rows, key=lambda item: item["route"]):
                support_rows.append(
                    {
                        "hub_route": route_id,
                        "endpoint_route": endpoint["route"],
                        "endpoint_family": endpoint["derived_route_family"],
                        "derived_role_family": endpoint["derived_role_family"],
                        "route_pair": pair_key(route_id, endpoint["route"]),
                        "a_share_bounce_available": pair_key(route_id, endpoint["route"]) in {
                            pair_key(row["route_i"], row["route_j"]) for row in a_share_bounce_rows
                        },
                    }
                )
        hub_candidate_rows.append(
            {
                "route": route_id,
                "qubit_native_route": route_row["qubit_native_route"],
                "Q_native_class": route_row["Q_native_class"],
                "subchannel_partition": route_row["subchannel_partition"],
                "hub_native_class": hub_native_class,
                "A_exposure_per_t_SW": route_row["A_exposure_per_t_SW"],
                "ticks_to_A_SHARE": route_row["ticks_to_A_SHARE"],
                "states_at_A_SHARE_bounce": ";".join(states_at_a_share),
                "partner_states_at_A_SHARE_bounce": ";".join(partner_states),
                "has_reorganization_onset_at_A_SHARE": has_reorg,
                "a_share_bounce_degree": len(partners),
                "a_share_bounce_partners": ";".join(sorted(partners)),
                "endpoint_routes_covered": len(covered_endpoint_routes),
                "endpoint_role_families_covered": len(covered_role_families),
                "endpoint_families_covered": len(covered_endpoint_families),
                "covers_all_endpoint_routes": covers_all_routes,
                "covers_all_endpoint_role_families": covers_all_role_families,
                "covers_all_endpoint_families": covers_all_endpoint_families,
                "hub_origin_selected": selected,
            }
        )

    selected_hub = selected_hubs[0] if len(selected_hubs) == 1 else ""
    selected_row = next((row for row in hub_candidate_rows if row["route"] == selected_hub), {})
    if len(selected_hubs) == 1 and selected_hub == qp022a_summary["derived_hub_route"]:
        result_class = "QP022B_CL_HUB_ORIGIN_RULE_SELECTED"
    elif selected_hubs:
        result_class = "QP022B_CL_HUB_ORIGIN_BOUNDARY_AMBIGUOUS"
    else:
        result_class = "QP022B_CL_HUB_ORIGIN_RULE_FAILED"

    summary = {
        "artifact": "QP022B_PRIVATE_CL_HUB_ORIGIN_RULE",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp001/qp001_qubit_phase_functional_table.csv",
            "artifacts/qp003/qp003_interference_bounce_coupling_table.csv",
            "artifacts/qp022a/qp022a_route_inventory_table.csv",
        ],
        "selector_used_qp004_labels": False,
        "selected_hub_route": selected_hub,
        "selected_hubs": selected_hubs,
        "hub_origin_rule_unique": len(selected_hubs) == 1,
        "qp022a_hub_route": qp022a_summary["derived_hub_route"],
        "selected_matches_qp022a_hub": selected_hub == qp022a_summary["derived_hub_route"],
        "candidate_routes": len(hub_candidate_rows),
        "endpoint_routes_required": len(endpoint_routes),
        "endpoint_role_families_required": len(endpoint_role_families),
        "endpoint_families_required": len(endpoint_families),
        "selected_hub_endpoint_routes_covered": selected_row.get("endpoint_routes_covered", 0),
        "selected_hub_endpoint_role_families_covered": selected_row.get("endpoint_role_families_covered", 0),
        "selected_hub_endpoint_families_covered": selected_row.get("endpoint_families_covered", 0),
        "selected_hub_a_share_bounce_degree": selected_row.get("a_share_bounce_degree", 0),
        "necessary_conditions": [
            "native negative/full integer-winding alpha_H^2*D single-block route",
            "reorganization onset at A_SHARE",
            "A-share bounce contact to every non-hub endpoint route",
            "coverage of all derived endpoint role families",
            "coverage of all derived endpoint route families",
        ],
        "next_frontier": "QP022C_PRIVATE_LANE_SEPARATION_RULE",
    }

    hub_fields = [
        "route",
        "qubit_native_route",
        "Q_native_class",
        "subchannel_partition",
        "hub_native_class",
        "A_exposure_per_t_SW",
        "ticks_to_A_SHARE",
        "states_at_A_SHARE_bounce",
        "partner_states_at_A_SHARE_bounce",
        "has_reorganization_onset_at_A_SHARE",
        "a_share_bounce_degree",
        "a_share_bounce_partners",
        "endpoint_routes_covered",
        "endpoint_role_families_covered",
        "endpoint_families_covered",
        "covers_all_endpoint_routes",
        "covers_all_endpoint_role_families",
        "covers_all_endpoint_families",
        "hub_origin_selected",
    ]
    support_fields = [
        "hub_route",
        "endpoint_route",
        "endpoint_family",
        "derived_role_family",
        "route_pair",
        "a_share_bounce_available",
    ]
    write_csv(HUB_OUT, hub_candidate_rows, hub_fields)
    write_csv(SUPPORT_OUT, support_rows, support_fields)
    write_csv(SCHEMA_OUT, schema_rows(), ["quantity", "definition", "role"])
    write_csv(
        NEXT_OUT,
        [
            {
                "frontier": summary["next_frontier"],
                "why_next": "QP022B selected the CL hub from lower grammar and A-share reorganization behavior. QP022C should derive the neutral/charged/transition lane separation rule from endpoint grammar.",
                "input_surface": "qp022b_hub_candidate_table.csv;qp022b_hub_support_edges.csv",
                "target_output": "private lane separation rule",
            }
        ],
        ["frontier", "why_next", "input_surface", "target_output"],
    )
    write_json(SUMMARY_OUT, summary)
    write_report(summary, hub_candidate_rows, support_rows)

    print(summary["result_class"])
    print(f"selected_hub_route={summary['selected_hub_route']}")
    print(f"hub_origin_rule_unique={summary['hub_origin_rule_unique']}")
    print(f"selected_matches_qp022a_hub={summary['selected_matches_qp022a_hub']}")
    print(f"endpoint_routes_covered={summary['selected_hub_endpoint_routes_covered']}/{summary['endpoint_routes_required']}")
    print(f"endpoint_role_families_covered={summary['selected_hub_endpoint_role_families_covered']}/{summary['endpoint_role_families_required']}")
    print(f"selector_used_qp004_labels={summary['selector_used_qp004_labels']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
