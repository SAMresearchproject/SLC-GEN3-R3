from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP001_ROUTES = ARTIFACTS / "qp001" / "qp001_qubit_phase_functional_table.csv"
QP004_RULES = ARTIFACTS / "qp004" / "qp004_phase_role_operator_rules.csv"
QP022B_SUPPORT = ARTIFACTS / "qp022b" / "qp022b_hub_support_edges.csv"
QP022B_SUMMARY = ARTIFACTS / "qp022b" / "qp022b_summary.json"

QP022C_DIR = ARTIFACTS / "qp022c"
PREFLIGHT_OUT = QP022C_DIR / "qp022c_preflight.md"
SUMMARY_OUT = QP022C_DIR / "qp022c_summary.json"
ENDPOINT_OUT = QP022C_DIR / "qp022c_endpoint_lane_table.csv"
LANE_OUT = QP022C_DIR / "qp022c_lane_separation_table.csv"
COMPARISON_OUT = QP022C_DIR / "qp022c_qp004_comparison_table.csv"
SCHEMA_OUT = QP022C_DIR / "qp022c_schema.csv"
NEXT_OUT = QP022C_DIR / "qp022c_next_frontier.csv"
DOC_OUT = REPORTS / "QP022C_PRIVATE_LANE_SEPARATION_RULE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def pair_key(left: str, right: str) -> str:
    return "<->".join(sorted([left, right]))


def split_pairs(value: str) -> list[str]:
    return [pair_key(*item.strip().split("<->", 1)) for item in value.split(";") if item.strip()]


def write_preflight() -> None:
    QP022C_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP022C Preflight - Lane Separation Rule

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

## Question

```text
Can neutral, charged, and transition lanes be separated from endpoint route
grammar plus the QP022B derived hub support, without using QP004 role labels as
selector inputs?
```

## Selector Inputs

```text
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp022b/qp022b_hub_support_edges.csv
artifacts/qp022b/qp022b_summary.json
```

QP004 is comparison only.

## Pass

```text
exactly three lanes are selected
each lane has exactly two endpoint routes
all six lane edges are hub-supported
the derived lane pair sets match QP004 exactly when compared after selection
```

## Boundary

```text
lanes are partly recovered but one endpoint class remains ambiguous.
```

## Failure

```text
lane separation conflicts with the lower route grammar or QP004 comparison.
```
""",
        encoding="utf-8",
    )


def endpoint_lane(row: dict[str, str]) -> tuple[str, str, str]:
    native_route = row["qubit_native_route"]
    native_class = row["Q_native_class"]
    lowered_route = native_route.lower()
    lowered_class = native_class.lower()

    if native_class == "INTEGER_WINDING_NEUTRAL_IDENTITY":
        return (
            "DERIVED_NEUTRAL_BINARY_MIXING_TOPOLOGY",
            "NEUTRAL_IDENTITY_ACTIVE_ENDPOINT",
            "single-block neutral identity / outer-binary active grammar",
        )
    if native_class == "NEUTRAL_IDENTITY_PHASE":
        return (
            "DERIVED_NEUTRAL_BINARY_MIXING_TOPOLOGY",
            "NEUTRAL_SCALAR_RETURN_ENDPOINT",
            "outer-binary scalar even-return seed grammar",
        )
    if "triadic_screen_minus" in lowered_class:
        return (
            "DERIVED_DUAL_POLARITY_CHARGED_TOPOLOGY",
            "CHARGED_MINUS_TRIADIC_ENDPOINT",
            "minus triadic polarity grammar",
        )
    if "triadic_screen_plus" in lowered_class:
        return (
            "DERIVED_DUAL_POLARITY_CHARGED_TOPOLOGY",
            "CHARGED_PLUS_TRIADIC_ENDPOINT",
            "plus triadic polarity grammar",
        )
    if "binary_split__8_4" in lowered_route or native_class == "UNKNOWN_SUBCHANNEL_MODE":
        return (
            "DERIVED_TRANSITION_COLOR_COUPLED_TOPOLOGY",
            "TRANSITION_8_4_ENDPOINT",
            "8+4 transition route grammar",
        )
    if "owner_triad" in lowered_route or native_class == "OWNER_AXIS_NEUTRAL":
        return (
            "DERIVED_TRANSITION_COLOR_COUPLED_TOPOLOGY",
            "TRANSITION_OWNER_COLOR_ENDPOINT",
            "owner/color route grammar",
        )
    return ("DERIVED_UNCLASSIFIED_LANE", "UNCLASSIFIED_ENDPOINT", "no lane rule matched")


def qp004_rule_index(qp004_rows: list[dict[str, str]]) -> dict[frozenset[str], dict[str, str]]:
    out: dict[frozenset[str], dict[str, str]] = {}
    for row in qp004_rows:
        out[frozenset(split_pairs(row["required_phase_pairs"]))] = row
    return out


def schema_rows() -> list[dict[str, str]]:
    return [
        {
            "quantity": "QP022C_LANE_SEPARATION_RULE_SELECTED",
            "definition": "endpoint grammar separates the six hub-supported endpoints into three two-endpoint lanes",
            "role": "pass class",
        },
        {
            "quantity": "DERIVED_NEUTRAL_BINARY_MIXING_TOPOLOGY",
            "definition": "neutral identity active endpoint plus neutral scalar/even-return endpoint",
            "role": "neutral lane",
        },
        {
            "quantity": "DERIVED_DUAL_POLARITY_CHARGED_TOPOLOGY",
            "definition": "minus and plus triadic polarity endpoints",
            "role": "charged lane",
        },
        {
            "quantity": "DERIVED_TRANSITION_COLOR_COUPLED_TOPOLOGY",
            "definition": "8+4 transition endpoint plus owner/color endpoint",
            "role": "transition lane",
        },
    ]


def markdown_table(rows: list[dict[str, object]], fields: list[str], headers: list[str]) -> str:
    lines = [
        "| " + " | ".join(headers) + " |",
        "| " + " | ".join("---" for _ in headers) + " |",
    ]
    for row in rows:
        lines.append("| " + " | ".join(str(row.get(field, "")) for field in fields) + " |")
    return "\n".join(lines)


def write_report(summary: dict[str, object], lane_rows: list[dict[str, object]], comparison_rows: list[dict[str, object]]) -> None:
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    lane_table = markdown_table(
        lane_rows,
        ["derived_lane", "endpoint_routes", "endpoint_classes", "required_phase_pairs", "all_edges_hub_supported"],
        ["Derived Lane", "Endpoints", "Endpoint Classes", "Pairs", "Hub Supported"],
    )
    comparison_table = markdown_table(
        comparison_rows,
        ["derived_lane", "matched_qp004_role_operator", "exact_qp004_pair_match"],
        ["Derived Lane", "Matched QP004 Operator", "Exact Match"],
    )
    DOC_OUT.write_text(
        f"""# QP022C - Private Lane Separation Rule

## Verdict

`{summary['result_class']}`

QP022C derives neutral, charged, and transition lane separation from endpoint
route grammar plus QP022B hub support.

## Selector Inputs

```text
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp022b/qp022b_hub_support_edges.csv
artifacts/qp022b/qp022b_summary.json
```

QP004 is comparison only.

## Main Result

```text
selected_hub_route = {summary['selected_hub_route']}
derived_lanes = {summary['derived_lanes']}
lanes_with_two_endpoints = {summary['lanes_with_two_endpoints']}/{summary['derived_lanes']}
exact_qp004_rule_matches = {summary['exact_qp004_rule_matches']}/{summary['qp004_rule_count']}
selector_used_qp004_labels = {summary['selector_used_qp004_labels']}
free_parameters_introduced = {summary['free_parameters_introduced']}
```

## Derived Lanes

{lane_table}

## QP004 Comparison

{comparison_table}

## Meaning

The lane split is recovered from endpoint grammar:

```text
neutral    = neutral identity active + scalar/even-return endpoint
charged    = minus triadic + plus triadic endpoint
transition = 8+4 endpoint + owner/color endpoint
```

This makes the QP004 role classes a downstream match to lower route grammar
rather than the selector source.

## Next Frontier

`{summary['next_frontier']}`

Generated at UTC: `{summary['generated_at_utc']}`
""",
        encoding="utf-8",
    )


def main() -> int:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    for path in [QP001_ROUTES, QP004_RULES, QP022B_SUPPORT, QP022B_SUMMARY]:
        if not path.exists():
            raise FileNotFoundError(path)

    route_rows = read_csv(QP001_ROUTES)
    qp004_rows = read_csv(QP004_RULES)
    support_rows = read_csv(QP022B_SUPPORT)
    qp022b_summary = read_json(QP022B_SUMMARY)
    selected_hub = str(qp022b_summary["selected_hub_route"])

    route_by_id = {row["qubit_id"]: row for row in route_rows}
    supported_endpoints = sorted({
        row["endpoint_route"]
        for row in support_rows
        if row["hub_route"] == selected_hub and row["a_share_bounce_available"] == "True"
    })
    endpoint_rows: list[dict[str, object]] = []
    lanes: dict[str, list[dict[str, object]]] = defaultdict(list)
    for endpoint in supported_endpoints:
        route_row = route_by_id[endpoint]
        lane, endpoint_class, reason = endpoint_lane(route_row)
        endpoint_record = {
            "endpoint_route": endpoint,
            "selected_hub_route": selected_hub,
            "hub_pair": pair_key(selected_hub, endpoint),
            "qubit_native_route": route_row["qubit_native_route"],
            "Q_native_class": route_row["Q_native_class"],
            "subchannel_partition": route_row["subchannel_partition"],
            "derived_lane": lane,
            "endpoint_class": endpoint_class,
            "lane_rule_reason": reason,
            "hub_supported": True,
        }
        endpoint_rows.append(endpoint_record)
        lanes[lane].append(endpoint_record)

    qp004_index = qp004_rule_index(qp004_rows)
    lane_rows: list[dict[str, object]] = []
    comparison_rows: list[dict[str, object]] = []
    matched_qp004: set[frozenset[str]] = set()
    unclassified_endpoints = [
        row["endpoint_route"] for row in endpoint_rows if row["derived_lane"] == "DERIVED_UNCLASSIFIED_LANE"
    ]

    for lane, endpoints in sorted(lanes.items()):
        endpoint_routes = sorted(str(row["endpoint_route"]) for row in endpoints)
        endpoint_classes = sorted(str(row["endpoint_class"]) for row in endpoints)
        required_pairs = [pair_key(selected_hub, route) for route in endpoint_routes]
        pairset = frozenset(required_pairs)
        matched = qp004_index.get(pairset)
        if matched:
            matched_qp004.add(pairset)
        all_edges_supported = all(row["hub_supported"] is True for row in endpoints)
        lane_rows.append(
            {
                "derived_lane": lane,
                "endpoint_routes": ";".join(endpoint_routes),
                "endpoint_classes": ";".join(endpoint_classes),
                "required_phase_pairs": ";".join(sorted(required_pairs)),
                "endpoint_count": len(endpoint_routes),
                "all_edges_hub_supported": all_edges_supported,
                "matched_qp004_role_operator": matched["phase_role_operator"] if matched else "",
            }
        )
        comparison_rows.append(
            {
                "derived_lane": lane,
                "derived_required_phase_pairs": ";".join(sorted(required_pairs)),
                "matched_qp004_target_route": matched["suk055_target_route"] if matched else "",
                "matched_qp004_role_operator": matched["phase_role_operator"] if matched else "",
                "matched_qp004_required_phase_pairs": matched["required_phase_pairs"] if matched else "",
                "exact_qp004_pair_match": matched is not None,
                "pair_delta": "" if matched else "NO_EXACT_QP004_RULE_MATCH",
            }
        )

    expected_lanes = {
        "DERIVED_NEUTRAL_BINARY_MIXING_TOPOLOGY",
        "DERIVED_DUAL_POLARITY_CHARGED_TOPOLOGY",
        "DERIVED_TRANSITION_COLOR_COUPLED_TOPOLOGY",
    }
    lane_names = set(lanes)
    lanes_with_two = sum(1 for row in lane_rows if int(row["endpoint_count"]) == 2)
    all_expected_lanes_present = lane_names == expected_lanes
    all_lanes_two = lanes_with_two == len(expected_lanes)
    exact_matches = len(matched_qp004)
    qp004_rule_count = len(qp004_index)
    if all_expected_lanes_present and all_lanes_two and exact_matches == qp004_rule_count and not unclassified_endpoints:
        result_class = "QP022C_LANE_SEPARATION_RULE_SELECTED"
    elif exact_matches or all_expected_lanes_present:
        result_class = "QP022C_LANE_SEPARATION_BOUNDARY_PARTIAL"
    else:
        result_class = "QP022C_LANE_SEPARATION_RULE_FAILED"

    lane_counts = Counter(row["derived_lane"] for row in endpoint_rows)
    summary = {
        "artifact": "QP022C_PRIVATE_LANE_SEPARATION_RULE",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp001/qp001_qubit_phase_functional_table.csv",
            "artifacts/qp022b/qp022b_hub_support_edges.csv",
            "artifacts/qp022b/qp022b_summary.json",
        ],
        "comparison_only_inputs": [
            "artifacts/qp004/qp004_phase_role_operator_rules.csv",
        ],
        "selector_used_qp004_labels": False,
        "selected_hub_route": selected_hub,
        "supported_endpoints": len(supported_endpoints),
        "derived_lanes": len(lanes),
        "derived_lane_counts": dict(lane_counts),
        "expected_lanes_present": all_expected_lanes_present,
        "lanes_with_two_endpoints": lanes_with_two,
        "all_lanes_have_two_endpoints": all_lanes_two,
        "unclassified_endpoints": unclassified_endpoints,
        "qp004_rule_count": qp004_rule_count,
        "exact_qp004_rule_matches": exact_matches,
        "unmatched_qp004_rules": [
            ";".join(sorted(key))
            for key in qp004_index
            if key not in matched_qp004
        ],
        "lane_separation_recovered_without_qp004_labels": result_class == "QP022C_LANE_SEPARATION_RULE_SELECTED",
        "next_frontier": "QP022D_PRIVATE_DERIVED_TOPOLOGY_REPLAY",
    }

    endpoint_fields = [
        "endpoint_route",
        "selected_hub_route",
        "hub_pair",
        "qubit_native_route",
        "Q_native_class",
        "subchannel_partition",
        "derived_lane",
        "endpoint_class",
        "lane_rule_reason",
        "hub_supported",
    ]
    lane_fields = [
        "derived_lane",
        "endpoint_routes",
        "endpoint_classes",
        "required_phase_pairs",
        "endpoint_count",
        "all_edges_hub_supported",
        "matched_qp004_role_operator",
    ]
    comparison_fields = [
        "derived_lane",
        "derived_required_phase_pairs",
        "matched_qp004_target_route",
        "matched_qp004_role_operator",
        "matched_qp004_required_phase_pairs",
        "exact_qp004_pair_match",
        "pair_delta",
    ]
    write_csv(ENDPOINT_OUT, endpoint_rows, endpoint_fields)
    write_csv(LANE_OUT, lane_rows, lane_fields)
    write_csv(COMPARISON_OUT, comparison_rows, comparison_fields)
    write_csv(SCHEMA_OUT, schema_rows(), ["quantity", "definition", "role"])
    write_csv(
        NEXT_OUT,
        [
            {
                "frontier": summary["next_frontier"],
                "why_next": "QP022C derived the lane separation rule. QP022D should replay QP017B using the QP022-derived topology rather than imported QP004 topology.",
                "input_surface": "qp022c_lane_separation_table.csv",
                "target_output": "derived-topology replay of QP017B selector",
            }
        ],
        ["frontier", "why_next", "input_surface", "target_output"],
    )
    write_json(SUMMARY_OUT, summary)
    write_report(summary, lane_rows, comparison_rows)

    print(summary["result_class"])
    print(f"selected_hub_route={summary['selected_hub_route']}")
    print(f"derived_lanes={summary['derived_lanes']}")
    print(f"lanes_with_two_endpoints={summary['lanes_with_two_endpoints']}/{summary['derived_lanes']}")
    print(f"exact_qp004_rule_matches={summary['exact_qp004_rule_matches']}/{summary['qp004_rule_count']}")
    print(f"selector_used_qp004_labels={summary['selector_used_qp004_labels']}")
    print(f"next={summary['next_frontier']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
