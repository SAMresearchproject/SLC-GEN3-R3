from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP016_SELECTOR = ARTIFACTS / "qp016" / "qp016_stable_mode_selector_table.csv"
QP022B_SUMMARY = ARTIFACTS / "qp022b" / "qp022b_summary.json"
QP022C_SUMMARY = ARTIFACTS / "qp022c" / "qp022c_summary.json"
QP022C_ENDPOINTS = ARTIFACTS / "qp022c" / "qp022c_endpoint_lane_table.csv"
QP022C_LANES = ARTIFACTS / "qp022c" / "qp022c_lane_separation_table.csv"

QP022D_DIR = ARTIFACTS / "qp022d"
PREFLIGHT_OUT = QP022D_DIR / "qp022d_preflight.md"
SUMMARY_OUT = QP022D_DIR / "qp022d_summary.json"
EDGE_OUT = QP022D_DIR / "qp022d_derived_topology_edges.csv"
ROUTE_OUT = QP022D_DIR / "qp022d_route_topology_table.csv"
DECISION_OUT = QP022D_DIR / "qp022d_derived_topology_replay_decisions.csv"
SELECTION_OUT = QP022D_DIR / "qp022d_replay_selection_summary.csv"
SCHEMA_OUT = QP022D_DIR / "qp022d_schema.csv"
NEXT_OUT = QP022D_DIR / "qp022d_next_frontier.csv"
DOC_OUT = REPORTS / "QP022D_PRIVATE_DERIVED_TOPOLOGY_REPLAY.md"

EXPECTED_STABLE = {"QUBIT-NL-001<->QUBIT-NL-001"}
EXPECTED_BOUNDARY = {"QUBIT-NL-001<->QUBIT-UNK-001"}
EXPECTED_CHARGED = {"QUBIT-CL-001<->QUBIT-TM-001", "QUBIT-CL-001<->QUBIT-TP-001"}

LANE_KIND = {
    "DERIVED_NEUTRAL_BINARY_MIXING_TOPOLOGY": "NEUTRAL",
    "DERIVED_DUAL_POLARITY_CHARGED_TOPOLOGY": "CHARGED",
    "DERIVED_TRANSITION_COLOR_COUPLED_TOPOLOGY": "TRANSITION",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def pair_key(left: str, right: str) -> str:
    return "<->".join(sorted([left, right]))


def split_pair(value: str) -> tuple[str, str]:
    left, right = value.split("<->", 1)
    return left, right


def split_semicolon(value: str) -> list[str]:
    return [item.strip() for item in value.split(";") if item.strip()]


def write_preflight() -> None:
    QP022D_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP022D Preflight - Derived-Topology Replay

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP022D is not checking whether QP017B was correct. It asks whether the role
selector shape that QP017B needed can now be replayed using QP022-derived
topology rather than imported QP004 topology.

## Selector Inputs

```text
artifacts/qp016/qp016_stable_mode_selector_table.csv
artifacts/qp022b/qp022b_summary.json
artifacts/qp022c/qp022c_summary.json
artifacts/qp022c/qp022c_endpoint_lane_table.csv
artifacts/qp022c/qp022c_lane_separation_table.csv
```

## Explicitly Not Used As Selector

```text
artifacts/qp004/*
artifacts/qp017/qp017_stable_mode_role_operator_bridge.csv role/operator columns
audits/private_hostile_qp010_qp021/*
```

## Question

```text
Can the QP016 stable/boundary surface plus QP022-derived topology select the
same stable anchor, boundary bridge, and charged carrier separation that QP017B
previously required?
```
""",
        encoding="utf-8",
    )


def topology_edges(lane_rows: list[dict[str, str]]) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for lane in lane_rows:
        derived_lane = lane["derived_lane"]
        kind = LANE_KIND.get(derived_lane, "UNKNOWN")
        for raw_pair in split_semicolon(lane["required_phase_pairs"]):
            left, right = split_pair(raw_pair)
            rows.append(
                {
                    "route_pair": pair_key(left, right),
                    "route_i": left,
                    "route_j": right,
                    "derived_lane": derived_lane,
                    "derived_kind": kind,
                    "endpoint_count_in_lane": lane["endpoint_count"],
                    "all_edges_hub_supported": lane["all_edges_hub_supported"],
                    "source": "QP022C_DERIVED_TOPOLOGY",
                }
            )
    return sorted(rows, key=lambda row: (str(row["derived_lane"]), str(row["route_pair"])))


def route_topology(edge_rows: list[dict[str, object]], endpoint_rows: list[dict[str, str]]) -> dict[str, dict[str, set[str]]]:
    topology: dict[str, dict[str, set[str]]] = defaultdict(
        lambda: {"lanes": set(), "kinds": set(), "partners": set(), "endpoint_classes": set()}
    )
    endpoint_class = {row["endpoint_route"]: row["endpoint_class"] for row in endpoint_rows}
    for edge in edge_rows:
        left = str(edge["route_i"])
        right = str(edge["route_j"])
        lane = str(edge["derived_lane"])
        kind = str(edge["derived_kind"])
        for route, partner in ((left, right), (right, left)):
            topology[route]["lanes"].add(lane)
            topology[route]["kinds"].add(kind)
            topology[route]["partners"].add(partner)
            if route in endpoint_class:
                topology[route]["endpoint_classes"].add(endpoint_class[route])
    return topology


def route_rows(topology: dict[str, dict[str, set[str]]], hub_route: str) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for route in sorted(topology):
        rows.append(
            {
                "route": route,
                "is_selected_hub": route == hub_route,
                "degree": len(topology[route]["partners"]),
                "derived_lanes": ";".join(sorted(topology[route]["lanes"])),
                "derived_kinds": ";".join(sorted(topology[route]["kinds"])),
                "partners": ";".join(sorted(topology[route]["partners"])),
                "endpoint_classes": ";".join(sorted(topology[route]["endpoint_classes"])),
            }
        )
    return rows


def direct_lanes_for_pair(edge_rows: list[dict[str, object]], route_pair: str) -> set[str]:
    return {
        str(edge["derived_lane"])
        for edge in edge_rows
        if str(edge["route_pair"]) == route_pair
    }


def direct_kinds_for_pair(edge_rows: list[dict[str, object]], route_pair: str) -> set[str]:
    return {
        str(edge["derived_kind"])
        for edge in edge_rows
        if str(edge["route_pair"]) == route_pair
    }


def select_with_derived_topology(
    qp016_rows: list[dict[str, str]],
    edge_rows: list[dict[str, object]],
    topology: dict[str, dict[str, set[str]]],
    hub_route: str,
) -> tuple[list[dict[str, object]], dict[str, set[str]]]:
    decisions: list[dict[str, object]] = []
    selected: dict[str, set[str]] = {"stable": set(), "boundary": set(), "charged": set()}

    for row in qp016_rows:
        route_pair = pair_key(row["route_i"], row["route_j"])
        route_i = row["route_i"]
        route_j = row["route_j"]
        selector_class = row["selector_class"]
        pair_structure = row["pair_structure"]
        kinds_i = set(topology.get(route_i, {"kinds": set()})["kinds"])
        kinds_j = set(topology.get(route_j, {"kinds": set()})["kinds"])
        direct_lanes = direct_lanes_for_pair(edge_rows, route_pair)
        direct_kinds = direct_kinds_for_pair(edge_rows, route_pair)

        selected_class = "NOT_SELECTED"
        reason = "QP016 commit class and QP022-derived topology do not jointly select this pair"

        stable_ok = (
            selector_class == "STABLE_SELF_CLOSURE_MODE_SELECTED"
            and pair_structure == "SELF_CLOSURE"
            and route_i == route_j
            and route_i != hub_route
            and kinds_i == {"NEUTRAL"}
        )
        if stable_ok:
            selected["stable"].add(route_pair)
            selected_class = "STABLE_DERIVED_TOPOLOGY_ANCHOR"
            reason = "stable self-closure sits on a non-hub neutral derived route"

        boundary_ok = (
            selector_class == "BOUNDARY_REORGANIZATION_CANDIDATE"
            and pair_structure == "MIXED_ROUTE_INTERSECTION"
            and route_i != route_j
            and hub_route not in {route_i, route_j}
            and {frozenset(kinds_i), frozenset(kinds_j)} == {frozenset({"NEUTRAL"}), frozenset({"TRANSITION"})}
            and not direct_lanes
        )
        if boundary_ok:
            selected["boundary"].add(route_pair)
            selected_class = "BOUNDARY_DERIVED_TOPOLOGY_BRIDGE"
            reason = "boundary candidate links neutral route support to transition route support outside the hub"

        charged_ok = (
            selector_class == "TRANSIENT_COMMIT_TAIL"
            and pair_structure == "MIXED_ROUTE_INTERSECTION"
            and hub_route in {route_i, route_j}
            and direct_kinds == {"CHARGED"}
            and direct_lanes == {"DERIVED_DUAL_POLARITY_CHARGED_TOPOLOGY"}
        )
        if charged_ok:
            selected["charged"].add(route_pair)
            selected_class = "CHARGED_DERIVED_TRANSIENT_CARRIER_SEPARATED"
            reason = "charged lane is a direct hub carrier pair, separated from stable/boundary promotion"

        decisions.append(
            {
                "QP016_rank": row["QP016_rank"],
                "route_pair": route_pair,
                "route_i": route_i,
                "route_j": route_j,
                "qp016_selector_class": selector_class,
                "qp016_pair_structure": pair_structure,
                "latest_commit_probability": row["latest_commit_probability"],
                "stability_index": row["stability_index"],
                "route_i_derived_kinds": ";".join(sorted(kinds_i)),
                "route_j_derived_kinds": ";".join(sorted(kinds_j)),
                "direct_derived_lanes": ";".join(sorted(direct_lanes)),
                "direct_derived_kinds": ";".join(sorted(direct_kinds)),
                "selected_class": selected_class,
                "reason": reason,
            }
        )
    return decisions, selected


def write_doc(summary: dict[str, object], selections: list[dict[str, object]]) -> None:
    selected_lines = "\n".join(
        f"| {row['lane']} | {row['selected_pairs']} | {row['expected_pairs']} | {row['matches_expected']} |"
        for row in selections
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP022D - Private Derived-Topology Replay

## Result

```text
{summary['result_class']}
```

QP022D uses QP016 stable/boundary commit classes plus the QP022B/QP022C
derived topology. It does not use QP004 role labels as selector input.

## Replay

| lane | selected pairs | expected replay pairs | matches expected |
| --- | --- | --- | --- |
{selected_lines}

## Key Fields

```text
selected_hub_route = {summary['selected_hub_route']}
selector_used_qp004_labels = {summary['selector_used_qp004_labels']}
free_parameters_introduced = {summary['free_parameters_introduced']}
stable_replay_matches = {summary['stable_replay_matches']}
boundary_replay_matches = {summary['boundary_replay_matches']}
charged_replay_matches = {summary['charged_replay_matches']}
full_replay_matches = {summary['full_replay_matches']}
```

## Interpretation

The Phase 2 topology chain now reaches the old QP017B endpoint without importing
QP004 topology as the selector. CL is selected as hub by QP022B, lanes are
separated by QP022C, and QP022D replays the stable anchor, boundary bridge, and
charged transient-carrier separation from those derived pieces.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    qp016_rows = read_csv(QP016_SELECTOR)
    qp022b_summary = read_json(QP022B_SUMMARY)
    qp022c_summary = read_json(QP022C_SUMMARY)
    endpoint_rows = read_csv(QP022C_ENDPOINTS)
    lane_rows = read_csv(QP022C_LANES)

    hub_route = str(qp022b_summary["selected_hub_route"])
    edge_rows = topology_edges(lane_rows)
    topology = route_topology(edge_rows, endpoint_rows)
    route_table = route_rows(topology, hub_route)
    decisions, selected = select_with_derived_topology(qp016_rows, edge_rows, topology, hub_route)

    stable = selected["stable"]
    boundary = selected["boundary"]
    charged = selected["charged"]
    stable_matches = stable == EXPECTED_STABLE
    boundary_matches = boundary == EXPECTED_BOUNDARY
    charged_matches = charged == EXPECTED_CHARGED
    full_replay_matches = stable_matches and boundary_matches and charged_matches

    if full_replay_matches and not bool(qp022c_summary.get("selector_used_qp004_labels", True)):
        result_class = "QP022D_DERIVED_TOPOLOGY_REPLAY_MATCHES_QP017B"
        next_frontier = "QP023_PRIVATE_DERIVED_ROLE_TO_PARTICLE_TABLE_FREEZE"
    elif stable_matches and boundary_matches:
        result_class = "QP022D_BOUNDARY_CHARGED_REPLAY_NOT_CLOSED"
        next_frontier = "QP022E_PRIVATE_CHARGED_REPLAY_REPAIR"
    else:
        result_class = "QP022D_FAIL_DERIVED_TOPOLOGY_REPLAY"
        next_frontier = "STOP_PHASE2_REPLAY_FAILURE"

    selection_rows = [
        {
            "lane": "stable",
            "selected_pairs": ";".join(sorted(stable)),
            "expected_pairs": ";".join(sorted(EXPECTED_STABLE)),
            "matches_expected": stable_matches,
            "selected_count": len(stable),
        },
        {
            "lane": "boundary",
            "selected_pairs": ";".join(sorted(boundary)),
            "expected_pairs": ";".join(sorted(EXPECTED_BOUNDARY)),
            "matches_expected": boundary_matches,
            "selected_count": len(boundary),
        },
        {
            "lane": "charged_carrier",
            "selected_pairs": ";".join(sorted(charged)),
            "expected_pairs": ";".join(sorted(EXPECTED_CHARGED)),
            "matches_expected": charged_matches,
            "selected_count": len(charged),
        },
    ]

    class_counts = Counter(str(row["selected_class"]) for row in decisions)
    summary = {
        "artifact": "QP022D_PRIVATE_DERIVED_TOPOLOGY_REPLAY",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp016/qp016_stable_mode_selector_table.csv",
            "artifacts/qp022b/qp022b_summary.json",
            "artifacts/qp022c/qp022c_summary.json",
            "artifacts/qp022c/qp022c_endpoint_lane_table.csv",
            "artifacts/qp022c/qp022c_lane_separation_table.csv",
        ],
        "selector_used_qp004_labels": False,
        "selected_hub_route": hub_route,
        "qp022b_hub_origin_unique": bool(qp022b_summary.get("hub_origin_rule_unique", False)),
        "qp022c_lane_separation_recovered_without_qp004_labels": bool(
            qp022c_summary.get("lane_separation_recovered_without_qp004_labels", False)
        ),
        "derived_topology_edges": len(edge_rows),
        "derived_route_nodes": len(route_table),
        "qp016_rows_replayed": len(decisions),
        "selected_class_counts": dict(class_counts),
        "expected_stable_pairs": sorted(EXPECTED_STABLE),
        "selected_stable_pairs": sorted(stable),
        "stable_replay_matches": stable_matches,
        "expected_boundary_pairs": sorted(EXPECTED_BOUNDARY),
        "selected_boundary_pairs": sorted(boundary),
        "boundary_replay_matches": boundary_matches,
        "expected_charged_carrier_pairs": sorted(EXPECTED_CHARGED),
        "selected_charged_carrier_pairs": sorted(charged),
        "charged_replay_matches": charged_matches,
        "full_replay_matches": full_replay_matches,
        "law": "stable and boundary promotion are selected by QP016 commit class plus QP022-derived topology; charged carriers remain separated direct hub pairs",
        "next_frontier": next_frontier,
    }

    schema_rows = [
        {
            "class": "STABLE_DERIVED_TOPOLOGY_ANCHOR",
            "meaning": "QP016 stable self-closure on non-hub neutral derived route",
            "status": "stable replay lane",
        },
        {
            "class": "BOUNDARY_DERIVED_TOPOLOGY_BRIDGE",
            "meaning": "QP016 boundary candidate linking neutral and transition derived support outside hub",
            "status": "boundary replay lane",
        },
        {
            "class": "CHARGED_DERIVED_TRANSIENT_CARRIER_SEPARATED",
            "meaning": "transient direct hub pair in derived charged lane, kept out of stable/boundary promotion",
            "status": "charged carrier lane",
        },
        {
            "class": "QP022D_DERIVED_TOPOLOGY_REPLAY_MATCHES_QP017B",
            "meaning": "derived topology reproduces stable, boundary, and charged replay targets",
            "status": "pass",
        },
        {
            "class": "QP022D_BOUNDARY_CHARGED_REPLAY_NOT_CLOSED",
            "meaning": "stable/boundary replay works but charged carrier separation is incomplete",
            "status": "boundary",
        },
        {
            "class": "QP022D_FAIL_DERIVED_TOPOLOGY_REPLAY",
            "meaning": "derived topology does not reproduce stable/boundary replay targets",
            "status": "fail",
        },
    ]

    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP022D closes the derived-topology replay if PASS; next freeze should carry the derived role topology into particle-table filling without importing QP004 labels as a selector.",
            "launch_from": "qp022d_summary.json;qp022d_derived_topology_replay_decisions.csv",
            "target_output": "derived role-to-particle table freeze",
        }
    ]

    write_csv(
        EDGE_OUT,
        edge_rows,
        [
            "route_pair",
            "route_i",
            "route_j",
            "derived_lane",
            "derived_kind",
            "endpoint_count_in_lane",
            "all_edges_hub_supported",
            "source",
        ],
    )
    write_csv(
        ROUTE_OUT,
        route_table,
        ["route", "is_selected_hub", "degree", "derived_lanes", "derived_kinds", "partners", "endpoint_classes"],
    )
    write_csv(
        DECISION_OUT,
        decisions,
        [
            "QP016_rank",
            "route_pair",
            "route_i",
            "route_j",
            "qp016_selector_class",
            "qp016_pair_structure",
            "latest_commit_probability",
            "stability_index",
            "route_i_derived_kinds",
            "route_j_derived_kinds",
            "direct_derived_lanes",
            "direct_derived_kinds",
            "selected_class",
            "reason",
        ],
    )
    write_csv(
        SELECTION_OUT,
        selection_rows,
        ["lane", "selected_pairs", "expected_pairs", "matches_expected", "selected_count"],
    )
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, selection_rows)

    print(result_class)
    print(f"selected_hub_route={hub_route}")
    print(f"stable_replay_matches={stable_matches}")
    print(f"boundary_replay_matches={boundary_matches}")
    print(f"charged_replay_matches={charged_matches}")
    print(f"full_replay_matches={full_replay_matches}")
    print(f"selector_used_qp004_labels={summary['selector_used_qp004_labels']}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
