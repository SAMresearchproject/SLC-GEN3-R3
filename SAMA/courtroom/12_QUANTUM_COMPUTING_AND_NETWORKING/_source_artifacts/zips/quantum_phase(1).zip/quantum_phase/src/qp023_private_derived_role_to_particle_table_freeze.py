from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP018_SLOTS = ARTIFACTS / "qp018" / "qp018_role_bridge_particle_slot_selector.csv"
QP019_MASS = ARTIFACTS / "qp019" / "qp019_particle_slot_native_mass_surface_bridge.csv"
QP021_CHARGED = ARTIFACTS / "qp021" / "qp021_charged_particle_mass_bridge.csv"
QP022D_SUMMARY = ARTIFACTS / "qp022d" / "qp022d_summary.json"
QP022D_SELECTIONS = ARTIFACTS / "qp022d" / "qp022d_replay_selection_summary.csv"

QP023_DIR = ARTIFACTS / "qp023"
PREFLIGHT_OUT = QP023_DIR / "qp023_preflight.md"
SUMMARY_OUT = QP023_DIR / "qp023_summary.json"
TABLE_OUT = QP023_DIR / "qp023_derived_particle_table_freeze.csv"
FROZEN_OUT = QP023_DIR / "qp023_frozen_mass_surface_table.csv"
OPEN_OUT = QP023_DIR / "qp023_open_slot_inventory.csv"
LANE_OUT = QP023_DIR / "qp023_lane_counts.csv"
SCHEMA_OUT = QP023_DIR / "qp023_schema.csv"
NEXT_OUT = QP023_DIR / "qp023_next_frontier.csv"
DOC_OUT = REPORTS / "QP023_PRIVATE_DERIVED_ROLE_TO_PARTICLE_TABLE_FREEZE.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def as_bool(value: object) -> bool:
    return str(value).strip().lower() == "true"


def join_values(values: list[str] | set[str]) -> str:
    return ";".join(sorted(item for item in values if item))


def write_preflight() -> None:
    QP023_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP023 Preflight - Derived Role To Particle Table Freeze

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP023 is a forward freeze. It does not re-check QP018, QP019, QP021, or QP022D.
It asks which downstream particle slots and native mass surfaces can now be
carried by the QP022-derived topology.

## Selector Inputs

```text
artifacts/qp022d/qp022d_summary.json
artifacts/qp022d/qp022d_replay_selection_summary.csv
artifacts/qp018/qp018_role_bridge_particle_slot_selector.csv
artifacts/qp019/qp019_particle_slot_native_mass_surface_bridge.csv
artifacts/qp021/qp021_charged_particle_mass_bridge.csv
```

## Legacy Label Guard

```text
QP004 labels are not selector inputs.
Legacy phase_role_operator columns may exist inside downstream QP018/QP019
artifacts, but QP023 selection ignores those columns.
```

## Question

```text
Given QP022-derived stable, boundary, and charged carrier lanes, which particle
slots and native mass surfaces can be frozen now?
```
""",
        encoding="utf-8",
    )


def indexed(rows: list[dict[str, str]], key: str) -> dict[str, dict[str, str]]:
    return {row[key]: row for row in rows}


def freeze_class_for_row(
    mass_row: dict[str, str],
    slot_row: dict[str, str],
    charged_row: dict[str, str] | None,
    stable_pairs: set[str],
    boundary_pairs: set[str],
    charged_pairs: set[str],
) -> tuple[str, str, str, bool, str]:
    source_pair = mass_row.get("qp017_source_pair", "")
    charge_class = slot_row.get("charge_class", "")
    promoted_mass = as_bool(mass_row.get("promote_to_native_mass_surface", ""))

    if source_pair in stable_pairs:
        if promoted_mass:
            return (
                "DERIVED_STABLE_ANCHOR_LANE",
                source_pair,
                "STABLE_ANCHOR_MASS_SURFACE_FROZEN",
                True,
                "stable QP022D anchor carries this native mass surface",
            )
        return (
            "DERIVED_STABLE_ANCHOR_LANE",
            source_pair,
            "STABLE_REACHABLE_SLOT_HELD_OPEN",
            False,
            "stable lane reaches this slot family but no native mass readout is selected",
        )

    if source_pair in boundary_pairs:
        if promoted_mass:
            return (
                "DERIVED_BOUNDARY_REORGANIZATION_LANE",
                source_pair,
                "BOUNDARY_REORGANIZATION_MASS_SURFACE_FROZEN",
                True,
                "boundary QP022D bridge carries this native mass surface",
            )
        return (
            "DERIVED_BOUNDARY_REORGANIZATION_LANE",
            source_pair,
            "BOUNDARY_REACHABLE_SLOT_HELD_OPEN",
            False,
            "boundary lane reaches this slot family but no native mass readout is selected",
        )

    if charge_class == "charged":
        if charged_row and as_bool(charged_row.get("selected_charged_mass_surface", "")):
            return (
                "DERIVED_CHARGED_CARRIER_LANE",
                join_values(charged_pairs),
                "CHARGED_CARRIER_MASS_SURFACE_FROZEN",
                True,
                "QP022D charged carriers carry this QP021 selected charged mass surface",
            )
        return (
            "DERIVED_CHARGED_CARRIER_LANE",
            join_values(charged_pairs),
            "CHARGED_CARRIER_SLOT_HELD_OPEN",
            False,
            "charged scaffold remains available but has no selected charged mass surface",
        )

    return (
        "DERIVED_UNASSIGNED_DOWNSTREAM_SLOT",
        "",
        "UNASSIGNED_SLOT_HELD_OPEN",
        False,
        "slot is downstream-visible but not reached by the current derived replay lanes",
    )


def build_table(
    slot_rows: list[dict[str, str]],
    mass_rows: list[dict[str, str]],
    charged_rows: list[dict[str, str]],
    q022d_summary: dict[str, object],
) -> list[dict[str, object]]:
    slots_by_pair = indexed(slot_rows, "suk055_pair")
    charged_by_pair = indexed(charged_rows, "suk055_pair")
    stable_pairs = set(str(item) for item in q022d_summary["selected_stable_pairs"])
    boundary_pairs = set(str(item) for item in q022d_summary["selected_boundary_pairs"])
    charged_pairs = set(str(item) for item in q022d_summary["selected_charged_carrier_pairs"])

    rows: list[dict[str, object]] = []
    for mass_row in mass_rows:
        pair = mass_row["suk055_pair"]
        slot_row = slots_by_pair.get(pair, {})
        charged_row = charged_by_pair.get(pair)
        lane, source_pairs, freeze_class, frozen, reading = freeze_class_for_row(
            mass_row, slot_row, charged_row, stable_pairs, boundary_pairs, charged_pairs
        )
        selected_mass = mass_row.get("selected_mass_readout_MeV", "")
        if charged_row and charged_row.get("selected_mass_readout_MeV"):
            selected_mass = charged_row["selected_mass_readout_MeV"]
        selected_surface = mass_row.get("selected_surface", "")
        if charged_row and charged_row.get("selected_surface"):
            selected_surface = charged_row["selected_surface"]
        integer_contact = mass_row.get("integer_shift_contact_class", "")
        if charged_row and charged_row.get("integer_shift_contact_class"):
            integer_contact = charged_row["integer_shift_contact_class"]
        contact_tightness = mass_row.get("contact_tightness", "")
        if charged_row and charged_row.get("contact_tightness"):
            contact_tightness = charged_row["contact_tightness"]

        rows.append(
            {
                "QP023_rank": 0,
                "suk055_pair": pair,
                "oriented_symbols": mass_row.get("oriented_symbols", ""),
                "charge_class": slot_row.get("charge_class", ""),
                "derived_replay_lane": lane,
                "derived_source_pairs": source_pairs,
                "qp018_selector_class": slot_row.get("QP018_selector_class", ""),
                "qp019_bridge_class": mass_row.get("QP019_bridge_class", ""),
                "qp021_charged_status": charged_row.get("charged_mass_status", "") if charged_row else "",
                "native_interaction_strength": slot_row.get("native_interaction_strength", ""),
                "slot_selector_score": slot_row.get("slot_selector_score", ""),
                "selected_surface": selected_surface,
                "selected_mass_readout_MeV": selected_mass,
                "integer_shift_contact_class": integer_contact,
                "contact_tightness": contact_tightness,
                "QP023_freeze_class": freeze_class,
                "frozen_mass_surface": frozen,
                "open_reason": "" if frozen else reading,
                "SAM_reading": reading,
            }
        )

    rows.sort(
        key=lambda row: (
            0 if row["frozen_mass_surface"] else 1,
            str(row["derived_replay_lane"]),
            str(row["suk055_pair"]),
        )
    )
    for index, row in enumerate(rows, start=1):
        row["QP023_rank"] = index
    return rows


def lane_counts(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    grouped: dict[str, list[dict[str, object]]] = {}
    for row in rows:
        grouped.setdefault(str(row["derived_replay_lane"]), []).append(row)
    out: list[dict[str, object]] = []
    for lane in sorted(grouped):
        lane_rows = grouped[lane]
        frozen = [row for row in lane_rows if bool(row["frozen_mass_surface"])]
        out.append(
            {
                "derived_replay_lane": lane,
                "slot_rows": len(lane_rows),
                "frozen_mass_surfaces": len(frozen),
                "open_slots": len(lane_rows) - len(frozen),
                "frozen_pairs": join_values({str(row["suk055_pair"]) for row in frozen}),
            }
        )
    return out


def write_doc(summary: dict[str, object], lane_rows: list[dict[str, object]], frozen_rows: list[dict[str, object]]) -> None:
    lane_lines = "\n".join(
        f"| {row['derived_replay_lane']} | {row['slot_rows']} | {row['frozen_mass_surfaces']} | {row['open_slots']} | {row['frozen_pairs']} |"
        for row in lane_rows
    )
    frozen_lines = "\n".join(
        f"| {row['suk055_pair']} | {row['derived_replay_lane']} | {row['selected_mass_readout_MeV']} | {row['QP023_freeze_class']} |"
        for row in frozen_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP023 - Private Derived Role To Particle Table Freeze

## Result

```text
{summary['result_class']}
```

QP023 freezes the particle-table surface carried by QP022-derived topology. It
uses QP022D selected stable, boundary, and charged carrier lanes, then carries
downstream QP018/QP019/QP021 slot and mass-surface results into one table.

## Lane Counts

| derived replay lane | slot rows | frozen mass surfaces | open slots | frozen pairs |
| --- | ---: | ---: | ---: | --- |
{lane_lines}

## Frozen Mass Surfaces

| pair | derived lane | selected mass readout MeV | freeze class |
| --- | --- | ---: | --- |
{frozen_lines}

## Key Fields

```text
particle_table_rows = {summary['particle_table_rows']}
frozen_mass_surfaces = {summary['frozen_mass_surfaces']}
open_slots = {summary['open_slots']}
legacy_role_operator_column_used_for_selection = {summary['legacy_role_operator_column_used_for_selection']}
selector_used_qp004_labels = {summary['selector_used_qp004_labels']}
```

## Interpretation

The derived QP022 topology now carries four frozen private particle mass
surfaces:

```text
stable anchor: b<->s
boundary reorganization: c<->s
charged carriers: b<->c, b<->t
```

The remaining rows stay visible as open scaffolds rather than being thrown away.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    slot_rows = read_csv(QP018_SLOTS)
    mass_rows = read_csv(QP019_MASS)
    charged_rows = read_csv(QP021_CHARGED)
    q022d_summary = read_json(QP022D_SUMMARY)
    q022d_selection_rows = read_csv(QP022D_SELECTIONS)

    rows = build_table(slot_rows, mass_rows, charged_rows, q022d_summary)
    frozen_rows = [row for row in rows if bool(row["frozen_mass_surface"])]
    open_rows = [row for row in rows if not bool(row["frozen_mass_surface"])]
    lanes = lane_counts(rows)

    frozen_classes = Counter(str(row["QP023_freeze_class"]) for row in frozen_rows)
    open_classes = Counter(str(row["QP023_freeze_class"]) for row in open_rows)
    required_freeze_classes = {
        "STABLE_ANCHOR_MASS_SURFACE_FROZEN",
        "BOUNDARY_REORGANIZATION_MASS_SURFACE_FROZEN",
        "CHARGED_CARRIER_MASS_SURFACE_FROZEN",
    }
    classes_present = set(frozen_classes)
    required_classes_present = required_freeze_classes <= classes_present

    if (
        q022d_summary.get("full_replay_matches") is True
        and required_classes_present
        and len(frozen_rows) == 4
    ):
        result_class = "QP023_DERIVED_PARTICLE_TABLE_FREEZE_BUILT"
        next_frontier = "QP024_PRIVATE_OPEN_SLOT_PROMOTION_SELECTOR"
    elif q022d_summary.get("full_replay_matches") is True and frozen_rows:
        result_class = "QP023_BOUNDARY_PARTIAL_PARTICLE_TABLE_FREEZE"
        next_frontier = "QP023B_PRIVATE_PARTIAL_FREEZE_REPAIR"
    else:
        result_class = "QP023_FAIL_NO_DERIVED_PARTICLE_TABLE_FREEZE"
        next_frontier = "STOP_PHASE2_PARTICLE_FREEZE_FAILURE"

    summary = {
        "artifact": "QP023_PRIVATE_DERIVED_ROLE_TO_PARTICLE_TABLE_FREEZE",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp022d/qp022d_summary.json",
            "artifacts/qp022d/qp022d_replay_selection_summary.csv",
            "artifacts/qp018/qp018_role_bridge_particle_slot_selector.csv",
            "artifacts/qp019/qp019_particle_slot_native_mass_surface_bridge.csv",
            "artifacts/qp021/qp021_charged_particle_mass_bridge.csv",
        ],
        "selector_used_qp004_labels": False,
        "legacy_role_operator_column_used_for_selection": False,
        "qp022d_full_replay_matches": bool(q022d_summary.get("full_replay_matches")),
        "qp022d_selection_rows": len(q022d_selection_rows),
        "particle_table_rows": len(rows),
        "frozen_mass_surfaces": len(frozen_rows),
        "open_slots": len(open_rows),
        "frozen_class_counts": dict(frozen_classes),
        "open_class_counts": dict(open_classes),
        "required_freeze_classes_present": required_classes_present,
        "frozen_pairs": [str(row["suk055_pair"]) for row in frozen_rows],
        "open_pairs": [str(row["suk055_pair"]) for row in open_rows],
        "law": "QP022-derived replay lanes carry downstream particle slots into frozen, held-open, or unassigned table rows",
        "next_frontier": next_frontier,
    }

    schema_rows = [
        {
            "class": "STABLE_ANCHOR_MASS_SURFACE_FROZEN",
            "meaning": "QP022D stable anchor carries a QP019 selected native mass surface",
            "status": "frozen",
        },
        {
            "class": "BOUNDARY_REORGANIZATION_MASS_SURFACE_FROZEN",
            "meaning": "QP022D boundary bridge carries a QP019 selected native mass surface",
            "status": "frozen",
        },
        {
            "class": "CHARGED_CARRIER_MASS_SURFACE_FROZEN",
            "meaning": "QP022D charged carrier lane carries a QP021 selected charged mass surface",
            "status": "frozen",
        },
        {
            "class": "STABLE_REACHABLE_SLOT_HELD_OPEN",
            "meaning": "stable lane reaches the slot family but no mass surface is selected",
            "status": "open",
        },
        {
            "class": "CHARGED_CARRIER_SLOT_HELD_OPEN",
            "meaning": "charged scaffold remains available but no selected mass surface exists",
            "status": "open",
        },
        {
            "class": "QP023_DERIVED_PARTICLE_TABLE_FREEZE_BUILT",
            "meaning": "derived lanes freeze stable, boundary, and charged mass surfaces into one particle table",
            "status": "pass",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP023 freezes the derived particle table surface. QP024 should attack open-slot promotion using the held-open rows rather than revisiting frozen gates.",
            "launch_from": "qp023_derived_particle_table_freeze.csv;qp023_open_slot_inventory.csv",
            "target_output": "open slot promotion selector",
        }
    ]

    fields = [
        "QP023_rank",
        "suk055_pair",
        "oriented_symbols",
        "charge_class",
        "derived_replay_lane",
        "derived_source_pairs",
        "qp018_selector_class",
        "qp019_bridge_class",
        "qp021_charged_status",
        "native_interaction_strength",
        "slot_selector_score",
        "selected_surface",
        "selected_mass_readout_MeV",
        "integer_shift_contact_class",
        "contact_tightness",
        "QP023_freeze_class",
        "frozen_mass_surface",
        "open_reason",
        "SAM_reading",
    ]
    write_csv(TABLE_OUT, rows, fields)
    write_csv(FROZEN_OUT, frozen_rows, fields)
    write_csv(OPEN_OUT, open_rows, fields)
    write_csv(
        LANE_OUT,
        lanes,
        ["derived_replay_lane", "slot_rows", "frozen_mass_surfaces", "open_slots", "frozen_pairs"],
    )
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, lanes, frozen_rows)

    print(result_class)
    print(f"particle_table_rows={len(rows)}")
    print(f"frozen_mass_surfaces={len(frozen_rows)}")
    print(f"open_slots={len(open_rows)}")
    print(f"required_freeze_classes_present={required_classes_present}")
    print(f"selector_used_qp004_labels={summary['selector_used_qp004_labels']}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
