from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP016_SUMMARY = ARTIFACTS / "qp016" / "qp016_summary.json"
QP023_SUMMARY = ARTIFACTS / "qp023" / "qp023_summary.json"
QP023_OPEN = ARTIFACTS / "qp023" / "qp023_open_slot_inventory.csv"

QP024_DIR = ARTIFACTS / "qp024"
PREFLIGHT_OUT = QP024_DIR / "qp024_preflight.md"
SUMMARY_OUT = QP024_DIR / "qp024_summary.json"
FRONTIER_OUT = QP024_DIR / "qp024_open_slot_frontier_table.csv"
LANE_FRONTIER_OUT = QP024_DIR / "qp024_lane_frontier_summary.csv"
SCHEMA_OUT = QP024_DIR / "qp024_schema.csv"
NEXT_OUT = QP024_DIR / "qp024_next_frontier.csv"
DOC_OUT = REPORTS / "QP024_PRIVATE_OPEN_SLOT_PROMOTION_SELECTOR.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def as_float(value: str) -> float:
    if not value:
        return 0.0
    return float(value)


def write_preflight() -> None:
    QP024_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP024 Preflight - Open Slot Promotion Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP024 starts from the QP023 open-slot inventory and asks whether any held-open
particle slots promote under already-native SAM thresholds.

## Selector Inputs

```text
artifacts/qp023/qp023_open_slot_inventory.csv
artifacts/qp023/qp023_summary.json
artifacts/qp016/qp016_summary.json
```

## Question

```text
Do any held-open slots clear A_SIDE or A_SHARE now, and if not, which open
slots are the highest-pressure frontier for the next forward gate?
```
""",
        encoding="utf-8",
    )


def classify(native_strength: float, a_side: float, a_share: float, lane_rank: int) -> tuple[str, str]:
    if native_strength >= a_share:
        return (
            "OPEN_SLOT_PROMOTES_TO_STABLE_WRITE_SURFACE",
            "native interaction strength clears A_SHARE",
        )
    if native_strength >= a_side:
        return (
            "OPEN_SLOT_ENTERS_BOUNDARY_BASIN",
            "native interaction strength clears A_SIDE but not A_SHARE",
        )
    if lane_rank == 1:
        return (
            "TOP_OPEN_FRONTIER_BELOW_A_SIDE",
            "strongest open slot in this derived lane, but still below A_SIDE",
        )
    return (
        "HELD_OPEN_SUB_A_SIDE",
        "held-open scaffold remains below native boundary threshold",
    )


def build_frontier(open_rows: list[dict[str, str]], a_side: float, a_share: float) -> list[dict[str, object]]:
    grouped: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in open_rows:
        grouped[row["derived_replay_lane"]].append(row)

    rows: list[dict[str, object]] = []
    for lane, lane_rows in grouped.items():
        ordered = sorted(
            lane_rows,
            key=lambda row: (
                as_float(row["native_interaction_strength"]),
                as_float(row["slot_selector_score"]),
            ),
            reverse=True,
        )
        for lane_rank, row in enumerate(ordered, start=1):
            native_strength = as_float(row["native_interaction_strength"])
            slot_score = as_float(row["slot_selector_score"])
            promotion_class, reason = classify(native_strength, a_side, a_share, lane_rank)
            rows.append(
                {
                    "QP024_rank": 0,
                    "lane_rank": lane_rank,
                    "suk055_pair": row["suk055_pair"],
                    "oriented_symbols": row["oriented_symbols"],
                    "charge_class": row["charge_class"],
                    "derived_replay_lane": lane,
                    "native_interaction_strength": native_strength,
                    "slot_selector_score": slot_score,
                    "native_fraction_of_A_SIDE": native_strength / a_side if a_side else 0.0,
                    "native_fraction_of_A_SHARE": native_strength / a_share if a_share else 0.0,
                    "gap_to_A_SIDE": max(0.0, a_side - native_strength),
                    "gap_to_A_SHARE": max(0.0, a_share - native_strength),
                    "QP023_freeze_class": row["QP023_freeze_class"],
                    "QP024_promotion_class": promotion_class,
                    "promotes_now": promotion_class
                    in {"OPEN_SLOT_PROMOTES_TO_STABLE_WRITE_SURFACE", "OPEN_SLOT_ENTERS_BOUNDARY_BASIN"},
                    "SAM_reading": reason,
                }
            )

    rows.sort(
        key=lambda row: (
            0 if bool(row["promotes_now"]) else 1,
            -float(row["native_interaction_strength"]),
            str(row["suk055_pair"]),
        )
    )
    for rank, row in enumerate(rows, start=1):
        row["QP024_rank"] = rank
    return rows


def lane_summary(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    grouped: dict[str, list[dict[str, object]]] = defaultdict(list)
    for row in rows:
        grouped[str(row["derived_replay_lane"])].append(row)
    out: list[dict[str, object]] = []
    for lane in sorted(grouped):
        lane_rows = sorted(grouped[lane], key=lambda row: float(row["native_interaction_strength"]), reverse=True)
        top = lane_rows[0]
        promotes = [row for row in lane_rows if bool(row["promotes_now"])]
        out.append(
            {
                "derived_replay_lane": lane,
                "open_slots": len(lane_rows),
                "promotes_now": len(promotes),
                "top_frontier_pair": top["suk055_pair"],
                "top_native_interaction_strength": top["native_interaction_strength"],
                "top_fraction_of_A_SIDE": top["native_fraction_of_A_SIDE"],
                "top_gap_to_A_SIDE": top["gap_to_A_SIDE"],
                "top_promotion_class": top["QP024_promotion_class"],
            }
        )
    return out


def write_doc(summary: dict[str, object], lane_rows: list[dict[str, object]], top_rows: list[dict[str, object]]) -> None:
    lane_lines = "\n".join(
        f"| {row['derived_replay_lane']} | {row['open_slots']} | {row['promotes_now']} | {row['top_frontier_pair']} | {row['top_fraction_of_A_SIDE']} | {row['top_gap_to_A_SIDE']} |"
        for row in lane_rows
    )
    top_lines = "\n".join(
        f"| {row['suk055_pair']} | {row['derived_replay_lane']} | {row['native_interaction_strength']} | {row['native_fraction_of_A_SIDE']} | {row['QP024_promotion_class']} |"
        for row in top_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP024 - Private Open Slot Promotion Selector

## Result

```text
{summary['result_class']}
```

QP024 starts from QP023's held-open particle slots and applies the native
thresholds already used by QP016:

```text
A_SIDE = {summary['A_SIDE']}
A_SHARE = {summary['A_SHARE']}
```

## Lane Frontier

| derived replay lane | open slots | promotes now | top frontier pair | top fraction of A_SIDE | top gap to A_SIDE |
| --- | ---: | ---: | --- | ---: | ---: |
{lane_lines}

## Top Open Frontiers

| pair | derived lane | native strength | fraction of A_SIDE | class |
| --- | --- | ---: | ---: | --- |
{top_lines}

## Interpretation

No held-open slot crosses the native `A_SIDE` boundary in QP024. The result is
still useful: it ranks the next open fronts without changing frozen QP023
surface claims.

The strongest two frontiers are:

```text
stable lane  = {summary['top_stable_frontier_pair']}
charged lane = {summary['top_charged_frontier_pair']}
```

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp016_summary = read_json(QP016_SUMMARY)
    qp023_summary = read_json(QP023_SUMMARY)
    open_rows = read_csv(QP023_OPEN)
    thresholds = qp016_summary["thresholds"]
    a_side = float(thresholds["A_SIDE"])
    a_share = float(thresholds["A_SHARE"])

    frontier_rows = build_frontier(open_rows, a_side, a_share)
    lanes = lane_summary(frontier_rows)
    promotions = [row for row in frontier_rows if bool(row["promotes_now"])]
    top_by_lane = {row["derived_replay_lane"]: row for row in lanes}
    top_rows = sorted(
        [row for row in frontier_rows if int(row["lane_rank"]) == 1],
        key=lambda row: float(row["native_interaction_strength"]),
        reverse=True,
    )
    class_counts = Counter(str(row["QP024_promotion_class"]) for row in frontier_rows)

    if promotions:
        result_class = "QP024_OPEN_SLOT_PROMOTION_SELECTOR_FOUND_PROMOTIONS"
        next_frontier = "QP025_PRIVATE_PROMOTED_OPEN_SLOT_MASS_SURFACE_BUILD"
    else:
        result_class = "QP024_OPEN_SLOT_FRONTIER_RANKED_NO_NATIVE_PROMOTION"
        next_frontier = "QP025_PRIVATE_SUB_A_SIDE_REINFORCEMENT_SELECTOR"

    stable_lane = top_by_lane.get("DERIVED_STABLE_ANCHOR_LANE", {})
    charged_lane = top_by_lane.get("DERIVED_CHARGED_CARRIER_LANE", {})
    summary = {
        "artifact": "QP024_PRIVATE_OPEN_SLOT_PROMOTION_SELECTOR",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp023/qp023_open_slot_inventory.csv",
            "artifacts/qp023/qp023_summary.json",
            "artifacts/qp016/qp016_summary.json",
        ],
        "selector_used_qp004_labels": False,
        "A_SIDE": a_side,
        "A_SHARE": a_share,
        "qp023_open_slots": int(qp023_summary.get("open_slots", len(open_rows))),
        "frontier_rows": len(frontier_rows),
        "promotions_now": len(promotions),
        "promotion_class_counts": dict(class_counts),
        "top_stable_frontier_pair": stable_lane.get("top_frontier_pair", ""),
        "top_stable_fraction_of_A_SIDE": stable_lane.get("top_fraction_of_A_SIDE", ""),
        "top_stable_gap_to_A_SIDE": stable_lane.get("top_gap_to_A_SIDE", ""),
        "top_charged_frontier_pair": charged_lane.get("top_frontier_pair", ""),
        "top_charged_fraction_of_A_SIDE": charged_lane.get("top_fraction_of_A_SIDE", ""),
        "top_charged_gap_to_A_SIDE": charged_lane.get("top_gap_to_A_SIDE", ""),
        "law": "held-open slots promote only if native interaction strength clears A_SIDE or A_SHARE; otherwise they become ranked sub-threshold frontiers",
        "next_frontier": next_frontier,
    }

    schema_rows = [
        {
            "class": "OPEN_SLOT_PROMOTES_TO_STABLE_WRITE_SURFACE",
            "meaning": "open slot clears A_SHARE",
            "status": "promotion",
        },
        {
            "class": "OPEN_SLOT_ENTERS_BOUNDARY_BASIN",
            "meaning": "open slot clears A_SIDE but not A_SHARE",
            "status": "promotion",
        },
        {
            "class": "TOP_OPEN_FRONTIER_BELOW_A_SIDE",
            "meaning": "strongest open slot in a lane, below native boundary threshold",
            "status": "ranked frontier",
        },
        {
            "class": "HELD_OPEN_SUB_A_SIDE",
            "meaning": "open scaffold below native boundary threshold",
            "status": "held open",
        },
        {
            "class": "QP024_OPEN_SLOT_FRONTIER_RANKED_NO_NATIVE_PROMOTION",
            "meaning": "no open slot promotes; top stable and charged frontiers are ranked",
            "status": "frontier",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP024 ranks open slots but finds no native promotion. QP025 should test whether sub-A-side reinforcement can lift a frontier without changing frozen QP023 rows.",
            "launch_from": "qp024_open_slot_frontier_table.csv;qp024_lane_frontier_summary.csv",
            "target_output": "sub-A-side reinforcement selector",
        }
    ]

    fields = [
        "QP024_rank",
        "lane_rank",
        "suk055_pair",
        "oriented_symbols",
        "charge_class",
        "derived_replay_lane",
        "native_interaction_strength",
        "slot_selector_score",
        "native_fraction_of_A_SIDE",
        "native_fraction_of_A_SHARE",
        "gap_to_A_SIDE",
        "gap_to_A_SHARE",
        "QP023_freeze_class",
        "QP024_promotion_class",
        "promotes_now",
        "SAM_reading",
    ]
    write_csv(FRONTIER_OUT, frontier_rows, fields)
    write_csv(
        LANE_FRONTIER_OUT,
        lanes,
        [
            "derived_replay_lane",
            "open_slots",
            "promotes_now",
            "top_frontier_pair",
            "top_native_interaction_strength",
            "top_fraction_of_A_SIDE",
            "top_gap_to_A_SIDE",
            "top_promotion_class",
        ],
    )
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, lanes, top_rows)

    print(result_class)
    print(f"frontier_rows={len(frontier_rows)}")
    print(f"promotions_now={len(promotions)}")
    print(f"top_stable_frontier_pair={summary['top_stable_frontier_pair']}")
    print(f"top_stable_fraction_of_A_SIDE={summary['top_stable_fraction_of_A_SIDE']}")
    print(f"top_charged_frontier_pair={summary['top_charged_frontier_pair']}")
    print(f"top_charged_fraction_of_A_SIDE={summary['top_charged_fraction_of_A_SIDE']}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
