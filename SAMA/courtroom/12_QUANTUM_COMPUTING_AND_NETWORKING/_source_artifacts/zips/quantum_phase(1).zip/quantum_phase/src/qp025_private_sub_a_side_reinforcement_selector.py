from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP016_SUMMARY = ARTIFACTS / "qp016" / "qp016_summary.json"
QP023_TABLE = ARTIFACTS / "qp023" / "qp023_derived_particle_table_freeze.csv"
QP024_FRONTIER = ARTIFACTS / "qp024" / "qp024_open_slot_frontier_table.csv"
QP024_SUMMARY = ARTIFACTS / "qp024" / "qp024_summary.json"

QP025_DIR = ARTIFACTS / "qp025"
PREFLIGHT_OUT = QP025_DIR / "qp025_preflight.md"
SUMMARY_OUT = QP025_DIR / "qp025_summary.json"
LANE_OUT = QP025_DIR / "qp025_lane_reinforcement_table.csv"
PREFIX_OUT = QP025_DIR / "qp025_open_prefix_reinforcement_table.csv"
SCHEMA_OUT = QP025_DIR / "qp025_schema.csv"
NEXT_OUT = QP025_DIR / "qp025_next_frontier.csv"
DOC_OUT = REPORTS / "QP025_PRIVATE_SUB_A_SIDE_REINFORCEMENT_SELECTOR.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def as_float(value: str) -> float:
    if not value:
        return 0.0
    return float(value)


def as_bool(value: str) -> bool:
    return value.strip().lower() == "true"


def join(values: list[str]) -> str:
    return ";".join(values)


def write_preflight() -> None:
    QP025_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP025 Preflight - Sub-A-Side Reinforcement Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP025 starts from the QP023 particle table and QP024 open-slot frontier. It asks
whether multiple held-open, sub-A_SIDE slots accumulate coherently enough to
cross a native threshold.

## Selector Inputs

```text
artifacts/qp023/qp023_derived_particle_table_freeze.csv
artifacts/qp024/qp024_open_slot_frontier_table.csv
artifacts/qp024/qp024_summary.json
artifacts/qp016/qp016_summary.json
```

## Question

```text
Does open-only lane accumulation cross A_SIDE, and does frozen-carrier support
create a distinct near-threshold reinforcement surface?
```
""",
        encoding="utf-8",
    )


def classify_open_sum(open_sum: float, a_side: float, a_share: float) -> str:
    if open_sum >= a_share:
        return "OPEN_REINFORCEMENT_CROSSES_A_SHARE"
    if open_sum >= a_side:
        return "OPEN_REINFORCEMENT_CROSSES_A_SIDE"
    if open_sum / a_side >= 0.95:
        return "OPEN_REINFORCEMENT_NEAR_A_SIDE"
    return "OPEN_REINFORCEMENT_SUB_A_SIDE"


def build_prefix_rows(open_rows: list[dict[str, str]], a_side: float, a_share: float) -> list[dict[str, object]]:
    grouped: dict[str, list[dict[str, str]]] = {}
    for row in open_rows:
        grouped.setdefault(row["derived_replay_lane"], []).append(row)

    rows: list[dict[str, object]] = []
    for lane, lane_rows in grouped.items():
        ordered = sorted(lane_rows, key=lambda row: as_float(row["native_interaction_strength"]), reverse=True)
        total = 0.0
        selected_pairs: list[str] = []
        for prefix_rank, row in enumerate(ordered, start=1):
            total += as_float(row["native_interaction_strength"])
            selected_pairs.append(row["suk055_pair"])
            rows.append(
                {
                    "derived_replay_lane": lane,
                    "prefix_rank": prefix_rank,
                    "prefix_pairs": join(selected_pairs),
                    "prefix_native_strength": total,
                    "prefix_fraction_of_A_SIDE": total / a_side if a_side else 0.0,
                    "prefix_fraction_of_A_SHARE": total / a_share if a_share else 0.0,
                    "prefix_gap_to_A_SIDE": max(0.0, a_side - total),
                    "prefix_gap_to_A_SHARE": max(0.0, a_share - total),
                    "prefix_crosses_A_SIDE": total >= a_side,
                    "prefix_crosses_A_SHARE": total >= a_share,
                }
            )
    return rows


def build_lane_rows(
    particle_rows: list[dict[str, str]],
    open_rows: list[dict[str, str]],
    prefix_rows: list[dict[str, object]],
    a_side: float,
    a_share: float,
) -> list[dict[str, object]]:
    lanes = sorted({row["derived_replay_lane"] for row in particle_rows})
    rows: list[dict[str, object]] = []
    for lane in lanes:
        lane_particle = [row for row in particle_rows if row["derived_replay_lane"] == lane]
        lane_open = [row for row in open_rows if row["derived_replay_lane"] == lane]
        lane_frozen = [row for row in lane_particle if as_bool(row["frozen_mass_surface"])]
        frozen_sum = sum(as_float(row["native_interaction_strength"]) for row in lane_frozen)
        open_sum = sum(as_float(row["native_interaction_strength"]) for row in lane_open)
        combined_sum = frozen_sum + open_sum
        lane_prefixes = [row for row in prefix_rows if row["derived_replay_lane"] == lane]
        first_a_side = next((row for row in lane_prefixes if row["prefix_crosses_A_SIDE"]), None)
        first_a_share = next((row for row in lane_prefixes if row["prefix_crosses_A_SHARE"]), None)
        top_open = max(lane_open, key=lambda row: as_float(row["native_interaction_strength"]), default={})
        open_class = classify_open_sum(open_sum, a_side, a_share)
        carrier_support = bool(lane_frozen) and bool(lane_open) and combined_sum >= a_share and open_sum < a_side
        if carrier_support:
            carrier_class = "CARRIER_ASSISTED_REINFORCEMENT_SURFACE"
        elif lane_frozen and not lane_open:
            carrier_class = "FROZEN_ONLY_NO_OPEN_REINFORCEMENT"
        elif combined_sum >= a_side:
            carrier_class = "COMBINED_LANE_CROSSES_A_SIDE"
        else:
            carrier_class = "NO_CARRIER_ASSISTED_THRESHOLD"
        rows.append(
            {
                "derived_replay_lane": lane,
                "open_slots": len(lane_open),
                "frozen_mass_surfaces": len(lane_frozen),
                "top_open_pair": top_open.get("suk055_pair", ""),
                "open_native_sum": open_sum,
                "open_fraction_of_A_SIDE": open_sum / a_side if a_side else 0.0,
                "open_fraction_of_A_SHARE": open_sum / a_share if a_share else 0.0,
                "open_gap_to_A_SIDE": max(0.0, a_side - open_sum),
                "open_gap_to_A_SHARE": max(0.0, a_share - open_sum),
                "open_reinforcement_class": open_class,
                "first_prefix_crossing_A_SIDE": first_a_side["prefix_pairs"] if first_a_side else "",
                "first_prefix_crossing_A_SHARE": first_a_share["prefix_pairs"] if first_a_share else "",
                "frozen_native_sum": frozen_sum,
                "combined_native_sum": combined_sum,
                "combined_fraction_of_A_SIDE": combined_sum / a_side if a_side else 0.0,
                "combined_fraction_of_A_SHARE": combined_sum / a_share if a_share else 0.0,
                "carrier_support_class": carrier_class,
            }
        )
    return rows


def write_doc(summary: dict[str, object], lane_rows: list[dict[str, object]]) -> None:
    lines = "\n".join(
        f"| {row['derived_replay_lane']} | {row['open_slots']} | {row['open_native_sum']} | {row['open_fraction_of_A_SIDE']} | {row['open_gap_to_A_SIDE']} | {row['open_reinforcement_class']} | {row['carrier_support_class']} |"
        for row in lane_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP025 - Private Sub-A-Side Reinforcement Selector

## Result

```text
{summary['result_class']}
```

QP025 asks whether held-open slots can accumulate coherently inside each derived
lane.

## Lane Reinforcement

| derived replay lane | open slots | open native sum | open fraction of A_SIDE | open gap to A_SIDE | open class | carrier support |
| --- | ---: | ---: | ---: | ---: | --- | --- |
{lines}

## Key Fields

```text
A_SIDE = {summary['A_SIDE']}
A_SHARE = {summary['A_SHARE']}
stable_open_fraction_of_A_SIDE = {summary['stable_open_fraction_of_A_SIDE']}
stable_open_gap_to_A_SIDE = {summary['stable_open_gap_to_A_SIDE']}
charged_open_fraction_of_A_SIDE = {summary['charged_open_fraction_of_A_SIDE']}
charged_open_gap_to_A_SIDE = {summary['charged_open_gap_to_A_SIDE']}
open_lanes_crossing_A_SIDE = {summary['open_lanes_crossing_A_SIDE']}
carrier_assisted_lanes = {summary['carrier_assisted_lanes']}
```

## Interpretation

Open-only reinforcement does not cross `A_SIDE`, but the stable open lane is a
near-boundary reservoir: its held-open rows reach roughly 96.8 percent of
`A_SIDE`.

That makes the next question sharply local: what supplies the small remaining
stable-lane closure gap without changing the already frozen QP023 rows?

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp016_summary = read_json(QP016_SUMMARY)
    qp024_summary = read_json(QP024_SUMMARY)
    particle_rows = read_csv(QP023_TABLE)
    open_rows = read_csv(QP024_FRONTIER)
    thresholds = qp016_summary["thresholds"]
    a_side = float(thresholds["A_SIDE"])
    a_share = float(thresholds["A_SHARE"])

    prefix_rows = build_prefix_rows(open_rows, a_side, a_share)
    lane_rows = build_lane_rows(particle_rows, open_rows, prefix_rows, a_side, a_share)
    open_cross_a_side = [row for row in lane_rows if row["open_reinforcement_class"] in {"OPEN_REINFORCEMENT_CROSSES_A_SIDE", "OPEN_REINFORCEMENT_CROSSES_A_SHARE"}]
    near_a_side = [row for row in lane_rows if row["open_reinforcement_class"] == "OPEN_REINFORCEMENT_NEAR_A_SIDE"]
    carrier_assisted = [row for row in lane_rows if row["carrier_support_class"] == "CARRIER_ASSISTED_REINFORCEMENT_SURFACE"]
    stable_row = next((row for row in lane_rows if row["derived_replay_lane"] == "DERIVED_STABLE_ANCHOR_LANE"), {})
    charged_row = next((row for row in lane_rows if row["derived_replay_lane"] == "DERIVED_CHARGED_CARRIER_LANE"), {})

    if open_cross_a_side:
        result_class = "QP025_SUB_A_SIDE_REINFORCEMENT_PROMOTES_OPEN_LANE"
        next_frontier = "QP026_PRIVATE_REINFORCED_OPEN_SLOT_MASS_SURFACE_BUILD"
    elif near_a_side:
        result_class = "QP025_STABLE_OPEN_REINFORCEMENT_NEAR_A_SIDE"
        next_frontier = "QP026_PRIVATE_STABLE_LANE_RESIDUAL_CLOSURE_SELECTOR"
    else:
        result_class = "QP025_REINFORCEMENT_NO_PROMOTION"
        next_frontier = "QP026_PRIVATE_OPEN_SLOT_EXTERNAL_SUPPORT_SEARCH"

    summary = {
        "artifact": "QP025_PRIVATE_SUB_A_SIDE_REINFORCEMENT_SELECTOR",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp023/qp023_derived_particle_table_freeze.csv",
            "artifacts/qp024/qp024_open_slot_frontier_table.csv",
            "artifacts/qp024/qp024_summary.json",
            "artifacts/qp016/qp016_summary.json",
        ],
        "selector_used_qp004_labels": False,
        "A_SIDE": a_side,
        "A_SHARE": a_share,
        "qp024_promotions_now": qp024_summary.get("promotions_now", 0),
        "lane_rows": len(lane_rows),
        "prefix_rows": len(prefix_rows),
        "open_lanes_crossing_A_SIDE": len(open_cross_a_side),
        "near_A_SIDE_open_lanes": len(near_a_side),
        "carrier_assisted_lanes": len(carrier_assisted),
        "stable_open_fraction_of_A_SIDE": stable_row.get("open_fraction_of_A_SIDE", ""),
        "stable_open_gap_to_A_SIDE": stable_row.get("open_gap_to_A_SIDE", ""),
        "stable_open_native_sum": stable_row.get("open_native_sum", ""),
        "stable_carrier_support_class": stable_row.get("carrier_support_class", ""),
        "charged_open_fraction_of_A_SIDE": charged_row.get("open_fraction_of_A_SIDE", ""),
        "charged_open_gap_to_A_SIDE": charged_row.get("open_gap_to_A_SIDE", ""),
        "charged_open_native_sum": charged_row.get("open_native_sum", ""),
        "charged_carrier_support_class": charged_row.get("carrier_support_class", ""),
        "law": "sub-A-side open slots are summed by derived lane; open-only threshold crossing and carrier-assisted support are kept separate",
        "next_frontier": next_frontier,
    }

    schema_rows = [
        {
            "class": "OPEN_REINFORCEMENT_CROSSES_A_SHARE",
            "meaning": "open-only lane sum clears A_SHARE",
            "status": "promotion",
        },
        {
            "class": "OPEN_REINFORCEMENT_CROSSES_A_SIDE",
            "meaning": "open-only lane sum clears A_SIDE",
            "status": "promotion",
        },
        {
            "class": "OPEN_REINFORCEMENT_NEAR_A_SIDE",
            "meaning": "open-only lane sum reaches at least 95 percent of A_SIDE",
            "status": "near-boundary frontier",
        },
        {
            "class": "CARRIER_ASSISTED_REINFORCEMENT_SURFACE",
            "meaning": "frozen carrier plus held-open row sum clears A_SHARE while open-only remains below A_SIDE",
            "status": "support surface",
        },
        {
            "class": "QP025_STABLE_OPEN_REINFORCEMENT_NEAR_A_SIDE",
            "meaning": "stable held-open lane nearly reaches A_SIDE but does not promote by open-only accumulation",
            "status": "frontier",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP025 finds a near-A_SIDE stable open reservoir. QP026 should target the small residual closure gap directly.",
            "launch_from": "qp025_lane_reinforcement_table.csv;qp025_open_prefix_reinforcement_table.csv",
            "target_output": "stable lane residual closure selector",
        }
    ]

    write_csv(
        LANE_OUT,
        lane_rows,
        [
            "derived_replay_lane",
            "open_slots",
            "frozen_mass_surfaces",
            "top_open_pair",
            "open_native_sum",
            "open_fraction_of_A_SIDE",
            "open_fraction_of_A_SHARE",
            "open_gap_to_A_SIDE",
            "open_gap_to_A_SHARE",
            "open_reinforcement_class",
            "first_prefix_crossing_A_SIDE",
            "first_prefix_crossing_A_SHARE",
            "frozen_native_sum",
            "combined_native_sum",
            "combined_fraction_of_A_SIDE",
            "combined_fraction_of_A_SHARE",
            "carrier_support_class",
        ],
    )
    write_csv(
        PREFIX_OUT,
        prefix_rows,
        [
            "derived_replay_lane",
            "prefix_rank",
            "prefix_pairs",
            "prefix_native_strength",
            "prefix_fraction_of_A_SIDE",
            "prefix_fraction_of_A_SHARE",
            "prefix_gap_to_A_SIDE",
            "prefix_gap_to_A_SHARE",
            "prefix_crosses_A_SIDE",
            "prefix_crosses_A_SHARE",
        ],
    )
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, lane_rows)

    print(result_class)
    print(f"open_lanes_crossing_A_SIDE={len(open_cross_a_side)}")
    print(f"near_A_SIDE_open_lanes={len(near_a_side)}")
    print(f"stable_open_fraction_of_A_SIDE={summary['stable_open_fraction_of_A_SIDE']}")
    print(f"stable_open_gap_to_A_SIDE={summary['stable_open_gap_to_A_SIDE']}")
    print(f"charged_open_fraction_of_A_SIDE={summary['charged_open_fraction_of_A_SIDE']}")
    print(f"carrier_assisted_lanes={len(carrier_assisted)}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
