from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

ENGINE_SUMMARY = ARTIFACTS / "core" / "phase_field_engine_summary.json"
QP025_SUMMARY = ARTIFACTS / "qp025" / "qp025_summary.json"
QP025_LANES = ARTIFACTS / "qp025" / "qp025_lane_reinforcement_table.csv"

QP026_DIR = ARTIFACTS / "qp026"
PREFLIGHT_OUT = QP026_DIR / "qp026_preflight.md"
SUMMARY_OUT = QP026_DIR / "qp026_summary.json"
CANDIDATE_OUT = QP026_DIR / "qp026_native_residual_candidate_table.csv"
CLOSURE_OUT = QP026_DIR / "qp026_residual_closure_table.csv"
SCHEMA_OUT = QP026_DIR / "qp026_schema.csv"
NEXT_OUT = QP026_DIR / "qp026_next_frontier.csv"
DOC_OUT = REPORTS / "QP026_PRIVATE_STABLE_LANE_RESIDUAL_CLOSURE_SELECTOR.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP026_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP026 Preflight - Stable Lane Residual Closure Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP026 starts from the QP025 stable-lane residual gap and compares it to a sealed
family of native terms built from lower SAM/QP constants.

## Selector Inputs

```text
artifacts/qp025/qp025_summary.json
artifacts/qp025/qp025_lane_reinforcement_table.csv
artifacts/core/phase_field_engine_summary.json
```

## Sealed Candidate Family

Numerators:

```text
A0
A_SIDE
A_SHARE
```

Denominators:

```text
D
alpha_H * D
R - D
R
R + D
R + alpha_H^2
R + alpha_H * D
R + D^2
R + 2^D
R * alpha_H
R * D
R * alpha_H^2
R^2
```

## Question

```text
Does an existing native term sit at the QP025 stable residual scale, and does it
close the gap or leave a smaller next residual?
```
""",
        encoding="utf-8",
    )


def threshold(engine: dict[str, object], name: str) -> float:
    for row in engine["thresholds"]:
        if row["name"] == name:
            return float(row["value"])
    raise KeyError(name)


def candidate_terms(a0: float, a_side: float, a_share: float, r: int, d: int, alpha_h: int) -> list[dict[str, object]]:
    denominators = {
        "D": d,
        "alpha_H_times_D": alpha_h * d,
        "R_minus_D": r - d,
        "R": r,
        "R_plus_D": r + d,
        "R_plus_alpha_H_sq": r + alpha_h**2,
        "R_plus_alpha_H_times_D": r + alpha_h * d,
        "R_plus_D_sq": r + d**2,
        "R_plus_2_pow_D": r + 2**d,
        "R_times_alpha_H": r * alpha_h,
        "R_times_D": r * d,
        "R_times_alpha_H_sq": r * alpha_h**2,
        "R_sq": r**2,
    }
    numerators = {"A0": a0, "A_SIDE": a_side, "A_SHARE": a_share}
    rows: list[dict[str, object]] = []
    for numerator_name, numerator in numerators.items():
        for denominator_name, denominator in denominators.items():
            if denominator <= 0:
                continue
            rows.append(
                {
                    "candidate_id": f"{numerator_name}_over_{denominator_name}",
                    "numerator": numerator_name,
                    "denominator_basis": denominator_name,
                    "denominator_value": denominator,
                    "candidate_value": numerator / denominator,
                }
            )
    return rows


def score_candidates(rows: list[dict[str, object]], target_gap: float) -> list[dict[str, object]]:
    scored: list[dict[str, object]] = []
    for row in rows:
        value = float(row["candidate_value"])
        abs_delta = abs(value - target_gap)
        signed_delta = value - target_gap
        relative_delta = abs_delta / target_gap if target_gap else 0.0
        closes_fraction = value / target_gap if target_gap else 0.0
        if abs_delta <= 1e-12:
            contact_class = "EXACT_RESIDUAL_CLOSURE"
        elif relative_delta <= 0.01:
            contact_class = "TIGHT_NATIVE_RESIDUAL_CONTACT"
        elif relative_delta <= 0.10:
            contact_class = "NEAR_NATIVE_RESIDUAL_CONTACT"
        else:
            contact_class = "NON_CONTACT_CANDIDATE"
        scored.append(
            {
                **row,
                "target_gap": target_gap,
                "signed_delta_to_gap": signed_delta,
                "abs_delta_to_gap": abs_delta,
                "relative_delta_to_gap": relative_delta,
                "fraction_of_gap_closed": closes_fraction,
                "contact_class": contact_class,
            }
        )
    scored.sort(key=lambda row: (float(row["relative_delta_to_gap"]), str(row["candidate_id"])))
    for rank, row in enumerate(scored, start=1):
        row["QP026_rank"] = rank
    return scored


def write_doc(summary: dict[str, object], top_rows: list[dict[str, object]]) -> None:
    top_lines = "\n".join(
        f"| {row['QP026_rank']} | {row['candidate_id']} | {row['candidate_value']} | {row['fraction_of_gap_closed']} | {row['relative_delta_to_gap']} | {row['contact_class']} |"
        for row in top_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP026 - Private Stable Lane Residual Closure Selector

## Result

```text
{summary['result_class']}
```

QP026 compares the QP025 stable residual gap to a sealed family of native terms
from `A0`, `A_SIDE`, `A_SHARE`, `R`, `D`, and `alpha_H`.

## Stable Residual Target

```text
stable_open_gap_to_A_SIDE = {summary['target_stable_gap_to_A_SIDE']}
```

## Top Native Contacts

| rank | candidate | value | fraction of gap closed | relative delta | class |
| ---: | --- | ---: | ---: | ---: | --- |
{top_lines}

## Key Fields

```text
best_candidate = {summary['best_candidate_id']}
best_candidate_value = {summary['best_candidate_value']}
best_fraction_of_gap_closed = {summary['best_fraction_of_gap_closed']}
residual_after_best_candidate = {summary['residual_after_best_candidate']}
best_contact_class = {summary['best_contact_class']}
```

## Interpretation

The best sealed native term is:

```text
A0 / (R + 2^D)
```

It closes about 99.545 percent of the QP025 stable residual gap but does not
exactly close it. The remaining residual is small enough to justify a targeted
route-exposure crumb selector as the next forward gate.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    engine = read_json(ENGINE_SUMMARY)
    q025_summary = read_json(QP025_SUMMARY)
    q025_lanes = read_csv(QP025_LANES)

    constants = engine["constants"]
    a0 = float(constants["A0"])
    r = int(constants["R"])
    d = int(constants["D"])
    alpha_h = int(constants["ALPHA_H"])
    a_side = threshold(engine, "A_SIDE")
    a_share = threshold(engine, "A_SHARE")
    stable_lane = next(row for row in q025_lanes if row["derived_replay_lane"] == "DERIVED_STABLE_ANCHOR_LANE")
    target_gap = float(stable_lane["open_gap_to_A_SIDE"])

    candidates = candidate_terms(a0, a_side, a_share, r, d, alpha_h)
    scored = score_candidates(candidates, target_gap)
    best = scored[0]
    residual_after_best = target_gap - float(best["candidate_value"])
    if best["contact_class"] == "EXACT_RESIDUAL_CLOSURE":
        result_class = "QP026_STABLE_RESIDUAL_EXACT_NATIVE_CLOSURE"
        next_frontier = "QP027_PRIVATE_REINFORCED_STABLE_SLOT_FREEZE"
    elif best["contact_class"] == "TIGHT_NATIVE_RESIDUAL_CONTACT":
        result_class = "QP026_STABLE_RESIDUAL_TIGHT_NATIVE_CONTACT"
        next_frontier = "QP027_PRIVATE_ROUTE_EXPOSURE_RESIDUAL_CRUMB_SELECTOR"
    else:
        result_class = "QP026_STABLE_RESIDUAL_NO_NATIVE_CONTACT"
        next_frontier = "QP027_PRIVATE_RESIDUAL_SOURCE_SEARCH"

    closure_rows = [
        {
            "target_stable_gap_to_A_SIDE": target_gap,
            "best_candidate_id": best["candidate_id"],
            "best_candidate_value": best["candidate_value"],
            "residual_after_best_candidate": residual_after_best,
            "residual_abs_after_best_candidate": abs(residual_after_best),
            "stable_lane_open_sum": stable_lane["open_native_sum"],
            "stable_lane_open_plus_best_candidate": float(stable_lane["open_native_sum"]) + float(best["candidate_value"]),
            "A_SIDE": a_side,
            "closes_A_SIDE_after_best_candidate": float(stable_lane["open_native_sum"]) + float(best["candidate_value"]) >= a_side,
        }
    ]

    summary = {
        "artifact": "QP026_PRIVATE_STABLE_LANE_RESIDUAL_CLOSURE_SELECTOR",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp025/qp025_summary.json",
            "artifacts/qp025/qp025_lane_reinforcement_table.csv",
            "artifacts/core/phase_field_engine_summary.json",
        ],
        "selector_used_qp004_labels": False,
        "A0": a0,
        "R": r,
        "D": d,
        "alpha_H": alpha_h,
        "A_SIDE": a_side,
        "A_SHARE": a_share,
        "target_stable_gap_to_A_SIDE": target_gap,
        "qp025_result_class": q025_summary["result_class"],
        "candidate_terms_tested": len(scored),
        "best_candidate_id": best["candidate_id"],
        "best_candidate_value": best["candidate_value"],
        "best_fraction_of_gap_closed": best["fraction_of_gap_closed"],
        "best_relative_delta_to_gap": best["relative_delta_to_gap"],
        "best_contact_class": best["contact_class"],
        "residual_after_best_candidate": residual_after_best,
        "residual_abs_after_best_candidate": abs(residual_after_best),
        "stable_lane_open_plus_best_candidate": closure_rows[0]["stable_lane_open_plus_best_candidate"],
        "closes_A_SIDE_after_best_candidate": closure_rows[0]["closes_A_SIDE_after_best_candidate"],
        "law": "stable residual closure is compared to a sealed family of native constant ratios; exact closure and next residual are kept separate",
        "next_frontier": next_frontier,
    }

    schema_rows = [
        {
            "class": "EXACT_RESIDUAL_CLOSURE",
            "meaning": "candidate equals target residual within numerical precision",
            "status": "closure",
        },
        {
            "class": "TIGHT_NATIVE_RESIDUAL_CONTACT",
            "meaning": "candidate is within 1 percent of target residual",
            "status": "near closure",
        },
        {
            "class": "NEAR_NATIVE_RESIDUAL_CONTACT",
            "meaning": "candidate is within 10 percent of target residual",
            "status": "contact",
        },
        {
            "class": "QP026_STABLE_RESIDUAL_TIGHT_NATIVE_CONTACT",
            "meaning": "stable residual gap has a tight native contact but remains slightly open",
            "status": "frontier",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "A0/(R+2^D) closes nearly all of the stable residual but leaves a small remainder. QP027 should test whether route exposure crumbs account for that remainder.",
            "launch_from": "qp026_native_residual_candidate_table.csv;qp026_residual_closure_table.csv",
            "target_output": "route exposure residual crumb selector",
        }
    ]

    candidate_fields = [
        "QP026_rank",
        "candidate_id",
        "numerator",
        "denominator_basis",
        "denominator_value",
        "candidate_value",
        "target_gap",
        "signed_delta_to_gap",
        "abs_delta_to_gap",
        "relative_delta_to_gap",
        "fraction_of_gap_closed",
        "contact_class",
    ]
    write_csv(CANDIDATE_OUT, scored, candidate_fields)
    write_csv(
        CLOSURE_OUT,
        closure_rows,
        [
            "target_stable_gap_to_A_SIDE",
            "best_candidate_id",
            "best_candidate_value",
            "residual_after_best_candidate",
            "residual_abs_after_best_candidate",
            "stable_lane_open_sum",
            "stable_lane_open_plus_best_candidate",
            "A_SIDE",
            "closes_A_SIDE_after_best_candidate",
        ],
    )
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, scored[:8])

    print(result_class)
    print(f"target_stable_gap_to_A_SIDE={target_gap}")
    print(f"best_candidate_id={best['candidate_id']}")
    print(f"best_candidate_value={best['candidate_value']}")
    print(f"best_fraction_of_gap_closed={best['fraction_of_gap_closed']}")
    print(f"residual_after_best_candidate={residual_after_best}")
    print(f"closes_A_SIDE_after_best_candidate={summary['closes_A_SIDE_after_best_candidate']}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
