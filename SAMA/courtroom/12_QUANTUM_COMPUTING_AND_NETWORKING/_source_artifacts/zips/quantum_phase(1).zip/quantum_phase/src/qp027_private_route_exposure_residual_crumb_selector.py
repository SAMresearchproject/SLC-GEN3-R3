from __future__ import annotations

import csv
import itertools
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP001_ROUTES = ARTIFACTS / "qp001" / "qp001_qubit_phase_functional_table.csv"
QP026_SUMMARY = ARTIFACTS / "qp026" / "qp026_summary.json"
QP026_CLOSURE = ARTIFACTS / "qp026" / "qp026_residual_closure_table.csv"

QP027_DIR = ARTIFACTS / "qp027"
PREFLIGHT_OUT = QP027_DIR / "qp027_preflight.md"
SUMMARY_OUT = QP027_DIR / "qp027_summary.json"
CRUMB_OUT = QP027_DIR / "qp027_route_exposure_crumb_table.csv"
CLOSURE_OUT = QP027_DIR / "qp027_stable_residual_chain_table.csv"
SCHEMA_OUT = QP027_DIR / "qp027_schema.csv"
NEXT_OUT = QP027_DIR / "qp027_next_frontier.csv"
DOC_OUT = REPORTS / "QP027_PRIVATE_ROUTE_EXPOSURE_RESIDUAL_CRUMB_SELECTOR.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP027_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP027 Preflight - Route Exposure Residual Crumb Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP027 starts from the QP026 remaining residual after `A0 / (R + 2^D)` and tests
whether QP001 route-exposure crumbs account for that remainder.

## Selector Inputs

```text
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp026/qp026_summary.json
artifacts/qp026/qp026_residual_closure_table.csv
```

## Sealed Candidate Family

```text
all unique QP001 route-exposure subsets with subset size 1, 2, or 3
```

No multiplicities are allowed. QP027 may add each route exposure at most once.

## Question

```text
Does the QP026 remainder match a native route-exposure crumb bundle, and does
that bundle close A_SIDE or leave a smaller residual?
```
""",
        encoding="utf-8",
    )


def score_bundles(route_rows: list[dict[str, str]], target: float) -> list[dict[str, object]]:
    terms = [
        {
            "qubit_id": row["qubit_id"],
            "qubit_native_route": row["qubit_native_route"],
            "Q_native_class": row["Q_native_class"],
            "A_exposure_per_t_SW": float(row["A_exposure_per_t_SW"]),
        }
        for row in route_rows
    ]
    scored: list[dict[str, object]] = []
    for size in (1, 2, 3):
        for combo in itertools.combinations(terms, size):
            value = sum(term["A_exposure_per_t_SW"] for term in combo)
            abs_delta = abs(value - target)
            signed_delta = value - target
            relative_delta = abs_delta / target if target else 0.0
            fraction_closed = value / target if target else 0.0
            if abs_delta <= 1e-12:
                contact_class = "EXACT_ROUTE_EXPOSURE_CRUMB_CLOSURE"
            elif relative_delta <= 0.01:
                contact_class = "TIGHT_ROUTE_EXPOSURE_CRUMB_CONTACT"
            elif relative_delta <= 0.10:
                contact_class = "NEAR_ROUTE_EXPOSURE_CRUMB_CONTACT"
            else:
                contact_class = "NON_CONTACT_ROUTE_EXPOSURE_BUNDLE"
            scored.append(
                {
                    "bundle_size": size,
                    "route_bundle": ";".join(term["qubit_id"] for term in combo),
                    "route_classes": ";".join(term["Q_native_class"] for term in combo),
                    "route_exposure_sum": value,
                    "target_residual_after_qp026": target,
                    "signed_delta_to_target": signed_delta,
                    "abs_delta_to_target": abs_delta,
                    "relative_delta_to_target": relative_delta,
                    "fraction_of_target_closed": fraction_closed,
                    "contact_class": contact_class,
                }
            )
    scored.sort(key=lambda row: (float(row["relative_delta_to_target"]), int(row["bundle_size"]), str(row["route_bundle"])))
    for rank, row in enumerate(scored, start=1):
        row["QP027_rank"] = rank
    return scored


def write_doc(summary: dict[str, object], top_rows: list[dict[str, object]]) -> None:
    top_lines = "\n".join(
        f"| {row['QP027_rank']} | {row['route_bundle']} | {row['route_exposure_sum']} | {row['fraction_of_target_closed']} | {row['relative_delta_to_target']} | {row['contact_class']} |"
        for row in top_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP027 - Private Route Exposure Residual Crumb Selector

## Result

```text
{summary['result_class']}
```

QP027 tests QP001 route-exposure bundles against the residual left by QP026.

## Target

```text
residual_after_qp026 = {summary['target_residual_after_qp026']}
```

## Top Route Crumbs

| rank | route bundle | exposure sum | fraction closed | relative delta | class |
| ---: | --- | ---: | ---: | ---: | --- |
{top_lines}

## Key Fields

```text
best_route_bundle = {summary['best_route_bundle']}
best_route_exposure_sum = {summary['best_route_exposure_sum']}
best_fraction_of_target_closed = {summary['best_fraction_of_target_closed']}
residual_after_best_bundle = {summary['residual_after_best_bundle']}
stable_chain_closes_A_SIDE = {summary['stable_chain_closes_A_SIDE']}
```

## Interpretation

The best sealed bundle is:

```text
QUBIT-NL-001 + QUBIT-UNK-001 + QUBIT-CL-001
```

It closes about 99.568 percent of the QP026 remainder but still leaves an
ultra-small residual. The stable chain is still just under `A_SIDE`.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    route_rows = read_csv(QP001_ROUTES)
    q026_summary = read_json(QP026_SUMMARY)
    q026_closure = read_csv(QP026_CLOSURE)[0]
    target = float(q026_summary["residual_after_best_candidate"])
    scored = score_bundles(route_rows, target)
    best = scored[0]
    residual_after_best = target - float(best["route_exposure_sum"])
    stable_open_sum = float(q026_closure["stable_lane_open_sum"])
    best_qp026 = float(q026_summary["best_candidate_value"])
    a_side = float(q026_summary["A_SIDE"])
    stable_chain = stable_open_sum + best_qp026 + float(best["route_exposure_sum"])
    closes_a_side = stable_chain >= a_side

    if best["contact_class"] == "EXACT_ROUTE_EXPOSURE_CRUMB_CLOSURE" and closes_a_side:
        result_class = "QP027_ROUTE_EXPOSURE_CRUMB_EXACTLY_CLOSES_STABLE_LANE"
        next_frontier = "QP028_PRIVATE_STABLE_SLOT_PROMOTION_FREEZE"
    elif best["contact_class"] == "TIGHT_ROUTE_EXPOSURE_CRUMB_CONTACT":
        result_class = "QP027_ROUTE_EXPOSURE_CRUMB_TIGHT_CONTACT"
        next_frontier = "QP028_PRIVATE_ULTRA_RESIDUAL_FLOOR_SELECTOR"
    else:
        result_class = "QP027_ROUTE_EXPOSURE_CRUMB_NO_CONTACT"
        next_frontier = "QP028_PRIVATE_RESIDUAL_FLOOR_SEARCH"

    chain_rows = [
        {
            "stable_open_sum": stable_open_sum,
            "qp026_best_candidate_id": q026_summary["best_candidate_id"],
            "qp026_best_candidate_value": best_qp026,
            "qp027_best_route_bundle": best["route_bundle"],
            "qp027_best_route_exposure_sum": best["route_exposure_sum"],
            "stable_chain_sum": stable_chain,
            "A_SIDE": a_side,
            "stable_chain_gap_to_A_SIDE": max(0.0, a_side - stable_chain),
            "stable_chain_closes_A_SIDE": closes_a_side,
        }
    ]

    summary = {
        "artifact": "QP027_PRIVATE_ROUTE_EXPOSURE_RESIDUAL_CRUMB_SELECTOR",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp001/qp001_qubit_phase_functional_table.csv",
            "artifacts/qp026/qp026_summary.json",
            "artifacts/qp026/qp026_residual_closure_table.csv",
        ],
        "selector_used_qp004_labels": False,
        "candidate_bundles_tested": len(scored),
        "target_residual_after_qp026": target,
        "best_route_bundle": best["route_bundle"],
        "best_route_classes": best["route_classes"],
        "best_route_exposure_sum": best["route_exposure_sum"],
        "best_fraction_of_target_closed": best["fraction_of_target_closed"],
        "best_relative_delta_to_target": best["relative_delta_to_target"],
        "best_contact_class": best["contact_class"],
        "residual_after_best_bundle": residual_after_best,
        "residual_abs_after_best_bundle": abs(residual_after_best),
        "stable_chain_sum": stable_chain,
        "stable_chain_gap_to_A_SIDE": max(0.0, a_side - stable_chain),
        "stable_chain_closes_A_SIDE": closes_a_side,
        "law": "the QP026 residual is compared to sealed route-exposure subsets from QP001; exact closure and ultra-residual are kept separate",
        "next_frontier": next_frontier,
    }
    schema_rows = [
        {
            "class": "EXACT_ROUTE_EXPOSURE_CRUMB_CLOSURE",
            "meaning": "route exposure bundle equals QP026 remainder within numerical precision",
            "status": "closure",
        },
        {
            "class": "TIGHT_ROUTE_EXPOSURE_CRUMB_CONTACT",
            "meaning": "route exposure bundle is within 1 percent of QP026 remainder",
            "status": "near closure",
        },
        {
            "class": "QP027_ROUTE_EXPOSURE_CRUMB_TIGHT_CONTACT",
            "meaning": "route exposure crumbs explain nearly all of the QP026 remainder but leave an ultra-residual",
            "status": "frontier",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP027 leaves an ultra-small residual after the best QP001 route exposure bundle. QP028 should test whether this is a native floor or a stop boundary.",
            "launch_from": "qp027_route_exposure_crumb_table.csv;qp027_stable_residual_chain_table.csv",
            "target_output": "ultra residual floor selector",
        }
    ]

    fields = [
        "QP027_rank",
        "bundle_size",
        "route_bundle",
        "route_classes",
        "route_exposure_sum",
        "target_residual_after_qp026",
        "signed_delta_to_target",
        "abs_delta_to_target",
        "relative_delta_to_target",
        "fraction_of_target_closed",
        "contact_class",
    ]
    write_csv(CRUMB_OUT, scored, fields)
    write_csv(
        CLOSURE_OUT,
        chain_rows,
        [
            "stable_open_sum",
            "qp026_best_candidate_id",
            "qp026_best_candidate_value",
            "qp027_best_route_bundle",
            "qp027_best_route_exposure_sum",
            "stable_chain_sum",
            "A_SIDE",
            "stable_chain_gap_to_A_SIDE",
            "stable_chain_closes_A_SIDE",
        ],
    )
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, scored[:8])

    print(result_class)
    print(f"target_residual_after_qp026={target}")
    print(f"best_route_bundle={best['route_bundle']}")
    print(f"best_route_exposure_sum={best['route_exposure_sum']}")
    print(f"best_fraction_of_target_closed={best['fraction_of_target_closed']}")
    print(f"residual_after_best_bundle={residual_after_best}")
    print(f"stable_chain_gap_to_A_SIDE={summary['stable_chain_gap_to_A_SIDE']}")
    print(f"stable_chain_closes_A_SIDE={closes_a_side}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
