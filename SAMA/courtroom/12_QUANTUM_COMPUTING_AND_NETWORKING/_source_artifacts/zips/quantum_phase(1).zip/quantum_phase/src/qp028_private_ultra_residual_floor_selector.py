from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP001_ROUTES = ARTIFACTS / "qp001" / "qp001_qubit_phase_functional_table.csv"
QP027_SUMMARY = ARTIFACTS / "qp027" / "qp027_summary.json"
QP027_CHAIN = ARTIFACTS / "qp027" / "qp027_stable_residual_chain_table.csv"

QP028_DIR = ARTIFACTS / "qp028"
PREFLIGHT_OUT = QP028_DIR / "qp028_preflight.md"
SUMMARY_OUT = QP028_DIR / "qp028_summary.json"
FLOOR_OUT = QP028_DIR / "qp028_ultra_residual_floor_table.csv"
OVERSHOOT_OUT = QP028_DIR / "qp028_route_floor_overshoot_table.csv"
SCHEMA_OUT = QP028_DIR / "qp028_schema.csv"
NEXT_OUT = QP028_DIR / "qp028_next_frontier.csv"
DOC_OUT = REPORTS / "QP028_PRIVATE_ULTRA_RESIDUAL_FLOOR_SELECTOR.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP028_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP028 Preflight - Ultra Residual Floor Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP028 starts from the QP027 ultra-residual and tests whether any whole QP001
route-exposure quantum can be added without overshooting `A_SIDE`.

## Selector Inputs

```text
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp027/qp027_summary.json
artifacts/qp027/qp027_stable_residual_chain_table.csv
```

## Question

```text
Is the QP027 ultra-residual above or below the smallest available QP001 route
exposure floor?
```
""",
        encoding="utf-8",
    )


def write_doc(summary: dict[str, object], overshoot_rows: list[dict[str, object]]) -> None:
    top_lines = "\n".join(
        f"| {row['rank']} | {row['qubit_id']} | {row['A_exposure_per_t_SW']} | {row['overshoot_after_addition']} | {row['addition_class']} |"
        for row in overshoot_rows[:6]
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP028 - Private Ultra Residual Floor Selector

## Result

```text
{summary['result_class']}
```

QP028 tests whether the QP027 ultra-residual is large enough to accept another
whole QP001 route-exposure quantum.

## Floor Result

```text
ultra_residual = {summary['ultra_residual_after_qp027']}
minimum_route_exposure = {summary['minimum_route_exposure']}
minimum_route = {summary['minimum_route']}
ultra_residual_fraction_of_minimum_route = {summary['ultra_residual_fraction_of_minimum_route']}
below_route_exposure_floor = {summary['below_route_exposure_floor']}
```

## Lowest Additions

| rank | route | exposure | overshoot after addition | class |
| ---: | --- | ---: | ---: | --- |
{top_lines}

## Interpretation

The remaining residual is below the smallest whole QP001 route exposure. Adding
even the smallest route exposure overshoots `A_SIDE`. This is a real boundary
for the current Phase 2 particle lane: the stable chain is close, but it does
not close under whole route-exposure crumbs.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    route_rows = read_csv(QP001_ROUTES)
    q027_summary = read_json(QP027_SUMMARY)
    q027_chain = read_csv(QP027_CHAIN)[0]
    ultra_residual = float(q027_summary["stable_chain_gap_to_A_SIDE"])
    stable_chain_sum = float(q027_summary["stable_chain_sum"])
    a_side = float(q027_chain["A_SIDE"])

    routes = sorted(route_rows, key=lambda row: float(row["A_exposure_per_t_SW"]))
    min_route = routes[0]
    min_exposure = float(min_route["A_exposure_per_t_SW"])
    below_floor = ultra_residual < min_exposure
    overshoot_rows: list[dict[str, object]] = []
    for rank, row in enumerate(routes, start=1):
        exposure = float(row["A_exposure_per_t_SW"])
        chain_after = stable_chain_sum + exposure
        overshoot = max(0.0, chain_after - a_side)
        gap_after = max(0.0, a_side - chain_after)
        if chain_after == a_side:
            addition_class = "EXACT_WHOLE_ROUTE_EXPOSURE_CLOSURE"
        elif chain_after > a_side:
            addition_class = "WHOLE_ROUTE_EXPOSURE_OVERSHOOTS_A_SIDE"
        else:
            addition_class = "WHOLE_ROUTE_EXPOSURE_STILL_BELOW_A_SIDE"
        overshoot_rows.append(
            {
                "rank": rank,
                "qubit_id": row["qubit_id"],
                "Q_native_class": row["Q_native_class"],
                "A_exposure_per_t_SW": exposure,
                "stable_chain_after_addition": chain_after,
                "gap_after_addition": gap_after,
                "overshoot_after_addition": overshoot,
                "addition_class": addition_class,
            }
        )

    exact = [row for row in overshoot_rows if row["addition_class"] == "EXACT_WHOLE_ROUTE_EXPOSURE_CLOSURE"]
    non_overshoot = [row for row in overshoot_rows if row["addition_class"] == "WHOLE_ROUTE_EXPOSURE_STILL_BELOW_A_SIDE"]
    if exact:
        result_class = "QP028_WHOLE_ROUTE_EXPOSURE_EXACTLY_CLOSES_STABLE_LANE"
        next_frontier = "QP029_PRIVATE_STABLE_SLOT_PROMOTION_FREEZE"
    elif below_floor and not non_overshoot:
        result_class = "QP028_ULTRA_RESIDUAL_BELOW_ROUTE_EXPOSURE_FLOOR_BOUNDARY"
        next_frontier = "STOP_PHASE2_STABLE_RESIDUAL_FLOOR_BOUNDARY"
    else:
        result_class = "QP028_ULTRA_RESIDUAL_ROUTE_FLOOR_OPEN"
        next_frontier = "QP029_PRIVATE_ROUTE_FLOOR_EXTENSION_SELECTOR"

    floor_rows = [
        {
            "ultra_residual_after_qp027": ultra_residual,
            "minimum_route": min_route["qubit_id"],
            "minimum_route_class": min_route["Q_native_class"],
            "minimum_route_exposure": min_exposure,
            "ultra_residual_fraction_of_minimum_route": ultra_residual / min_exposure if min_exposure else 0.0,
            "below_route_exposure_floor": below_floor,
            "smallest_route_overshoot_if_added": overshoot_rows[0]["overshoot_after_addition"],
        }
    ]
    summary = {
        "artifact": "QP028_PRIVATE_ULTRA_RESIDUAL_FLOOR_SELECTOR",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp001/qp001_qubit_phase_functional_table.csv",
            "artifacts/qp027/qp027_summary.json",
            "artifacts/qp027/qp027_stable_residual_chain_table.csv",
        ],
        "selector_used_qp004_labels": False,
        "ultra_residual_after_qp027": ultra_residual,
        "stable_chain_sum": stable_chain_sum,
        "A_SIDE": a_side,
        "minimum_route": min_route["qubit_id"],
        "minimum_route_class": min_route["Q_native_class"],
        "minimum_route_exposure": min_exposure,
        "ultra_residual_fraction_of_minimum_route": ultra_residual / min_exposure if min_exposure else 0.0,
        "below_route_exposure_floor": below_floor,
        "routes_that_close_without_overshoot": len(exact),
        "routes_that_remain_below_A_SIDE": len(non_overshoot),
        "smallest_route_overshoot_if_added": overshoot_rows[0]["overshoot_after_addition"],
        "law": "stable chain may only add whole QP001 route-exposure quanta in this gate; residuals below that floor become a boundary",
        "next_frontier": next_frontier,
    }

    schema_rows = [
        {
            "class": "WHOLE_ROUTE_EXPOSURE_OVERSHOOTS_A_SIDE",
            "meaning": "adding this route exposure takes the stable chain past A_SIDE",
            "status": "overshoot",
        },
        {
            "class": "QP028_ULTRA_RESIDUAL_BELOW_ROUTE_EXPOSURE_FLOOR_BOUNDARY",
            "meaning": "ultra residual is below the smallest available whole route exposure",
            "status": "boundary",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP028 finds the remaining residual below the whole-route exposure floor. Further closure requires a new native floor concept or a decision to stop this Phase 2 lane here.",
            "launch_from": "qp028_ultra_residual_floor_table.csv;qp028_route_floor_overshoot_table.csv",
            "target_output": "phase 2 boundary decision",
        }
    ]

    write_csv(
        FLOOR_OUT,
        floor_rows,
        [
            "ultra_residual_after_qp027",
            "minimum_route",
            "minimum_route_class",
            "minimum_route_exposure",
            "ultra_residual_fraction_of_minimum_route",
            "below_route_exposure_floor",
            "smallest_route_overshoot_if_added",
        ],
    )
    write_csv(
        OVERSHOOT_OUT,
        overshoot_rows,
        [
            "rank",
            "qubit_id",
            "Q_native_class",
            "A_exposure_per_t_SW",
            "stable_chain_after_addition",
            "gap_after_addition",
            "overshoot_after_addition",
            "addition_class",
        ],
    )
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, overshoot_rows)

    print(result_class)
    print(f"ultra_residual_after_qp027={ultra_residual}")
    print(f"minimum_route={min_route['qubit_id']}")
    print(f"minimum_route_exposure={min_exposure}")
    print(f"ultra_residual_fraction_of_minimum_route={summary['ultra_residual_fraction_of_minimum_route']}")
    print(f"smallest_route_overshoot_if_added={summary['smallest_route_overshoot_if_added']}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
