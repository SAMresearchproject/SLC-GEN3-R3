from __future__ import annotations

import ast
import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

SAM_ROOT = Path("C:/VS/Stam_model-A-v1.0")
G510I_SUMMARY = SAM_ROOT / "tests" / "Substrate" / "G510I_COSMIC_A_INVENTORY_ACCOUNTING" / "G510I_summary.json"
G510I_SEALED = SAM_ROOT / "audit" / "audits" / "SEALED_ENVELOPE_G510I_COSMIC_A_INVENTORY_ACCOUNTING_2026_05_27.md"
G510I_VERDICT = SAM_ROOT / "audit" / "audits" / "VERDICT_G510I_COSMIC_A_INVENTORY_ACCOUNTING_2026_05_27.md"

QP026_SUMMARY = ARTIFACTS / "qp026" / "qp026_summary.json"
QP027_SUMMARY = ARTIFACTS / "qp027" / "qp027_summary.json"
QP028_SUMMARY = ARTIFACTS / "qp028" / "qp028_summary.json"

QP029_DIR = ARTIFACTS / "qp029"
PREFLIGHT_OUT = QP029_DIR / "qp029_preflight.md"
SUMMARY_OUT = QP029_DIR / "qp029_summary.json"
SOURCE_OUT = QP029_DIR / "qp029_sealed_source_provenance_table.csv"
COMPARISON_OUT = QP029_DIR / "qp029_boundary_floor_comparison_table.csv"
ROLE_OUT = QP029_DIR / "qp029_floor_role_map.csv"
NEXT_OUT = QP029_DIR / "qp029_next_frontier.csv"
SCHEMA_OUT = QP029_DIR / "qp029_schema.csv"
DOC_OUT = REPORTS / "QP029_PRIVATE_SEALED_BOUNDARY_INVENTORY_FLOOR_IMPORT.md"


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_preflight() -> None:
    QP029_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP029 Preflight - Sealed Boundary Inventory Floor Import

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP029 does not rerun, validate, or score G510I, QP026, QP027, or QP028. It
imports the sealed G510I boundary-inventory floor as upstream SAM lab provenance
and classifies its downstream role in the existing private QP residual chain.

## Selector Inputs

```text
C:/VS/Stam_model-A-v1.0/tests/Substrate/G510I_COSMIC_A_INVENTORY_ACCOUNTING/G510I_summary.json
C:/VS/Stam_model-A-v1.0/audit/audits/SEALED_ENVELOPE_G510I_COSMIC_A_INVENTORY_ACCOUNTING_2026_05_27.md
C:/VS/Stam_model-A-v1.0/audit/audits/VERDICT_G510I_COSMIC_A_INVENTORY_ACCOUNTING_2026_05_27.md
artifacts/qp026/qp026_summary.json
artifacts/qp027/qp027_summary.json
artifacts/qp028/qp028_summary.json
```

## Question

```text
Does the sealed G510I boundary_inventory identify QP026's A0/(R+2^D) floor as
existing SAM lab data, and what role does that floor play in the QP026-QP028
residual chain?
```
""",
        encoding="utf-8",
    )


def g510i_cosmic_inventory(summary: dict[str, object]) -> dict[str, float]:
    for check in summary["validation_checks"]:  # type: ignore[index]
        if check["name"] == "cosmic average inventory can be projected after native accounting":
            detail = ast.literal_eval(check["detail"])
            return {key: float(value) for key, value in detail.items()}
    raise ValueError("G510I cosmic average inventory check not found")


def classify_match(delta: float, tolerance: float) -> str:
    if delta <= tolerance:
        return "EXACT_WITHIN_NUMERICAL_TOLERANCE"
    if delta <= 1e-12:
        return "NUMERIC_CONTACT"
    return "NON_MATCH"


def write_doc(summary: dict[str, object], comparison_rows: list[dict[str, object]]) -> None:
    comparison_lines = "\n".join(
        f"| {row['quantity']} | {row['value']} | {row['role']} |"
        for row in comparison_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP029 - Private Sealed Boundary Inventory Floor Import

## Result

```text
{summary['result_class']}
```

QP029 imports the sealed SAM lab G510I boundary-inventory floor into the private
QuantumPhase chain.

## Imported Sealed SAM Input

```text
source_test = G510I_COSMIC_A_INVENTORY_ACCOUNTING
source_status = {summary['g510i_status']}
sealed_envelope_present = {summary['sealed_envelope_present']}
verdict_present = {summary['verdict_present']}
boundary_inventory = {summary['g510i_boundary_inventory_value']}
```

## Boundary Floor Match

```text
QP026 candidate = {summary['qp026_best_candidate_id']}
QP026 candidate value = {summary['qp026_best_candidate_value']}
absolute delta = {summary['absolute_delta_qp026_to_g510i_boundary']}
match class = {summary['boundary_floor_match_class']}
```

The QP026 floor is therefore not just a private QP candidate. It is the same
number as the sealed SAM lab boundary-inventory floor:

```text
A0 / (R + 2^D) = A0 / 20
```

## Residual Chain Role

| quantity | value | role |
| --- | ---: | --- |
{comparison_lines}

## Interpretation

The sealed G510I result upgrades the QP026 floor from candidate-only status to
imported existing SAM lab data. Downstream use remains one-way: QP may use this
as provenance, but QP029 does not promote a private QP result back into the
public SAM lab record.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    g510i = read_json(G510I_SUMMARY)
    qp026 = read_json(QP026_SUMMARY)
    qp027 = read_json(QP027_SUMMARY)
    qp028 = read_json(QP028_SUMMARY)

    inventory = g510i_cosmic_inventory(g510i)
    boundary_inventory = inventory["boundary_inventory"]
    qp026_candidate = float(qp026["best_candidate_value"])
    qp026_gap = float(qp026["target_stable_gap_to_A_SIDE"])
    qp026_residual_after_candidate = float(qp026["residual_after_best_candidate"])
    qp027_route_sum = float(qp027["best_route_exposure_sum"])
    qp027_ultra_residual = float(qp027["stable_chain_gap_to_A_SIDE"])
    qp028_minimum_route_exposure = float(qp028["minimum_route_exposure"])
    qp028_overshoot = float(qp028["smallest_route_overshoot_if_added"])

    a0 = float(qp026["A0"])
    r = int(qp026["R"])
    d = int(qp026["D"])
    native_denominator = r + (2**d)
    native_floor = a0 / native_denominator
    delta_qp026_to_g510i = abs(qp026_candidate - boundary_inventory)
    delta_native_to_g510i = abs(native_floor - boundary_inventory)
    tolerance = 1e-18
    match_class = classify_match(delta_qp026_to_g510i, tolerance)

    if (
        g510i["status"] == "PASS"
        and G510I_SEALED.exists()
        and G510I_VERDICT.exists()
        and match_class == "EXACT_WITHIN_NUMERICAL_TOLERANCE"
    ):
        result_class = "QP029_SEALED_BOUNDARY_FLOOR_MATCHES_QP026_NATIVE_CANDIDATE"
        next_frontier = "QP030_PRIVATE_BOUNDARY_FLOOR_TO_LEDGER_CELL_ROLE_SELECTOR"
    elif match_class != "NON_MATCH":
        result_class = "QP029_BOUNDARY_FLOOR_NUMERIC_CONTACT_NEEDS_ROLE_SELECTOR"
        next_frontier = "QP030_PRIVATE_BOUNDARY_FLOOR_ROLE_SELECTOR"
    else:
        result_class = "QP029_BOUNDARY_FLOOR_DOES_NOT_MATCH_QP026_CANDIDATE"
        next_frontier = "STOP_BOUNDARY_FLOOR_IMPORT"

    source_rows = [
        {
            "source": "G510I_COSMIC_A_INVENTORY_ACCOUNTING",
            "path": str(G510I_SUMMARY),
            "status": g510i["status"],
            "result_class": g510i["result_class"],
            "sealed_envelope_present": G510I_SEALED.exists(),
            "verdict_present": G510I_VERDICT.exists(),
            "validation_checks": f"{g510i['validation_checks_passed']}/{g510i['validation_checks_total']}",
            "wrong_controls": f"{g510i['wrong_controls_passed']}/{g510i['wrong_controls_total']}",
            "import_policy": "DOWNSTREAM_QP_USE_ALLOWED_NO_UPSTREAM_PROMOTION",
        },
    ]

    comparison_rows = [
        {
            "quantity": "G510I boundary_inventory",
            "value": boundary_inventory,
            "role": "SEALED_SAM_LAB_BOUNDARY_INVENTORY_FLOOR",
        },
        {
            "quantity": "QP026 best candidate",
            "value": qp026_candidate,
            "role": "PRIVATE_QP_NATIVE_RESIDUAL_CANDIDATE",
        },
        {
            "quantity": "A0/(R+2^D)",
            "value": native_floor,
            "role": "NATIVE_FORM_OF_SHARED_FLOOR",
        },
        {
            "quantity": "QP026 target gap to A_SIDE",
            "value": qp026_gap,
            "role": "STABLE_LANE_GAP_BEFORE_BOUNDARY_FLOOR",
        },
        {
            "quantity": "residual after sealed floor",
            "value": qp026_gap - boundary_inventory,
            "role": "QP027_ROUTE_CRUMB_TARGET",
        },
        {
            "quantity": "QP027 best route crumb sum",
            "value": qp027_route_sum,
            "role": "ROUTE_EXPOSURE_CRUMB_CONTRIBUTION",
        },
        {
            "quantity": "QP027/QP028 ultra residual",
            "value": qp027_ultra_residual,
            "role": "BELOW_WHOLE_ROUTE_EXPOSURE_FLOOR",
        },
        {
            "quantity": "QP028 minimum whole route exposure",
            "value": qp028_minimum_route_exposure,
            "role": "SMALLEST_AVAILABLE_WHOLE_ROUTE_QUANTUM",
        },
    ]

    role_rows = [
        {
            "item": "A0/(R+2^D)",
            "status_before_qp029": "QP026_NATIVE_CANDIDATE",
            "status_after_qp029": "EXISTING_SEALED_SAM_BOUNDARY_INVENTORY_DATA",
            "allowed_use": "QP_DOWNSTREAM_PROVENANCE",
            "blocked_use": "UPSTREAM_SAM_PROMOTION_FROM_PRIVATE_QP",
        },
        {
            "item": "residual_after_sealed_floor",
            "status_before_qp029": "QP026_REMAINDER",
            "status_after_qp029": "BOUNDARY_FLOOR_REMAINDER_FOR_ROUTE_CRUMBS",
            "allowed_use": "QP030_ROLE_SELECTOR_INPUT",
            "blocked_use": "CLAIMING_FINAL_CELL_ROLE_WITHOUT_QP030",
        },
        {
            "item": "ultra_residual_after_qp027",
            "status_before_qp029": "QP028_STOP_BOUNDARY",
            "status_after_qp029": "ROUTE_FLOOR_BOUNDARY_DOWNSTREAM_OF_SEALED_FLOOR",
            "allowed_use": "PHASE2_BOUNDARY_CONDITION",
            "blocked_use": "ADDING_SUB_ROUTE_CRUMBS_WITHOUT_NEW RULE",
        },
    ]

    schema_rows = [
        {
            "class": "QP029_SEALED_BOUNDARY_FLOOR_MATCHES_QP026_NATIVE_CANDIDATE",
            "meaning": "sealed SAM lab boundary inventory equals the private QP026 native residual floor",
            "status": "imported provenance",
        },
        {
            "class": "DOWNSTREAM_QP_USE_ALLOWED_NO_UPSTREAM_PROMOTION",
            "meaning": "QP can use sealed SAM lab data, but private QP results do not promote back to SAM automatically",
            "status": "routing rule",
        },
    ]

    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "The sealed boundary floor now has provenance. QP030 should assign the floor's native role without rerunning old tests.",
            "launch_from": "qp029_boundary_floor_comparison_table.csv;qp029_floor_role_map.csv",
            "target_output": "boundary floor to ledger cell role selector",
        }
    ]

    fraction_closed = boundary_inventory / qp026_gap if qp026_gap else 0.0
    residual_after_floor = qp026_gap - boundary_inventory
    residual_delta_to_qp026 = abs(residual_after_floor - qp026_residual_after_candidate)

    summary = {
        "artifact": "QP029_PRIVATE_SEALED_BOUNDARY_INVENTORY_FLOOR_IMPORT",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "sealed_sam_lab_data_imported": True,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            str(G510I_SUMMARY),
            str(G510I_SEALED),
            str(G510I_VERDICT),
            "artifacts/qp026/qp026_summary.json",
            "artifacts/qp027/qp027_summary.json",
            "artifacts/qp028/qp028_summary.json",
        ],
        "g510i_status": g510i["status"],
        "g510i_result_class": g510i["result_class"],
        "sealed_envelope_present": G510I_SEALED.exists(),
        "verdict_present": G510I_VERDICT.exists(),
        "g510i_boundary_inventory_value": boundary_inventory,
        "qp026_best_candidate_id": qp026["best_candidate_id"],
        "qp026_best_candidate_value": qp026_candidate,
        "native_floor_formula": "A0/(R+2^D)",
        "A0": a0,
        "R": r,
        "D": d,
        "native_denominator_R_plus_2_pow_D": native_denominator,
        "native_floor_value": native_floor,
        "absolute_delta_qp026_to_g510i_boundary": delta_qp026_to_g510i,
        "absolute_delta_native_to_g510i_boundary": delta_native_to_g510i,
        "boundary_floor_match_tolerance": tolerance,
        "boundary_floor_match_class": match_class,
        "qp026_target_gap_to_A_SIDE": qp026_gap,
        "fraction_of_qp026_gap_closed_by_sealed_floor": fraction_closed,
        "residual_after_sealed_floor": residual_after_floor,
        "qp026_recorded_residual_after_best_candidate": qp026_residual_after_candidate,
        "residual_delta_to_qp026_record": residual_delta_to_qp026,
        "qp027_best_route_crumb_sum": qp027_route_sum,
        "qp027_ultra_residual_after_route_crumbs": qp027_ultra_residual,
        "qp028_minimum_whole_route_exposure": qp028_minimum_route_exposure,
        "qp028_ultra_residual_fraction_of_minimum_route": qp028["ultra_residual_fraction_of_minimum_route"],
        "qp028_smallest_route_overshoot_if_added": qp028_overshoot,
        "routing_law": "sealed SAM lab data can move downstream into private QP; private QP cannot promote upstream without a separate SAM route",
        "role_statement": "A0/(R+2^D) is an imported sealed SAM boundary-inventory floor in the QP residual chain",
        "next_frontier": next_frontier,
    }

    write_csv(
        SOURCE_OUT,
        source_rows,
        [
            "source",
            "path",
            "status",
            "result_class",
            "sealed_envelope_present",
            "verdict_present",
            "validation_checks",
            "wrong_controls",
            "import_policy",
        ],
    )
    write_csv(COMPARISON_OUT, comparison_rows, ["quantity", "value", "role"])
    write_csv(
        ROLE_OUT,
        role_rows,
        ["item", "status_before_qp029", "status_after_qp029", "allowed_use", "blocked_use"],
    )
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, comparison_rows)

    print(result_class)
    print(f"g510i_boundary_inventory={boundary_inventory}")
    print(f"qp026_best_candidate={qp026_candidate}")
    print(f"native_floor={native_floor}")
    print(f"absolute_delta_qp026_to_g510i_boundary={delta_qp026_to_g510i}")
    print(f"fraction_of_qp026_gap_closed_by_sealed_floor={fraction_closed}")
    print(f"residual_after_sealed_floor={residual_after_floor}")
    print(f"qp027_ultra_residual_after_route_crumbs={qp027_ultra_residual}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
