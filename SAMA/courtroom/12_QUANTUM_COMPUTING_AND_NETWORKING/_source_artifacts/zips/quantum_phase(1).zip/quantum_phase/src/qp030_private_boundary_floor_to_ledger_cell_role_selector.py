from __future__ import annotations

import csv
import itertools
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP001_ROUTES = ARTIFACTS / "qp001" / "qp001_qubit_phase_functional_table.csv"
QP016_STABLE_MODES = ARTIFACTS / "qp016" / "qp016_stable_mode_selector_table.csv"
QP025_LANES = ARTIFACTS / "qp025" / "qp025_lane_reinforcement_table.csv"
QP027_CHAIN = ARTIFACTS / "qp027" / "qp027_stable_residual_chain_table.csv"
QP029_SUMMARY = ARTIFACTS / "qp029" / "qp029_summary.json"
QP029_COMPARISON = ARTIFACTS / "qp029" / "qp029_boundary_floor_comparison_table.csv"
QP029_ROLE_MAP = ARTIFACTS / "qp029" / "qp029_floor_role_map.csv"

QP030_DIR = ARTIFACTS / "qp030"
PREFLIGHT_OUT = QP030_DIR / "qp030_preflight.md"
SUMMARY_OUT = QP030_DIR / "qp030_summary.json"
ROLE_SCORE_OUT = QP030_DIR / "qp030_role_score_table.csv"
MECHANISM_OUT = QP030_DIR / "qp030_floor_mechanism_chain.csv"
ROUTE_CONTACT_OUT = QP030_DIR / "qp030_route_floor_contact_table.csv"
LEDGER_CONTACT_OUT = QP030_DIR / "qp030_ledger_threshold_contact_table.csv"
DECISION_OUT = QP030_DIR / "qp030_role_decision_table.csv"
SCHEMA_OUT = QP030_DIR / "qp030_schema.csv"
NEXT_OUT = QP030_DIR / "qp030_next_frontier.csv"
DOC_OUT = REPORTS / "QP030_PRIVATE_BOUNDARY_FLOOR_TO_LEDGER_CELL_ROLE_SELECTOR.md"


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_preflight() -> None:
    QP030_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP030 Preflight - Boundary Floor to Ledger Cell Role Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP030 does not rerun QP026-QP029. It starts from the sealed boundary floor
imported by QP029 and classifies the floor's downstream role in the private QP
chain.

## Selector Inputs

```text
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp016/qp016_stable_mode_selector_table.csv
artifacts/qp025/qp025_lane_reinforcement_table.csv
artifacts/qp027/qp027_stable_residual_chain_table.csv
artifacts/qp029/qp029_summary.json
artifacts/qp029/qp029_boundary_floor_comparison_table.csv
artifacts/qp029/qp029_floor_role_map.csv
```

## Candidate Roles

```text
SEALED_BOUNDARY_INVENTORY_FLOOR
LEDGER_CELL_COMPLETION_SUPPORT
ROUTE_CELL_RESIDUAL_QUANTUM
```

## Question

```text
Does the imported A0/(R+2^D) floor act primarily as a boundary inventory floor,
a ledger-cell completion floor, or a route-cell residual quantum?
```
""",
        encoding="utf-8",
    )


def route_bundle_contacts(route_rows: list[dict[str, str]], target: float) -> list[dict[str, object]]:
    terms = [
        {
            "route_bundle": row["qubit_id"],
            "route_classes": row["Q_native_class"],
            "route_exposure_sum": float(row["A_exposure_per_t_SW"]),
            "bundle_size": 1,
        }
        for row in route_rows
    ]
    base = [
        {
            "qubit_id": row["qubit_id"],
            "Q_native_class": row["Q_native_class"],
            "A_exposure_per_t_SW": float(row["A_exposure_per_t_SW"]),
        }
        for row in route_rows
    ]
    for size in (2, 3):
        for combo in itertools.combinations(base, size):
            terms.append(
                {
                    "route_bundle": ";".join(item["qubit_id"] for item in combo),
                    "route_classes": ";".join(item["Q_native_class"] for item in combo),
                    "route_exposure_sum": sum(float(item["A_exposure_per_t_SW"]) for item in combo),
                    "bundle_size": size,
                }
            )

    rows: list[dict[str, object]] = []
    for term in terms:
        value = float(term["route_exposure_sum"])
        abs_delta = abs(value - target)
        relative_delta = abs_delta / target if target else 0.0
        if relative_delta <= 1e-12:
            contact_class = "EXACT_ROUTE_EXPOSURE_MATCH"
        elif relative_delta <= 0.01:
            contact_class = "TIGHT_ROUTE_EXPOSURE_CONTACT"
        elif relative_delta <= 0.10:
            contact_class = "NEAR_ROUTE_EXPOSURE_CONTACT"
        else:
            contact_class = "NO_ROUTE_EXPOSURE_CONTACT"
        rows.append(
            {
                "bundle_size": term["bundle_size"],
                "route_bundle": term["route_bundle"],
                "route_classes": term["route_classes"],
                "route_exposure_sum": value,
                "target_boundary_floor": target,
                "abs_delta_to_boundary_floor": abs_delta,
                "relative_delta_to_boundary_floor": relative_delta,
                "contact_class": contact_class,
            }
        )
    rows.sort(key=lambda row: (float(row["relative_delta_to_boundary_floor"]), int(row["bundle_size"]), str(row["route_bundle"])))
    for rank, row in enumerate(rows, start=1):
        row["QP030_route_contact_rank"] = rank
    return rows


def ledger_threshold_contacts(a_side: float, a_share: float, boundary_floor: float) -> list[dict[str, object]]:
    thresholds = [
        ("A_SIDE", a_side, "half-write side threshold"),
        ("A_SHARE", a_share, "first reorganization threshold"),
        ("A_WRITE_MIDPOINT", 0.5, "write midpoint"),
        ("A_HORIZON", 1.0, "horizon saturation"),
    ]
    rows: list[dict[str, object]] = []
    for name, value, meaning in thresholds:
        abs_delta = abs(value - boundary_floor)
        relative_delta = abs_delta / value if value else 0.0
        floor_fraction = boundary_floor / value if value else 0.0
        if relative_delta <= 1e-12:
            contact_class = "EXACT_LEDGER_THRESHOLD"
        elif relative_delta <= 0.01:
            contact_class = "TIGHT_LEDGER_THRESHOLD_CONTACT"
        elif floor_fraction < 1.0:
            contact_class = "SUB_THRESHOLD_SUPPORT_SCALE"
        else:
            contact_class = "ABOVE_THRESHOLD_SCALE"
        rows.append(
            {
                "threshold": name,
                "threshold_value": value,
                "boundary_floor": boundary_floor,
                "floor_fraction_of_threshold": floor_fraction,
                "abs_delta": abs_delta,
                "relative_delta": relative_delta,
                "meaning": meaning,
                "contact_class": contact_class,
            }
        )
    return rows


def write_doc(summary: dict[str, object], role_rows: list[dict[str, object]], chain_rows: list[dict[str, object]]) -> None:
    role_lines = "\n".join(
        f"| {row['rank']} | {row['candidate_role']} | {row['role_score']} | {row['decision']} | {row['reason']} |"
        for row in role_rows
    )
    chain_lines = "\n".join(
        f"| {row['chain_step']} | {row['quantity']} | {row['value']} | {row['chain_status']} |"
        for row in chain_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP030 - Private Boundary Floor to Ledger Cell Role Selector

## Result

```text
{summary['result_class']}
```

QP030 classifies the sealed `A0/(R+2^D)` floor imported by QP029.

## Selected Role

```text
primary_role = {summary['selected_primary_role']}
secondary_function = {summary['selected_secondary_function']}
blocked_role = {summary['blocked_role']}
```

## Role Scores

| rank | candidate role | score | decision | reason |
| ---: | --- | ---: | --- | --- |
{role_lines}

## Mechanism Chain

| step | quantity | value | status |
| ---: | --- | ---: | --- |
{chain_lines}

## Interpretation

The floor is selected as a boundary-inventory floor first. It is not a whole
route-exposure quantum and it is not itself a ledger threshold. Its downstream
function is ledger-cell completion support: it supplies almost all of the
stable-lane gap, after which QP route crumbs carry the remaining route-level
structure until the chain stops below the whole-route exposure floor.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    route_rows = read_csv(QP001_ROUTES)
    stable_modes = read_csv(QP016_STABLE_MODES)
    lane_rows = read_csv(QP025_LANES)
    qp027_chain = read_csv(QP027_CHAIN)[0]
    qp029 = read_json(QP029_SUMMARY)
    qp029_comparison = read_csv(QP029_COMPARISON)
    qp029_role_map = read_csv(QP029_ROLE_MAP)

    boundary_floor = float(qp029["g510i_boundary_inventory_value"])
    a_side = float(qp029["qp026_target_gap_to_A_SIDE"]) + float(qp029["stable_chain_sum"]) if "stable_chain_sum" in qp029 else float(qp027_chain["A_SIDE"])
    # QP029 does not store A_SHARE directly; QP016 stores both thresholds.
    a_share = float(stable_modes[0]["stable_threshold_A_SHARE"])
    stable_lane = next(row for row in lane_rows if row["derived_replay_lane"] == "DERIVED_STABLE_ANCHOR_LANE")
    stable_open_sum = float(stable_lane["open_native_sum"])
    stable_gap = float(stable_lane["open_gap_to_A_SIDE"])
    residual_after_floor = float(qp029["residual_after_sealed_floor"])
    route_crumb_sum = float(qp029["qp027_best_route_crumb_sum"])
    ultra_residual = float(qp029["qp027_ultra_residual_after_route_crumbs"])
    minimum_route = float(qp029["qp028_minimum_whole_route_exposure"])
    stable_after_floor = stable_open_sum + boundary_floor
    stable_after_route_crumbs = float(qp027_chain["stable_chain_sum"])
    floor_fraction_of_gap = boundary_floor / stable_gap if stable_gap else 0.0
    residual_fraction_of_min_route = ultra_residual / minimum_route if minimum_route else 0.0

    route_contacts = route_bundle_contacts(route_rows, boundary_floor)
    best_route_contact = route_contacts[0]
    ledger_contacts = ledger_threshold_contacts(float(qp027_chain["A_SIDE"]), a_share, boundary_floor)
    exact_or_tight_route_contact = best_route_contact["contact_class"] in {
        "EXACT_ROUTE_EXPOSURE_MATCH",
        "TIGHT_ROUTE_EXPOSURE_CONTACT",
    }
    exact_ledger_threshold = any(row["contact_class"] == "EXACT_LEDGER_THRESHOLD" for row in ledger_contacts)

    boundary_score = 0
    boundary_reasons: list[str] = []
    if qp029["sealed_sam_lab_data_imported"]:
        boundary_score += 2
        boundary_reasons.append("sealed SAM lab provenance imported")
    if qp029["boundary_floor_match_class"] == "EXACT_WITHIN_NUMERICAL_TOLERANCE":
        boundary_score += 2
        boundary_reasons.append("zero-delta match to QP026 native floor")
    if qp029["native_denominator_R_plus_2_pow_D"] == int(qp029["R"]) + (2 ** int(qp029["D"])):
        boundary_score += 1
        boundary_reasons.append("native denominator is R+2^D")
    if not exact_or_tight_route_contact:
        boundary_score += 1
        boundary_reasons.append("not a whole route-exposure quantum")

    ledger_score = 0
    ledger_reasons: list[str] = []
    if floor_fraction_of_gap >= 0.99:
        ledger_score += 2
        ledger_reasons.append("supplies more than 99 percent of stable-lane A_SIDE gap")
    if stable_after_floor < float(qp027_chain["A_SIDE"]):
        ledger_score += 1
        ledger_reasons.append("supports ledger closure without crossing A_SIDE alone")
    if ultra_residual < minimum_route:
        ledger_score += 1
        ledger_reasons.append("route chain stops below the whole-route exposure floor")
    if not exact_ledger_threshold:
        ledger_reasons.append("not itself an exact ledger threshold")

    route_score = 0
    route_reasons: list[str] = []
    if exact_or_tight_route_contact:
        route_score += 2
        route_reasons.append("matches a whole route-exposure bundle")
    else:
        route_reasons.append("does not match a whole route-exposure bundle")
    if residual_after_floor > 0.0:
        route_score += 1
        route_reasons.append("creates the target that QP027 route crumbs then address")

    role_rows = [
        {
            "candidate_role": "SEALED_BOUNDARY_INVENTORY_FLOOR",
            "role_score": boundary_score,
            "decision": "SELECT_PRIMARY_ROLE",
            "reason": "; ".join(boundary_reasons),
        },
        {
            "candidate_role": "LEDGER_CELL_COMPLETION_SUPPORT",
            "role_score": ledger_score,
            "decision": "SELECT_SECONDARY_FUNCTION",
            "reason": "; ".join(ledger_reasons),
        },
        {
            "candidate_role": "ROUTE_CELL_RESIDUAL_QUANTUM",
            "role_score": route_score,
            "decision": "BLOCK_AS_PRIMARY_ROLE",
            "reason": "; ".join(route_reasons),
        },
    ]
    role_rows.sort(key=lambda row: (-int(row["role_score"]), str(row["candidate_role"])))
    for rank, row in enumerate(role_rows, start=1):
        row["rank"] = rank

    mechanism_rows = [
        {
            "chain_step": 1,
            "quantity": "stable_open_sum",
            "value": stable_open_sum,
            "chain_status": "stable lane below A_SIDE before floor",
        },
        {
            "chain_step": 2,
            "quantity": "sealed_boundary_floor",
            "value": boundary_floor,
            "chain_status": "imported boundary-inventory floor",
        },
        {
            "chain_step": 3,
            "quantity": "stable_after_floor",
            "value": stable_after_floor,
            "chain_status": "near A_SIDE but not crossing",
        },
        {
            "chain_step": 4,
            "quantity": "residual_after_floor",
            "value": residual_after_floor,
            "chain_status": "route crumb target",
        },
        {
            "chain_step": 5,
            "quantity": "qp027_route_crumb_sum",
            "value": route_crumb_sum,
            "chain_status": "route-exposure crumbs add downstream structure",
        },
        {
            "chain_step": 6,
            "quantity": "ultra_residual_after_route_crumbs",
            "value": ultra_residual,
            "chain_status": "below whole-route exposure floor",
        },
    ]

    decision_rows = [
        {
            "decision_item": "selected_primary_role",
            "decision_value": "SEALED_BOUNDARY_INVENTORY_FLOOR",
            "reason": "exact sealed G510I provenance plus exact QP026 native floor match",
        },
        {
            "decision_item": "selected_secondary_function",
            "decision_value": "LEDGER_CELL_COMPLETION_SUPPORT",
            "reason": "floor closes almost all of the stable-lane gap but does not itself cross A_SIDE",
        },
        {
            "decision_item": "blocked_role",
            "decision_value": "ROUTE_CELL_RESIDUAL_QUANTUM",
            "reason": "floor is not a whole QP001 route exposure or route-exposure bundle",
        },
        {
            "decision_item": "application_rule",
            "decision_value": "APPLY_BOUNDARY_FLOOR_BEFORE_ROUTE_CRUMBS",
            "reason": "QP027 route crumbs operate on the remainder after the sealed boundary floor",
        },
    ]

    result_class = "QP030_BOUNDARY_INVENTORY_FLOOR_SELECTED_WITH_LEDGER_COMPLETION_SUPPORT"
    next_frontier = "QP031_PRIVATE_BOUNDARY_FLOOR_OPEN_SLOT_PROPAGATION_SELECTOR"
    schema_rows = [
        {
            "class": result_class,
            "meaning": "sealed boundary floor is primary; ledger-cell completion is the downstream function",
            "status": "selected",
        },
        {
            "class": "ROUTE_CELL_RESIDUAL_QUANTUM",
            "meaning": "floor is treated as a route quantum only if it matches whole QP001 route exposure grammar",
            "status": "blocked as primary in QP030",
        },
        {
            "class": next_frontier,
            "meaning": "apply selected floor role to the open-slot table to see whether any particle slots promote",
            "status": "next",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP030 selects the floor role. QP031 should apply that role to open particle slots instead of rechecking the floor.",
            "launch_from": "qp030_role_decision_table.csv;qp030_floor_mechanism_chain.csv;artifacts/qp024/qp024_open_slot_frontier_table.csv",
            "target_output": "open slot propagation selector",
        }
    ]

    summary = {
        "artifact": "QP030_PRIVATE_BOUNDARY_FLOOR_TO_LEDGER_CELL_ROLE_SELECTOR",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp001/qp001_qubit_phase_functional_table.csv",
            "artifacts/qp016/qp016_stable_mode_selector_table.csv",
            "artifacts/qp025/qp025_lane_reinforcement_table.csv",
            "artifacts/qp027/qp027_stable_residual_chain_table.csv",
            "artifacts/qp029/qp029_summary.json",
            "artifacts/qp029/qp029_boundary_floor_comparison_table.csv",
            "artifacts/qp029/qp029_floor_role_map.csv",
        ],
        "qp029_result_class": qp029["result_class"],
        "selected_primary_role": "SEALED_BOUNDARY_INVENTORY_FLOOR",
        "selected_secondary_function": "LEDGER_CELL_COMPLETION_SUPPORT",
        "blocked_role": "ROUTE_CELL_RESIDUAL_QUANTUM",
        "application_rule": "APPLY_BOUNDARY_FLOOR_BEFORE_ROUTE_CRUMBS",
        "boundary_floor": boundary_floor,
        "stable_lane_open_sum": stable_open_sum,
        "stable_gap_to_A_SIDE": stable_gap,
        "boundary_floor_fraction_of_stable_gap": floor_fraction_of_gap,
        "stable_after_boundary_floor": stable_after_floor,
        "residual_after_boundary_floor": residual_after_floor,
        "qp027_route_crumb_sum": route_crumb_sum,
        "stable_after_route_crumbs": stable_after_route_crumbs,
        "ultra_residual_after_route_crumbs": ultra_residual,
        "minimum_whole_route_exposure": minimum_route,
        "ultra_residual_fraction_of_minimum_route": residual_fraction_of_min_route,
        "closest_route_bundle_to_boundary_floor": best_route_contact["route_bundle"],
        "closest_route_bundle_relative_delta": best_route_contact["relative_delta_to_boundary_floor"],
        "closest_route_bundle_contact_class": best_route_contact["contact_class"],
        "floor_is_exact_ledger_threshold": exact_ledger_threshold,
        "comparison_rows_imported": len(qp029_comparison),
        "role_map_rows_imported": len(qp029_role_map),
        "routing_law": "QP030 consumes QP029 as downstream private QP provenance and does not promote private results upstream",
        "next_frontier": next_frontier,
    }

    write_csv(
        ROLE_SCORE_OUT,
        role_rows,
        ["rank", "candidate_role", "role_score", "decision", "reason"],
    )
    write_csv(
        MECHANISM_OUT,
        mechanism_rows,
        ["chain_step", "quantity", "value", "chain_status"],
    )
    write_csv(
        ROUTE_CONTACT_OUT,
        route_contacts,
        [
            "QP030_route_contact_rank",
            "bundle_size",
            "route_bundle",
            "route_classes",
            "route_exposure_sum",
            "target_boundary_floor",
            "abs_delta_to_boundary_floor",
            "relative_delta_to_boundary_floor",
            "contact_class",
        ],
    )
    write_csv(
        LEDGER_CONTACT_OUT,
        ledger_contacts,
        [
            "threshold",
            "threshold_value",
            "boundary_floor",
            "floor_fraction_of_threshold",
            "abs_delta",
            "relative_delta",
            "meaning",
            "contact_class",
        ],
    )
    write_csv(
        DECISION_OUT,
        decision_rows,
        ["decision_item", "decision_value", "reason"],
    )
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, role_rows, mechanism_rows)

    print(result_class)
    print(f"selected_primary_role={summary['selected_primary_role']}")
    print(f"selected_secondary_function={summary['selected_secondary_function']}")
    print(f"blocked_role={summary['blocked_role']}")
    print(f"boundary_floor_fraction_of_stable_gap={floor_fraction_of_gap}")
    print(f"closest_route_bundle_to_boundary_floor={best_route_contact['route_bundle']}")
    print(f"closest_route_bundle_relative_delta={best_route_contact['relative_delta_to_boundary_floor']}")
    print(f"ultra_residual_fraction_of_minimum_route={residual_fraction_of_min_route}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
