from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP024_OPEN_SLOTS = ARTIFACTS / "qp024" / "qp024_open_slot_frontier_table.csv"
QP025_LANES = ARTIFACTS / "qp025" / "qp025_lane_reinforcement_table.csv"
QP025_PREFIXES = ARTIFACTS / "qp025" / "qp025_open_prefix_reinforcement_table.csv"
QP030_SUMMARY = ARTIFACTS / "qp030" / "qp030_summary.json"
QP030_DECISIONS = ARTIFACTS / "qp030" / "qp030_role_decision_table.csv"

QP031_DIR = ARTIFACTS / "qp031"
PREFLIGHT_OUT = QP031_DIR / "qp031_preflight.md"
SUMMARY_OUT = QP031_DIR / "qp031_summary.json"
SLOT_OUT = QP031_DIR / "qp031_slot_boundary_floor_propagation_table.csv"
PREFIX_OUT = QP031_DIR / "qp031_prefix_boundary_floor_propagation_table.csv"
LANE_OUT = QP031_DIR / "qp031_lane_boundary_floor_summary.csv"
DECISION_OUT = QP031_DIR / "qp031_propagation_decision_table.csv"
SCHEMA_OUT = QP031_DIR / "qp031_schema.csv"
NEXT_OUT = QP031_DIR / "qp031_next_frontier.csv"
DOC_OUT = REPORTS / "QP031_PRIVATE_BOUNDARY_FLOOR_OPEN_SLOT_PROPAGATION_SELECTOR.md"


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_preflight() -> None:
    QP031_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP031 Preflight - Boundary Floor Open Slot Propagation Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP031 does not rerun QP024-QP030. It applies the QP030-selected boundary-floor
role to the existing open particle-slot and lane-prefix surfaces.

## Selector Inputs

```text
artifacts/qp024/qp024_open_slot_frontier_table.csv
artifacts/qp025/qp025_lane_reinforcement_table.csv
artifacts/qp025/qp025_open_prefix_reinforcement_table.csv
artifacts/qp030/qp030_summary.json
artifacts/qp030/qp030_role_decision_table.csv
```

## Application Rule

```text
APPLY_BOUNDARY_FLOOR_BEFORE_ROUTE_CRUMBS
```

Boundary-floor propagation is tested before route crumbs. Route crumbs are only
reported on the lane where QP030's mechanism chain already exists.

## Question

```text
Does the selected boundary-inventory floor promote any open particle slot, or
does it propagate only as lane-level ledger support?
```
""",
        encoding="utf-8",
    )


def promotion_class(value: float, threshold: float, label: str) -> str:
    if value >= threshold:
        return f"{label}_PROMOTES_ACROSS_A_SIDE"
    return f"{label}_REMAINS_SUB_A_SIDE"


def write_doc(summary: dict[str, object], lane_rows: list[dict[str, object]], top_slots: list[dict[str, object]]) -> None:
    lane_lines = "\n".join(
        f"| {row['derived_replay_lane']} | {row['open_native_sum']} | {row['after_boundary_floor']} | {row['gap_after_boundary_floor']} | {row['after_allowed_route_crumbs']} | {row['final_gap_to_A_SIDE']} | {row['lane_propagation_class']} |"
        for row in lane_rows
    )
    slot_lines = "\n".join(
        f"| {row['QP031_rank']} | {row['suk055_pair']} | {row['derived_replay_lane']} | {row['after_boundary_floor']} | {row['gap_after_boundary_floor']} | {row['slot_propagation_class']} |"
        for row in top_slots
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP031 - Private Boundary Floor Open Slot Propagation Selector

## Result

```text
{summary['result_class']}
```

QP031 applies the QP030-selected boundary-inventory floor to open particle-slot
and lane-prefix surfaces.

## Rule Used

```text
{summary['application_rule']}
```

## Lane Propagation

| lane | open sum | after floor | gap after floor | after allowed crumbs | final gap | class |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
{lane_lines}

## Top Slot Contacts

| rank | slot | lane | after floor | gap after floor | class |
| ---: | --- | --- | ---: | ---: | --- |
{slot_lines}

## Interpretation

The selected floor propagates strongly at the stable lane level, but it does not
promote any single open particle slot by itself. With the already-allowed route
crumbs applied after the floor, the stable lane reaches the ultra-residual
boundary from QP028, still just below `A_SIDE`.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    open_slots = read_csv(QP024_OPEN_SLOTS)
    lane_rows_in = read_csv(QP025_LANES)
    prefix_rows_in = read_csv(QP025_PREFIXES)
    qp030 = read_json(QP030_SUMMARY)
    decisions = read_csv(QP030_DECISIONS)

    boundary_floor = float(qp030["boundary_floor"])
    route_crumb_sum = float(qp030["qp027_route_crumb_sum"])
    minimum_whole_route_exposure = float(qp030["minimum_whole_route_exposure"])
    a_side = float(qp030["stable_lane_open_sum"]) + float(qp030["stable_gap_to_A_SIDE"])
    stable_lane_name = "DERIVED_STABLE_ANCHOR_LANE"

    slot_rows: list[dict[str, object]] = []
    for row in open_slots:
        base = float(row["native_interaction_strength"])
        after_floor = base + boundary_floor
        gap_after_floor = max(0.0, a_side - after_floor)
        crosses = after_floor >= a_side
        slot_class = promotion_class(after_floor, a_side, "SINGLE_SLOT_BOUNDARY_FLOOR")
        slot_rows.append(
            {
                "suk055_pair": row["suk055_pair"],
                "oriented_symbols": row["oriented_symbols"],
                "charge_class": row["charge_class"],
                "derived_replay_lane": row["derived_replay_lane"],
                "base_native_interaction_strength": base,
                "boundary_floor_added": boundary_floor,
                "after_boundary_floor": after_floor,
                "fraction_of_A_SIDE_after_boundary_floor": after_floor / a_side,
                "gap_after_boundary_floor": gap_after_floor,
                "slot_crosses_A_SIDE_after_boundary_floor": crosses,
                "slot_propagation_class": slot_class,
            }
        )
    slot_rows.sort(key=lambda row: (float(row["gap_after_boundary_floor"]), str(row["suk055_pair"])))
    for rank, row in enumerate(slot_rows, start=1):
        row["QP031_rank"] = rank

    prefix_rows: list[dict[str, object]] = []
    for row in prefix_rows_in:
        lane = row["derived_replay_lane"]
        base = float(row["prefix_native_strength"])
        after_floor = base + boundary_floor
        gap_after_floor = max(0.0, a_side - after_floor)
        route_crumbs_allowed = lane == stable_lane_name
        after_allowed_route_crumbs = after_floor + route_crumb_sum if route_crumbs_allowed else ""
        if route_crumbs_allowed:
            final_value = float(after_allowed_route_crumbs)
            final_gap = max(0.0, a_side - final_value)
            below_whole_route_floor = final_gap < minimum_whole_route_exposure
            if final_value >= a_side:
                prefix_class = "PREFIX_PROMOTES_AFTER_BOUNDARY_FLOOR_AND_ROUTE_CRUMBS"
            elif below_whole_route_floor:
                prefix_class = "PREFIX_REACHES_ROUTE_FLOOR_LIMIT_BELOW_A_SIDE"
            else:
                prefix_class = "PREFIX_REMAINS_SUB_A_SIDE_AFTER_ALLOWED_CRUMBS"
        else:
            final_value = after_floor
            final_gap = gap_after_floor
            below_whole_route_floor = False
            prefix_class = promotion_class(after_floor, a_side, "PREFIX_BOUNDARY_FLOOR")
        prefix_rows.append(
            {
                "derived_replay_lane": lane,
                "prefix_rank": row["prefix_rank"],
                "prefix_pairs": row["prefix_pairs"],
                "base_prefix_strength": base,
                "boundary_floor_added": boundary_floor,
                "after_boundary_floor": after_floor,
                "fraction_of_A_SIDE_after_boundary_floor": after_floor / a_side,
                "gap_after_boundary_floor": gap_after_floor,
                "route_crumbs_allowed": route_crumbs_allowed,
                "route_crumb_sum_added": route_crumb_sum if route_crumbs_allowed else "",
                "after_allowed_route_crumbs": after_allowed_route_crumbs,
                "final_gap_to_A_SIDE": final_gap,
                "final_gap_below_whole_route_floor": below_whole_route_floor,
                "prefix_propagation_class": prefix_class,
            }
        )

    lane_rows: list[dict[str, object]] = []
    for row in lane_rows_in:
        lane = row["derived_replay_lane"]
        base = float(row["open_native_sum"])
        after_floor = base + boundary_floor
        gap_after_floor = max(0.0, a_side - after_floor)
        route_crumbs_allowed = lane == stable_lane_name
        if route_crumbs_allowed:
            after_allowed_route_crumbs = after_floor + route_crumb_sum
            final_gap = max(0.0, a_side - after_allowed_route_crumbs)
            below_whole_route_floor = final_gap < minimum_whole_route_exposure
            if after_allowed_route_crumbs >= a_side:
                lane_class = "LANE_PROMOTES_AFTER_BOUNDARY_FLOOR_AND_ROUTE_CRUMBS"
            elif below_whole_route_floor:
                lane_class = "LANE_REACHES_ROUTE_FLOOR_LIMIT_BELOW_A_SIDE"
            else:
                lane_class = "LANE_REMAINS_SUB_A_SIDE_AFTER_ALLOWED_CRUMBS"
        else:
            after_allowed_route_crumbs = ""
            final_gap = gap_after_floor
            below_whole_route_floor = False
            lane_class = promotion_class(after_floor, a_side, "LANE_BOUNDARY_FLOOR")
        lane_rows.append(
            {
                "derived_replay_lane": lane,
                "open_slots": row["open_slots"],
                "open_native_sum": base,
                "boundary_floor_added": boundary_floor,
                "after_boundary_floor": after_floor,
                "gap_after_boundary_floor": gap_after_floor,
                "fraction_of_A_SIDE_after_boundary_floor": after_floor / a_side,
                "route_crumbs_allowed": route_crumbs_allowed,
                "route_crumb_sum_added": route_crumb_sum if route_crumbs_allowed else "",
                "after_allowed_route_crumbs": after_allowed_route_crumbs,
                "final_gap_to_A_SIDE": final_gap,
                "final_gap_below_whole_route_floor": below_whole_route_floor,
                "lane_propagation_class": lane_class,
            }
        )
    lane_rows.sort(key=lambda row: (float(row["final_gap_to_A_SIDE"]), str(row["derived_replay_lane"])))

    slot_promotions = [row for row in slot_rows if row["slot_crosses_A_SIDE_after_boundary_floor"]]
    prefix_promotions = [
        row
        for row in prefix_rows
        if row["prefix_propagation_class"] in {
            "PREFIX_PROMOTES_AFTER_BOUNDARY_FLOOR_AND_ROUTE_CRUMBS",
            "PREFIX_BOUNDARY_FLOOR_PROMOTES_ACROSS_A_SIDE",
        }
    ]
    lanes_at_route_floor_limit = [
        row
        for row in lane_rows
        if row["lane_propagation_class"] == "LANE_REACHES_ROUTE_FLOOR_LIMIT_BELOW_A_SIDE"
    ]

    if slot_promotions:
        result_class = "QP031_BOUNDARY_FLOOR_PROMOTES_OPEN_PARTICLE_SLOT"
        next_frontier = "QP032_PRIVATE_PROMOTED_SLOT_MASS_SURFACE_FREEZE"
    elif lanes_at_route_floor_limit:
        result_class = "QP031_BOUNDARY_FLOOR_PROPAGATES_STABLE_LANE_TO_ROUTE_FLOOR_LIMIT"
        next_frontier = "QP032_PRIVATE_ULTRA_RESIDUAL_ROLE_OR_STOP_SELECTOR"
    else:
        result_class = "QP031_BOUNDARY_FLOOR_NO_OPEN_SLOT_PROMOTION"
        next_frontier = "QP032_PRIVATE_OPEN_SLOT_MISSING_MECHANISM_SELECTOR"

    top_slot = slot_rows[0]
    top_lane = lane_rows[0]
    decision_rows = [
        {
            "decision_item": "slot_promotions_after_boundary_floor",
            "decision_value": len(slot_promotions),
            "reason": "single open slots remain below A_SIDE after applying the selected boundary floor",
        },
        {
            "decision_item": "prefix_promotions_after_allowed_route_crumbs",
            "decision_value": len(prefix_promotions),
            "reason": "stable lane prefixes remain just below A_SIDE even after allowed route crumbs",
        },
        {
            "decision_item": "top_slot_after_floor",
            "decision_value": top_slot["suk055_pair"],
            "reason": f"gap after floor = {top_slot['gap_after_boundary_floor']}",
        },
        {
            "decision_item": "top_lane_after_allowed_route_crumbs",
            "decision_value": top_lane["derived_replay_lane"],
            "reason": f"final gap = {top_lane['final_gap_to_A_SIDE']}",
        },
        {
            "decision_item": "application_status",
            "decision_value": "BOUNDARY_FLOOR_PROPAGATES_AS_LANE_SUPPORT_NOT_SLOT_PROMOTION",
            "reason": "floor supports the stable lane but does not directly assign a new open-slot mass surface",
        },
    ]

    schema_rows = [
        {
            "class": "QP031_BOUNDARY_FLOOR_PROPAGATES_STABLE_LANE_TO_ROUTE_FLOOR_LIMIT",
            "meaning": "boundary floor plus allowed route crumbs brings the stable lane to the below-route-floor limit",
            "status": "selected",
        },
        {
            "class": "SINGLE_SLOT_BOUNDARY_FLOOR_REMAINS_SUB_A_SIDE",
            "meaning": "single open particle slot does not promote after adding the selected boundary floor",
            "status": "slot boundary",
        },
        {
            "class": "QP032_PRIVATE_ULTRA_RESIDUAL_ROLE_OR_STOP_SELECTOR",
            "meaning": "next forward gate decides whether the ultra residual has a role or is a stop boundary",
            "status": "next",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP031 finds no single open-slot promotion, but the stable lane reaches the route-floor limit. The next forward question is the role of the ultra residual.",
            "launch_from": "qp031_lane_boundary_floor_summary.csv;qp031_prefix_boundary_floor_propagation_table.csv;artifacts/qp030/qp030_summary.json",
            "target_output": "ultra residual role or stop selector",
        }
    ]

    summary = {
        "artifact": "QP031_PRIVATE_BOUNDARY_FLOOR_OPEN_SLOT_PROPAGATION_SELECTOR",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp024/qp024_open_slot_frontier_table.csv",
            "artifacts/qp025/qp025_lane_reinforcement_table.csv",
            "artifacts/qp025/qp025_open_prefix_reinforcement_table.csv",
            "artifacts/qp030/qp030_summary.json",
            "artifacts/qp030/qp030_role_decision_table.csv",
        ],
        "qp030_result_class": qp030["result_class"],
        "application_rule": qp030["application_rule"],
        "boundary_floor": boundary_floor,
        "route_crumb_sum": route_crumb_sum,
        "minimum_whole_route_exposure": minimum_whole_route_exposure,
        "A_SIDE": a_side,
        "open_slots_tested": len(slot_rows),
        "open_prefixes_tested": len(prefix_rows),
        "lanes_tested": len(lane_rows),
        "single_slot_promotions_after_boundary_floor": len(slot_promotions),
        "prefix_promotions_after_allowed_route_crumbs": len(prefix_promotions),
        "lanes_at_route_floor_limit": len(lanes_at_route_floor_limit),
        "top_slot_after_boundary_floor": top_slot["suk055_pair"],
        "top_slot_gap_after_boundary_floor": top_slot["gap_after_boundary_floor"],
        "top_slot_fraction_of_A_SIDE_after_boundary_floor": top_slot["fraction_of_A_SIDE_after_boundary_floor"],
        "top_lane_after_allowed_route_crumbs": top_lane["derived_replay_lane"],
        "top_lane_final_gap_to_A_SIDE": top_lane["final_gap_to_A_SIDE"],
        "top_lane_final_gap_below_whole_route_floor": top_lane["final_gap_below_whole_route_floor"],
        "decision_rows_imported": len(decisions),
        "interpretation": "boundary floor propagates as lane-level ledger support and does not directly promote an open particle slot",
        "next_frontier": next_frontier,
    }

    write_csv(
        SLOT_OUT,
        slot_rows,
        [
            "QP031_rank",
            "suk055_pair",
            "oriented_symbols",
            "charge_class",
            "derived_replay_lane",
            "base_native_interaction_strength",
            "boundary_floor_added",
            "after_boundary_floor",
            "fraction_of_A_SIDE_after_boundary_floor",
            "gap_after_boundary_floor",
            "slot_crosses_A_SIDE_after_boundary_floor",
            "slot_propagation_class",
        ],
    )
    write_csv(
        PREFIX_OUT,
        prefix_rows,
        [
            "derived_replay_lane",
            "prefix_rank",
            "prefix_pairs",
            "base_prefix_strength",
            "boundary_floor_added",
            "after_boundary_floor",
            "fraction_of_A_SIDE_after_boundary_floor",
            "gap_after_boundary_floor",
            "route_crumbs_allowed",
            "route_crumb_sum_added",
            "after_allowed_route_crumbs",
            "final_gap_to_A_SIDE",
            "final_gap_below_whole_route_floor",
            "prefix_propagation_class",
        ],
    )
    write_csv(
        LANE_OUT,
        lane_rows,
        [
            "derived_replay_lane",
            "open_slots",
            "open_native_sum",
            "boundary_floor_added",
            "after_boundary_floor",
            "gap_after_boundary_floor",
            "fraction_of_A_SIDE_after_boundary_floor",
            "route_crumbs_allowed",
            "route_crumb_sum_added",
            "after_allowed_route_crumbs",
            "final_gap_to_A_SIDE",
            "final_gap_below_whole_route_floor",
            "lane_propagation_class",
        ],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, lane_rows, slot_rows[:6])

    print(result_class)
    print(f"single_slot_promotions_after_boundary_floor={len(slot_promotions)}")
    print(f"prefix_promotions_after_allowed_route_crumbs={len(prefix_promotions)}")
    print(f"lanes_at_route_floor_limit={len(lanes_at_route_floor_limit)}")
    print(f"top_slot_after_boundary_floor={top_slot['suk055_pair']}")
    print(f"top_slot_gap_after_boundary_floor={top_slot['gap_after_boundary_floor']}")
    print(f"top_lane_after_allowed_route_crumbs={top_lane['derived_replay_lane']}")
    print(f"top_lane_final_gap_to_A_SIDE={top_lane['final_gap_to_A_SIDE']}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
