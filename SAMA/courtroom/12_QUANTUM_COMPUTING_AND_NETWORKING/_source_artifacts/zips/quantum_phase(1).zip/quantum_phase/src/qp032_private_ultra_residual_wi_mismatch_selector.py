from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

CORE_ENGINE = ARTIFACTS / "core" / "phase_field_engine_summary.json"
QP030_SUMMARY = ARTIFACTS / "qp030" / "qp030_summary.json"
QP031_SUMMARY = ARTIFACTS / "qp031" / "qp031_summary.json"
QP031_LANES = ARTIFACTS / "qp031" / "qp031_lane_boundary_floor_summary.csv"
QP031_SLOTS = ARTIFACTS / "qp031" / "qp031_slot_boundary_floor_propagation_table.csv"

QP032_DIR = ARTIFACTS / "qp032"
PREFLIGHT_OUT = QP032_DIR / "qp032_preflight.md"
SUMMARY_OUT = QP032_DIR / "qp032_summary.json"
WI_OUT = QP032_DIR / "qp032_wi_mismatch_table.csv"
ROLE_OUT = QP032_DIR / "qp032_ultra_residual_role_score_table.csv"
DECISION_OUT = QP032_DIR / "qp032_wi_closure_decision_table.csv"
SCHEMA_OUT = QP032_DIR / "qp032_schema.csv"
NEXT_OUT = QP032_DIR / "qp032_next_frontier.csv"
DOC_OUT = REPORTS / "QP032_PRIVATE_ULTRA_RESIDUAL_WI_MISMATCH_SELECTOR.md"


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_preflight() -> None:
    QP032_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP032 Preflight - Ultra Residual W/I Mismatch Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP032 does not rerun QP030 or QP031. It starts from the QP031 lane-support
limit and asks whether the remaining ultra residual is the mismatch between the
half-write target and the information-return support.

## Selector Inputs

```text
artifacts/core/phase_field_engine_summary.json
artifacts/qp030/qp030_summary.json
artifacts/qp031/qp031_summary.json
artifacts/qp031/qp031_lane_boundary_floor_summary.csv
artifacts/qp031/qp031_slot_boundary_floor_propagation_table.csv
```

## W/I Closure Definition

```text
W_target = A_SIDE
I_return = stable lane after boundary floor plus allowed route crumbs
W/I mismatch = W_target - I_return
```

## Question

```text
Is the QP031 ultra residual a W/I mismatch boundary, an additive route
continuation, or a single-slot promotion deficit?
```
""",
        encoding="utf-8",
    )


def write_doc(summary: dict[str, object], role_rows: list[dict[str, object]], wi_rows: list[dict[str, object]]) -> None:
    role_lines = "\n".join(
        f"| {row['rank']} | {row['candidate_role']} | {row['role_score']} | {row['decision']} | {row['reason']} |"
        for row in role_rows
    )
    wi_lines = "\n".join(
        f"| {row['quantity']} | {row['value']} | {row['meaning']} |"
        for row in wi_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP032 - Private Ultra Residual W/I Mismatch Selector

## Result

```text
{summary['result_class']}
```

QP032 classifies the QP031 ultra residual under the Phase 3 W/I closure frame.

## W/I Closure Readout

| quantity | value | meaning |
| --- | ---: | --- |
{wi_lines}

## Role Scores

| rank | candidate role | score | decision | reason |
| ---: | --- | ---: | --- | --- |
{role_lines}

## Interpretation

The ultra residual is exactly the remaining difference between the half-write
target and the information-return support after the boundary floor and allowed
route crumbs. It is below the smallest whole route-exposure quantum, so QP032
blocks ordinary additive continuation. The next move is W/I self-support at the
slot level, not another threshold push.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    core = read_json(CORE_ENGINE)
    qp030 = read_json(QP030_SUMMARY)
    qp031 = read_json(QP031_SUMMARY)
    lane_rows = read_csv(QP031_LANES)
    slot_rows = read_csv(QP031_SLOTS)

    stable_lane = next(row for row in lane_rows if row["derived_replay_lane"] == "DERIVED_STABLE_ANCHOR_LANE")
    top_slot = slot_rows[0]
    a_side = float(qp031["A_SIDE"])
    i_return = float(stable_lane["after_allowed_route_crumbs"])
    wi_mismatch = a_side - i_return
    recorded_ultra_residual = float(qp031["top_lane_final_gap_to_A_SIDE"])
    minimum_route_exposure = float(qp031["minimum_whole_route_exposure"])
    route_floor_fraction = wi_mismatch / minimum_route_exposure if minimum_route_exposure else 0.0
    a_side_fraction = wi_mismatch / a_side if a_side else 0.0
    top_slot_gap = float(qp031["top_slot_gap_after_boundary_floor"])
    top_slot_gap_ratio = top_slot_gap / wi_mismatch if wi_mismatch else 0.0
    mismatch_delta = abs(wi_mismatch - recorded_ultra_residual)
    tolerance = 1e-18

    below_route_floor = wi_mismatch < minimum_route_exposure
    exact_wi_record_match = mismatch_delta <= tolerance
    no_slot_promotions = int(qp031["single_slot_promotions_after_boundary_floor"]) == 0
    no_prefix_promotions = int(qp031["prefix_promotions_after_allowed_route_crumbs"]) == 0

    wi_score = 0
    wi_reasons: list[str] = []
    if exact_wi_record_match:
        wi_score += 2
        wi_reasons.append("W_target minus I_return equals recorded ultra residual")
    if below_route_floor:
        wi_score += 2
        wi_reasons.append("mismatch is below whole route-exposure floor")
    if no_slot_promotions:
        wi_score += 1
        wi_reasons.append("no single slot promotes under boundary floor")
    if no_prefix_promotions:
        wi_score += 1
        wi_reasons.append("no prefix promotes under allowed route crumbs")

    additive_score = 0
    additive_reasons: list[str] = []
    if not below_route_floor:
        additive_score += 2
        additive_reasons.append("mismatch can accept a whole route exposure")
    else:
        additive_reasons.append("mismatch is smaller than the smallest whole route exposure")

    slot_score = 0
    slot_reasons: list[str] = []
    if top_slot_gap <= minimum_route_exposure:
        slot_score += 2
        slot_reasons.append("top open-slot gap is at route-floor scale")
    else:
        slot_reasons.append("top open-slot gap is far larger than the ultra residual")
    if no_slot_promotions:
        slot_reasons.append("slot promotion did not occur in QP031")

    rounding_score = 0
    rounding_reasons: list[str] = []
    if a_side_fraction <= 1e-9:
        rounding_score += 1
        rounding_reasons.append("mismatch is below 1e-9 of A_SIDE")
    else:
        rounding_reasons.append("mismatch is small but above pure numerical-rounding cutoff")

    role_rows = [
        {
            "candidate_role": "WI_RETURN_MISMATCH_BOUNDARY",
            "role_score": wi_score,
            "decision": "SELECT_PRIMARY_ROLE",
            "reason": "; ".join(wi_reasons),
        },
        {
            "candidate_role": "ADDITIVE_ROUTE_CONTINUATION",
            "role_score": additive_score,
            "decision": "BLOCK",
            "reason": "; ".join(additive_reasons),
        },
        {
            "candidate_role": "SINGLE_SLOT_PROMOTION_DEFICIT",
            "role_score": slot_score,
            "decision": "BLOCK",
            "reason": "; ".join(slot_reasons),
        },
        {
            "candidate_role": "NUMERICAL_ROUNDING_ONLY",
            "role_score": rounding_score,
            "decision": "BLOCK",
            "reason": "; ".join(rounding_reasons),
        },
    ]
    role_rows.sort(key=lambda row: (-int(row["role_score"]), str(row["candidate_role"])))
    for rank, row in enumerate(role_rows, start=1):
        row["rank"] = rank

    if role_rows[0]["candidate_role"] == "WI_RETURN_MISMATCH_BOUNDARY":
        result_class = "QP032_ULTRA_RESIDUAL_SELECTED_AS_WI_MISMATCH_BOUNDARY"
        next_frontier = "QP033_PRIVATE_SLOT_WI_SELF_SUPPORT_TABLE"
    elif role_rows[0]["candidate_role"] == "ADDITIVE_ROUTE_CONTINUATION":
        result_class = "QP032_ULTRA_RESIDUAL_ROUTE_CONTINUATION_OPEN"
        next_frontier = "QP033_PRIVATE_ROUTE_CONTINUATION_SELECTOR"
    else:
        result_class = "QP032_ULTRA_RESIDUAL_ROLE_UNRESOLVED"
        next_frontier = "QP033_PRIVATE_ULTRA_RESIDUAL_ROLE_SEARCH"

    wi_rows = [
        {
            "quantity": "W_target",
            "value": a_side,
            "meaning": "A_SIDE half-write target",
        },
        {
            "quantity": "I_return",
            "value": i_return,
            "meaning": "stable lane after boundary floor plus allowed route crumbs",
        },
        {
            "quantity": "W_minus_I_mismatch",
            "value": wi_mismatch,
            "meaning": "remaining mismatch before exact W/I closure",
        },
        {
            "quantity": "minimum_whole_route_exposure",
            "value": minimum_route_exposure,
            "meaning": "smallest whole route quantum available to additive continuation",
        },
        {
            "quantity": "top_slot_gap_after_boundary_floor",
            "value": top_slot_gap,
            "meaning": "best single-slot gap after boundary floor",
        },
    ]

    decision_rows = [
        {
            "decision_item": "selected_ultra_residual_role",
            "decision_value": "WI_RETURN_MISMATCH_BOUNDARY",
            "reason": "ultra residual equals W_target - I_return and is below the whole route floor",
        },
        {
            "decision_item": "additive_route_continuation",
            "decision_value": "BLOCKED",
            "reason": "mismatch is 0.6342952270762854 of the minimum whole route exposure",
        },
        {
            "decision_item": "slot_promotion_from_threshold",
            "decision_value": "BLOCKED",
            "reason": "top open-slot gap remains much larger than the W/I mismatch",
        },
        {
            "decision_item": "phase3_next_rule",
            "decision_value": "W/I_SELF_SUPPORT_REQUIRED",
            "reason": "particle identity needs fixed-point closure, not more additive support",
        },
    ]

    schema_rows = [
        {
            "class": result_class,
            "meaning": "ultra residual is selected as W/I mismatch boundary",
            "status": "selected",
        },
        {
            "class": "ADDITIVE_ROUTE_CONTINUATION",
            "meaning": "ordinary route addition may continue only if residual can accept a whole route exposure",
            "status": "blocked in QP032",
        },
        {
            "class": next_frontier,
            "meaning": "rank open slots by W/I self-support",
            "status": "next",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP032 selects the ultra residual as W/I mismatch boundary. QP033 should rank open slots by write-anchor/information-return self-support.",
            "launch_from": "qp032_wi_mismatch_table.csv;qp032_wi_closure_decision_table.csv;artifacts/qp031/qp031_slot_boundary_floor_propagation_table.csv",
            "target_output": "slot W/I self-support table",
        }
    ]

    summary = {
        "artifact": "QP032_PRIVATE_ULTRA_RESIDUAL_WI_MISMATCH_SELECTOR",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/core/phase_field_engine_summary.json",
            "artifacts/qp030/qp030_summary.json",
            "artifacts/qp031/qp031_summary.json",
            "artifacts/qp031/qp031_lane_boundary_floor_summary.csv",
            "artifacts/qp031/qp031_slot_boundary_floor_propagation_table.csv",
        ],
        "phase3_campaign": "SAM_QP032_QP0XX_PHASE3_WI_CLOSURE_PARTICLE_IDENTITY_CAMPAIGN",
        "active_formula": core["active_formula"],
        "active_engine": core["active_engine"],
        "qp030_result_class": qp030["result_class"],
        "qp031_result_class": qp031["result_class"],
        "W_target": a_side,
        "I_return": i_return,
        "WI_mismatch": wi_mismatch,
        "recorded_ultra_residual": recorded_ultra_residual,
        "mismatch_delta_to_qp031_record": mismatch_delta,
        "mismatch_match_tolerance": tolerance,
        "exact_WI_record_match": exact_wi_record_match,
        "minimum_whole_route_exposure": minimum_route_exposure,
        "WI_mismatch_fraction_of_minimum_route_exposure": route_floor_fraction,
        "WI_mismatch_fraction_of_A_SIDE": a_side_fraction,
        "below_whole_route_floor": below_route_floor,
        "top_slot_after_boundary_floor": top_slot["suk055_pair"],
        "top_slot_gap_after_boundary_floor": top_slot_gap,
        "top_slot_gap_to_WI_mismatch_ratio": top_slot_gap_ratio,
        "single_slot_promotions_after_boundary_floor": qp031["single_slot_promotions_after_boundary_floor"],
        "prefix_promotions_after_allowed_route_crumbs": qp031["prefix_promotions_after_allowed_route_crumbs"],
        "selected_ultra_residual_role": "WI_RETURN_MISMATCH_BOUNDARY",
        "blocked_as_additive_route_continuation": below_route_floor,
        "blocked_as_single_slot_promotion_deficit": top_slot_gap > wi_mismatch,
        "interpretation": "ultra residual is W/I closure mismatch, not ordinary lane support or direct slot promotion",
        "next_frontier": next_frontier,
    }

    write_csv(WI_OUT, wi_rows, ["quantity", "value", "meaning"])
    write_csv(ROLE_OUT, role_rows, ["rank", "candidate_role", "role_score", "decision", "reason"])
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, role_rows, wi_rows)

    print(result_class)
    print(f"W_target={a_side}")
    print(f"I_return={i_return}")
    print(f"WI_mismatch={wi_mismatch}")
    print(f"recorded_ultra_residual={recorded_ultra_residual}")
    print(f"below_whole_route_floor={below_route_floor}")
    print(f"WI_mismatch_fraction_of_minimum_route_exposure={route_floor_fraction}")
    print(f"top_slot_gap_to_WI_mismatch_ratio={top_slot_gap_ratio}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
