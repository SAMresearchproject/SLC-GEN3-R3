from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP024_OPEN_SLOTS = ARTIFACTS / "qp024" / "qp024_open_slot_frontier_table.csv"
QP031_LANES = ARTIFACTS / "qp031" / "qp031_lane_boundary_floor_summary.csv"
QP031_SLOTS = ARTIFACTS / "qp031" / "qp031_slot_boundary_floor_propagation_table.csv"
QP032_SUMMARY = ARTIFACTS / "qp032" / "qp032_summary.json"
QP032_DECISIONS = ARTIFACTS / "qp032" / "qp032_wi_closure_decision_table.csv"

QP033_DIR = ARTIFACTS / "qp033"
PREFLIGHT_OUT = QP033_DIR / "qp033_preflight.md"
SUMMARY_OUT = QP033_DIR / "qp033_summary.json"
SELF_SUPPORT_OUT = QP033_DIR / "qp033_slot_wi_self_support_table.csv"
LANE_RETURN_OUT = QP033_DIR / "qp033_lane_information_return_table.csv"
DECISION_OUT = QP033_DIR / "qp033_self_support_decision_table.csv"
SCHEMA_OUT = QP033_DIR / "qp033_schema.csv"
NEXT_OUT = QP033_DIR / "qp033_next_frontier.csv"
DOC_OUT = REPORTS / "QP033_PRIVATE_SLOT_WI_SELF_SUPPORT_TABLE.md"


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def as_float(value: str) -> float:
    if value == "":
        return 0.0
    return float(value)


def write_preflight() -> None:
    QP033_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP033 Preflight - Slot W/I Self-Support Table

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP033 does not rerun QP031 or QP032. It applies the Phase 3 rule that particle
identity requires write-anchor / information-return self-support.

## Selector Inputs

```text
artifacts/qp024/qp024_open_slot_frontier_table.csv
artifacts/qp031/qp031_lane_boundary_floor_summary.csv
artifacts/qp031/qp031_slot_boundary_floor_propagation_table.csv
artifacts/qp032/qp032_summary.json
artifacts/qp032/qp032_wi_closure_decision_table.csv
```

## W/I Slot Rule

```text
W_slot = open slot support after boundary floor
I_return_slot = lane information return distributed by native slot share
W/I self-support score = 1 - abs(W_slot - I_return_slot) / max(W_slot, I_return_slot)
fixed point contact = abs(W_slot - I_return_slot) <= QP032 W/I mismatch
```

No fitted weights are introduced.

## Question

```text
Which open slots have the strongest W/I self-support, and does any slot reach
the QP032 fixed-point mismatch scale?
```
""",
        encoding="utf-8",
    )


def write_doc(summary: dict[str, object], top_rows: list[dict[str, object]]) -> None:
    top_lines = "\n".join(
        f"| {row['QP033_rank']} | {row['suk055_pair']} | {row['derived_replay_lane']} | {row['W_slot']} | {row['I_return_slot']} | {row['WI_delta']} | {row['WI_self_support_score']} | {row['fixed_point_class']} |"
        for row in top_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP033 - Private Slot W/I Self-Support Table

## Result

```text
{summary['result_class']}
```

QP033 ranks open particle slots by write-anchor / information-return
self-support.

## Top Slot Rows

| rank | slot | lane | W slot | I return slot | W/I delta | score | class |
| ---: | --- | --- | ---: | ---: | ---: | ---: | --- |
{top_lines}

## Key Fields

```text
top_slot = {summary['top_wi_self_support_slot']}
top_score = {summary['top_wi_self_support_score']}
top_WI_delta = {summary['top_WI_delta']}
top_WI_delta_in_ultra_residual_units = {summary['top_WI_delta_in_ultra_residual_units']}
fixed_point_slot_promotions = {summary['fixed_point_slot_promotions']}
```

## Interpretation

The strongest W/I self-support slot is identified, but no open slot reaches the
QP032 ultra-residual fixed-point scale. This keeps particle identity held open
and moves Phase 3 to the lane-support versus particle-identity separation rule.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    q024_rows = read_csv(QP024_OPEN_SLOTS)
    lane_rows_in = read_csv(QP031_LANES)
    slot_rows_in = read_csv(QP031_SLOTS)
    qp032 = read_json(QP032_SUMMARY)
    decisions = read_csv(QP032_DECISIONS)

    q024_by_pair = {row["suk055_pair"]: row for row in q024_rows}
    wi_mismatch = float(qp032["WI_mismatch"])
    a_side = float(qp032["W_target"])

    lane_return_rows: list[dict[str, object]] = []
    lane_return_by_lane: dict[str, dict[str, float]] = {}
    for row in lane_rows_in:
        lane = row["derived_replay_lane"]
        open_sum = as_float(row["open_native_sum"])
        after_floor = as_float(row["after_boundary_floor"])
        after_crumbs = as_float(row["after_allowed_route_crumbs"])
        final_return = after_crumbs if after_crumbs else after_floor
        return_gain = final_return - open_sum
        lane_return_by_lane[lane] = {
            "open_sum": open_sum,
            "final_return": final_return,
            "return_gain": return_gain,
        }
        lane_return_rows.append(
            {
                "derived_replay_lane": lane,
                "open_native_sum": open_sum,
                "final_information_return": final_return,
                "return_gain": return_gain,
                "return_gain_fraction_of_A_SIDE": return_gain / a_side if a_side else 0.0,
                "route_crumbs_used": row["route_crumbs_allowed"],
                "lane_return_class": "LANE_INFORMATION_RETURN_AVAILABLE" if open_sum else "NO_OPEN_SLOT_RETURN_SURFACE",
            }
        )

    support_rows: list[dict[str, object]] = []
    for row in slot_rows_in:
        lane = row["derived_replay_lane"]
        lane_info = lane_return_by_lane[lane]
        base = float(row["base_native_interaction_strength"])
        w_slot = float(row["after_boundary_floor"])
        if lane_info["open_sum"] > 0.0:
            slot_share = base / lane_info["open_sum"]
            i_return_slot = lane_info["final_return"] * slot_share
        else:
            slot_share = 0.0
            i_return_slot = 0.0
        wi_delta = abs(w_slot - i_return_slot)
        denominator = max(w_slot, i_return_slot)
        score = 1.0 - (wi_delta / denominator) if denominator else 0.0
        fixed_point_contact = wi_delta <= wi_mismatch
        if fixed_point_contact:
            fixed_point_class = "WI_FIXED_POINT_CONTACT"
        elif score >= 0.95:
            fixed_point_class = "STRONG_WI_SELF_SUPPORT_HELD_OPEN"
        elif score >= 0.75:
            fixed_point_class = "MODERATE_WI_SELF_SUPPORT_HELD_OPEN"
        else:
            fixed_point_class = "WEAK_WI_SELF_SUPPORT_HELD_OPEN"
        q024 = q024_by_pair[row["suk055_pair"]]
        support_rows.append(
            {
                "suk055_pair": row["suk055_pair"],
                "oriented_symbols": row["oriented_symbols"],
                "charge_class": row["charge_class"],
                "derived_replay_lane": lane,
                "base_native_interaction_strength": base,
                "slot_share_of_lane_open_sum": slot_share,
                "W_slot": w_slot,
                "I_return_slot": i_return_slot,
                "WI_delta": wi_delta,
                "WI_delta_in_ultra_residual_units": wi_delta / wi_mismatch if wi_mismatch else 0.0,
                "WI_self_support_score": score,
                "fixed_point_contact": fixed_point_contact,
                "fixed_point_class": fixed_point_class,
                "slot_selector_score": q024["slot_selector_score"],
                "QP024_rank": q024["QP024_rank"],
            }
        )
    support_rows.sort(
        key=lambda row: (
            -float(row["WI_self_support_score"]),
            float(row["WI_delta"]),
            int(row["QP024_rank"]),
            str(row["suk055_pair"]),
        )
    )
    for rank, row in enumerate(support_rows, start=1):
        row["QP033_rank"] = rank

    fixed_points = [row for row in support_rows if row["fixed_point_contact"]]
    strong_held_open = [row for row in support_rows if row["fixed_point_class"] == "STRONG_WI_SELF_SUPPORT_HELD_OPEN"]
    top = support_rows[0]
    if fixed_points:
        result_class = "QP033_SLOT_WI_FIXED_POINT_CONTACT_FOUND"
        next_frontier = "QP034_PRIVATE_FIXED_POINT_SLOT_PROMOTION_SELECTOR"
    elif strong_held_open:
        result_class = "QP033_STRONG_SLOT_WI_SELF_SUPPORT_HELD_OPEN"
        next_frontier = "QP034_PRIVATE_LANE_SUPPORT_VS_PARTICLE_IDENTITY_SEPARATOR"
    else:
        result_class = "QP033_NO_STRONG_SLOT_WI_SELF_SUPPORT"
        next_frontier = "QP034_PRIVATE_SLOT_RETURN_MECHANISM_SEARCH"

    decision_rows = [
        {
            "decision_item": "top_wi_self_support_slot",
            "decision_value": top["suk055_pair"],
            "reason": f"highest W/I self-support score = {top['WI_self_support_score']}",
        },
        {
            "decision_item": "fixed_point_slot_promotions",
            "decision_value": len(fixed_points),
            "reason": "fixed point requires WI_delta <= QP032 WI_mismatch",
        },
        {
            "decision_item": "strong_self_support_held_open_slots",
            "decision_value": len(strong_held_open),
            "reason": "score >= 0.95 but mismatch remains above ultra-residual scale",
        },
        {
            "decision_item": "next_rule",
            "decision_value": "LANE_SUPPORT_VS_PARTICLE_IDENTITY_SEPARATOR",
            "reason": "strong self-support does not automatically promote particle identity",
        },
    ]
    schema_rows = [
        {
            "class": result_class,
            "meaning": "open slots ranked by W/I self-support; strongest contact remains held open",
            "status": "selected",
        },
        {
            "class": "WI_FIXED_POINT_CONTACT",
            "meaning": "slot W/I delta is at or below the QP032 ultra-residual mismatch scale",
            "status": "not reached" if not fixed_points else "reached",
        },
        {
            "class": next_frontier,
            "meaning": "separate lane support from localized particle identity",
            "status": "next",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP033 finds strong W/I self-support but no fixed-point slot promotion. QP034 should explain why lane support can exist without localized particle identity.",
            "launch_from": "qp033_slot_wi_self_support_table.csv;qp033_self_support_decision_table.csv;artifacts/qp032/qp032_summary.json",
            "target_output": "lane support versus particle identity separator",
        }
    ]

    summary = {
        "artifact": "QP033_PRIVATE_SLOT_WI_SELF_SUPPORT_TABLE",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp024/qp024_open_slot_frontier_table.csv",
            "artifacts/qp031/qp031_lane_boundary_floor_summary.csv",
            "artifacts/qp031/qp031_slot_boundary_floor_propagation_table.csv",
            "artifacts/qp032/qp032_summary.json",
            "artifacts/qp032/qp032_wi_closure_decision_table.csv",
        ],
        "phase3_campaign": qp032["phase3_campaign"],
        "qp032_result_class": qp032["result_class"],
        "WI_mismatch_threshold": wi_mismatch,
        "open_slots_ranked": len(support_rows),
        "fixed_point_slot_promotions": len(fixed_points),
        "strong_self_support_held_open_slots": len(strong_held_open),
        "top_wi_self_support_slot": top["suk055_pair"],
        "top_wi_self_support_lane": top["derived_replay_lane"],
        "top_wi_self_support_score": top["WI_self_support_score"],
        "top_WI_delta": top["WI_delta"],
        "top_WI_delta_in_ultra_residual_units": top["WI_delta_in_ultra_residual_units"],
        "top_fixed_point_class": top["fixed_point_class"],
        "decision_rows_imported": len(decisions),
        "interpretation": "slot W/I self-support can be strong without reaching particle identity fixed-point closure",
        "next_frontier": next_frontier,
    }

    write_csv(
        LANE_RETURN_OUT,
        lane_return_rows,
        [
            "derived_replay_lane",
            "open_native_sum",
            "final_information_return",
            "return_gain",
            "return_gain_fraction_of_A_SIDE",
            "route_crumbs_used",
            "lane_return_class",
        ],
    )
    write_csv(
        SELF_SUPPORT_OUT,
        support_rows,
        [
            "QP033_rank",
            "suk055_pair",
            "oriented_symbols",
            "charge_class",
            "derived_replay_lane",
            "base_native_interaction_strength",
            "slot_share_of_lane_open_sum",
            "W_slot",
            "I_return_slot",
            "WI_delta",
            "WI_delta_in_ultra_residual_units",
            "WI_self_support_score",
            "fixed_point_contact",
            "fixed_point_class",
            "slot_selector_score",
            "QP024_rank",
        ],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, support_rows[:8])

    print(result_class)
    print(f"top_wi_self_support_slot={top['suk055_pair']}")
    print(f"top_wi_self_support_score={top['WI_self_support_score']}")
    print(f"top_WI_delta={top['WI_delta']}")
    print(f"top_WI_delta_in_ultra_residual_units={top['WI_delta_in_ultra_residual_units']}")
    print(f"fixed_point_slot_promotions={len(fixed_points)}")
    print(f"strong_self_support_held_open_slots={len(strong_held_open)}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
