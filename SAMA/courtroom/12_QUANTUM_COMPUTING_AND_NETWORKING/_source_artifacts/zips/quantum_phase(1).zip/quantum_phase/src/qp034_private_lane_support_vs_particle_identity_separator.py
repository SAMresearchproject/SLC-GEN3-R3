from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP031_LANES = ARTIFACTS / "qp031" / "qp031_lane_boundary_floor_summary.csv"
QP032_SUMMARY = ARTIFACTS / "qp032" / "qp032_summary.json"
QP033_SUMMARY = ARTIFACTS / "qp033" / "qp033_summary.json"
QP033_SELF_SUPPORT = ARTIFACTS / "qp033" / "qp033_slot_wi_self_support_table.csv"

QP034_DIR = ARTIFACTS / "qp034"
PREFLIGHT_OUT = QP034_DIR / "qp034_preflight.md"
SUMMARY_OUT = QP034_DIR / "qp034_summary.json"
SEPARATION_OUT = QP034_DIR / "qp034_lane_identity_separation_table.csv"
RULE_OUT = QP034_DIR / "qp034_separation_rule_table.csv"
DECISION_OUT = QP034_DIR / "qp034_identity_decision_table.csv"
SCHEMA_OUT = QP034_DIR / "qp034_schema.csv"
NEXT_OUT = QP034_DIR / "qp034_next_frontier.csv"
DOC_OUT = REPORTS / "QP034_PRIVATE_LANE_SUPPORT_VS_PARTICLE_IDENTITY_SEPARATOR.md"


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def as_float(value: str) -> float:
    if value == "":
        return 0.0
    return float(value)


def write_preflight() -> None:
    QP034_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP034 Preflight - Lane Support vs Particle Identity Separator

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP034 does not rerun QP031-QP033. It separates collective lane support from
localized particle identity using the W/I mismatch and slot self-support outputs.

## Selector Inputs

```text
artifacts/qp031/qp031_lane_boundary_floor_summary.csv
artifacts/qp032/qp032_summary.json
artifacts/qp033/qp033_summary.json
artifacts/qp033/qp033_slot_wi_self_support_table.csv
```

## Question

```text
Why can the stable lane reach the route-floor limit while no open particle slot
promotes?
```
""",
        encoding="utf-8",
    )


def write_doc(summary: dict[str, object], separation_rows: list[dict[str, object]]) -> None:
    sep_lines = "\n".join(
        f"| {row['derived_replay_lane']} | {row['lane_closure_fraction']} | {row['best_slot']} | {row['best_slot_WI_self_support_score']} | {row['best_slot_delta_in_ultra_units']} | {row['fixed_point_slots']} | {row['separation_class']} |"
        for row in separation_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP034 - Private Lane Support vs Particle Identity Separator

## Result

```text
{summary['result_class']}
```

QP034 separates collective lane support from localized particle identity.

## Separation Table

| lane | lane closure fraction | best slot | best slot score | best slot delta in ultra units | fixed point slots | class |
| --- | ---: | --- | ---: | ---: | ---: | --- |
{sep_lines}

## Key Fields

```text
stable_lane_closure_fraction = {summary['stable_lane_closure_fraction']}
stable_lane_final_gap_to_A_SIDE = {summary['stable_lane_final_gap_to_A_SIDE']}
top_slot = {summary['top_slot']}
top_slot_WI_self_support_score = {summary['top_slot_WI_self_support_score']}
top_slot_delta_in_ultra_units = {summary['top_slot_delta_in_ultra_units']}
fixed_point_slot_promotions = {summary['fixed_point_slot_promotions']}
```

## Interpretation

The stable lane is collectively supported to the route-floor limit, but particle
identity remains localized and requires fixed-point W/I closure. Strong slot
self-support is therefore a candidate condition, not a promotion condition by
itself.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    lane_rows = read_csv(QP031_LANES)
    qp032 = read_json(QP032_SUMMARY)
    qp033 = read_json(QP033_SUMMARY)
    slot_rows = read_csv(QP033_SELF_SUPPORT)

    a_side = float(qp032["W_target"])
    ultra = float(qp032["WI_mismatch"])
    slot_rows_by_lane: dict[str, list[dict[str, str]]] = {}
    for row in slot_rows:
        slot_rows_by_lane.setdefault(row["derived_replay_lane"], []).append(row)

    separation_rows: list[dict[str, object]] = []
    for lane in lane_rows:
        lane_name = lane["derived_replay_lane"]
        final_gap = as_float(lane["final_gap_to_A_SIDE"])
        final_return = a_side - final_gap
        lane_closure_fraction = final_return / a_side if a_side else 0.0
        lane_below_route_floor = lane["final_gap_below_whole_route_floor"] == "True"
        lane_slots = slot_rows_by_lane.get(lane_name, [])
        if lane_slots:
            best = sorted(
                lane_slots,
                key=lambda row: (
                    -float(row["WI_self_support_score"]),
                    float(row["WI_delta"]),
                    int(row["QP033_rank"]),
                ),
            )[0]
            best_slot = best["suk055_pair"]
            best_score = float(best["WI_self_support_score"])
            best_delta = float(best["WI_delta"])
            best_delta_units = float(best["WI_delta_in_ultra_residual_units"])
            fixed_count = sum(1 for row in lane_slots if row["fixed_point_contact"] == "True")
        else:
            best_slot = ""
            best_score = 0.0
            best_delta = 0.0
            best_delta_units = 0.0
            fixed_count = 0

        if lane_below_route_floor and fixed_count == 0 and best_score >= 0.95:
            separation_class = "LANE_SUPPORTED_IDENTITY_HELD_OPEN_STRONG_SLOT"
        elif lane_below_route_floor and fixed_count == 0:
            separation_class = "LANE_SUPPORTED_IDENTITY_HELD_OPEN"
        elif fixed_count > 0:
            separation_class = "PARTICLE_IDENTITY_FIXED_POINT_AVAILABLE"
        elif best_score >= 0.95:
            separation_class = "STRONG_SLOT_SUPPORT_WITHOUT_LANE_CLOSURE"
        elif lane_slots:
            separation_class = "OPEN_SLOT_IDENTITY_UNRESOLVED"
        else:
            separation_class = "NO_OPEN_SLOT_IDENTITY_SURFACE"

        separation_rows.append(
            {
                "derived_replay_lane": lane_name,
                "open_slots": lane["open_slots"],
                "final_information_return": final_return,
                "final_gap_to_A_SIDE": final_gap,
                "lane_closure_fraction": lane_closure_fraction,
                "lane_gap_in_ultra_units": final_gap / ultra if ultra else 0.0,
                "lane_gap_below_route_floor": lane_below_route_floor,
                "best_slot": best_slot,
                "best_slot_WI_self_support_score": best_score,
                "best_slot_WI_delta": best_delta,
                "best_slot_delta_in_ultra_units": best_delta_units,
                "fixed_point_slots": fixed_count,
                "separation_class": separation_class,
            }
        )
    separation_rows.sort(
        key=lambda row: (
            -float(row["lane_closure_fraction"]),
            -float(row["best_slot_WI_self_support_score"]),
            str(row["derived_replay_lane"]),
        )
    )

    stable = next(row for row in separation_rows if row["derived_replay_lane"] == "DERIVED_STABLE_ANCHOR_LANE")
    top_slot = slot_rows[0]
    fixed_promotions = int(qp033["fixed_point_slot_promotions"])
    strong_held_open = int(qp033["strong_self_support_held_open_slots"])
    if (
        stable["lane_gap_below_route_floor"]
        and fixed_promotions == 0
        and strong_held_open > 0
    ):
        result_class = "QP034_LANE_SUPPORT_PARTICLE_IDENTITY_SEPARATED"
        next_frontier = "QP035_PRIVATE_HALF_WRITE_INFORMATION_FIXED_POINT_SELECTOR"
    elif fixed_promotions > 0:
        result_class = "QP034_PARTICLE_IDENTITY_FIXED_POINT_AVAILABLE"
        next_frontier = "QP035_PRIVATE_FIXED_POINT_PROMOTION_FREEZE"
    else:
        result_class = "QP034_IDENTITY_SEPARATOR_UNRESOLVED"
        next_frontier = "QP035_PRIVATE_IDENTITY_RULE_SEARCH"

    rule_rows = [
        {
            "rule": "LANE_SUPPORT",
            "condition": "collective lane final gap is at or below the route-floor limit",
            "status": "true for stable lane",
        },
        {
            "rule": "PARTICLE_IDENTITY",
            "condition": "localized slot W/I delta is at or below the ultra residual",
            "status": "not true for open slots",
        },
        {
            "rule": "STRONG_SELF_SUPPORT",
            "condition": "slot W/I score is high but still above fixed-point mismatch",
            "status": "candidate support, not promotion",
        },
    ]
    decision_rows = [
        {
            "decision_item": "lane_support_particle_identity_relation",
            "decision_value": "SEPARATED",
            "reason": "stable lane reaches route-floor limit while fixed-point slot promotions remain zero",
        },
        {
            "decision_item": "strong_self_support_status",
            "decision_value": "HELD_OPEN",
            "reason": "top slot score is strong but delta remains far above QP032 ultra-residual scale",
        },
        {
            "decision_item": "next_rule",
            "decision_value": "HALF_WRITE_INFORMATION_FIXED_POINT_SELECTOR",
            "reason": "particle identity requires local W/I fixed-point closure",
        },
    ]
    schema_rows = [
        {
            "class": result_class,
            "meaning": "lane support and particle identity are separated by local W/I fixed-point closure",
            "status": "selected",
        },
        {
            "class": "LANE_SUPPORTED_IDENTITY_HELD_OPEN_STRONG_SLOT",
            "meaning": "collective lane support is near closed and a strong slot exists, but no fixed-point slot promotes",
            "status": "stable lane class",
        },
        {
            "class": next_frontier,
            "meaning": "derive/apply the fixed-point selector for half-write and information return",
            "status": "next",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP034 separates lane support from localized particle identity. QP035 should test the fixed-point selector itself.",
            "launch_from": "qp034_lane_identity_separation_table.csv;artifacts/qp033/qp033_slot_wi_self_support_table.csv;artifacts/qp032/qp032_summary.json",
            "target_output": "half-write / information-return fixed-point selector",
        }
    ]

    summary = {
        "artifact": "QP034_PRIVATE_LANE_SUPPORT_VS_PARTICLE_IDENTITY_SEPARATOR",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp031/qp031_lane_boundary_floor_summary.csv",
            "artifacts/qp032/qp032_summary.json",
            "artifacts/qp033/qp033_summary.json",
            "artifacts/qp033/qp033_slot_wi_self_support_table.csv",
        ],
        "phase3_campaign": qp033["phase3_campaign"],
        "qp032_result_class": qp032["result_class"],
        "qp033_result_class": qp033["result_class"],
        "stable_lane_closure_fraction": stable["lane_closure_fraction"],
        "stable_lane_final_gap_to_A_SIDE": stable["final_gap_to_A_SIDE"],
        "stable_lane_gap_in_ultra_units": stable["lane_gap_in_ultra_units"],
        "top_slot": top_slot["suk055_pair"],
        "top_slot_WI_self_support_score": top_slot["WI_self_support_score"],
        "top_slot_WI_delta": top_slot["WI_delta"],
        "top_slot_delta_in_ultra_units": top_slot["WI_delta_in_ultra_residual_units"],
        "fixed_point_slot_promotions": fixed_promotions,
        "strong_self_support_held_open_slots": strong_held_open,
        "identity_rule": "particle identity requires localized W/I fixed-point closure, not lane support alone",
        "interpretation": "collective lane support can be near closed while particle identity remains held open",
        "next_frontier": next_frontier,
    }

    write_csv(
        SEPARATION_OUT,
        separation_rows,
        [
            "derived_replay_lane",
            "open_slots",
            "final_information_return",
            "final_gap_to_A_SIDE",
            "lane_closure_fraction",
            "lane_gap_in_ultra_units",
            "lane_gap_below_route_floor",
            "best_slot",
            "best_slot_WI_self_support_score",
            "best_slot_WI_delta",
            "best_slot_delta_in_ultra_units",
            "fixed_point_slots",
            "separation_class",
        ],
    )
    write_csv(RULE_OUT, rule_rows, ["rule", "condition", "status"])
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, separation_rows)

    print(result_class)
    print(f"stable_lane_closure_fraction={stable['lane_closure_fraction']}")
    print(f"stable_lane_gap_in_ultra_units={stable['lane_gap_in_ultra_units']}")
    print(f"top_slot={top_slot['suk055_pair']}")
    print(f"top_slot_WI_self_support_score={top_slot['WI_self_support_score']}")
    print(f"top_slot_delta_in_ultra_units={top_slot['WI_delta_in_ultra_residual_units']}")
    print(f"fixed_point_slot_promotions={fixed_promotions}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
