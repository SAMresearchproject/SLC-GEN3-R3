from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP032_SUMMARY = ARTIFACTS / "qp032" / "qp032_summary.json"
QP033_SELF_SUPPORT = ARTIFACTS / "qp033" / "qp033_slot_wi_self_support_table.csv"
QP034_SUMMARY = ARTIFACTS / "qp034" / "qp034_summary.json"
QP034_SEPARATION = ARTIFACTS / "qp034" / "qp034_lane_identity_separation_table.csv"

QP035_DIR = ARTIFACTS / "qp035"
PREFLIGHT_OUT = QP035_DIR / "qp035_preflight.md"
SUMMARY_OUT = QP035_DIR / "qp035_summary.json"
FIXED_POINT_OUT = QP035_DIR / "qp035_fixed_point_selector_table.csv"
CORRECTION_OUT = QP035_DIR / "qp035_local_return_correction_table.csv"
DECISION_OUT = QP035_DIR / "qp035_fixed_point_decision_table.csv"
SCHEMA_OUT = QP035_DIR / "qp035_schema.csv"
NEXT_OUT = QP035_DIR / "qp035_next_frontier.csv"
DOC_OUT = REPORTS / "QP035_PRIVATE_HALF_WRITE_INFORMATION_FIXED_POINT_SELECTOR.md"


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_preflight() -> None:
    QP035_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP035 Preflight - Half-Write / Information Fixed-Point Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP035 does not rerun QP032-QP034. It applies the Phase 3 fixed-point concept to
the open-slot W/I table.

## Selector Inputs

```text
artifacts/qp032/qp032_summary.json
artifacts/qp033/qp033_slot_wi_self_support_table.csv
artifacts/qp034/qp034_summary.json
artifacts/qp034/qp034_lane_identity_separation_table.csv
```

## Fixed-Point Conditions

```text
direct W/I contact:      abs(W_slot - I_return_slot) <= ultra residual
half-split contact:      abs(W_slot/2 - I_return_slot/2) <= ultra residual
closure complement:      abs((W_slot/2 + I_return_slot/2) - A_SIDE) <= ultra residual
```

No fitted weights are introduced.

## Question

```text
Does any open slot satisfy a native half-write / information-return fixed-point
condition, or is a local return correction still missing?
```
""",
        encoding="utf-8",
    )


def fixed_point_class(
    direct_contact: bool,
    half_contact: bool,
    complement_contact: bool,
    score: float,
) -> str:
    if direct_contact:
        return "DIRECT_WI_FIXED_POINT_PROMOTION"
    if half_contact:
        return "HALF_SPLIT_WI_FIXED_POINT_CONTACT"
    if complement_contact:
        return "COMPLEMENT_CLOSURE_FIXED_POINT_CONTACT"
    if score >= 0.95:
        return "STRONG_WI_SUPPORT_NEEDS_LOCAL_RETURN_CORRECTION"
    if score >= 0.75:
        return "MODERATE_WI_SUPPORT_NEEDS_LOCAL_RETURN_CORRECTION"
    return "WEAK_WI_SUPPORT_HELD_OPEN"


def write_doc(summary: dict[str, object], top_rows: list[dict[str, object]]) -> None:
    top_lines = "\n".join(
        f"| {row['QP035_rank']} | {row['suk055_pair']} | {row['direct_WI_delta']} | {row['half_split_delta']} | {row['closure_complement_delta']} | {row['local_return_correction_needed']} | {row['fixed_point_class']} |"
        for row in top_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP035 - Private Half-Write / Information Fixed-Point Selector

## Result

```text
{summary['result_class']}
```

QP035 applies the Phase 3 fixed-point selector to the open-slot W/I table.

## Top Fixed-Point Rows

| rank | slot | direct delta | half-split delta | complement delta | correction needed | class |
| ---: | --- | ---: | ---: | ---: | ---: | --- |
{top_lines}

## Key Fields

```text
top_slot = {summary['top_slot']}
top_fixed_point_class = {summary['top_fixed_point_class']}
direct_fixed_point_promotions = {summary['direct_fixed_point_promotions']}
half_split_contacts = {summary['half_split_contacts']}
complement_closure_contacts = {summary['complement_closure_contacts']}
top_local_return_correction_needed = {summary['top_local_return_correction_needed']}
top_direct_delta_in_ultra_units = {summary['top_direct_delta_in_ultra_units']}
```

## Interpretation

The half-write / information split does not by itself close an open particle
slot. The strongest candidate remains held open and requires a local return
correction before particle identity can promote.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    qp032 = read_json(QP032_SUMMARY)
    qp034 = read_json(QP034_SUMMARY)
    slot_rows = read_csv(QP033_SELF_SUPPORT)
    separation_rows = read_csv(QP034_SEPARATION)

    ultra = float(qp032["WI_mismatch"])
    a_side = float(qp032["W_target"])

    rows: list[dict[str, object]] = []
    for row in slot_rows:
        w_slot = float(row["W_slot"])
        i_slot = float(row["I_return_slot"])
        score = float(row["WI_self_support_score"])
        direct_delta = abs(w_slot - i_slot)
        half_write = w_slot / 2.0
        half_info = i_slot / 2.0
        half_delta = abs(half_write - half_info)
        complement_sum = half_write + half_info
        complement_delta = abs(complement_sum - a_side)
        direct_contact = direct_delta <= ultra
        half_contact = half_delta <= ultra
        complement_contact = complement_delta <= ultra
        local_correction_needed = max(0.0, direct_delta - ultra)
        half_correction_needed = max(0.0, half_delta - ultra)
        correction_fraction_of_direct_delta = local_correction_needed / direct_delta if direct_delta else 0.0
        selector_class = fixed_point_class(direct_contact, half_contact, complement_contact, score)
        rows.append(
            {
                "suk055_pair": row["suk055_pair"],
                "oriented_symbols": row["oriented_symbols"],
                "charge_class": row["charge_class"],
                "derived_replay_lane": row["derived_replay_lane"],
                "W_slot": w_slot,
                "I_return_slot": i_slot,
                "direct_WI_delta": direct_delta,
                "direct_delta_in_ultra_units": direct_delta / ultra if ultra else 0.0,
                "half_write": half_write,
                "half_information": half_info,
                "half_split_delta": half_delta,
                "half_split_delta_in_ultra_units": half_delta / ultra if ultra else 0.0,
                "closure_complement_sum": complement_sum,
                "closure_complement_delta": complement_delta,
                "closure_complement_delta_in_ultra_units": complement_delta / ultra if ultra else 0.0,
                "local_return_correction_needed": local_correction_needed,
                "half_split_correction_needed": half_correction_needed,
                "correction_fraction_of_direct_delta": correction_fraction_of_direct_delta,
                "WI_self_support_score": score,
                "direct_fixed_point_contact": direct_contact,
                "half_split_fixed_point_contact": half_contact,
                "complement_closure_contact": complement_contact,
                "fixed_point_class": selector_class,
            }
        )
    rows.sort(
        key=lambda row: (
            int(not row["direct_fixed_point_contact"]),
            int(not row["half_split_fixed_point_contact"]),
            int(not row["complement_closure_contact"]),
            -float(row["WI_self_support_score"]),
            float(row["local_return_correction_needed"]),
            str(row["suk055_pair"]),
        )
    )
    for rank, row in enumerate(rows, start=1):
        row["QP035_rank"] = rank

    direct_promotions = [row for row in rows if row["direct_fixed_point_contact"]]
    half_contacts = [row for row in rows if row["half_split_fixed_point_contact"]]
    complement_contacts = [row for row in rows if row["complement_closure_contact"]]
    strong_needing_correction = [
        row
        for row in rows
        if row["fixed_point_class"] == "STRONG_WI_SUPPORT_NEEDS_LOCAL_RETURN_CORRECTION"
    ]
    top = rows[0]

    if direct_promotions:
        result_class = "QP035_HALF_WRITE_INFORMATION_FIXED_POINT_PROMOTION_SELECTED"
        next_frontier = "QP036_PRIVATE_PARTICLE_IDENTITY_CLOSURE_FREEZE"
    elif half_contacts or complement_contacts:
        result_class = "QP035_HALF_WRITE_INFORMATION_FIXED_POINT_CONTACT_HELD_OPEN"
        next_frontier = "QP036_PRIVATE_FIXED_POINT_CONTACT_PROMOTION_RULE"
    elif strong_needing_correction:
        result_class = "QP035_FIXED_POINT_SELECTOR_HELD_OPEN_LOCAL_RETURN_CORRECTION_REQUIRED"
        next_frontier = "QP036_PRIVATE_LOCAL_INFORMATION_RETURN_CORRECTION_SELECTOR"
    else:
        result_class = "QP035_FIXED_POINT_SELECTOR_NO_CONTACT"
        next_frontier = "QP036_PRIVATE_IDENTITY_CLOSURE_MISSING_MECHANISM"

    correction_rows = [
        {
            "suk055_pair": row["suk055_pair"],
            "derived_replay_lane": row["derived_replay_lane"],
            "local_return_correction_needed": row["local_return_correction_needed"],
            "local_return_correction_in_ultra_units": row["direct_delta_in_ultra_units"],
            "correction_fraction_of_direct_delta": row["correction_fraction_of_direct_delta"],
            "fixed_point_class": row["fixed_point_class"],
        }
        for row in rows
    ]
    decision_rows = [
        {
            "decision_item": "direct_fixed_point_promotions",
            "decision_value": len(direct_promotions),
            "reason": "direct contact requires abs(W_slot - I_return_slot) <= QP032 ultra residual",
        },
        {
            "decision_item": "half_split_contacts",
            "decision_value": len(half_contacts),
            "reason": "half split still leaves W/I mismatch above ultra-residual scale",
        },
        {
            "decision_item": "complement_closure_contacts",
            "decision_value": len(complement_contacts),
            "reason": "half-write plus half-information does not complement-close to A_SIDE",
        },
        {
            "decision_item": "selected_missing_mechanism",
            "decision_value": "LOCAL_INFORMATION_RETURN_CORRECTION",
            "reason": "strong W/I support exists but no fixed-point contact promotes",
        },
    ]
    schema_rows = [
        {
            "class": result_class,
            "meaning": "half-write/information fixed-point selector is applied; strong slots remain held open",
            "status": "selected",
        },
        {
            "class": "DIRECT_WI_FIXED_POINT_PROMOTION",
            "meaning": "localized slot W/I delta is at or below QP032 ultra residual",
            "status": "not reached" if not direct_promotions else "reached",
        },
        {
            "class": next_frontier,
            "meaning": "find or reject the local information-return correction mechanism",
            "status": "next",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP035 finds that half-write/information splitting alone does not promote a slot. The next forward question is whether SAM/QP has a native local return correction.",
            "launch_from": "qp035_fixed_point_selector_table.csv;qp035_local_return_correction_table.csv;artifacts/qp034/qp034_summary.json",
            "target_output": "local information-return correction selector",
        }
    ]

    stable_sep = next(row for row in separation_rows if row["derived_replay_lane"] == "DERIVED_STABLE_ANCHOR_LANE")
    summary = {
        "artifact": "QP035_PRIVATE_HALF_WRITE_INFORMATION_FIXED_POINT_SELECTOR",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp032/qp032_summary.json",
            "artifacts/qp033/qp033_slot_wi_self_support_table.csv",
            "artifacts/qp034/qp034_summary.json",
            "artifacts/qp034/qp034_lane_identity_separation_table.csv",
        ],
        "phase3_campaign": qp034["phase3_campaign"],
        "qp032_result_class": qp032["result_class"],
        "qp034_result_class": qp034["result_class"],
        "ultra_residual_threshold": ultra,
        "A_SIDE": a_side,
        "slots_tested": len(rows),
        "direct_fixed_point_promotions": len(direct_promotions),
        "half_split_contacts": len(half_contacts),
        "complement_closure_contacts": len(complement_contacts),
        "strong_slots_needing_local_return_correction": len(strong_needing_correction),
        "top_slot": top["suk055_pair"],
        "top_fixed_point_class": top["fixed_point_class"],
        "top_direct_WI_delta": top["direct_WI_delta"],
        "top_direct_delta_in_ultra_units": top["direct_delta_in_ultra_units"],
        "top_half_split_delta": top["half_split_delta"],
        "top_half_split_delta_in_ultra_units": top["half_split_delta_in_ultra_units"],
        "top_closure_complement_delta": top["closure_complement_delta"],
        "top_local_return_correction_needed": top["local_return_correction_needed"],
        "stable_lane_separation_class": stable_sep["separation_class"],
        "selected_missing_mechanism": "LOCAL_INFORMATION_RETURN_CORRECTION",
        "interpretation": "half-write/information split is necessary but not sufficient for particle identity; local return correction remains missing",
        "next_frontier": next_frontier,
    }

    write_csv(
        FIXED_POINT_OUT,
        rows,
        [
            "QP035_rank",
            "suk055_pair",
            "oriented_symbols",
            "charge_class",
            "derived_replay_lane",
            "W_slot",
            "I_return_slot",
            "direct_WI_delta",
            "direct_delta_in_ultra_units",
            "half_write",
            "half_information",
            "half_split_delta",
            "half_split_delta_in_ultra_units",
            "closure_complement_sum",
            "closure_complement_delta",
            "closure_complement_delta_in_ultra_units",
            "local_return_correction_needed",
            "half_split_correction_needed",
            "correction_fraction_of_direct_delta",
            "WI_self_support_score",
            "direct_fixed_point_contact",
            "half_split_fixed_point_contact",
            "complement_closure_contact",
            "fixed_point_class",
        ],
    )
    write_csv(
        CORRECTION_OUT,
        correction_rows,
        [
            "suk055_pair",
            "derived_replay_lane",
            "local_return_correction_needed",
            "local_return_correction_in_ultra_units",
            "correction_fraction_of_direct_delta",
            "fixed_point_class",
        ],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, rows[:8])

    print(result_class)
    print(f"top_slot={top['suk055_pair']}")
    print(f"top_fixed_point_class={top['fixed_point_class']}")
    print(f"direct_fixed_point_promotions={len(direct_promotions)}")
    print(f"half_split_contacts={len(half_contacts)}")
    print(f"complement_closure_contacts={len(complement_contacts)}")
    print(f"top_local_return_correction_needed={top['local_return_correction_needed']}")
    print(f"top_direct_delta_in_ultra_units={top['direct_delta_in_ultra_units']}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
