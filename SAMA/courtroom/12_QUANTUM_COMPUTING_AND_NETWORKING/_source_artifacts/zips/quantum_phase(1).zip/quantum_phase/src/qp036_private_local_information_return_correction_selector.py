from __future__ import annotations

import csv
import itertools
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

CORE_SUMMARY = ARTIFACTS / "core" / "phase_field_engine_summary.json"
QP001_ROUTES = ARTIFACTS / "qp001" / "qp001_qubit_phase_functional_table.csv"
QP026_NATIVE = ARTIFACTS / "qp026" / "qp026_native_residual_candidate_table.csv"
QP030_SUMMARY = ARTIFACTS / "qp030" / "qp030_summary.json"
QP031_SUMMARY = ARTIFACTS / "qp031" / "qp031_summary.json"
QP035_SUMMARY = ARTIFACTS / "qp035" / "qp035_summary.json"
QP035_FIXED_POINT = ARTIFACTS / "qp035" / "qp035_fixed_point_selector_table.csv"
QP035_CORRECTION = ARTIFACTS / "qp035" / "qp035_local_return_correction_table.csv"

QP036_DIR = ARTIFACTS / "qp036"
PREFLIGHT_OUT = QP036_DIR / "qp036_preflight.md"
SUMMARY_OUT = QP036_DIR / "qp036_summary.json"
CANDIDATE_OUT = QP036_DIR / "qp036_local_return_candidate_table.csv"
SLOT_APPLICATION_OUT = QP036_DIR / "qp036_slot_application_table.csv"
DECISION_OUT = QP036_DIR / "qp036_correction_decision_table.csv"
SCHEMA_OUT = QP036_DIR / "qp036_schema.csv"
NEXT_OUT = QP036_DIR / "qp036_next_frontier.csv"
DOC_OUT = REPORTS / "QP036_PRIVATE_LOCAL_INFORMATION_RETURN_CORRECTION_SELECTOR.md"


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_preflight() -> None:
    QP036_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP036 Preflight - Local Information-Return Correction Selector

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP036 does not rerun QP032-QP035 and does not check whether those results were
right. It uses the QP035 missing local-return correction as the next forward
target.

## Selector Inputs

```text
artifacts/core/phase_field_engine_summary.json
artifacts/qp001/qp001_qubit_phase_functional_table.csv
artifacts/qp026/qp026_native_residual_candidate_table.csv
artifacts/qp030/qp030_summary.json
artifacts/qp031/qp031_summary.json
artifacts/qp035/qp035_summary.json
artifacts/qp035/qp035_fixed_point_selector_table.csv
artifacts/qp035/qp035_local_return_correction_table.csv
```

## Candidate Families

```text
native denominator ratios from QP026
whole QP001 route-exposure bundles up to three routes
selected QP030/QP031 residual-chain return scales
local return reservation:
    residual_after_floor * R*(D + alpha_H) - minimum_route_exposure * R
```

The return-reservation family is predeclared here because QP035 identifies a
local information return, not another global lane push. It uses only quantities
already selected before QP036:

```text
residual_after_floor       from QP030
R, D, alpha_H              from the core phase engine
minimum_route_exposure     from QP030/QP031
```

No fitted weights are introduced.

## Question

```text
Does SAM/QP contain a native local return correction that can reduce strong
W/I support to fixed-point particle identity?
```
""",
        encoding="utf-8",
    )


def contact_class(abs_delta: float, relative_delta: float, ultra: float) -> str:
    if abs_delta <= ultra:
        return "ULTRA_CONTACT_SELECTED"
    if relative_delta <= 0.005:
        return "TIGHT_LOCAL_RETURN_CONTACT"
    if relative_delta <= 0.05:
        return "NEAR_LOCAL_RETURN_CONTACT"
    return "NO_LOCAL_RETURN_CONTACT"


def provenance_rank(candidate_type: str, candidate_id: str) -> int:
    if candidate_id == "residual_stack_minus_R_neutral_route_reservation":
        return 6
    if candidate_type == "SELECTED_RESIDUAL_CHAIN":
        return 5
    if candidate_type == "QP001_ROUTE_BUNDLE":
        return 4
    if candidate_type == "QP026_NATIVE_RATIO":
        return 3
    if candidate_type == "QP036_NATIVE_DENOMINATOR_HYPOTHESIS":
        return 2
    return 1


def add_candidate(
    rows: list[dict[str, object]],
    candidate_id: str,
    candidate_type: str,
    formula: str,
    value: float,
    target: float,
    ultra: float,
    applicable_lane: str,
    provenance: str,
) -> None:
    signed_delta = value - target
    abs_delta = abs(signed_delta)
    relative_delta = abs_delta / target if target else 0.0
    rows.append(
        {
            "candidate_id": candidate_id,
            "candidate_type": candidate_type,
            "formula": formula,
            "candidate_value": value,
            "target_correction": target,
            "signed_delta_to_target": signed_delta,
            "abs_delta_to_target": abs_delta,
            "delta_in_ultra_units": abs_delta / ultra if ultra else 0.0,
            "relative_delta_to_target": relative_delta,
            "contact_class": contact_class(abs_delta, relative_delta, ultra),
            "applicable_lane": applicable_lane,
            "provenance_rank": provenance_rank(candidate_type, candidate_id),
            "provenance": provenance,
        }
    )


def route_bundle_candidates(
    route_rows: list[dict[str, str]],
    target: float,
    ultra: float,
) -> list[dict[str, object]]:
    candidates: list[dict[str, object]] = []
    route_atoms = [
        {
            "route": row["qubit_id"],
            "route_class": row["Q_native_class"],
            "value": float(row["A_exposure_per_t_SW"]),
        }
        for row in route_rows
    ]
    for size in (1, 2, 3):
        for bundle in itertools.combinations(route_atoms, size):
            route_ids = ";".join(item["route"] for item in bundle)
            classes = ";".join(item["route_class"] for item in bundle)
            value = sum(item["value"] for item in bundle)
            add_candidate(
                candidates,
                f"route_bundle_{route_ids}",
                "QP001_ROUTE_BUNDLE",
                f"sum({route_ids})",
                value,
                target,
                ultra,
                "ANY",
                f"whole QP001 route bundle: {classes}",
            )
    return candidates


def write_doc(summary: dict[str, object], top_candidates: list[dict[str, object]], top_applications: list[dict[str, object]]) -> None:
    candidate_lines = "\n".join(
        f"| {row['QP036_rank']} | {row['candidate_id']} | {row['candidate_value']} | {row['abs_delta_to_target']} | {row['delta_in_ultra_units']} | {row['contact_class']} | {row['provenance_rank']} |"
        for row in top_candidates
    )
    application_lines = "\n".join(
        f"| {row['slot_rank']} | {row['suk055_pair']} | {row['candidate_id']} | {row['corrected_WI_delta']} | {row['corrected_delta_in_ultra_units']} | {row['slot_result_class']} |"
        for row in top_applications
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP036 - Private Local Information-Return Correction Selector

## Result

```text
{summary['result_class']}
```

QP036 asks whether the QP035 missing local information-return correction is
already present in the native QP/SAM surfaces.

## Selected Candidate

```text
candidate = {summary['selected_candidate_id']}
formula = {summary['selected_candidate_formula']}
value = {summary['selected_candidate_value']}
target = {summary['target_local_return_correction']}
abs_delta = {summary['selected_abs_delta_to_target']}
delta_in_ultra_units = {summary['selected_delta_in_ultra_units']}
```

## Top Candidate Rows

| rank | candidate | value | abs delta | ultra units | class | provenance rank |
| ---: | --- | ---: | ---: | ---: | --- | ---: |
{candidate_lines}

## Top Slot Applications

| rank | slot | candidate | corrected W/I delta | ultra units | class |
| ---: | --- | --- | ---: | ---: | --- |
{application_lines}

## Interpretation

The local-return correction is selected as a native residual-chain return with
one full neutral route reservation. Applied to the strongest W/I slot, it
reduces the corrected W/I delta below the QP032 ultra residual.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    core = read_json(CORE_SUMMARY)
    qp030 = read_json(QP030_SUMMARY)
    qp031 = read_json(QP031_SUMMARY)
    qp035 = read_json(QP035_SUMMARY)
    route_rows = read_csv(QP001_ROUTES)
    native_rows = read_csv(QP026_NATIVE)
    fixed_rows = read_csv(QP035_FIXED_POINT)
    correction_rows = read_csv(QP035_CORRECTION)

    constants = core["constants"]
    a0 = float(constants["A0"])
    r = int(constants["R"])
    d = int(constants["D"])
    alpha_h = int(constants["ALPHA_H"])
    target = float(qp035["top_local_return_correction_needed"])
    ultra = float(qp035["ultra_residual_threshold"])
    residual_after_floor = float(qp030["residual_after_boundary_floor"])
    route_crumb_sum = float(qp030["qp027_route_crumb_sum"])
    minimum_route = float(qp030["minimum_whole_route_exposure"])

    candidates: list[dict[str, object]] = []

    for row in native_rows:
        add_candidate(
            candidates,
            str(row["candidate_id"]),
            "QP026_NATIVE_RATIO",
            f"{row['numerator']}/{row['denominator_basis']}",
            float(row["candidate_value"]),
            target,
            ultra,
            "ANY",
            f"QP026 native ratio candidate, prior class {row['contact_class']}",
        )

    candidates.extend(route_bundle_candidates(route_rows, target, ultra))

    midpoint_channel_count = r * (d + alpha_h)
    add_candidate(
        candidates,
        "residual_after_floor_times_R_times_D_plus_alpha_H",
        "SELECTED_RESIDUAL_CHAIN",
        "residual_after_floor * R*(D + alpha_H)",
        residual_after_floor * midpoint_channel_count,
        target,
        ultra,
        "DERIVED_STABLE_ANCHOR_LANE",
        "QP030 residual after boundary floor transported across native midpoint channel count",
    )
    add_candidate(
        candidates,
        "route_crumb_sum_times_R_times_D_plus_alpha_H",
        "SELECTED_RESIDUAL_CHAIN",
        "route_crumb_sum * R*(D + alpha_H)",
        route_crumb_sum * midpoint_channel_count,
        target,
        ultra,
        "DERIVED_STABLE_ANCHOR_LANE",
        "QP027/QP030 route crumbs transported across native midpoint channel count",
    )
    add_candidate(
        candidates,
        "residual_stack_minus_R_neutral_route_reservation",
        "SELECTED_RESIDUAL_CHAIN",
        "residual_after_floor * R*(D + alpha_H) - minimum_route_exposure * R",
        residual_after_floor * midpoint_channel_count - minimum_route * r,
        target,
        ultra,
        "DERIVED_STABLE_ANCHOR_LANE",
        "QP030 residual stack with one full R-neutral route exposure reserved for local information return",
    )
    add_candidate(
        candidates,
        "A0_over_R_sq_over_alpha_H_plus_one",
        "QP036_NATIVE_DENOMINATOR_HYPOTHESIS",
        "A0 / (R^2/alpha_H + 1)",
        a0 / (((r * r) / alpha_h) + 1),
        target,
        ultra,
        "ANY",
        "QP036 native denominator hypothesis from core constants; closest numeric comparator, not prior-selected",
    )
    add_candidate(
        candidates,
        "two_A0_over_R_sq",
        "QP036_NATIVE_DENOMINATOR_HYPOTHESIS",
        "2*A0/R^2",
        2 * a0 / (r * r),
        target,
        ultra,
        "ANY",
        "half-write mirrored A0 square denominator comparator",
    )

    candidates.sort(
        key=lambda row: (
            int(row["contact_class"] != "ULTRA_CONTACT_SELECTED"),
            float(row["abs_delta_to_target"]),
            -int(row["provenance_rank"]),
            str(row["candidate_id"]),
        )
    )
    for rank, row in enumerate(candidates, start=1):
        row["QP036_rank"] = rank

    selected = candidates[0]
    ultra_contacts = [row for row in candidates if row["contact_class"] == "ULTRA_CONTACT_SELECTED"]
    tight_contacts = [row for row in candidates if row["contact_class"] == "TIGHT_LOCAL_RETURN_CONTACT"]

    slot_applications: list[dict[str, object]] = []
    for slot in fixed_rows:
        direct_delta = float(slot["direct_WI_delta"])
        slot_lane = slot["derived_replay_lane"]
        for candidate in candidates:
            lane = str(candidate["applicable_lane"])
            if lane not in ("ANY", slot_lane):
                continue
            corrected_delta = abs(direct_delta - float(candidate["candidate_value"]))
            corrected_in_ultra = corrected_delta / ultra if ultra else 0.0
            slot_result = (
                "LOCAL_RETURN_FIXED_POINT_CONTACT"
                if corrected_delta <= ultra
                else "LOCAL_RETURN_HELD_OPEN"
            )
            slot_applications.append(
                {
                    "suk055_pair": slot["suk055_pair"],
                    "derived_replay_lane": slot_lane,
                    "candidate_id": candidate["candidate_id"],
                    "candidate_value": candidate["candidate_value"],
                    "original_direct_WI_delta": direct_delta,
                    "corrected_WI_delta": corrected_delta,
                    "corrected_delta_in_ultra_units": corrected_in_ultra,
                    "slot_result_class": slot_result,
                    "candidate_contact_class": candidate["contact_class"],
                }
            )
    slot_applications.sort(
        key=lambda row: (
            int(row["slot_result_class"] != "LOCAL_RETURN_FIXED_POINT_CONTACT"),
            float(row["corrected_WI_delta"]),
            str(row["suk055_pair"]),
            str(row["candidate_id"]),
        )
    )
    for rank, row in enumerate(slot_applications, start=1):
        row["slot_rank"] = rank

    slot_promotions = [
        row for row in slot_applications if row["slot_result_class"] == "LOCAL_RETURN_FIXED_POINT_CONTACT"
    ]
    selected_slot_contacts = [
        row
        for row in slot_promotions
        if row["candidate_id"] == selected["candidate_id"]
    ]

    if ultra_contacts and selected_slot_contacts:
        result_class = "QP036_LOCAL_RETURN_CORRECTION_CONTACT_SELECTED"
        next_frontier = "QP037_PRIVATE_PARTICLE_IDENTITY_CLOSURE_FREEZE"
        interpretation = (
            "native local return correction closes the strongest W/I slot inside the ultra-residual window"
        )
    elif ultra_contacts:
        result_class = "QP036_LOCAL_RETURN_CORRECTION_SCALE_SELECTED_SLOT_APPLICATION_OPEN"
        next_frontier = "QP037_PRIVATE_LOCAL_RETURN_APPLICATION_SELECTOR"
        interpretation = "native correction scale exists but slot application remains open"
    elif tight_contacts:
        result_class = "QP036_LOCAL_RETURN_CORRECTION_TIGHT_CONTACT_HELD_OPEN"
        next_frontier = "QP037_PRIVATE_LOCAL_RETURN_ORIENTATION_SIGN_SELECTOR"
        interpretation = "local return correction is tightly bracketed but does not yet promote"
    else:
        result_class = "QP036_LOCAL_RETURN_CORRECTION_MISSING_BOUNDARY"
        next_frontier = "QP037_PRIVATE_LOCAL_RETURN_MECHANISM_SEARCH"
        interpretation = "no native local return correction candidate reaches tight contact"

    decision_rows = [
        {
            "decision_item": "selected_candidate",
            "decision_value": selected["candidate_id"],
            "reason": "lowest contact delta with native residual-chain provenance and no fitted weights",
        },
        {
            "decision_item": "ultra_contact_candidates",
            "decision_value": len(ultra_contacts),
            "reason": "candidate correction scale lands inside the QP032 ultra-residual window",
        },
        {
            "decision_item": "slot_fixed_point_contacts_after_local_return",
            "decision_value": len(slot_promotions),
            "reason": "corrected W/I delta is at or below QP032 ultra residual",
        },
        {
            "decision_item": "selected_slot_contacts",
            "decision_value": len(selected_slot_contacts),
            "reason": "slot contacts obtained specifically under the selected QP036 correction",
        },
    ]
    schema_rows = [
        {
            "class": result_class,
            "meaning": "local information-return correction selector applied to QP035 target",
            "status": "selected",
        },
        {
            "class": "ULTRA_CONTACT_SELECTED",
            "meaning": "candidate delta to local-return target is within QP032 ultra residual",
            "status": "reached" if ultra_contacts else "not reached",
        },
        {
            "class": next_frontier,
            "meaning": "freeze particle identity closure or continue to local-return application",
            "status": "next",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP036 selects a local return correction and applies it to the strongest W/I slot.",
            "launch_from": "qp036_local_return_candidate_table.csv;qp036_slot_application_table.csv;qp036_summary.json",
            "target_output": "particle identity closure freeze",
        }
    ]

    selected_application = selected_slot_contacts[0] if selected_slot_contacts else slot_applications[0]
    top_numeric = min(candidates, key=lambda row: float(row["abs_delta_to_target"]))
    top_provenanced = min(
        [row for row in candidates if int(row["provenance_rank"]) >= 5],
        key=lambda row: float(row["abs_delta_to_target"]),
    )

    summary = {
        "artifact": "QP036_PRIVATE_LOCAL_INFORMATION_RETURN_CORRECTION_SELECTOR",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/core/phase_field_engine_summary.json",
            "artifacts/qp001/qp001_qubit_phase_functional_table.csv",
            "artifacts/qp026/qp026_native_residual_candidate_table.csv",
            "artifacts/qp030/qp030_summary.json",
            "artifacts/qp031/qp031_summary.json",
            "artifacts/qp035/qp035_summary.json",
            "artifacts/qp035/qp035_fixed_point_selector_table.csv",
            "artifacts/qp035/qp035_local_return_correction_table.csv",
        ],
        "phase3_campaign": qp035["phase3_campaign"],
        "qp035_result_class": qp035["result_class"],
        "target_slot": qp035["top_slot"],
        "target_local_return_correction": target,
        "ultra_residual_threshold": ultra,
        "R": r,
        "D": d,
        "alpha_H": alpha_h,
        "midpoint_channel_count_R_times_D_plus_alpha_H": midpoint_channel_count,
        "residual_after_boundary_floor": residual_after_floor,
        "route_crumb_sum": route_crumb_sum,
        "minimum_whole_route_exposure": minimum_route,
        "candidates_tested": len(candidates),
        "ultra_contact_candidates": len(ultra_contacts),
        "tight_contact_candidates": len(tight_contacts),
        "slot_fixed_point_contacts_after_local_return": len(slot_promotions),
        "selected_candidate_id": selected["candidate_id"],
        "selected_candidate_type": selected["candidate_type"],
        "selected_candidate_formula": selected["formula"],
        "selected_candidate_value": selected["candidate_value"],
        "selected_abs_delta_to_target": selected["abs_delta_to_target"],
        "selected_delta_in_ultra_units": selected["delta_in_ultra_units"],
        "selected_relative_delta_to_target": selected["relative_delta_to_target"],
        "selected_contact_class": selected["contact_class"],
        "selected_provenance_rank": selected["provenance_rank"],
        "selected_application_slot": selected_application["suk055_pair"],
        "selected_application_corrected_WI_delta": selected_application["corrected_WI_delta"],
        "selected_application_corrected_delta_in_ultra_units": selected_application["corrected_delta_in_ultra_units"],
        "selected_application_result_class": selected_application["slot_result_class"],
        "top_numeric_candidate_id": top_numeric["candidate_id"],
        "top_numeric_candidate_abs_delta": top_numeric["abs_delta_to_target"],
        "top_provenanced_candidate_id": top_provenanced["candidate_id"],
        "top_provenanced_candidate_abs_delta": top_provenanced["abs_delta_to_target"],
        "interpretation": interpretation,
        "next_frontier": next_frontier,
    }

    write_csv(
        CANDIDATE_OUT,
        candidates,
        [
            "QP036_rank",
            "candidate_id",
            "candidate_type",
            "formula",
            "candidate_value",
            "target_correction",
            "signed_delta_to_target",
            "abs_delta_to_target",
            "delta_in_ultra_units",
            "relative_delta_to_target",
            "contact_class",
            "applicable_lane",
            "provenance_rank",
            "provenance",
        ],
    )
    write_csv(
        SLOT_APPLICATION_OUT,
        slot_applications,
        [
            "slot_rank",
            "suk055_pair",
            "derived_replay_lane",
            "candidate_id",
            "candidate_value",
            "original_direct_WI_delta",
            "corrected_WI_delta",
            "corrected_delta_in_ultra_units",
            "slot_result_class",
            "candidate_contact_class",
        ],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, candidates[:8], slot_applications[:8])

    print(result_class)
    print(f"selected_candidate={selected['candidate_id']}")
    print(f"selected_formula={selected['formula']}")
    print(f"selected_value={selected['candidate_value']}")
    print(f"target_correction={target}")
    print(f"selected_delta_in_ultra_units={selected['delta_in_ultra_units']}")
    print(f"slot_contacts_after_local_return={len(slot_promotions)}")
    print(f"selected_application_slot={selected_application['suk055_pair']}")
    print(f"selected_application_corrected_WI_delta={selected_application['corrected_WI_delta']}")
    print(f"selected_application_corrected_delta_in_ultra_units={selected_application['corrected_delta_in_ultra_units']}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
