from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP035_FIXED_POINT = ARTIFACTS / "qp035" / "qp035_fixed_point_selector_table.csv"
QP036_SUMMARY = ARTIFACTS / "qp036" / "qp036_summary.json"
QP036_CANDIDATES = ARTIFACTS / "qp036" / "qp036_local_return_candidate_table.csv"
QP036_APPLICATIONS = ARTIFACTS / "qp036" / "qp036_slot_application_table.csv"

QP037_DIR = ARTIFACTS / "qp037"
PREFLIGHT_OUT = QP037_DIR / "qp037_preflight.md"
SUMMARY_OUT = QP037_DIR / "qp037_summary.json"
FREEZE_OUT = QP037_DIR / "qp037_particle_identity_freeze_table.csv"
PROMOTION_OUT = QP037_DIR / "qp037_promoted_identity_table.csv"
HELD_OPEN_OUT = QP037_DIR / "qp037_held_open_identity_table.csv"
DECISION_OUT = QP037_DIR / "qp037_freeze_decision_table.csv"
SCHEMA_OUT = QP037_DIR / "qp037_schema.csv"
NEXT_OUT = QP037_DIR / "qp037_next_frontier.csv"
DOC_OUT = REPORTS / "QP037_PRIVATE_PARTICLE_IDENTITY_CLOSURE_FREEZE.md"


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_preflight() -> None:
    QP037_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP037 Preflight - Particle Identity Closure Freeze

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP037 does not rerun QP032-QP036. It freezes the identity status implied by the
QP036 selected local return correction.

## Selector Inputs

```text
artifacts/qp035/qp035_fixed_point_selector_table.csv
artifacts/qp036/qp036_summary.json
artifacts/qp036/qp036_local_return_candidate_table.csv
artifacts/qp036/qp036_slot_application_table.csv
```

## Freeze Rule

```text
Use only the QP036 selected correction.
Apply it only to the lane for which QP036 selected it, unless the candidate is
marked ANY.
Promote a slot only when corrected_WI_delta <= QP032/QP036 ultra residual.
Keep per-slot alternate candidate contacts out of the freeze decision.
```

No fitted weights are introduced.

## Question

```text
Which slots promote, remain held open, or are blocked under W/I closure after
the selected local return correction?
```
""",
        encoding="utf-8",
    )


def freeze_class(
    direct_contact: bool,
    correction_applies: bool,
    corrected_contact: bool,
    score: float,
) -> tuple[str, str]:
    if direct_contact:
        return "PROMOTED", "DIRECT_WI_FIXED_POINT_IDENTITY"
    if correction_applies and corrected_contact:
        return "PROMOTED", "LOCAL_RETURN_WI_FIXED_POINT_IDENTITY"
    if correction_applies and score >= 0.95:
        return "HELD_OPEN", "STRONG_SLOT_SELECTED_CORRECTION_SUBCONTACT"
    if correction_applies and score >= 0.75:
        return "HELD_OPEN", "MODERATE_SLOT_SELECTED_CORRECTION_SUBCONTACT"
    if correction_applies:
        return "HELD_OPEN", "WEAK_SLOT_SELECTED_CORRECTION_SUBCONTACT"
    if score >= 0.95:
        return "HELD_OPEN", "STRONG_SLOT_NO_SELECTED_RETURN_FOR_LANE"
    if score >= 0.75:
        return "HELD_OPEN", "MODERATE_SLOT_NO_SELECTED_RETURN_FOR_LANE"
    return "HELD_OPEN", "WEAK_SLOT_NO_SELECTED_RETURN_FOR_LANE"


def write_doc(summary: dict[str, object], freeze_rows: list[dict[str, object]]) -> None:
    table_lines = "\n".join(
        f"| {row['QP037_rank']} | {row['suk055_pair']} | {row['derived_replay_lane']} | {row['freeze_status']} | {row['freeze_class']} | {row['corrected_WI_delta']} | {row['corrected_delta_in_ultra_units']} |"
        for row in freeze_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP037 - Private Particle Identity Closure Freeze

## Result

```text
{summary['result_class']}
```

QP037 freezes the Phase 3 particle identity status after the QP036 selected
local information-return correction.

## Freeze Rule

```text
selected correction = {summary['selected_candidate_id']}
selected formula = {summary['selected_candidate_formula']}
selected correction value = {summary['selected_candidate_value']}
ultra residual threshold = {summary['ultra_residual_threshold']}
```

## Identity Freeze Table

| rank | slot | lane | status | class | corrected delta | ultra units |
| ---: | --- | --- | --- | --- | ---: | ---: |
{table_lines}

## Key Fields

```text
promoted_identity_slots = {summary['promoted_identity_slots']}
held_open_identity_slots = {summary['held_open_identity_slots']}
blocked_identity_slots = {summary['blocked_identity_slots']}
promoted_slots = {summary['promoted_slots']}
top_promoted_slot = {summary['top_promoted_slot']}
top_promoted_corrected_WI_delta = {summary['top_promoted_corrected_WI_delta']}
top_promoted_corrected_delta_in_ultra_units = {summary['top_promoted_corrected_delta_in_ultra_units']}
```

## Interpretation

The selected local-return correction promotes one open slot, `c<->t`, to a
Phase 3 W/I fixed-point identity. The remaining open slots stay open under this
freeze because the selected correction either remains subcontact for that slot
or is not the selected return mechanism for that lane.

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    qp036 = read_json(QP036_SUMMARY)
    fixed_rows = read_csv(QP035_FIXED_POINT)
    candidate_rows = read_csv(QP036_CANDIDATES)
    application_rows = read_csv(QP036_APPLICATIONS)

    selected_id = str(qp036["selected_candidate_id"])
    selected_candidate = next(row for row in candidate_rows if row["candidate_id"] == selected_id)
    selected_value = float(selected_candidate["candidate_value"])
    selected_lane = selected_candidate["applicable_lane"]
    ultra = float(qp036["ultra_residual_threshold"])

    selected_application_by_slot = {
        row["suk055_pair"]: row
        for row in application_rows
        if row["candidate_id"] == selected_id
    }

    freeze_rows: list[dict[str, object]] = []
    for row in fixed_rows:
        slot = row["suk055_pair"]
        lane = row["derived_replay_lane"]
        score = float(row["WI_self_support_score"])
        direct_delta = float(row["direct_WI_delta"])
        direct_contact = row["direct_fixed_point_contact"] == "True"
        correction_applies = selected_lane == "ANY" or selected_lane == lane
        if correction_applies:
            corrected_delta = abs(direct_delta - selected_value)
            correction_used = selected_id
            correction_value = selected_value
        else:
            corrected_delta = direct_delta
            correction_used = "NO_SELECTED_CORRECTION_FOR_LANE"
            correction_value = ""
        corrected_contact = corrected_delta <= ultra
        status, cls = freeze_class(direct_contact, correction_applies, corrected_contact, score)
        application_rank = selected_application_by_slot.get(slot, {}).get("slot_rank", "")
        freeze_rows.append(
            {
                "suk055_pair": slot,
                "oriented_symbols": row["oriented_symbols"],
                "charge_class": row["charge_class"],
                "derived_replay_lane": lane,
                "W_slot": float(row["W_slot"]),
                "I_return_slot": float(row["I_return_slot"]),
                "direct_WI_delta": direct_delta,
                "direct_delta_in_ultra_units": float(row["direct_delta_in_ultra_units"]),
                "WI_self_support_score": score,
                "selected_correction_applicable": correction_applies,
                "selected_correction_used": correction_used,
                "selected_correction_value": correction_value,
                "corrected_WI_delta": corrected_delta,
                "corrected_delta_in_ultra_units": corrected_delta / ultra if ultra else 0.0,
                "freeze_status": status,
                "freeze_class": cls,
                "qp036_selected_application_rank": application_rank,
            }
        )

    freeze_rows.sort(
        key=lambda row: (
            int(row["freeze_status"] != "PROMOTED"),
            float(row["corrected_WI_delta"]),
            -float(row["WI_self_support_score"]),
            str(row["suk055_pair"]),
        )
    )
    for rank, row in enumerate(freeze_rows, start=1):
        row["QP037_rank"] = rank

    promoted = [row for row in freeze_rows if row["freeze_status"] == "PROMOTED"]
    held_open = [row for row in freeze_rows if row["freeze_status"] == "HELD_OPEN"]
    blocked = [row for row in freeze_rows if row["freeze_status"] == "BLOCKED"]
    top_promoted = promoted[0] if promoted else {}

    if promoted and not blocked:
        result_class = "QP037_PARTICLE_IDENTITY_FREEZE_ONE_PROMOTION_HELD_OPEN_REST"
        next_frontier = "QP038_PRIVATE_COMPOSITE_STABILITY_QUANTUM_SPAGHETTIFICATION_BOUNDARY"
        interpretation = "Phase 3 freezes one W/I fixed-point identity and holds the remaining open slots open"
    elif promoted:
        result_class = "QP037_PARTICLE_IDENTITY_FREEZE_PROMOTIONS_WITH_BLOCKED_REST"
        next_frontier = "QP038_PRIVATE_COMPOSITE_STABILITY_QUANTUM_SPAGHETTIFICATION_BOUNDARY"
        interpretation = "Phase 3 freezes promotions and blocked slots"
    else:
        result_class = "QP037_PARTICLE_IDENTITY_FREEZE_NO_PROMOTION"
        next_frontier = "QP038_PRIVATE_IDENTITY_RULE_EXTENSION_SEARCH"
        interpretation = "Phase 3 freezes no particle identity promotion"

    decision_rows = [
        {
            "decision_item": "selected_correction_used_for_freeze",
            "decision_value": selected_id,
            "reason": "freeze uses QP036 selected correction only",
        },
        {
            "decision_item": "promoted_identity_slots",
            "decision_value": len(promoted),
            "reason": "corrected W/I delta at or below QP036 ultra residual",
        },
        {
            "decision_item": "held_open_identity_slots",
            "decision_value": len(held_open),
            "reason": "not promoted under selected local return correction",
        },
        {
            "decision_item": "blocked_identity_slots",
            "decision_value": len(blocked),
            "reason": "no slot is blocked by the freeze; non-promoted slots remain open",
        },
    ]
    schema_rows = [
        {
            "class": result_class,
            "meaning": "Phase 3 particle identity decisions are frozen under the selected local-return correction",
            "status": "selected",
        },
        {
            "class": "LOCAL_RETURN_WI_FIXED_POINT_IDENTITY",
            "meaning": "selected correction brings corrected W/I delta inside ultra residual",
            "status": "reached" if promoted else "not reached",
        },
        {
            "class": next_frontier,
            "meaning": "connect single-slot identity freeze to composite stability and quantum spaghettification",
            "status": "next",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP037 freezes the single unresolved particle identity result; next connects this to many-SW composite stability.",
            "launch_from": "qp037_particle_identity_freeze_table.csv;qp037_summary.json",
            "target_output": "composite stability versus single-particle identity boundary",
        }
    ]

    summary = {
        "artifact": "QP037_PRIVATE_PARTICLE_IDENTITY_CLOSURE_FREEZE",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_QUANTUM_PHASE_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp035/qp035_fixed_point_selector_table.csv",
            "artifacts/qp036/qp036_summary.json",
            "artifacts/qp036/qp036_local_return_candidate_table.csv",
            "artifacts/qp036/qp036_slot_application_table.csv",
        ],
        "phase3_campaign": qp036["phase3_campaign"],
        "qp036_result_class": qp036["result_class"],
        "selected_candidate_id": selected_id,
        "selected_candidate_formula": qp036["selected_candidate_formula"],
        "selected_candidate_value": selected_value,
        "selected_candidate_applicable_lane": selected_lane,
        "ultra_residual_threshold": ultra,
        "open_slots_tested": len(freeze_rows),
        "promoted_identity_slots": len(promoted),
        "held_open_identity_slots": len(held_open),
        "blocked_identity_slots": len(blocked),
        "promoted_slots": ";".join(str(row["suk055_pair"]) for row in promoted),
        "held_open_slots": ";".join(str(row["suk055_pair"]) for row in held_open),
        "top_promoted_slot": top_promoted.get("suk055_pair", ""),
        "top_promoted_lane": top_promoted.get("derived_replay_lane", ""),
        "top_promoted_corrected_WI_delta": top_promoted.get("corrected_WI_delta", ""),
        "top_promoted_corrected_delta_in_ultra_units": top_promoted.get("corrected_delta_in_ultra_units", ""),
        "top_promoted_identity_class": top_promoted.get("freeze_class", ""),
        "strong_held_open_slots": sum(1 for row in held_open if str(row["freeze_class"]).startswith("STRONG")),
        "moderate_held_open_slots": sum(1 for row in held_open if str(row["freeze_class"]).startswith("MODERATE")),
        "weak_held_open_slots": sum(1 for row in held_open if str(row["freeze_class"]).startswith("WEAK")),
        "freeze_rule": "use only QP036 selected correction; promote only corrected W/I contact inside ultra residual",
        "interpretation": interpretation,
        "next_frontier": next_frontier,
    }

    fields = [
        "QP037_rank",
        "suk055_pair",
        "oriented_symbols",
        "charge_class",
        "derived_replay_lane",
        "W_slot",
        "I_return_slot",
        "direct_WI_delta",
        "direct_delta_in_ultra_units",
        "WI_self_support_score",
        "selected_correction_applicable",
        "selected_correction_used",
        "selected_correction_value",
        "corrected_WI_delta",
        "corrected_delta_in_ultra_units",
        "freeze_status",
        "freeze_class",
        "qp036_selected_application_rank",
    ]
    write_csv(FREEZE_OUT, freeze_rows, fields)
    write_csv(PROMOTION_OUT, promoted, fields)
    write_csv(HELD_OPEN_OUT, held_open, fields)
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, freeze_rows)

    print(result_class)
    print(f"selected_correction={selected_id}")
    print(f"promoted_identity_slots={len(promoted)}")
    print(f"promoted_slots={summary['promoted_slots']}")
    print(f"held_open_identity_slots={len(held_open)}")
    print(f"blocked_identity_slots={len(blocked)}")
    print(f"top_promoted_corrected_WI_delta={summary['top_promoted_corrected_WI_delta']}")
    print(f"top_promoted_corrected_delta_in_ultra_units={summary['top_promoted_corrected_delta_in_ultra_units']}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
