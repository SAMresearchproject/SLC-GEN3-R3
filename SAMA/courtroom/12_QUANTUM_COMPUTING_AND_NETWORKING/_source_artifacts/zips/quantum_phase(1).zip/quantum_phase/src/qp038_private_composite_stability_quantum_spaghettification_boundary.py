from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PUBLIC_SAM = Path(r"C:\VS\Stam_model-A-v1.0")

ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP037_SUMMARY = ARTIFACTS / "qp037" / "qp037_summary.json"
QP037_FREEZE = ARTIFACTS / "qp037" / "qp037_particle_identity_freeze_table.csv"
QP006_PRIORITY = ARTIFACTS / "qp006" / "qp006_heavy_composite_slot_priority_table.csv"
QP005_SUMMARY = ARTIFACTS / "qp005" / "qp005_native_composite_interaction_strength_summary.json"

QGA038D_SUMMARY = (
    PUBLIC_SAM
    / "tests"
    / "Substrate"
    / "QGA038D_DIFFERENTIAL_A_ROAD_COHERENCE_SHEAR_BREAKUP_SELECTOR"
    / "QGA038D_summary.json"
)
QGA038D_SHEAR = (
    PUBLIC_SAM
    / "tests"
    / "Substrate"
    / "QGA038D_DIFFERENTIAL_A_ROAD_COHERENCE_SHEAR_BREAKUP_SELECTOR"
    / "QGA038D_coherence_shear_table.csv"
)
QGA038E_SUMMARY = (
    PUBLIC_SAM
    / "tests"
    / "Substrate"
    / "QGA038E_A_GRADIENT_COHERENCE_LIMIT_FROM_MASTER_A_ROAD"
    / "QGA038E_summary.json"
)
QGA076_SUMMARY = PUBLIC_SAM / "composites" / "native_binding_resonance_summary.json"
QGA076_LEDGER = PUBLIC_SAM / "composites" / "composite_stability_ledger.csv"

QP038_DIR = ARTIFACTS / "qp038"
PREFLIGHT_OUT = QP038_DIR / "qp038_preflight.md"
SUMMARY_OUT = QP038_DIR / "qp038_summary.json"
BOUNDARY_OUT = QP038_DIR / "qp038_identity_composite_boundary_table.csv"
COHERENCE_OUT = QP038_DIR / "qp038_coherence_gate_table.csv"
COMPOSITE_OUT = QP038_DIR / "qp038_composite_stability_import_table.csv"
DECISION_OUT = QP038_DIR / "qp038_boundary_decision_table.csv"
SCHEMA_OUT = QP038_DIR / "qp038_schema.csv"
NEXT_OUT = QP038_DIR / "qp038_next_frontier.csv"
DOC_OUT = REPORTS / "QP038_PRIVATE_COMPOSITE_STABILITY_QUANTUM_SPAGHETTIFICATION_BOUNDARY.md"

A_SHARE = 1 / 12
FULL_CONTACT_FAILURE = 1.0


def read_json(path: Path) -> dict[str, object]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, object]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, object]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fnum(value: str | float | int | None, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def write_preflight() -> None:
    QP038_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP038 Preflight - Composite Stability / Quantum Spaghettification Boundary

## Mode

```text
FORWARD_MODEL_BUILD
```

## Not Audit / Not Retest

```text
is_audit_or_retest = False
confirmation_or_double_check = False
```

QP038 does not rerun QP037, QGA038D, QGA038E, QGA076, QP005, or QP006. It reads
their existing structured artifacts as downstream inputs and builds the next
boundary rule.

## Selector Inputs

```text
artifacts/qp037/qp037_summary.json
artifacts/qp037/qp037_particle_identity_freeze_table.csv
artifacts/qp006/qp006_heavy_composite_slot_priority_table.csv
artifacts/qp005/qp005_native_composite_interaction_strength_summary.json
C:/VS/Stam_model-A-v1.0/tests/Substrate/QGA038D_DIFFERENTIAL_A_ROAD_COHERENCE_SHEAR_BREAKUP_SELECTOR/QGA038D_summary.json
C:/VS/Stam_model-A-v1.0/tests/Substrate/QGA038D_DIFFERENTIAL_A_ROAD_COHERENCE_SHEAR_BREAKUP_SELECTOR/QGA038D_coherence_shear_table.csv
C:/VS/Stam_model-A-v1.0/tests/Substrate/QGA038E_A_GRADIENT_COHERENCE_LIMIT_FROM_MASTER_A_ROAD/QGA038E_summary.json
C:/VS/Stam_model-A-v1.0/composites/native_binding_resonance_summary.json
C:/VS/Stam_model-A-v1.0/composites/composite_stability_ledger.csv
```

## Boundary Rule

```text
single unresolved identity = QP037 W/I fixed-point promotion
composite support = many-SW native binding / conserved cross-section support
quantum spaghettification = extended massive closure coherence shear
```

The selected A-road shear law remains:

```text
coherence_ratio = beta_rel*d_route*r_s/(r^2 - (L/2)^2)
```

Classification:

```text
coherence_ratio < 1/12      -> COHERENT_SHARED_CLOSURE
1/12 <= coherence_ratio < 1 -> COHERENCE_SHEAR_REORGANIZATION_BOUNDARY
coherence_ratio >= 1        -> BREAKUP_RETARDED_CONTACT_FAILURE
```

No fitted weights are introduced.

## Question

```text
Can the private QP particle-identity freeze be cleanly separated from many-SW
composite stability and from extended-body A-road coherence failure?
```
""",
        encoding="utf-8",
    )


def boundary_status(identity_status: str, priority_class: str, strength_fraction: float) -> tuple[str, str]:
    if identity_status == "PROMOTED" and priority_class.startswith("P3"):
        return (
            "LOCAL_IDENTITY_PROMOTED_COMPOSITE_BINDING_HELD_OPEN",
            "W/I identity closes before many-SW binding reaches A-share scale",
        )
    if identity_status == "PROMOTED":
        return (
            "LOCAL_IDENTITY_PROMOTED_WITH_COMPOSITE_SUPPORT",
            "W/I identity is promoted and composite lane is already A-share scale or stronger",
        )
    if strength_fraction >= 1.0:
        return (
            "COMPOSITE_SUPPORT_WITH_IDENTITY_HELD_OPEN",
            "many-SW binding support is stronger than local identity closure in this table",
        )
    return (
        "IDENTITY_AND_COMPOSITE_HELD_OPEN",
        "neither local W/I identity nor A-share composite binding promotes for this slot",
    )


def coherence_outcome(row: dict[str, str]) -> str:
    classification = row.get("classification", "")
    route_status = row.get("route_status", "")
    if route_status == "NO_COMPLETED_PARENT_LEDGER_CROSSING":
        return "A1_HORIZON_GUARD"
    if classification == "COHERENT_SHARED_CLOSURE":
        return "extended closure remains synchronized"
    if classification == "COHERENCE_SHEAR_REORGANIZATION_BOUNDARY":
        return "extended closure enters reorganization band"
    if classification == "BREAKUP_RETARDED_CONTACT_FAILURE":
        return "extended closure loses shared retarded contact"
    return "unclassified guard row"


def write_doc(
    summary: dict[str, object],
    boundary_rows: list[dict[str, object]],
    coherence_rows: list[dict[str, object]],
    composite_rows: list[dict[str, object]],
) -> None:
    boundary_lines = "\n".join(
        f"| {row['rank']} | {row['suk055_pair']} | {row['identity_status']} | {row['composite_priority_class']} | {row['native_interaction_strength']} | {row['strength_fraction_of_A_SHARE']} | {row['boundary_status']} |"
        for row in boundary_rows
    )
    coherence_lines = "\n".join(
        f"| {row['case_id']} | {row['coherence_ratio']} | {row['base12_landmark']} | {row['classification']} | {row['boundary_role']} |"
        for row in coherence_rows
    )
    composite_lines = "\n".join(
        f"| {row['composite_id']} | {row['symbol']} | {row['branch']} | {row['stability_class']} | {row['qp038_role']} |"
        for row in composite_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP038 - Private Composite Stability / Quantum Spaghettification Boundary

## Result

```text
{summary['result_class']}
```

QP038 separates three lanes that now need to stay distinct:

```text
single unresolved identity -> local W/I fixed-point closure
many-SW composite support -> native binding and conserved cross-section support
extended A-road propagation -> coherence shear / quantum spaghettification
```

## Boundary Table

| rank | slot | identity status | composite priority | native strength | A-share fraction | boundary status |
| ---: | --- | --- | --- | ---: | ---: | --- |
{boundary_lines}

## Coherence Gate

| case | coherence ratio | base-12 landmark | classification | boundary role |
| --- | ---: | --- | --- | --- |
{coherence_lines}

## Composite Import

| composite | symbol | branch | stability class | QP038 role |
| --- | --- | --- | --- | --- |
{composite_lines}

## Key Fields

```text
promoted_identity_slots = {summary['promoted_identity_slots']}
promoted_identity_slots_with_sub_A_share_composite_binding = {summary['promoted_identity_slots_with_sub_A_share_composite_binding']}
qga076_composite_rows_selected = {summary['qga076_composite_rows_selected']}
coherent_shared_closure_rows = {summary['coherent_shared_closure_rows']}
reorganization_boundary_rows = {summary['reorganization_boundary_rows']}
breakup_failure_rows = {summary['breakup_failure_rows']}
massless_route_result = {summary['massless_route_result']}
selected_shear_rule = {summary['selected_shear_rule']}
selected_master_A_rule = {summary['selected_master_A_rule']}
```

## Interpretation

`c<->t` remains the important crossing point. QP037 promotes it as a local W/I
fixed-point identity, while QP006 still classifies the same slot as a sub-A-share
composite scaffold. That is not a conflict. It selects the boundary:

```text
identity closure is local
composite stability is many-SW support
quantum spaghettification is extended-body synchronization failure under A-road propagation
```

The QGA038D/E A-road law then supplies the motion/gradient gate for extended
closures:

```text
coherence_ratio < 1/12      -> coherent shared closure
1/12 <= coherence_ratio < 1 -> reorganization boundary
coherence_ratio >= 1        -> retarded-contact failure
```

## Next Frontier

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    qp037 = read_json(QP037_SUMMARY)
    qp037_rows = read_csv(QP037_FREEZE)
    qp006_rows = read_csv(QP006_PRIORITY)
    qp005 = read_json(QP005_SUMMARY)
    qga038d = read_json(QGA038D_SUMMARY)
    qga038d_rows = read_csv(QGA038D_SHEAR)
    qga038e = read_json(QGA038E_SUMMARY)
    qga076 = read_json(QGA076_SUMMARY)
    qga076_rows = read_csv(QGA076_LEDGER)

    qp006_by_pair = {row["suk055_pair"]: row for row in qp006_rows}
    boundary_rows: list[dict[str, object]] = []
    for row in qp037_rows:
        pair = row["suk055_pair"]
        priority = qp006_by_pair.get(pair, {})
        strength = fnum(priority.get("native_interaction_strength"))
        strength_fraction = strength / A_SHARE if A_SHARE else 0.0
        status, note = boundary_status(
            row["freeze_status"],
            priority.get("priority_class", "NOT_IN_QP006_PRIORITY_TABLE"),
            strength_fraction,
        )
        boundary_rows.append(
            {
                "rank": row["QP037_rank"],
                "suk055_pair": pair,
                "identity_status": row["freeze_status"],
                "identity_class": row["freeze_class"],
                "corrected_WI_delta": row["corrected_WI_delta"],
                "corrected_delta_in_ultra_units": row["corrected_delta_in_ultra_units"],
                "composite_priority_class": priority.get("priority_class", "NOT_IN_QP006_PRIORITY_TABLE"),
                "native_interaction_strength": strength,
                "strength_fraction_of_A_SHARE": strength_fraction,
                "native_closure_class": priority.get("native_closure_class", ""),
                "boundary_status": status,
                "boundary_note": note,
            }
        )

    promoted_identity_rows = [row for row in boundary_rows if row["identity_status"] == "PROMOTED"]
    promoted_sub_a_share_rows = [
        row
        for row in promoted_identity_rows
        if fnum(row["strength_fraction_of_A_SHARE"]) < 1.0
    ]

    coherence_rows: list[dict[str, object]] = []
    for row in qga038d_rows:
        ratio = row.get("coherence_ratio", "")
        coherence_rows.append(
            {
                "case_id": row.get("case_id", ""),
                "body_type": row.get("body_type", ""),
                "beta_rel": row.get("beta_rel", ""),
                "coherence_ratio": ratio,
                "base12_landmark": row.get("base12_landmark", ""),
                "classification": row.get("classification", ""),
                "route_status": row.get("route_status", ""),
                "boundary_role": coherence_outcome(row),
                "note": row.get("note", ""),
            }
        )

    class_counts = Counter(row["classification"] for row in coherence_rows if row["classification"])
    qga076_branch_counts = qga076.get("branch_counts", {})
    composite_rows: list[dict[str, object]] = []
    for row in qga076_rows:
        composite_rows.append(
            {
                "composite_id": row["composite_id"],
                "symbol": row["symbol"],
                "branch": row["branch"],
                "stability_class": row["stability_class"],
                "terminality": row["terminality"],
                "response_support": row["response_support"],
                "mass_readout_status": row["mass_readout_status"],
                "qp038_role": "MANY_SW_COMPOSITE_SUPPORT_IMPORT",
            }
        )

    has_identity_boundary = bool(promoted_identity_rows and promoted_sub_a_share_rows)
    has_composite_inventory = int(qga076["composite_rows_selected"]) > 0
    has_full_shear_ladder = all(
        class_counts.get(cls, 0) > 0
        for cls in [
            "COHERENT_SHARED_CLOSURE",
            "COHERENCE_SHEAR_REORGANIZATION_BOUNDARY",
            "BREAKUP_RETARDED_CONTACT_FAILURE",
        ]
    )
    has_master_a_rule = str(qga038e["selected_rule"]) == "coherence_ratio = beta_rel*d_route*r_s/(r^2 - (L/2)^2)"

    if has_identity_boundary and has_composite_inventory and has_full_shear_ladder and has_master_a_rule:
        result_class = "QP038_COMPOSITE_STABILITY_QUANTUM_SPAGHETTIFICATION_BOUNDARY_SELECTED"
        interpretation = "local W/I identity, many-SW composite support, and extended A-road coherence shear are cleanly separated"
        next_frontier = "QP039_PRIVATE_WI_IDENTITY_TO_COMPOSITE_RETURN_CHANNEL_SELECTOR"
    else:
        result_class = "QP038_BOUNDARY_HELD_OPEN_INCOMPLETE_INPUT_CHAIN"
        interpretation = "the boundary chain is incomplete under available inputs"
        next_frontier = "QP039_PRIVATE_BOUNDARY_INPUT_REPAIR"

    decision_rows = [
        {
            "decision_item": "single_identity_lane",
            "decision_value": qp037["result_class"],
            "reason": "QP037 freezes one local W/I fixed-point identity",
        },
        {
            "decision_item": "identity_vs_composite_boundary",
            "decision_value": "SELECTED" if has_identity_boundary else "HELD_OPEN",
            "reason": "promoted identity slot remains sub-A-share in QP006 composite-strength table",
        },
        {
            "decision_item": "many_SW_composite_lane",
            "decision_value": qga076["verdict"],
            "reason": "QGA076 supplies native composite stability ledger without observed composite masses",
        },
        {
            "decision_item": "extended_A_road_coherence_lane",
            "decision_value": qga038d["verdict"],
            "reason": "QGA038D supplies coherent/reorganization/failure ladder",
        },
        {
            "decision_item": "master_A_shear_formula",
            "decision_value": qga038e["selected_rule"],
            "reason": "QGA038E derives the local A(r)=r_s/r coherence-limit form",
        },
        {
            "decision_item": "massless_guard",
            "decision_value": qga038d["massless_route_result"],
            "reason": "single massless route does not carry extended front/back coherence burden",
        },
    ]

    schema_rows = [
        {
            "class": result_class,
            "meaning": "QP038 selects the boundary between single identity, composite support, and quantum spaghettification",
            "status": "selected" if result_class.endswith("SELECTED") else "held_open",
        },
        {
            "class": "LOCAL_IDENTITY_PROMOTED_COMPOSITE_BINDING_HELD_OPEN",
            "meaning": "a local W/I particle identity can close before many-SW binding reaches A-share scale",
            "status": "reached" if has_identity_boundary else "not_reached",
        },
        {
            "class": "QUANTUM_SPAGHETTIFICATION_GATE",
            "meaning": "extended massive closures must remain synchronized under A-road propagation",
            "status": "available" if has_full_shear_ladder else "incomplete",
        },
        {
            "class": next_frontier,
            "meaning": "ask how the frozen W/I identity participates in composite return channels",
            "status": "next",
        },
    ]

    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP038 separates identity closure from many-SW support; next selects the return channel that lets a frozen identity participate in composite structure.",
            "launch_from": "qp038_identity_composite_boundary_table.csv;qp038_summary.json",
            "target_output": "W/I identity to composite return-channel selector",
        }
    ]

    summary = {
        "artifact": "QP038_PRIVATE_COMPOSITE_STABILITY_QUANTUM_SPAGHETTIFICATION_BOUNDARY",
        "result_class": result_class,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_E_DRIVE_READS_PUBLIC_SAM_STRUCTURED_ARTIFACTS_DOWNSTREAM",
        "test_type": "FORWARD_MODEL_BUILD",
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp037/qp037_summary.json",
            "artifacts/qp037/qp037_particle_identity_freeze_table.csv",
            "artifacts/qp006/qp006_heavy_composite_slot_priority_table.csv",
            "artifacts/qp005/qp005_native_composite_interaction_strength_summary.json",
            str(QGA038D_SUMMARY),
            str(QGA038D_SHEAR),
            str(QGA038E_SUMMARY),
            str(QGA076_SUMMARY),
            str(QGA076_LEDGER),
        ],
        "phase3_campaign": "SAM_QP032_QP0XX_PHASE3_WI_CLOSURE_PARTICLE_IDENTITY_CAMPAIGN",
        "qp037_result_class": qp037["result_class"],
        "promoted_identity_slots": int(qp037["promoted_identity_slots"]),
        "promoted_identity_slot_list": qp037["promoted_slots"],
        "promoted_identity_slots_with_sub_A_share_composite_binding": len(promoted_sub_a_share_rows),
        "top_boundary_slot": promoted_sub_a_share_rows[0]["suk055_pair"] if promoted_sub_a_share_rows else "",
        "top_boundary_identity_class": promoted_sub_a_share_rows[0]["identity_class"] if promoted_sub_a_share_rows else "",
        "top_boundary_composite_priority": promoted_sub_a_share_rows[0]["composite_priority_class"] if promoted_sub_a_share_rows else "",
        "top_boundary_native_strength": promoted_sub_a_share_rows[0]["native_interaction_strength"] if promoted_sub_a_share_rows else "",
        "top_boundary_strength_fraction_of_A_SHARE": promoted_sub_a_share_rows[0]["strength_fraction_of_A_SHARE"] if promoted_sub_a_share_rows else "",
        "qp005_law": qp005["law"],
        "qp006_open_slots_joined": len(boundary_rows),
        "qga076_result_class": qga076["verdict"],
        "qga076_composite_rows_selected": qga076["composite_rows_selected"],
        "qga076_branch_counts": qga076_branch_counts,
        "qga076_observed_composite_masses_used": qga076["observed_composite_masses_used"],
        "qga038d_result_class": qga038d["verdict"],
        "qga038e_result_class": qga038e["verdict"],
        "selected_shear_rule": qga038d["selected_rule"],
        "selected_master_A_rule": qga038e["selected_rule"],
        "first_reorganization_ratio": qga038e["first_reorganization_ratio"],
        "full_contact_failure_ratio": qga038e["full_contact_failure_ratio"],
        "coherent_shared_closure_rows": class_counts.get("COHERENT_SHARED_CLOSURE", 0),
        "reorganization_boundary_rows": class_counts.get("COHERENCE_SHEAR_REORGANIZATION_BOUNDARY", 0),
        "breakup_failure_rows": class_counts.get("BREAKUP_RETARDED_CONTACT_FAILURE", 0),
        "horizon_guard_rows": sum(1 for row in coherence_rows if row["route_status"] == "NO_COMPLETED_PARENT_LEDGER_CROSSING"),
        "massless_route_result": qga038d["massless_route_result"],
        "massive_route_result": qga038d["massive_route_result"],
        "boundary_rule": "single identity is local W/I fixed point; composite support is many-SW binding; quantum spaghettification is extended A-road coherence shear",
        "interpretation": interpretation,
        "next_frontier": next_frontier,
    }

    boundary_fields = [
        "rank",
        "suk055_pair",
        "identity_status",
        "identity_class",
        "corrected_WI_delta",
        "corrected_delta_in_ultra_units",
        "composite_priority_class",
        "native_interaction_strength",
        "strength_fraction_of_A_SHARE",
        "native_closure_class",
        "boundary_status",
        "boundary_note",
    ]
    coherence_fields = [
        "case_id",
        "body_type",
        "beta_rel",
        "coherence_ratio",
        "base12_landmark",
        "classification",
        "route_status",
        "boundary_role",
        "note",
    ]
    composite_fields = [
        "composite_id",
        "symbol",
        "branch",
        "stability_class",
        "terminality",
        "response_support",
        "mass_readout_status",
        "qp038_role",
    ]
    write_csv(BOUNDARY_OUT, boundary_rows, boundary_fields)
    write_csv(COHERENCE_OUT, coherence_rows, coherence_fields)
    write_csv(COMPOSITE_OUT, composite_rows, composite_fields)
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, boundary_rows, coherence_rows, composite_rows)

    print(result_class)
    print(f"top_boundary_slot={summary['top_boundary_slot']}")
    print(f"top_boundary_identity_class={summary['top_boundary_identity_class']}")
    print(f"top_boundary_composite_priority={summary['top_boundary_composite_priority']}")
    print(f"top_boundary_strength_fraction_of_A_SHARE={summary['top_boundary_strength_fraction_of_A_SHARE']}")
    print(f"coherent_shared_closure_rows={summary['coherent_shared_closure_rows']}")
    print(f"reorganization_boundary_rows={summary['reorganization_boundary_rows']}")
    print(f"breakup_failure_rows={summary['breakup_failure_rows']}")
    print(f"qga076_composite_rows_selected={summary['qga076_composite_rows_selected']}")
    print(f"next={next_frontier}")


if __name__ == "__main__":
    main()
