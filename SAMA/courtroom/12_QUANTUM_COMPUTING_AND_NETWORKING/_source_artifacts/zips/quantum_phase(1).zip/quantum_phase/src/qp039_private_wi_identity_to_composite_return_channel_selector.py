from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]

ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

QP037_FREEZE = ARTIFACTS / "qp037" / "qp037_particle_identity_freeze_table.csv"
QP038_SUMMARY = ARTIFACTS / "qp038" / "qp038_summary.json"
QP038_BOUNDARY = ARTIFACTS / "qp038" / "qp038_identity_composite_boundary_table.csv"
QP006_PRIORITY = ARTIFACTS / "qp006" / "qp006_heavy_composite_slot_priority_table.csv"
COMPOSITE_SUPPORT = PHASE4 / "phase4_composite_support_table.csv"
COMPOSITE_SCAFFOLDS = PHASE4 / "phase4_composite_scaffold_table.csv"
BLANK_REGISTRY = PHASE4 / "phase4_blank_registry.csv"

QP039_DIR = ARTIFACTS / "qp039"
PREFLIGHT_OUT = QP039_DIR / "qp039_preflight.md"
SUMMARY_OUT = QP039_DIR / "qp039_summary.json"
RETURN_CHANNEL_OUT = QP039_DIR / "qp039_return_channel_table.csv"
SCAFFOLD_JOIN_OUT = QP039_DIR / "qp039_scaffold_join_table.csv"
SUPPORT_CHANNEL_OUT = QP039_DIR / "qp039_composite_support_channel_table.csv"
COMPOSITE_QUEUE_OUT = QP039_DIR / "qp039_composite_role_queue_table.csv"
BLANK_DELTA_OUT = QP039_DIR / "qp039_blank_delta_table.csv"
DECISION_OUT = QP039_DIR / "qp039_decision_table.csv"
NEXT_OUT = QP039_DIR / "qp039_next_frontier.csv"
SCHEMA_OUT = QP039_DIR / "qp039_schema.csv"
DOC_OUT = REPORTS / "QP039_PRIVATE_WI_IDENTITY_TO_COMPOSITE_RETURN_CHANNEL_SELECTOR.md"

A_SHARE = 1.0 / 12.0


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fnum(value: str | float | int | None, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def pair_parts(pair: str) -> tuple[str, str]:
    left, right = pair.split("<->")
    return left.strip(), right.strip()


def oriented_scaffold_ids(pair: str) -> tuple[str, str]:
    left, right = pair_parts(pair)
    return f"{left}_anti_{right}", f"{right}_anti_{left}"


def support_channel_class(row: dict[str, str]) -> str:
    branch = row.get("branch", "")
    confinement = row.get("confinement_status", "")
    if branch == "meson" and "Q_ANTI_Q" in confinement:
        return "MANY_SW_Q_ANTI_Q_RETURN_CHANNEL_SUPPORT"
    if branch == "baryon" and "BARYON_COLOR_SINGLET" in confinement:
        return "MANY_SW_QQQ_COLOR_SINGLET_RETURN_CHANNEL_SUPPORT"
    if branch == "nuclear_composite":
        return "SECOND_ORDER_COMPOSITE_RETURN_CHANNEL_SUPPORT"
    return "COMPOSITE_SUPPORT_CHANNEL_UNCLASSIFIED"


def return_channel_status(
    identity_row: dict[str, str],
    boundary_row: dict[str, str],
    scaffold_a_present: bool,
    scaffold_b_present: bool,
) -> tuple[str, str]:
    promoted_identity = (
        identity_row.get("freeze_status") == "PROMOTED"
        and identity_row.get("freeze_class") == "LOCAL_RETURN_WI_FIXED_POINT_IDENTITY"
    )
    boundary_selected = (
        boundary_row.get("boundary_status")
        == "LOCAL_IDENTITY_PROMOTED_COMPOSITE_BINDING_HELD_OPEN"
    )
    scaffold_present = scaffold_a_present and scaffold_b_present
    sub_a_share = fnum(boundary_row.get("strength_fraction_of_A_SHARE")) < 1.0
    p3_scaffold = boundary_row.get("composite_priority_class") == "P3_SCAFFOLD_HELD_OPEN"

    if promoted_identity and boundary_selected and scaffold_present and sub_a_share and p3_scaffold:
        return (
            "FILLED_LOCAL_WI_TO_COMPOSITE_RETURN_CHANNEL",
            "local W/I identity is promoted; both q anti-q orientations exist; many-SW binding remains sub-A-share, so the row is a bridge not a mass readout",
        )
    if promoted_identity and not scaffold_present:
        return (
            "BOUNDARY_SCAFFOLD_ORIENTATION_MISSING",
            "local W/I identity promotes, but both composite scaffold orientations are not present",
        )
    if promoted_identity and not sub_a_share:
        return (
            "BOUNDARY_ALREADY_COMPOSITE_SCALE",
            "local W/I identity promotes, but native strength is already A-share scale or stronger",
        )
    if scaffold_present:
        return (
            "SCAFFOLD_PRESENT_LOCAL_RETURN_NOT_SELECTED",
            "the composite scaffold exists, but local W/I identity is not promoted for this row",
        )
    return (
        "OPEN_NO_SELECTED_RETURN_CHANNEL",
        "neither local W/I promotion nor complete composite scaffold orientation is selected",
    )


def write_preflight() -> None:
    QP039_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP039 Preflight - W/I Identity to Composite Return Channel Selector

```text
test_id = QP039
test_name = PRIVATE_WI_IDENTITY_TO_COMPOSITE_RETURN_CHANNEL_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp037/qp037_particle_identity_freeze_table.csv
artifacts/qp038/qp038_summary.json
artifacts/qp038/qp038_identity_composite_boundary_table.csv
artifacts/qp006/qp006_heavy_composite_slot_priority_table.csv
phase4_tables/phase4_composite_support_table.csv
phase4_tables/phase4_composite_scaffold_table.csv
phase4_tables/phase4_blank_registry.csv
```

## Expected Outputs

```text
artifacts/qp039/qp039_summary.json
artifacts/qp039/qp039_return_channel_table.csv
artifacts/qp039/qp039_scaffold_join_table.csv
artifacts/qp039/qp039_composite_support_channel_table.csv
artifacts/qp039/qp039_composite_role_queue_table.csv
artifacts/qp039/qp039_blank_delta_table.csv
docs/reports/QP039_PRIVATE_WI_IDENTITY_TO_COMPOSITE_RETURN_CHANNEL_SELECTOR.md
```

## Forward Question

```text
How does a frozen local W/I identity become a many-SW composite return channel?
```

## Selector Rule

A return channel is selected only when:

```text
local W/I identity is PROMOTED
identity class = LOCAL_RETURN_WI_FIXED_POINT_IDENTITY
QP038 boundary status = LOCAL_IDENTITY_PROMOTED_COMPOSITE_BINDING_HELD_OPEN
both q anti-q scaffold orientations exist in the Phase 4 scaffold table
native composite strength remains below A-share
composite priority class remains P3_SCAFFOLD_HELD_OPEN
```

This fills a bridge blank. It does not emit a composite mass readout.
""",
        encoding="utf-8",
    )


def write_doc(
    summary: dict[str, Any],
    return_rows: list[dict[str, Any]],
    support_rows: list[dict[str, Any]],
    queue_rows: list[dict[str, Any]],
    blank_delta_rows: list[dict[str, Any]],
) -> None:
    selected_lines = "\n".join(
        f"| {row['return_channel_id']} | {row['suk055_pair']} | {row['oriented_scaffolds']} | {row['identity_status']} | {row['strength_fraction_of_A_SHARE']} | {row['return_channel_status']} |"
        for row in return_rows
    )
    support_lines = "\n".join(
        f"| {row['composite_id']} | {row['symbol']} | {row['branch']} | {row['return_channel_class']} | {row['mass_readout_status']} |"
        for row in support_rows
    )
    queue_lines = "\n".join(
        f"| {row['queue_rank']} | {row['suk055_pair']} | {row['priority_class']} | {row['native_interaction_strength']} | {row['queue_status']} |"
        for row in queue_rows
    )
    blank_lines = "\n".join(
        f"| {row['blank_group']} | {row['before_status']} | {row['after_status']} | {row['delta_note']} |"
        for row in blank_delta_rows
    )

    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP039 - Private W/I Identity to Composite Return Channel Selector

## Preflight

```text
test_id = QP039
test_name = PRIVATE_WI_IDENTITY_TO_COMPOSITE_RETURN_CHANNEL_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP039 fills the Phase 4 return-channel blank by selecting the bridge:

```text
local W/I fixed-point identity -> q anti-q composite scaffold orientation
```

It does not claim a composite mass readout. The mass-readout question moves to
QP040.

## Selected Return Channel

| return channel | slot | scaffold orientations | identity status | A-share fraction | status |
| --- | --- | --- | --- | ---: | --- |
{selected_lines}

## Composite Support Channels

| composite | symbol | branch | return-channel class | mass readout status |
| --- | --- | --- | --- | --- |
{support_lines}

## Composite Role Queue for QP040

| rank | slot | priority class | native strength | queue status |
| ---: | --- | --- | ---: | --- |
{queue_lines}

## Blank Delta

| blank group | before | after | note |
| --- | --- | --- | --- |
{blank_lines}

## Key Fields

```text
selected_return_channels = {summary['selected_return_channels']}
scaffold_join_rows = {summary['scaffold_join_rows']}
composite_support_channel_rows = {summary['composite_support_channel_rows']}
composite_role_queue_rows = {summary['composite_role_queue_rows']}
free_parameters_introduced = {summary['free_parameters_introduced']}
external_data_used = {summary['external_data_used']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

The selected row is a bridge, not a shortcut. It says a promoted local W/I
identity can participate in a composite scaffold when both oriented q anti-q
slots already exist, while the many-SW binding side remains below A-share.

That is exactly the QP038 separation:

```text
single identity closure != many-SW composite support != extended A-road shear
```

## Next Move

```text
{summary['next_frontier']}
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    qp037_rows = read_csv(QP037_FREEZE)
    qp038 = read_json(QP038_SUMMARY)
    boundary_rows = read_csv(QP038_BOUNDARY)
    priority_rows = read_csv(QP006_PRIORITY)
    support_rows_in = read_csv(COMPOSITE_SUPPORT)
    scaffold_rows = read_csv(COMPOSITE_SCAFFOLDS)
    blank_rows = read_csv(BLANK_REGISTRY)

    boundary_by_pair = {row["suk055_pair"]: row for row in boundary_rows}
    priority_by_pair = {row["suk055_pair"]: row for row in priority_rows}
    scaffold_ids = {row["scaffold_id"] for row in scaffold_rows}

    scaffold_join_rows: list[dict[str, Any]] = []
    return_rows: list[dict[str, Any]] = []
    for row in qp037_rows:
        pair = row["suk055_pair"]
        scaffold_a, scaffold_b = oriented_scaffold_ids(pair)
        boundary = boundary_by_pair.get(pair, {})
        priority = priority_by_pair.get(pair, {})
        scaffold_a_present = scaffold_a in scaffold_ids
        scaffold_b_present = scaffold_b in scaffold_ids
        status, note = return_channel_status(
            row,
            boundary,
            scaffold_a_present,
            scaffold_b_present,
        )
        join_row = {
            "rank": row["QP037_rank"],
            "suk055_pair": pair,
            "oriented_scaffolds": f"{scaffold_a};{scaffold_b}",
            "scaffold_a_present": scaffold_a_present,
            "scaffold_b_present": scaffold_b_present,
            "identity_status": row["freeze_status"],
            "identity_class": row["freeze_class"],
            "charge_class": row["charge_class"],
            "corrected_WI_delta": row["corrected_WI_delta"],
            "corrected_delta_in_ultra_units": row["corrected_delta_in_ultra_units"],
            "WI_self_support_score": row["WI_self_support_score"],
            "boundary_status": boundary.get("boundary_status", ""),
            "composite_priority_class": priority.get("priority_class", ""),
            "native_interaction_strength": priority.get("native_interaction_strength", ""),
            "strength_fraction_of_A_SHARE": priority.get("strength_fraction_of_A_SHARE", ""),
            "return_channel_status": status,
            "return_channel_note": note,
        }
        scaffold_join_rows.append(join_row)
        if status == "FILLED_LOCAL_WI_TO_COMPOSITE_RETURN_CHANNEL":
            return_rows.append(
                {
                    "return_channel_id": f"QP039-RC-{len(return_rows) + 1:03d}",
                    "suk055_pair": pair,
                    "oriented_scaffolds": f"{scaffold_a};{scaffold_b}",
                    "return_channel_class": "LOCAL_WI_FIXED_POINT_TO_Q_ANTI_Q_SCAFFOLD_RETURN_CHANNEL",
                    "identity_status": row["freeze_status"],
                    "identity_class": row["freeze_class"],
                    "charge_class": row["charge_class"],
                    "corrected_WI_delta": row["corrected_WI_delta"],
                    "corrected_delta_in_ultra_units": row["corrected_delta_in_ultra_units"],
                    "WI_self_support_score": row["WI_self_support_score"],
                    "native_interaction_strength": boundary.get("native_interaction_strength", ""),
                    "strength_fraction_of_A_SHARE": boundary.get("strength_fraction_of_A_SHARE", ""),
                    "composite_priority_class": boundary.get("composite_priority_class", ""),
                    "mass_readout_status": "NO_MASS_READOUT_QP040_REQUIRED",
                    "return_channel_status": status,
                    "next_selector": "QP040_PRIVATE_NATIVE_BINDING_RESIDUE_OPERATOR",
                    "note": note,
                }
            )

    support_channel_rows: list[dict[str, Any]] = []
    for row in support_rows_in:
        support_channel_rows.append(
            {
                "composite_id": row["composite_id"],
                "symbol": row["symbol"],
                "branch": row["branch"],
                "constituents": row["constituents"],
                "stability_class": row["stability_class"],
                "confinement_status": row["confinement_status"],
                "resonance_status": row["resonance_status"],
                "mass_readout_status": row["mass_readout_status"],
                "return_channel_class": support_channel_class(row),
                "phase4_status": row["phase4_status"],
                "source": row["source"],
            }
        )

    queue_rows: list[dict[str, Any]] = []
    for row in priority_rows:
        priority_class = row["priority_class"]
        if priority_class.startswith("P1") or priority_class.startswith("P2"):
            queue_status = "QP040_HIGH_PRIORITY_COMPOSITE_ROLE_QUEUE"
        elif row["suk055_pair"] in {r["suk055_pair"] for r in return_rows}:
            queue_status = "QP039_RETURN_CHANNEL_SELECTED_QP040_BINDING_OPEN"
        else:
            queue_status = "QP040_BOUNDARY_QUEUE_HELD_AFTER_RETURN_SELECTOR"
        queue_rows.append(
            {
                "queue_rank": row["priority_rank"],
                "suk055_pair": row["suk055_pair"],
                "oriented_slot_ids": row["oriented_slot_ids"],
                "charge_class": row["charge_class"],
                "priority_class": priority_class,
                "phase_role_operator": row["phase_role_operator"],
                "native_interaction_strength": row["native_interaction_strength"],
                "native_closure_class": row["native_closure_class"],
                "interaction_mass_coordinate_MeV": row["interaction_mass_coordinate_MeV"],
                "queue_status": queue_status,
                "next_selector": "QP040_PRIVATE_NATIVE_BINDING_RESIDUE_OPERATOR",
            }
        )

    blank_before = {
        row["blank_group"]: row
        for row in blank_rows
    }
    return_blank = blank_before.get("QP039_return_channel", {})
    return_filled = len(return_rows) > 0
    blank_delta_rows = [
        {
            "blank_group": "QP039_return_channel",
            "before_status": return_blank.get("current_status", "NEXT_PHASE4_SELECTOR"),
            "after_status": "FILLED_BY_QP039" if return_filled else "HELD_OPEN_AFTER_QP039",
            "selector_used": "QP039_PRIVATE_WI_IDENTITY_TO_COMPOSITE_RETURN_CHANNEL_SELECTOR",
            "delta_note": "one local W/I fixed-point identity selected as q anti-q composite return channel"
            if return_filled
            else "no local W/I fixed-point identity satisfied all return-channel gates",
        },
        {
            "blank_group": "meson_scaffold_mass_readouts",
            "before_status": blank_before.get("meson_scaffold_mass_readouts", {}).get("current_status", "OPEN_PHASE4"),
            "after_status": "QP040_READY",
            "selector_used": "QP039 bridge only; QP040 still required",
            "delta_note": "return-channel bridge is available, but mass readout remains a separate binding-residue problem",
        },
        {
            "blank_group": "baryon_scaffold_mass_readouts",
            "before_status": blank_before.get("baryon_scaffold_mass_readouts", {}).get("current_status", "OPEN_PHASE4"),
            "after_status": "QP040_READY",
            "selector_used": "QP039 bridge only; QP040 still required",
            "delta_note": "baryon support remains many-SW binding; no baryon mass rows are promoted by QP039 alone",
        },
    ]

    status_counts = Counter(row["return_channel_status"] for row in scaffold_join_rows)
    support_counts = Counter(row["return_channel_class"] for row in support_channel_rows)
    queue_counts = Counter(row["queue_status"] for row in queue_rows)

    if return_filled and qp038.get("result_class") == "QP038_COMPOSITE_STABILITY_QUANTUM_SPAGHETTIFICATION_BOUNDARY_SELECTED":
        result_class = "QP039_RETURN_CHANNEL_BRIDGE_SELECTED"
        next_frontier = "QP040_PRIVATE_NATIVE_BINDING_RESIDUE_OPERATOR"
        campaign_status = "QP039_FILLED_RETURN_CHANNEL_QP040_READY"
    else:
        result_class = "QP039_RETURN_CHANNEL_HELD_OPEN"
        next_frontier = "QP039B_RETURN_CHANNEL_INPUT_REPAIR"
        campaign_status = "QP039_HELD_OPEN"

    decision_rows = [
        {
            "decision_item": "preflight",
            "decision_value": "PASS_FORWARD_MODEL_BUILD",
            "reason": "new forward selector; not audit, not retest, no public write",
        },
        {
            "decision_item": "qp038_boundary_available",
            "decision_value": qp038.get("result_class", ""),
            "reason": "QP039 requires local identity/composite/A-road separation from QP038",
        },
        {
            "decision_item": "return_channel_blank",
            "decision_value": "FILLED" if return_filled else "HELD_OPEN",
            "reason": "selected channels satisfying all W/I-to-composite bridge gates",
        },
        {
            "decision_item": "mass_readout",
            "decision_value": "NOT_EMITTED",
            "reason": "QP039 fills bridge only; QP040 selects binding residue operator",
        },
    ]

    schema_rows = [
        {
            "class": "FILLED_LOCAL_WI_TO_COMPOSITE_RETURN_CHANNEL",
            "meaning": "promoted local W/I identity has both q anti-q scaffold orientations and remains sub-A-share as composite",
            "status": "selected" if return_filled else "not_reached",
        },
        {
            "class": "SCAFFOLD_PRESENT_LOCAL_RETURN_NOT_SELECTED",
            "meaning": "composite scaffold exists, but local W/I identity does not promote",
            "status": "used",
        },
        {
            "class": "MANY_SW_Q_ANTI_Q_RETURN_CHANNEL_SUPPORT",
            "meaning": "filled composite support rows with q anti-q confinement act as meson return-channel support",
            "status": "available",
        },
        {
            "class": "MANY_SW_QQQ_COLOR_SINGLET_RETURN_CHANNEL_SUPPORT",
            "meaning": "filled baryon support rows act through color-singlet many-SW support",
            "status": "available",
        },
    ]

    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP039 fills the W/I-to-composite bridge but deliberately does not emit composite masses; QP040 must select the binding residue operator.",
            "launch_from": "qp039_return_channel_table.csv;qp039_composite_support_channel_table.csv;qp039_composite_role_queue_table.csv",
            "target_output": "native binding residue operator for meson and baryon scaffold fill passes",
        }
    ]

    summary = {
        "artifact": "QP039_PRIVATE_WI_IDENTITY_TO_COMPOSITE_RETURN_CHANNEL_SELECTOR",
        "result_class": result_class,
        "campaign_status": campaign_status,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp037/qp037_particle_identity_freeze_table.csv",
            "artifacts/qp038/qp038_summary.json",
            "artifacts/qp038/qp038_identity_composite_boundary_table.csv",
            "artifacts/qp006/qp006_heavy_composite_slot_priority_table.csv",
            "phase4_tables/phase4_composite_support_table.csv",
            "phase4_tables/phase4_composite_scaffold_table.csv",
            "phase4_tables/phase4_blank_registry.csv",
        ],
        "qp038_result_class": qp038.get("result_class", ""),
        "selected_return_channels": len(return_rows),
        "selected_return_channel_ids": ";".join(row["return_channel_id"] for row in return_rows),
        "selected_return_channel_pairs": ";".join(row["suk055_pair"] for row in return_rows),
        "scaffold_join_rows": len(scaffold_join_rows),
        "return_channel_status_counts": dict(status_counts),
        "composite_support_channel_rows": len(support_channel_rows),
        "support_channel_class_counts": dict(support_counts),
        "composite_role_queue_rows": len(queue_rows),
        "composite_role_queue_counts": dict(queue_counts),
        "blank_delta_rows": len(blank_delta_rows),
        "QP039_return_channel_after_status": "FILLED_BY_QP039" if return_filled else "HELD_OPEN_AFTER_QP039",
        "mass_readout_emitted": False,
        "next_frontier": next_frontier,
        "interpretation": "QP039 fills the bridge from local W/I identity to q anti-q composite return channel while preserving the QP038 separation from mass readout and A-road shear.",
    }

    QP039_DIR.mkdir(parents=True, exist_ok=True)
    write_csv(
        SCAFFOLD_JOIN_OUT,
        scaffold_join_rows,
        [
            "rank",
            "suk055_pair",
            "oriented_scaffolds",
            "scaffold_a_present",
            "scaffold_b_present",
            "identity_status",
            "identity_class",
            "charge_class",
            "corrected_WI_delta",
            "corrected_delta_in_ultra_units",
            "WI_self_support_score",
            "boundary_status",
            "composite_priority_class",
            "native_interaction_strength",
            "strength_fraction_of_A_SHARE",
            "return_channel_status",
            "return_channel_note",
        ],
    )
    write_csv(
        RETURN_CHANNEL_OUT,
        return_rows,
        [
            "return_channel_id",
            "suk055_pair",
            "oriented_scaffolds",
            "return_channel_class",
            "identity_status",
            "identity_class",
            "charge_class",
            "corrected_WI_delta",
            "corrected_delta_in_ultra_units",
            "WI_self_support_score",
            "native_interaction_strength",
            "strength_fraction_of_A_SHARE",
            "composite_priority_class",
            "mass_readout_status",
            "return_channel_status",
            "next_selector",
            "note",
        ],
    )
    write_csv(
        SUPPORT_CHANNEL_OUT,
        support_channel_rows,
        [
            "composite_id",
            "symbol",
            "branch",
            "constituents",
            "stability_class",
            "confinement_status",
            "resonance_status",
            "mass_readout_status",
            "return_channel_class",
            "phase4_status",
            "source",
        ],
    )
    write_csv(
        COMPOSITE_QUEUE_OUT,
        queue_rows,
        [
            "queue_rank",
            "suk055_pair",
            "oriented_slot_ids",
            "charge_class",
            "priority_class",
            "phase_role_operator",
            "native_interaction_strength",
            "native_closure_class",
            "interaction_mass_coordinate_MeV",
            "queue_status",
            "next_selector",
        ],
    )
    write_csv(
        BLANK_DELTA_OUT,
        blank_delta_rows,
        ["blank_group", "before_status", "after_status", "selector_used", "delta_note"],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, return_rows, support_channel_rows, queue_rows, blank_delta_rows)

    print(summary["artifact"])
    print(f"result_class={summary['result_class']}")
    print(f"selected_return_channels={summary['selected_return_channels']}")
    print(f"QP039_return_channel_after_status={summary['QP039_return_channel_after_status']}")
    print(f"next_frontier={summary['next_frontier']}")


if __name__ == "__main__":
    main()
