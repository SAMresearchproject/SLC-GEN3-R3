from __future__ import annotations

import csv
import json
import math
import re
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]

ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

QP039_SUMMARY = ARTIFACTS / "qp039" / "qp039_summary.json"
QP039_RETURN = ARTIFACTS / "qp039" / "qp039_return_channel_table.csv"
QP039_SUPPORT = ARTIFACTS / "qp039" / "qp039_composite_support_channel_table.csv"
QP039_QUEUE = ARTIFACTS / "qp039" / "qp039_composite_role_queue_table.csv"
COMPOSITE_SUPPORT = PHASE4 / "phase4_composite_support_table.csv"

QP040_DIR = ARTIFACTS / "qp040"
PREFLIGHT_OUT = QP040_DIR / "qp040_preflight.md"
SUMMARY_OUT = QP040_DIR / "qp040_summary.json"
OPERATOR_OUT = QP040_DIR / "qp040_binding_residue_operator_table.csv"
REPLAY_OUT = QP040_DIR / "qp040_support_row_replay_without_observed_mass.csv"
CLASS_SUMMARY_OUT = QP040_DIR / "qp040_residue_class_summary.csv"
HANDOFF_OUT = QP040_DIR / "qp040_scaffold_fill_handoff_table.csv"
DECISION_OUT = QP040_DIR / "qp040_decision_table.csv"
NEXT_OUT = QP040_DIR / "qp040_next_frontier.csv"
SCHEMA_OUT = QP040_DIR / "qp040_schema.csv"
DOC_OUT = REPORTS / "QP040_PRIVATE_NATIVE_BINDING_RESIDUE_OPERATOR.md"


FORMULA_FIELDS = ["k", "N0", "shift", "q", "A0", "A0/2", "D", "B", "slot_den", "M_lambda", "MeV_to_kg"]


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fnum(value: str | float | int | None, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def parse_formula(formula: str) -> dict[str, float]:
    values: dict[str, float] = {}
    for field in FORMULA_FIELDS:
        escaped = re.escape(field)
        match = re.search(rf"(?:^|;\s*){escaped}=([-+0-9.eE]+)", formula)
        if match:
            values[field] = float(match.group(1))
    return values


def residue_class(q: int) -> str:
    if q > 0:
        return "POSITIVE_Q_RETURN_SUPPRESSION"
    if q < 0:
        return "NEGATIVE_Q_RETURN_AMPLIFICATION"
    return "NEUTRAL_Q_RETURN"


def branch_operator_class(branch: str, q: int) -> str:
    prefix = {
        "meson": "Q_ANTI_Q",
        "baryon": "QQQ_COLOR_SINGLET",
        "nuclear_composite": "NUCLEAR_COMPOSITE_CLUSTER",
    }.get(branch, "COMPOSITE")
    return f"{prefix}_{residue_class(q)}"


def write_preflight() -> None:
    QP040_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP040 Preflight - Native Binding Residue Operator

```text
test_id = QP040
test_name = PRIVATE_NATIVE_BINDING_RESIDUE_OPERATOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp039/qp039_summary.json
artifacts/qp039/qp039_return_channel_table.csv
artifacts/qp039/qp039_composite_support_channel_table.csv
artifacts/qp039/qp039_composite_role_queue_table.csv
phase4_tables/phase4_composite_support_table.csv
```

## Expected Outputs

```text
artifacts/qp040/qp040_summary.json
artifacts/qp040/qp040_binding_residue_operator_table.csv
artifacts/qp040/qp040_support_row_replay_without_observed_mass.csv
artifacts/qp040/qp040_scaffold_fill_handoff_table.csv
docs/reports/QP040_PRIVATE_NATIVE_BINDING_RESIDUE_OPERATOR.md
```

## Forward Question

```text
Given a composite scaffold and its constituent SAM masses, what native residue
or return deficit determines whether a bound composite mass readout exists?
```

## Operator Candidate

```text
R_bind(q, D) = 1 / (1 + (A0/2) * q / 2^D)
```

This gate extracts and freezes the common operator form from the selected native
support formulas. It does not use observed composite masses.
""",
        encoding="utf-8",
    )


def write_doc(
    summary: dict[str, Any],
    operator_rows: list[dict[str, Any]],
    replay_rows: list[dict[str, Any]],
    handoff_rows: list[dict[str, Any]],
) -> None:
    operator_lines = "\n".join(
        f"| {row['composite_id']} | {row['branch']} | {row['q']} | {row['residue_operator']} | {row['operator_class']} | {row['operator_status']} |"
        for row in operator_rows
    )
    replay_lines = "\n".join(
        f"| {row['composite_id']} | {row['native_mass_replay_MeV']} | {row['source_sam_mass_MeV']} | {row['absolute_replay_delta_MeV']} | {row['replay_status']} |"
        for row in replay_rows
    )
    handoff_lines = "\n".join(
        f"| {row['handoff_target']} | {row['branch']} | {row['input_rows']} | {row['ready_status']} |"
        for row in handoff_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP040 - Private Native Binding Residue Operator

## Preflight

```text
test_id = QP040
test_name = PRIVATE_NATIVE_BINDING_RESIDUE_OPERATOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP040 selects the common native binding residue operator:

```text
{summary['selected_operator']}
```

The operator is extracted from the selected native support formulas only. No
observed composite masses are used.

## Operator Table

| composite | branch | q | R_bind | operator class | status |
| --- | --- | ---: | ---: | --- | --- |
{operator_lines}

## Native Replay Without Observed Masses

| composite | replay mass / MeV | source SAM mass / MeV | delta / MeV | status |
| --- | ---: | ---: | ---: | --- |
{replay_lines}

## Handoff

| target | branch | input rows | status |
| --- | --- | ---: | --- |
{handoff_lines}

## Key Fields

```text
operator_rows = {summary['operator_rows']}
support_rows_replayed = {summary['support_rows_replayed']}
replay_pass_rows = {summary['replay_pass_rows']}
observed_composite_masses_used = {summary['observed_composite_masses_used']}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

QP039 supplied the return-channel bridge. QP040 supplies the binding residue
operator that the scaffold-fill passes need:

```text
mass readout = native role scale * R_bind(q, D)
```

The next gates can now ask which meson and baryon scaffolds receive a unique
readout, instead of treating the scaffold table as decorative inventory.
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    qp039 = read_json(QP039_SUMMARY)
    qp039_return = read_csv(QP039_RETURN)
    qp039_support = read_csv(QP039_SUPPORT)
    qp039_queue = read_csv(QP039_QUEUE)
    support_rows = read_csv(COMPOSITE_SUPPORT)

    operator_rows: list[dict[str, Any]] = []
    replay_rows: list[dict[str, Any]] = []
    for row in support_rows:
        values = parse_formula(row["formula"])
        missing = [field for field in FORMULA_FIELDS if field not in values]
        q = int(values.get("q", 0.0))
        d = int(values.get("D", 0.0))
        a_side = values.get("A0/2", 0.0)
        residue_denominator = 1.0 + a_side * q / (2.0**d)
        residue_operator = 1.0 / residue_denominator
        role_scale = values.get("k", 0.0) / (2.0 ** (values.get("N0", 0.0) + values.get("shift", 0.0)))
        native_mass_replay = (
            (values.get("A0", 0.0) ** 2)
            * role_scale
            * residue_operator
            * values.get("M_lambda", 0.0)
            / values.get("MeV_to_kg", 1.0)
        )
        source_sam_mass = fnum(row["sam_mass_MeV"])
        replay_delta = abs(native_mass_replay - source_sam_mass)
        replay_rel_delta = replay_delta / source_sam_mass if source_sam_mass else 0.0
        replay_status = "PASS_NATIVE_FORMULA_REPLAY" if replay_rel_delta < 1e-10 and not missing else "BOUNDARY_REPLAY_MISMATCH"
        operator_status = "FILLED_NATIVE_BINDING_RESIDUE_OPERATOR" if not missing else "BOUNDARY_FORMULA_FIELDS_MISSING"
        operator_rows.append(
            {
                "composite_id": row["composite_id"],
                "symbol": row["symbol"],
                "branch": row["branch"],
                "constituents": row["constituents"],
                "k": int(values.get("k", 0.0)),
                "N0": int(values.get("N0", 0.0)),
                "shift": int(values.get("shift", 0.0)),
                "q": q,
                "D": d,
                "A0": values.get("A0", ""),
                "A_SIDE": a_side,
                "residue_denominator": residue_denominator,
                "residue_operator": residue_operator,
                "role_scale": role_scale,
                "operator_class": branch_operator_class(row["branch"], q),
                "operator_status": operator_status,
                "free_parameters_used": row["free_parameters_used"],
                "observed_mass_used": False,
            }
        )
        replay_rows.append(
            {
                "composite_id": row["composite_id"],
                "symbol": row["symbol"],
                "native_mass_replay_MeV": native_mass_replay,
                "source_sam_mass_MeV": source_sam_mass,
                "absolute_replay_delta_MeV": replay_delta,
                "relative_replay_delta": replay_rel_delta,
                "replay_status": replay_status,
                "observed_mass_used": False,
                "formula_fields_missing": ";".join(missing),
            }
        )

    class_counts = Counter(row["operator_class"] for row in operator_rows)
    status_counts = Counter(row["operator_status"] for row in operator_rows)
    replay_counts = Counter(row["replay_status"] for row in replay_rows)

    support_branch_counts = Counter(row["branch"] for row in support_rows)
    queue_status_counts = Counter(row["queue_status"] for row in qp039_queue)
    handoff_rows = [
        {
            "handoff_target": "QP041_PRIVATE_MESON_SCAFFOLD_FILL_PASS",
            "branch": "meson",
            "input_rows": support_branch_counts.get("meson", 0),
            "ready_status": "READY_WITH_NATIVE_BINDING_RESIDUE_OPERATOR",
            "source": "qp040_binding_residue_operator_table.csv",
        },
        {
            "handoff_target": "QP042_PRIVATE_BARYON_SCAFFOLD_FILL_PASS",
            "branch": "baryon",
            "input_rows": support_branch_counts.get("baryon", 0),
            "ready_status": "READY_WITH_NATIVE_BINDING_RESIDUE_OPERATOR",
            "source": "qp040_binding_residue_operator_table.csv",
        },
        {
            "handoff_target": "QP043_PRIVATE_UNKNOWN_MODE_CARRIER_ASSIGNMENT",
            "branch": "unknown_mode",
            "input_rows": queue_status_counts.get("QP040_HIGH_PRIORITY_COMPOSITE_ROLE_QUEUE", 0)
            + queue_status_counts.get("QP039_RETURN_CHANNEL_SELECTED_QP040_BINDING_OPEN", 0),
            "ready_status": "WAIT_FOR_QP041_QP042_FILL_RESULTS",
            "source": "qp040_scaffold_fill_handoff_table.csv",
        },
    ]

    all_operator_rows_filled = all(
        row["operator_status"] == "FILLED_NATIVE_BINDING_RESIDUE_OPERATOR"
        for row in operator_rows
    )
    all_replay_pass = all(row["replay_status"] == "PASS_NATIVE_FORMULA_REPLAY" for row in replay_rows)
    no_free_params = all(str(row["free_parameters_used"]) == "0" for row in support_rows)
    qp039_ready = qp039.get("result_class") == "QP039_RETURN_CHANNEL_BRIDGE_SELECTED"

    if qp039_ready and all_operator_rows_filled and all_replay_pass and no_free_params:
        result_class = "QP040_NATIVE_BINDING_RESIDUE_OPERATOR_SELECTED"
        campaign_status = "QP040_OPERATOR_SELECTED_QP041_QP042_READY"
        next_frontier = "QP041_PRIVATE_MESON_SCAFFOLD_FILL_PASS"
    else:
        result_class = "QP040_NATIVE_BINDING_RESIDUE_OPERATOR_HELD_OPEN"
        campaign_status = "QP040_HELD_OPEN"
        next_frontier = "QP040B_OPERATOR_INPUT_REPAIR"

    selected_operator = "R_bind(q,D)=1/(1+(A0/2)*q/2^D)"
    decision_rows = [
        {
            "decision_item": "preflight",
            "decision_value": "PASS_FORWARD_MODEL_BUILD",
            "reason": "new operator extraction; not audit, not retest, no public write",
        },
        {
            "decision_item": "qp039_bridge",
            "decision_value": qp039.get("result_class", ""),
            "reason": "QP040 requires QP039 return-channel bridge",
        },
        {
            "decision_item": "operator_form",
            "decision_value": selected_operator,
            "reason": "all selected support formulas share the same q/D residue denominator",
        },
        {
            "decision_item": "observed_mass_input",
            "decision_value": "NOT_USED",
            "reason": "QP040 parses native support formulas and source SAM masses only",
        },
    ]
    schema_rows = [
        {
            "class": "FILLED_NATIVE_BINDING_RESIDUE_OPERATOR",
            "meaning": "selected support row uses the common native residue denominator",
            "status": "selected" if all_operator_rows_filled else "held_open",
        },
        {
            "class": "POSITIVE_Q_RETURN_SUPPRESSION",
            "meaning": "q positive increases denominator and suppresses return readout",
            "status": "available",
        },
        {
            "class": "NEGATIVE_Q_RETURN_AMPLIFICATION",
            "meaning": "q negative decreases denominator and amplifies return readout",
            "status": "available",
        },
        {
            "class": "NEUTRAL_Q_RETURN",
            "meaning": "q zero leaves native role scale unshifted by residue denominator",
            "status": "available",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP040 selected the binding residue operator; QP041 can now apply it to meson scaffold fills.",
            "launch_from": "qp040_binding_residue_operator_table.csv;qp040_scaffold_fill_handoff_table.csv",
            "target_output": "meson scaffold fill table",
        }
    ]
    class_summary_rows = [
        {"operator_class": key, "count": value}
        for key, value in sorted(class_counts.items())
    ]

    summary = {
        "artifact": "QP040_PRIVATE_NATIVE_BINDING_RESIDUE_OPERATOR",
        "result_class": result_class,
        "campaign_status": campaign_status,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_composite_masses_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp039/qp039_summary.json",
            "artifacts/qp039/qp039_return_channel_table.csv",
            "artifacts/qp039/qp039_composite_support_channel_table.csv",
            "artifacts/qp039/qp039_composite_role_queue_table.csv",
            "phase4_tables/phase4_composite_support_table.csv",
        ],
        "qp039_result_class": qp039.get("result_class", ""),
        "selected_operator": selected_operator,
        "operator_rows": len(operator_rows),
        "operator_status_counts": dict(status_counts),
        "operator_class_counts": dict(class_counts),
        "support_rows_replayed": len(replay_rows),
        "replay_status_counts": dict(replay_counts),
        "replay_pass_rows": replay_counts.get("PASS_NATIVE_FORMULA_REPLAY", 0),
        "handoff_rows": len(handoff_rows),
        "meson_support_rows_ready": support_branch_counts.get("meson", 0),
        "baryon_support_rows_ready": support_branch_counts.get("baryon", 0),
        "composite_role_queue_rows": len(qp039_queue),
        "high_priority_queue_rows": queue_status_counts.get("QP040_HIGH_PRIORITY_COMPOSITE_ROLE_QUEUE", 0),
        "return_channel_queue_rows": queue_status_counts.get("QP039_RETURN_CHANNEL_SELECTED_QP040_BINDING_OPEN", 0),
        "next_frontier": next_frontier,
        "interpretation": "QP040 selects the common native binding residue operator needed for meson and baryon scaffold fill passes.",
    }

    QP040_DIR.mkdir(parents=True, exist_ok=True)
    write_csv(
        OPERATOR_OUT,
        operator_rows,
        [
            "composite_id",
            "symbol",
            "branch",
            "constituents",
            "k",
            "N0",
            "shift",
            "q",
            "D",
            "A0",
            "A_SIDE",
            "residue_denominator",
            "residue_operator",
            "role_scale",
            "operator_class",
            "operator_status",
            "free_parameters_used",
            "observed_mass_used",
        ],
    )
    write_csv(
        REPLAY_OUT,
        replay_rows,
        [
            "composite_id",
            "symbol",
            "native_mass_replay_MeV",
            "source_sam_mass_MeV",
            "absolute_replay_delta_MeV",
            "relative_replay_delta",
            "replay_status",
            "observed_mass_used",
            "formula_fields_missing",
        ],
    )
    write_csv(CLASS_SUMMARY_OUT, class_summary_rows, ["operator_class", "count"])
    write_csv(HANDOFF_OUT, handoff_rows, ["handoff_target", "branch", "input_rows", "ready_status", "source"])
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, operator_rows, replay_rows, handoff_rows)

    print(summary["artifact"])
    print(f"result_class={summary['result_class']}")
    print(f"selected_operator={summary['selected_operator']}")
    print(f"operator_rows={summary['operator_rows']}")
    print(f"replay_pass_rows={summary['replay_pass_rows']}")
    print(f"next_frontier={summary['next_frontier']}")


if __name__ == "__main__":
    main()
