from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]

ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

QP040_SUMMARY = ARTIFACTS / "qp040" / "qp040_summary.json"
QP040_OPERATOR = ARTIFACTS / "qp040" / "qp040_binding_residue_operator_table.csv"
QP039_QUEUE = ARTIFACTS / "qp039" / "qp039_composite_role_queue_table.csv"
COMPOSITE_SUPPORT = PHASE4 / "phase4_composite_support_table.csv"
COMPOSITE_SCAFFOLDS = PHASE4 / "phase4_composite_scaffold_table.csv"

QP041_DIR = ARTIFACTS / "qp041"
PREFLIGHT_OUT = QP041_DIR / "qp041_preflight.md"
SUMMARY_OUT = QP041_DIR / "qp041_summary.json"
MESON_FILL_OUT = QP041_DIR / "qp041_meson_fill_table.csv"
MESON_BOUNDARY_OUT = QP041_DIR / "qp041_meson_open_boundary_table.csv"
MESON_FAMILY_OUT = QP041_DIR / "qp041_meson_family_fill_map.csv"
DECISION_OUT = QP041_DIR / "qp041_decision_table.csv"
NEXT_OUT = QP041_DIR / "qp041_next_frontier.csv"
SCHEMA_OUT = QP041_DIR / "qp041_schema.csv"
DOC_OUT = REPORTS / "QP041_PRIVATE_MESON_SCAFFOLD_FILL_PASS.md"


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def meson_scaffold_from_constituents(constituents: str) -> tuple[str, str | None]:
    left, right = constituents.split(";")
    if right.startswith("anti_"):
        anti = right.replace("anti_", "", 1)
    elif right.startswith("anti-"):
        anti = right.replace("anti-", "", 1)
    else:
        anti = right
    primary = f"{left}_anti_{anti}"
    conjugate = None if left == anti else f"{anti}_anti_{left}"
    return primary, conjugate


def parse_pair_scaffolds(oriented_slot_ids: str) -> list[str]:
    return [item.strip() for item in oriented_slot_ids.split(";") if item.strip()]


def write_preflight() -> None:
    QP041_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP041 Preflight - Meson Scaffold Fill Pass

```text
test_id = QP041
test_name = PRIVATE_MESON_SCAFFOLD_FILL_PASS
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp040/qp040_summary.json
artifacts/qp040/qp040_binding_residue_operator_table.csv
artifacts/qp039/qp039_composite_role_queue_table.csv
phase4_tables/phase4_composite_support_table.csv
phase4_tables/phase4_composite_scaffold_table.csv
```

## Expected Outputs

```text
artifacts/qp041/qp041_summary.json
artifacts/qp041/qp041_meson_fill_table.csv
artifacts/qp041/qp041_meson_open_boundary_table.csv
artifacts/qp041/qp041_meson_family_fill_map.csv
docs/reports/QP041_PRIVATE_MESON_SCAFFOLD_FILL_PASS.md
```

## Forward Question

```text
Which of the 36 q anti-q meson scaffold slots receive a unique native mass
readout from QP039 and QP040?
```

Rows are filled only from selected native composite support families and the
QP040 binding-residue operator. Observed meson masses are not used.
""",
        encoding="utf-8",
    )


def write_doc(
    summary: dict[str, Any],
    fill_rows: list[dict[str, Any]],
    boundary_rows: list[dict[str, Any]],
    family_rows: list[dict[str, Any]],
) -> None:
    fill_lines = "\n".join(
        f"| {row['scaffold_id']} | {row['support_family']} | {row['symbol']} | {row['sam_mass_MeV']} | {row['fill_status']} |"
        for row in fill_rows
    )
    boundary_lines = "\n".join(
        f"| {row['scaffold_id']} | {row['charge']} | {row['boundary_class']} | {row['selector_needed']} |"
        for row in boundary_rows
    )
    family_lines = "\n".join(
        f"| {row['support_family']} | {row['symbol']} | {row['filled_scaffolds']} | {row['operator_class']} |"
        for row in family_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP041 - Private Meson Scaffold Fill Pass

## Preflight

```text
test_id = QP041
test_name = PRIVATE_MESON_SCAFFOLD_FILL_PASS
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP041 fills the meson scaffolds that have a selected native support family and
the QP040 binding-residue operator.

## Filled Meson Rows

| scaffold | family | symbol | SAM mass / MeV | status |
| --- | --- | --- | ---: | --- |
{fill_lines}

## Family Map

| family | symbol | filled scaffolds | operator class |
| --- | --- | --- | --- |
{family_lines}

## Open Boundaries

| scaffold | charge | boundary class | selector needed |
| --- | ---: | --- | --- |
{boundary_lines}

## Key Fields

```text
meson_scaffold_rows = {summary['meson_scaffold_rows']}
filled_meson_scaffold_rows = {summary['filled_meson_scaffold_rows']}
candidate_meson_scaffold_rows = {summary['candidate_meson_scaffold_rows']}
open_boundary_rows = {summary['open_boundary_rows']}
observed_meson_masses_used = {summary['observed_meson_masses_used']}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

The meson table now has a real first fill layer. The filled rows are not inferred
from external observed meson masses; they are Phase 4 scaffolds reached by the
selected support families and the QP040 residue operator.

Rows that remain open now name the missing selector: either a role-scale
readout selector for queued heavy mesons, a return-channel binding selector, or
a neutral self-channel selector.
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    qp040 = read_json(QP040_SUMMARY)
    operator_rows = read_csv(QP040_OPERATOR)
    queue_rows = read_csv(QP039_QUEUE)
    support_rows = read_csv(COMPOSITE_SUPPORT)
    scaffold_rows = [
        row
        for row in read_csv(COMPOSITE_SCAFFOLDS)
        if row["scaffold_type"] == "MESON_Q_ANTI_Q"
    ]

    operator_by_family = {row["composite_id"]: row for row in operator_rows}
    scaffold_by_id = {row["scaffold_id"]: row for row in scaffold_rows}

    fill_by_scaffold: dict[str, dict[str, Any]] = {}
    family_rows: list[dict[str, Any]] = []
    for support in support_rows:
        if support["branch"] != "meson":
            continue
        primary, conjugate = meson_scaffold_from_constituents(support["constituents"])
        fill_ids = [primary]
        if conjugate:
            fill_ids.append(conjugate)
        operator = operator_by_family.get(support["composite_id"], {})
        reached = [scaffold_id for scaffold_id in fill_ids if scaffold_id in scaffold_by_id]
        for scaffold_id in reached:
            scaffold = scaffold_by_id[scaffold_id]
            fill_by_scaffold[scaffold_id] = {
                "scaffold_id": scaffold_id,
                "constituents": scaffold["constituents"],
                "charge": scaffold["charge"],
                "support_family": support["composite_id"],
                "symbol": support["symbol"],
                "sam_mass_MeV": support["sam_mass_MeV"],
                "constituent_sum_MeV": support["constituent_sum_MeV"],
                "operator_class": operator.get("operator_class", ""),
                "residue_operator": operator.get("residue_operator", ""),
                "formula": support["formula"],
                "fill_status": "FILLED_NATIVE_MESON_READOUT",
                "observed_mass_used": False,
                "free_parameters_used": support["free_parameters_used"],
                "source": "QP040_NATIVE_BINDING_RESIDUE_OPERATOR_SELECTED",
            }
        family_rows.append(
            {
                "support_family": support["composite_id"],
                "symbol": support["symbol"],
                "support_constituents": support["constituents"],
                "filled_scaffolds": ";".join(reached),
                "filled_count": len(reached),
                "operator_class": operator.get("operator_class", ""),
                "residue_operator": operator.get("residue_operator", ""),
                "sam_mass_MeV": support["sam_mass_MeV"],
            }
        )

    queue_scaffolds: dict[str, dict[str, str]] = {}
    for row in queue_rows:
        for scaffold_id in parse_pair_scaffolds(row["oriented_slot_ids"]):
            queue_scaffolds[scaffold_id] = row

    fill_rows = [fill_by_scaffold[key] for key in sorted(fill_by_scaffold)]
    boundary_rows: list[dict[str, Any]] = []
    for scaffold in scaffold_rows:
        scaffold_id = scaffold["scaffold_id"]
        if scaffold_id in fill_by_scaffold:
            continue
        queue = queue_scaffolds.get(scaffold_id)
        if queue and queue["queue_status"] == "QP040_HIGH_PRIORITY_COMPOSITE_ROLE_QUEUE":
            boundary_class = "CANDIDATE_MESON_READOUT_ROLE_SCALE_SELECTOR_NEEDED"
            selector_needed = "QP041B_ROLE_SCALE_FOR_HIGH_PRIORITY_MESON_QUEUE"
        elif queue and queue["queue_status"] == "QP039_RETURN_CHANNEL_SELECTED_QP040_BINDING_OPEN":
            boundary_class = "CANDIDATE_RETURN_CHANNEL_BINDING_SELECTOR_NEEDED"
            selector_needed = "QP041C_RETURN_CHANNEL_BINDING_SCALE_SELECTOR"
        elif queue:
            boundary_class = "BOUNDARY_LOCAL_RETURN_NOT_SELECTED"
            selector_needed = "LOCAL_WI_RETURN_SELECTOR_OR_ROLE_SCALE_SELECTOR"
        elif scaffold["charge"] == "0":
            boundary_class = "BOUNDARY_NEUTRAL_SELF_CHANNEL_SELECTOR_NEEDED"
            selector_needed = "NEUTRAL_SELF_CHANNEL_ROLE_SCALE_SELECTOR"
        else:
            boundary_class = "OPEN_PHASE4_MESON_SELECTOR_NEEDED"
            selector_needed = "MESON_ROLE_SCALE_AND_RETURN_CHANNEL_SELECTOR"
        boundary_rows.append(
            {
                "scaffold_id": scaffold_id,
                "constituents": scaffold["constituents"],
                "charge": scaffold["charge"],
                "identity_status": scaffold["identity_status"],
                "mass_status": scaffold["mass_status"],
                "boundary_class": boundary_class,
                "selector_needed": selector_needed,
                "phase4_status": "OPEN_PHASE4_BOUNDARY_AFTER_QP041",
            }
        )

    boundary_counts = Counter(row["boundary_class"] for row in boundary_rows)
    fill_count = len(fill_rows)
    candidate_count = sum(
        1
        for row in boundary_rows
        if row["boundary_class"].startswith("CANDIDATE")
    )
    open_count = len(boundary_rows)
    if qp040.get("result_class") == "QP040_NATIVE_BINDING_RESIDUE_OPERATOR_SELECTED" and fill_count > 0:
        result_class = "QP041_MESON_SCAFFOLD_FIRST_FILL_SELECTED"
        campaign_status = "QP041_MESON_FILL_SELECTED_QP042_NEXT"
        next_frontier = "QP042_PRIVATE_BARYON_SCAFFOLD_FILL_PASS"
    else:
        result_class = "QP041_MESON_SCAFFOLD_FILL_HELD_OPEN"
        campaign_status = "QP041_HELD_OPEN"
        next_frontier = "QP041B_MESON_INPUT_REPAIR"

    decision_rows = [
        {
            "decision_item": "preflight",
            "decision_value": "PASS_FORWARD_MODEL_BUILD",
            "reason": "new scaffold fill pass; not audit, not retest, no public write",
        },
        {
            "decision_item": "qp040_operator",
            "decision_value": qp040.get("result_class", ""),
            "reason": "QP041 requires the native binding residue operator",
        },
        {
            "decision_item": "meson_fill",
            "decision_value": f"{fill_count}_ROWS_FILLED",
            "reason": "selected meson support families map onto Phase 4 q anti-q scaffolds",
        },
        {
            "decision_item": "observed_mass_input",
            "decision_value": "NOT_USED",
            "reason": "QP041 uses selected SAM-native support masses and operator rows only",
        },
    ]
    schema_rows = [
        {
            "class": "FILLED_NATIVE_MESON_READOUT",
            "meaning": "meson scaffold receives a selected native support-family mass readout",
            "status": "selected",
        },
        {
            "class": "CANDIDATE_MESON_READOUT_ROLE_SCALE_SELECTOR_NEEDED",
            "meaning": "high-priority composite role queue exists, but unique role scale is not selected",
            "status": "boundary",
        },
        {
            "class": "CANDIDATE_RETURN_CHANNEL_BINDING_SELECTOR_NEEDED",
            "meaning": "QP039 return channel exists, but binding scale is still open",
            "status": "boundary",
        },
        {
            "class": "BOUNDARY_NEUTRAL_SELF_CHANNEL_SELECTOR_NEEDED",
            "meaning": "neutral same-flavor q anti-q scaffold needs self-channel selector",
            "status": "boundary",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP041 filled the selected meson support layer; QP042 should run the same native separation on baryon qqq scaffolds.",
            "launch_from": "qp041_meson_fill_table.csv;qp041_meson_open_boundary_table.csv",
            "target_output": "baryon scaffold fill table",
        }
    ]
    summary = {
        "artifact": "QP041_PRIVATE_MESON_SCAFFOLD_FILL_PASS",
        "result_class": result_class,
        "campaign_status": campaign_status,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_meson_masses_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp040/qp040_summary.json",
            "artifacts/qp040/qp040_binding_residue_operator_table.csv",
            "artifacts/qp039/qp039_composite_role_queue_table.csv",
            "phase4_tables/phase4_composite_support_table.csv",
            "phase4_tables/phase4_composite_scaffold_table.csv",
        ],
        "qp040_result_class": qp040.get("result_class", ""),
        "meson_scaffold_rows": len(scaffold_rows),
        "filled_meson_scaffold_rows": fill_count,
        "filled_meson_support_families": len(family_rows),
        "filled_meson_scaffold_ids": ";".join(row["scaffold_id"] for row in fill_rows),
        "candidate_meson_scaffold_rows": candidate_count,
        "open_boundary_rows": open_count,
        "boundary_class_counts": dict(boundary_counts),
        "next_frontier": next_frontier,
        "interpretation": "QP041 fills exact selected meson support-family scaffolds and converts the remaining meson table blanks into typed selector boundaries.",
    }

    QP041_DIR.mkdir(parents=True, exist_ok=True)
    write_csv(
        MESON_FILL_OUT,
        fill_rows,
        [
            "scaffold_id",
            "constituents",
            "charge",
            "support_family",
            "symbol",
            "sam_mass_MeV",
            "constituent_sum_MeV",
            "operator_class",
            "residue_operator",
            "formula",
            "fill_status",
            "observed_mass_used",
            "free_parameters_used",
            "source",
        ],
    )
    write_csv(
        MESON_BOUNDARY_OUT,
        boundary_rows,
        [
            "scaffold_id",
            "constituents",
            "charge",
            "identity_status",
            "mass_status",
            "boundary_class",
            "selector_needed",
            "phase4_status",
        ],
    )
    write_csv(
        MESON_FAMILY_OUT,
        family_rows,
        [
            "support_family",
            "symbol",
            "support_constituents",
            "filled_scaffolds",
            "filled_count",
            "operator_class",
            "residue_operator",
            "sam_mass_MeV",
        ],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, fill_rows, boundary_rows, family_rows)

    print(summary["artifact"])
    print(f"result_class={summary['result_class']}")
    print(f"filled_meson_scaffold_rows={summary['filled_meson_scaffold_rows']}")
    print(f"candidate_meson_scaffold_rows={summary['candidate_meson_scaffold_rows']}")
    print(f"open_boundary_rows={summary['open_boundary_rows']}")
    print(f"next_frontier={summary['next_frontier']}")


if __name__ == "__main__":
    main()
