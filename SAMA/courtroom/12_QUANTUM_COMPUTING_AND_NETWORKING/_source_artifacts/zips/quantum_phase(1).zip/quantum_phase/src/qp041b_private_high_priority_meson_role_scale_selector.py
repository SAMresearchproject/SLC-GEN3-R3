from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]

ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

QP005_SUMMARY = ARTIFACTS / "qp005" / "qp005_native_composite_interaction_strength_summary.json"
QP005_STRENGTH = ARTIFACTS / "qp005" / "qp005_native_composite_interaction_strength_table.csv"
QP039_QUEUE = ARTIFACTS / "qp039" / "qp039_composite_role_queue_table.csv"
QP040_SUMMARY = ARTIFACTS / "qp040" / "qp040_summary.json"
QP041_SUMMARY = ARTIFACTS / "qp041" / "qp041_summary.json"
QP041_BOUNDARY = ARTIFACTS / "qp041" / "qp041_meson_open_boundary_table.csv"
COMPOSITE_SCAFFOLDS = PHASE4 / "phase4_composite_scaffold_table.csv"

QP041B_DIR = ARTIFACTS / "qp041b"
PREFLIGHT_OUT = QP041B_DIR / "qp041b_preflight.md"
SUMMARY_OUT = QP041B_DIR / "qp041b_summary.json"
ROLE_SCALE_OUT = QP041B_DIR / "qp041b_high_priority_meson_role_scale_table.csv"
PAIR_OUT = QP041B_DIR / "qp041b_pair_role_scale_selector_table.csv"
BOUNDARY_DELTA_OUT = QP041B_DIR / "qp041b_meson_boundary_delta_table.csv"
DECISION_OUT = QP041B_DIR / "qp041b_decision_table.csv"
NEXT_OUT = QP041B_DIR / "qp041b_next_frontier.csv"
SCHEMA_OUT = QP041B_DIR / "qp041b_schema.csv"
DOC_OUT = REPORTS / "QP041B_PRIVATE_HIGH_PRIORITY_MESON_ROLE_SCALE_SELECTOR.md"

A_SHARE = 1.0 / 12.0
WRITE_MIDPOINT = 0.5


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fnum(value: str | float | int | None, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def split_slots(oriented_slot_ids: str) -> list[str]:
    return [item.strip() for item in oriented_slot_ids.split(";") if item.strip()]


def role_scale_status(priority_class: str, closure_class: str, strength: float) -> tuple[str, str]:
    if priority_class == "P1_ROLE_LOCK_FIRST" and strength >= WRITE_MIDPOINT:
        return (
            "FILLED_NATIVE_MESON_ROLE_SCALE_LOCK",
            "write-midpoint role lock selects a native interaction mass coordinate",
        )
    if priority_class == "P2_A_SHARE_ROLE_CANDIDATE" and strength >= A_SHARE:
        return (
            "FILLED_NATIVE_MESON_A_SHARE_ROLE_SCALE_COORDINATE",
            "A-share-scale closure selects a native interaction mass coordinate, with final binding residue still downstream",
        )
    if "A_SHARE" in closure_class and strength >= A_SHARE:
        return (
            "FILLED_NATIVE_MESON_A_SHARE_ROLE_SCALE_COORDINATE",
            "A-share closure class selects a native interaction mass coordinate",
        )
    return (
        "BOUNDARY_ROLE_SCALE_NOT_SELECTED",
        "native strength does not cross the role-scale selector used by QP041B",
    )


def write_preflight() -> None:
    QP041B_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP041B Preflight - High-Priority Meson Role-Scale Selector

```text
test_id = QP041B
test_name = PRIVATE_HIGH_PRIORITY_MESON_ROLE_SCALE_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp005/qp005_native_composite_interaction_strength_summary.json
artifacts/qp005/qp005_native_composite_interaction_strength_table.csv
artifacts/qp039/qp039_composite_role_queue_table.csv
artifacts/qp040/qp040_summary.json
artifacts/qp041/qp041_summary.json
artifacts/qp041/qp041_meson_open_boundary_table.csv
phase4_tables/phase4_composite_scaffold_table.csv
```

## Expected Outputs

```text
artifacts/qp041b/qp041b_summary.json
artifacts/qp041b/qp041b_high_priority_meson_role_scale_table.csv
artifacts/qp041b/qp041b_pair_role_scale_selector_table.csv
artifacts/qp041b/qp041b_meson_boundary_delta_table.csv
docs/reports/QP041B_PRIVATE_HIGH_PRIORITY_MESON_ROLE_SCALE_SELECTOR.md
```

## Forward Question

```text
Can the QP005 native interaction mass coordinate fill the QP041 high-priority
meson role-scale blanks without using observed meson masses?
```

This gate can fill role-scale coordinates. It does not claim final bound meson
mass readouts unless a binding residue/readout selector is also selected.
""",
        encoding="utf-8",
    )


def write_doc(
    summary: dict[str, Any],
    role_rows: list[dict[str, Any]],
    pair_rows: list[dict[str, Any]],
    boundary_delta_rows: list[dict[str, Any]],
) -> None:
    role_lines = "\n".join(
        f"| {row['scaffold_id']} | {row['suk055_pair']} | {row['role_coordinate_MeV']} | {row['phase_role_operator']} | {row['role_scale_status']} |"
        for row in role_rows
    )
    pair_lines = "\n".join(
        f"| {row['suk055_pair']} | {row['priority_class']} | {row['native_interaction_strength']} | {row['interaction_mass_coordinate_MeV']} | {row['pair_selector_status']} |"
        for row in pair_rows
    )
    delta_lines = "\n".join(
        f"| {row['boundary_group']} | {row['before_count']} | {row['after_count']} | {row['delta_note']} |"
        for row in boundary_delta_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP041B - Private High-Priority Meson Role-Scale Selector

## Preflight

```text
test_id = QP041B
test_name = PRIVATE_HIGH_PRIORITY_MESON_ROLE_SCALE_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP041B selects native role-scale coordinates for high-priority meson scaffolds
using the QP005 interaction mass coordinate:

```text
M_role = native_interaction_strength * (m_a + m_b)
```

This is not a final bound-meson mass claim. It fills the role-scale layer and
hands final binding/readout to QP041C.

## Filled Role-Scale Rows

| scaffold | pair | role coordinate / MeV | role operator | status |
| --- | --- | ---: | --- | --- |
{role_lines}

## Pair Selector Table

| pair | priority | native strength | interaction coordinate / MeV | status |
| --- | --- | ---: | ---: | --- |
{pair_lines}

## Boundary Delta

| boundary group | before | after | note |
| --- | ---: | ---: | --- |
{delta_lines}

## Key Fields

```text
high_priority_pairs = {summary['high_priority_pairs']}
filled_role_scale_pairs = {summary['filled_role_scale_pairs']}
filled_role_scale_rows = {summary['filled_role_scale_rows']}
final_bound_mass_rows_emitted = {summary['final_bound_mass_rows_emitted']}
observed_meson_masses_used = {summary['observed_meson_masses_used']}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

QP041B advances the meson table one layer deeper. The eight high-priority
candidate scaffolds are no longer generic blanks; they now carry native role
coordinates and wait only for the final binding/readout selector.
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    qp005 = read_json(QP005_SUMMARY)
    qp040 = read_json(QP040_SUMMARY)
    qp041 = read_json(QP041_SUMMARY)
    strength_rows = read_csv(QP005_STRENGTH)
    queue_rows = read_csv(QP039_QUEUE)
    boundary_rows = read_csv(QP041_BOUNDARY)
    scaffold_rows = {
        row["scaffold_id"]: row
        for row in read_csv(COMPOSITE_SCAFFOLDS)
        if row["scaffold_type"] == "MESON_Q_ANTI_Q"
    }

    strength_by_pair = {row["suk055_pair"]: row for row in strength_rows}
    boundary_by_scaffold = {row["scaffold_id"]: row for row in boundary_rows}
    high_priority_queue = [
        row
        for row in queue_rows
        if row["queue_status"] == "QP040_HIGH_PRIORITY_COMPOSITE_ROLE_QUEUE"
    ]

    pair_rows: list[dict[str, Any]] = []
    role_rows: list[dict[str, Any]] = []
    for queue in high_priority_queue:
        pair = queue["suk055_pair"]
        strength = strength_by_pair.get(pair, {})
        native_strength = fnum(queue["native_interaction_strength"])
        status, note = role_scale_status(
            queue["priority_class"],
            queue["native_closure_class"],
            native_strength,
        )
        pair_row = {
            "suk055_pair": pair,
            "priority_class": queue["priority_class"],
            "charge_class": queue["charge_class"],
            "phase_role_operator": queue["phase_role_operator"],
            "native_interaction_strength": native_strength,
            "native_closure_class": queue["native_closure_class"],
            "constituent_sum_MeV": strength.get("constituent_sum_MeV", ""),
            "interaction_mass_coordinate_MeV": queue["interaction_mass_coordinate_MeV"],
            "mass_coordinate_grade": strength.get("mass_coordinate_grade", ""),
            "pair_selector_status": status,
            "pair_selector_note": note,
            "observed_mass_used": False,
        }
        pair_rows.append(pair_row)
        for scaffold_id in split_slots(queue["oriented_slot_ids"]):
            scaffold = scaffold_rows.get(scaffold_id, {})
            boundary = boundary_by_scaffold.get(scaffold_id, {})
            if not scaffold or not boundary:
                continue
            role_rows.append(
                {
                    "scaffold_id": scaffold_id,
                    "suk055_pair": pair,
                    "constituents": scaffold.get("constituents", ""),
                    "charge": scaffold.get("charge", ""),
                    "phase_role_operator": queue["phase_role_operator"],
                    "priority_class": queue["priority_class"],
                    "native_interaction_strength": native_strength,
                    "native_closure_class": queue["native_closure_class"],
                    "role_coordinate_MeV": queue["interaction_mass_coordinate_MeV"],
                    "constituent_sum_MeV": strength.get("constituent_sum_MeV", ""),
                    "mass_coordinate_grade": strength.get("mass_coordinate_grade", ""),
                    "role_scale_status": status,
                    "final_bound_mass_status": "BOUNDARY_QP041C_BINDING_READOUT_REQUIRED",
                    "observed_mass_used": False,
                    "free_parameters_used": 0,
                    "source_boundary_class": boundary.get("boundary_class", ""),
                    "next_selector": "QP041C_MESON_BINDING_READOUT_SELECTOR",
                    "note": note,
                }
            )

    filled_role_rows = [
        row
        for row in role_rows
        if str(row["role_scale_status"]).startswith("FILLED_NATIVE_MESON")
    ]
    filled_pair_rows = [
        row
        for row in pair_rows
        if str(row["pair_selector_status"]).startswith("FILLED_NATIVE_MESON")
    ]

    before_candidate_count = sum(
        1
        for row in boundary_rows
        if row["boundary_class"] == "CANDIDATE_MESON_READOUT_ROLE_SCALE_SELECTOR_NEEDED"
    )
    before_return_count = sum(
        1
        for row in boundary_rows
        if row["boundary_class"] == "CANDIDATE_RETURN_CHANNEL_BINDING_SELECTOR_NEEDED"
    )
    boundary_delta_rows = [
        {
            "boundary_group": "CANDIDATE_MESON_READOUT_ROLE_SCALE_SELECTOR_NEEDED",
            "before_count": before_candidate_count,
            "after_count": before_candidate_count - len(filled_role_rows),
            "delta_note": "QP041B fills role-scale coordinates for the high-priority meson queue",
        },
        {
            "boundary_group": "FILLED_ROLE_SCALE_BINDING_READOUT_OPEN",
            "before_count": 0,
            "after_count": len(filled_role_rows),
            "delta_note": "rows now carry native role coordinate but still need final binding/readout selector",
        },
        {
            "boundary_group": "CANDIDATE_RETURN_CHANNEL_BINDING_SELECTOR_NEEDED",
            "before_count": before_return_count,
            "after_count": before_return_count,
            "delta_note": "QP041B does not touch c<->t return-channel binding rows",
        },
    ]

    status_counts = Counter(row["role_scale_status"] for row in role_rows)
    grade_counts = Counter(row["mass_coordinate_grade"] for row in role_rows)

    if (
        qp005.get("result_class") == "QP005_PRIVATE_NATIVE_COMPOSITE_INTERACTION_STRENGTH_LAW_BUILT"
        and qp040.get("result_class") == "QP040_NATIVE_BINDING_RESIDUE_OPERATOR_SELECTED"
        and qp041.get("result_class") == "QP041_MESON_SCAFFOLD_FIRST_FILL_SELECTED"
        and len(filled_role_rows) > 0
    ):
        result_class = "QP041B_HIGH_PRIORITY_MESON_ROLE_SCALE_COORDINATES_SELECTED"
        campaign_status = "QP041B_ROLE_SCALE_SELECTED_QP041C_NEXT"
        next_frontier = "QP041C_PRIVATE_MESON_BINDING_READOUT_SELECTOR"
    else:
        result_class = "QP041B_HIGH_PRIORITY_MESON_ROLE_SCALE_HELD_OPEN"
        campaign_status = "QP041B_HELD_OPEN"
        next_frontier = "QP041B_INPUT_REPAIR"

    decision_rows = [
        {
            "decision_item": "preflight",
            "decision_value": "PASS_FORWARD_MODEL_BUILD",
            "reason": "new role-scale selector; not audit, not retest, no public write",
        },
        {
            "decision_item": "role_scale_coordinate",
            "decision_value": "SELECTED" if filled_role_rows else "HELD_OPEN",
            "reason": "QP005 interaction mass coordinate is available for high-priority meson queue rows",
        },
        {
            "decision_item": "final_bound_mass",
            "decision_value": "NOT_EMITTED",
            "reason": "QP041B fills role scale only; binding/readout remains QP041C",
        },
        {
            "decision_item": "observed_mass_input",
            "decision_value": "NOT_USED",
            "reason": "QP041B uses QP005 native pair coordinates and QP039/QP041 queue/boundary rows only",
        },
    ]
    schema_rows = [
        {
            "class": "FILLED_NATIVE_MESON_ROLE_SCALE_LOCK",
            "meaning": "write-midpoint role lock selects native interaction mass coordinate",
            "status": "selected" if any(row["role_scale_status"] == "FILLED_NATIVE_MESON_ROLE_SCALE_LOCK" for row in role_rows) else "not_reached",
        },
        {
            "class": "FILLED_NATIVE_MESON_A_SHARE_ROLE_SCALE_COORDINATE",
            "meaning": "A-share role candidate selects native interaction mass coordinate",
            "status": "selected" if any(row["role_scale_status"] == "FILLED_NATIVE_MESON_A_SHARE_ROLE_SCALE_COORDINATE" for row in role_rows) else "not_reached",
        },
        {
            "class": "BOUNDARY_QP041C_BINDING_READOUT_REQUIRED",
            "meaning": "role scale is filled but final bound mass/readout selector remains open",
            "status": "next",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP041B filled high-priority role coordinates but did not emit final bound masses; QP041C must select the binding/readout layer.",
            "launch_from": "qp041b_high_priority_meson_role_scale_table.csv;qp040_binding_residue_operator_table.csv",
            "target_output": "meson binding/readout selector table",
        }
    ]

    summary = {
        "artifact": "QP041B_PRIVATE_HIGH_PRIORITY_MESON_ROLE_SCALE_SELECTOR",
        "result_class": result_class,
        "campaign_status": campaign_status,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_meson_masses_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp005/qp005_native_composite_interaction_strength_summary.json",
            "artifacts/qp005/qp005_native_composite_interaction_strength_table.csv",
            "artifacts/qp039/qp039_composite_role_queue_table.csv",
            "artifacts/qp040/qp040_summary.json",
            "artifacts/qp041/qp041_summary.json",
            "artifacts/qp041/qp041_meson_open_boundary_table.csv",
            "phase4_tables/phase4_composite_scaffold_table.csv",
        ],
        "qp005_result_class": qp005.get("result_class", ""),
        "qp040_result_class": qp040.get("result_class", ""),
        "qp041_result_class": qp041.get("result_class", ""),
        "high_priority_pairs": len(high_priority_queue),
        "filled_role_scale_pairs": len(filled_pair_rows),
        "filled_role_scale_rows": len(filled_role_rows),
        "role_scale_status_counts": dict(status_counts),
        "mass_coordinate_grade_counts": dict(grade_counts),
        "final_bound_mass_rows_emitted": 0,
        "boundary_delta_rows": len(boundary_delta_rows),
        "next_frontier": next_frontier,
        "interpretation": "QP041B fills native role-scale coordinates for high-priority meson scaffolds; final binding/readout remains the next selector.",
    }

    QP041B_DIR.mkdir(parents=True, exist_ok=True)
    write_csv(
        ROLE_SCALE_OUT,
        role_rows,
        [
            "scaffold_id",
            "suk055_pair",
            "constituents",
            "charge",
            "phase_role_operator",
            "priority_class",
            "native_interaction_strength",
            "native_closure_class",
            "role_coordinate_MeV",
            "constituent_sum_MeV",
            "mass_coordinate_grade",
            "role_scale_status",
            "final_bound_mass_status",
            "observed_mass_used",
            "free_parameters_used",
            "source_boundary_class",
            "next_selector",
            "note",
        ],
    )
    write_csv(
        PAIR_OUT,
        pair_rows,
        [
            "suk055_pair",
            "priority_class",
            "charge_class",
            "phase_role_operator",
            "native_interaction_strength",
            "native_closure_class",
            "constituent_sum_MeV",
            "interaction_mass_coordinate_MeV",
            "mass_coordinate_grade",
            "pair_selector_status",
            "pair_selector_note",
            "observed_mass_used",
        ],
    )
    write_csv(
        BOUNDARY_DELTA_OUT,
        boundary_delta_rows,
        ["boundary_group", "before_count", "after_count", "delta_note"],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, role_rows, pair_rows, boundary_delta_rows)

    print(summary["artifact"])
    print(f"result_class={summary['result_class']}")
    print(f"filled_role_scale_pairs={summary['filled_role_scale_pairs']}")
    print(f"filled_role_scale_rows={summary['filled_role_scale_rows']}")
    print(f"final_bound_mass_rows_emitted={summary['final_bound_mass_rows_emitted']}")
    print(f"next_frontier={summary['next_frontier']}")


if __name__ == "__main__":
    main()
