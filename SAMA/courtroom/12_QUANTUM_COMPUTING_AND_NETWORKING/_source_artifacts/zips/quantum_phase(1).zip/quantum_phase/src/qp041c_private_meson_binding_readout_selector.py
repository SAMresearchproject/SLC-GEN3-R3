from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]

ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"

QP039_RETURN = ARTIFACTS / "qp039" / "qp039_return_channel_table.csv"
QP039_QUEUE = ARTIFACTS / "qp039" / "qp039_composite_role_queue_table.csv"
QP040_OPERATOR = ARTIFACTS / "qp040" / "qp040_binding_residue_operator_table.csv"
QP041_BOUNDARY = ARTIFACTS / "qp041" / "qp041_meson_open_boundary_table.csv"
QP041B_SUMMARY = ARTIFACTS / "qp041b" / "qp041b_summary.json"
QP041B_ROLE = ARTIFACTS / "qp041b" / "qp041b_high_priority_meson_role_scale_table.csv"

QP041C_DIR = ARTIFACTS / "qp041c"
PREFLIGHT_OUT = QP041C_DIR / "qp041c_preflight.md"
SUMMARY_OUT = QP041C_DIR / "qp041c_summary.json"
BINDING_READOUT_OUT = QP041C_DIR / "qp041c_meson_binding_readout_table.csv"
RESIDUE_SELECTOR_OUT = QP041C_DIR / "qp041c_residue_selector_table.csv"
RETURN_CHANNEL_OUT = QP041C_DIR / "qp041c_return_channel_binding_table.csv"
BOUNDARY_DELTA_OUT = QP041C_DIR / "qp041c_meson_boundary_delta_table.csv"
DECISION_OUT = QP041C_DIR / "qp041c_decision_table.csv"
NEXT_OUT = QP041C_DIR / "qp041c_next_frontier.csv"
SCHEMA_OUT = QP041C_DIR / "qp041c_schema.csv"
DOC_OUT = REPORTS / "QP041C_PRIVATE_MESON_BINDING_READOUT_SELECTOR.md"


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def fnum(value: str | float | int | None, default: float = 0.0) -> float:
    if value is None or value == "":
        return default
    return float(value)


def split_slots(oriented_slot_ids: str) -> list[str]:
    return [item.strip() for item in oriented_slot_ids.split(";") if item.strip()]


def parse_constituent_bases(constituents: str) -> tuple[str, str]:
    left, right = constituents.split(";")
    for prefix in ("anti_", "anti-"):
        if right.startswith(prefix):
            right = right.replace(prefix, "", 1)
            break
    return left, right


def residue_lookup(operator_rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    rows = [row for row in operator_rows if row["branch"] == "meson"]
    by_family = {row["composite_id"]: row for row in rows}
    return {
        "SELF_NEUTRAL": by_family["neutral_pion_family"],
        "MIXED_NEUTRAL": by_family["neutral_kaon_family"],
        "TRANSITION_COLOR": by_family["charged_kaon_family"],
        "DUAL_POLARITY_CHARGED": by_family["charged_pion_family"],
    }


def select_residue(row: dict[str, Any], residues: dict[str, dict[str, str]]) -> tuple[str, dict[str, str], str]:
    left, right = parse_constituent_bases(str(row["constituents"]))
    phase_role = str(row["phase_role_operator"])
    charge = str(row["charge"])
    if charge == "0" and left == right:
        return (
            "SELF_NEUTRAL_Q_ANTI_Q_RESIDUE",
            residues["SELF_NEUTRAL"],
            "neutral self-channel selects q=-15 from neutral pion family",
        )
    if phase_role == "NEUTRAL_BINARY_MIXING_ROLE_OPERATOR":
        return (
            "MIXED_NEUTRAL_Q_ANTI_Q_RESIDUE",
            residues["MIXED_NEUTRAL"],
            "neutral binary mixing selects q=-7 from neutral kaon family",
        )
    if phase_role == "TRANSITION_COLOR_COUPLED_ROLE_OPERATOR":
        return (
            "TRANSITION_COLOR_Q_ANTI_Q_RESIDUE",
            residues["TRANSITION_COLOR"],
            "transition color-coupled role selects q=0 from charged kaon family",
        )
    if phase_role == "DUAL_POLARITY_CHARGED_HEAVY_ROLE_OPERATOR":
        return (
            "DUAL_POLARITY_CHARGED_Q_ANTI_Q_RESIDUE",
            residues["DUAL_POLARITY_CHARGED"],
            "dual-polarity charged role selects q=4 from charged pion family",
        )
    if charge != "0":
        return (
            "CHARGED_FALLBACK_Q_ANTI_Q_RESIDUE",
            residues["DUAL_POLARITY_CHARGED"],
            "charged fallback selects q=4 from charged pion family",
        )
    return (
        "MIXED_NEUTRAL_FALLBACK_Q_ANTI_Q_RESIDUE",
        residues["MIXED_NEUTRAL"],
        "neutral fallback selects q=-7 from neutral kaon family",
    )


def write_preflight() -> None:
    QP041C_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP041C Preflight - Meson Binding Readout Selector

```text
test_id = QP041C
test_name = PRIVATE_MESON_BINDING_READOUT_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp039/qp039_return_channel_table.csv
artifacts/qp039/qp039_composite_role_queue_table.csv
artifacts/qp040/qp040_binding_residue_operator_table.csv
artifacts/qp041/qp041_meson_open_boundary_table.csv
artifacts/qp041b/qp041b_summary.json
artifacts/qp041b/qp041b_high_priority_meson_role_scale_table.csv
```

## Expected Outputs

```text
artifacts/qp041c/qp041c_summary.json
artifacts/qp041c/qp041c_meson_binding_readout_table.csv
artifacts/qp041c/qp041c_residue_selector_table.csv
artifacts/qp041c/qp041c_return_channel_binding_table.csv
docs/reports/QP041C_PRIVATE_MESON_BINDING_READOUT_SELECTOR.md
```

## Forward Question

```text
Can QP040 residue classes plus QP041B role coordinates emit native meson
binding/readout coordinates without observed meson masses?
```

This gate emits SAM-native binding/readout coordinates, not external observed
mass matches.
""",
        encoding="utf-8",
    )


def write_doc(
    summary: dict[str, Any],
    readout_rows: list[dict[str, Any]],
    residue_rows: list[dict[str, Any]],
    delta_rows: list[dict[str, Any]],
) -> None:
    readout_lines = "\n".join(
        f"| {row['scaffold_id']} | {row['suk055_pair']} | {row['role_coordinate_MeV']} | {row['residue_q']} | {row['native_binding_readout_MeV']} | {row['binding_readout_status']} |"
        for row in readout_rows
    )
    residue_lines = "\n".join(
        f"| {row['selector_class']} | {row['source_family']} | {row['q']} | {row['residue_operator']} | {row['selector_rule']} |"
        for row in residue_rows
    )
    delta_lines = "\n".join(
        f"| {row['boundary_group']} | {row['before_count']} | {row['after_count']} | {row['delta_note']} |"
        for row in delta_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP041C - Private Meson Binding Readout Selector

## Preflight

```text
test_id = QP041C
test_name = PRIVATE_MESON_BINDING_READOUT_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP041C emits SAM-native binding/readout coordinates:

```text
M_readout = M_role * R_bind(q,D)
```

Observed meson masses are not used.

## Binding Readout Rows

| scaffold | pair | role coordinate / MeV | q | native readout / MeV | status |
| --- | --- | ---: | ---: | ---: | --- |
{readout_lines}

## Residue Selector

| selector class | source family | q | R_bind | selector rule |
| --- | --- | ---: | ---: | --- |
{residue_lines}

## Boundary Delta

| boundary group | before | after | note |
| --- | ---: | ---: | --- |
{delta_lines}

## Key Fields

```text
binding_readout_rows = {summary['binding_readout_rows']}
high_priority_role_rows_consumed = {summary['high_priority_role_rows_consumed']}
return_channel_rows_consumed = {summary['return_channel_rows_consumed']}
observed_meson_masses_used = {summary['observed_meson_masses_used']}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

The high-priority meson queue now has native binding/readout coordinates. QP041C
also consumes the two `c<->t` return-channel rows because QP039 selected that
bridge and the phase role selects the mixed-neutral residue class.
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    qp041b = read_json(QP041B_SUMMARY)
    role_rows = read_csv(QP041B_ROLE)
    operator_rows = read_csv(QP040_OPERATOR)
    return_rows = read_csv(QP039_RETURN)
    queue_rows = read_csv(QP039_QUEUE)
    boundary_rows = read_csv(QP041_BOUNDARY)

    residues = residue_lookup(operator_rows)
    return_pairs = {row["suk055_pair"] for row in return_rows}
    boundary_by_scaffold = {row["scaffold_id"]: row for row in boundary_rows}

    readout_inputs: list[dict[str, Any]] = []
    for row in role_rows:
        readout_inputs.append({**row, "input_source": "QP041B_HIGH_PRIORITY_ROLE_SCALE"})

    for queue in queue_rows:
        if queue["suk055_pair"] not in return_pairs:
            continue
        for scaffold_id in split_slots(queue["oriented_slot_ids"]):
            boundary = boundary_by_scaffold.get(scaffold_id)
            if not boundary:
                continue
            readout_inputs.append(
                {
                    "scaffold_id": scaffold_id,
                    "suk055_pair": queue["suk055_pair"],
                    "constituents": boundary["constituents"],
                    "charge": boundary["charge"],
                    "phase_role_operator": queue["phase_role_operator"],
                    "priority_class": queue["priority_class"],
                    "native_interaction_strength": queue["native_interaction_strength"],
                    "native_closure_class": queue["native_closure_class"],
                    "role_coordinate_MeV": queue["interaction_mass_coordinate_MeV"],
                    "constituent_sum_MeV": "",
                    "mass_coordinate_grade": "RETURN_CHANNEL_PAIR_MASS_COORDINATE",
                    "role_scale_status": "FILLED_RETURN_CHANNEL_ROLE_COORDINATE",
                    "final_bound_mass_status": "BOUNDARY_QP041C_BINDING_READOUT_REQUIRED",
                    "observed_mass_used": "False",
                    "free_parameters_used": "0",
                    "source_boundary_class": boundary["boundary_class"],
                    "next_selector": "QP041C_MESON_BINDING_READOUT_SELECTOR",
                    "note": "QP039 return channel supplies local W/I bridge for binding readout",
                    "input_source": "QP039_RETURN_CHANNEL_BINDING",
                }
            )

    readout_rows: list[dict[str, Any]] = []
    residue_selector_records: dict[str, dict[str, Any]] = {}
    for row in readout_inputs:
        selector_class, residue, selector_note = select_residue(row, residues)
        role_coordinate = fnum(row["role_coordinate_MeV"])
        residue_operator = fnum(residue["residue_operator"])
        readout = role_coordinate * residue_operator
        residue_selector_records[selector_class] = {
            "selector_class": selector_class,
            "source_family": residue["composite_id"],
            "source_symbol": residue["symbol"],
            "q": residue["q"],
            "D": residue["D"],
            "residue_operator": residue["residue_operator"],
            "operator_class": residue["operator_class"],
            "selector_rule": selector_note,
        }
        readout_rows.append(
            {
                "scaffold_id": row["scaffold_id"],
                "suk055_pair": row["suk055_pair"],
                "constituents": row["constituents"],
                "charge": row["charge"],
                "input_source": row["input_source"],
                "phase_role_operator": row["phase_role_operator"],
                "priority_class": row["priority_class"],
                "native_closure_class": row["native_closure_class"],
                "role_coordinate_MeV": role_coordinate,
                "residue_selector_class": selector_class,
                "residue_source_family": residue["composite_id"],
                "residue_q": residue["q"],
                "residue_D": residue["D"],
                "residue_operator": residue_operator,
                "native_binding_readout_MeV": readout,
                "binding_readout_status": "FILLED_NATIVE_MESON_BINDING_READOUT_COORDINATE",
                "external_observed_mass_used": False,
                "free_parameters_used": 0,
                "mass_coordinate_grade": row["mass_coordinate_grade"],
                "next_selector": "QP043_PRIVATE_UNKNOWN_MODE_CARRIER_ASSIGNMENT",
                "note": selector_note,
            }
        )

    residue_rows = list(residue_selector_records.values())
    input_counts = Counter(row["input_source"] for row in readout_rows)
    selector_counts = Counter(row["residue_selector_class"] for row in readout_rows)

    high_priority_before = int(qp041b.get("filled_role_scale_rows", 0))
    return_before = sum(
        1
        for row in boundary_rows
        if row["boundary_class"] == "CANDIDATE_RETURN_CHANNEL_BINDING_SELECTOR_NEEDED"
    )
    delta_rows = [
        {
            "boundary_group": "FILLED_ROLE_SCALE_BINDING_READOUT_OPEN",
            "before_count": high_priority_before,
            "after_count": 0,
            "delta_note": "QP041C applies native residue selector to QP041B role-scale rows",
        },
        {
            "boundary_group": "CANDIDATE_RETURN_CHANNEL_BINDING_SELECTOR_NEEDED",
            "before_count": return_before,
            "after_count": 0,
            "delta_note": "QP041C applies mixed-neutral residue to QP039 return-channel rows",
        },
        {
            "boundary_group": "FILLED_NATIVE_MESON_BINDING_READOUT_COORDINATE",
            "before_count": 0,
            "after_count": len(readout_rows),
            "delta_note": "native binding/readout coordinates emitted without observed meson masses",
        },
    ]

    if (
        qp041b.get("result_class") == "QP041B_HIGH_PRIORITY_MESON_ROLE_SCALE_COORDINATES_SELECTED"
        and len(readout_rows) == high_priority_before + return_before
        and readout_rows
    ):
        result_class = "QP041C_MESON_BINDING_READOUT_COORDINATES_SELECTED"
        campaign_status = "QP041C_BINDING_READOUT_SELECTED_QP043_NEXT"
        next_frontier = "QP043_PRIVATE_UNKNOWN_MODE_CARRIER_ASSIGNMENT"
    else:
        result_class = "QP041C_MESON_BINDING_READOUT_HELD_OPEN"
        campaign_status = "QP041C_HELD_OPEN"
        next_frontier = "QP041C_INPUT_REPAIR"

    decision_rows = [
        {
            "decision_item": "preflight",
            "decision_value": "PASS_FORWARD_MODEL_BUILD",
            "reason": "new binding/readout selector; not audit, not retest, no public write",
        },
        {
            "decision_item": "binding_readout",
            "decision_value": f"{len(readout_rows)}_ROWS_SELECTED",
            "reason": "phase-role residue selector applied to QP041B role rows plus QP039 return-channel rows",
        },
        {
            "decision_item": "observed_mass_input",
            "decision_value": "NOT_USED",
            "reason": "QP041C uses QP040 residue classes and QP041B/QP039 native coordinates only",
        },
    ]
    schema_rows = [
        {
            "class": "FILLED_NATIVE_MESON_BINDING_READOUT_COORDINATE",
            "meaning": "role coordinate multiplied by selected QP040 residue operator",
            "status": "selected" if readout_rows else "not_reached",
        },
        {
            "class": "DUAL_POLARITY_CHARGED_Q_ANTI_Q_RESIDUE",
            "meaning": "dual-polarity charged role selects q=4 positive suppression",
            "status": "available",
        },
        {
            "class": "TRANSITION_COLOR_Q_ANTI_Q_RESIDUE",
            "meaning": "transition color-coupled role selects q=0 neutral return",
            "status": "available",
        },
        {
            "class": "MIXED_NEUTRAL_Q_ANTI_Q_RESIDUE",
            "meaning": "neutral binary mixing selects q=-7 mixed-neutral return",
            "status": "available",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP041C emitted native meson binding/readout coordinates; unknown modes can now be assigned against filled particle, meson, baryon, and candidate sectors.",
            "launch_from": "qp041c_meson_binding_readout_table.csv;qp041_meson_fill_table.csv;qp042_baryon_fill_table.csv;phase4_unknown_mode_candidates.csv",
            "target_output": "unknown mode carrier assignment table",
        }
    ]
    summary = {
        "artifact": "QP041C_PRIVATE_MESON_BINDING_READOUT_SELECTOR",
        "result_class": result_class,
        "campaign_status": campaign_status,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_meson_masses_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp039/qp039_return_channel_table.csv",
            "artifacts/qp039/qp039_composite_role_queue_table.csv",
            "artifacts/qp040/qp040_binding_residue_operator_table.csv",
            "artifacts/qp041/qp041_meson_open_boundary_table.csv",
            "artifacts/qp041b/qp041b_summary.json",
            "artifacts/qp041b/qp041b_high_priority_meson_role_scale_table.csv",
        ],
        "qp041b_result_class": qp041b.get("result_class", ""),
        "binding_readout_rows": len(readout_rows),
        "high_priority_role_rows_consumed": input_counts.get("QP041B_HIGH_PRIORITY_ROLE_SCALE", 0),
        "return_channel_rows_consumed": input_counts.get("QP039_RETURN_CHANNEL_BINDING", 0),
        "residue_selector_counts": dict(selector_counts),
        "boundary_delta_rows": len(delta_rows),
        "next_frontier": next_frontier,
        "interpretation": "QP041C emits SAM-native meson binding/readout coordinates from QP041B role coordinates and QP040 residue selectors without observed meson mass input.",
    }

    QP041C_DIR.mkdir(parents=True, exist_ok=True)
    write_csv(
        BINDING_READOUT_OUT,
        readout_rows,
        [
            "scaffold_id",
            "suk055_pair",
            "constituents",
            "charge",
            "input_source",
            "phase_role_operator",
            "priority_class",
            "native_closure_class",
            "role_coordinate_MeV",
            "residue_selector_class",
            "residue_source_family",
            "residue_q",
            "residue_D",
            "residue_operator",
            "native_binding_readout_MeV",
            "binding_readout_status",
            "external_observed_mass_used",
            "free_parameters_used",
            "mass_coordinate_grade",
            "next_selector",
            "note",
        ],
    )
    write_csv(
        RESIDUE_SELECTOR_OUT,
        residue_rows,
        [
            "selector_class",
            "source_family",
            "source_symbol",
            "q",
            "D",
            "residue_operator",
            "operator_class",
            "selector_rule",
        ],
    )
    write_csv(
        RETURN_CHANNEL_OUT,
        [row for row in readout_rows if row["input_source"] == "QP039_RETURN_CHANNEL_BINDING"],
        [
            "scaffold_id",
            "suk055_pair",
            "constituents",
            "charge",
            "input_source",
            "phase_role_operator",
            "role_coordinate_MeV",
            "residue_selector_class",
            "residue_q",
            "residue_operator",
            "native_binding_readout_MeV",
            "binding_readout_status",
            "external_observed_mass_used",
        ],
    )
    write_csv(BOUNDARY_DELTA_OUT, delta_rows, ["boundary_group", "before_count", "after_count", "delta_note"])
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, readout_rows, residue_rows, delta_rows)

    print(summary["artifact"])
    print(f"result_class={summary['result_class']}")
    print(f"binding_readout_rows={summary['binding_readout_rows']}")
    print(f"high_priority_role_rows_consumed={summary['high_priority_role_rows_consumed']}")
    print(f"return_channel_rows_consumed={summary['return_channel_rows_consumed']}")
    print(f"next_frontier={summary['next_frontier']}")


if __name__ == "__main__":
    main()
