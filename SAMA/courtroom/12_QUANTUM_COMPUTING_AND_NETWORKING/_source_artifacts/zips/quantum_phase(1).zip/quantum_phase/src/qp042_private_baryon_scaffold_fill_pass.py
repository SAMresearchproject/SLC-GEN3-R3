from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]

ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

QP040_SUMMARY = ARTIFACTS / "qp040" / "qp040_summary.json"
QP040_OPERATOR = ARTIFACTS / "qp040" / "qp040_binding_residue_operator_table.csv"
COMPOSITE_SUPPORT = PHASE4 / "phase4_composite_support_table.csv"
COMPOSITE_SCAFFOLDS = PHASE4 / "phase4_composite_scaffold_table.csv"

QP042_DIR = ARTIFACTS / "qp042"
PREFLIGHT_OUT = QP042_DIR / "qp042_preflight.md"
SUMMARY_OUT = QP042_DIR / "qp042_summary.json"
BARYON_FILL_OUT = QP042_DIR / "qp042_baryon_fill_table.csv"
BARYON_BOUNDARY_OUT = QP042_DIR / "qp042_baryon_open_boundary_table.csv"
BARYON_FAMILY_OUT = QP042_DIR / "qp042_baryon_family_fill_map.csv"
DECISION_OUT = QP042_DIR / "qp042_decision_table.csv"
NEXT_OUT = QP042_DIR / "qp042_next_frontier.csv"
SCHEMA_OUT = QP042_DIR / "qp042_schema.csv"
DOC_OUT = REPORTS / "QP042_PRIVATE_BARYON_SCAFFOLD_FILL_PASS.md"

QUARK_ORDER = {symbol: idx for idx, symbol in enumerate(["b", "c", "d", "s", "t", "u"])}


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def baryon_scaffold_from_constituents(constituents: str) -> str:
    parts = constituents.split(";")
    ordered = sorted(parts, key=lambda item: QUARK_ORDER[item])
    return "".join(ordered)


def baryon_boundary_class(constituents: str, mass_status: str) -> tuple[str, str]:
    parts = set(constituents.split(";"))
    if parts <= {"d", "u"}:
        return (
            "CANDIDATE_LIGHT_BARYON_EXCITED_STATE_SELECTOR_NEEDED",
            "LIGHT_BARYON_ISOSPIN_AND_EXCITATION_SELECTOR",
        )
    if "t" in parts:
        return (
            "BOUNDARY_TOP_BARYON_ROLE_SCALE_SELECTOR_NEEDED",
            "TOP_BARYON_STABILITY_AND_ROLE_SCALE_SELECTOR",
        )
    if "b" in parts:
        return (
            "BOUNDARY_BOTTOM_BARYON_ROLE_SCALE_SELECTOR_NEEDED",
            "BOTTOM_BARYON_BINDING_ROLE_SCALE_SELECTOR",
        )
    if "c" in parts:
        return (
            "BOUNDARY_CHARM_BARYON_ROLE_SCALE_SELECTOR_NEEDED",
            "CHARM_BARYON_BINDING_ROLE_SCALE_SELECTOR",
        )
    if "s" in parts:
        return (
            "CANDIDATE_STRANGE_BARYON_SELECTOR_NEEDED",
            "STRANGE_BARYON_BINDING_ROLE_SCALE_SELECTOR",
        )
    if "STRICT_CONSTITUENT_SUM_AVAILABLE" in mass_status:
        return (
            "BOUNDARY_STRICT_CONSTITUENT_SUM_BINDING_SELECTOR_NEEDED",
            "BARYON_BINDING_RESIDUE_ROLE_SCALE_SELECTOR",
        )
    return (
        "OPEN_BARYON_CONSTITUENT_MASS_SELECTOR_NEEDED",
        "BARYON_CONSTITUENT_MASS_AND_BINDING_SELECTOR",
    )


def write_preflight() -> None:
    QP042_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP042 Preflight - Baryon Scaffold Fill Pass

```text
test_id = QP042
test_name = PRIVATE_BARYON_SCAFFOLD_FILL_PASS
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp040/qp040_summary.json
artifacts/qp040/qp040_binding_residue_operator_table.csv
phase4_tables/phase4_composite_support_table.csv
phase4_tables/phase4_composite_scaffold_table.csv
```

## Expected Outputs

```text
artifacts/qp042/qp042_summary.json
artifacts/qp042/qp042_baryon_fill_table.csv
artifacts/qp042/qp042_baryon_open_boundary_table.csv
artifacts/qp042/qp042_baryon_family_fill_map.csv
docs/reports/QP042_PRIVATE_BARYON_SCAFFOLD_FILL_PASS.md
```

## Forward Question

```text
Which of the 56 qqq baryon scaffold slots receive a unique native mass readout
from QP039 and QP040?
```

Rows are filled only from selected native baryon support families and the QP040
binding-residue operator. Observed baryon masses are not used.
""",
        encoding="utf-8",
    )


def write_doc(
    summary: dict[str, Any],
    fill_rows: list[dict[str, Any]],
    boundary_rows: list[dict[str, Any]],
    family_rows: list[dict[str, Any]],
) -> None:
    fill_lines = "\n".join(
        f"| {row['scaffold_id']} | {row['support_family']} | {row['symbol']} | {row['sam_mass_MeV']} | {row['fill_status']} |"
        for row in fill_rows
    )
    boundary_lines = "\n".join(
        f"| {row['scaffold_id']} | {row['charge']} | {row['boundary_class']} | {row['selector_needed']} |"
        for row in boundary_rows
    )
    family_lines = "\n".join(
        f"| {row['support_family']} | {row['symbol']} | {row['filled_scaffold']} | {row['operator_class']} |"
        for row in family_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP042 - Private Baryon Scaffold Fill Pass

## Preflight

```text
test_id = QP042
test_name = PRIVATE_BARYON_SCAFFOLD_FILL_PASS
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP042 fills the baryon scaffolds reached by selected native baryon support
families and the QP040 binding-residue operator.

## Filled Baryon Rows

| scaffold | family | symbol | SAM mass / MeV | status |
| --- | --- | --- | ---: | --- |
{fill_lines}

## Family Map

| family | symbol | filled scaffold | operator class |
| --- | --- | --- | --- |
{family_lines}

## Open Boundaries

| scaffold | charge | boundary class | selector needed |
| --- | ---: | --- | --- |
{boundary_lines}

## Key Fields

```text
baryon_scaffold_rows = {summary['baryon_scaffold_rows']}
filled_baryon_scaffold_rows = {summary['filled_baryon_scaffold_rows']}
candidate_baryon_scaffold_rows = {summary['candidate_baryon_scaffold_rows']}
open_boundary_rows = {summary['open_boundary_rows']}
observed_baryon_masses_used = {summary['observed_baryon_masses_used']}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

The proton/neutron rows are now explicit filled qqq scaffold rows. The rest of
the baryon lattice remains structured, not empty: light, strange, charm, bottom,
and top baryon sectors each name their missing role-scale/binding selector.
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    qp040 = read_json(QP040_SUMMARY)
    operator_rows = read_csv(QP040_OPERATOR)
    support_rows = read_csv(COMPOSITE_SUPPORT)
    scaffold_rows = [
        row
        for row in read_csv(COMPOSITE_SCAFFOLDS)
        if row["scaffold_type"] == "BARYON_QQQ"
    ]

    operator_by_family = {row["composite_id"]: row for row in operator_rows}
    scaffold_by_id = {row["scaffold_id"]: row for row in scaffold_rows}

    fill_by_scaffold: dict[str, dict[str, Any]] = {}
    family_rows: list[dict[str, Any]] = []
    for support in support_rows:
        if support["branch"] != "baryon":
            continue
        scaffold_id = baryon_scaffold_from_constituents(support["constituents"])
        operator = operator_by_family.get(support["composite_id"], {})
        scaffold = scaffold_by_id.get(scaffold_id)
        if scaffold:
            fill_by_scaffold[scaffold_id] = {
                "scaffold_id": scaffold_id,
                "constituents": scaffold["constituents"],
                "charge": scaffold["charge"],
                "support_family": support["composite_id"],
                "symbol": support["symbol"],
                "sam_mass_MeV": support["sam_mass_MeV"],
                "constituent_sum_MeV": support["constituent_sum_MeV"],
                "operator_class": operator.get("operator_class", ""),
                "residue_operator": operator.get("residue_operator", ""),
                "formula": support["formula"],
                "fill_status": "FILLED_NATIVE_BARYON_READOUT",
                "observed_mass_used": False,
                "free_parameters_used": support["free_parameters_used"],
                "source": "QP040_NATIVE_BINDING_RESIDUE_OPERATOR_SELECTED",
            }
        family_rows.append(
            {
                "support_family": support["composite_id"],
                "symbol": support["symbol"],
                "support_constituents": support["constituents"],
                "filled_scaffold": scaffold_id if scaffold else "",
                "filled_count": 1 if scaffold else 0,
                "operator_class": operator.get("operator_class", ""),
                "residue_operator": operator.get("residue_operator", ""),
                "sam_mass_MeV": support["sam_mass_MeV"],
            }
        )

    fill_rows = [fill_by_scaffold[key] for key in sorted(fill_by_scaffold)]
    boundary_rows: list[dict[str, Any]] = []
    for scaffold in scaffold_rows:
        scaffold_id = scaffold["scaffold_id"]
        if scaffold_id in fill_by_scaffold:
            continue
        boundary_class, selector_needed = baryon_boundary_class(scaffold["constituents"], scaffold["mass_status"])
        boundary_rows.append(
            {
                "scaffold_id": scaffold_id,
                "constituents": scaffold["constituents"],
                "charge": scaffold["charge"],
                "identity_status": scaffold["identity_status"],
                "mass_status": scaffold["mass_status"],
                "boundary_class": boundary_class,
                "selector_needed": selector_needed,
                "phase4_status": "OPEN_PHASE4_BOUNDARY_AFTER_QP042",
            }
        )

    boundary_counts = Counter(row["boundary_class"] for row in boundary_rows)
    fill_count = len(fill_rows)
    candidate_count = sum(
        1
        for row in boundary_rows
        if row["boundary_class"].startswith("CANDIDATE")
    )
    open_count = len(boundary_rows)
    if qp040.get("result_class") == "QP040_NATIVE_BINDING_RESIDUE_OPERATOR_SELECTED" and fill_count > 0:
        result_class = "QP042_BARYON_SCAFFOLD_FIRST_FILL_SELECTED"
        campaign_status = "QP042_BARYON_FILL_SELECTED_QP043_NEXT"
        next_frontier = "QP043_PRIVATE_UNKNOWN_MODE_CARRIER_ASSIGNMENT"
    else:
        result_class = "QP042_BARYON_SCAFFOLD_FILL_HELD_OPEN"
        campaign_status = "QP042_HELD_OPEN"
        next_frontier = "QP042B_BARYON_INPUT_REPAIR"

    decision_rows = [
        {
            "decision_item": "preflight",
            "decision_value": "PASS_FORWARD_MODEL_BUILD",
            "reason": "new scaffold fill pass; not audit, not retest, no public write",
        },
        {
            "decision_item": "qp040_operator",
            "decision_value": qp040.get("result_class", ""),
            "reason": "QP042 requires the native binding residue operator",
        },
        {
            "decision_item": "baryon_fill",
            "decision_value": f"{fill_count}_ROWS_FILLED",
            "reason": "selected baryon support families map onto Phase 4 qqq scaffolds",
        },
        {
            "decision_item": "observed_mass_input",
            "decision_value": "NOT_USED",
            "reason": "QP042 uses selected SAM-native support masses and operator rows only",
        },
    ]
    schema_rows = [
        {
            "class": "FILLED_NATIVE_BARYON_READOUT",
            "meaning": "baryon scaffold receives a selected native support-family mass readout",
            "status": "selected",
        },
        {
            "class": "CANDIDATE_LIGHT_BARYON_EXCITED_STATE_SELECTOR_NEEDED",
            "meaning": "light baryon row outside proton/neutron needs isospin/excitation selector",
            "status": "boundary",
        },
        {
            "class": "CANDIDATE_STRANGE_BARYON_SELECTOR_NEEDED",
            "meaning": "strange baryon scaffold needs native strange binding selector",
            "status": "boundary",
        },
        {
            "class": "BOUNDARY_HEAVY_BARYON_ROLE_SCALE_SELECTOR_NEEDED",
            "meaning": "heavy baryon scaffold needs charm/bottom/top role-scale selector",
            "status": "boundary",
        },
    ]
    next_rows = [
        {
            "next_frontier": next_frontier,
            "why_next": "QP041 and QP042 filled the selected composite support layer; QP043 can now assign or quarantine unknown native modes against the filled/candidate rows.",
            "launch_from": "qp041_meson_fill_table.csv;qp042_baryon_fill_table.csv;phase4_unknown_mode_candidates.csv",
            "target_output": "unknown mode carrier assignment table",
        }
    ]
    summary = {
        "artifact": "QP042_PRIVATE_BARYON_SCAFFOLD_FILL_PASS",
        "result_class": result_class,
        "campaign_status": campaign_status,
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_baryon_masses_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp040/qp040_summary.json",
            "artifacts/qp040/qp040_binding_residue_operator_table.csv",
            "phase4_tables/phase4_composite_support_table.csv",
            "phase4_tables/phase4_composite_scaffold_table.csv",
        ],
        "qp040_result_class": qp040.get("result_class", ""),
        "baryon_scaffold_rows": len(scaffold_rows),
        "filled_baryon_scaffold_rows": fill_count,
        "filled_baryon_support_families": len(family_rows),
        "filled_baryon_scaffold_ids": ";".join(row["scaffold_id"] for row in fill_rows),
        "candidate_baryon_scaffold_rows": candidate_count,
        "open_boundary_rows": open_count,
        "boundary_class_counts": dict(boundary_counts),
        "next_frontier": next_frontier,
        "interpretation": "QP042 fills proton/neutron qqq support scaffolds and converts the remaining baryon lattice into typed selector boundaries.",
    }

    QP042_DIR.mkdir(parents=True, exist_ok=True)
    write_csv(
        BARYON_FILL_OUT,
        fill_rows,
        [
            "scaffold_id",
            "constituents",
            "charge",
            "support_family",
            "symbol",
            "sam_mass_MeV",
            "constituent_sum_MeV",
            "operator_class",
            "residue_operator",
            "formula",
            "fill_status",
            "observed_mass_used",
            "free_parameters_used",
            "source",
        ],
    )
    write_csv(
        BARYON_BOUNDARY_OUT,
        boundary_rows,
        [
            "scaffold_id",
            "constituents",
            "charge",
            "identity_status",
            "mass_status",
            "boundary_class",
            "selector_needed",
            "phase4_status",
        ],
    )
    write_csv(
        BARYON_FAMILY_OUT,
        family_rows,
        [
            "support_family",
            "symbol",
            "support_constituents",
            "filled_scaffold",
            "filled_count",
            "operator_class",
            "residue_operator",
            "sam_mass_MeV",
        ],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_item", "decision_value", "reason"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["class", "meaning", "status"])
    write_json(SUMMARY_OUT, summary)
    write_doc(summary, fill_rows, boundary_rows, family_rows)

    print(summary["artifact"])
    print(f"result_class={summary['result_class']}")
    print(f"filled_baryon_scaffold_rows={summary['filled_baryon_scaffold_rows']}")
    print(f"candidate_baryon_scaffold_rows={summary['candidate_baryon_scaffold_rows']}")
    print(f"open_boundary_rows={summary['open_boundary_rows']}")
    print(f"next_frontier={summary['next_frontier']}")


if __name__ == "__main__":
    main()
