from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]

ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

UNKNOWN_MODES = PHASE4 / "phase4_unknown_mode_candidates.csv"
PARTICLE_MATRIX = PHASE4 / "phase4_particle_periodic_matrix.csv"
PARTICLE_TABLE = PHASE4 / "phase4_parameter_free_particle_table.csv"

QP022A_ROUTE_INVENTORY = ARTIFACTS / "qp022a" / "qp022a_route_inventory_table.csv"
QP039_RETURN = ARTIFACTS / "qp039" / "qp039_return_channel_table.csv"
QP039_QUEUE = ARTIFACTS / "qp039" / "qp039_composite_role_queue_table.csv"
QP041_MESON_FILL = ARTIFACTS / "qp041" / "qp041_meson_fill_table.csv"
QP041C_BINDING = ARTIFACTS / "qp041c" / "qp041c_meson_binding_readout_table.csv"
QP042_BARYON_FILL = ARTIFACTS / "qp042" / "qp042_baryon_fill_table.csv"

QP043_DIR = ARTIFACTS / "qp043"
PREFLIGHT_OUT = QP043_DIR / "qp043_preflight.md"
SUMMARY_OUT = QP043_DIR / "qp043_summary.json"
ASSIGNMENT_OUT = QP043_DIR / "qp043_unknown_mode_assignment_table.csv"
BOUNDARY_OUT = QP043_DIR / "qp043_unassigned_mode_boundary_table.csv"
CARRIER_SUMMARY_OUT = QP043_DIR / "qp043_carrier_family_summary_table.csv"
DECISION_OUT = QP043_DIR / "qp043_decision_table.csv"
NEXT_OUT = QP043_DIR / "qp043_next_frontier.csv"
SCHEMA_OUT = QP043_DIR / "qp043_schema.csv"
DOC_OUT = REPORTS / "QP043_PRIVATE_UNKNOWN_MODE_CARRIER_ASSIGNMENT.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def parse_partition(value: str) -> list[int]:
    clean = value.strip().removeprefix("(").removesuffix(")")
    return [int(part.strip()) for part in clean.split(",") if part.strip()]


def partition_key(parts: list[int]) -> str:
    return "(" + ",".join(str(part) for part in parts) + ")"


def one_line(text: str) -> str:
    return " ".join(text.split())


def carrier_context(
    return_rows: list[dict[str, str]],
    queue_rows: list[dict[str, str]],
    meson_fill_rows: list[dict[str, str]],
    binding_rows: list[dict[str, str]],
    baryon_rows: list[dict[str, str]],
    route_rows: list[dict[str, str]],
) -> dict[str, Any]:
    return_row = next(
        row for row in return_rows if row["return_channel_status"] == "FILLED_LOCAL_WI_TO_COMPOSITE_RETURN_CHANNEL"
    )
    route_84 = next(row for row in route_rows if row["qubit_native_route"] == "layered_admissible__binary_split__8_4")
    return_binding = [row for row in binding_rows if row["input_source"] == "QP039_RETURN_CHANNEL_BINDING"]
    high_priority_binding = [row for row in binding_rows if row["input_source"] == "QP041B_HIGH_PRIORITY_ROLE_SCALE"]
    charged_role = [
        row
        for row in high_priority_binding
        if row["phase_role_operator"] == "DUAL_POLARITY_CHARGED_HEAVY_ROLE_OPERATOR"
    ]
    transition_role = [
        row
        for row in high_priority_binding
        if row["phase_role_operator"] == "TRANSITION_COLOR_COUPLED_ROLE_OPERATOR"
    ]
    neutral_role = [
        row
        for row in high_priority_binding
        if row["phase_role_operator"] == "NEUTRAL_BINARY_MIXING_ROLE_OPERATOR"
    ]
    return_queue = {row["suk055_pair"]: row for row in queue_rows}
    return_pair = return_row["suk055_pair"]
    return_queue_row = return_queue[return_pair]
    return {
        "return_row": return_row,
        "route_84": route_84,
        "return_binding": return_binding,
        "high_priority_binding": high_priority_binding,
        "charged_role": charged_role,
        "transition_role": transition_role,
        "neutral_role": neutral_role,
        "meson_fill_rows": meson_fill_rows,
        "baryon_rows": baryon_rows,
        "return_queue_row": return_queue_row,
    }


def classify_mode(row: dict[str, str], context: dict[str, Any]) -> dict[str, Any]:
    parts = parse_partition(row["subchannel_partition"])
    counts = Counter(parts)
    shape = row["ownership_class"]
    shape_class = row["mass_native_formula"] or row["ownership_class"]
    n_parts = len(parts)
    max_part = max(parts)
    contains_84 = counts[8] >= 1 and counts[4] >= 1
    contains_alpha3 = counts[8] >= 1
    contains_d2 = counts[9] >= 1
    contains_d = counts[3] >= 1
    contains_alpha2 = counts[4] >= 1
    contains_half = counts[2] >= 1
    exact = partition_key(parts)

    if parts == [8, 4]:
        binding_rows = context["return_binding"]
        carrier_rows = ";".join(row["scaffold_id"] for row in binding_rows)
        readouts = ";".join(row["native_binding_readout_MeV"] for row in binding_rows)
        return {
            "classification": "ASSIGNED_EXISTING_CARRIER",
            "carrier_family": "TRANSITION_8_4_LOCAL_RETURN_CARRIER",
            "carrier_id": context["return_row"]["return_channel_id"],
            "carrier_scaffolds": carrier_rows,
            "carrier_source": "QP022A_ROUTE_TOPOLOGY + QP039_RETURN + QP041C_BINDING_READOUT",
            "carrier_coordinate": readouts,
            "selector_status": "UNIQUE_SELECTOR_PRESENT",
            "selector_needed": "NONE",
            "assignment_strength": "UNIQUE_EXACT_8_4_MATCH",
            "assignment_note": (
                "(8,4) is QUBIT-UNK-001's transition endpoint in QP022A; QP039 selected the c<->t local return "
                "carrier and QP041C emitted both oriented binding/readout coordinates."
            ),
        }

    if parts == [3, 3, 3, 3]:
        return {
            "classification": "CANDIDATE_NEW_NATIVE_MODE",
            "carrier_family": "D_PLUS_ONE_STABLE_PROPAGATION_MODE",
            "carrier_id": "SAM-DISCOVERY-PROPAGATION-4X3",
            "carrier_scaffolds": "",
            "carrier_source": "R12_PARTITION_GRAMMAR + PARTICLE_TABLE_TRIADIC_4_4_4_CONTRAST",
            "carrier_coordinate": "",
            "selector_status": "PROPAGATION_STABILITY_SELECTOR_NEEDED",
            "selector_needed": "D_PLUS_ONE_PROPAGATION_STABILITY_SELECTOR",
            "assignment_strength": "UNIFORM_D_BLOCK_CANDIDATE",
            "assignment_note": (
                "Uniform four blocks of D=3 is not an existing particle row; it is the clean D+1 propagation-mode "
                "candidate produced by the R=12 partition grammar."
            ),
        }

    if parts == [2, 2, 2, 2, 2, 2]:
        return {
            "classification": "CANDIDATE_NEW_NATIVE_MODE",
            "carrier_family": "SIX_HALF_CONTACT_WRITE_ROUTE",
            "carrier_id": "SAM-DISCOVERY-SIX-HALF-CONTACT",
            "carrier_scaffolds": "",
            "carrier_source": "R12_HALF_CONTACT_GRAMMAR",
            "carrier_coordinate": "",
            "selector_status": "HALF_CONTACT_WRITE_SELECTOR_NEEDED",
            "selector_needed": "SIX_CONTACT_LEDGER_ROUTE_SELECTOR",
            "assignment_strength": "UNIFORM_HALF_WRITE_CANDIDATE",
            "assignment_note": (
                "Uniform six blocks of alpha_H=2 organizes the half-contact/six-contact grammar but has no unique "
                "filled carrier yet."
            ),
        }

    if parts == [1] * 12:
        return {
            "classification": "CANDIDATE_NEW_NATIVE_MODE",
            "carrier_family": "TWELVE_MICROCELL_A_SHARE_LATTICE",
            "carrier_id": "SAM-DISCOVERY-12X1-MICROCELL",
            "carrier_scaffolds": "",
            "carrier_source": "R12_A_SHARE_MICROCELL_GRAMMAR",
            "carrier_coordinate": "",
            "selector_status": "MICROCELL_COARSE_GRAIN_SELECTOR_NEEDED",
            "selector_needed": "A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR",
            "assignment_strength": "UNIFORM_MICROCELL_CANDIDATE",
            "assignment_note": (
                "Uniform twelve blocks of one is the R=12 microcell limit. It organizes the blank rather than "
                "assigning a particle or composite carrier."
            ),
        }

    if contains_84:
        return {
            "classification": "CANDIDATE_COMPOSITE_CARRIER",
            "carrier_family": "TRANSITION_8_4_RESIDUE_BASIN",
            "carrier_id": "QP039-RC-001_BASIN",
            "carrier_scaffolds": context["return_row"]["oriented_scaffolds"],
            "carrier_source": "QP039_RETURN_CHANNEL_BASIN",
            "carrier_coordinate": context["return_queue_row"]["native_interaction_strength"],
            "selector_status": "RESIDUE_SELECTOR_NEEDED",
            "selector_needed": "TRANSITION_8_4_RESIDUE_BASIN_SELECTOR",
            "assignment_strength": "CONTAINS_8_AND_4_NOT_EXACT",
            "assignment_note": (
                f"{exact} carries the 8+4 transition grammar plus extra residue; it attaches to the selected "
                "return-channel basin but is not the exact selected carrier."
            ),
        }

    if parts == [9, 3]:
        return {
            "classification": "CANDIDATE_COMPOSITE_CARRIER",
            "carrier_family": "D2_D_BINARY_COMPOSITE_BASIN",
            "carrier_id": "SAM-CANDIDATE-D2-D",
            "carrier_scaffolds": "",
            "carrier_source": "R12_D2_PLUS_D_BINARY_GRAMMAR",
            "carrier_coordinate": "",
            "selector_status": "D2_D_SELECTOR_NEEDED",
            "selector_needed": "D2_D_BINARY_COMPOSITE_SELECTOR",
            "assignment_strength": "EXACT_D2_D_BINARY_CANDIDATE",
            "assignment_note": (
                "(9,3) is an exact D^2 + D binary route. It is organized as a composite basin; QP043 does not "
                "yet have a unique filled particle, meson, or baryon carrier for it."
            ),
        }

    if contains_alpha3:
        return {
            "classification": "CANDIDATE_COMPOSITE_CARRIER",
            "carrier_family": "ALPHA_H3_ASYMMETRIC_TRANSITION_BASIN",
            "carrier_id": "SAM-CANDIDATE-ALPHA3",
            "carrier_scaffolds": context["return_row"]["oriented_scaffolds"],
            "carrier_source": "QP022A_8_4_TRANSITION_GRAMMAR",
            "carrier_coordinate": "",
            "selector_status": "ASYMMETRIC_BASIN_SELECTOR_NEEDED",
            "selector_needed": "ALPHA_H3_TRANSITION_RESIDUE_SELECTOR",
            "assignment_strength": "CONTAINS_8_TRANSITION_HEAD",
            "assignment_note": (
                f"{exact} carries the alpha_H^3=8 transition head. It points at the 8+4 family but does not "
                "uniquely select the c<->t carrier."
            ),
        }

    if contains_d2:
        return {
            "classification": "CANDIDATE_COMPOSITE_CARRIER",
            "carrier_family": "D2_LAYERED_COMPOSITE_BASIN",
            "carrier_id": "SAM-CANDIDATE-D2",
            "carrier_scaffolds": "",
            "carrier_source": "R12_D2_LAYERED_GRAMMAR",
            "carrier_coordinate": "",
            "selector_status": "D2_LAYER_SELECTOR_NEEDED",
            "selector_needed": "D2_LAYERED_COMPOSITE_SELECTOR",
            "assignment_strength": "CONTAINS_D2_LAYER",
            "assignment_note": (
                f"{exact} contains D^2=9. It organizes into the D2 composite basin but needs a layer selector."
            ),
        }

    if counts[4] >= 2:
        scaffolds = ";".join(row["scaffold_id"] for row in context["charged_role"])
        readouts = ";".join(row["native_binding_readout_MeV"] for row in context["charged_role"])
        return {
            "classification": "CANDIDATE_COMPOSITE_CARRIER",
            "carrier_family": "DUAL_POLARITY_CHARGED_HEAVY_ROLE_BASIN",
            "carrier_id": "QP041C-DUAL-POLARITY-CHARGED",
            "carrier_scaffolds": scaffolds,
            "carrier_source": "QP041B_ROLE_SCALE + QP041C_BINDING_READOUT",
            "carrier_coordinate": readouts,
            "selector_status": "ROLE_AXIS_SELECTOR_NEEDED",
            "selector_needed": "DUAL_POLARITY_ROLE_AXIS_SELECTOR",
            "assignment_strength": "MULTIPLE_ALPHA_H2_BLOCKS",
            "assignment_note": (
                f"{exact} carries multiple alpha_H^2=4 blocks, the same block scale used by triadic and "
                "dual-polarity charged role lanes. Existing carriers are a basin, not a unique assignment."
            ),
        }

    if contains_alpha2 and contains_d:
        scaffolds = ";".join(row["scaffold_id"] for row in context["transition_role"])
        readouts = ";".join(row["native_binding_readout_MeV"] for row in context["transition_role"])
        return {
            "classification": "CANDIDATE_COMPOSITE_CARRIER",
            "carrier_family": "TRANSITION_COLOR_COUPLED_ROLE_BASIN",
            "carrier_id": "QP041C-TRANSITION-COLOR",
            "carrier_scaffolds": scaffolds,
            "carrier_source": "QP041B_ROLE_SCALE + QP041C_BINDING_READOUT",
            "carrier_coordinate": readouts,
            "selector_status": "COLOR_TRANSITION_SELECTOR_NEEDED",
            "selector_needed": "TRANSITION_COLOR_ROLE_AXIS_SELECTOR",
            "assignment_strength": "ALPHA_H2_AND_D_MIX",
            "assignment_note": (
                f"{exact} mixes alpha_H^2=4 with D=3 and points at transition-color q anti-q role space."
            ),
        }

    if counts[3] >= 2:
        scaffolds = ";".join(row["scaffold_id"] for row in context["baryon_rows"])
        readouts = ";".join(row["sam_mass_MeV"] for row in context["baryon_rows"])
        return {
            "classification": "CANDIDATE_COMPOSITE_CARRIER",
            "carrier_family": "TRIADIC_D_AXIS_BARYON_BASIN",
            "carrier_id": "QP042-LIGHT-BARYON-BASIN",
            "carrier_scaffolds": scaffolds,
            "carrier_source": "QP042_BARYON_FILL",
            "carrier_coordinate": readouts,
            "selector_status": "BARYON_AXIS_SELECTOR_NEEDED",
            "selector_needed": "TRIADIC_D_AXIS_BARYON_SELECTOR",
            "assignment_strength": "MULTIPLE_D_BLOCKS",
            "assignment_note": (
                f"{exact} carries repeated D=3 blocks and therefore organizes into the triadic/baryon basin."
            ),
        }

    if n_parts == 4:
        return {
            "classification": "CANDIDATE_NEW_NATIVE_MODE",
            "carrier_family": "D_PLUS_ONE_PART_COUNT_PROPAGATION_BASIN",
            "carrier_id": "SAM-CANDIDATE-NPARTS-4",
            "carrier_scaffolds": "",
            "carrier_source": "R12_D_PLUS_ONE_PART_COUNT_GRAMMAR",
            "carrier_coordinate": "",
            "selector_status": "PART_COUNT_PROPAGATION_SELECTOR_NEEDED",
            "selector_needed": "D_PLUS_ONE_PART_COUNT_SELECTOR",
            "assignment_strength": "N_PARTS_EQUALS_D_PLUS_ONE",
            "assignment_note": (
                f"{exact} has four parts. That points to D+1 propagation grammar, but not to a unique carrier."
            ),
        }

    if contains_d:
        return {
            "classification": "CANDIDATE_COMPOSITE_CARRIER",
            "carrier_family": "D_AXIS_LAYERED_COMPOSITE_BASIN",
            "carrier_id": "SAM-CANDIDATE-D-AXIS",
            "carrier_scaffolds": "",
            "carrier_source": "R12_D_AXIS_GRAMMAR",
            "carrier_coordinate": "",
            "selector_status": "D_AXIS_SELECTOR_NEEDED",
            "selector_needed": "D_AXIS_LAYERED_COMPOSITE_SELECTOR",
            "assignment_strength": "CONTAINS_D_LAYER",
            "assignment_note": f"{exact} contains D=3 and is grouped into the D-axis composite basin.",
        }

    if contains_half and n_parts >= 6:
        return {
            "classification": "CANDIDATE_NEW_NATIVE_MODE",
            "carrier_family": "HALF_CONTACT_RESIDUE_LADDER",
            "carrier_id": "SAM-CANDIDATE-HALF-LADDER",
            "carrier_scaffolds": "",
            "carrier_source": "R12_HALF_CONTACT_GRAMMAR",
            "carrier_coordinate": "",
            "selector_status": "HALF_CONTACT_RESIDUE_SELECTOR_NEEDED",
            "selector_needed": "HALF_CONTACT_RESIDUE_LADDER_SELECTOR",
            "assignment_strength": "HALF_CONTACT_DOMINANT",
            "assignment_note": (
                f"{exact} is dominated by alpha_H=2 and unit residues. It is a native-mode candidate, not "
                "an existing carrier."
            ),
        }

    if contains_alpha2:
        return {
            "classification": "CANDIDATE_COMPOSITE_CARRIER",
            "carrier_family": "ALPHA_H2_ROLE_RESIDUE_BASIN",
            "carrier_id": "SAM-CANDIDATE-ALPHA2",
            "carrier_scaffolds": "",
            "carrier_source": "R12_ALPHA_H2_GRAMMAR",
            "carrier_coordinate": "",
            "selector_status": "ALPHA_H2_RESIDUE_SELECTOR_NEEDED",
            "selector_needed": "ALPHA_H2_ROLE_RESIDUE_SELECTOR",
            "assignment_strength": "CONTAINS_ALPHA_H2_LAYER",
            "assignment_note": f"{exact} contains alpha_H^2=4 and is grouped into the role-residue basin.",
        }

    return {
        "classification": "UNASSIGNED_BOUNDARY",
        "carrier_family": "UNIT_RESIDUE_BOUNDARY",
        "carrier_id": "UNASSIGNED",
        "carrier_scaffolds": "",
        "carrier_source": "R12_LAYERED_GRAMMAR",
        "carrier_coordinate": "",
        "selector_status": "NO_UNIQUE_CARRIER",
        "selector_needed": "UNIT_RESIDUE_ASSIGNMENT_SELECTOR",
        "assignment_strength": "NO_MATCH",
        "assignment_note": (
            f"{exact} has only low-order residue structure after earlier selectors. It remains an unassigned boundary."
        ),
    }


def write_preflight() -> None:
    QP043_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP043 Preflight - Unknown Mode Carrier Assignment

```text
test_id = QP043
test_name = PRIVATE_UNKNOWN_MODE_CARRIER_ASSIGNMENT
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
phase4_tables/phase4_unknown_mode_candidates.csv
phase4_tables/phase4_particle_periodic_matrix.csv
phase4_tables/phase4_parameter_free_particle_table.csv
artifacts/qp022a/qp022a_route_inventory_table.csv
artifacts/qp039/qp039_return_channel_table.csv
artifacts/qp039/qp039_composite_role_queue_table.csv
artifacts/qp041/qp041_meson_fill_table.csv
artifacts/qp041c/qp041c_meson_binding_readout_table.csv
artifacts/qp042/qp042_baryon_fill_table.csv
```

## Expected Outputs

```text
artifacts/qp043/qp043_summary.json
artifacts/qp043/qp043_unknown_mode_assignment_table.csv
artifacts/qp043/qp043_unassigned_mode_boundary_table.csv
docs/reports/QP043_PRIVATE_UNKNOWN_MODE_CARRIER_ASSIGNMENT.md
```

## Forward Question

```text
Do any of the 50 admissible unknown substrate-string modes attach to filled
particle, meson, baryon, or native-mode carrier slots after QP039-QP041C/QP042?
```

This gate assigns carriers by SAM partition grammar and filled private artifacts.
It does not use observed masses or external particle tables.
""",
        encoding="utf-8",
    )


def write_doc(
    summary: dict[str, Any],
    assignment_rows: list[dict[str, Any]],
    carrier_rows: list[dict[str, Any]],
    boundary_rows: list[dict[str, Any]],
) -> None:
    assigned_lines = "\n".join(
        f"| {row['native_id']} | {row['subchannel_partition']} | {row['classification']} | {row['carrier_family']} | {row['carrier_id']} | {row['selector_status']} |"
        for row in assignment_rows[:18]
    )
    carrier_lines = "\n".join(
        f"| {row['carrier_family']} | {row['classification']} | {row['mode_count']} | {row['example_modes']} | {row['selector_needed']} |"
        for row in carrier_rows
    )
    boundary_lines = "\n".join(
        f"| {row['native_id']} | {row['subchannel_partition']} | {row['boundary_class']} | {row['selector_needed']} |"
        for row in boundary_rows[:20]
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP043 - Private Unknown Mode Carrier Assignment

## Preflight

```text
test_id = QP043
test_name = PRIVATE_UNKNOWN_MODE_CARRIER_ASSIGNMENT
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP043 consumes the 50 unknown substrate-string modes and assigns each row to an
existing carrier, a composite carrier basin, a new native-mode candidate, or a
remaining boundary.

## Key Fields

```text
unknown_mode_rows = {summary['unknown_mode_rows']}
assigned_existing_carrier_rows = {summary['assigned_existing_carrier_rows']}
candidate_composite_carrier_rows = {summary['candidate_composite_carrier_rows']}
candidate_new_native_mode_rows = {summary['candidate_new_native_mode_rows']}
unassigned_boundary_rows = {summary['unassigned_boundary_rows']}
unique_existing_carriers_selected = {summary['unique_existing_carriers_selected']}
observed_masses_used = {summary['observed_masses_used']}
external_data_used = {summary['external_data_used']}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## First Assignment Rows

| native id | partition | class | carrier family | carrier id | selector status |
| --- | --- | --- | --- | --- | --- |
{assigned_lines}

## Carrier Family Summary

| carrier family | class | modes | examples | selector needed |
| --- | --- | ---: | --- | --- |
{carrier_lines}

## Boundary Rows

| native id | partition | boundary class | selector needed |
| --- | --- | --- | --- |
{boundary_lines}

## Interpretation

QP043 closes the first exact unknown-mode carrier: `(8,4)` now attaches to the
selected QP039 `c<->t` local-return channel and the QP041C oriented binding
readouts. The remaining rows are no longer blank in the same way: they are
sorted into transition, D-axis, charged-role, propagation, half-contact, and
microcell basins, each with one named selector.
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    unknown_rows = read_csv(UNKNOWN_MODES)
    particle_rows = read_csv(PARTICLE_TABLE)
    particle_matrix = read_csv(PARTICLE_MATRIX)
    route_rows = read_csv(QP022A_ROUTE_INVENTORY)
    return_rows = read_csv(QP039_RETURN)
    queue_rows = read_csv(QP039_QUEUE)
    meson_rows = read_csv(QP041_MESON_FILL)
    binding_rows = read_csv(QP041C_BINDING)
    baryon_rows = read_csv(QP042_BARYON_FILL)
    context = carrier_context(return_rows, queue_rows, meson_rows, binding_rows, baryon_rows, route_rows)

    assignment_rows: list[dict[str, Any]] = []
    for row in unknown_rows:
        assigned = classify_mode(row, context)
        parts = parse_partition(row["subchannel_partition"])
        assignment_rows.append(
            {
                "native_id": row["native_id"],
                "native_family": row["native_family"],
                "subchannel_partition": row["subchannel_partition"],
                "partition_terms": ";".join(str(part) for part in parts),
                "n_parts": len(parts),
                "has_part_8": int(8 in parts),
                "has_part_4": int(4 in parts),
                "has_part_3": int(3 in parts),
                "has_part_2": int(2 in parts),
                "shape_class": row["ownership_class"],
                "classification": assigned["classification"],
                "carrier_family": assigned["carrier_family"],
                "carrier_id": assigned["carrier_id"],
                "carrier_scaffolds": assigned["carrier_scaffolds"],
                "carrier_source": assigned["carrier_source"],
                "carrier_coordinate": assigned["carrier_coordinate"],
                "selector_status": assigned["selector_status"],
                "selector_needed": assigned["selector_needed"],
                "assignment_strength": assigned["assignment_strength"],
                "assignment_note": one_line(assigned["assignment_note"]),
            }
        )

    boundary_rows = [
        {
            "native_id": row["native_id"],
            "subchannel_partition": row["subchannel_partition"],
            "boundary_class": row["classification"],
            "carrier_family": row["carrier_family"],
            "selector_needed": row["selector_needed"],
            "boundary_note": row["assignment_note"],
        }
        for row in assignment_rows
        if row["classification"] != "ASSIGNED_EXISTING_CARRIER"
    ]

    families: dict[tuple[str, str], list[dict[str, Any]]] = {}
    for row in assignment_rows:
        families.setdefault((row["classification"], row["carrier_family"]), []).append(row)
    carrier_rows: list[dict[str, Any]] = []
    for (classification, carrier_family), rows in sorted(families.items(), key=lambda item: (item[0][0], item[0][1])):
        selectors = sorted({str(row["selector_needed"]) for row in rows})
        carrier_rows.append(
            {
                "classification": classification,
                "carrier_family": carrier_family,
                "mode_count": len(rows),
                "example_modes": ";".join(str(row["native_id"]) for row in rows[:5]),
                "selector_needed": ";".join(selectors),
            }
        )

    class_counts = Counter(str(row["classification"]) for row in assignment_rows)
    carrier_counts = Counter(str(row["carrier_family"]) for row in assignment_rows)
    summary = {
        "artifact": "QP043_PRIVATE_UNKNOWN_MODE_CARRIER_ASSIGNMENT",
        "result_class": "QP043_UNKNOWN_MODE_CARRIERS_ORGANIZED_ONE_EXACT_ASSIGNED",
        "campaign_status": "QP043_UNKNOWN_MODE_ASSIGNMENT_COMPLETE_QP044_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_masses_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            str(UNKNOWN_MODES.relative_to(ROOT)),
            str(PARTICLE_MATRIX.relative_to(ROOT)),
            str(PARTICLE_TABLE.relative_to(ROOT)),
            str(QP022A_ROUTE_INVENTORY.relative_to(ROOT)),
            str(QP039_RETURN.relative_to(ROOT)),
            str(QP039_QUEUE.relative_to(ROOT)),
            str(QP041_MESON_FILL.relative_to(ROOT)),
            str(QP041C_BINDING.relative_to(ROOT)),
            str(QP042_BARYON_FILL.relative_to(ROOT)),
        ],
        "particle_rows_consumed": len(particle_rows),
        "particle_matrix_rows_consumed": len(particle_matrix),
        "return_channels_consumed": len(return_rows),
        "meson_support_rows_consumed": len(meson_rows),
        "meson_binding_rows_consumed": len(binding_rows),
        "baryon_rows_consumed": len(baryon_rows),
        "unknown_mode_rows": len(assignment_rows),
        "assigned_existing_carrier_rows": class_counts["ASSIGNED_EXISTING_CARRIER"],
        "candidate_composite_carrier_rows": class_counts["CANDIDATE_COMPOSITE_CARRIER"],
        "candidate_new_native_mode_rows": class_counts["CANDIDATE_NEW_NATIVE_MODE"],
        "unassigned_boundary_rows": class_counts["UNASSIGNED_BOUNDARY"],
        "class_counts": dict(class_counts),
        "carrier_family_counts": dict(carrier_counts),
        "unique_existing_carriers_selected": "QP039-RC-001:c<->t",
        "exact_assigned_modes": ";".join(
            str(row["native_id"]) for row in assignment_rows if row["classification"] == "ASSIGNED_EXISTING_CARRIER"
        ),
        "unassigned_mode_ids": ";".join(
            str(row["native_id"]) for row in assignment_rows if row["classification"] == "UNASSIGNED_BOUNDARY"
        ),
        "next_frontier": "QP044_PRIVATE_PHASE4_TABLE_REFRESH",
        "interpretation": (
            "QP043 assigns the exact (8,4) unknown mode to the selected c<->t return carrier and organizes "
            "the remaining unknown modes into named carrier basins or native-mode selector frontiers."
        ),
    }

    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "new carrier assignment gate; not audit, not retest, no public write",
        },
        {
            "decision_point": "exact_existing_carrier_assignment",
            "decision": "PASS_ONE_EXACT_CARRIER",
            "note": "SAM-UNK-001 (8,4) attaches to QP039-RC-001 and QP041C c<->t oriented readouts",
        },
        {
            "decision_point": "unknown_table_reduction",
            "decision": "PASS_ORGANIZED_BOUNDARIES",
            "note": "all unknown rows now carry a carrier family and one selector-needed label",
        },
    ]
    next_rows = [
        {
            "next_frontier": "QP044_PRIVATE_PHASE4_TABLE_REFRESH",
            "why_next": "QP043 organized the unknown-mode table; Phase 4 tables can now refresh with filled/basin/boundary status.",
            "launch_from": "qp043_unknown_mode_assignment_table.csv",
            "target_output": "phase4 table v2 freeze and blank registry refresh",
        }
    ]
    schema_rows = [
        {
            "field": "ASSIGNED_EXISTING_CARRIER",
            "meaning": "unique filled carrier selected by exact partition grammar and filled artifacts",
            "class": "classification",
        },
        {
            "field": "CANDIDATE_COMPOSITE_CARRIER",
            "meaning": "mode points at an existing composite carrier basin but needs a unique selector",
            "class": "classification",
        },
        {
            "field": "CANDIDATE_NEW_NATIVE_MODE",
            "meaning": "mode is organized as native propagation/contact/microcell grammar, not an existing carrier",
            "class": "classification",
        },
        {
            "field": "UNASSIGNED_BOUNDARY",
            "meaning": "mode remains a low-order residue boundary after carrier assignment",
            "class": "classification",
        },
    ]

    write_json(SUMMARY_OUT, summary)
    write_csv(
        ASSIGNMENT_OUT,
        assignment_rows,
        [
            "native_id",
            "native_family",
            "subchannel_partition",
            "partition_terms",
            "n_parts",
            "has_part_8",
            "has_part_4",
            "has_part_3",
            "has_part_2",
            "shape_class",
            "classification",
            "carrier_family",
            "carrier_id",
            "carrier_scaffolds",
            "carrier_source",
            "carrier_coordinate",
            "selector_status",
            "selector_needed",
            "assignment_strength",
            "assignment_note",
        ],
    )
    write_csv(
        BOUNDARY_OUT,
        boundary_rows,
        [
            "native_id",
            "subchannel_partition",
            "boundary_class",
            "carrier_family",
            "selector_needed",
            "boundary_note",
        ],
    )
    write_csv(
        CARRIER_SUMMARY_OUT,
        carrier_rows,
        ["classification", "carrier_family", "mode_count", "example_modes", "selector_needed"],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, assignment_rows, carrier_rows, boundary_rows)

    print(summary["result_class"])
    print(f"assigned_existing_carrier_rows={summary['assigned_existing_carrier_rows']}")
    print(f"candidate_composite_carrier_rows={summary['candidate_composite_carrier_rows']}")
    print(f"candidate_new_native_mode_rows={summary['candidate_new_native_mode_rows']}")
    print(f"unassigned_boundary_rows={summary['unassigned_boundary_rows']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
