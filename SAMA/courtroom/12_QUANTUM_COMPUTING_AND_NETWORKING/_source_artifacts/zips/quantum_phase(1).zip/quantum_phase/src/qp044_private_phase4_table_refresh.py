from __future__ import annotations

import csv
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

PARTICLE_TABLE = PHASE4 / "phase4_parameter_free_particle_table.csv"
PARTICLE_MATRIX = PHASE4 / "phase4_particle_periodic_matrix.csv"
COMPOSITE_SUPPORT = PHASE4 / "phase4_composite_support_table.csv"
COMPOSITE_SCAFFOLD = PHASE4 / "phase4_composite_scaffold_table.csv"
ELEMENT_ATLAS = PHASE4 / "phase4_element_periodic_atlas.csv"
UNKNOWN_CANDIDATES = PHASE4 / "phase4_unknown_mode_candidates.csv"
OLD_BLANK_REGISTRY = PHASE4 / "phase4_blank_registry.csv"

QP039_SUMMARY = ARTIFACTS / "qp039" / "qp039_summary.json"
QP040_SUMMARY = ARTIFACTS / "qp040" / "qp040_summary.json"
QP041_SUMMARY = ARTIFACTS / "qp041" / "qp041_summary.json"
QP041B_SUMMARY = ARTIFACTS / "qp041b" / "qp041b_summary.json"
QP041C_SUMMARY = ARTIFACTS / "qp041c" / "qp041c_summary.json"
QP042_SUMMARY = ARTIFACTS / "qp042" / "qp042_summary.json"
QP043_SUMMARY = ARTIFACTS / "qp043" / "qp043_summary.json"

QP039_RETURN = ARTIFACTS / "qp039" / "qp039_return_channel_table.csv"
QP040_OPERATOR = ARTIFACTS / "qp040" / "qp040_binding_residue_operator_table.csv"
QP041_MESON_FILL = ARTIFACTS / "qp041" / "qp041_meson_fill_table.csv"
QP041_MESON_BOUNDARY = ARTIFACTS / "qp041" / "qp041_meson_open_boundary_table.csv"
QP041C_BINDING = ARTIFACTS / "qp041c" / "qp041c_meson_binding_readout_table.csv"
QP042_BARYON_FILL = ARTIFACTS / "qp042" / "qp042_baryon_fill_table.csv"
QP042_BARYON_BOUNDARY = ARTIFACTS / "qp042" / "qp042_baryon_open_boundary_table.csv"
QP043_ASSIGNMENT = ARTIFACTS / "qp043" / "qp043_unknown_mode_assignment_table.csv"
QP043_CARRIER_SUMMARY = ARTIFACTS / "qp043" / "qp043_carrier_family_summary_table.csv"

QP044_DIR = ARTIFACTS / "qp044"
PREFLIGHT_OUT = QP044_DIR / "qp044_preflight.md"
SUMMARY_OUT = QP044_DIR / "qp044_summary.json"
FREEZE_OUT = PHASE4 / "phase4_particle_composite_freeze_v2.csv"
BLANK_REGISTRY_OUT = PHASE4 / "phase4_blank_registry_v2.csv"
TABLE_INDEX_OUT = PHASE4 / "phase4_table_index_v2.csv"
SUMMARY_V2_OUT = PHASE4 / "phase4_summary_v2.json"
DELTA_OUT = QP044_DIR / "qp044_phase4_delta_table.csv"
DECISION_OUT = QP044_DIR / "qp044_decision_table.csv"
NEXT_OUT = QP044_DIR / "qp044_next_frontier.csv"
SCHEMA_OUT = QP044_DIR / "qp044_schema.csv"
DOC_OUT = REPORTS / "QP044_PRIVATE_PHASE4_TABLE_REFRESH.md"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def short_float(value: str) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value)
    if number == 0:
        return "0"
    if abs(number) >= 1000 or abs(number) < 0.001:
        return f"{number:.12e}"
    return f"{number:.12g}"


def one_line(text: Any) -> str:
    return " ".join(str(text if text is not None else "").split())


def write_preflight() -> None:
    QP044_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP044 Preflight - Phase 4 Table Refresh

```text
test_id = QP044
test_name = PRIVATE_PHASE4_TABLE_REFRESH
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
QP039-QP043 private artifacts
phase4_tables/*.csv
phase4_tables/*.png
```

## Expected Outputs

```text
artifacts/qp044/qp044_summary.json
phase4_tables/phase4_particle_composite_freeze_v2.csv
phase4_tables/phase4_blank_registry_v2.csv
phase4_tables/phase4_table_index_v2.csv
phase4_tables/phase4_summary_v2.json
docs/reports/QP044_PRIVATE_PHASE4_TABLE_REFRESH.md
```

## Forward Question

```text
How many blanks were filled after QP039-QP043, and what exact selector remains
for each still-open Phase 4 branch?
```

This gate packages current Phase 4 state. It does not retest earlier gates and
does not use external observed masses.
""",
        encoding="utf-8",
    )


def freeze_rows() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []

    for row in read_csv(PARTICLE_TABLE):
        rows.append(
            {
                "freeze_id": f"ELEM-{row['native_id']}",
                "layer": "elementary_particle",
                "object_id": row["native_id"],
                "symbol_or_scaffold": row["symbol"],
                "partition_or_route": row["subchannel_partition"],
                "status": "FILLED_PARAMETER_FREE",
                "classification": row["parameter_free_grade"],
                "native_readout_MeV": short_float(row["mass_MeV"]),
                "selector_needed": "NONE",
                "source": "phase4_parameter_free_particle_table.csv",
                "note": f"{row['symbol']} frozen elementary row",
            }
        )

    for row in read_csv(QP041_MESON_FILL):
        rows.append(
            {
                "freeze_id": f"MESON-SUPPORT-{row['scaffold_id']}",
                "layer": "meson_support_readout",
                "object_id": row["support_family"],
                "symbol_or_scaffold": row["scaffold_id"],
                "partition_or_route": row["constituents"],
                "status": row["fill_status"],
                "classification": row["operator_class"],
                "native_readout_MeV": short_float(row["sam_mass_MeV"]),
                "selector_needed": "NONE",
                "source": "artifacts/qp041/qp041_meson_fill_table.csv",
                "note": f"{row['symbol']} support-family readout filled",
            }
        )

    for row in read_csv(QP041C_BINDING):
        rows.append(
            {
                "freeze_id": f"MESON-BINDING-{row['scaffold_id']}",
                "layer": "meson_binding_coordinate",
                "object_id": row["suk055_pair"],
                "symbol_or_scaffold": row["scaffold_id"],
                "partition_or_route": row["phase_role_operator"],
                "status": row["binding_readout_status"],
                "classification": row["residue_selector_class"],
                "native_readout_MeV": short_float(row["native_binding_readout_MeV"]),
                "selector_needed": "NONE",
                "source": "artifacts/qp041c/qp041c_meson_binding_readout_table.csv",
                "note": "native binding/readout coordinate emitted",
            }
        )

    for row in read_csv(QP042_BARYON_FILL):
        rows.append(
            {
                "freeze_id": f"BARYON-{row['scaffold_id']}",
                "layer": "baryon_readout",
                "object_id": row["support_family"],
                "symbol_or_scaffold": row["scaffold_id"],
                "partition_or_route": row["constituents"],
                "status": row["fill_status"],
                "classification": row["operator_class"],
                "native_readout_MeV": short_float(row["sam_mass_MeV"]),
                "selector_needed": "NONE",
                "source": "artifacts/qp042/qp042_baryon_fill_table.csv",
                "note": f"{row['symbol']} baryon scaffold readout filled",
            }
        )

    for row in read_csv(QP043_ASSIGNMENT):
        readout = row["carrier_coordinate"]
        rows.append(
            {
                "freeze_id": f"UNKNOWN-{row['native_id']}",
                "layer": "unknown_mode_assignment",
                "object_id": row["native_id"],
                "symbol_or_scaffold": row["carrier_id"],
                "partition_or_route": row["subchannel_partition"],
                "status": row["classification"],
                "classification": row["carrier_family"],
                "native_readout_MeV": readout,
                "selector_needed": row["selector_needed"],
                "source": "artifacts/qp043/qp043_unknown_mode_assignment_table.csv",
                "note": row["assignment_note"],
            }
        )

    return rows


def blank_registry_rows(summary: dict[str, Any]) -> list[dict[str, Any]]:
    meson_boundary = read_csv(QP041_MESON_BOUNDARY)
    baryon_boundary = read_csv(QP042_BARYON_BOUNDARY)
    unknown_assignment = read_csv(QP043_ASSIGNMENT)
    carrier_summary = read_csv(QP043_CARRIER_SUMMARY)

    meson_after_qp041c = [
        row
        for row in meson_boundary
        if row["boundary_class"]
        not in {
            "CANDIDATE_MESON_READOUT_ROLE_SCALE_SELECTOR_NEEDED",
            "CANDIDATE_RETURN_CHANNEL_BINDING_SELECTOR_NEEDED",
        }
    ]
    meson_boundary_counts = Counter(row["boundary_class"] for row in meson_after_qp041c)
    baryon_counts = Counter(row["boundary_class"] for row in baryon_boundary)

    rows: list[dict[str, Any]] = [
        {
            "branch": "elementary_particle_surface",
            "total_rows": summary["particle_rows"],
            "filled_rows": summary["particle_rows"],
            "open_rows": 0,
            "status": "FROZEN_PARAMETER_FREE",
            "selector_needed": "NONE",
            "source": "phase4_parameter_free_particle_table.csv",
            "note": "13 elementary rows remain filled after Phase 4 refresh",
        },
        {
            "branch": "meson_scaffold_support_and_binding",
            "total_rows": 36,
            "filled_rows": summary["unique_meson_scaffolds_touched"],
            "open_rows": 36 - summary["unique_meson_scaffolds_touched"],
            "status": "PARTIAL_FILL_WITH_BINDING_COORDINATES",
            "selector_needed": "NEUTRAL_SELF_CHANNEL_OR_LOCAL_RETURN_OR_ROLE_AXIS_SELECTOR",
            "source": "QP041 + QP041C",
            "note": f"remaining meson boundary counts: {dict(meson_boundary_counts)}",
        },
        {
            "branch": "baryon_scaffold_readout",
            "total_rows": 56,
            "filled_rows": summary["baryon_filled_rows"],
            "open_rows": 56 - summary["baryon_filled_rows"],
            "status": "PARTIAL_FILL_LIGHT_BARYON_SUPPORT",
            "selector_needed": "STRANGE_CHARM_BOTTOM_TOP_BARYON_ROLE_SCALE_SELECTOR",
            "source": "QP042",
            "note": f"remaining baryon boundary counts: {dict(baryon_counts)}",
        },
        {
            "branch": "unknown_mode_carrier_assignment",
            "total_rows": summary["unknown_mode_rows"],
            "filled_rows": summary["unknown_exact_carrier_rows"],
            "open_rows": summary["unknown_mode_rows"] - summary["unknown_exact_carrier_rows"],
            "status": "ONE_EXACT_CARRIER_PLUS_ORGANIZED_BASINS",
            "selector_needed": "SEE_QP043_CARRIER_FAMILY_SUMMARY",
            "source": "QP043",
            "note": "all unknown modes now carry a carrier family or native-mode selector label",
        },
        {
            "branch": "a_share_microcell_lattice",
            "total_rows": 1,
            "filled_rows": 0,
            "open_rows": 1,
            "status": "NEXT_PIXEL_SCALE_FRONTIER",
            "selector_needed": "A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR",
            "source": "QP043 SAM-UNK-050",
            "note": "twelve unit microcells need a native coarse-grain law into one A-share/write structure",
        },
        {
            "branch": "element_isotope_a_road",
            "total_rows": summary["element_rows"],
            "filled_rows": 0,
            "open_rows": summary["element_rows"],
            "status": "OPEN_AFTER_PARTICLE_COMPOSITE_REFRESH",
            "selector_needed": "NUCLEAR_BINDING_AND_ISOTOPE_A_ROAD_SELECTOR",
            "source": "phase4_element_periodic_atlas.csv",
            "note": "campaign file still lists this as QP045, but QP044 recommends microcell selector first",
        },
    ]

    for row in carrier_summary:
        if row["classification"] == "ASSIGNED_EXISTING_CARRIER":
            continue
        rows.append(
            {
                "branch": f"unknown_mode::{row['carrier_family']}",
                "total_rows": row["mode_count"],
                "filled_rows": 0,
                "open_rows": row["mode_count"],
                "status": row["classification"],
                "selector_needed": row["selector_needed"],
                "source": "artifacts/qp043/qp043_carrier_family_summary_table.csv",
                "note": f"examples: {row['example_modes']}",
            }
        )
    return rows


def write_doc(summary: dict[str, Any], delta_rows: list[dict[str, Any]], registry_rows: list[dict[str, Any]]) -> None:
    delta_lines = "\n".join(
        f"| {row['surface']} | {row['before']} | {row['after']} | {row['delta']} |"
        for row in delta_rows
    )
    registry_lines = "\n".join(
        f"| {row['branch']} | {row['filled_rows']} | {row['open_rows']} | {row['status']} | {row['selector_needed']} |"
        for row in registry_rows[:12]
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP044 - Private Phase 4 Table Refresh

## Preflight

```text
test_id = QP044
test_name = PRIVATE_PHASE4_TABLE_REFRESH
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP044 freezes the Phase 4 table package after QP039-QP043. The table now has
one combined v2 freeze surface and a v2 blank registry with named selectors.

## Key Fields

```text
freeze_rows = {summary['freeze_rows']}
elementary_particle_rows = {summary['particle_rows']}
unique_meson_scaffolds_touched = {summary['unique_meson_scaffolds_touched']}
meson_binding_coordinate_rows = {summary['meson_binding_coordinate_rows']}
baryon_filled_rows = {summary['baryon_filled_rows']}
unknown_exact_carrier_rows = {summary['unknown_exact_carrier_rows']}
unknown_composite_basin_rows = {summary['unknown_composite_basin_rows']}
unknown_native_candidate_rows = {summary['unknown_native_candidate_rows']}
unknown_unassigned_boundary_rows = {summary['unknown_unassigned_boundary_rows']}
next_frontier = {summary['next_frontier']}
```

## Phase 4 Delta

| surface | before | after | delta |
| --- | ---: | ---: | --- |
{delta_lines}

## Blank Registry Preview

| branch | filled | open | status | selector needed |
| --- | ---: | ---: | --- | --- |
{registry_lines}

## Interpretation

The freeze surface is no longer just elementary particles plus empty composite
scaffolds. It now carries the QP039 return bridge, QP040 binding operator,
QP041/QP041C meson readouts, QP042 baryon fills, and QP043 unknown-mode carrier
assignment. The sharpest next physics selector is the pixel-scale one:

```text
A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR
```

That selector asks how `SAM-UNK-050 = (1,1,1,1,1,1,1,1,1,1,1,1)` coarse-grains
into one meaningful A-share/write structure.
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    qp039 = read_json(QP039_SUMMARY)
    qp040 = read_json(QP040_SUMMARY)
    qp041 = read_json(QP041_SUMMARY)
    qp041b = read_json(QP041B_SUMMARY)
    qp041c = read_json(QP041C_SUMMARY)
    qp042 = read_json(QP042_SUMMARY)
    qp043 = read_json(QP043_SUMMARY)

    particle_rows = read_csv(PARTICLE_TABLE)
    particle_matrix = read_csv(PARTICLE_MATRIX)
    element_rows = read_csv(ELEMENT_ATLAS)
    unknown_candidates = read_csv(UNKNOWN_CANDIDATES)
    meson_fill = read_csv(QP041_MESON_FILL)
    meson_binding = read_csv(QP041C_BINDING)
    baryon_fill = read_csv(QP042_BARYON_FILL)
    unknown_assignment = read_csv(QP043_ASSIGNMENT)

    unique_meson_scaffolds = sorted({row["scaffold_id"] for row in meson_fill} | {row["scaffold_id"] for row in meson_binding})
    freeze = freeze_rows()

    summary = {
        "artifact": "QP044_PRIVATE_PHASE4_TABLE_REFRESH",
        "result_class": "QP044_PHASE4_TABLES_REFRESHED_QP045_MICROCELL_SELECTOR_RECOMMENDED",
        "campaign_status": "QP044_TABLE_REFRESH_COMPLETE_QP045_MICROCELL_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_masses_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "QP039-QP043 private artifacts",
            "phase4_tables/phase4_parameter_free_particle_table.csv",
            "phase4_tables/phase4_composite_scaffold_table.csv",
            "phase4_tables/phase4_unknown_mode_candidates.csv",
        ],
        "qp039_result_class": qp039["result_class"],
        "qp040_result_class": qp040["result_class"],
        "qp041_result_class": qp041["result_class"],
        "qp041b_result_class": qp041b["result_class"],
        "qp041c_result_class": qp041c["result_class"],
        "qp042_result_class": qp042["result_class"],
        "qp043_result_class": qp043["result_class"],
        "freeze_rows": len(freeze),
        "particle_rows": len(particle_rows),
        "particle_matrix_rows": len(particle_matrix),
        "element_rows": len(element_rows),
        "unknown_candidate_rows": len(unknown_candidates),
        "unique_meson_scaffolds_touched": len(unique_meson_scaffolds),
        "meson_support_readout_rows": len(meson_fill),
        "meson_binding_coordinate_rows": len(meson_binding),
        "baryon_filled_rows": len(baryon_fill),
        "unknown_mode_rows": len(unknown_assignment),
        "unknown_exact_carrier_rows": qp043["assigned_existing_carrier_rows"],
        "unknown_composite_basin_rows": qp043["candidate_composite_carrier_rows"],
        "unknown_native_candidate_rows": qp043["candidate_new_native_mode_rows"],
        "unknown_unassigned_boundary_rows": qp043["unassigned_boundary_rows"],
        "sam_unk_050_status": "TWELVE_MICROCELL_A_SHARE_LATTICE",
        "sam_unk_050_selector": "A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR",
        "next_frontier": "QP045_PRIVATE_A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR",
        "interpretation": (
            "QP044 refreshes Phase 4 into a v2 table package and recommends the A-share microcell coarse-grain "
            "selector as the next physics gate from SAM-UNK-050."
        ),
    }

    registry = blank_registry_rows(summary)
    delta_rows = [
        {
            "surface": "elementary_particle_rows",
            "before": 13,
            "after": summary["particle_rows"],
            "delta": summary["particle_rows"] - 13,
        },
        {
            "surface": "meson_scaffolds_touched",
            "before": 0,
            "after": summary["unique_meson_scaffolds_touched"],
            "delta": summary["unique_meson_scaffolds_touched"],
        },
        {
            "surface": "meson_binding_coordinates",
            "before": 0,
            "after": summary["meson_binding_coordinate_rows"],
            "delta": summary["meson_binding_coordinate_rows"],
        },
        {
            "surface": "baryon_filled_rows",
            "before": 0,
            "after": summary["baryon_filled_rows"],
            "delta": summary["baryon_filled_rows"],
        },
        {
            "surface": "unknown_exact_carriers",
            "before": 0,
            "after": summary["unknown_exact_carrier_rows"],
            "delta": summary["unknown_exact_carrier_rows"],
        },
        {
            "surface": "unknown_modes_with_named_family",
            "before": 0,
            "after": summary["unknown_mode_rows"],
            "delta": summary["unknown_mode_rows"],
        },
    ]
    table_index = [
        {
            "table_file": "phase4_particle_composite_freeze_v2.csv",
            "rows": len(freeze),
            "purpose": "combined Phase 4 filled/candidate/boundary freeze after QP039-QP043",
            "png_use": "source for refreshed composite package",
        },
        {
            "table_file": "phase4_blank_registry_v2.csv",
            "rows": len(registry),
            "purpose": "remaining branch selectors after QP044",
            "png_use": "roadmap/selector legend",
        },
        {
            "table_file": "phase4_table_index_v2.csv",
            "rows": 6,
            "purpose": "index for v2 private table package",
            "png_use": "table package manifest",
        },
        {
            "table_file": "phase4_summary_v2.json",
            "rows": 1,
            "purpose": "machine-readable QP044 package summary",
            "png_use": "summary cards",
        },
        {
            "table_file": "phase4_qp043_unknown_mode_assignment_table.png",
            "rows": summary["unknown_mode_rows"],
            "purpose": "QP043 visual unknown-mode reduction",
            "png_use": "primary unknown-mode visual",
        },
        {
            "table_file": "phase4_qp043_carrier_family_summary.png",
            "rows": len(read_csv(QP043_CARRIER_SUMMARY)),
            "purpose": "QP043 carrier family summary",
            "png_use": "carrier basin visual",
        },
    ]

    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "table refresh package; not audit, not retest, no public write",
        },
        {
            "decision_point": "phase4_v2_freeze",
            "decision": "PASS_REFRESHED_FREEZE_SURFACE",
            "note": "combined elementary, meson, baryon, and unknown-mode assignments into one v2 surface",
        },
        {
            "decision_point": "next_physics_gate",
            "decision": "SELECT_MICROCELL_COARSE_GRAIN_SELECTOR",
            "note": "SAM-UNK-050 supplies the pixel-scale next selector",
        },
    ]
    next_rows = [
        {
            "next_frontier": "QP045_PRIVATE_A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR",
            "why_next": "SAM-UNK-050 is the unique twelve-microcell A-share lattice row exposed by QP043.",
            "launch_from": "phase4_blank_registry_v2.csv;qp043_unknown_mode_assignment_table.csv",
            "target_output": "native coarse-grain law for twelve unit cells to one A-share/write structure",
        }
    ]
    schema_rows = [
        {
            "field": "freeze_id",
            "meaning": "stable row identifier in the v2 combined freeze surface",
            "class": "phase4_particle_composite_freeze_v2",
        },
        {
            "field": "selector_needed",
            "meaning": "NONE for filled rows or one named selector for still-open rows",
            "class": "phase4_blank_registry_v2",
        },
        {
            "field": "A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR",
            "meaning": "next native selector for SAM-UNK-050 twelve-unit microcell lattice",
            "class": "next_frontier",
        },
    ]

    write_csv(
        FREEZE_OUT,
        freeze,
        [
            "freeze_id",
            "layer",
            "object_id",
            "symbol_or_scaffold",
            "partition_or_route",
            "status",
            "classification",
            "native_readout_MeV",
            "selector_needed",
            "source",
            "note",
        ],
    )
    write_csv(
        BLANK_REGISTRY_OUT,
        registry,
        ["branch", "total_rows", "filled_rows", "open_rows", "status", "selector_needed", "source", "note"],
    )
    write_csv(TABLE_INDEX_OUT, table_index, ["table_file", "rows", "purpose", "png_use"])
    write_json(SUMMARY_V2_OUT, summary)
    write_json(SUMMARY_OUT, summary)
    write_csv(DELTA_OUT, delta_rows, ["surface", "before", "after", "delta"])
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, delta_rows, registry)

    print(summary["result_class"])
    print(f"freeze_rows={summary['freeze_rows']}")
    print(f"unique_meson_scaffolds_touched={summary['unique_meson_scaffolds_touched']}")
    print(f"unknown_exact_carrier_rows={summary['unknown_exact_carrier_rows']}")
    print(f"sam_unk_050_selector={summary['sam_unk_050_selector']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
