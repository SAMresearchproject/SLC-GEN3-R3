from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

QP001_SUMMARY = ARTIFACTS / "qp001" / "qp001_phase_functional_summary.json"
QP043_ASSIGNMENT = ARTIFACTS / "qp043" / "qp043_unknown_mode_assignment_table.csv"
QP044_SUMMARY = ARTIFACTS / "qp044" / "qp044_summary.json"
PARTICLE_TABLE = PHASE4 / "phase4_parameter_free_particle_table.csv"

QP045_DIR = ARTIFACTS / "qp045"
PREFLIGHT_OUT = QP045_DIR / "qp045_preflight.md"
SUMMARY_OUT = QP045_DIR / "qp045_summary.json"
COARSE_GRAIN_OUT = QP045_DIR / "qp045_microcell_coarse_grain_table.csv"
SELECTOR_LADDER_OUT = QP045_DIR / "qp045_selector_ladder.csv"
UNIFORM_MAP_OUT = QP045_DIR / "qp045_uniform_partition_map.csv"
DECISION_OUT = QP045_DIR / "qp045_decision_table.csv"
NEXT_OUT = QP045_DIR / "qp045_next_frontier.csv"
SCHEMA_OUT = QP045_DIR / "qp045_schema.csv"
DOC_OUT = REPORTS / "QP045_PRIVATE_A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR.md"


R = 12
A_SIDE = Fraction(1, 24)
A_SHARE = Fraction(1, 12)
A_WRITE_MIDPOINT = Fraction(1, 2)
A_FULL = Fraction(1, 1)
A_CELL = A_SHARE / R


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def frac_text(value: Fraction) -> str:
    return f"{value.numerator}/{value.denominator}" if value.denominator != 1 else str(value.numerator)


def dec_text(value: Fraction) -> str:
    return f"{float(value):.15g}"


def partition_text(group_count: int, group_size: int) -> str:
    return "(" + ",".join(str(group_size) for _ in range(group_count)) + ("," if group_count == 1 else "") + ")"


def write_preflight() -> None:
    QP045_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP045 Preflight - A-share Microcell Coarse-Grain Selector

```text
test_id = QP045
test_name = PRIVATE_A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp001/qp001_phase_functional_summary.json
artifacts/qp043/qp043_unknown_mode_assignment_table.csv
artifacts/qp044/qp044_summary.json
phase4_tables/phase4_parameter_free_particle_table.csv
```

## Expected Outputs

```text
artifacts/qp045/qp045_summary.json
artifacts/qp045/qp045_microcell_coarse_grain_table.csv
artifacts/qp045/qp045_selector_ladder.csv
artifacts/qp045/qp045_uniform_partition_map.csv
docs/reports/QP045_PRIVATE_A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR.md
```

## Forward Question

```text
How does SAM-UNK-050, the uniform 12 microcell lattice, coarse-grain into one
meaningful A-share/write structure?
```

This gate selects a native coarse-grain law from R=12 and QP001 thresholds. It
does not use observed masses or external particle data.
""",
        encoding="utf-8",
    )


def uniform_partition_map(particle_rows: list[dict[str, str]], assignment_rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    particles_by_partition: dict[str, list[str]] = {}
    for row in particle_rows:
        particles_by_partition.setdefault(row["subchannel_partition"], []).append(row["symbol"])

    assignment_by_partition = {row["subchannel_partition"]: row for row in assignment_rows}
    rows: list[dict[str, Any]] = []
    specs = [
        (12, 1, "raw_microcell_lattice"),
        (6, 2, "six_half_contact_route"),
        (4, 3, "D_plus_one_propagation_candidate"),
        (3, 4, "triadic_particle_screen"),
        (2, 6, "outer_binary_scalar_return"),
        (1, 12, "single_block_integer_winding"),
    ]
    for group_count, group_size, role in specs:
        partition = partition_text(group_count, group_size)
        matched_particles = ";".join(particles_by_partition.get(partition, []))
        matched_unknown = assignment_by_partition.get(partition, {})
        rows.append(
            {
                "group_count": group_count,
                "group_size": group_size,
                "partition": partition,
                "microcell_count": group_count * group_size,
                "A_total_fraction": frac_text(A_SHARE),
                "A_total_decimal": dec_text(A_SHARE),
                "coarse_grain_role": role,
                "matched_particle_symbols": matched_particles,
                "matched_unknown_mode": matched_unknown.get("native_id", ""),
                "matched_unknown_family": matched_unknown.get("carrier_family", ""),
                "selector_reading": (
                    "same A-share total; partition geometry selects lane family, not total A magnitude"
                ),
            }
        )
    return rows


def selector_ladder() -> list[dict[str, Any]]:
    specs = [
        (1, "MICROCELL_UNIT", "one unresolved unit cell"),
        (6, "A_SIDE_WRITE_ONSET", "half-share boundary; write candidacy begins"),
        (12, "A_SHARE_WRITE_ACCESS", "one full share; meaningful write structure"),
        (48, "QG_BOUNDARY_START", "QP001 qg boundary start = 1/3"),
        (72, "WRITE_MIDPOINT", "classical ledger midpoint"),
        (144, "A_FULL_CLOSURE", "full closure of 12 A-share packets"),
    ]
    rows: list[dict[str, Any]] = []
    for microcells, threshold, meaning in specs:
        A_value = Fraction(microcells, R * R)
        rows.append(
            {
                "microcells": microcells,
                "A_fraction": frac_text(A_value),
                "A_decimal": dec_text(A_value),
                "threshold": threshold,
                "meaning": meaning,
                "A_share_units": dec_text(A_value / A_SHARE),
            }
        )
    return rows


def coarse_grain_table() -> list[dict[str, Any]]:
    return [
        {
            "selector_name": "A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR",
            "law": "A(N_microcells)=N_microcells/R^2",
            "R": R,
            "A_cell_fraction": frac_text(A_CELL),
            "A_cell_decimal": dec_text(A_CELL),
            "A_side_microcells": int(A_SIDE / A_CELL),
            "A_share_microcells": int(A_SHARE / A_CELL),
            "write_midpoint_microcells": int(A_WRITE_MIDPOINT / A_CELL),
            "full_closure_microcells": int(A_FULL / A_CELL),
            "selected_status": "SELECTED_NATIVE_COARSE_GRAIN_LAW",
            "note": "twelve unit microcells coarse-grain to one A-share; six microcells are A_SIDE",
        },
        {
            "selector_name": "PARTITION_GEOMETRY_LANE_SELECTOR",
            "law": "sum(partition)=R => total A=A_SHARE; partition shape selects lane",
            "R": R,
            "A_cell_fraction": frac_text(A_CELL),
            "A_cell_decimal": dec_text(A_CELL),
            "A_side_microcells": int(A_SIDE / A_CELL),
            "A_share_microcells": int(A_SHARE / A_CELL),
            "write_midpoint_microcells": int(A_WRITE_MIDPOINT / A_CELL),
            "full_closure_microcells": int(A_FULL / A_CELL),
            "selected_status": "SELECTED_NATIVE_GEOMETRY_SELECTOR",
            "note": "(12,), (6,6), (4,4,4), (3,3,3,3), (2,2,2,2,2,2), and 12x1 are the same A-share total with different geometry",
        },
    ]


def write_doc(summary: dict[str, Any], grain_rows: list[dict[str, Any]], ladder_rows: list[dict[str, Any]], uniform_rows: list[dict[str, Any]]) -> None:
    grain_lines = "\n".join(
        f"| {row['selector_name']} | {row['law']} | {row['A_cell_fraction']} | {row['A_share_microcells']} | {row['selected_status']} |"
        for row in grain_rows
    )
    ladder_lines = "\n".join(
        f"| {row['microcells']} | {row['A_fraction']} | {row['threshold']} | {row['A_share_units']} | {row['meaning']} |"
        for row in ladder_rows
    )
    uniform_lines = "\n".join(
        f"| {row['partition']} | {row['group_count']} x {row['group_size']} | {row['coarse_grain_role']} | {row['matched_particle_symbols']} | {row['matched_unknown_mode']} |"
        for row in uniform_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP045 - Private A-share Microcell Coarse-Grain Selector

## Preflight

```text
test_id = QP045
test_name = PRIVATE_A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP045 selects the pixel-scale coarse-grain law:

```text
A_cell = A_SHARE / R = 1 / R^2 = 1/144
A(N microcells) = N / R^2
```

So `SAM-UNK-050 = (1,1,1,1,1,1,1,1,1,1,1,1)` is one A-share written
pixel by pixel.

## Coarse-Grain Selector

| selector | law | A cell | cells to A-share | status |
| --- | --- | ---: | ---: | --- |
{grain_lines}

## Threshold Ladder

| microcells | A | threshold | A-share units | meaning |
| ---: | ---: | --- | ---: | --- |
{ladder_lines}

## Uniform Partition Map

| partition | grouping | role | matched particles | matched unknown |
| --- | --- | --- | --- | --- |
{uniform_lines}

## Key Fields

```text
A_cell = {summary['A_cell_fraction']} = {summary['A_cell_decimal']}
A_SIDE_microcells = {summary['A_SIDE_microcells']}
A_SHARE_microcells = {summary['A_SHARE_microcells']}
WRITE_MIDPOINT_microcells = {summary['WRITE_MIDPOINT_microcells']}
A_FULL_microcells = {summary['A_FULL_microcells']}
uniform_share_partitions_mapped = {summary['uniform_share_partitions_mapped']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

This is the first clean pixel-scale law in the private Phase 4 branch. It says
the total A-share is fixed by the count, while the partition geometry decides
what kind of lane the share becomes. That is why `(12,)`, `(6,6)`, `(4,4,4)`,
`(3,3,3,3)`, `(2,2,2,2,2,2)`, and the 12x1 microcell row can all be native
without being the same physical carrier.
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp001 = read_json(QP001_SUMMARY)
    qp044 = read_json(QP044_SUMMARY)
    assignment_rows = read_csv(QP043_ASSIGNMENT)
    particle_rows = read_csv(PARTICLE_TABLE)
    sam_unk_050 = next(row for row in assignment_rows if row["native_id"] == "SAM-UNK-050")

    grain_rows = coarse_grain_table()
    ladder_rows = selector_ladder()
    uniform_rows = uniform_partition_map(particle_rows, assignment_rows)

    summary = {
        "artifact": "QP045_PRIVATE_A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR",
        "result_class": "QP045_A_SHARE_MICROCELL_COARSE_GRAIN_LAW_SELECTED",
        "campaign_status": "QP045_MICROCELL_COARSE_GRAIN_SELECTED_QP046_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_masses_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp001/qp001_phase_functional_summary.json",
            "artifacts/qp043/qp043_unknown_mode_assignment_table.csv",
            "artifacts/qp044/qp044_summary.json",
            "phase4_tables/phase4_parameter_free_particle_table.csv",
        ],
        "qp001_result_class": qp001["result_class"],
        "qp044_result_class": qp044["result_class"],
        "sam_unk_050_carrier_family": sam_unk_050["carrier_family"],
        "sam_unk_050_partition": sam_unk_050["subchannel_partition"],
        "R": R,
        "A_cell_fraction": frac_text(A_CELL),
        "A_cell_decimal": dec_text(A_CELL),
        "A_SIDE_microcells": int(A_SIDE / A_CELL),
        "A_SHARE_microcells": int(A_SHARE / A_CELL),
        "WRITE_MIDPOINT_microcells": int(A_WRITE_MIDPOINT / A_CELL),
        "A_FULL_microcells": int(A_FULL / A_CELL),
        "uniform_share_partitions_mapped": len(uniform_rows),
        "matched_particle_partition_families": {
            row["partition"]: row["matched_particle_symbols"]
            for row in uniform_rows
            if row["matched_particle_symbols"]
        },
        "matched_unknown_partition_families": {
            row["partition"]: row["matched_unknown_mode"]
            for row in uniform_rows
            if row["matched_unknown_mode"]
        },
        "selected_law": "A(N_microcells)=N/R^2",
        "selected_selector": "A_SHARE_MICROCELL_COARSE_GRAIN_SELECTOR",
        "next_frontier": "QP046_PRIVATE_PARTITION_GEOMETRY_LANE_SELECTOR",
        "interpretation": (
            "SAM-UNK-050 selects the twelve-unit A-share lattice. Each microcell carries 1/144 A, "
            "so 12 microcells make A_SHARE, 6 make A_SIDE, 72 make WRITE_MIDPOINT, and 144 make full closure."
        ),
    }

    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "new microcell selector gate; not audit, not retest, no public write",
        },
        {
            "decision_point": "microcell_unit",
            "decision": "SELECT_A_CELL_EQUALS_ONE_OVER_R_SQUARED",
            "note": "A_cell = A_SHARE/R = 1/144",
        },
        {
            "decision_point": "uniform_partition_map",
            "decision": "PASS_ALL_UNIFORM_DIVISOR_PARTITIONS_MAP_TO_A_SHARE",
            "note": "partition geometry selects lane while total A remains A_SHARE",
        },
    ]
    next_rows = [
        {
            "next_frontier": "QP046_PRIVATE_PARTITION_GEOMETRY_LANE_SELECTOR",
            "why_next": "QP045 fixes the A-share microcell count; QP046 should select which partition geometry becomes which lane.",
            "launch_from": "qp045_uniform_partition_map.csv",
            "target_output": "lane selector for 12x1, 6x2, 4x3, 3x4, 2x6, and 1x12 geometries",
        }
    ]
    schema_rows = [
        {
            "field": "A_CELL",
            "meaning": "one microcell A contribution, equal to A_SHARE/R = 1/R^2",
            "class": "coarse_grain_law",
        },
        {
            "field": "uniform_partition_map",
            "meaning": "all uniform divisor partitions sum to R and therefore carry one A-share",
            "class": "partition_geometry",
        },
        {
            "field": "PARTITION_GEOMETRY_LANE_SELECTOR",
            "meaning": "next selector: choose lane from partition shape rather than total A",
            "class": "next_frontier",
        },
    ]

    write_json(SUMMARY_OUT, summary)
    write_csv(
        COARSE_GRAIN_OUT,
        grain_rows,
        [
            "selector_name",
            "law",
            "R",
            "A_cell_fraction",
            "A_cell_decimal",
            "A_side_microcells",
            "A_share_microcells",
            "write_midpoint_microcells",
            "full_closure_microcells",
            "selected_status",
            "note",
        ],
    )
    write_csv(
        SELECTOR_LADDER_OUT,
        ladder_rows,
        ["microcells", "A_fraction", "A_decimal", "threshold", "meaning", "A_share_units"],
    )
    write_csv(
        UNIFORM_MAP_OUT,
        uniform_rows,
        [
            "group_count",
            "group_size",
            "partition",
            "microcell_count",
            "A_total_fraction",
            "A_total_decimal",
            "coarse_grain_role",
            "matched_particle_symbols",
            "matched_unknown_mode",
            "matched_unknown_family",
            "selector_reading",
        ],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, grain_rows, ladder_rows, uniform_rows)

    print(summary["result_class"])
    print(f"A_cell={summary['A_cell_fraction']}={summary['A_cell_decimal']}")
    print(f"A_SIDE_microcells={summary['A_SIDE_microcells']}")
    print(f"A_SHARE_microcells={summary['A_SHARE_microcells']}")
    print(f"WRITE_MIDPOINT_microcells={summary['WRITE_MIDPOINT_microcells']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
