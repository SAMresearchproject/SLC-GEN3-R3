from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

QP045_UNIFORM_MAP = ARTIFACTS / "qp045" / "qp045_uniform_partition_map.csv"
QP045_SUMMARY = ARTIFACTS / "qp045" / "qp045_summary.json"
QP043_ASSIGNMENT = ARTIFACTS / "qp043" / "qp043_unknown_mode_assignment_table.csv"
QP022A_ROUTE_INVENTORY = ARTIFACTS / "qp022a" / "qp022a_route_inventory_table.csv"
QP037_FREEZE = ARTIFACTS / "qp037" / "qp037_particle_identity_freeze_table.csv"
PARTICLE_TABLE = PHASE4 / "phase4_parameter_free_particle_table.csv"

QP046_DIR = ARTIFACTS / "qp046"
PREFLIGHT_OUT = QP046_DIR / "qp046_preflight.md"
SUMMARY_OUT = QP046_DIR / "qp046_summary.json"
LANE_OUT = QP046_DIR / "qp046_partition_geometry_lane_table.csv"
AXIS_OUT = QP046_DIR / "qp046_axis_duality_table.csv"
EVIDENCE_OUT = QP046_DIR / "qp046_existing_route_evidence_table.csv"
DECISION_OUT = QP046_DIR / "qp046_decision_table.csv"
NEXT_OUT = QP046_DIR / "qp046_next_frontier.csv"
SCHEMA_OUT = QP046_DIR / "qp046_schema.csv"
DOC_OUT = REPORTS / "QP046_PRIVATE_PARTITION_GEOMETRY_LANE_SELECTOR.md"


R = 12
D = 3
ALPHA_H = 2
D_PLUS_ONE = D + 1
A_SHARE = Fraction(1, 12)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP046_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP046 Preflight - Partition Geometry Lane Selector

```text
test_id = QP046
test_name = PRIVATE_PARTITION_GEOMETRY_LANE_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp045/qp045_uniform_partition_map.csv
artifacts/qp045/qp045_summary.json
artifacts/qp043/qp043_unknown_mode_assignment_table.csv
artifacts/qp022a/qp022a_route_inventory_table.csv
artifacts/qp037/qp037_particle_identity_freeze_table.csv
phase4_tables/phase4_parameter_free_particle_table.csv
```

## Expected Outputs

```text
artifacts/qp046/qp046_summary.json
artifacts/qp046/qp046_partition_geometry_lane_table.csv
artifacts/qp046/qp046_axis_duality_table.csv
docs/reports/QP046_PRIVATE_PARTITION_GEOMETRY_LANE_SELECTOR.md
```

## Forward Question

```text
Given that QP045 showed all uniform divisor partitions of R=12 carry one
A-share, which native partition geometry selects each lane?
```

This is a forward selector gate. It does not rerun QP045 and does not test
prior results; it uses the QP045 law as input and assigns lane meaning from
geometry.
""",
        encoding="utf-8",
    )


def lane_rule(group_count: int, group_size: int) -> dict[str, str]:
    if group_count == R and group_size == 1:
        return {
            "selected_lane": "MICROCELL_FLOOR_LANE",
            "selector": "R_BY_ONE_A_SHARE_MICROCELL_FLOOR_SELECTOR",
            "status": "SELECTED_NATIVE_NONPARTICLE_LANE",
            "rule": "group_count=R and group_size=1",
            "meaning": "raw A-share pixel lattice; floor for coarse-graining",
        }
    if group_count == R // ALPHA_H and group_size == ALPHA_H:
        return {
            "selected_lane": "SIX_HALF_CONTACT_WRITE_ROUTE",
            "selector": "HALF_CONTACT_ROUTE_SELECTOR",
            "status": "SELECTED_NATIVE_NONPARTICLE_LANE",
            "rule": "group_count=R/alpha_H and group_size=alpha_H",
            "meaning": "six half-contact segments route unresolved A into write access",
        }
    if group_count == D_PLUS_ONE and group_size == D:
        return {
            "selected_lane": "D_PLUS_ONE_PROPAGATION_LANE",
            "selector": "D_PLUS_ONE_PART_COUNT_PROPAGATION_SELECTOR",
            "status": "SELECTED_NATIVE_PROPAGATION_LANE",
            "rule": "group_count=D+1 and group_size=D",
            "meaning": "D+1 part count over D-sized blocks selects stable propagation geometry",
        }
    if group_count == D and group_size == D_PLUS_ONE:
        return {
            "selected_lane": "TRIADIC_PARTICLE_SCREEN_LANE",
            "selector": "D_AXIS_WITH_D_PLUS_ONE_BLOCK_SCREEN_SELECTOR",
            "status": "SELECTED_FILLED_PARTICLE_LANE",
            "rule": "group_count=D and group_size=D+1",
            "meaning": "D triadic owner axes with D+1 block width select quark/color screen",
        }
    if group_count == ALPHA_H and group_size == R // ALPHA_H:
        return {
            "selected_lane": "OUTER_BINARY_SCALAR_RETURN_LANE",
            "selector": "OUTER_BINARY_RETURN_SELECTOR",
            "status": "SELECTED_FILLED_PARTICLE_LANE",
            "rule": "group_count=alpha_H and group_size=R/alpha_H",
            "meaning": "outer binary split selects scalar neutral return seed",
        }
    if group_count == 1 and group_size == R:
        return {
            "selected_lane": "SINGLE_BLOCK_INTEGER_WINDING_LANE",
            "selector": "FULL_RADIX_INTEGER_WINDING_SELECTOR",
            "status": "SELECTED_FILLED_PARTICLE_LANE",
            "rule": "group_count=1 and group_size=R",
            "meaning": "one full radix block selects charged and neutral lepton winding lanes",
        }
    return {
        "selected_lane": "UNSELECTED_GEOMETRY",
        "selector": "PARTITION_GEOMETRY_SELECTOR_NEEDED",
        "status": "BOUNDARY_SELECTOR_NEEDED",
        "rule": "no native divisor lane rule matched",
        "meaning": "partition is outside the current uniform divisor lane grammar",
    }


def by_partition(rows: list[dict[str, str]]) -> dict[str, list[dict[str, str]]]:
    out: dict[str, list[dict[str, str]]] = {}
    for row in rows:
        out.setdefault(row.get("subchannel_partition", ""), []).append(row)
    return out


def build_lane_table(
    uniform_rows: list[dict[str, str]],
    particles_by_partition: dict[str, list[dict[str, str]]],
    unknown_by_partition: dict[str, list[dict[str, str]]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in uniform_rows:
        group_count = int(row["group_count"])
        group_size = int(row["group_size"])
        partition = row["partition"]
        rule = lane_rule(group_count, group_size)
        particles = particles_by_partition.get(partition, [])
        unknowns = unknown_by_partition.get(partition, [])
        matched_particle_symbols = ";".join(p["symbol"] for p in particles)
        matched_particle_families = ";".join(sorted({p["native_family"] for p in particles}))
        matched_unknown_ids = ";".join(u["native_id"] for u in unknowns)
        matched_unknown_families = ";".join(sorted({u["carrier_family"] for u in unknowns}))
        rows.append(
            {
                "partition": partition,
                "geometry": f"{group_count}x{group_size}",
                "group_count": group_count,
                "group_size": group_size,
                "A_total": row["A_total_fraction"],
                "selected_lane": rule["selected_lane"],
                "selector": rule["selector"],
                "status": rule["status"],
                "selector_rule": rule["rule"],
                "geometry_meaning": rule["meaning"],
                "matched_particle_symbols": matched_particle_symbols,
                "matched_particle_families": matched_particle_families,
                "matched_unknown_ids": matched_unknown_ids,
                "matched_unknown_families": matched_unknown_families,
                "lane_claim": (
                    "lane selected from partition geometry; total A-share alone is not the selector"
                ),
            }
        )
    return rows


def axis_duality_rows(lane_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    by_geom = {row["geometry"]: row for row in lane_rows}
    pairs = [
        ("12x1", "1x12", "microcell floor versus full-radix integer winding"),
        ("6x2", "2x6", "half-contact write route versus outer binary scalar return"),
        ("4x3", "3x4", "D+1 propagation part count versus triadic particle screen"),
    ]
    rows: list[dict[str, Any]] = []
    for left, right, meaning in pairs:
        left_row = by_geom[left]
        right_row = by_geom[right]
        rows.append(
            {
                "duality_pair": f"{left} <-> {right}",
                "left_partition": left_row["partition"],
                "left_lane": left_row["selected_lane"],
                "left_selector": left_row["selector"],
                "right_partition": right_row["partition"],
                "right_lane": right_row["selected_lane"],
                "right_selector": right_row["selector"],
                "same_A_total": "true",
                "why_distinct": meaning,
                "selector_reading": "exchanging group_count and group_size changes the lane",
            }
        )
    return rows


def evidence_table(
    lane_rows: list[dict[str, Any]],
    route_rows: list[dict[str, str]],
    freeze_rows: list[dict[str, str]],
) -> list[dict[str, Any]]:
    route_family_by_hint = {
        "SINGLE_BLOCK_INTEGER_WINDING_LANE": "QUBIT-CL-001;QUBIT-NL-001",
        "OUTER_BINARY_SCALAR_RETURN_LANE": "QUBIT-BN-001",
        "TRIADIC_PARTICLE_SCREEN_LANE": "QUBIT-TM-001;QUBIT-TP-001;QUBIT-COLOR-001",
        "D_PLUS_ONE_PROPAGATION_LANE": "QUBIT-UNK-001 family excluded; QP043 selects SAM-UNK-008 propagation candidate",
        "SIX_HALF_CONTACT_WRITE_ROUTE": "QP043 selects SAM-UNK-026 six half-contact write route",
        "MICROCELL_FLOOR_LANE": "QP043 selects SAM-UNK-050 twelve microcell A-share lattice",
    }
    route_by_id = {row["route"]: row for row in route_rows}
    promoted_freeze = ";".join(
        row["suk055_pair"] for row in freeze_rows if row["freeze_status"] == "PROMOTED"
    )
    rows: list[dict[str, Any]] = []
    for lane in lane_rows:
        hint = route_family_by_hint.get(lane["selected_lane"], "")
        route_bits: list[str] = []
        for route_id in hint.split(";"):
            route_id = route_id.strip()
            if route_id in route_by_id:
                route_bits.append(f"{route_id}:{route_by_id[route_id]['derived_route_family']}")
        rows.append(
            {
                "partition": lane["partition"],
                "selected_lane": lane["selected_lane"],
                "particle_or_unknown_evidence": lane["matched_particle_symbols"] or lane["matched_unknown_ids"],
                "route_evidence": ";".join(route_bits) or hint,
                "qp037_promoted_local_return": promoted_freeze if lane["selected_lane"] == "TRIADIC_PARTICLE_SCREEN_LANE" else "",
                "evidence_reading": "existing private rows support the lane assignment without observed-mass input",
            }
        )
    return rows


def write_doc(summary: dict[str, Any], lane_rows: list[dict[str, Any]], axis_rows: list[dict[str, Any]]) -> None:
    lane_lines = "\n".join(
        "| {partition} | {geometry} | {A_total} | {selected_lane} | {selector} | {status} | {matched_particle_symbols} | {matched_unknown_ids} |".format(
            **row
        )
        for row in lane_rows
    )
    axis_lines = "\n".join(
        "| {duality_pair} | {left_lane} | {right_lane} | {why_distinct} |".format(**row)
        for row in axis_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP046 - Private Partition Geometry Lane Selector

## Preflight

```text
test_id = QP046
test_name = PRIVATE_PARTITION_GEOMETRY_LANE_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP045 showed that every uniform divisor partition of `R=12` carries the same
total A-share:

```text
sum(partition)=R
A_total = A_SHARE = 1/12
```

QP046 selects the next rule:

```text
lane = f(group_count, group_size)
total A-share magnitude does not select the lane by itself
```

## Lane Table

| partition | geometry | A total | selected lane | selector | status | particles | unknowns |
| --- | --- | ---: | --- | --- | --- | --- | --- |
{lane_lines}

## Axis Duality

| pair | left lane | right lane | why distinct |
| --- | --- | --- | --- |
{axis_lines}

## Key Fields

```text
selected_lane_rows = {summary['selected_lane_rows']}
filled_particle_lane_rows = {summary['filled_particle_lane_rows']}
native_nonparticle_lane_rows = {summary['native_nonparticle_lane_rows']}
propagation_lane_rows = {summary['propagation_lane_rows']}
axis_duality_pairs = {summary['axis_duality_pairs']}
free_parameters_introduced = {summary['free_parameters_introduced']}
observed_masses_used = {str(summary['observed_masses_used']).lower()}
next_frontier = {summary['next_frontier']}
```

## Interpretation

This closes the immediate ambiguity opened by QP045. `A_SHARE=1/12` is the
shared amount, but the shape of the share determines the lane. In particular,
`(4,4,4)` and `(3,3,3,3)` are not interchangeable:

```text
(4,4,4)   = 3 x 4 = D axes with D+1 block width -> triadic particle screen
(3,3,3,3) = 4 x 3 = D+1 part count over D blocks -> propagation lane
```

So SAM-UNK-050 is not a hidden particle slot. It is the 12x1 microcell floor
that lets the other one-share geometries be read as different lane families.
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp045_summary = read_json(QP045_SUMMARY)
    uniform_rows = read_csv(QP045_UNIFORM_MAP)
    assignment_rows = read_csv(QP043_ASSIGNMENT)
    particle_rows = read_csv(PARTICLE_TABLE)
    route_rows = read_csv(QP022A_ROUTE_INVENTORY)
    freeze_rows = read_csv(QP037_FREEZE)

    lane_rows = build_lane_table(
        uniform_rows,
        particles_by_partition=by_partition(particle_rows),
        unknown_by_partition=by_partition(assignment_rows),
    )
    axis_rows = axis_duality_rows(lane_rows)
    evidence_rows = evidence_table(lane_rows, route_rows, freeze_rows)

    status_counts: dict[str, int] = {}
    for row in lane_rows:
        status_counts[row["status"]] = status_counts.get(row["status"], 0) + 1

    lane_map = {row["partition"]: row["selected_lane"] for row in lane_rows}
    summary = {
        "artifact": "QP046_PRIVATE_PARTITION_GEOMETRY_LANE_SELECTOR",
        "result_class": "QP046_PARTITION_GEOMETRY_LANE_SELECTOR_SELECTED",
        "campaign_status": "QP046_PARTITION_GEOMETRY_SELECTED_QP047_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_masses_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp045/qp045_uniform_partition_map.csv",
            "artifacts/qp045/qp045_summary.json",
            "artifacts/qp043/qp043_unknown_mode_assignment_table.csv",
            "artifacts/qp022a/qp022a_route_inventory_table.csv",
            "artifacts/qp037/qp037_particle_identity_freeze_table.csv",
            "phase4_tables/phase4_parameter_free_particle_table.csv",
        ],
        "qp045_result_class": qp045_summary["result_class"],
        "R": R,
        "D": D,
        "alpha_H": ALPHA_H,
        "A_SHARE": "1/12",
        "selected_lane_rows": len(lane_rows),
        "status_counts": status_counts,
        "filled_particle_lane_rows": status_counts.get("SELECTED_FILLED_PARTICLE_LANE", 0),
        "native_nonparticle_lane_rows": status_counts.get("SELECTED_NATIVE_NONPARTICLE_LANE", 0),
        "propagation_lane_rows": status_counts.get("SELECTED_NATIVE_PROPAGATION_LANE", 0),
        "axis_duality_pairs": len(axis_rows),
        "lane_map": lane_map,
        "critical_distinction": {
            "(4,4,4)": "3x4 = triadic particle screen",
            "(3,3,3,3)": "4x3 = D+1 propagation lane",
        },
        "sam_unk_050_reading": "12x1 microcell floor, not a particle mass claim",
        "selected_rule": "lane = f(group_count, group_size) over uniform divisor partitions of R=12",
        "next_frontier": "QP047_PRIVATE_NUCLEAR_BINDING_ISOTOPE_A_ROAD_SELECTOR",
        "interpretation": (
            "QP046 separates A-share magnitude from lane geometry. The same A_SHARE=1/12 can become "
            "microcell floor, half-contact route, propagation lane, triadic screen, scalar return, or integer winding "
            "depending on group_count and group_size."
        ),
    }

    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "new partition geometry selector; not audit, not retest, no public write",
        },
        {
            "decision_point": "same_A_share",
            "decision": "DO_NOT_USE_A_TOTAL_AS_LANE_SELECTOR",
            "note": "all uniform divisor partitions carry A_SHARE=1/12",
        },
        {
            "decision_point": "geometry_selector",
            "decision": "SELECT_LANE_FROM_GROUP_COUNT_AND_GROUP_SIZE",
            "note": "partition shape determines lane family",
        },
        {
            "decision_point": "critical_distinction",
            "decision": "SEPARATE_3X4_TRIADIC_FROM_4X3_PROPAGATION",
            "note": "(4,4,4) and (3,3,3,3) have same A total but different geometry",
        },
    ]
    next_rows = [
        {
            "next_frontier": "QP047_PRIVATE_NUCLEAR_BINDING_ISOTOPE_A_ROAD_SELECTOR",
            "why_next": "QP046 closes uniform one-share lane geometry; Phase 4 can now move to many-SW element/isotope A-road blanks.",
            "launch_from": "qp046_partition_geometry_lane_table.csv",
            "target_output": "first native element/isotope A-road fill or exact selector boundary",
        }
    ]
    schema_rows = [
        {
            "field": "group_count",
            "meaning": "number of repeated blocks in the uniform divisor partition",
            "class": "geometry_selector_input",
        },
        {
            "field": "group_size",
            "meaning": "microcell width of each repeated block",
            "class": "geometry_selector_input",
        },
        {
            "field": "selected_lane",
            "meaning": "lane family selected from partition geometry at fixed A_SHARE",
            "class": "selector_output",
        },
        {
            "field": "axis_duality",
            "meaning": "exchange of group_count and group_size changes lane at the same A total",
            "class": "geometry_distinction",
        },
    ]

    write_json(SUMMARY_OUT, summary)
    write_csv(
        LANE_OUT,
        lane_rows,
        [
            "partition",
            "geometry",
            "group_count",
            "group_size",
            "A_total",
            "selected_lane",
            "selector",
            "status",
            "selector_rule",
            "geometry_meaning",
            "matched_particle_symbols",
            "matched_particle_families",
            "matched_unknown_ids",
            "matched_unknown_families",
            "lane_claim",
        ],
    )
    write_csv(
        AXIS_OUT,
        axis_rows,
        [
            "duality_pair",
            "left_partition",
            "left_lane",
            "left_selector",
            "right_partition",
            "right_lane",
            "right_selector",
            "same_A_total",
            "why_distinct",
            "selector_reading",
        ],
    )
    write_csv(
        EVIDENCE_OUT,
        evidence_rows,
        [
            "partition",
            "selected_lane",
            "particle_or_unknown_evidence",
            "route_evidence",
            "qp037_promoted_local_return",
            "evidence_reading",
        ],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, lane_rows, axis_rows)

    print(summary["result_class"])
    print(f"selected_lane_rows={summary['selected_lane_rows']}")
    print(f"filled_particle_lane_rows={summary['filled_particle_lane_rows']}")
    print(f"native_nonparticle_lane_rows={summary['native_nonparticle_lane_rows']}")
    print(f"propagation_lane_rows={summary['propagation_lane_rows']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
