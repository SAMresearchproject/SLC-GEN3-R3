from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

ELEMENT_ATLAS = PHASE4 / "phase4_element_periodic_atlas.csv"
A_ROAD_GATE = PHASE4 / "phase4_a_road_coherence_gate_table.csv"
COMPOSITE_SUPPORT = PHASE4 / "phase4_composite_support_table.csv"
QP040_OPERATOR = ARTIFACTS / "qp040" / "qp040_binding_residue_operator_table.csv"
QP046_SUMMARY = ARTIFACTS / "qp046" / "qp046_summary.json"

QP047_DIR = ARTIFACTS / "qp047"
PREFLIGHT_OUT = QP047_DIR / "qp047_preflight.md"
SUMMARY_OUT = QP047_DIR / "qp047_summary.json"
ELEMENT_CONTEXT_OUT = QP047_DIR / "qp047_element_a_road_context_table.csv"
BAND_SUMMARY_OUT = QP047_DIR / "qp047_a_road_band_summary_table.csv"
NUCLEAR_BRIDGE_OUT = QP047_DIR / "qp047_nuclear_support_bridge_table.csv"
DECISION_OUT = QP047_DIR / "qp047_decision_table.csv"
NEXT_OUT = QP047_DIR / "qp047_next_frontier.csv"
SCHEMA_OUT = QP047_DIR / "qp047_schema.csv"
DOC_OUT = REPORTS / "QP047_PRIVATE_NUCLEAR_BINDING_ISOTOPE_A_ROAD_SELECTOR.md"

PHASE4_ELEMENT_CONTEXT_V1 = PHASE4 / "phase4_element_a_road_context_v1.csv"
PHASE4_BLANK_REGISTRY_V3 = PHASE4 / "phase4_blank_registry_v3.csv"
PHASE4_SUMMARY_V3 = PHASE4 / "phase4_summary_v3.json"


R = 12
A_SIDE = Fraction(1, 24)
A_SHARE = Fraction(1, 12)
QG_START = Fraction(1, 3)
WRITE_MIDPOINT = Fraction(1, 2)


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP047_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP047 Preflight - Nuclear Binding and Isotope A-road Selector

```text
test_id = QP047
test_name = PRIVATE_NUCLEAR_BINDING_ISOTOPE_A_ROAD_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
phase4_tables/phase4_element_periodic_atlas.csv
phase4_tables/phase4_a_road_coherence_gate_table.csv
phase4_tables/phase4_composite_support_table.csv
artifacts/qp040/qp040_binding_residue_operator_table.csv
artifacts/qp046/qp046_summary.json
```

## Expected Outputs

```text
artifacts/qp047/qp047_summary.json
artifacts/qp047/qp047_element_a_road_context_table.csv
artifacts/qp047/qp047_a_road_band_summary_table.csv
artifacts/qp047/qp047_nuclear_support_bridge_table.csv
docs/reports/QP047_PRIVATE_NUCLEAR_BINDING_ISOTOPE_A_ROAD_SELECTOR.md
phase4_tables/phase4_element_a_road_context_v1.csv
phase4_tables/phase4_blank_registry_v3.csv
```

## Forward Question

```text
Which element/isotope rows can be filled now as SAM-native A-road formation
context, and which rows still need a nuclear isotope mass-readout selector?
```

This is a forward element-layer fill pass. It does not rerun prior gates and
does not use observed isotope masses or abundance values as selector inputs.
""",
        encoding="utf-8",
    )


def parse_float(text: str) -> float | None:
    value = text.strip()
    if not value:
        return None
    try:
        return float(value)
    except ValueError:
        return None


def band_for_A(A_value: float | None) -> tuple[str, str]:
    if A_value is None:
        return ("A_LOCAL_NOT_PRESENT", "A-local value is not present in the atlas row")
    A_fraction = Fraction(A_value).limit_denominator(10**12)
    if A_fraction < A_SIDE:
        return ("BELOW_A_SIDE_COHERENT_FORMATION", "A_local < 1/24; coherent formation context")
    if A_fraction < A_SHARE:
        return ("A_SIDE_TO_A_SHARE_FUSION_ACCESS", "1/24 <= A_local < 1/12; fusion/write-access band")
    if A_fraction < QG_START:
        return ("A_SHARE_TO_QG_REORGANIZATION", "1/12 <= A_local < 1/3; reorganization-heavy context")
    if A_fraction < WRITE_MIDPOINT:
        return ("QG_TO_WRITE_MIDPOINT_DENSE_CONTEXT", "1/3 <= A_local < 1/2; dense r-process/compact context")
    return ("AT_OR_ABOVE_WRITE_MIDPOINT_BOUNDARY", "A_local >= 1/2; write-midpoint boundary selector needed")


def selector_status(row: dict[str, str], A_value: float | None) -> tuple[str, str]:
    lane = row["sam_formation_lane"].strip()
    provenance = row["sam_context_provenance"].strip()
    if A_value is not None:
        return (
            "FILLED_NATIVE_ELEMENT_A_ROAD_CONTEXT",
            "A-local context present; formation band selected",
        )
    if lane and provenance:
        return (
            "ROUTE_CONTEXT_PRESENT_A_LOCAL_OPEN",
            "formation lane is registered, but A-local selector is still open",
        )
    return (
        "OPEN_ELEMENT_CONTEXT_SELECTOR_NEEDED",
        "element row lacks enough SAM-native context for this pass",
    )


def build_element_context(element_rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for row in element_rows:
        A_value = parse_float(row["A_local_at_formation"])
        band, band_meaning = band_for_A(A_value)
        status, status_note = selector_status(row, A_value)
        out.append(
            {
                "atomic_number": row["atomic_number"],
                "symbol": row["symbol"],
                "name": row["name"],
                "period": row["period"],
                "group": row["group"],
                "block": row["block"],
                "category": row["category"],
                "sam_formation_lane": row["sam_formation_lane"],
                "sam_context_provenance": row["sam_context_provenance"],
                "A_local_at_formation": row["A_local_at_formation"],
                "A_band": band,
                "A_band_meaning": band_meaning,
                "regime": row["regime"],
                "selector_status": status,
                "selector_note": status_note,
                "next_selector_needed": (
                    "NUCLEAR_ISOTOPE_MASS_READOUT_SELECTOR"
                    if status == "FILLED_NATIVE_ELEMENT_A_ROAD_CONTEXT"
                    else "A_LOCAL_FORMATION_CONTEXT_SELECTOR"
                ),
            }
        )
    return out


def band_summary(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    counts: dict[str, dict[str, Any]] = {}
    for row in rows:
        band = row["A_band"]
        counts.setdefault(
            band,
            {
                "A_band": band,
                "rows": 0,
                "symbols": [],
                "example_regimes": [],
                "meaning": row["A_band_meaning"],
            },
        )
        counts[band]["rows"] += 1
        counts[band]["symbols"].append(row["symbol"])
        if row["regime"] and row["regime"] not in counts[band]["example_regimes"]:
            counts[band]["example_regimes"].append(row["regime"])
    return [
        {
            "A_band": band,
            "rows": payload["rows"],
            "symbols": ";".join(payload["symbols"]),
            "example_regimes": ";".join(payload["example_regimes"][:6]),
            "meaning": payload["meaning"],
        }
        for band, payload in sorted(counts.items(), key=lambda item: item[0])
    ]


def nuclear_bridge_table(
    composite_rows: list[dict[str, str]], operator_rows: list[dict[str, str]]
) -> list[dict[str, Any]]:
    operator_by_id = {row["composite_id"]: row for row in operator_rows}
    rows: list[dict[str, Any]] = []
    for row in composite_rows:
        if row["branch"] != "nuclear_composite":
            continue
        operator = operator_by_id.get(row["composite_id"], {})
        rows.append(
            {
                "composite_id": row["composite_id"],
                "symbol": row["symbol"],
                "constituents": row["constituents"],
                "sam_mass_MeV": row["sam_mass_MeV"],
                "stability_class": row["stability_class"],
                "confinement_status": row["confinement_status"],
                "resonance_status": row["resonance_status"],
                "operator_class": operator.get("operator_class", ""),
                "operator_status": operator.get("operator_status", ""),
                "free_parameters_used": row["free_parameters_used"],
                "observed_mass_used": operator.get("observed_mass_used", "False"),
                "element_anchor": "H/He isotope bridge",
                "phase4_reading": "FILLED_NATIVE_NUCLEAR_SUPPORT_BRIDGE",
            }
        )
    return rows


def write_doc(
    summary: dict[str, Any],
    band_rows: list[dict[str, Any]],
    bridge_rows: list[dict[str, Any]],
) -> None:
    band_lines = "\n".join(
        f"| {row['A_band']} | {row['rows']} | {row['symbols']} | {row['meaning']} |"
        for row in band_rows
    )
    bridge_lines = "\n".join(
        "| {composite_id} | {symbol} | {constituents} | {sam_mass_MeV} | {phase4_reading} |".format(
            **row
        )
        for row in bridge_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP047 - Private Nuclear Binding and Isotope A-road Selector

## Preflight

```text
test_id = QP047
test_name = PRIVATE_NUCLEAR_BINDING_ISOTOPE_A_ROAD_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP047 fills the element layer where the current private table already has
SAM-native A-local formation context. It also carries forward the existing
deuteron and alpha-particle nuclear support bridges.

## A-road Band Summary

| A band | rows | symbols | meaning |
| --- | ---: | --- | --- |
{band_lines}

## Nuclear Support Bridges

| composite | symbol | constituents | SAM mass MeV | reading |
| --- | --- | --- | ---: | --- |
{bridge_lines}

## Key Fields

```text
element_rows = {summary['element_rows']}
filled_A_local_context_rows = {summary['filled_A_local_context_rows']}
route_context_present_A_local_open_rows = {summary['route_context_present_A_local_open_rows']}
nuclear_support_bridge_rows = {summary['nuclear_support_bridge_rows']}
free_parameters_introduced = {summary['free_parameters_introduced']}
observed_isotope_masses_used = {str(summary['observed_isotope_masses_used']).lower()}
observed_abundance_used_as_selector = {str(summary['observed_abundance_used_as_selector']).lower()}
next_frontier = {summary['next_frontier']}
```

## Interpretation

This moves the periodic element table out of blank territory for the rows that
already carry SAM A-local context. It does not claim a complete isotope mass
predictor. The next missing piece is narrower now:

```text
given an element A-road formation band plus nuclear support bridge,
select the isotope mass/readout layer.
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp046 = read_json(QP046_SUMMARY)
    element_rows = read_csv(ELEMENT_ATLAS)
    a_road_rows = read_csv(A_ROAD_GATE)
    composite_rows = read_csv(COMPOSITE_SUPPORT)
    operator_rows = read_csv(QP040_OPERATOR)

    context_rows = build_element_context(element_rows)
    band_rows = band_summary(context_rows)
    bridge_rows = nuclear_bridge_table(composite_rows, operator_rows)

    status_counts: dict[str, int] = {}
    for row in context_rows:
        status_counts[row["selector_status"]] = status_counts.get(row["selector_status"], 0) + 1

    band_counts = {row["A_band"]: int(row["rows"]) for row in band_rows}
    summary = {
        "artifact": "QP047_PRIVATE_NUCLEAR_BINDING_ISOTOPE_A_ROAD_SELECTOR",
        "result_class": "QP047_ELEMENT_A_ROAD_CONTEXT_LAYER_FILLED",
        "campaign_status": "QP047_ELEMENT_A_ROAD_CONTEXT_FILLED_QP048_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_isotope_masses_used": False,
        "observed_abundance_used_as_selector": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "phase4_tables/phase4_element_periodic_atlas.csv",
            "phase4_tables/phase4_a_road_coherence_gate_table.csv",
            "phase4_tables/phase4_composite_support_table.csv",
            "artifacts/qp040/qp040_binding_residue_operator_table.csv",
            "artifacts/qp046/qp046_summary.json",
        ],
        "qp046_result_class": qp046["result_class"],
        "element_rows": len(context_rows),
        "filled_A_local_context_rows": status_counts.get("FILLED_NATIVE_ELEMENT_A_ROAD_CONTEXT", 0),
        "route_context_present_A_local_open_rows": status_counts.get(
            "ROUTE_CONTEXT_PRESENT_A_LOCAL_OPEN", 0
        ),
        "open_element_context_rows": status_counts.get("OPEN_ELEMENT_CONTEXT_SELECTOR_NEEDED", 0),
        "band_counts": band_counts,
        "nuclear_support_bridge_rows": len(bridge_rows),
        "nuclear_support_bridge_ids": ";".join(row["composite_id"] for row in bridge_rows),
        "a_road_gate_rows_consumed": len(a_road_rows),
        "A_SIDE": "1/24",
        "A_SHARE": "1/12",
        "QG_START": "1/3",
        "WRITE_MIDPOINT": "1/2",
        "next_frontier": "QP048_PRIVATE_PHASE4_FREEZE_AND_VISUAL_PACKAGE",
        "interpretation": (
            "QP047 fills the element A-road context layer for rows with A_local_at_formation and keeps "
            "the missing isotope mass/readout law as a named downstream selector."
        ),
    }

    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "new element A-road context fill; not audit, not retest, no public write",
        },
        {
            "decision_point": "A_local_context",
            "decision": "FILL_ROWS_WITH_A_LOCAL_FORMATION_CONTEXT",
            "note": "A-local values select formation bands against A_SIDE, A_SHARE, QG_START, and WRITE_MIDPOINT",
        },
        {
            "decision_point": "nuclear_support_bridge",
            "decision": "CARRY_DEUTERON_AND_ALPHA_SUPPORT_BRIDGES",
            "note": "nuclear composite bridges are already selected by QP040/composite support",
        },
        {
            "decision_point": "isotope_mass_readout",
            "decision": "HELD_FOR_NEXT_SELECTOR",
            "note": "no observed isotope masses are used; full isotope mass readout remains downstream",
        },
    ]
    next_rows = [
        {
            "next_frontier": "QP048_PRIVATE_PHASE4_FREEZE_AND_VISUAL_PACKAGE",
            "why_next": "QP047 fills the first element A-road context layer; Phase 4 can now freeze the private table state.",
            "launch_from": "qp047_element_a_road_context_table.csv",
            "target_output": "Phase 4 final filled/open table package and updated PNG/table surfaces",
        }
    ]
    schema_rows = [
        {
            "field": "A_band",
            "meaning": "formation context band selected from A_local_at_formation",
            "class": "element_a_road_selector",
        },
        {
            "field": "nuclear_support_bridge",
            "meaning": "deuteron and alpha support rows already carrying native composite readout",
            "class": "nuclear_bridge",
        },
        {
            "field": "NUCLEAR_ISOTOPE_MASS_READOUT_SELECTOR",
            "meaning": "downstream selector needed to turn A-road context into isotope mass/readout rows",
            "class": "remaining_boundary",
        },
    ]
    blank_registry_v3 = [
        {
            "branch": "element_a_road_context",
            "total_rows": len(context_rows),
            "filled_rows": status_counts.get("FILLED_NATIVE_ELEMENT_A_ROAD_CONTEXT", 0),
            "open_rows": status_counts.get("ROUTE_CONTEXT_PRESENT_A_LOCAL_OPEN", 0)
            + status_counts.get("OPEN_ELEMENT_CONTEXT_SELECTOR_NEEDED", 0),
            "status": "PARTIAL_FILL_WITH_A_LOCAL_CONTEXT",
            "selector_needed": "NUCLEAR_ISOTOPE_MASS_READOUT_SELECTOR",
            "source": "QP047",
            "note": "rows with A_local_at_formation now carry a selected A-road formation band",
        },
        {
            "branch": "nuclear_support_bridge",
            "total_rows": len(bridge_rows),
            "filled_rows": len(bridge_rows),
            "open_rows": 0,
            "status": "FILLED_NATIVE_NUCLEAR_SUPPORT_BRIDGE",
            "selector_needed": "NONE_FOR_DEUTERON_ALPHA_SUPPORT",
            "source": "QP040 + QP047",
            "note": "deuteron and alpha support bridges carried into the element layer",
        },
    ]

    fields = [
        "atomic_number",
        "symbol",
        "name",
        "period",
        "group",
        "block",
        "category",
        "sam_formation_lane",
        "sam_context_provenance",
        "A_local_at_formation",
        "A_band",
        "A_band_meaning",
        "regime",
        "selector_status",
        "selector_note",
        "next_selector_needed",
    ]
    write_json(SUMMARY_OUT, summary)
    write_csv(ELEMENT_CONTEXT_OUT, context_rows, fields)
    write_csv(PHASE4_ELEMENT_CONTEXT_V1, context_rows, fields)
    write_csv(BAND_SUMMARY_OUT, band_rows, ["A_band", "rows", "symbols", "example_regimes", "meaning"])
    write_csv(
        NUCLEAR_BRIDGE_OUT,
        bridge_rows,
        [
            "composite_id",
            "symbol",
            "constituents",
            "sam_mass_MeV",
            "stability_class",
            "confinement_status",
            "resonance_status",
            "operator_class",
            "operator_status",
            "free_parameters_used",
            "observed_mass_used",
            "element_anchor",
            "phase4_reading",
        ],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_csv(
        PHASE4_BLANK_REGISTRY_V3,
        blank_registry_v3,
        ["branch", "total_rows", "filled_rows", "open_rows", "status", "selector_needed", "source", "note"],
    )
    write_json(PHASE4_SUMMARY_V3, summary)
    write_doc(summary, band_rows, bridge_rows)

    print(summary["result_class"])
    print(f"element_rows={summary['element_rows']}")
    print(f"filled_A_local_context_rows={summary['filled_A_local_context_rows']}")
    print(f"route_context_present_A_local_open_rows={summary['route_context_present_A_local_open_rows']}")
    print(f"nuclear_support_bridge_rows={summary['nuclear_support_bridge_rows']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
