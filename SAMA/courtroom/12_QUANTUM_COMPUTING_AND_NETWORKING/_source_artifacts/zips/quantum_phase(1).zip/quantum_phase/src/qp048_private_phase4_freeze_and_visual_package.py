from __future__ import annotations

import csv
import importlib.util
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

QP044_SUMMARY = ARTIFACTS / "qp044" / "qp044_summary.json"
QP045_SUMMARY = ARTIFACTS / "qp045" / "qp045_summary.json"
QP046_SUMMARY = ARTIFACTS / "qp046" / "qp046_summary.json"
QP047_SUMMARY = ARTIFACTS / "qp047" / "qp047_summary.json"
QP041_SUMMARY = ARTIFACTS / "qp041" / "qp041_summary.json"
QP042_SUMMARY = ARTIFACTS / "qp042" / "qp042_summary.json"
QP046_LANE_TABLE = ARTIFACTS / "qp046" / "qp046_partition_geometry_lane_table.csv"
QP047_CONTEXT_TABLE = ARTIFACTS / "qp047" / "qp047_element_a_road_context_table.csv"
QP047_BAND_TABLE = ARTIFACTS / "qp047" / "qp047_a_road_band_summary_table.csv"

RENDERER = PHASE4 / "render_phase4_private_table_pngs.py"

QP048_DIR = ARTIFACTS / "qp048"
PREFLIGHT_OUT = QP048_DIR / "qp048_preflight.md"
SUMMARY_OUT = QP048_DIR / "qp048_summary.json"
FREEZE_SUMMARY_OUT = QP048_DIR / "qp048_phase4_freeze_summary.csv"
BLANK_REGISTRY_OUT = QP048_DIR / "qp048_blank_registry_final.csv"
TABLE_INDEX_OUT = QP048_DIR / "qp048_table_index_final.csv"
DECISION_OUT = QP048_DIR / "qp048_decision_table.csv"
NEXT_OUT = QP048_DIR / "qp048_next_frontier.csv"
SCHEMA_OUT = QP048_DIR / "qp048_schema.csv"
DOC_OUT = REPORTS / "QP048_PRIVATE_PHASE4_FREEZE_AND_VISUAL_PACKAGE.md"

PHASE4_FREEZE_SUMMARY = PHASE4 / "phase4_freeze_summary.csv"
PHASE4_BLANK_REGISTRY_FINAL = PHASE4 / "phase4_blank_registry_final.csv"
PHASE4_TABLE_INDEX_FINAL = PHASE4 / "phase4_table_index_final.csv"
PHASE4_SUMMARY_FINAL = PHASE4 / "phase4_summary_final.json"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP048_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP048 Preflight - Phase 4 Freeze and Visual Package

```text
test_id = QP048
test_name = PRIVATE_PHASE4_FREEZE_AND_VISUAL_PACKAGE
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
QP041-QP042 scaffold summaries
QP044-QP047 summaries
QP046 partition geometry lane table
QP047 element A-road context table
phase4_tables/render_phase4_private_table_pngs.py
```

## Expected Outputs

```text
artifacts/qp048/qp048_summary.json
phase4_tables/phase4_freeze_summary.csv
phase4_tables/phase4_blank_registry_final.csv
phase4_tables/phase4_table_index_final.csv
phase4_tables/phase4_summary_final.json
phase4_tables/phase4_qp046_partition_geometry_lane_table.png
phase4_tables/phase4_qp047_element_a_road_context_table.png
phase4_tables/phase4_qp048_freeze_summary.png
docs/reports/QP048_PRIVATE_PHASE4_FREEZE_AND_VISUAL_PACKAGE.md
```

## Forward Question

```text
What is the clean private Phase 4 freeze after QP039-QP047?
```

This is a forward packaging gate. It does not rerun result gates and does not
change public SAM files.
""",
        encoding="utf-8",
    )


def load_renderer() -> Any:
    spec = importlib.util.spec_from_file_location("phase4_renderer", RENDERER)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Unable to load renderer at {RENDERER}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def freeze_rows(
    qp041: dict[str, Any],
    qp042: dict[str, Any],
    qp044: dict[str, Any],
    qp046: dict[str, Any],
    qp047: dict[str, Any],
) -> list[dict[str, Any]]:
    return [
        {
            "branch": "elementary_particle_surface",
            "total_rows": qp044["particle_rows"],
            "filled_rows": qp044["particle_rows"],
            "organized_rows": 0,
            "open_rows": 0,
            "status": "FROZEN_PARAMETER_FREE",
            "selector_needed": "NONE",
        },
        {
            "branch": "uniform_partition_geometry_lanes",
            "total_rows": qp046["selected_lane_rows"],
            "filled_rows": qp046["selected_lane_rows"],
            "organized_rows": 0,
            "open_rows": 0,
            "status": "FILLED_NATIVE_PARTITION_GEOMETRY_SELECTOR",
            "selector_needed": "NONE",
        },
        {
            "branch": "meson_scaffold_support_and_binding",
            "total_rows": qp041["meson_scaffold_rows"],
            "filled_rows": qp044["unique_meson_scaffolds_touched"],
            "organized_rows": qp044["meson_binding_coordinate_rows"],
            "open_rows": qp041["meson_scaffold_rows"] - qp044["unique_meson_scaffolds_touched"],
            "status": "PARTIAL_FILL_WITH_BINDING_COORDINATES",
            "selector_needed": "NEUTRAL_SELF_CHANNEL_OR_LOCAL_RETURN_OR_ROLE_AXIS_SELECTOR",
        },
        {
            "branch": "baryon_scaffold_readout",
            "total_rows": qp042["baryon_scaffold_rows"],
            "filled_rows": qp044["baryon_filled_rows"],
            "organized_rows": 0,
            "open_rows": qp042["baryon_scaffold_rows"] - qp044["baryon_filled_rows"],
            "status": "PARTIAL_FILL_LIGHT_BARYON_SUPPORT",
            "selector_needed": "STRANGE_CHARM_BOTTOM_TOP_BARYON_ROLE_SCALE_SELECTOR",
        },
        {
            "branch": "unknown_mode_carrier_assignment",
            "total_rows": qp044["unknown_mode_rows"],
            "filled_rows": qp044["unknown_exact_carrier_rows"],
            "organized_rows": qp044["unknown_composite_basin_rows"] + qp044["unknown_native_candidate_rows"],
            "open_rows": qp044["unknown_unassigned_boundary_rows"],
            "status": "ONE_EXACT_CARRIER_PLUS_ORGANIZED_BASINS",
            "selector_needed": "SEE_QP043_CARRIER_FAMILY_SUMMARY",
        },
        {
            "branch": "element_a_road_context",
            "total_rows": qp047["element_rows"],
            "filled_rows": qp047["filled_A_local_context_rows"],
            "organized_rows": 0,
            "open_rows": qp047["route_context_present_A_local_open_rows"],
            "status": "PARTIAL_FILL_WITH_A_LOCAL_CONTEXT",
            "selector_needed": "A_LOCAL_FORMATION_CONTEXT_SELECTOR_AND_ISOTOPE_MASS_READOUT",
        },
        {
            "branch": "nuclear_support_bridge",
            "total_rows": qp047["nuclear_support_bridge_rows"],
            "filled_rows": qp047["nuclear_support_bridge_rows"],
            "organized_rows": 0,
            "open_rows": 0,
            "status": "FILLED_NATIVE_NUCLEAR_SUPPORT_BRIDGE",
            "selector_needed": "NONE_FOR_DEUTERON_ALPHA_SUPPORT",
        },
        {
            "branch": "isotope_mass_readout",
            "total_rows": qp047["element_rows"],
            "filled_rows": 0,
            "organized_rows": qp047["filled_A_local_context_rows"],
            "open_rows": qp047["element_rows"],
            "status": "DOWNSTREAM_SELECTOR_OPEN",
            "selector_needed": "NUCLEAR_ISOTOPE_MASS_READOUT_SELECTOR",
        },
    ]


def blank_registry_rows(freeze: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [
        {
            "branch": row["branch"],
            "open_rows": row["open_rows"],
            "status": row["status"],
            "selector_needed": row["selector_needed"],
            "phase4_reading": (
                "closed" if int(row["open_rows"]) == 0 else "open selector named"
            ),
        }
        for row in freeze
    ]


def table_index_rows() -> list[dict[str, Any]]:
    entries = [
        ("phase4_freeze_summary.csv", "8", "final branch-level freeze summary", "primary freeze table"),
        ("phase4_blank_registry_final.csv", "8", "final open selector registry", "remaining work map"),
        ("phase4_table_index_final.csv", "13", "final table/PNG manifest", "package index"),
        ("phase4_summary_final.json", "1", "machine-readable final Phase 4 summary", "summary cards"),
        ("phase4_element_a_road_context_v1.csv", "118", "QP047 element A-road context layer", "element table source"),
        ("phase4_qp046_partition_geometry_lane_table.png", "6", "QP046 geometry lane visual", "partition geometry visual"),
        ("phase4_qp047_element_a_road_context_table.png", "118", "QP047 element A-road visual", "element context visual"),
        ("phase4_qp048_freeze_summary.png", "8", "QP048 branch freeze visual", "freeze visual"),
        ("phase4_parameter_free_particle_table.png", "13", "elementary particle surface", "particle visual"),
        ("phase4_particle_periodic_matrix.png", "6", "native lane/generation matrix", "matrix visual"),
        ("phase4_composite_support_table.png", "8", "composite support table", "support visual"),
        ("phase4_composite_scaffold_table.png", "92", "composite scaffold snapshot", "scaffold visual"),
        ("phase4_qp043_unknown_mode_assignment_table.png", "50", "unknown mode carrier assignment", "unknown visual"),
    ]
    return [
        {"table_file": table_file, "rows": rows, "purpose": purpose, "png_use": png_use}
        for table_file, rows, purpose, png_use in entries
    ]


def render_visuals(renderer: Any, freeze: list[dict[str, Any]]) -> list[str]:
    renderer.main()
    lane_rows = read_csv(QP046_LANE_TABLE)
    element_rows = read_csv(QP047_CONTEXT_TABLE)
    band_rows = read_csv(QP047_BAND_TABLE)

    renderer.table_image(
        PHASE4 / "phase4_qp046_partition_geometry_lane_table.png",
        "QP046 Partition Geometry Lanes",
        "One A-share, six lane geometries selected by group count and group size",
        "private QP046",
        [
            ("partition", "Partition", 260),
            ("geometry", "Geometry", 100),
            ("selected_lane", "Selected lane", 285),
            ("selector", "Selector", 330),
            ("status", "Status", 245),
            ("matched_particle_symbols", "Particles", 160),
            ("matched_unknown_ids", "Unknown", 140),
        ],
        lane_rows,
        cards=[
            ("Lane rows", str(len(lane_rows)), renderer.BLUE),
            ("Particle lanes", "3", renderer.GREEN),
            ("Native nonparticle", "2", renderer.PURPLE),
            ("Propagation", "1", renderer.AMBER),
        ],
        row_palette={
            "SELECTED_FILLED_PARTICLE_LANE": renderer.PALE_GREEN,
            "SELECTED_NATIVE_NONPARTICLE_LANE": renderer.PALE_PURPLE,
            "SELECTED_NATIVE_PROPAGATION_LANE": renderer.PALE_AMBER,
        },
        palette_field="status",
        max_lines_by_col={"selected_lane": 3, "selector": 3, "status": 3},
        width=1660,
    )

    display_elements = element_rows[:36]
    renderer.table_image(
        PHASE4 / "phase4_qp047_element_a_road_context_table.png",
        "QP047 Element A-road Context",
        "A-local formation bands filled where available; remaining rows keep route context open",
        "private QP047",
        [
            ("atomic_number", "Z", 70),
            ("symbol", "Symbol", 90),
            ("name", "Element / band", 180),
            ("sam_formation_lane", "Formation lane", 260),
            ("A_local_at_formation", "A local", 130),
            ("A_band", "A band", 300),
            ("selector_status", "Status", 280),
        ],
        display_elements,
        cards=[
            ("Elements", "118", renderer.BLUE),
            ("A-local filled", "27", renderer.GREEN),
            ("A-local open", "91", renderer.AMBER),
            ("Nuclear bridges", "2", renderer.PURPLE),
        ],
        row_palette={
            "FILLED_NATIVE_ELEMENT_A_ROAD_CONTEXT": renderer.PALE_GREEN,
            "ROUTE_CONTEXT_PRESENT_A_LOCAL_OPEN": renderer.PALE_AMBER,
        },
        palette_field="selector_status",
        max_lines_by_col={"sam_formation_lane": 3, "A_band": 3, "selector_status": 3},
        width=1450,
    )

    renderer.table_image(
        PHASE4 / "phase4_qp048_freeze_summary.png",
        "QP048 Phase 4 Freeze",
        "Private Phase 4 filled/open branch state after QP039-QP047",
        "private QP048",
        [
            ("branch", "Branch", 360),
            ("total_rows", "Total", 90),
            ("filled_rows", "Filled", 90),
            ("organized_rows", "Organized", 110),
            ("open_rows", "Open", 90),
            ("status", "Status", 320),
            ("selector_needed", "Selector needed", 420),
        ],
        freeze,
        cards=[
            ("Closed branches", str(sum(int(row["open_rows"]) == 0 for row in freeze)), renderer.GREEN),
            ("Open branches", str(sum(int(row["open_rows"]) > 0 for row in freeze)), renderer.AMBER),
            ("Particle lanes", "13+6", renderer.BLUE),
            ("Element A-local", "27", renderer.PURPLE),
        ],
        row_palette={
            "FROZEN_PARAMETER_FREE": renderer.PALE_GREEN,
            "FILLED_NATIVE_PARTITION_GEOMETRY_SELECTOR": renderer.PALE_GREEN,
            "FILLED_NATIVE_NUCLEAR_SUPPORT_BRIDGE": renderer.PALE_GREEN,
            "PARTIAL_FILL_WITH_BINDING_COORDINATES": renderer.PALE_AMBER,
            "PARTIAL_FILL_LIGHT_BARYON_SUPPORT": renderer.PALE_AMBER,
            "ONE_EXACT_CARRIER_PLUS_ORGANIZED_BASINS": renderer.PALE_BLUE,
            "PARTIAL_FILL_WITH_A_LOCAL_CONTEXT": renderer.PALE_AMBER,
            "DOWNSTREAM_SELECTOR_OPEN": renderer.PALE_RED,
        },
        palette_field="status",
        max_lines_by_col={"branch": 3, "status": 3, "selector_needed": 3},
        width=1550,
    )

    return [
        "phase4_parameter_free_particle_table.png",
        "phase4_particle_periodic_matrix.png",
        "phase4_composite_support_table.png",
        "phase4_composite_scaffold_table.png",
        "phase4_qp043_unknown_mode_assignment_table.png",
        "phase4_qp043_carrier_family_summary.png",
        "phase4_qp046_partition_geometry_lane_table.png",
        "phase4_qp047_element_a_road_context_table.png",
        "phase4_qp048_freeze_summary.png",
    ]


def write_doc(summary: dict[str, Any], freeze: list[dict[str, Any]], pngs: list[str]) -> None:
    freeze_lines = "\n".join(
        "| {branch} | {total_rows} | {filled_rows} | {organized_rows} | {open_rows} | {status} | {selector_needed} |".format(
            **row
        )
        for row in freeze
    )
    png_lines = "\n".join(f"- `{png}`" for png in pngs)
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP048 - Private Phase 4 Freeze and Visual Package

## Preflight

```text
test_id = QP048
test_name = PRIVATE_PHASE4_FREEZE_AND_VISUAL_PACKAGE
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

## Freeze Summary

| branch | total | filled | organized | open | status | selector needed |
| --- | ---: | ---: | ---: | ---: | --- | --- |
{freeze_lines}

## Visual Package

{png_lines}

## Key Fields

```text
freeze_branches = {summary['freeze_branches']}
closed_branches = {summary['closed_branches']}
open_branches = {summary['open_branches']}
generated_pngs = {summary['generated_pngs']}
public_repo_write = {str(summary['public_repo_write']).lower()}
next_frontier = {summary['next_frontier']}
```

## Interpretation

Phase 4 now has a private frozen table state. The particle surface, partition
geometry lanes, and deuteron/alpha nuclear support bridge are closed in this
package. The remaining open work is explicit: meson/baryon deeper selectors,
unknown-mode basin selectors, A-local context for 91 element rows, and the
isotope mass/readout law.
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp041 = read_json(QP041_SUMMARY)
    qp042 = read_json(QP042_SUMMARY)
    qp044 = read_json(QP044_SUMMARY)
    qp045 = read_json(QP045_SUMMARY)
    qp046 = read_json(QP046_SUMMARY)
    qp047 = read_json(QP047_SUMMARY)

    freeze = freeze_rows(qp041, qp042, qp044, qp046, qp047)
    blank_registry = blank_registry_rows(freeze)
    table_index = table_index_rows()
    renderer = load_renderer()
    pngs = render_visuals(renderer, freeze)

    summary = {
        "artifact": "QP048_PRIVATE_PHASE4_FREEZE_AND_VISUAL_PACKAGE",
        "result_class": "QP048_PHASE4_FREEZE_AND_VISUAL_PACKAGE_BUILT",
        "campaign_status": "QP048_PHASE4_PRIVATE_FREEZE_COMPLETE",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp044/qp044_summary.json",
            "artifacts/qp041/qp041_summary.json",
            "artifacts/qp042/qp042_summary.json",
            "artifacts/qp045/qp045_summary.json",
            "artifacts/qp046/qp046_summary.json",
            "artifacts/qp047/qp047_summary.json",
            "phase4_tables/render_phase4_private_table_pngs.py",
        ],
        "qp044_result_class": qp044["result_class"],
        "qp045_result_class": qp045["result_class"],
        "qp046_result_class": qp046["result_class"],
        "qp047_result_class": qp047["result_class"],
        "freeze_branches": len(freeze),
        "closed_branches": sum(int(row["open_rows"]) == 0 for row in freeze),
        "open_branches": sum(int(row["open_rows"]) > 0 for row in freeze),
        "generated_pngs": len(pngs),
        "png_files": pngs,
        "next_frontier": "PHASE4_COMPLETE_OR_PHASE5_ISOTOPE_MASS_READOUT_SELECTOR",
        "interpretation": (
            "QP048 freezes the private Phase 4 particle/composite/element table state and regenerates the visual package."
        ),
    }

    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "new package/freeze gate; not audit, not retest, no public write",
        },
        {
            "decision_point": "freeze_tables",
            "decision": "WRITE_FINAL_PHASE4_TABLE_PACKAGE",
            "note": "branch summary, blank registry, table index, and machine summary emitted",
        },
        {
            "decision_point": "visuals",
            "decision": "RENDER_PRIVATE_PHASE4_PNGS",
            "note": "existing Phase 4 PNGs refreshed and QP046/QP047/QP048 visuals added",
        },
    ]
    next_rows = [
        {
            "next_frontier": "PHASE4_COMPLETE_OR_PHASE5_ISOTOPE_MASS_READOUT_SELECTOR",
            "why_next": "Phase 4 has a frozen private table state; the next major open branch is isotope mass/readout from A-road context.",
            "launch_from": "phase4_freeze_summary.csv",
            "target_output": "phase decision: stop/freeze, hostile audit, or Phase 5 isotope selector campaign",
        }
    ]
    schema_rows = [
        {
            "field": "filled_rows",
            "meaning": "rows with a selected native result in the branch",
            "class": "freeze_count",
        },
        {
            "field": "organized_rows",
            "meaning": "rows organized into candidate basins or downstream context without final fill",
            "class": "freeze_count",
        },
        {
            "field": "open_rows",
            "meaning": "rows requiring a named selector after Phase 4",
            "class": "freeze_count",
        },
    ]

    fields = ["branch", "total_rows", "filled_rows", "organized_rows", "open_rows", "status", "selector_needed"]
    registry_fields = ["branch", "open_rows", "status", "selector_needed", "phase4_reading"]
    index_fields = ["table_file", "rows", "purpose", "png_use"]
    write_json(SUMMARY_OUT, summary)
    write_json(PHASE4_SUMMARY_FINAL, summary)
    write_csv(FREEZE_SUMMARY_OUT, freeze, fields)
    write_csv(PHASE4_FREEZE_SUMMARY, freeze, fields)
    write_csv(BLANK_REGISTRY_OUT, blank_registry, registry_fields)
    write_csv(PHASE4_BLANK_REGISTRY_FINAL, blank_registry, registry_fields)
    write_csv(TABLE_INDEX_OUT, table_index, index_fields)
    write_csv(PHASE4_TABLE_INDEX_FINAL, table_index, index_fields)
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, freeze, pngs)

    print(summary["result_class"])
    print(f"freeze_branches={summary['freeze_branches']}")
    print(f"closed_branches={summary['closed_branches']}")
    print(f"open_branches={summary['open_branches']}")
    print(f"generated_pngs={summary['generated_pngs']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
