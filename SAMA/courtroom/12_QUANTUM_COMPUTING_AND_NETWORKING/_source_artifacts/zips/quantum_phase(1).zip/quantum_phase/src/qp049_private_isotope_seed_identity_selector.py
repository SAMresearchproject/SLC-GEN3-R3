from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

QP048_SUMMARY = ARTIFACTS / "qp048" / "qp048_summary.json"
QP047_CONTEXT = ARTIFACTS / "qp047" / "qp047_element_a_road_context_table.csv"
QP047_NUCLEAR_BRIDGE = ARTIFACTS / "qp047" / "qp047_nuclear_support_bridge_table.csv"
COMPOSITE_SUPPORT = PHASE4 / "phase4_composite_support_table.csv"
PARTICLE_TABLE = PHASE4 / "phase4_parameter_free_particle_table.csv"

QP049_DIR = ARTIFACTS / "qp049"
PREFLIGHT_OUT = QP049_DIR / "qp049_preflight.md"
SUMMARY_OUT = QP049_DIR / "qp049_summary.json"
SEED_TABLE_OUT = QP049_DIR / "qp049_isotope_seed_identity_table.csv"
FAMILY_SUMMARY_OUT = QP049_DIR / "qp049_seed_family_summary_table.csv"
RADIX_CYCLE_OUT = QP049_DIR / "qp049_radix_alpha_cycle_table.csv"
BRIDGE_USAGE_OUT = QP049_DIR / "qp049_nuclear_bridge_usage_table.csv"
DECISION_OUT = QP049_DIR / "qp049_decision_table.csv"
NEXT_OUT = QP049_DIR / "qp049_next_frontier.csv"
SCHEMA_OUT = QP049_DIR / "qp049_schema.csv"
DOC_OUT = REPORTS / "QP049_PRIVATE_ISOTOPE_SEED_IDENTITY_SELECTOR.md"

PHASE5_SEED_TABLE = PHASE4 / "phase5_isotope_seed_identity_v1.csv"
PHASE5_SUMMARY = PHASE4 / "phase5_summary_v1.json"


R = 12
ALPHA_Z = 2
ALPHA_NUCLEON_COUNT = 4


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP049_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP049 Preflight - Isotope Seed Identity Selector

```text
test_id = QP049
test_name = PRIVATE_ISOTOPE_SEED_IDENTITY_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp048/qp048_summary.json
artifacts/qp047/qp047_element_a_road_context_table.csv
artifacts/qp047/qp047_nuclear_support_bridge_table.csv
phase4_tables/phase4_composite_support_table.csv
phase4_tables/phase4_parameter_free_particle_table.csv
```

## Expected Outputs

```text
artifacts/qp049/qp049_summary.json
artifacts/qp049/qp049_isotope_seed_identity_table.csv
artifacts/qp049/qp049_seed_family_summary_table.csv
artifacts/qp049/qp049_radix_alpha_cycle_table.csv
docs/reports/QP049_PRIVATE_ISOTOPE_SEED_IDENTITY_SELECTOR.md
phase4_tables/phase5_isotope_seed_identity_v1.csv
```

## Forward Question

```text
Can SAM select a native isotope seed identity for each element before isotope
mass/readout, using only proton/neutron/deuteron/alpha support and Z?
```

This is a forward seed selector. It does not use observed isotope masses and
does not emit isotope masses.
""",
        encoding="utf-8",
    )


def seed_for_z(z: int) -> dict[str, Any]:
    if z == 1:
        return {
            "seed_family": "HYDROGEN_PROTON_DEUTERON_SEED",
            "seed_identity": "p with optional n bridge",
            "alpha_units": 0,
            "residual_charge_units": 1,
            "seed_vector": "p | p+n",
            "native_bridge": "proton + deuteron",
            "selector_status": "FILLED_NATIVE_ISOTOPE_SEED_IDENTITY",
            "seed_note": "hydrogen lane anchors the proton/deuteron isotope seed bridge",
        }
    if z == 2:
        return {
            "seed_family": "HELIUM_ALPHA_CLOSURE_SEED",
            "seed_identity": "alpha",
            "alpha_units": 1,
            "residual_charge_units": 0,
            "seed_vector": "alpha",
            "native_bridge": "alpha_particle",
            "selector_status": "FILLED_NATIVE_ISOTOPE_SEED_IDENTITY",
            "seed_note": "helium anchors the closed alpha bridge",
        }
    alpha_units = z // ALPHA_Z
    residual = z % ALPHA_Z
    if residual == 0:
        return {
            "seed_family": "EVEN_Z_ALPHA_STACK_SEED",
            "seed_identity": "alpha_stack",
            "alpha_units": alpha_units,
            "residual_charge_units": 0,
            "seed_vector": f"{alpha_units} alpha",
            "native_bridge": "alpha_particle stack",
            "selector_status": "FILLED_NATIVE_ISOTOPE_SEED_IDENTITY",
            "seed_note": "even Z selects alpha-stack seed identity",
        }
    return {
        "seed_family": "ODD_Z_ALPHA_STACK_PLUS_RESIDUAL_SEED",
        "seed_identity": "alpha_stack_plus_residual",
        "alpha_units": alpha_units,
        "residual_charge_units": 1,
        "seed_vector": f"{alpha_units} alpha + p lane residual",
        "native_bridge": "alpha_particle stack + proton/deuteron residual",
        "selector_status": "FILLED_NATIVE_ISOTOPE_SEED_IDENTITY",
        "seed_note": "odd Z selects alpha stack plus one residual charge lane",
    }


def build_seed_table(element_rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in element_rows:
        z = int(row["atomic_number"])
        seed = seed_for_z(z)
        alpha_units = int(seed["alpha_units"])
        residual = int(seed["residual_charge_units"])
        radix_cycle = (z - 1) // R + 1
        radix_slot = (z - 1) % R + 1
        alpha_cycle = alpha_units // (R // ALPHA_Z)
        alpha_slot = alpha_units % (R // ALPHA_Z)
        rows.append(
            {
                "atomic_number": z,
                "symbol": row["symbol"],
                "name": row["name"],
                "seed_family": seed["seed_family"],
                "seed_identity": seed["seed_identity"],
                "seed_vector": seed["seed_vector"],
                "alpha_units": alpha_units,
                "residual_charge_units": residual,
                "radix_cycle": radix_cycle,
                "radix_slot": radix_slot,
                "alpha_cycle": alpha_cycle,
                "alpha_slot": alpha_slot,
                "A_band": row["A_band"],
                "A_local_at_formation": row["A_local_at_formation"],
                "formation_lane": row["sam_formation_lane"],
                "native_bridge": seed["native_bridge"],
                "selector_status": seed["selector_status"],
                "mass_readout_status": "NOT_EMITTED_QP050_REQUIRED",
                "next_selector_needed": "NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR",
                "seed_note": seed["seed_note"],
            }
        )
    return rows


def family_summary(seed_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in seed_rows:
        grouped[row["seed_family"]].append(row)
    out: list[dict[str, Any]] = []
    for family, rows in grouped.items():
        out.append(
            {
                "seed_family": family,
                "row_count": len(rows),
                "symbols": ";".join(str(row["symbol"]) for row in rows),
                "alpha_unit_range": f"{min(int(row['alpha_units']) for row in rows)}..{max(int(row['alpha_units']) for row in rows)}",
                "residual_values": ";".join(sorted({str(row["residual_charge_units"]) for row in rows})),
                "A_bands_present": ";".join(sorted({str(row["A_band"]) for row in rows})),
                "selector_status": "FILLED_NATIVE_ISOTOPE_SEED_IDENTITY",
            }
        )
    return sorted(out, key=lambda row: row["seed_family"])


def radix_cycle_summary(seed_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[int, list[dict[str, Any]]] = defaultdict(list)
    for row in seed_rows:
        grouped[int(row["radix_cycle"])].append(row)
    out: list[dict[str, Any]] = []
    for cycle, rows in sorted(grouped.items()):
        out.append(
            {
                "radix_cycle": cycle,
                "z_range": f"{min(int(row['atomic_number']) for row in rows)}..{max(int(row['atomic_number']) for row in rows)}",
                "row_count": len(rows),
                "symbols": ";".join(str(row["symbol"]) for row in rows),
                "alpha_units_range": f"{min(int(row['alpha_units']) for row in rows)}..{max(int(row['alpha_units']) for row in rows)}",
                "odd_residual_rows": sum(int(row["residual_charge_units"]) for row in rows),
                "A_bands_present": ";".join(sorted({str(row["A_band"]) for row in rows})),
            }
        )
    return out


def bridge_usage_rows(
    nuclear_bridge_rows: list[dict[str, str]], composite_rows: list[dict[str, str]]
) -> list[dict[str, Any]]:
    composite_by_id = {row["composite_id"]: row for row in composite_rows}
    rows: list[dict[str, Any]] = []
    for bridge in nuclear_bridge_rows:
        composite = composite_by_id.get(bridge["composite_id"], {})
        rows.append(
            {
                "bridge_id": bridge["composite_id"],
                "symbol": bridge["symbol"],
                "constituents": bridge["constituents"],
                "sam_mass_MeV": bridge["sam_mass_MeV"],
                "resonance_status": bridge["resonance_status"],
                "phase4_reading": bridge["phase4_reading"],
                "qp049_usage": (
                    "hydrogen isotope residual bridge"
                    if bridge["composite_id"] == "deuteron"
                    else "alpha-stack seed unit"
                ),
                "source_status": composite.get("phase4_status", ""),
                "observed_mass_used": bridge["observed_mass_used"],
            }
        )
    rows.insert(
        0,
        {
            "bridge_id": "proton_neutron",
            "symbol": "p/n",
            "constituents": "p;n",
            "sam_mass_MeV": "see phase4_composite_support_table.csv",
            "resonance_status": "BARYON_COLOR_SINGLET_SELECTED",
            "phase4_reading": "FILLED_NATIVE_BARYON_SUPPORT",
            "qp049_usage": "base nucleon seed pair",
            "source_status": "FILLED_NATIVE_COMPOSITE_SUPPORT",
            "observed_mass_used": "False",
        },
    )
    return rows


def write_doc(
    summary: dict[str, Any],
    family_rows: list[dict[str, Any]],
    cycle_rows: list[dict[str, Any]],
    bridge_rows: list[dict[str, Any]],
) -> None:
    family_lines = "\n".join(
        f"| {row['seed_family']} | {row['row_count']} | {row['alpha_unit_range']} | {row['residual_values']} |"
        for row in family_rows
    )
    cycle_lines = "\n".join(
        f"| {row['radix_cycle']} | {row['z_range']} | {row['row_count']} | {row['alpha_units_range']} | {row['odd_residual_rows']} |"
        for row in cycle_rows
    )
    bridge_lines = "\n".join(
        f"| {row['bridge_id']} | {row['symbol']} | {row['constituents']} | {row['qp049_usage']} |"
        for row in bridge_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP049 - Private Isotope Seed Identity Selector

## Preflight

```text
test_id = QP049
test_name = PRIVATE_ISOTOPE_SEED_IDENTITY_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP049 selects a seed identity for the isotope layer before attempting isotope
mass/readout:

```text
Z = 1      -> proton/deuteron seed
Z = 2      -> alpha closure seed
even Z > 2 -> alpha-stack seed
odd Z > 1  -> alpha-stack plus one residual charge lane
```

## Seed Family Summary

| seed family | rows | alpha units | residual values |
| --- | ---: | --- | --- |
{family_lines}

## Radix Cycle Summary

| radix cycle | Z range | rows | alpha units | odd residual rows |
| ---: | --- | ---: | --- | ---: |
{cycle_lines}

## Bridge Usage

| bridge | symbol | constituents | QP049 usage |
| --- | --- | --- | --- |
{bridge_lines}

## Key Fields

```text
element_rows = {summary['element_rows']}
seed_identity_rows = {summary['seed_identity_rows']}
seed_family_count = {summary['seed_family_count']}
radix_cycles = {summary['radix_cycles']}
mass_readout_rows_emitted = {summary['mass_readout_rows_emitted']}
observed_isotope_masses_used = {str(summary['observed_isotope_masses_used']).lower()}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

This is a real compression step. The isotope table no longer starts from 118
unstructured blanks. Every element now has a SAM-native seed identity built from
the proton/neutron, deuteron, and alpha bridges. The remaining missing selector
is narrower:

```text
seed identity + A-road band -> neutron-excess / binding-depth readout
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp048 = read_json(QP048_SUMMARY)
    element_rows = read_csv(QP047_CONTEXT)
    nuclear_bridge_rows = read_csv(QP047_NUCLEAR_BRIDGE)
    composite_rows = read_csv(COMPOSITE_SUPPORT)
    particle_rows = read_csv(PARTICLE_TABLE)

    seed_rows = build_seed_table(element_rows)
    family_rows = family_summary(seed_rows)
    cycle_rows = radix_cycle_summary(seed_rows)
    bridge_rows = bridge_usage_rows(nuclear_bridge_rows, composite_rows)

    family_counts = Counter(row["seed_family"] for row in seed_rows)
    A_band_counts = Counter(row["A_band"] for row in seed_rows)
    summary = {
        "artifact": "QP049_PRIVATE_ISOTOPE_SEED_IDENTITY_SELECTOR",
        "result_class": "QP049_ISOTOPE_SEED_IDENTITY_SELECTED_ALL_ELEMENTS",
        "campaign_status": "QP049_ISOTOPE_SEED_IDENTITY_SELECTED_QP050_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_isotope_masses_used": False,
        "observed_abundance_used_as_selector": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp048/qp048_summary.json",
            "artifacts/qp047/qp047_element_a_road_context_table.csv",
            "artifacts/qp047/qp047_nuclear_support_bridge_table.csv",
            "phase4_tables/phase4_composite_support_table.csv",
            "phase4_tables/phase4_parameter_free_particle_table.csv",
        ],
        "qp048_result_class": qp048["result_class"],
        "element_rows": len(seed_rows),
        "seed_identity_rows": len(seed_rows),
        "seed_family_count": len(family_rows),
        "seed_family_counts": dict(family_counts),
        "A_band_counts": dict(A_band_counts),
        "radix_cycles": len(cycle_rows),
        "nuclear_bridge_rows_consumed": len(nuclear_bridge_rows),
        "composite_support_rows_consumed": len(composite_rows),
        "particle_rows_available": len(particle_rows),
        "mass_readout_rows_emitted": 0,
        "selected_rule": "seed_identity(Z)=proton/deuteron for Z=1; alpha for Z=2; alpha_stack for even Z; alpha_stack_plus_residual for odd Z",
        "next_frontier": "QP050_PRIVATE_SYMMETRIC_ISOTOPE_SEED_MASS_READOUT",
        "interpretation": (
            "QP049 reduces isotope mass/readout from 118 generic blanks to a native seed grammar based on "
            "proton/deuteron and alpha support. Mass readout remains downstream."
        ),
    }

    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "new isotope seed selector; not audit, not retest, no public write",
        },
        {
            "decision_point": "seed_identity",
            "decision": "SELECT_ALPHA_LADDER_PLUS_RESIDUAL_SEED_GRAMMAR",
            "note": "all element Z values map to hydrogen, alpha, alpha-stack, or alpha-stack plus residual",
        },
        {
            "decision_point": "mass_readout",
            "decision": "NOT_EMITTED_QP050_REQUIRED",
            "note": "QP049 fills seed identity only; neutron-excess/binding-depth selector is next",
        },
    ]
    next_rows = [
        {
            "next_frontier": "QP050_PRIVATE_SYMMETRIC_ISOTOPE_SEED_MASS_READOUT",
            "why_next": "QP049 selects isotope seed identity for all elements; the next missing piece is the symmetric A_seed=2Z mass/readout surface.",
            "launch_from": "qp049_isotope_seed_identity_table.csv",
            "target_output": "baseline isotope seed mass/readout table without observed isotope masses",
        }
    ]
    schema_rows = [
        {
            "field": "alpha_units",
            "meaning": "floor(Z/2), the number of alpha seed units in the element seed",
            "class": "seed_identity",
        },
        {
            "field": "residual_charge_units",
            "meaning": "Z mod 2, the residual charge lane after alpha stacking",
            "class": "seed_identity",
        },
        {
            "field": "radix_cycle",
            "meaning": "R=12 cycle index over atomic number Z",
            "class": "radix_context",
        },
    ]

    fields = [
        "atomic_number",
        "symbol",
        "name",
        "seed_family",
        "seed_identity",
        "seed_vector",
        "alpha_units",
        "residual_charge_units",
        "radix_cycle",
        "radix_slot",
        "alpha_cycle",
        "alpha_slot",
        "A_band",
        "A_local_at_formation",
        "formation_lane",
        "native_bridge",
        "selector_status",
        "mass_readout_status",
        "next_selector_needed",
        "seed_note",
    ]
    write_json(SUMMARY_OUT, summary)
    write_json(PHASE5_SUMMARY, summary)
    write_csv(SEED_TABLE_OUT, seed_rows, fields)
    write_csv(PHASE5_SEED_TABLE, seed_rows, fields)
    write_csv(
        FAMILY_SUMMARY_OUT,
        family_rows,
        [
            "seed_family",
            "row_count",
            "symbols",
            "alpha_unit_range",
            "residual_values",
            "A_bands_present",
            "selector_status",
        ],
    )
    write_csv(
        RADIX_CYCLE_OUT,
        cycle_rows,
        [
            "radix_cycle",
            "z_range",
            "row_count",
            "symbols",
            "alpha_units_range",
            "odd_residual_rows",
            "A_bands_present",
        ],
    )
    write_csv(
        BRIDGE_USAGE_OUT,
        bridge_rows,
        [
            "bridge_id",
            "symbol",
            "constituents",
            "sam_mass_MeV",
            "resonance_status",
            "phase4_reading",
            "qp049_usage",
            "source_status",
            "observed_mass_used",
        ],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, family_rows, cycle_rows, bridge_rows)

    print(summary["result_class"])
    print(f"element_rows={summary['element_rows']}")
    print(f"seed_family_count={summary['seed_family_count']}")
    print(f"radix_cycles={summary['radix_cycles']}")
    print(f"mass_readout_rows_emitted={summary['mass_readout_rows_emitted']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
