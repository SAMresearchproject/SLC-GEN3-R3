from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
PHASE4 = ROOT / "phase4_tables"

QP049_SUMMARY = ARTIFACTS / "qp049" / "qp049_summary.json"
QP049_SEED_TABLE = ARTIFACTS / "qp049" / "qp049_isotope_seed_identity_table.csv"
QP047_NUCLEAR_BRIDGE = ARTIFACTS / "qp047" / "qp047_nuclear_support_bridge_table.csv"

QP050_DIR = ARTIFACTS / "qp050"
PREFLIGHT_OUT = QP050_DIR / "qp050_preflight.md"
SUMMARY_OUT = QP050_DIR / "qp050_summary.json"
SEED_MASS_OUT = QP050_DIR / "qp050_symmetric_seed_mass_readout_table.csv"
FAMILY_SUMMARY_OUT = QP050_DIR / "qp050_seed_mass_family_summary_table.csv"
FRONTIER_OUT = QP050_DIR / "qp050_neutron_excess_frontier_table.csv"
DECISION_OUT = QP050_DIR / "qp050_decision_table.csv"
NEXT_OUT = QP050_DIR / "qp050_next_frontier.csv"
SCHEMA_OUT = QP050_DIR / "qp050_schema.csv"
DOC_OUT = REPORTS / "QP050_PRIVATE_SYMMETRIC_ISOTOPE_SEED_MASS_READOUT.md"

PHASE5_SEED_MASS_TABLE = PHASE4 / "phase5_symmetric_isotope_seed_mass_v1.csv"
PHASE5_SUMMARY = PHASE4 / "phase5_summary_v2.json"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP050_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP050 Preflight - Symmetric Isotope Seed Mass Readout

```text
test_id = QP050
test_name = PRIVATE_SYMMETRIC_ISOTOPE_SEED_MASS_READOUT
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp049/qp049_summary.json
artifacts/qp049/qp049_isotope_seed_identity_table.csv
artifacts/qp047/qp047_nuclear_support_bridge_table.csv
```

## Expected Outputs

```text
artifacts/qp050/qp050_summary.json
artifacts/qp050/qp050_symmetric_seed_mass_readout_table.csv
artifacts/qp050/qp050_seed_mass_family_summary_table.csv
artifacts/qp050/qp050_neutron_excess_frontier_table.csv
docs/reports/QP050_PRIVATE_SYMMETRIC_ISOTOPE_SEED_MASS_READOUT.md
phase4_tables/phase5_symmetric_isotope_seed_mass_v1.csv
```

## Forward Question

```text
Can the QP049 alpha/deuteron seed grammar emit a baseline symmetric isotope
seed mass surface with A_seed = 2Z?
```

This is a forward mass-readout seed gate. It does not use observed isotope
masses and does not claim final isotope masses.
""",
        encoding="utf-8",
    )


def bridge_masses(bridge_rows: list[dict[str, str]]) -> tuple[float, float]:
    masses = {row["composite_id"]: float(row["sam_mass_MeV"]) for row in bridge_rows}
    return masses["deuteron"], masses["alpha_particle"]


def build_seed_mass_rows(seed_rows: list[dict[str, str]], m_d: float, m_alpha: float) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in seed_rows:
        z = int(row["atomic_number"])
        alpha_units = int(row["alpha_units"])
        residual = int(row["residual_charge_units"])
        A_seed = 2 * z
        N_seed = z
        seed_mass = alpha_units * m_alpha + residual * m_d
        rows.append(
            {
                "atomic_number": z,
                "symbol": row["symbol"],
                "name": row["name"],
                "seed_family": row["seed_family"],
                "seed_vector": row["seed_vector"],
                "alpha_units": alpha_units,
                "deuteron_residual_units": residual,
                "Z_seed": z,
                "N_seed": N_seed,
                "A_seed": A_seed,
                "N_minus_Z_seed": N_seed - z,
                "symmetric_seed_mass_MeV": f"{seed_mass:.12e}",
                "seed_mass_per_nucleon_MeV": f"{seed_mass / A_seed:.12e}",
                "mass_law": "floor(Z/2)*M_alpha + (Z mod 2)*M_deuteron",
                "A_band": row["A_band"],
                "A_local_at_formation": row["A_local_at_formation"],
                "readout_status": "FILLED_SYMMETRIC_ISOTOPE_SEED_MASS",
                "final_isotope_status": "NEUTRON_EXCESS_BINDING_DEPTH_OPEN",
                "next_selector_needed": "NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR",
            }
        )
    return rows


def family_summary(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[row["seed_family"]].append(row)
    out: list[dict[str, Any]] = []
    for family, members in grouped.items():
        masses = [float(row["symmetric_seed_mass_MeV"]) for row in members]
        out.append(
            {
                "seed_family": family,
                "rows": len(members),
                "A_seed_range": f"{min(int(row['A_seed']) for row in members)}..{max(int(row['A_seed']) for row in members)}",
                "mass_range_MeV": f"{min(masses):.6e}..{max(masses):.6e}",
                "symbols": ";".join(str(row["symbol"]) for row in members),
                "readout_status": "FILLED_SYMMETRIC_ISOTOPE_SEED_MASS",
            }
        )
    return sorted(out, key=lambda row: row["seed_family"])


def frontier_rows(seed_mass_rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    band_counts = Counter(row["A_band"] for row in seed_mass_rows)
    out = [
        {
            "frontier": "NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR",
            "rows": len(seed_mass_rows),
            "current_state": "A_seed=2Z symmetric seed mass emitted",
            "missing_operator": "DeltaN(A_band,Z,seed_family) and binding-depth correction",
            "why_needed": "final isotope masses require extra neutron/binding-depth structure beyond N=Z baseline",
        }
    ]
    for band, count in sorted(band_counts.items()):
        out.append(
            {
                "frontier": f"A_BAND::{band}",
                "rows": count,
                "current_state": "seed mass available",
                "missing_operator": "band-specific neutron excess depth",
                "why_needed": "A-road band should select how far final isotope readout departs from symmetric seed",
            }
        )
    return out


def write_doc(
    summary: dict[str, Any],
    family_rows: list[dict[str, Any]],
    frontier: list[dict[str, Any]],
) -> None:
    family_lines = "\n".join(
        f"| {row['seed_family']} | {row['rows']} | {row['A_seed_range']} | {row['mass_range_MeV']} |"
        for row in family_rows
    )
    frontier_lines = "\n".join(
        f"| {row['frontier']} | {row['rows']} | {row['missing_operator']} |"
        for row in frontier
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP050 - Private Symmetric Isotope Seed Mass Readout

## Preflight

```text
test_id = QP050
test_name = PRIVATE_SYMMETRIC_ISOTOPE_SEED_MASS_READOUT
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP050 emits the symmetric isotope seed mass surface:

```text
M_seed(Z) = floor(Z/2) * M_alpha + (Z mod 2) * M_deuteron
A_seed = 2Z
N_seed = Z
```

This is a baseline seed readout, not a final isotope-mass claim.

## Family Summary

| seed family | rows | A seed range | mass range MeV |
| --- | ---: | --- | --- |
{family_lines}

## Next Frontier

| frontier | rows | missing operator |
| --- | ---: | --- |
{frontier_lines}

## Key Fields

```text
seed_mass_rows_emitted = {summary['seed_mass_rows_emitted']}
observed_isotope_masses_used = {str(summary['observed_isotope_masses_used']).lower()}
free_parameters_introduced = {summary['free_parameters_introduced']}
M_deuteron = {summary['M_deuteron_MeV']}
M_alpha = {summary['M_alpha_MeV']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

QP050 is the first isotope-layer mass surface, but it is deliberately the
baseline surface. It says every element has a native symmetric seed readout
built from alpha units and the deuteron residual. The remaining physical
question has sharpened:

```text
What selects neutron excess and binding depth above the N=Z seed?
```
""",
        encoding="utf-8",
    )


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp049 = read_json(QP049_SUMMARY)
    seed_rows = read_csv(QP049_SEED_TABLE)
    bridge_rows = read_csv(QP047_NUCLEAR_BRIDGE)
    m_d, m_alpha = bridge_masses(bridge_rows)

    seed_mass_rows = build_seed_mass_rows(seed_rows, m_d, m_alpha)
    family_rows = family_summary(seed_mass_rows)
    frontier = frontier_rows(seed_mass_rows)

    summary = {
        "artifact": "QP050_PRIVATE_SYMMETRIC_ISOTOPE_SEED_MASS_READOUT",
        "result_class": "QP050_SYMMETRIC_ISOTOPE_SEED_MASS_SURFACE_EMITTED",
        "campaign_status": "QP050_SYMMETRIC_SEED_MASS_EMITTED_QP051_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_isotope_masses_used": False,
        "observed_abundance_used_as_selector": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp049/qp049_summary.json",
            "artifacts/qp049/qp049_isotope_seed_identity_table.csv",
            "artifacts/qp047/qp047_nuclear_support_bridge_table.csv",
        ],
        "qp049_result_class": qp049["result_class"],
        "M_deuteron_MeV": f"{m_d:.12e}",
        "M_alpha_MeV": f"{m_alpha:.12e}",
        "seed_mass_rows_emitted": len(seed_mass_rows),
        "symmetric_N_equals_Z_rows": len(seed_mass_rows),
        "mass_law": "M_seed(Z)=floor(Z/2)*M_alpha+(Z mod 2)*M_deuteron",
        "A_seed_law": "A_seed=2Z",
        "N_seed_law": "N_seed=Z",
        "final_isotope_mass_rows_emitted": 0,
        "next_frontier": "QP051_PRIVATE_NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR",
        "interpretation": (
            "QP050 emits a symmetric isotope seed mass surface for all elements using deuteron and alpha support. "
            "Final isotope masses require neutron-excess/binding-depth selection."
        ),
    }

    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "new symmetric seed mass surface; not audit, not retest, no public write",
        },
        {
            "decision_point": "mass_law",
            "decision": "SELECT_ALPHA_STACK_PLUS_DEUTERON_RESIDUAL_MASS_LAW",
            "note": "universal baseline M_seed(Z)=floor(Z/2)*M_alpha+(Z mod 2)*M_deuteron",
        },
        {
            "decision_point": "final_isotope_mass",
            "decision": "NOT_EMITTED_QP051_REQUIRED",
            "note": "neutron excess and binding depth remain downstream",
        },
    ]
    next_rows = [
        {
            "next_frontier": "QP051_PRIVATE_NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR",
            "why_next": "QP050 emits the symmetric N=Z seed mass surface; final isotope readout needs neutron-excess/binding-depth selection.",
            "launch_from": "qp050_symmetric_seed_mass_readout_table.csv",
            "target_output": "native neutron-excess/binding-depth selector or exact boundary",
        }
    ]
    schema_rows = [
        {
            "field": "symmetric_seed_mass_MeV",
            "meaning": "baseline isotope seed mass from alpha/deuteron stack",
            "class": "mass_seed_readout",
        },
        {
            "field": "A_seed",
            "meaning": "baseline symmetric mass number, equal to 2Z",
            "class": "seed_readout",
        },
        {
            "field": "N_seed",
            "meaning": "baseline symmetric neutron count, equal to Z",
            "class": "seed_readout",
        },
    ]

    fields = [
        "atomic_number",
        "symbol",
        "name",
        "seed_family",
        "seed_vector",
        "alpha_units",
        "deuteron_residual_units",
        "Z_seed",
        "N_seed",
        "A_seed",
        "N_minus_Z_seed",
        "symmetric_seed_mass_MeV",
        "seed_mass_per_nucleon_MeV",
        "mass_law",
        "A_band",
        "A_local_at_formation",
        "readout_status",
        "final_isotope_status",
        "next_selector_needed",
    ]
    write_json(SUMMARY_OUT, summary)
    write_json(PHASE5_SUMMARY, summary)
    write_csv(SEED_MASS_OUT, seed_mass_rows, fields)
    write_csv(PHASE5_SEED_MASS_TABLE, seed_mass_rows, fields)
    write_csv(
        FAMILY_SUMMARY_OUT,
        family_rows,
        ["seed_family", "rows", "A_seed_range", "mass_range_MeV", "symbols", "readout_status"],
    )
    write_csv(FRONTIER_OUT, frontier, ["frontier", "rows", "current_state", "missing_operator", "why_needed"])
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, family_rows, frontier)

    print(summary["result_class"])
    print(f"seed_mass_rows_emitted={summary['seed_mass_rows_emitted']}")
    print(f"final_isotope_mass_rows_emitted={summary['final_isotope_mass_rows_emitted']}")
    print(f"M_deuteron={summary['M_deuteron_MeV']}")
    print(f"M_alpha={summary['M_alpha_MeV']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
