from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
CAMPAIGNS = ROOT / "docs" / "campaigns"
PHASE4 = ROOT / "phase4_tables"

QP049_SEED_TABLE = ARTIFACTS / "qp049" / "qp049_isotope_seed_identity_table.csv"
QP050_SUMMARY = ARTIFACTS / "qp050" / "qp050_summary.json"
QP050_SEED_MASS_TABLE = ARTIFACTS / "qp050" / "qp050_symmetric_seed_mass_readout_table.csv"
QP047_ELEMENT_CONTEXT = ARTIFACTS / "qp047" / "qp047_element_a_road_context_table.csv"
QP040_BINDING_OPERATOR = ARTIFACTS / "qp040" / "qp040_binding_residue_operator_table.csv"

QP051_DIR = ARTIFACTS / "qp051"
PREFLIGHT_OUT = QP051_DIR / "qp051_preflight.md"
SUMMARY_OUT = QP051_DIR / "qp051_summary.json"
LANE_OUT = QP051_DIR / "qp051_neutron_excess_binding_depth_lane_table.csv"
BAND_SUMMARY_OUT = QP051_DIR / "qp051_band_depth_selector_summary_table.csv"
OPERATOR_SUMMARY_OUT = QP051_DIR / "qp051_binding_operator_selector_summary_table.csv"
DECISION_OUT = QP051_DIR / "qp051_decision_table.csv"
NEXT_OUT = QP051_DIR / "qp051_next_frontier.csv"
SCHEMA_OUT = QP051_DIR / "qp051_schema.csv"
DOC_OUT = REPORTS / "QP051_PRIVATE_NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR.md"
CAMPAIGN = CAMPAIGNS / "SAM_QP049_QP0XX_PHASE5_ISOTOPE_MASS_READOUT_CAMPAIGN.md"

PHASE5_LANE_TABLE = PHASE4 / "phase5_neutron_excess_binding_depth_lanes_v1.csv"
PHASE5_SUMMARY = PHASE4 / "phase5_summary_v3.json"

R = 12

BAND_DEPTH: dict[str, int | None] = {
    "A_LOCAL_NOT_PRESENT": None,
    "BELOW_A_SIDE_COHERENT_FORMATION": 0,
    "A_SIDE_TO_A_SHARE_FUSION_ACCESS": 1,
    "A_SHARE_TO_QG_REORGANIZATION": 2,
    "QG_TO_WRITE_MIDPOINT_DENSE_CONTEXT": 3,
}

BAND_MEANING: dict[str, str] = {
    "A_LOCAL_NOT_PRESENT": "no local A formation value in the Phase 4 element context",
    "BELOW_A_SIDE_COHERENT_FORMATION": "coherent N=Z seed formation below A_SIDE",
    "A_SIDE_TO_A_SHARE_FUSION_ACCESS": "first local fusion-access band above A_SIDE",
    "A_SHARE_TO_QG_REORGANIZATION": "reorganization band above A_SHARE",
    "QG_TO_WRITE_MIDPOINT_DENSE_CONTEXT": "dense context above QG_START and below write midpoint",
}


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP051_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP051 Preflight - Neutron Excess Binding Depth Selector

```text
test_id = QP051
test_name = PRIVATE_NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp050/qp050_summary.json
artifacts/qp050/qp050_symmetric_seed_mass_readout_table.csv
artifacts/qp049/qp049_isotope_seed_identity_table.csv
artifacts/qp047/qp047_element_a_road_context_table.csv
artifacts/qp040/qp040_binding_residue_operator_table.csv
```

## Expected Outputs

```text
artifacts/qp051/qp051_summary.json
artifacts/qp051/qp051_neutron_excess_binding_depth_lane_table.csv
artifacts/qp051/qp051_band_depth_selector_summary_table.csv
artifacts/qp051/qp051_binding_operator_selector_summary_table.csv
docs/reports/QP051_PRIVATE_NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR.md
phase4_tables/phase5_neutron_excess_binding_depth_lanes_v1.csv
```

## Forward Question

```text
Given the QP050 symmetric isotope seed surface, what native lane selects
neutron-excess/binding-depth ownership before final isotope mass readout?
```

This is a new forward selector gate. It does not rerun or audit QP050.
""",
        encoding="utf-8",
    )


def index_by_z(rows: list[dict[str, str]]) -> dict[int, dict[str, str]]:
    return {int(row["atomic_number"]): row for row in rows}


def nuclear_operator_rows(operator_rows: list[dict[str, str]]) -> dict[str, dict[str, str]]:
    out: dict[str, dict[str, str]] = {}
    for row in operator_rows:
        if row["composite_id"] in {"deuteron", "alpha_particle"}:
            out[row["composite_id"]] = row
    return out


def lane_from_depth(depth: int) -> str:
    if depth <= 0:
        return "SYMMETRIC_SEED_DOMINANT_LANE"
    if depth == 1:
        return "FIRST_NEUTRON_EXCESS_WRITE_LANE"
    if depth in {2, 3}:
        return "NEUTRON_RESERVOIR_REORGANIZATION_LANE"
    return "STACKED_NEUTRON_RESERVOIR_LANE"


def selector_source(band_depth: int | None, radix_depth: int) -> str:
    if band_depth is None and radix_depth == 0:
        return "SEED_BASELINE_ONLY"
    if band_depth is None:
        return "RADIX_STACK_DEPTH_ONLY"
    if radix_depth == 0 and band_depth == 0:
        return "A_ROAD_COHERENT_SEED_BASELINE"
    if band_depth > radix_depth:
        return "A_ROAD_DEPTH_DOMINANT"
    if radix_depth > band_depth:
        return "RADIX_STACK_DEPTH_DOMINANT"
    return "A_ROAD_AND_RADIX_DEPTH_AGREE"


def binding_operator_for_row(row: dict[str, str], ops: dict[str, dict[str, str]]) -> tuple[str, dict[str, str]]:
    if int(row["deuteron_residual_units"]) > 0:
        return "DEUTERON_RESIDUAL_TERMINAL_OPERATOR", ops["deuteron"]
    return "ALPHA_STACK_TERMINAL_OPERATOR", ops["alpha_particle"]


def build_lane_rows(
    seed_mass_rows: list[dict[str, str]],
    seed_identity_rows: dict[int, dict[str, str]],
    context_rows: dict[int, dict[str, str]],
    ops: dict[str, dict[str, str]],
) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for mass_row in seed_mass_rows:
        z = int(mass_row["atomic_number"])
        seed_row = seed_identity_rows[z]
        context_row = context_rows[z]
        band = context_row["A_band"]
        band_depth = BAND_DEPTH.get(band)
        radix_cycle = int(seed_row["radix_cycle"])
        radix_depth = max(0, radix_cycle - 1)
        selected_depth = max(radix_depth, band_depth or 0)
        source = selector_source(band_depth, radix_depth)
        lane = lane_from_depth(selected_depth)
        operator_source, op = binding_operator_for_row(mass_row, ops)
        residue_operator = float(op["residue_operator"])
        depth_coordinate = selected_depth * (residue_operator - 1.0)
        A_depth_coordinate = selected_depth / R
        rows.append(
            {
                "atomic_number": z,
                "symbol": mass_row["symbol"],
                "name": mass_row["name"],
                "seed_family": mass_row["seed_family"],
                "seed_vector": mass_row["seed_vector"],
                "Z_seed": mass_row["Z_seed"],
                "N_seed": mass_row["N_seed"],
                "A_seed": mass_row["A_seed"],
                "symmetric_seed_mass_MeV": mass_row["symmetric_seed_mass_MeV"],
                "radix_cycle": radix_cycle,
                "radix_slot": seed_row["radix_slot"],
                "alpha_cycle": seed_row["alpha_cycle"],
                "alpha_slot": seed_row["alpha_slot"],
                "alpha_units": mass_row["alpha_units"],
                "deuteron_residual_units": mass_row["deuteron_residual_units"],
                "formation_lane": context_row["sam_formation_lane"],
                "A_local_at_formation": context_row["A_local_at_formation"],
                "A_band": band,
                "A_band_depth_index": "" if band_depth is None else band_depth,
                "radix_stack_depth_index": radix_depth,
                "selected_neutron_excess_depth_index": selected_depth,
                "selected_neutron_excess_lane": lane,
                "selector_source": source,
                "binding_operator_source": operator_source,
                "binding_operator_composite": op["composite_id"],
                "binding_operator_q": op["q"],
                "binding_residue_operator": f"{residue_operator:.16g}",
                "binding_depth_coordinate": f"{depth_coordinate:.12e}",
                "A_depth_coordinate": f"{A_depth_coordinate:.12e}",
                "deltaN_count_status": "QP052_NUMERIC_DELTA_N_SELECTOR_REQUIRED",
                "final_isotope_mass_status": "QP052_BINDING_DEPTH_MASS_CORRECTION_REQUIRED",
                "selector_status": "FILLED_NEUTRON_EXCESS_BINDING_DEPTH_LANE",
                "next_selector_needed": "QP052_PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR",
                "note": BAND_MEANING.get(band, ""),
            }
        )
    return rows


def summarize_by(rows: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[str(row[key])].append(row)
    out: list[dict[str, Any]] = []
    for value, members in grouped.items():
        depths = [int(row["selected_neutron_excess_depth_index"]) for row in members]
        out.append(
            {
                key: value,
                "rows": len(members),
                "depth_range": f"{min(depths)}..{max(depths)}",
                "symbols": ";".join(str(row["symbol"]) for row in members),
                "lanes_present": ";".join(sorted({str(row["selected_neutron_excess_lane"]) for row in members})),
            }
        )
    return sorted(out, key=lambda row: row[key])


def write_doc(
    summary: dict[str, Any],
    band_summary: list[dict[str, Any]],
    operator_summary: list[dict[str, Any]],
) -> None:
    band_lines = "\n".join(
        f"| {row['A_band']} | {row['rows']} | {row['depth_range']} | {row['lanes_present']} |"
        for row in band_summary
    )
    operator_lines = "\n".join(
        f"| {row['binding_operator_source']} | {row['rows']} | {row['depth_range']} | {row['lanes_present']} |"
        for row in operator_summary
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP051 - Private Neutron Excess Binding Depth Selector

## Preflight

```text
test_id = QP051
test_name = PRIVATE_NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP051 selects a native lane for neutron-excess and binding-depth ownership for
all 118 element seed rows.

The selector uses two existing SAM-native handles:

```text
A-road band depth from QP047
R=12 radix stack depth from QP049
```

and attaches the QP040 nuclear residue operator:

```text
alpha stack rows -> alpha terminal operator
odd residual rows -> deuteron terminal operator
```

## Band Summary

| A band | rows | selected depth range | lanes present |
| --- | ---: | --- | --- |
{band_lines}

## Operator Summary

| operator source | rows | selected depth range | lanes present |
| --- | ---: | --- | --- |
{operator_lines}

## Key Counts

```text
lane_rows_emitted = {summary['lane_rows_emitted']}
selected_lane_count = {summary['selected_lane_count']}
rows_with_positive_depth = {summary['rows_with_positive_neutron_excess_depth']}
rows_seed_depth_zero = {summary['rows_seed_depth_zero']}
observed_isotope_masses_used = {str(summary['observed_isotope_masses_used']).lower()}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

QP051 fills the ownership layer between symmetric isotope seed mass and final
isotope mass. The table now says which native lane carries neutron-excess and
binding-depth pressure for each element row. The next gate can turn this lane
depth into a numeric DeltaN and mass correction.
""",
        encoding="utf-8",
    )


def update_campaign(summary: dict[str, Any]) -> None:
    text = CAMPAIGN.read_text(encoding="utf-8")
    text = text.replace(
        "ACTIVE_PHASE5_ISOTOPE_MASS_READOUT_QP050_COMPLETE_QP051_NEXT",
        "ACTIVE_PHASE5_ISOTOPE_MASS_READOUT_QP051_COMPLETE_QP052_NEXT",
    )
    marker = "### QP051 - Neutron Excess Binding Depth Selector\n"
    result_block = f"""### QP051 - Neutron Excess Binding Depth Selector

Status:

```text
COMPLETE
result_class = {summary['result_class']}
lane_rows_emitted = {summary['lane_rows_emitted']}
selected_lane_count = {summary['selected_lane_count']}
rows_with_positive_neutron_excess_depth = {summary['rows_with_positive_neutron_excess_depth']}
rows_seed_depth_zero = {summary['rows_seed_depth_zero']}
observed_isotope_masses_used = false
free_parameters_introduced = 0
next_frontier = {summary['next_frontier']}
```

Question:

```text
Given the QP050 symmetric seed isotope surface, what native rule selects the
neutron-excess or binding-depth lane needed for final isotope mass/readout?
```

Result:

```text
PASS. QP051 selects a neutron-excess/binding-depth lane for all 118 element
seed rows using QP047 A-road band depth, QP049 R=12 radix stack depth, and the
QP040 nuclear residue operator.
```

Output:

```text
artifacts/qp051/qp051_summary.json
artifacts/qp051/qp051_neutron_excess_binding_depth_lane_table.csv
docs/reports/QP051_PRIVATE_NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR.md
phase4_tables/phase5_neutron_excess_binding_depth_lanes_v1.csv
```

### QP052 - Numeric DeltaN and Binding Mass Selector

Question:

```text
Can SAM convert the QP051 neutron-excess/binding-depth lane into a numeric
DeltaN and isotope mass correction without observed isotope masses?
```

Expected output:

```text
numeric DeltaN selector and binding-depth mass correction, or exact named
boundary
```
"""
    if marker in text:
        before, after = text.split(marker, 1)
        if "## First Move" in after:
            _, tail = after.split("## First Move", 1)
            text = before + result_block + "\n## First Move" + tail
        else:
            text = before + result_block
    text = text.replace(
        "next_test = QP051_PRIVATE_NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR",
        "next_test = QP052_PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR",
    )
    CAMPAIGN.write_text(text, encoding="utf-8")


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp050 = read_json(QP050_SUMMARY)
    seed_mass_rows = read_csv(QP050_SEED_MASS_TABLE)
    seed_identity = index_by_z(read_csv(QP049_SEED_TABLE))
    context = index_by_z(read_csv(QP047_ELEMENT_CONTEXT))
    ops = nuclear_operator_rows(read_csv(QP040_BINDING_OPERATOR))

    lane_rows = build_lane_rows(seed_mass_rows, seed_identity, context, ops)
    band_summary = summarize_by(lane_rows, "A_band")
    operator_summary = summarize_by(lane_rows, "binding_operator_source")
    lane_counts = Counter(row["selected_neutron_excess_lane"] for row in lane_rows)
    source_counts = Counter(row["selector_source"] for row in lane_rows)

    positive_depth = sum(int(row["selected_neutron_excess_depth_index"]) > 0 for row in lane_rows)
    zero_depth = len(lane_rows) - positive_depth

    summary = {
        "artifact": "QP051_PRIVATE_NEUTRON_EXCESS_BINDING_DEPTH_SELECTOR",
        "result_class": "QP051_NEUTRON_EXCESS_BINDING_DEPTH_LANES_SELECTED",
        "campaign_status": "QP051_NEUTRON_EXCESS_BINDING_DEPTH_SELECTED_QP052_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_isotope_masses_used": False,
        "observed_abundance_used_as_selector": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp050/qp050_summary.json",
            "artifacts/qp050/qp050_symmetric_seed_mass_readout_table.csv",
            "artifacts/qp049/qp049_isotope_seed_identity_table.csv",
            "artifacts/qp047/qp047_element_a_road_context_table.csv",
            "artifacts/qp040/qp040_binding_residue_operator_table.csv",
        ],
        "qp050_result_class": qp050["result_class"],
        "lane_rows_emitted": len(lane_rows),
        "selected_lane_count": len(lane_counts),
        "selected_lane_counts": dict(lane_counts),
        "selector_source_counts": dict(source_counts),
        "rows_with_positive_neutron_excess_depth": positive_depth,
        "rows_seed_depth_zero": zero_depth,
        "binding_operator_source_counts": dict(Counter(row["binding_operator_source"] for row in lane_rows)),
        "final_isotope_mass_rows_emitted": 0,
        "numeric_deltaN_rows_emitted": 0,
        "next_frontier": "QP052_PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR",
        "interpretation": (
            "QP051 selects neutron-excess/binding-depth lanes for the isotope layer from A-road band depth, "
            "R=12 radix stack depth, and the QP040 nuclear residue operator."
        ),
    }

    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "new neutron-excess/binding-depth selector; not audit, not retest, no public write",
        },
        {
            "decision_point": "lane_selector",
            "decision": "SELECT_MAX_A_ROAD_DEPTH_AND_RADIX_STACK_DEPTH",
            "note": "A-road formation depth and R=12 stack depth select lane ownership",
        },
        {
            "decision_point": "binding_operator",
            "decision": "ATTACH_QP040_ALPHA_OR_DEUTERON_TERMINAL_OPERATOR",
            "note": "even alpha-stack rows use alpha terminal operator; odd residual rows use deuteron terminal operator",
        },
        {
            "decision_point": "numeric_deltaN",
            "decision": "QP052_REQUIRED",
            "note": "QP051 emits depth lanes and operator coordinates; numeric DeltaN is next",
        },
    ]
    next_rows = [
        {
            "next_frontier": "QP052_PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR",
            "why_next": "QP051 selects the lane and operator; final isotope readout needs numeric DeltaN and binding-depth mass correction.",
            "launch_from": "qp051_neutron_excess_binding_depth_lane_table.csv",
            "target_output": "numeric DeltaN selector and binding-depth mass correction",
        }
    ]
    schema_rows = [
        {
            "field": "selected_neutron_excess_depth_index",
            "meaning": "native depth index from max(A-road band depth, R=12 stack depth)",
            "class": "selector_depth",
        },
        {
            "field": "selected_neutron_excess_lane",
            "meaning": "native lane that owns neutron-excess/binding-depth pressure",
            "class": "selector_lane",
        },
        {
            "field": "binding_depth_coordinate",
            "meaning": "dimensionless depth coordinate from selected depth and QP040 residue operator",
            "class": "binding_depth_coordinate",
        },
    ]

    lane_fields = [
        "atomic_number",
        "symbol",
        "name",
        "seed_family",
        "seed_vector",
        "Z_seed",
        "N_seed",
        "A_seed",
        "symmetric_seed_mass_MeV",
        "radix_cycle",
        "radix_slot",
        "alpha_cycle",
        "alpha_slot",
        "alpha_units",
        "deuteron_residual_units",
        "formation_lane",
        "A_local_at_formation",
        "A_band",
        "A_band_depth_index",
        "radix_stack_depth_index",
        "selected_neutron_excess_depth_index",
        "selected_neutron_excess_lane",
        "selector_source",
        "binding_operator_source",
        "binding_operator_composite",
        "binding_operator_q",
        "binding_residue_operator",
        "binding_depth_coordinate",
        "A_depth_coordinate",
        "deltaN_count_status",
        "final_isotope_mass_status",
        "selector_status",
        "next_selector_needed",
        "note",
    ]
    write_json(SUMMARY_OUT, summary)
    write_json(PHASE5_SUMMARY, summary)
    write_csv(LANE_OUT, lane_rows, lane_fields)
    write_csv(PHASE5_LANE_TABLE, lane_rows, lane_fields)
    write_csv(BAND_SUMMARY_OUT, band_summary, ["A_band", "rows", "depth_range", "symbols", "lanes_present"])
    write_csv(
        OPERATOR_SUMMARY_OUT,
        operator_summary,
        ["binding_operator_source", "rows", "depth_range", "symbols", "lanes_present"],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, band_summary, operator_summary)
    update_campaign(summary)

    print(summary["result_class"])
    print(f"lane_rows_emitted={summary['lane_rows_emitted']}")
    print(f"selected_lane_count={summary['selected_lane_count']}")
    print(f"rows_with_positive_neutron_excess_depth={summary['rows_with_positive_neutron_excess_depth']}")
    print(f"rows_seed_depth_zero={summary['rows_seed_depth_zero']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
