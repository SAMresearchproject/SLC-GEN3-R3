from __future__ import annotations

import csv
import json
import math
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
CAMPAIGNS = ROOT / "docs" / "campaigns"
PHASE4 = ROOT / "phase4_tables"

QP051_SUMMARY = ARTIFACTS / "qp051" / "qp051_summary.json"
QP051_LANE_TABLE = ARTIFACTS / "qp051" / "qp051_neutron_excess_binding_depth_lane_table.csv"
PHASE4_SUPPORT_TABLE = PHASE4 / "phase4_composite_support_table.csv"

QP052_DIR = ARTIFACTS / "qp052"
PREFLIGHT_OUT = QP052_DIR / "qp052_preflight.md"
SUMMARY_OUT = QP052_DIR / "qp052_summary.json"
MASS_TABLE_OUT = QP052_DIR / "qp052_numeric_deltaN_binding_mass_table.csv"
DEPTH_SUMMARY_OUT = QP052_DIR / "qp052_depth_packet_summary_table.csv"
LANE_SUMMARY_OUT = QP052_DIR / "qp052_lane_mass_summary_table.csv"
DECISION_OUT = QP052_DIR / "qp052_decision_table.csv"
NEXT_OUT = QP052_DIR / "qp052_next_frontier.csv"
SCHEMA_OUT = QP052_DIR / "qp052_schema.csv"
DOC_OUT = REPORTS / "QP052_PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR.md"
CAMPAIGN = CAMPAIGNS / "SAM_QP049_QP0XX_PHASE5_ISOTOPE_MASS_READOUT_CAMPAIGN.md"

PHASE5_MASS_TABLE = PHASE4 / "phase5_numeric_deltaN_binding_mass_v1.csv"
PHASE5_SUMMARY = PHASE4 / "phase5_summary_v4.json"

R = 12


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP052_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP052 Preflight - Numeric DeltaN and Binding Mass Selector

```text
test_id = QP052
test_name = PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp051/qp051_summary.json
artifacts/qp051/qp051_neutron_excess_binding_depth_lane_table.csv
phase4_tables/phase4_composite_support_table.csv
```

## Expected Outputs

```text
artifacts/qp052/qp052_summary.json
artifacts/qp052/qp052_numeric_deltaN_binding_mass_table.csv
artifacts/qp052/qp052_depth_packet_summary_table.csv
artifacts/qp052/qp052_lane_mass_summary_table.csv
docs/reports/QP052_PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR.md
phase4_tables/phase5_numeric_deltaN_binding_mass_v1.csv
```

## Forward Question

```text
Can SAM convert the QP051 neutron-excess depth lane into closed integer
DeltaN packets and a native bound-neutron mass correction?
```

This is a new forward selector gate. It does not rerun or audit QP051.
""",
        encoding="utf-8",
    )


def support_mass(rows: list[dict[str, str]], composite_id: str) -> float:
    for row in rows:
        if row["composite_id"] == composite_id:
            return float(row["sam_mass_MeV"])
    raise KeyError(composite_id)


def build_mass_rows(lane_rows: list[dict[str, str]], neutron_mass: float) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in lane_rows:
        z = int(row["atomic_number"])
        n_seed = int(row["N_seed"])
        a_seed = int(row["A_seed"])
        depth = int(row["selected_neutron_excess_depth_index"])
        raw_packets = z * depth / R
        delta_n = math.floor(raw_packets)
        residual = raw_packets - delta_n
        residue_operator = float(row["binding_residue_operator"])
        operator_gap = residue_operator - 1.0
        added_neutron_mass = delta_n * neutron_mass
        bound_neutron_mass_correction = -added_neutron_mass * operator_gap
        final_mass = float(row["symmetric_seed_mass_MeV"]) + added_neutron_mass + bound_neutron_mass_correction
        n_candidate = n_seed + delta_n
        a_candidate = a_seed + delta_n
        rows.append(
            {
                "atomic_number": z,
                "symbol": row["symbol"],
                "name": row["name"],
                "seed_family": row["seed_family"],
                "selected_neutron_excess_lane": row["selected_neutron_excess_lane"],
                "selector_source": row["selector_source"],
                "binding_operator_source": row["binding_operator_source"],
                "binding_operator_composite": row["binding_operator_composite"],
                "binding_residue_operator": row["binding_residue_operator"],
                "Z_candidate": z,
                "N_seed": n_seed,
                "A_seed": a_seed,
                "selected_depth_index": depth,
                "deltaN_raw_exposure": f"{raw_packets:.12e}",
                "deltaN_closed_packets": delta_n,
                "deltaN_fractional_residual": f"{residual:.12e}",
                "N_candidate": n_candidate,
                "A_candidate": a_candidate,
                "symmetric_seed_mass_MeV": row["symmetric_seed_mass_MeV"],
                "M_neutron_MeV": f"{neutron_mass:.12e}",
                "added_neutron_mass_MeV": f"{added_neutron_mass:.12e}",
                "binding_operator_gap": f"{operator_gap:.12e}",
                "bound_neutron_mass_correction_MeV": f"{bound_neutron_mass_correction:.12e}",
                "sam_isotope_mass_candidate_MeV": f"{final_mass:.12e}",
                "mass_per_nucleon_candidate_MeV": f"{final_mass / a_candidate:.12e}",
                "deltaN_law": "DeltaN=floor(Z*selected_depth_index/R)",
                "binding_mass_law": "M_candidate=M_seed+DeltaN*M_neutron-DeltaN*M_neutron*(R_bind-1)",
                "packet_closure_status": "FILLED_NUMERIC_DELTA_N_PACKET_COUNT",
                "mass_readout_status": "FILLED_SAM_ISOTOPE_MASS_CANDIDATE",
                "next_selector_needed": "QP053_PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR",
            }
        )
    return rows


def summarize(rows: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[str(row[key])].append(row)
    out: list[dict[str, Any]] = []
    for value, members in grouped.items():
        delta_ns = [int(row["deltaN_closed_packets"]) for row in members]
        masses = [float(row["sam_isotope_mass_candidate_MeV"]) for row in members]
        out.append(
            {
                key: value,
                "rows": len(members),
                "deltaN_range": f"{min(delta_ns)}..{max(delta_ns)}",
                "mass_candidate_range_MeV": f"{min(masses):.6e}..{max(masses):.6e}",
                "symbols": ";".join(str(row["symbol"]) for row in members),
            }
        )
    return sorted(out, key=lambda row: row[key])


def write_doc(summary: dict[str, Any], depth_summary: list[dict[str, Any]], lane_summary: list[dict[str, Any]]) -> None:
    depth_lines = "\n".join(
        f"| {row['selected_depth_index']} | {row['rows']} | {row['deltaN_range']} | {row['mass_candidate_range_MeV']} |"
        for row in depth_summary
    )
    lane_lines = "\n".join(
        f"| {row['selected_neutron_excess_lane']} | {row['rows']} | {row['deltaN_range']} | {row['mass_candidate_range_MeV']} |"
        for row in lane_summary
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP052 - Private Numeric DeltaN and Binding Mass Selector

## Preflight

```text
test_id = QP052
test_name = PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP052 turns the QP051 depth lane into closed neutron packets:

```text
DeltaN = floor(Z * selected_depth_index / R)
R = 12
```

and emits a native isotope mass candidate:

```text
M_candidate = M_seed + DeltaN*M_neutron - DeltaN*M_neutron*(R_bind - 1)
```

The floor operation is the packet-closure rule: fractional exposure remains a
residual lane until a whole neutron packet closes.

## Depth Summary

| selected depth | rows | DeltaN range | mass candidate range MeV |
| ---: | ---: | --- | --- |
{depth_lines}

## Lane Summary

| selected lane | rows | DeltaN range | mass candidate range MeV |
| --- | ---: | --- | --- |
{lane_lines}

## Key Counts

```text
mass_candidate_rows_emitted = {summary['mass_candidate_rows_emitted']}
positive_deltaN_rows = {summary['positive_deltaN_rows']}
zero_deltaN_rows = {summary['zero_deltaN_rows']}
max_deltaN_closed_packets = {summary['max_deltaN_closed_packets']}
observed_isotope_masses_used = {str(summary['observed_isotope_masses_used']).lower()}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

QP052 fills the first full numeric isotope readout layer: each element row now
has a SAM-native DeltaN packet count, candidate N/A, and mass candidate derived
from the seed surface, neutron support mass, and QP040 binding residue operator.
""",
        encoding="utf-8",
    )


def update_campaign(summary: dict[str, Any]) -> None:
    text = CAMPAIGN.read_text(encoding="utf-8")
    text = text.replace(
        "ACTIVE_PHASE5_ISOTOPE_MASS_READOUT_QP051_COMPLETE_QP052_NEXT",
        "ACTIVE_PHASE5_ISOTOPE_MASS_READOUT_QP052_COMPLETE_QP053_NEXT",
    )
    marker = "### QP052 - Numeric DeltaN and Binding Mass Selector\n"
    result_block = f"""### QP052 - Numeric DeltaN and Binding Mass Selector

Status:

```text
COMPLETE
result_class = {summary['result_class']}
mass_candidate_rows_emitted = {summary['mass_candidate_rows_emitted']}
positive_deltaN_rows = {summary['positive_deltaN_rows']}
zero_deltaN_rows = {summary['zero_deltaN_rows']}
max_deltaN_closed_packets = {summary['max_deltaN_closed_packets']}
observed_isotope_masses_used = false
free_parameters_introduced = 0
next_frontier = {summary['next_frontier']}
```

Question:

```text
Can SAM convert the QP051 neutron-excess/binding-depth lane into a numeric
DeltaN and isotope mass correction without observed isotope masses?
```

Result:

```text
PASS. QP052 emits a numeric DeltaN packet count and SAM isotope mass candidate
for all 118 element rows using DeltaN=floor(Z*depth/R) and the QP040 nuclear
binding residue operator.
```

Output:

```text
artifacts/qp052/qp052_summary.json
artifacts/qp052/qp052_numeric_deltaN_binding_mass_table.csv
docs/reports/QP052_PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR.md
phase4_tables/phase5_numeric_deltaN_binding_mass_v1.csv
```

### QP053 - Isotope Roster Stability Selector

Question:

```text
Can SAM split the QP052 isotope candidate surface into stable, beta-active,
and synthetic/transient roster lanes without observed isotope masses?
```

Expected output:

```text
isotope roster stability selector, or exact named boundary
```
"""
    if marker in text:
        before, after = text.split(marker, 1)
        if "## First Move" in after:
            _, tail = after.split("## First Move", 1)
            text = before + result_block + "\n## First Move" + tail
        else:
            text = before + result_block
    text = text.replace(
        "next_test = QP052_PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR",
        "next_test = QP053_PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR",
    )
    CAMPAIGN.write_text(text, encoding="utf-8")


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp051 = read_json(QP051_SUMMARY)
    lane_rows = read_csv(QP051_LANE_TABLE)
    support_rows = read_csv(PHASE4_SUPPORT_TABLE)
    neutron_mass = support_mass(support_rows, "neutron")
    mass_rows = build_mass_rows(lane_rows, neutron_mass)
    depth_summary = summarize(mass_rows, "selected_depth_index")
    lane_summary = summarize(mass_rows, "selected_neutron_excess_lane")
    delta_ns = [int(row["deltaN_closed_packets"]) for row in mass_rows]
    masses = [float(row["sam_isotope_mass_candidate_MeV"]) for row in mass_rows]

    summary = {
        "artifact": "QP052_PRIVATE_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTOR",
        "result_class": "QP052_NUMERIC_DELTA_N_AND_BINDING_MASS_SELECTED",
        "campaign_status": "QP052_NUMERIC_DELTA_N_BINDING_MASS_SELECTED_QP053_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_isotope_masses_used": False,
        "observed_abundance_used_as_selector": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp051/qp051_summary.json",
            "artifacts/qp051/qp051_neutron_excess_binding_depth_lane_table.csv",
            "phase4_tables/phase4_composite_support_table.csv",
        ],
        "qp051_result_class": qp051["result_class"],
        "deltaN_law": "DeltaN=floor(Z*selected_depth_index/R)",
        "binding_mass_law": "M_candidate=M_seed+DeltaN*M_neutron-DeltaN*M_neutron*(R_bind-1)",
        "R": R,
        "M_neutron_MeV": f"{neutron_mass:.12e}",
        "mass_candidate_rows_emitted": len(mass_rows),
        "positive_deltaN_rows": sum(delta_n > 0 for delta_n in delta_ns),
        "zero_deltaN_rows": sum(delta_n == 0 for delta_n in delta_ns),
        "max_deltaN_closed_packets": max(delta_ns),
        "candidate_mass_range_MeV": f"{min(masses):.12e}..{max(masses):.12e}",
        "final_roster_stability_rows_emitted": 0,
        "next_frontier": "QP053_PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR",
        "interpretation": (
            "QP052 converts QP051 lane depth into integer neutron packet count and a SAM isotope mass candidate "
            "using the native neutron support mass and QP040 binding residue operator."
        ),
    }

    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "new numeric DeltaN and binding mass selector; not audit, not retest, no public write",
        },
        {
            "decision_point": "deltaN_packet_law",
            "decision": "SELECT_FLOOR_PACKET_CLOSURE",
            "note": "fractional exposure is retained as residual; closed integer packet count is floor(Z*depth/R)",
        },
        {
            "decision_point": "binding_mass_law",
            "decision": "SELECT_QP040_BOUND_NEUTRON_CORRECTION",
            "note": "neutron addition is corrected by terminal alpha/deuteron residue operator gap",
        },
        {
            "decision_point": "roster_stability",
            "decision": "QP053_REQUIRED",
            "note": "QP052 emits one candidate surface; isotope roster/stability branching is next",
        },
    ]
    next_rows = [
        {
            "next_frontier": "QP053_PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR",
            "why_next": "QP052 emits one candidate isotope surface; the roster still needs stability and transient lane splitting.",
            "launch_from": "qp052_numeric_deltaN_binding_mass_table.csv",
            "target_output": "stable/beta-active/synthetic isotope roster lane selector",
        }
    ]
    schema_rows = [
        {
            "field": "deltaN_closed_packets",
            "meaning": "integer neutron-excess packets closed by floor(Z*depth/R)",
            "class": "numeric_deltaN",
        },
        {
            "field": "sam_isotope_mass_candidate_MeV",
            "meaning": "candidate mass from seed mass, closed neutron packets, and binding correction",
            "class": "mass_candidate",
        },
        {
            "field": "deltaN_fractional_residual",
            "meaning": "unclosed fractional exposure remaining after packet closure",
            "class": "residual_lane",
        },
    ]

    fields = [
        "atomic_number",
        "symbol",
        "name",
        "seed_family",
        "selected_neutron_excess_lane",
        "selector_source",
        "binding_operator_source",
        "binding_operator_composite",
        "binding_residue_operator",
        "Z_candidate",
        "N_seed",
        "A_seed",
        "selected_depth_index",
        "deltaN_raw_exposure",
        "deltaN_closed_packets",
        "deltaN_fractional_residual",
        "N_candidate",
        "A_candidate",
        "symmetric_seed_mass_MeV",
        "M_neutron_MeV",
        "added_neutron_mass_MeV",
        "binding_operator_gap",
        "bound_neutron_mass_correction_MeV",
        "sam_isotope_mass_candidate_MeV",
        "mass_per_nucleon_candidate_MeV",
        "deltaN_law",
        "binding_mass_law",
        "packet_closure_status",
        "mass_readout_status",
        "next_selector_needed",
    ]
    write_json(SUMMARY_OUT, summary)
    write_json(PHASE5_SUMMARY, summary)
    write_csv(MASS_TABLE_OUT, mass_rows, fields)
    write_csv(PHASE5_MASS_TABLE, mass_rows, fields)
    write_csv(DEPTH_SUMMARY_OUT, depth_summary, ["selected_depth_index", "rows", "deltaN_range", "mass_candidate_range_MeV", "symbols"])
    write_csv(
        LANE_SUMMARY_OUT,
        lane_summary,
        ["selected_neutron_excess_lane", "rows", "deltaN_range", "mass_candidate_range_MeV", "symbols"],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, depth_summary, lane_summary)
    update_campaign(summary)

    print(summary["result_class"])
    print(f"mass_candidate_rows_emitted={summary['mass_candidate_rows_emitted']}")
    print(f"positive_deltaN_rows={summary['positive_deltaN_rows']}")
    print(f"zero_deltaN_rows={summary['zero_deltaN_rows']}")
    print(f"max_deltaN_closed_packets={summary['max_deltaN_closed_packets']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
