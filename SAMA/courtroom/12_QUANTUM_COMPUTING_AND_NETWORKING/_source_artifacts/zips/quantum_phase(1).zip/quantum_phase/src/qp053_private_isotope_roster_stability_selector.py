from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
CAMPAIGNS = ROOT / "docs" / "campaigns"
PHASE4 = ROOT / "phase4_tables"

QP052_SUMMARY = ARTIFACTS / "qp052" / "qp052_summary.json"
QP052_MASS_TABLE = ARTIFACTS / "qp052" / "qp052_numeric_deltaN_binding_mass_table.csv"
QP051_LANE_TABLE = ARTIFACTS / "qp051" / "qp051_neutron_excess_binding_depth_lane_table.csv"

QP053_DIR = ARTIFACTS / "qp053"
PREFLIGHT_OUT = QP053_DIR / "qp053_preflight.md"
SUMMARY_OUT = QP053_DIR / "qp053_summary.json"
ROSTER_OUT = QP053_DIR / "qp053_isotope_roster_stability_lane_table.csv"
RESIDUAL_SUMMARY_OUT = QP053_DIR / "qp053_residual_twelfths_summary_table.csv"
ROSTER_SUMMARY_OUT = QP053_DIR / "qp053_roster_lane_summary_table.csv"
ANCHOR_OUT = QP053_DIR / "qp053_anchor_candidate_table.csv"
DECISION_OUT = QP053_DIR / "qp053_decision_table.csv"
NEXT_OUT = QP053_DIR / "qp053_next_frontier.csv"
SCHEMA_OUT = QP053_DIR / "qp053_schema.csv"
DOC_OUT = REPORTS / "QP053_PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR.md"
CAMPAIGN = CAMPAIGNS / "SAM_QP049_QP0XX_PHASE5_ISOTOPE_MASS_READOUT_CAMPAIGN.md"

PHASE5_ROSTER_TABLE = PHASE4 / "phase5_isotope_roster_stability_lanes_v1.csv"
PHASE5_SUMMARY = PHASE4 / "phase5_summary_v5.json"

R = 12


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP053_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP053 Preflight - Isotope Roster Stability Selector

```text
test_id = QP053
test_name = PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp052/qp052_summary.json
artifacts/qp052/qp052_numeric_deltaN_binding_mass_table.csv
artifacts/qp051/qp051_neutron_excess_binding_depth_lane_table.csv
```

## Expected Outputs

```text
artifacts/qp053/qp053_summary.json
artifacts/qp053/qp053_isotope_roster_stability_lane_table.csv
artifacts/qp053/qp053_residual_twelfths_summary_table.csv
artifacts/qp053/qp053_roster_lane_summary_table.csv
docs/reports/QP053_PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR.md
phase4_tables/phase5_isotope_roster_stability_lanes_v1.csv
```

## Forward Question

```text
Can the QP052 fractional packet residual select isotope roster/stability lanes
without observed isotope masses?
```

This is a new forward roster split. It does not rerun or audit QP052.
""",
        encoding="utf-8",
    )


def index_by_z(rows: list[dict[str, str]]) -> dict[int, dict[str, str]]:
    return {int(row["atomic_number"]): row for row in rows}


def residual_class(units: int) -> str:
    if units == 0:
        return "EXACT_PACKET_CLOSURE"
    if units == 6:
        return "HALF_WRITE_RESIDUAL"
    if units in {4, 8}:
        return "TRIADIC_RESIDUAL"
    if units in {3, 9}:
        return "QUARTER_RESIDUAL"
    if units in {2, 10}:
        return "SIXTH_RESIDUAL"
    return "OFF_AXIS_RESIDUAL"


def roster_lane(units: int, formation_lane: str, A_band: str) -> str:
    if "SYNTHETIC" in formation_lane:
        return "SYNTHETIC_TRANSIENT_ROSTER_LANE"
    if "ACTINIDE" in formation_lane:
        return "ACTINIDE_TERMINUS_ROSTER_LANE"
    if units in {0, 6} and A_band == "QG_TO_WRITE_MIDPOINT_DENSE_CONTEXT":
        return "DENSE_CONTEXT_ANCHOR_ROSTER_LANE"
    if units == 0:
        return "EXACT_CLOSURE_ANCHOR_ROSTER_LANE"
    if units == 6:
        return "HALF_WRITE_ANCHOR_ROSTER_LANE"
    if units in {4, 8}:
        return "TRIADIC_BRANCH_ROSTER_LANE"
    if units in {3, 9}:
        return "QUARTER_BRANCH_ROSTER_LANE"
    if units in {2, 10}:
        return "SIXTH_BRANCH_ROSTER_LANE"
    return "OFF_AXIS_BRANCH_ROSTER_LANE"


def build_roster_rows(mass_rows: list[dict[str, str]], lane_by_z: dict[int, dict[str, str]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in mass_rows:
        z = int(row["atomic_number"])
        lane_row = lane_by_z[z]
        residual = float(row["deltaN_fractional_residual"])
        units = int(round(residual * R)) % R
        r_class = residual_class(units)
        r_lane = roster_lane(units, lane_row["formation_lane"], lane_row["A_band"])
        anchor_status = (
            "ANCHOR_CANDIDATE"
            if r_lane in {
                "EXACT_CLOSURE_ANCHOR_ROSTER_LANE",
                "HALF_WRITE_ANCHOR_ROSTER_LANE",
                "DENSE_CONTEXT_ANCHOR_ROSTER_LANE",
            }
            else "BRANCH_CANDIDATE"
        )
        rows.append(
            {
                "atomic_number": z,
                "symbol": row["symbol"],
                "name": row["name"],
                "Z_candidate": row["Z_candidate"],
                "N_candidate": row["N_candidate"],
                "A_candidate": row["A_candidate"],
                "sam_isotope_mass_candidate_MeV": row["sam_isotope_mass_candidate_MeV"],
                "selected_depth_index": row["selected_depth_index"],
                "deltaN_closed_packets": row["deltaN_closed_packets"],
                "deltaN_fractional_residual": row["deltaN_fractional_residual"],
                "residual_twelfths": units,
                "residual_fraction_native": f"{units}/12",
                "residual_class": r_class,
                "roster_stability_lane": r_lane,
                "anchor_status": anchor_status,
                "formation_lane": lane_row["formation_lane"],
                "A_band": lane_row["A_band"],
                "selected_neutron_excess_lane": row["selected_neutron_excess_lane"],
                "selector_status": "FILLED_ISOTOPE_ROSTER_STABILITY_LANE",
                "next_selector_needed": "QP054_PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR",
            }
        )
    return rows


def summarize(rows: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[str(row[key])].append(row)
    out: list[dict[str, Any]] = []
    for value, members in grouped.items():
        out.append(
            {
                key: value,
                "rows": len(members),
                "symbols": ";".join(str(row["symbol"]) for row in members),
                "A_candidate_range": f"{min(int(row['A_candidate']) for row in members)}..{max(int(row['A_candidate']) for row in members)}",
                "anchor_statuses": ";".join(sorted({str(row["anchor_status"]) for row in members})),
            }
        )
    return sorted(out, key=lambda row: row[key])


def write_doc(
    summary: dict[str, Any],
    residual_summary: list[dict[str, Any]],
    roster_summary: list[dict[str, Any]],
) -> None:
    residual_lines = "\n".join(
        f"| {row['residual_twelfths']} | {row['rows']} | {row['A_candidate_range']} | {row['anchor_statuses']} |"
        for row in residual_summary
    )
    roster_lines = "\n".join(
        f"| {row['roster_stability_lane']} | {row['rows']} | {row['A_candidate_range']} | {row['anchor_statuses']} |"
        for row in roster_summary
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP053 - Private Isotope Roster Stability Selector

## Preflight

```text
test_id = QP053
test_name = PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP053 converts the QP052 fractional packet residual into R=12 roster lanes:

```text
residual_twelfths = round(deltaN_fractional_residual * 12)
```

The split uses exact closure, half-write, triadic, quarter, sixth, and off-axis
residual classes, with formation-lane routing for synthetic and actinide
terminus rows.

## Residual Summary

| residual twelfths | rows | A candidate range | anchor statuses |
| ---: | ---: | --- | --- |
{residual_lines}

## Roster Lane Summary

| roster lane | rows | A candidate range | anchor statuses |
| --- | ---: | --- | --- |
{roster_lines}

## Key Counts

```text
roster_rows_emitted = {summary['roster_rows_emitted']}
anchor_candidate_rows = {summary['anchor_candidate_rows']}
branch_candidate_rows = {summary['branch_candidate_rows']}
roster_lane_count = {summary['roster_lane_count']}
observed_isotope_masses_used = {str(summary['observed_isotope_masses_used']).lower()}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

QP053 fills the first isotope roster/stability layer. QP052 produced a single
candidate isotope surface; QP053 now marks whether each row is an exact/half
anchor candidate, a structured residual branch, or a synthetic/transient route.
""",
        encoding="utf-8",
    )


def update_campaign(summary: dict[str, Any]) -> None:
    text = CAMPAIGN.read_text(encoding="utf-8")
    text = text.replace(
        "ACTIVE_PHASE5_ISOTOPE_MASS_READOUT_QP052_COMPLETE_QP053_NEXT",
        "ACTIVE_PHASE5_ISOTOPE_MASS_READOUT_QP053_COMPLETE_QP054_NEXT",
    )
    marker = "### QP053 - Isotope Roster Stability Selector\n"
    result_block = f"""### QP053 - Isotope Roster Stability Selector

Status:

```text
COMPLETE
result_class = {summary['result_class']}
roster_rows_emitted = {summary['roster_rows_emitted']}
anchor_candidate_rows = {summary['anchor_candidate_rows']}
branch_candidate_rows = {summary['branch_candidate_rows']}
roster_lane_count = {summary['roster_lane_count']}
observed_isotope_masses_used = false
free_parameters_introduced = 0
next_frontier = {summary['next_frontier']}
```

Question:

```text
Can SAM split the QP052 isotope candidate surface into stable, beta-active,
and synthetic/transient roster lanes without observed isotope masses?
```

Result:

```text
PASS. QP053 emits isotope roster/stability lanes for all 118 candidate rows
from the QP052 fractional packet residual and the QP051 formation/A-band lane.
```

Output:

```text
artifacts/qp053/qp053_summary.json
artifacts/qp053/qp053_isotope_roster_stability_lane_table.csv
docs/reports/QP053_PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR.md
phase4_tables/phase5_isotope_roster_stability_lanes_v1.csv
```

### QP054 - Isotope Neighbor Ladder Selector

Question:

```text
Can SAM use the residual-twelfths roster lane to generate neighboring isotope
ladder candidates around the QP052 primary candidate?
```

Expected output:

```text
native isotope neighbor ladder, or exact named boundary
```
"""
    if marker in text:
        before, after = text.split(marker, 1)
        if "## First Move" in after:
            _, tail = after.split("## First Move", 1)
            text = before + result_block + "\n## First Move" + tail
        else:
            text = before + result_block
    text = text.replace(
        "next_test = QP053_PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR",
        "next_test = QP054_PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR",
    )
    CAMPAIGN.write_text(text, encoding="utf-8")


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp052 = read_json(QP052_SUMMARY)
    mass_rows = read_csv(QP052_MASS_TABLE)
    lane_by_z = index_by_z(read_csv(QP051_LANE_TABLE))
    roster_rows = build_roster_rows(mass_rows, lane_by_z)
    residual_summary = summarize(roster_rows, "residual_twelfths")
    roster_summary = summarize(roster_rows, "roster_stability_lane")
    anchor_rows = [row for row in roster_rows if row["anchor_status"] == "ANCHOR_CANDIDATE"]
    lane_counts = Counter(row["roster_stability_lane"] for row in roster_rows)
    residual_counts = Counter(row["residual_twelfths"] for row in roster_rows)

    summary = {
        "artifact": "QP053_PRIVATE_ISOTOPE_ROSTER_STABILITY_SELECTOR",
        "result_class": "QP053_ISOTOPE_ROSTER_STABILITY_LANES_SELECTED",
        "campaign_status": "QP053_ROSTER_STABILITY_SELECTED_QP054_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_isotope_masses_used": False,
        "observed_abundance_used_as_selector": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp052/qp052_summary.json",
            "artifacts/qp052/qp052_numeric_deltaN_binding_mass_table.csv",
            "artifacts/qp051/qp051_neutron_excess_binding_depth_lane_table.csv",
        ],
        "qp052_result_class": qp052["result_class"],
        "residual_law": "residual_twelfths=round(deltaN_fractional_residual*12)",
        "roster_rows_emitted": len(roster_rows),
        "anchor_candidate_rows": len(anchor_rows),
        "branch_candidate_rows": len(roster_rows) - len(anchor_rows),
        "roster_lane_count": len(lane_counts),
        "roster_lane_counts": dict(lane_counts),
        "residual_twelfths_counts": dict(residual_counts),
        "next_frontier": "QP054_PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR",
        "interpretation": (
            "QP053 converts QP052 fractional packet residuals into isotope roster/stability lanes using R=12 residual classes "
            "and QP051 formation/A-band routing."
        ),
    }

    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "new isotope roster/stability selector; not audit, not retest, no public write",
        },
        {
            "decision_point": "residual_law",
            "decision": "SELECT_R12_FRACTIONAL_PACKET_RESIDUAL",
            "note": "fractional DeltaN residual maps to residual_twelfths",
        },
        {
            "decision_point": "roster_lane",
            "decision": "SELECT_ANCHOR_BRANCH_SYNTHETIC_ROUTE_CLASSES",
            "note": "exact/half residuals anchor; triadic/quarter/sixth/off-axis residuals branch; formation lane routes synthetic rows",
        },
        {
            "decision_point": "neighbor_ladder",
            "decision": "QP054_REQUIRED",
            "note": "residual lane can now generate neighboring isotope ladder candidates",
        },
    ]
    next_rows = [
        {
            "next_frontier": "QP054_PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR",
            "why_next": "QP053 classifies residual lanes; neighboring isotope candidates should be generated from the residual twelfths.",
            "launch_from": "qp053_isotope_roster_stability_lane_table.csv",
            "target_output": "native isotope neighbor ladder",
        }
    ]
    schema_rows = [
        {
            "field": "residual_twelfths",
            "meaning": "R=12 fractional packet residual from QP052",
            "class": "residual_coordinate",
        },
        {
            "field": "roster_stability_lane",
            "meaning": "native roster/stability lane selected from residual class and formation routing",
            "class": "roster_selector",
        },
        {
            "field": "anchor_status",
            "meaning": "anchor or branch candidate status for the isotope row",
            "class": "roster_status",
        },
    ]

    fields = [
        "atomic_number",
        "symbol",
        "name",
        "Z_candidate",
        "N_candidate",
        "A_candidate",
        "sam_isotope_mass_candidate_MeV",
        "selected_depth_index",
        "deltaN_closed_packets",
        "deltaN_fractional_residual",
        "residual_twelfths",
        "residual_fraction_native",
        "residual_class",
        "roster_stability_lane",
        "anchor_status",
        "formation_lane",
        "A_band",
        "selected_neutron_excess_lane",
        "selector_status",
        "next_selector_needed",
    ]
    write_json(SUMMARY_OUT, summary)
    write_json(PHASE5_SUMMARY, summary)
    write_csv(ROSTER_OUT, roster_rows, fields)
    write_csv(PHASE5_ROSTER_TABLE, roster_rows, fields)
    write_csv(
        RESIDUAL_SUMMARY_OUT,
        residual_summary,
        ["residual_twelfths", "rows", "symbols", "A_candidate_range", "anchor_statuses"],
    )
    write_csv(
        ROSTER_SUMMARY_OUT,
        roster_summary,
        ["roster_stability_lane", "rows", "symbols", "A_candidate_range", "anchor_statuses"],
    )
    write_csv(ANCHOR_OUT, anchor_rows, fields)
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, residual_summary, roster_summary)
    update_campaign(summary)

    print(summary["result_class"])
    print(f"roster_rows_emitted={summary['roster_rows_emitted']}")
    print(f"anchor_candidate_rows={summary['anchor_candidate_rows']}")
    print(f"branch_candidate_rows={summary['branch_candidate_rows']}")
    print(f"roster_lane_count={summary['roster_lane_count']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
