from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
CAMPAIGNS = ROOT / "docs" / "campaigns"
PHASE4 = ROOT / "phase4_tables"

QP053_SUMMARY = ARTIFACTS / "qp053" / "qp053_summary.json"
QP053_ROSTER_TABLE = ARTIFACTS / "qp053" / "qp053_isotope_roster_stability_lane_table.csv"
QP052_MASS_TABLE = ARTIFACTS / "qp052" / "qp052_numeric_deltaN_binding_mass_table.csv"

QP054_DIR = ARTIFACTS / "qp054"
PREFLIGHT_OUT = QP054_DIR / "qp054_preflight.md"
SUMMARY_OUT = QP054_DIR / "qp054_summary.json"
LADDER_OUT = QP054_DIR / "qp054_isotope_neighbor_ladder_table.csv"
SUMMARY_BY_ROLE_OUT = QP054_DIR / "qp054_ladder_role_summary_table.csv"
SUMMARY_BY_ROSTER_OUT = QP054_DIR / "qp054_roster_ladder_summary_table.csv"
DECISION_OUT = QP054_DIR / "qp054_decision_table.csv"
NEXT_OUT = QP054_DIR / "qp054_next_frontier.csv"
SCHEMA_OUT = QP054_DIR / "qp054_schema.csv"
DOC_OUT = REPORTS / "QP054_PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR.md"
CAMPAIGN = CAMPAIGNS / "SAM_QP049_QP0XX_PHASE5_ISOTOPE_MASS_READOUT_CAMPAIGN.md"

PHASE5_LADDER_TABLE = PHASE4 / "phase5_isotope_neighbor_ladder_v1.csv"
PHASE5_SUMMARY = PHASE4 / "phase5_summary_v6.json"

R = 12


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP054_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP054 Preflight - Isotope Neighbor Ladder Selector

```text
test_id = QP054
test_name = PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp053/qp053_summary.json
artifacts/qp053/qp053_isotope_roster_stability_lane_table.csv
artifacts/qp052/qp052_numeric_deltaN_binding_mass_table.csv
```

## Expected Outputs

```text
artifacts/qp054/qp054_summary.json
artifacts/qp054/qp054_isotope_neighbor_ladder_table.csv
artifacts/qp054/qp054_ladder_role_summary_table.csv
docs/reports/QP054_PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR.md
phase4_tables/phase5_isotope_neighbor_ladder_v1.csv
```

## Forward Question

```text
Can SAM use the residual-twelfths roster lane to generate neighboring isotope
ladder candidates around the QP052 primary candidate?
```

This is a new forward ladder generator. It does not rerun or audit QP053.
""",
        encoding="utf-8",
    )


def index_by_z(rows: list[dict[str, str]]) -> dict[int, dict[str, str]]:
    return {int(row["atomic_number"]): row for row in rows}


def preference(units: int, role: str) -> str:
    if units == 0:
        return "PRIMARY_EXACT"
    if units == 6:
        return "BALANCED_HALF_WRITE"
    if units < 6:
        return "PRIMARY_PREFERRED" if role == "FLOOR_PRIMARY" else "UPPER_BRANCH"
    return "CEIL_PREFERRED" if role == "CEIL_NEIGHBOR" else "LOWER_BRANCH"


def build_ladder_rows(roster_rows: list[dict[str, str]], mass_by_z: dict[int, dict[str, str]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for roster in roster_rows:
        z = int(roster["atomic_number"])
        mass = mass_by_z[z]
        units = int(roster["residual_twelfths"])
        floor_weight = (R - units) / R if units else 1.0
        ceil_weight = units / R
        neutron_mass = float(mass["M_neutron_MeV"])
        operator_gap = float(mass["binding_operator_gap"])
        bound_neutron_increment = neutron_mass * (1.0 - operator_gap)

        base_row = {
            "atomic_number": z,
            "symbol": roster["symbol"],
            "name": roster["name"],
            "roster_stability_lane": roster["roster_stability_lane"],
            "anchor_status": roster["anchor_status"],
            "residual_twelfths": units,
            "residual_fraction_native": roster["residual_fraction_native"],
            "selected_depth_index": roster["selected_depth_index"],
            "selected_neutron_excess_lane": roster["selected_neutron_excess_lane"],
            "formation_lane": roster["formation_lane"],
            "A_band": roster["A_band"],
        }
        rows.append(
            {
                **base_row,
                "ladder_role": "FLOOR_PRIMARY",
                "ladder_preference": preference(units, "FLOOR_PRIMARY"),
                "ladder_weight": f"{floor_weight:.12e}",
                "Z_candidate": roster["Z_candidate"],
                "N_candidate": roster["N_candidate"],
                "A_candidate": roster["A_candidate"],
                "sam_isotope_mass_candidate_MeV": roster["sam_isotope_mass_candidate_MeV"],
                "mass_ladder_note": "QP052 floor packet candidate",
                "selector_status": "FILLED_NATIVE_ISOTOPE_LADDER_ROW",
            }
        )
        if units != 0:
            rows.append(
                {
                    **base_row,
                    "ladder_role": "CEIL_NEIGHBOR",
                    "ladder_preference": preference(units, "CEIL_NEIGHBOR"),
                    "ladder_weight": f"{ceil_weight:.12e}",
                    "Z_candidate": roster["Z_candidate"],
                    "N_candidate": int(roster["N_candidate"]) + 1,
                    "A_candidate": int(roster["A_candidate"]) + 1,
                    "sam_isotope_mass_candidate_MeV": f"{float(roster['sam_isotope_mass_candidate_MeV']) + bound_neutron_increment:.12e}",
                    "mass_ladder_note": "ceil neighbor adds one bound neutron increment from QP052 operator gap",
                    "selector_status": "FILLED_NATIVE_ISOTOPE_LADDER_ROW",
                }
            )
    return rows


def summarize(rows: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[str(row[key])].append(row)
    out: list[dict[str, Any]] = []
    for value, members in grouped.items():
        out.append(
            {
                key: value,
                "rows": len(members),
                "A_candidate_range": f"{min(int(row['A_candidate']) for row in members)}..{max(int(row['A_candidate']) for row in members)}",
                "symbols": ";".join(str(row["symbol"]) for row in members),
                "preferences": ";".join(sorted({str(row["ladder_preference"]) for row in members})),
            }
        )
    return sorted(out, key=lambda row: row[key])


def write_doc(summary: dict[str, Any], role_summary: list[dict[str, Any]], roster_summary: list[dict[str, Any]]) -> None:
    role_lines = "\n".join(
        f"| {row['ladder_role']} | {row['rows']} | {row['A_candidate_range']} | {row['preferences']} |"
        for row in role_summary
    )
    roster_lines = "\n".join(
        f"| {row['roster_stability_lane']} | {row['rows']} | {row['A_candidate_range']} | {row['preferences']} |"
        for row in roster_summary
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP054 - Private Isotope Neighbor Ladder Selector

## Preflight

```text
test_id = QP054
test_name = PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP054 generates a native isotope neighbor ladder from the QP053 residual:

```text
floor row weight = (12 - residual_twelfths) / 12
ceil row weight  = residual_twelfths / 12
```

Exact residual rows keep one floor candidate. Nonzero residual rows add one
ceil-neighbor candidate with one bound-neutron increment.

## Role Summary

| ladder role | rows | A candidate range | preferences |
| --- | ---: | --- | --- |
{role_lines}

## Roster Summary

| roster lane | rows | A candidate range | preferences |
| --- | ---: | --- | --- |
{roster_lines}

## Key Counts

```text
ladder_rows_emitted = {summary['ladder_rows_emitted']}
floor_primary_rows = {summary['floor_primary_rows']}
ceil_neighbor_rows = {summary['ceil_neighbor_rows']}
balanced_half_write_pairs = {summary['balanced_half_write_pairs']}
observed_isotope_masses_used = {str(summary['observed_isotope_masses_used']).lower()}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

QP054 turns the single QP052 isotope surface into a native isotope ladder. The
residual twelfths now decide whether the floor candidate stands alone, the
floor candidate dominates, the upper neighbor dominates, or both share the
half-write balance.
""",
        encoding="utf-8",
    )


def update_campaign(summary: dict[str, Any]) -> None:
    text = CAMPAIGN.read_text(encoding="utf-8")
    text = text.replace(
        "ACTIVE_PHASE5_ISOTOPE_MASS_READOUT_QP053_COMPLETE_QP054_NEXT",
        "ACTIVE_PHASE5_ISOTOPE_MASS_READOUT_QP054_COMPLETE_QP055_NEXT",
    )
    marker = "### QP054 - Isotope Neighbor Ladder Selector\n"
    result_block = f"""### QP054 - Isotope Neighbor Ladder Selector

Status:

```text
COMPLETE
result_class = {summary['result_class']}
ladder_rows_emitted = {summary['ladder_rows_emitted']}
floor_primary_rows = {summary['floor_primary_rows']}
ceil_neighbor_rows = {summary['ceil_neighbor_rows']}
balanced_half_write_pairs = {summary['balanced_half_write_pairs']}
observed_isotope_masses_used = false
free_parameters_introduced = 0
next_frontier = {summary['next_frontier']}
```

Question:

```text
Can SAM use the residual-twelfths roster lane to generate neighboring isotope
ladder candidates around the QP052 primary candidate?
```

Result:

```text
PASS. QP054 emits a native isotope neighbor ladder with floor-primary and
ceil-neighbor rows selected by residual twelfths.
```

Output:

```text
artifacts/qp054/qp054_summary.json
artifacts/qp054/qp054_isotope_neighbor_ladder_table.csv
docs/reports/QP054_PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR.md
phase4_tables/phase5_isotope_neighbor_ladder_v1.csv
```

### QP055 - Phase 5 Isotope Freeze

Question:

```text
Can SAM freeze the Phase 5 isotope package into seed, DeltaN, roster, and
neighbor-ladder tables with a clear open frontier?
```

Expected output:

```text
Phase 5 isotope table package and next-frontier summary
```
"""
    if marker in text:
        before, after = text.split(marker, 1)
        if "## First Move" in after:
            _, tail = after.split("## First Move", 1)
            text = before + result_block + "\n## First Move" + tail
        else:
            text = before + result_block
    text = text.replace(
        "next_test = QP054_PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR",
        "next_test = QP055_PRIVATE_PHASE5_ISOTOPE_FREEZE",
    )
    CAMPAIGN.write_text(text, encoding="utf-8")


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp053 = read_json(QP053_SUMMARY)
    roster_rows = read_csv(QP053_ROSTER_TABLE)
    mass_by_z = index_by_z(read_csv(QP052_MASS_TABLE))
    ladder_rows = build_ladder_rows(roster_rows, mass_by_z)
    role_summary = summarize(ladder_rows, "ladder_role")
    roster_summary = summarize(ladder_rows, "roster_stability_lane")
    role_counts = Counter(row["ladder_role"] for row in ladder_rows)
    preference_counts = Counter(row["ladder_preference"] for row in ladder_rows)

    summary = {
        "artifact": "QP054_PRIVATE_ISOTOPE_NEIGHBOR_LADDER_SELECTOR",
        "result_class": "QP054_ISOTOPE_NEIGHBOR_LADDER_SELECTED",
        "campaign_status": "QP054_ISOTOPE_NEIGHBOR_LADDER_SELECTED_QP055_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_isotope_masses_used": False,
        "observed_abundance_used_as_selector": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp053/qp053_summary.json",
            "artifacts/qp053/qp053_isotope_roster_stability_lane_table.csv",
            "artifacts/qp052/qp052_numeric_deltaN_binding_mass_table.csv",
        ],
        "qp053_result_class": qp053["result_class"],
        "ladder_law": "floor_weight=(12-residual_twelfths)/12; ceil_weight=residual_twelfths/12",
        "ladder_rows_emitted": len(ladder_rows),
        "floor_primary_rows": role_counts["FLOOR_PRIMARY"],
        "ceil_neighbor_rows": role_counts["CEIL_NEIGHBOR"],
        "balanced_half_write_pairs": preference_counts["BALANCED_HALF_WRITE"],
        "ladder_preference_counts": dict(preference_counts),
        "next_frontier": "QP055_PRIVATE_PHASE5_ISOTOPE_FREEZE",
        "interpretation": (
            "QP054 converts QP053 residual twelfths into a native isotope neighbor ladder with floor-primary and "
            "ceil-neighbor candidates."
        ),
    }

    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "new isotope neighbor ladder; not audit, not retest, no public write",
        },
        {
            "decision_point": "ladder_law",
            "decision": "SELECT_RESIDUAL_TWELFTHS_FLOOR_CEIL_LADDER",
            "note": "residual twelfths split floor and ceil neighbor weights",
        },
        {
            "decision_point": "phase5_freeze",
            "decision": "QP055_READY",
            "note": "seed, depth, numeric DeltaN, roster, and neighbor ladder tables are ready for freeze",
        },
    ]
    next_rows = [
        {
            "next_frontier": "QP055_PRIVATE_PHASE5_ISOTOPE_FREEZE",
            "why_next": "QP054 emits the isotope neighbor ladder; Phase 5 can now freeze the generated isotope package.",
            "launch_from": "qp054_isotope_neighbor_ladder_table.csv",
            "target_output": "Phase 5 isotope table package",
        }
    ]
    schema_rows = [
        {
            "field": "ladder_role",
            "meaning": "floor primary candidate or ceil neighbor candidate",
            "class": "ladder_selector",
        },
        {
            "field": "ladder_weight",
            "meaning": "native residual-twelfths weight for the ladder row",
            "class": "ladder_coordinate",
        },
        {
            "field": "ladder_preference",
            "meaning": "whether floor, ceil, exact, or half-write balance dominates",
            "class": "ladder_status",
        },
    ]

    fields = [
        "atomic_number",
        "symbol",
        "name",
        "roster_stability_lane",
        "anchor_status",
        "residual_twelfths",
        "residual_fraction_native",
        "selected_depth_index",
        "selected_neutron_excess_lane",
        "formation_lane",
        "A_band",
        "ladder_role",
        "ladder_preference",
        "ladder_weight",
        "Z_candidate",
        "N_candidate",
        "A_candidate",
        "sam_isotope_mass_candidate_MeV",
        "mass_ladder_note",
        "selector_status",
    ]
    write_json(SUMMARY_OUT, summary)
    write_json(PHASE5_SUMMARY, summary)
    write_csv(LADDER_OUT, ladder_rows, fields)
    write_csv(PHASE5_LADDER_TABLE, ladder_rows, fields)
    write_csv(SUMMARY_BY_ROLE_OUT, role_summary, ["ladder_role", "rows", "A_candidate_range", "symbols", "preferences"])
    write_csv(
        SUMMARY_BY_ROSTER_OUT,
        roster_summary,
        ["roster_stability_lane", "rows", "A_candidate_range", "symbols", "preferences"],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, role_summary, roster_summary)
    update_campaign(summary)

    print(summary["result_class"])
    print(f"ladder_rows_emitted={summary['ladder_rows_emitted']}")
    print(f"floor_primary_rows={summary['floor_primary_rows']}")
    print(f"ceil_neighbor_rows={summary['ceil_neighbor_rows']}")
    print(f"balanced_half_write_pairs={summary['balanced_half_write_pairs']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
