from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
CAMPAIGNS = ROOT / "docs" / "campaigns"
PHASE4 = ROOT / "phase4_tables"

QP055_DIR = ARTIFACTS / "qp055"
PREFLIGHT_OUT = QP055_DIR / "qp055_preflight.md"
SUMMARY_OUT = QP055_DIR / "qp055_summary.json"
TABLE_INDEX_OUT = QP055_DIR / "qp055_phase5_table_index.csv"
FREEZE_SUMMARY_OUT = QP055_DIR / "qp055_phase5_freeze_summary_table.csv"
NEXT_OUT = QP055_DIR / "qp055_next_frontier.csv"
DOC_OUT = REPORTS / "QP055_PRIVATE_PHASE5_ISOTOPE_FREEZE.md"
CAMPAIGN = CAMPAIGNS / "SAM_QP049_QP0XX_PHASE5_ISOTOPE_MASS_READOUT_CAMPAIGN.md"

PHASE5_FREEZE_JSON = PHASE4 / "phase5_freeze_summary.json"
PHASE5_FREEZE_CSV = PHASE4 / "phase5_freeze_summary.csv"

TABLES = [
    ("isotope_seed_identity", "phase4_tables/phase5_isotope_seed_identity_v1.csv", "QP049", "seed identity for all 118 elements"),
    ("symmetric_seed_mass", "phase4_tables/phase5_symmetric_isotope_seed_mass_v1.csv", "QP050", "N=Z seed mass surface"),
    ("neutron_excess_lanes", "phase4_tables/phase5_neutron_excess_binding_depth_lanes_v1.csv", "QP051", "neutron-excess/binding-depth lane ownership"),
    ("numeric_deltaN_mass", "phase4_tables/phase5_numeric_deltaN_binding_mass_v1.csv", "QP052", "numeric DeltaN and isotope mass candidate surface"),
    ("roster_stability_lanes", "phase4_tables/phase5_isotope_roster_stability_lanes_v1.csv", "QP053", "residual-twelfths roster/stability lanes"),
    ("neighbor_ladder", "phase4_tables/phase5_isotope_neighbor_ladder_v1.csv", "QP054", "floor/ceil isotope neighbor ladder"),
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP055_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP055 Preflight - Phase 5 Isotope Freeze

```text
test_id = QP055
test_name = PRIVATE_PHASE5_ISOTOPE_FREEZE
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
phase4_tables/phase5_isotope_seed_identity_v1.csv
phase4_tables/phase5_symmetric_isotope_seed_mass_v1.csv
phase4_tables/phase5_neutron_excess_binding_depth_lanes_v1.csv
phase4_tables/phase5_numeric_deltaN_binding_mass_v1.csv
phase4_tables/phase5_isotope_roster_stability_lanes_v1.csv
phase4_tables/phase5_isotope_neighbor_ladder_v1.csv
```

## Expected Outputs

```text
artifacts/qp055/qp055_summary.json
artifacts/qp055/qp055_phase5_table_index.csv
artifacts/qp055/qp055_phase5_freeze_summary_table.csv
docs/reports/QP055_PRIVATE_PHASE5_ISOTOPE_FREEZE.md
phase4_tables/phase5_freeze_summary.json
phase4_tables/phase5_freeze_summary.csv
```

## Forward Question

```text
Can SAM freeze Phase 5 into a coherent isotope package with seed, DeltaN,
roster, and neighbor-ladder tables?
```

This is a new forward packaging gate. It does not rerun or audit QP049-QP054.
""",
        encoding="utf-8",
    )


def table_index() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for table_id, rel_path, source_gate, description in TABLES:
        path = ROOT / rel_path
        table_rows = read_csv(path)
        rows.append(
            {
                "table_id": table_id,
                "path": rel_path,
                "source_gate": source_gate,
                "rows": len(table_rows),
                "columns": len(table_rows[0]) if table_rows else 0,
                "description": description,
            }
        )
    return rows


def write_doc(summary: dict[str, Any], index_rows: list[dict[str, Any]]) -> None:
    index_lines = "\n".join(
        f"| {row['table_id']} | {row['source_gate']} | {row['rows']} | {row['path']} |"
        for row in index_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP055 - Private Phase 5 Isotope Freeze

## Preflight

```text
test_id = QP055
test_name = PRIVATE_PHASE5_ISOTOPE_FREEZE
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

Phase 5 is now frozen as a private isotope package.

## Table Index

| table | source gate | rows | path |
| --- | --- | ---: | --- |
{index_lines}

## Key Counts

```text
phase5_tables = {summary['phase5_tables']}
seed_identity_rows = {summary['seed_identity_rows']}
numeric_deltaN_mass_rows = {summary['numeric_deltaN_mass_rows']}
neighbor_ladder_rows = {summary['neighbor_ladder_rows']}
observed_isotope_masses_used = {str(summary['observed_isotope_masses_used']).lower()}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

QP055 freezes the first SAM-native isotope package. Phase 5 now carries a
closed path from element seed identity to symmetric seed mass, neutron-excess
depth, numeric DeltaN, primary mass candidate, residual roster lane, and
neighbor isotope ladder.
""",
        encoding="utf-8",
    )


def update_campaign(summary: dict[str, Any]) -> None:
    text = CAMPAIGN.read_text(encoding="utf-8")
    text = text.replace(
        "ACTIVE_PHASE5_ISOTOPE_MASS_READOUT_QP054_COMPLETE_QP055_NEXT",
        "COMPLETE_PHASE5_ISOTOPE_PACKAGE_QP055_FROZEN",
    )
    marker = "### QP055 - Phase 5 Isotope Freeze\n"
    result_block = f"""### QP055 - Phase 5 Isotope Freeze

Status:

```text
COMPLETE
result_class = {summary['result_class']}
phase5_tables = {summary['phase5_tables']}
seed_identity_rows = {summary['seed_identity_rows']}
numeric_deltaN_mass_rows = {summary['numeric_deltaN_mass_rows']}
neighbor_ladder_rows = {summary['neighbor_ladder_rows']}
observed_isotope_masses_used = false
free_parameters_introduced = 0
next_frontier = {summary['next_frontier']}
```

Question:

```text
Can SAM freeze the Phase 5 isotope package into seed, DeltaN, roster, and
neighbor-ladder tables with a clear open frontier?
```

Result:

```text
PASS. QP055 freezes the Phase 5 isotope package from QP049-QP054.
```

Output:

```text
artifacts/qp055/qp055_summary.json
artifacts/qp055/qp055_phase5_table_index.csv
docs/reports/QP055_PRIVATE_PHASE5_ISOTOPE_FREEZE.md
phase4_tables/phase5_freeze_summary.json
phase4_tables/phase5_freeze_summary.csv
```
"""
    if marker in text:
        before, after = text.split(marker, 1)
        if "## First Move" in after:
            _, tail = after.split("## First Move", 1)
            text = before + result_block + "\n## First Move" + tail
        else:
            text = before + result_block
    text = text.replace(
        "next_test = QP055_PRIVATE_PHASE5_ISOTOPE_FREEZE",
        "next_test = QP056_PRIVATE_PHASE5_ISOTOPE_VISUAL_PACKAGE_OR_SEALED_COMPARISON",
    )
    CAMPAIGN.write_text(text, encoding="utf-8")


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    index_rows = table_index()
    index_by_id = {row["table_id"]: row for row in index_rows}
    q054 = read_json(ARTIFACTS / "qp054" / "qp054_summary.json")
    summary = {
        "artifact": "QP055_PRIVATE_PHASE5_ISOTOPE_FREEZE",
        "result_class": "QP055_PHASE5_ISOTOPE_PACKAGE_FROZEN",
        "campaign_status": "COMPLETE_PHASE5_ISOTOPE_PACKAGE_QP055_FROZEN",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_isotope_masses_used": False,
        "observed_abundance_used_as_selector": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [row["path"] for row in index_rows],
        "qp054_result_class": q054["result_class"],
        "phase5_tables": len(index_rows),
        "seed_identity_rows": index_by_id["isotope_seed_identity"]["rows"],
        "symmetric_seed_mass_rows": index_by_id["symmetric_seed_mass"]["rows"],
        "neutron_excess_lane_rows": index_by_id["neutron_excess_lanes"]["rows"],
        "numeric_deltaN_mass_rows": index_by_id["numeric_deltaN_mass"]["rows"],
        "roster_stability_rows": index_by_id["roster_stability_lanes"]["rows"],
        "neighbor_ladder_rows": index_by_id["neighbor_ladder"]["rows"],
        "next_frontier": "QP056_PRIVATE_PHASE5_ISOTOPE_VISUAL_PACKAGE_OR_SEALED_COMPARISON",
        "interpretation": (
            "QP055 freezes the private Phase 5 isotope package from seed identity through neighbor-ladder generation."
        ),
    }
    freeze_rows = [
        {"metric": key, "value": value}
        for key, value in summary.items()
        if key
        in {
            "result_class",
            "phase5_tables",
            "seed_identity_rows",
            "symmetric_seed_mass_rows",
            "neutron_excess_lane_rows",
            "numeric_deltaN_mass_rows",
            "roster_stability_rows",
            "neighbor_ladder_rows",
            "next_frontier",
        }
    ]
    next_rows = [
        {
            "next_frontier": summary["next_frontier"],
            "why_next": "Phase 5 is frozen; next step is either a private visual package or a separately approved sealed comparison.",
            "launch_from": "qp055_phase5_table_index.csv",
            "target_output": "visual table package or sealed comparison protocol",
        }
    ]
    write_json(SUMMARY_OUT, summary)
    write_json(PHASE5_FREEZE_JSON, summary)
    write_csv(TABLE_INDEX_OUT, index_rows, ["table_id", "path", "source_gate", "rows", "columns", "description"])
    write_csv(FREEZE_SUMMARY_OUT, freeze_rows, ["metric", "value"])
    write_csv(PHASE5_FREEZE_CSV, freeze_rows, ["metric", "value"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_doc(summary, index_rows)
    update_campaign(summary)

    print(summary["result_class"])
    print(f"phase5_tables={summary['phase5_tables']}")
    print(f"seed_identity_rows={summary['seed_identity_rows']}")
    print(f"numeric_deltaN_mass_rows={summary['numeric_deltaN_mass_rows']}")
    print(f"neighbor_ladder_rows={summary['neighbor_ladder_rows']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
