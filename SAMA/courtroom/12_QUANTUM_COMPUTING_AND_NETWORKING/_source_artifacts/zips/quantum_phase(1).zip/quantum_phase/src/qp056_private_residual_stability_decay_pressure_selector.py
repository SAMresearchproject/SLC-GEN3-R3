from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
CAMPAIGNS = ROOT / "docs" / "campaigns"
PHASE4 = ROOT / "phase4_tables"

QP055_SUMMARY = ARTIFACTS / "qp055" / "qp055_summary.json"
QP054_LADDER_TABLE = ARTIFACTS / "qp054" / "qp054_isotope_neighbor_ladder_table.csv"

QP056_DIR = ARTIFACTS / "qp056"
PREFLIGHT_OUT = QP056_DIR / "qp056_preflight.md"
SUMMARY_OUT = QP056_DIR / "qp056_summary.json"
PRESSURE_OUT = QP056_DIR / "qp056_residual_stability_decay_pressure_table.csv"
PRESSURE_SUMMARY_OUT = QP056_DIR / "qp056_decay_pressure_summary_table.csv"
PREFERENCE_SUMMARY_OUT = QP056_DIR / "qp056_native_preference_summary_table.csv"
ELEMENT_SUMMARY_OUT = QP056_DIR / "qp056_element_primary_pressure_table.csv"
DECISION_OUT = QP056_DIR / "qp056_decision_table.csv"
NEXT_OUT = QP056_DIR / "qp056_next_frontier.csv"
SCHEMA_OUT = QP056_DIR / "qp056_schema.csv"
DOC_OUT = REPORTS / "QP056_PRIVATE_RESIDUAL_STABILITY_DECAY_PRESSURE_SELECTOR.md"
CAMPAIGN = CAMPAIGNS / "SAM_QP049_QP0XX_PHASE5_ISOTOPE_MASS_READOUT_CAMPAIGN.md"

PHASE5_PRESSURE_TABLE = PHASE4 / "phase5_residual_stability_decay_pressure_v1.csv"
PHASE5_SUMMARY = PHASE4 / "phase5_summary_v7.json"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP056_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP056 Preflight - Residual Stability Decay Pressure Selector

```text
test_id = QP056
test_name = PRIVATE_RESIDUAL_STABILITY_DECAY_PRESSURE_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
observed_half_lives_used = false
observed_abundance_used_as_selector = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp055/qp055_summary.json
artifacts/qp054/qp054_isotope_neighbor_ladder_table.csv
```

## Expected Outputs

```text
artifacts/qp056/qp056_summary.json
artifacts/qp056/qp056_residual_stability_decay_pressure_table.csv
artifacts/qp056/qp056_decay_pressure_summary_table.csv
artifacts/qp056/qp056_native_preference_summary_table.csv
docs/reports/QP056_PRIVATE_RESIDUAL_STABILITY_DECAY_PRESSURE_SELECTOR.md
phase4_tables/phase5_residual_stability_decay_pressure_v1.csv
```

## Forward Question

```text
Can SAM classify stability/decay pressure from the QP054 residual-twelfths
neighbor ladder without observed isotope masses, half-lives, or abundances?
```

This is a new forward pressure selector. It does not rerun or audit QP054/QP055.
""",
        encoding="utf-8",
    )


def residual_pressure(units: int, roster_lane: str) -> str:
    if "SYNTHETIC" in roster_lane:
        return "SYNTHETIC_HIGH_DECAY_PRESSURE"
    if "ACTINIDE" in roster_lane:
        return "ACTINIDE_ALPHA_CHAIN_PRESSURE"
    if "DENSE_CONTEXT" in roster_lane:
        return "DENSE_CONTEXT_LONG_ANCHOR_PRESSURE"
    if units == 0:
        return "EXACT_CLOSURE_STABILITY_PRESSURE"
    if units == 6:
        return "HALF_WRITE_BALANCE_PRESSURE"
    if units in {4, 8}:
        return "TRIADIC_BRANCH_DECAY_PRESSURE"
    if units in {3, 9}:
        return "QUARTER_BRANCH_REBALANCE_PRESSURE"
    if units in {2, 10}:
        return "SIXTH_BRANCH_REBALANCE_PRESSURE"
    return "OFF_AXIS_HIGH_REBALANCE_PRESSURE"


def native_preference(row: dict[str, str], pressure: str) -> str:
    pref = row["ladder_preference"]
    if "SYNTHETIC_HIGH" in pressure:
        return "TRANSIENT_ROUTE_CANDIDATE"
    if pref == "PRIMARY_EXACT":
        return "NATIVE_STABILITY_ANCHOR"
    if pref == "BALANCED_HALF_WRITE":
        return "NATIVE_HALF_WRITE_COANCHOR"
    if pref in {"PRIMARY_PREFERRED", "CEIL_PREFERRED"}:
        return "NATIVE_PREFERRED_BRANCH"
    return "NATIVE_SECONDARY_BRANCH"


def build_pressure_rows(ladder_rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in ladder_rows:
        units = int(row["residual_twelfths"])
        pressure = residual_pressure(units, row["roster_stability_lane"])
        preference = native_preference(row, pressure)
        rows.append(
            {
                "atomic_number": row["atomic_number"],
                "symbol": row["symbol"],
                "name": row["name"],
                "Z_candidate": row["Z_candidate"],
                "N_candidate": row["N_candidate"],
                "A_candidate": row["A_candidate"],
                "ladder_role": row["ladder_role"],
                "ladder_preference": row["ladder_preference"],
                "ladder_weight": row["ladder_weight"],
                "residual_twelfths": units,
                "residual_fraction_native": row["residual_fraction_native"],
                "roster_stability_lane": row["roster_stability_lane"],
                "anchor_status": row["anchor_status"],
                "selected_neutron_excess_lane": row["selected_neutron_excess_lane"],
                "formation_lane": row["formation_lane"],
                "A_band": row["A_band"],
                "decay_pressure_lane": pressure,
                "native_stability_preference": preference,
                "pressure_selector_status": "FILLED_NATIVE_RESIDUAL_STABILITY_DECAY_PRESSURE",
                "next_selector_needed": "QP057_PRIVATE_DECAY_DIRECTION_AND_CHAIN_SELECTOR",
            }
        )
    return rows


def summarize(rows: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[str(row[key])].append(row)
    out: list[dict[str, Any]] = []
    for value, members in grouped.items():
        out.append(
            {
                key: value,
                "rows": len(members),
                "A_candidate_range": f"{min(int(row['A_candidate']) for row in members)}..{max(int(row['A_candidate']) for row in members)}",
                "symbols": ";".join(str(row["symbol"]) for row in members),
                "preferences": ";".join(sorted({str(row["native_stability_preference"]) for row in members})),
            }
        )
    return sorted(out, key=lambda row: row[key])


def element_primary(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    preferred_order = {
        "NATIVE_STABILITY_ANCHOR": 0,
        "NATIVE_HALF_WRITE_COANCHOR": 1,
        "NATIVE_PREFERRED_BRANCH": 2,
        "NATIVE_SECONDARY_BRANCH": 3,
        "TRANSIENT_ROUTE_CANDIDATE": 4,
    }
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[str(row["atomic_number"])].append(row)
    out: list[dict[str, Any]] = []
    for z, members in grouped.items():
        chosen = sorted(
            members,
            key=lambda row: (
                preferred_order.get(str(row["native_stability_preference"]), 9),
                -float(row["ladder_weight"]),
                int(row["A_candidate"]),
            ),
        )[0]
        out.append(
            {
                "atomic_number": z,
                "symbol": chosen["symbol"],
                "primary_A_candidate": chosen["A_candidate"],
                "primary_N_candidate": chosen["N_candidate"],
                "primary_pressure_lane": chosen["decay_pressure_lane"],
                "primary_native_preference": chosen["native_stability_preference"],
                "available_ladder_rows": len(members),
                "all_A_candidates": ";".join(str(row["A_candidate"]) for row in members),
            }
        )
    return sorted(out, key=lambda row: int(row["atomic_number"]))


def write_doc(summary: dict[str, Any], pressure_summary: list[dict[str, Any]], preference_summary: list[dict[str, Any]]) -> None:
    pressure_lines = "\n".join(
        f"| {row['decay_pressure_lane']} | {row['rows']} | {row['A_candidate_range']} | {row['preferences']} |"
        for row in pressure_summary
    )
    preference_lines = "\n".join(
        f"| {row['native_stability_preference']} | {row['rows']} | {row['A_candidate_range']} |"
        for row in preference_summary
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP056 - Private Residual Stability Decay Pressure Selector

## Preflight

```text
test_id = QP056
test_name = PRIVATE_RESIDUAL_STABILITY_DECAY_PRESSURE_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
observed_half_lives_used = false
observed_abundance_used_as_selector = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP056 classifies native stability/decay pressure from residual twelfths,
ladder preference, and formation routing.

## Decay Pressure Summary

| pressure lane | rows | A candidate range | preferences |
| --- | ---: | --- | --- |
{pressure_lines}

## Native Preference Summary

| native preference | rows | A candidate range |
| --- | ---: | --- |
{preference_lines}

## Key Counts

```text
pressure_rows_emitted = {summary['pressure_rows_emitted']}
element_primary_rows = {summary['element_primary_rows']}
decay_pressure_lane_count = {summary['decay_pressure_lane_count']}
native_preference_count = {summary['native_preference_count']}
observed_isotope_masses_used = {str(summary['observed_isotope_masses_used']).lower()}
observed_half_lives_used = {str(summary['observed_half_lives_used']).lower()}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

QP056 says the leftover twelfths are not only isotope-neighbor structure. They
also carry native pressure: exact closure, half-write balance, triadic branch,
quarter/sixth rebalance, off-axis rebalance, dense-context anchor, actinide
chain pressure, and synthetic transient pressure.
""",
        encoding="utf-8",
    )


def update_campaign(summary: dict[str, Any]) -> None:
    text = CAMPAIGN.read_text(encoding="utf-8")
    text = text.replace(
        "COMPLETE_PHASE5_ISOTOPE_PACKAGE_QP055_FROZEN",
        "ACTIVE_PHASE5_ISOTOPE_PRESSURE_EXTENSION_QP056_COMPLETE_QP057_NEXT",
    )
    marker = "### QP056 - Residual Stability Decay Pressure Selector\n"
    result_block = f"""### QP056 - Residual Stability Decay Pressure Selector

Status:

```text
COMPLETE
result_class = {summary['result_class']}
pressure_rows_emitted = {summary['pressure_rows_emitted']}
element_primary_rows = {summary['element_primary_rows']}
decay_pressure_lane_count = {summary['decay_pressure_lane_count']}
native_preference_count = {summary['native_preference_count']}
observed_isotope_masses_used = false
observed_half_lives_used = false
free_parameters_introduced = 0
next_frontier = {summary['next_frontier']}
```

Question:

```text
Can SAM classify stability/decay pressure from residual twelfths without
observed isotope masses, half-lives, or abundances?
```

Result:

```text
PASS. QP056 emits native residual stability/decay pressure lanes for all 200
QP054 isotope ladder rows.
```

Output:

```text
artifacts/qp056/qp056_summary.json
artifacts/qp056/qp056_residual_stability_decay_pressure_table.csv
docs/reports/QP056_PRIVATE_RESIDUAL_STABILITY_DECAY_PRESSURE_SELECTOR.md
phase4_tables/phase5_residual_stability_decay_pressure_v1.csv
```

### QP057 - Decay Direction and Chain Selector

Question:

```text
Can SAM select native decay/rebalance direction from the QP056 pressure lanes?
```

Expected output:

```text
native decay/rebalance direction table, or exact named boundary
```
"""
    if "### QP056 - Residual Stability Decay Pressure Selector" not in text:
        text += "\n\n" + result_block
    else:
        before, after = text.split(marker, 1)
        text = before + result_block
    text = text.replace(
        "next_test = QP056_PRIVATE_PHASE5_ISOTOPE_VISUAL_PACKAGE_OR_SEALED_COMPARISON",
        "next_test = QP057_PRIVATE_DECAY_DIRECTION_AND_CHAIN_SELECTOR",
    )
    CAMPAIGN.write_text(text, encoding="utf-8")


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp055 = read_json(QP055_SUMMARY)
    ladder_rows = read_csv(QP054_LADDER_TABLE)
    pressure_rows = build_pressure_rows(ladder_rows)
    pressure_summary = summarize(pressure_rows, "decay_pressure_lane")
    preference_summary = summarize(pressure_rows, "native_stability_preference")
    element_rows = element_primary(pressure_rows)
    pressure_counts = Counter(row["decay_pressure_lane"] for row in pressure_rows)
    preference_counts = Counter(row["native_stability_preference"] for row in pressure_rows)

    summary = {
        "artifact": "QP056_PRIVATE_RESIDUAL_STABILITY_DECAY_PRESSURE_SELECTOR",
        "result_class": "QP056_RESIDUAL_STABILITY_DECAY_PRESSURE_SELECTED",
        "campaign_status": "QP056_RESIDUAL_STABILITY_DECAY_PRESSURE_SELECTED_QP057_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_isotope_masses_used": False,
        "observed_half_lives_used": False,
        "observed_abundance_used_as_selector": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp055/qp055_summary.json",
            "artifacts/qp054/qp054_isotope_neighbor_ladder_table.csv",
        ],
        "qp055_result_class": qp055["result_class"],
        "pressure_rows_emitted": len(pressure_rows),
        "element_primary_rows": len(element_rows),
        "decay_pressure_lane_count": len(pressure_counts),
        "native_preference_count": len(preference_counts),
        "decay_pressure_lane_counts": dict(pressure_counts),
        "native_preference_counts": dict(preference_counts),
        "next_frontier": "QP057_PRIVATE_DECAY_DIRECTION_AND_CHAIN_SELECTOR",
        "interpretation": (
            "QP056 maps residual twelfths and ladder preference into native stability/decay pressure lanes without observed isotope data."
        ),
    }
    decision_rows = [
        {
            "decision_point": "preflight",
            "decision": "PASS_FORWARD_MODEL_BUILD",
            "note": "new pressure selector; not audit, not retest, no public write",
        },
        {
            "decision_point": "pressure_lane",
            "decision": "SELECT_RESIDUAL_TWELFTHS_PRESSURE_CLASSES",
            "note": "residual twelfths and formation routing classify decay/stability pressure",
        },
        {
            "decision_point": "next",
            "decision": "QP057_READY",
            "note": "pressure lanes can now select decay/rebalance direction",
        },
    ]
    next_rows = [
        {
            "next_frontier": "QP057_PRIVATE_DECAY_DIRECTION_AND_CHAIN_SELECTOR",
            "why_next": "QP056 selects pressure; next step is direction of rebalance or decay chain.",
            "launch_from": "qp056_residual_stability_decay_pressure_table.csv",
            "target_output": "native decay/rebalance direction table",
        }
    ]
    schema_rows = [
        {"field": "decay_pressure_lane", "meaning": "native pressure class from residual twelfths and routing", "class": "pressure_selector"},
        {"field": "native_stability_preference", "meaning": "native anchor/branch/transient preference", "class": "preference_selector"},
        {"field": "primary_A_candidate", "meaning": "one native primary row per element selected from pressure preference", "class": "element_summary"},
    ]
    fields = [
        "atomic_number",
        "symbol",
        "name",
        "Z_candidate",
        "N_candidate",
        "A_candidate",
        "ladder_role",
        "ladder_preference",
        "ladder_weight",
        "residual_twelfths",
        "residual_fraction_native",
        "roster_stability_lane",
        "anchor_status",
        "selected_neutron_excess_lane",
        "formation_lane",
        "A_band",
        "decay_pressure_lane",
        "native_stability_preference",
        "pressure_selector_status",
        "next_selector_needed",
    ]
    write_json(SUMMARY_OUT, summary)
    write_json(PHASE5_SUMMARY, summary)
    write_csv(PRESSURE_OUT, pressure_rows, fields)
    write_csv(PHASE5_PRESSURE_TABLE, pressure_rows, fields)
    write_csv(PRESSURE_SUMMARY_OUT, pressure_summary, ["decay_pressure_lane", "rows", "A_candidate_range", "symbols", "preferences"])
    write_csv(PREFERENCE_SUMMARY_OUT, preference_summary, ["native_stability_preference", "rows", "A_candidate_range", "symbols", "preferences"])
    write_csv(
        ELEMENT_SUMMARY_OUT,
        element_rows,
        ["atomic_number", "symbol", "primary_A_candidate", "primary_N_candidate", "primary_pressure_lane", "primary_native_preference", "available_ladder_rows", "all_A_candidates"],
    )
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, pressure_summary, preference_summary)
    update_campaign(summary)

    print(summary["result_class"])
    print(f"pressure_rows_emitted={summary['pressure_rows_emitted']}")
    print(f"element_primary_rows={summary['element_primary_rows']}")
    print(f"decay_pressure_lane_count={summary['decay_pressure_lane_count']}")
    print(f"native_preference_count={summary['native_preference_count']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
