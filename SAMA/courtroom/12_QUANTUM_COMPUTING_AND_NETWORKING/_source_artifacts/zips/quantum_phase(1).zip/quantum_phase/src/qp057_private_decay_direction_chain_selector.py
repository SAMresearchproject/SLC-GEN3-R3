from __future__ import annotations

import csv
import json
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
CAMPAIGNS = ROOT / "docs" / "campaigns"
PHASE4 = ROOT / "phase4_tables"

QP056_SUMMARY = ARTIFACTS / "qp056" / "qp056_summary.json"
QP056_PRESSURE_TABLE = ARTIFACTS / "qp056" / "qp056_residual_stability_decay_pressure_table.csv"

QP057_DIR = ARTIFACTS / "qp057"
PREFLIGHT_OUT = QP057_DIR / "qp057_preflight.md"
SUMMARY_OUT = QP057_DIR / "qp057_summary.json"
DIRECTION_OUT = QP057_DIR / "qp057_decay_direction_chain_table.csv"
DIRECTION_SUMMARY_OUT = QP057_DIR / "qp057_direction_summary_table.csv"
CHAIN_SUMMARY_OUT = QP057_DIR / "qp057_chain_step_summary_table.csv"
DECISION_OUT = QP057_DIR / "qp057_decision_table.csv"
NEXT_OUT = QP057_DIR / "qp057_next_frontier.csv"
SCHEMA_OUT = QP057_DIR / "qp057_schema.csv"
DOC_OUT = REPORTS / "QP057_PRIVATE_DECAY_DIRECTION_CHAIN_SELECTOR.md"
CAMPAIGN = CAMPAIGNS / "SAM_QP049_QP0XX_PHASE5_ISOTOPE_MASS_READOUT_CAMPAIGN.md"

PHASE5_DIRECTION_TABLE = PHASE4 / "phase5_decay_direction_chain_v1.csv"
PHASE5_SUMMARY = PHASE4 / "phase5_summary_v8.json"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP057_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP057 Preflight - Decay Direction and Chain Selector

```text
test_id = QP057
test_name = PRIVATE_DECAY_DIRECTION_AND_CHAIN_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_decay_modes_used = false
observed_half_lives_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp056/qp056_summary.json
artifacts/qp056/qp056_residual_stability_decay_pressure_table.csv
```

## Expected Outputs

```text
artifacts/qp057/qp057_summary.json
artifacts/qp057/qp057_decay_direction_chain_table.csv
artifacts/qp057/qp057_direction_summary_table.csv
docs/reports/QP057_PRIVATE_DECAY_DIRECTION_CHAIN_SELECTOR.md
phase4_tables/phase5_decay_direction_chain_v1.csv
```

## Forward Question

```text
Can SAM select native decay/rebalance direction from the QP056 pressure lanes?
```

This is a new forward direction selector. It does not rerun or audit QP056.
""",
        encoding="utf-8",
    )


def direction_for(row: dict[str, str]) -> tuple[str, str]:
    pressure = row["decay_pressure_lane"]
    pref = row["native_stability_preference"]
    ladder_pref = row["ladder_preference"]
    if pressure == "EXACT_CLOSURE_STABILITY_PRESSURE":
        return "NO_REBALANCE_STABLE_ANCHOR", "SELF"
    if pressure == "DENSE_CONTEXT_LONG_ANCHOR_PRESSURE":
        return "DENSE_CONTEXT_LONG_ANCHOR_HOLD", "SELF_OR_HALF_WRITE_PAIR"
    if pressure == "HALF_WRITE_BALANCE_PRESSURE":
        return "HALF_WRITE_BIDIRECTIONAL_BALANCE", "PAIR"
    if pressure == "ACTINIDE_ALPHA_CHAIN_PRESSURE":
        return "ALPHA_CHAIN_DOWNSTEP", "ALPHA_MINUS_2Z_MINUS_4A"
    if pressure == "SYNTHETIC_HIGH_DECAY_PRESSURE":
        return "SYNTHETIC_DOWNCHAIN_CASCADE", "HEAVY_DOWNSTEP"
    if ladder_pref == "CEIL_PREFERRED":
        return "CEILWARD_NEUTRON_PACKET_COMPLETION", "PLUS_ONE_N"
    if ladder_pref == "PRIMARY_PREFERRED":
        return "FLOORWARD_NEUTRON_PACKET_REJECTION", "MINUS_RESIDUAL"
    if pref == "NATIVE_SECONDARY_BRANCH":
        return "RETURN_TO_PREFERRED_NEIGHBOR", "PAIR_RETURN"
    return "BRANCH_REBALANCE_OPEN", "BRANCH"


def build_direction_rows(pressure_rows: list[dict[str, str]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for row in pressure_rows:
        direction, chain_step = direction_for(row)
        z = int(row["Z_candidate"])
        n = int(row["N_candidate"])
        a = int(row["A_candidate"])
        if chain_step == "ALPHA_MINUS_2Z_MINUS_4A":
            target_z = max(0, z - 2)
            target_n = max(0, n - 2)
            target_a = max(0, a - 4)
        elif chain_step == "PLUS_ONE_N":
            target_z = z
            target_n = n + 1
            target_a = a + 1
        elif chain_step == "PAIR_RETURN":
            if row["ladder_role"] == "CEIL_NEIGHBOR":
                target_z = z
                target_n = max(0, n - 1)
                target_a = max(0, a - 1)
            else:
                target_z = z
                target_n = n + 1
                target_a = a + 1
        elif chain_step == "HEAVY_DOWNSTEP":
            target_z = max(0, z - 2)
            target_n = max(0, n - 2)
            target_a = max(0, a - 4)
        else:
            target_z = z
            target_n = n
            target_a = a
        rows.append(
            {
                "atomic_number": row["atomic_number"],
                "symbol": row["symbol"],
                "name": row["name"],
                "Z_candidate": z,
                "N_candidate": n,
                "A_candidate": a,
                "ladder_role": row["ladder_role"],
                "ladder_preference": row["ladder_preference"],
                "residual_twelfths": row["residual_twelfths"],
                "decay_pressure_lane": row["decay_pressure_lane"],
                "native_stability_preference": row["native_stability_preference"],
                "native_rebalance_direction": direction,
                "native_chain_step": chain_step,
                "target_Z_after_step": target_z,
                "target_N_after_step": target_n,
                "target_A_after_step": target_a,
                "direction_selector_status": "FILLED_NATIVE_DECAY_REBALANCE_DIRECTION",
                "next_selector_needed": "QP058_PRIVATE_PHASE5_PRESSURE_FREEZE_OR_COMPARISON_PROTOCOL",
            }
        )
    return rows


def summarize(rows: list[dict[str, Any]], key: str) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[str(row[key])].append(row)
    out: list[dict[str, Any]] = []
    for value, members in grouped.items():
        out.append(
            {
                key: value,
                "rows": len(members),
                "A_candidate_range": f"{min(int(row['A_candidate']) for row in members)}..{max(int(row['A_candidate']) for row in members)}",
                "symbols": ";".join(str(row["symbol"]) for row in members),
            }
        )
    return sorted(out, key=lambda row: row[key])


def write_doc(summary: dict[str, Any], direction_summary: list[dict[str, Any]], chain_summary: list[dict[str, Any]]) -> None:
    direction_lines = "\n".join(
        f"| {row['native_rebalance_direction']} | {row['rows']} | {row['A_candidate_range']} |"
        for row in direction_summary
    )
    chain_lines = "\n".join(
        f"| {row['native_chain_step']} | {row['rows']} | {row['A_candidate_range']} |"
        for row in chain_summary
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP057 - Private Decay Direction Chain Selector

## Preflight

```text
test_id = QP057
test_name = PRIVATE_DECAY_DIRECTION_AND_CHAIN_SELECTOR
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_decay_modes_used = false
observed_half_lives_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

QP057 selects native rebalance direction and first chain-step candidates from
QP056 pressure lanes.

## Direction Summary

| direction | rows | A candidate range |
| --- | ---: | --- |
{direction_lines}

## Chain Step Summary

| chain step | rows | A candidate range |
| --- | ---: | --- |
{chain_lines}

## Key Counts

```text
direction_rows_emitted = {summary['direction_rows_emitted']}
rebalance_direction_count = {summary['rebalance_direction_count']}
chain_step_count = {summary['chain_step_count']}
observed_decay_modes_used = {str(summary['observed_decay_modes_used']).lower()}
observed_half_lives_used = {str(summary['observed_half_lives_used']).lower()}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

QP057 turns pressure into direction. Exact closures hold, half-write lanes
balance, preferred branches point toward floor or ceil packet completion, and
actinide/synthetic high-pressure lanes point into down-chain steps.
""",
        encoding="utf-8",
    )


def update_campaign(summary: dict[str, Any]) -> None:
    text = CAMPAIGN.read_text(encoding="utf-8")
    text = text.replace(
        "ACTIVE_PHASE5_ISOTOPE_PRESSURE_EXTENSION_QP056_COMPLETE_QP057_NEXT",
        "ACTIVE_PHASE5_ISOTOPE_PRESSURE_EXTENSION_QP057_COMPLETE_QP058_NEXT",
    )
    marker = "### QP057 - Decay Direction and Chain Selector\n"
    result_block = f"""### QP057 - Decay Direction and Chain Selector

Status:

```text
COMPLETE
result_class = {summary['result_class']}
direction_rows_emitted = {summary['direction_rows_emitted']}
rebalance_direction_count = {summary['rebalance_direction_count']}
chain_step_count = {summary['chain_step_count']}
observed_decay_modes_used = false
observed_half_lives_used = false
free_parameters_introduced = 0
next_frontier = {summary['next_frontier']}
```

Question:

```text
Can SAM select native decay/rebalance direction from the QP056 pressure lanes?
```

Result:

```text
PASS. QP057 emits native decay/rebalance direction and first chain-step
candidates for all 200 QP056 pressure rows.
```

Output:

```text
artifacts/qp057/qp057_summary.json
artifacts/qp057/qp057_decay_direction_chain_table.csv
docs/reports/QP057_PRIVATE_DECAY_DIRECTION_CHAIN_SELECTOR.md
phase4_tables/phase5_decay_direction_chain_v1.csv
```

### QP058 - Phase 5 Pressure Freeze

Question:

```text
Can SAM freeze the isotope pressure extension as a coherent package?
```

Expected output:

```text
Phase 5 pressure-extension freeze and next-frontier summary
```
"""
    if "### QP057 - Decay Direction and Chain Selector" not in text:
        text += "\n\n" + result_block
    else:
        before, after = text.split(marker, 1)
        text = before + result_block
    text = text.replace(
        "next_test = QP057_PRIVATE_DECAY_DIRECTION_AND_CHAIN_SELECTOR",
        "next_test = QP058_PRIVATE_PHASE5_PRESSURE_FREEZE",
    )
    CAMPAIGN.write_text(text, encoding="utf-8")


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp056 = read_json(QP056_SUMMARY)
    pressure_rows = read_csv(QP056_PRESSURE_TABLE)
    direction_rows = build_direction_rows(pressure_rows)
    direction_summary = summarize(direction_rows, "native_rebalance_direction")
    chain_summary = summarize(direction_rows, "native_chain_step")
    direction_counts = Counter(row["native_rebalance_direction"] for row in direction_rows)
    chain_counts = Counter(row["native_chain_step"] for row in direction_rows)

    summary = {
        "artifact": "QP057_PRIVATE_DECAY_DIRECTION_AND_CHAIN_SELECTOR",
        "result_class": "QP057_DECAY_DIRECTION_AND_CHAIN_SELECTED",
        "campaign_status": "QP057_DECAY_DIRECTION_CHAIN_SELECTED_QP058_NEXT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_decay_modes_used": False,
        "observed_half_lives_used": False,
        "observed_isotope_masses_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp056/qp056_summary.json",
            "artifacts/qp056/qp056_residual_stability_decay_pressure_table.csv",
        ],
        "qp056_result_class": qp056["result_class"],
        "direction_rows_emitted": len(direction_rows),
        "rebalance_direction_count": len(direction_counts),
        "chain_step_count": len(chain_counts),
        "direction_counts": dict(direction_counts),
        "chain_step_counts": dict(chain_counts),
        "next_frontier": "QP058_PRIVATE_PHASE5_PRESSURE_FREEZE",
        "interpretation": (
            "QP057 selects native decay/rebalance direction and chain-step candidates from QP056 pressure lanes."
        ),
    }
    decision_rows = [
        {"decision_point": "preflight", "decision": "PASS_FORWARD_MODEL_BUILD", "note": "new direction selector; not audit, not retest, no public write"},
        {"decision_point": "direction", "decision": "SELECT_PRESSURE_TO_DIRECTION_MAP", "note": "pressure lane determines hold, balance, floorward, ceilward, or down-chain direction"},
        {"decision_point": "next", "decision": "QP058_READY", "note": "pressure extension can be frozen"},
    ]
    next_rows = [
        {
            "next_frontier": summary["next_frontier"],
            "why_next": "QP057 emits direction rows; pressure extension is ready for freeze.",
            "launch_from": "qp057_decay_direction_chain_table.csv",
            "target_output": "Phase 5 pressure-extension freeze",
        }
    ]
    schema_rows = [
        {"field": "native_rebalance_direction", "meaning": "selected native direction from pressure lane", "class": "direction_selector"},
        {"field": "native_chain_step", "meaning": "first symbolic chain step", "class": "chain_selector"},
        {"field": "target_A_after_step", "meaning": "native target A after first symbolic step", "class": "chain_coordinate"},
    ]
    fields = [
        "atomic_number",
        "symbol",
        "name",
        "Z_candidate",
        "N_candidate",
        "A_candidate",
        "ladder_role",
        "ladder_preference",
        "residual_twelfths",
        "decay_pressure_lane",
        "native_stability_preference",
        "native_rebalance_direction",
        "native_chain_step",
        "target_Z_after_step",
        "target_N_after_step",
        "target_A_after_step",
        "direction_selector_status",
        "next_selector_needed",
    ]
    write_json(SUMMARY_OUT, summary)
    write_json(PHASE5_SUMMARY, summary)
    write_csv(DIRECTION_OUT, direction_rows, fields)
    write_csv(PHASE5_DIRECTION_TABLE, direction_rows, fields)
    write_csv(DIRECTION_SUMMARY_OUT, direction_summary, ["native_rebalance_direction", "rows", "A_candidate_range", "symbols"])
    write_csv(CHAIN_SUMMARY_OUT, chain_summary, ["native_chain_step", "rows", "A_candidate_range", "symbols"])
    write_csv(DECISION_OUT, decision_rows, ["decision_point", "decision", "note"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_csv(SCHEMA_OUT, schema_rows, ["field", "meaning", "class"])
    write_doc(summary, direction_summary, chain_summary)
    update_campaign(summary)

    print(summary["result_class"])
    print(f"direction_rows_emitted={summary['direction_rows_emitted']}")
    print(f"rebalance_direction_count={summary['rebalance_direction_count']}")
    print(f"chain_step_count={summary['chain_step_count']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
