from __future__ import annotations

import csv
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
CAMPAIGNS = ROOT / "docs" / "campaigns"
PHASE4 = ROOT / "phase4_tables"

QP058_DIR = ARTIFACTS / "qp058"
PREFLIGHT_OUT = QP058_DIR / "qp058_preflight.md"
SUMMARY_OUT = QP058_DIR / "qp058_summary.json"
TABLE_INDEX_OUT = QP058_DIR / "qp058_pressure_extension_table_index.csv"
FREEZE_OUT = QP058_DIR / "qp058_pressure_extension_freeze_summary_table.csv"
NEXT_OUT = QP058_DIR / "qp058_next_frontier.csv"
DOC_OUT = REPORTS / "QP058_PRIVATE_PHASE5_PRESSURE_EXTENSION_FREEZE.md"
CAMPAIGN = CAMPAIGNS / "SAM_QP049_QP0XX_PHASE5_ISOTOPE_MASS_READOUT_CAMPAIGN.md"

PHASE5_PRESSURE_FREEZE_JSON = PHASE4 / "phase5_pressure_extension_freeze_summary.json"
PHASE5_PRESSURE_FREEZE_CSV = PHASE4 / "phase5_pressure_extension_freeze_summary.csv"

TABLES = [
    ("stability_decay_pressure", "phase4_tables/phase5_residual_stability_decay_pressure_v1.csv", "QP056", "native residual stability/decay pressure"),
    ("decay_direction_chain", "phase4_tables/phase5_decay_direction_chain_v1.csv", "QP057", "native rebalance direction and chain step"),
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def write_preflight() -> None:
    QP058_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP058 Preflight - Phase 5 Pressure Extension Freeze

```text
test_id = QP058
test_name = PRIVATE_PHASE5_PRESSURE_EXTENSION_FREEZE
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_decay_modes_used = false
observed_half_lives_used = false
observed_isotope_masses_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
phase4_tables/phase5_residual_stability_decay_pressure_v1.csv
phase4_tables/phase5_decay_direction_chain_v1.csv
```

## Forward Question

```text
Can SAM freeze the isotope pressure extension as a coherent package?
```

This is a new forward packaging gate. It does not rerun or audit QP056-QP057.
""",
        encoding="utf-8",
    )


def table_index() -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for table_id, rel_path, gate, description in TABLES:
        data = read_csv(ROOT / rel_path)
        rows.append(
            {
                "table_id": table_id,
                "path": rel_path,
                "source_gate": gate,
                "rows": len(data),
                "columns": len(data[0]) if data else 0,
                "description": description,
            }
        )
    return rows


def write_doc(summary: dict[str, Any], index_rows: list[dict[str, Any]]) -> None:
    lines = "\n".join(
        f"| {row['table_id']} | {row['source_gate']} | {row['rows']} | {row['path']} |"
        for row in index_rows
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP058 - Private Phase 5 Pressure Extension Freeze

## Result

```text
{summary['result_class']}
```

## Table Index

| table | source gate | rows | path |
| --- | --- | ---: | --- |
{lines}

## Key Counts

```text
pressure_extension_tables = {summary['pressure_extension_tables']}
stability_decay_pressure_rows = {summary['stability_decay_pressure_rows']}
decay_direction_chain_rows = {summary['decay_direction_chain_rows']}
observed_decay_modes_used = {str(summary['observed_decay_modes_used']).lower()}
observed_half_lives_used = {str(summary['observed_half_lives_used']).lower()}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

QP058 freezes the pressure extension on top of the Phase 5 isotope package.
SAM now carries a private native path from element seed to isotope ladder,
stability/decay pressure, and rebalance/chain direction.
""",
        encoding="utf-8",
    )


def update_campaign(summary: dict[str, Any]) -> None:
    text = CAMPAIGN.read_text(encoding="utf-8")
    text = text.replace(
        "ACTIVE_PHASE5_ISOTOPE_PRESSURE_EXTENSION_QP057_COMPLETE_QP058_NEXT",
        "COMPLETE_PHASE5_ISOTOPE_PRESSURE_EXTENSION_QP058_FROZEN",
    )
    marker = "### QP058 - Phase 5 Pressure Freeze\n"
    result_block = f"""### QP058 - Phase 5 Pressure Freeze

Status:

```text
COMPLETE
result_class = {summary['result_class']}
pressure_extension_tables = {summary['pressure_extension_tables']}
stability_decay_pressure_rows = {summary['stability_decay_pressure_rows']}
decay_direction_chain_rows = {summary['decay_direction_chain_rows']}
observed_decay_modes_used = false
observed_half_lives_used = false
free_parameters_introduced = 0
next_frontier = {summary['next_frontier']}
```

Result:

```text
PASS. QP058 freezes the Phase 5 pressure extension from QP056-QP057.
```
"""
    if "### QP058 - Phase 5 Pressure Freeze" not in text:
        text += "\n\n" + result_block
    else:
        before, after = text.split(marker, 1)
        text = before + result_block
    text = text.replace(
        "next_test = QP058_PRIVATE_PHASE5_PRESSURE_FREEZE",
        "next_test = QP059_PRIVATE_PHASE5_VISUAL_PACKAGE_OR_APPROVED_SEALED_COMPARISON",
    )
    CAMPAIGN.write_text(text, encoding="utf-8")


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    index_rows = table_index()
    index = {row["table_id"]: row for row in index_rows}
    summary = {
        "artifact": "QP058_PRIVATE_PHASE5_PRESSURE_EXTENSION_FREEZE",
        "result_class": "QP058_PHASE5_PRESSURE_EXTENSION_FROZEN",
        "campaign_status": "COMPLETE_PHASE5_ISOTOPE_PRESSURE_EXTENSION_QP058_FROZEN",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_decay_modes_used": False,
        "observed_half_lives_used": False,
        "observed_isotope_masses_used": False,
        "free_parameters_introduced": 0,
        "pressure_extension_tables": len(index_rows),
        "stability_decay_pressure_rows": index["stability_decay_pressure"]["rows"],
        "decay_direction_chain_rows": index["decay_direction_chain"]["rows"],
        "selector_inputs": [row["path"] for row in index_rows],
        "next_frontier": "QP059_PRIVATE_PHASE5_VISUAL_PACKAGE_OR_APPROVED_SEALED_COMPARISON",
        "interpretation": "QP058 freezes the Phase 5 isotope pressure extension from QP056-QP057.",
    }
    freeze_rows = [
        {"metric": key, "value": value}
        for key, value in summary.items()
        if key
        in {
            "result_class",
            "pressure_extension_tables",
            "stability_decay_pressure_rows",
            "decay_direction_chain_rows",
            "next_frontier",
        }
    ]
    next_rows = [
        {
            "next_frontier": summary["next_frontier"],
            "why_next": "The native pressure extension is frozen; next step is either a visual package or an explicitly approved sealed comparison.",
            "launch_from": "qp058_pressure_extension_table_index.csv",
            "target_output": "visual table package or sealed comparison protocol",
        }
    ]
    write_json(SUMMARY_OUT, summary)
    write_json(PHASE5_PRESSURE_FREEZE_JSON, summary)
    write_csv(TABLE_INDEX_OUT, index_rows, ["table_id", "path", "source_gate", "rows", "columns", "description"])
    write_csv(FREEZE_OUT, freeze_rows, ["metric", "value"])
    write_csv(PHASE5_PRESSURE_FREEZE_CSV, freeze_rows, ["metric", "value"])
    write_csv(NEXT_OUT, next_rows, ["next_frontier", "why_next", "launch_from", "target_output"])
    write_doc(summary, index_rows)
    update_campaign(summary)

    print(summary["result_class"])
    print(f"pressure_extension_tables={summary['pressure_extension_tables']}")
    print(f"stability_decay_pressure_rows={summary['stability_decay_pressure_rows']}")
    print(f"decay_direction_chain_rows={summary['decay_direction_chain_rows']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
