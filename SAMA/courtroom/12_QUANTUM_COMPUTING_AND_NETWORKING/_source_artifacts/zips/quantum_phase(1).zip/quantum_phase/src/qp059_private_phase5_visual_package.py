from __future__ import annotations

import csv
import json
import textwrap
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
CAMPAIGNS = ROOT / "docs" / "campaigns"
PHASE4 = ROOT / "phase4_tables"

QP055_SUMMARY = ARTIFACTS / "qp055" / "qp055_summary.json"
QP058_SUMMARY = ARTIFACTS / "qp058" / "qp058_summary.json"
QP052_MASS_TABLE = ARTIFACTS / "qp052" / "qp052_numeric_deltaN_binding_mass_table.csv"
QP054_LADDER_TABLE = ARTIFACTS / "qp054" / "qp054_isotope_neighbor_ladder_table.csv"
QP057_DIRECTION_TABLE = ARTIFACTS / "qp057" / "qp057_decay_direction_chain_table.csv"

QP059_DIR = ARTIFACTS / "qp059"
PREFLIGHT_OUT = QP059_DIR / "qp059_preflight.md"
SUMMARY_OUT = QP059_DIR / "qp059_summary.json"
ANCHOR_DIGEST_OUT = QP059_DIR / "qp059_anchor_digest.csv"
VISUAL_INDEX_OUT = QP059_DIR / "qp059_visual_index.csv"
CHAIN_PNG = QP059_DIR / "qp059_phase5_chain_summary.png"
ANCHOR_PNG = QP059_DIR / "qp059_anchor_digest.png"
PRESSURE_PNG = QP059_DIR / "qp059_residual_pressure_map.png"
DOC_OUT = REPORTS / "QP059_PRIVATE_PHASE5_VISUAL_PACKAGE.md"
CAMPAIGN = CAMPAIGNS / "SAM_QP049_QP0XX_PHASE5_ISOTOPE_MASS_READOUT_CAMPAIGN.md"

PHASE5_VISUAL_SUMMARY = PHASE4 / "phase5_visual_package_summary.json"
PHASE5_ANCHOR_DIGEST = PHASE4 / "phase5_visual_anchor_digest.csv"
PHASE5_CHAIN_PNG = PHASE4 / "phase5_visual_chain_summary.png"
PHASE5_ANCHOR_PNG = PHASE4 / "phase5_visual_anchor_digest.png"
PHASE5_PRESSURE_PNG = PHASE4 / "phase5_visual_residual_pressure_map.png"

ANCHORS = ["C", "O", "Fe", "Ni", "Au", "Pb", "Bi", "Th", "U", "Og"]

BG = "#f7f8fb"
INK = "#1e2430"
MUTED = "#667085"
NAVY = "#172033"
LINE = "#d6dbe5"
GREEN = "#d8f3e8"
GREEN_DARK = "#057a55"
BLUE = "#dceafe"
BLUE_DARK = "#1d4ed8"
AMBER = "#fff3d6"
AMBER_DARK = "#b45309"
ROSE = "#ffe4e6"
ROSE_DARK = "#be123c"
PURPLE = "#efe4ff"
PURPLE_DARK = "#7e22ce"


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont | ImageFont.ImageFont:
    candidates = [
        Path("C:/Windows/Fonts/segoeuib.ttf" if bold else "C:/Windows/Fonts/segoeui.ttf"),
        Path("C:/Windows/Fonts/arialbd.ttf" if bold else "C:/Windows/Fonts/arial.ttf"),
    ]
    for path in candidates:
        if path.exists():
            return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


FONT_TITLE = font(34, True)
FONT_H2 = font(23, True)
FONT_BODY = font(18)
FONT_SMALL = font(15)
FONT_TINY = font(13)
FONT_MONO = font(15)


def write_preflight() -> None:
    QP059_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP059 Preflight - Phase 5 Visual Package

```text
test_id = QP059
test_name = PRIVATE_PHASE5_VISUAL_PACKAGE
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
observed_decay_modes_used = false
observed_half_lives_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
artifacts/qp055/qp055_summary.json
artifacts/qp058/qp058_summary.json
artifacts/qp052/qp052_numeric_deltaN_binding_mass_table.csv
artifacts/qp054/qp054_isotope_neighbor_ladder_table.csv
artifacts/qp057/qp057_decay_direction_chain_table.csv
```

## Expected Outputs

```text
artifacts/qp059/qp059_phase5_chain_summary.png
artifacts/qp059/qp059_anchor_digest.png
artifacts/qp059/qp059_residual_pressure_map.png
artifacts/qp059/qp059_anchor_digest.csv
docs/reports/QP059_PRIVATE_PHASE5_VISUAL_PACKAGE.md
phase4_tables/phase5_visual_*.png
```

## Forward Question

```text
Can SAM render the private Phase 5 isotope/pressure result into an inspectable
visual package without observed isotope data or a sealed comparison?
```

This is a visual/readout packaging gate. It does not compare against external
isotope tables.
""",
        encoding="utf-8",
    )


def text_size(draw: ImageDraw.ImageDraw, text: str, fnt: ImageFont.ImageFont) -> tuple[int, int]:
    box = draw.textbbox((0, 0), text, font=fnt)
    return box[2] - box[0], box[3] - box[1]


def draw_text(
    draw: ImageDraw.ImageDraw,
    xy: tuple[int, int],
    text: str,
    fnt: ImageFont.ImageFont,
    fill: str = INK,
    width: int | None = None,
    line_spacing: int = 4,
) -> int:
    x, y = xy
    if width is None:
        draw.text((x, y), text, font=fnt, fill=fill)
        return text_size(draw, text, fnt)[1]
    avg_char = max(5, text_size(draw, "abcdefghijklmnopqrstuvwxyz", fnt)[0] // 26)
    wrap_chars = max(8, int((width // avg_char) * 0.68))
    lines: list[str] = []
    for raw_line in text.splitlines():
        if not raw_line:
            lines.append("")
        else:
            lines.extend(textwrap.wrap(raw_line, width=wrap_chars, break_long_words=False))
    cursor = y
    line_h = text_size(draw, "Ag", fnt)[1] + line_spacing
    for line in lines:
        draw.text((x, cursor), line, font=fnt, fill=fill)
        cursor += line_h
    return cursor - y


def rounded_rect(draw: ImageDraw.ImageDraw, box: tuple[int, int, int, int], fill: str, outline: str = LINE, r: int = 8) -> None:
    draw.rounded_rectangle(box, radius=r, fill=fill, outline=outline, width=1)


def render_chain_summary(path: Path) -> None:
    img = Image.new("RGB", (1700, 1000), BG)
    draw = ImageDraw.Draw(img)
    draw.rectangle((0, 0, 1700, 86), fill=NAVY)
    draw_text(draw, (44, 24), "SAM Phase 5 Isotope Chain", FONT_TITLE, "#ffffff")
    draw_text(draw, (44, 106), "Private visual package: no observed isotope masses, decay modes, half-lives, or abundance data used.", FONT_BODY, MUTED)

    stages = [
        ("QP049", "Seed identity", "Z -> alpha/deuteron seed\n118 rows"),
        ("QP050", "Symmetric seed mass", "M_seed(Z)\nA_seed = 2Z"),
        ("QP051", "Depth lane", "A-road + R=12 stack\nneutron-excess ownership"),
        ("QP052", "DeltaN packets", "DeltaN = floor(Z*depth/12)\n118 mass candidates"),
        ("QP053", "Roster lanes", "residual twelfths\nanchor / branch / transient"),
        ("QP054", "Neighbor ladder", "floor + ceil candidates\n200 ladder rows"),
        ("QP056", "Pressure", "stability / decay pressure\n200 rows"),
        ("QP057", "Direction", "hold / balance / chain step\n200 rows"),
    ]
    x0, y0 = 54, 180
    card_w, card_h = 370, 155
    gap_x, gap_y = 36, 60
    fills = [GREEN, GREEN, BLUE, BLUE, AMBER, AMBER, PURPLE, PURPLE]
    for idx, (gate, title, body) in enumerate(stages):
        col = idx % 4
        row = idx // 4
        x = x0 + col * (card_w + gap_x)
        y = y0 + row * (card_h + gap_y)
        rounded_rect(draw, (x, y, x + card_w, y + card_h), fills[idx])
        draw_text(draw, (x + 22, y + 18), gate, FONT_H2, NAVY)
        draw_text(draw, (x + 112, y + 19), title, FONT_H2, INK)
        draw_text(draw, (x + 22, y + 66), body, FONT_BODY, INK, width=card_w - 44)
        if col < 3:
            draw.line((x + card_w + 6, y + card_h // 2, x + card_w + gap_x - 8, y + card_h // 2), fill=MUTED, width=3)
            draw.polygon(
                [
                    (x + card_w + gap_x - 8, y + card_h // 2),
                    (x + card_w + gap_x - 22, y + card_h // 2 - 8),
                    (x + card_w + gap_x - 22, y + card_h // 2 + 8),
                ],
                fill=MUTED,
            )
    draw.line((54, 665, 1646, 665), fill=LINE, width=2)
    draw_text(draw, (70, 705), "Current frozen package", FONT_H2, NAVY)
    facts = [
        "6 isotope package tables",
        "2 pressure-extension tables",
        "118 element seed/mass rows",
        "200 ladder/pressure/direction rows",
        "0 free parameters introduced in Phase 5",
    ]
    for i, fact in enumerate(facts):
        x = 70 + (i % 3) * 500
        y = 760 + (i // 3) * 80
        rounded_rect(draw, (x, y, x + 430, y + 54), "#ffffff")
        draw_text(draw, (x + 18, y + 15), fact, FONT_BODY, INK)
    path.parent.mkdir(parents=True, exist_ok=True)
    img.save(path)


def build_anchor_digest() -> list[dict[str, Any]]:
    mass_by_symbol = {row["symbol"]: row for row in read_csv(QP052_MASS_TABLE)}
    direction_rows = read_csv(QP057_DIRECTION_TABLE)
    ladder_rows = read_csv(QP054_LADDER_TABLE)
    by_symbol: dict[str, list[dict[str, str]]] = defaultdict(list)
    for row in direction_rows:
        by_symbol[row["symbol"]].append(row)
    out: list[dict[str, Any]] = []
    for symbol in ANCHORS:
        mass = mass_by_symbol[symbol]
        ladder = sorted(by_symbol[symbol], key=lambda row: (row["ladder_role"], int(row["A_candidate"])))
        ladder_desc = "; ".join(
            f"{row['A_candidate']} {row['ladder_role']} {row['native_rebalance_direction']}"
            for row in ladder
        )
        primary = sorted(
            ladder,
            key=lambda row: (
                0 if row["ladder_preference"] in {"PRIMARY_EXACT", "PRIMARY_PREFERRED", "BALANCED_HALF_WRITE", "CEIL_PREFERRED"} else 1,
                -float(next((r["ladder_weight"] for r in ladder_rows if r["symbol"] == symbol and r["A_candidate"] == row["A_candidate"] and r["ladder_role"] == row["ladder_role"]), "0")),
            ),
        )[0]
        out.append(
            {
                "symbol": symbol,
                "Z": mass["Z_candidate"],
                "primary_A": primary["A_candidate"],
                "primary_N": primary["N_candidate"],
                "DeltaN": mass["deltaN_closed_packets"],
                "residual": mass["deltaN_fractional_residual"],
                "residual_native": f"{primary['residual_twelfths']}/12",
                "pressure": primary["decay_pressure_lane"],
                "direction": primary["native_rebalance_direction"],
                "chain_step": primary["native_chain_step"],
                "ladder": ladder_desc,
            }
        )
    return out


def render_anchor_digest(path: Path, rows: list[dict[str, Any]]) -> None:
    img = Image.new("RGB", (2100, 1080), BG)
    draw = ImageDraw.Draw(img)
    draw.rectangle((0, 0, 2100, 86), fill=NAVY)
    draw_text(draw, (42, 24), "SAM Phase 5 Anchor Digest", FONT_TITLE, "#ffffff")
    draw_text(draw, (42, 106), "Selected rows that make the isotope ladder and pressure result inspectable.", FONT_BODY, MUTED)

    cols = [
        ("Sym", 70),
        ("Z", 55),
        ("A/N", 90),
        ("DeltaN", 76),
        ("Residual", 82),
        ("Pressure", 315),
        ("Direction", 355),
        ("Ladder", 960),
    ]
    x = 42
    y = 165
    row_h = 78
    draw.rectangle((x, y, x + sum(w for _, w in cols), y + 42), fill="#dfe7f5")
    cursor = x
    for label, w in cols:
        draw_text(draw, (cursor + 10, y + 11), label, FONT_SMALL, NAVY)
        cursor += w
    for idx, row in enumerate(rows):
        y0 = y + 42 + idx * row_h
        fill = "#ffffff" if idx % 2 == 0 else "#f1f5fb"
        draw.rectangle((x, y0, x + sum(w for _, w in cols), y0 + row_h), fill=fill, outline=LINE)
        values = [
            row["symbol"],
            row["Z"],
            f"{row['primary_A']}/{row['primary_N']}",
            row["DeltaN"],
            row["residual_native"],
            row["pressure"].replace("_", " "),
            row["direction"].replace("_", " "),
            row["ladder"].replace("_", " "),
        ]
        cursor = x
        for (label, w), value in zip(cols, values):
            fnt = FONT_H2 if label == "Sym" else FONT_TINY
            draw_text(draw, (cursor + 10, y0 + 10), str(value), fnt, INK, width=w - 18, line_spacing=2)
            cursor += w
    img.save(path)


def render_pressure_map(path: Path) -> None:
    pressure_rows = read_csv(QP057_DIRECTION_TABLE)
    residual_groups: dict[int, list[dict[str, str]]] = defaultdict(list)
    for row in pressure_rows:
        residual_groups[int(row["residual_twelfths"])].append(row)
    img = Image.new("RGB", (1800, 1180), BG)
    draw = ImageDraw.Draw(img)
    draw.rectangle((0, 0, 1800, 86), fill=NAVY)
    draw_text(draw, (42, 24), "Residual Twelfths -> Pressure -> Direction", FONT_TITLE, "#ffffff")
    draw_text(draw, (42, 106), "The leftover neutron-packet fraction becomes native pressure and rebalance direction.", FONT_BODY, MUTED)
    card_w, card_h = 415, 210
    x0, y0 = 42, 165
    for units in range(12):
        members = residual_groups.get(units, [])
        pressures = Counter(row["decay_pressure_lane"] for row in members)
        directions = Counter(row["native_rebalance_direction"] for row in members)
        col = units % 4
        row = units // 4
        x = x0 + col * (card_w + 25)
        y = y0 + row * (card_h + 30)
        if units in {0, 6}:
            fill, accent = GREEN, GREEN_DARK
        elif units in {4, 8}:
            fill, accent = BLUE, BLUE_DARK
        elif units in {3, 9, 2, 10}:
            fill, accent = AMBER, AMBER_DARK
        else:
            fill, accent = ROSE, ROSE_DARK
        rounded_rect(draw, (x, y, x + card_w, y + card_h), fill)
        draw_text(draw, (x + 18, y + 14), f"{units}/12", FONT_TITLE, accent)
        draw_text(draw, (x + 135, y + 24), f"{len(members)} ladder rows", FONT_BODY, INK)
        p_text = "; ".join(f"{k.replace('_', ' ')} ({v})" for k, v in pressures.most_common(2)) or "no rows"
        d_text = "; ".join(f"{k.replace('_', ' ')} ({v})" for k, v in directions.most_common(2)) or "no direction"
        draw_text(draw, (x + 18, y + 78), "Pressure", FONT_SMALL, accent)
        draw_text(draw, (x + 18, y + 102), p_text, FONT_TINY, INK, width=card_w - 36, line_spacing=2)
        draw_text(draw, (x + 18, y + 150), "Direction", FONT_SMALL, accent)
        draw_text(draw, (x + 18, y + 174), d_text, FONT_TINY, INK, width=card_w - 36, line_spacing=2)
    img.save(path)


def copy_visuals() -> None:
    for src, dst in [
        (CHAIN_PNG, PHASE5_CHAIN_PNG),
        (ANCHOR_PNG, PHASE5_ANCHOR_PNG),
        (PRESSURE_PNG, PHASE5_PRESSURE_PNG),
    ]:
        dst.write_bytes(src.read_bytes())


def visual_index() -> list[dict[str, Any]]:
    entries = [
        ("phase5_chain_summary", CHAIN_PNG, PHASE5_CHAIN_PNG, "Phase 5 gate chain and package counts"),
        ("anchor_digest", ANCHOR_PNG, PHASE5_ANCHOR_PNG, "Key anchor rows and directions"),
        ("residual_pressure_map", PRESSURE_PNG, PHASE5_PRESSURE_PNG, "Residual twelfths pressure map"),
    ]
    rows: list[dict[str, Any]] = []
    for visual_id, artifact_path, phase_path, description in entries:
        with Image.open(artifact_path) as img:
            width, height = img.size
        rows.append(
            {
                "visual_id": visual_id,
                "artifact_path": str(artifact_path.relative_to(ROOT)).replace("\\", "/"),
                "phase_table_path": str(phase_path.relative_to(ROOT)).replace("\\", "/"),
                "width": width,
                "height": height,
                "description": description,
            }
        )
    return rows


def write_doc(summary: dict[str, Any], anchors: list[dict[str, Any]], visuals: list[dict[str, Any]]) -> None:
    anchor_lines = "\n".join(
        f"| {row['symbol']} | {row['primary_A']} | {row['DeltaN']} | {row['pressure']} | {row['direction']} |"
        for row in anchors
    )
    visual_lines = "\n".join(
        f"| {row['visual_id']} | {row['width']}x{row['height']} | {row['phase_table_path']} |"
        for row in visuals
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP059 - Private Phase 5 Visual Package

## Preflight

```text
test_id = QP059
test_name = PRIVATE_PHASE5_VISUAL_PACKAGE
test_type = FORWARD_MODEL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
observed_decay_modes_used = false
observed_half_lives_used = false
free_parameters_introduced = 0
```

## Result

```text
{summary['result_class']}
```

## Visual Index

| visual | size | path |
| --- | --- | --- |
{visual_lines}

## Anchor Digest

| symbol | primary A | DeltaN | pressure | direction |
| --- | ---: | ---: | --- | --- |
{anchor_lines}

## Key Counts

```text
visuals_generated = {summary['visuals_generated']}
anchor_digest_rows = {summary['anchor_digest_rows']}
observed_isotope_masses_used = {str(summary['observed_isotope_masses_used']).lower()}
observed_decay_modes_used = {str(summary['observed_decay_modes_used']).lower()}
free_parameters_introduced = {summary['free_parameters_introduced']}
next_frontier = {summary['next_frontier']}
```

## Interpretation

QP059 makes the Phase 5 isotope result visible without running a sealed
comparison. The next fork is either a private presentation/readout pass or an
explicitly approved sealed comparison against external isotope data.
""",
        encoding="utf-8",
    )


def update_campaign(summary: dict[str, Any]) -> None:
    text = CAMPAIGN.read_text(encoding="utf-8")
    text = text.replace(
        "COMPLETE_PHASE5_ISOTOPE_PRESSURE_EXTENSION_QP058_FROZEN",
        "COMPLETE_PHASE5_VISUAL_PACKAGE_QP059_BUILT",
    )
    text = text.replace(
        "next_test = QP059_PRIVATE_PHASE5_VISUAL_PACKAGE_OR_APPROVED_SEALED_COMPARISON",
        "next_test = QP060_PRIVATE_SEALED_COMPARISON_PROTOCOL_REQUIRES_EXPLICIT_APPROVAL",
    )
    result_block = f"""### QP059 - Phase 5 Visual Package

Status:

```text
COMPLETE
result_class = {summary['result_class']}
visuals_generated = {summary['visuals_generated']}
anchor_digest_rows = {summary['anchor_digest_rows']}
observed_isotope_masses_used = false
observed_decay_modes_used = false
free_parameters_introduced = 0
next_frontier = {summary['next_frontier']}
```

Result:

```text
PASS. QP059 renders the Phase 5 isotope/pressure package into private PNG
readout visuals and an anchor digest.
```
"""
    if "### QP059 - Phase 5 Visual Package" not in text:
        text += "\n\n" + result_block
    else:
        before, _ = text.split("### QP059 - Phase 5 Visual Package", 1)
        text = before + result_block
    CAMPAIGN.write_text(text, encoding="utf-8")


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()
    qp055 = read_json(QP055_SUMMARY)
    qp058 = read_json(QP058_SUMMARY)
    anchor_rows = build_anchor_digest()
    write_csv(
        ANCHOR_DIGEST_OUT,
        anchor_rows,
        ["symbol", "Z", "primary_A", "primary_N", "DeltaN", "residual", "residual_native", "pressure", "direction", "chain_step", "ladder"],
    )
    write_csv(
        PHASE5_ANCHOR_DIGEST,
        anchor_rows,
        ["symbol", "Z", "primary_A", "primary_N", "DeltaN", "residual", "residual_native", "pressure", "direction", "chain_step", "ladder"],
    )
    render_chain_summary(CHAIN_PNG)
    render_anchor_digest(ANCHOR_PNG, anchor_rows)
    render_pressure_map(PRESSURE_PNG)
    copy_visuals()
    visuals = visual_index()

    summary = {
        "artifact": "QP059_PRIVATE_PHASE5_VISUAL_PACKAGE",
        "result_class": "QP059_PHASE5_VISUAL_PACKAGE_BUILT",
        "campaign_status": "COMPLETE_PHASE5_VISUAL_PACKAGE_QP059_BUILT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_MODEL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_isotope_masses_used": False,
        "observed_decay_modes_used": False,
        "observed_half_lives_used": False,
        "free_parameters_introduced": 0,
        "selector_inputs": [
            "artifacts/qp055/qp055_summary.json",
            "artifacts/qp058/qp058_summary.json",
            "artifacts/qp052/qp052_numeric_deltaN_binding_mass_table.csv",
            "artifacts/qp054/qp054_isotope_neighbor_ladder_table.csv",
            "artifacts/qp057/qp057_decay_direction_chain_table.csv",
        ],
        "qp055_result_class": qp055["result_class"],
        "qp058_result_class": qp058["result_class"],
        "visuals_generated": len(visuals),
        "anchor_digest_rows": len(anchor_rows),
        "visual_ids": [row["visual_id"] for row in visuals],
        "next_frontier": "QP060_PRIVATE_SEALED_COMPARISON_PROTOCOL_REQUIRES_EXPLICIT_APPROVAL",
        "interpretation": "QP059 renders the private Phase 5 isotope/pressure package into inspectable PNGs and an anchor digest.",
    }
    write_json(SUMMARY_OUT, summary)
    write_json(PHASE5_VISUAL_SUMMARY, summary)
    write_csv(VISUAL_INDEX_OUT, visuals, ["visual_id", "artifact_path", "phase_table_path", "width", "height", "description"])
    write_doc(summary, anchor_rows, visuals)
    update_campaign(summary)

    print(summary["result_class"])
    print(f"visuals_generated={summary['visuals_generated']}")
    print(f"anchor_digest_rows={summary['anchor_digest_rows']}")
    print(f"next={summary['next_frontier']}")


if __name__ == "__main__":
    main()
