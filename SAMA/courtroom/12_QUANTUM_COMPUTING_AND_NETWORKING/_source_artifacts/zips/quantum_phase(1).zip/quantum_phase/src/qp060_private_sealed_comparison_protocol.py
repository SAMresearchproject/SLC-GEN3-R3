from __future__ import annotations

import csv
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
CAMPAIGNS = ROOT / "docs" / "campaigns"
PHASE4 = ROOT / "phase4_tables"

QP060_DIR = ARTIFACTS / "qp060"
PREFLIGHT_OUT = QP060_DIR / "qp060_preflight.md"
SUMMARY_OUT = QP060_DIR / "qp060_summary.json"
PREDICTION_MANIFEST_OUT = QP060_DIR / "qp060_prediction_manifest.csv"
HASH_MANIFEST_OUT = QP060_DIR / "qp060_file_hash_manifest.csv"
COMPARISON_SCHEMA_OUT = QP060_DIR / "qp060_comparison_schema.csv"
SCORING_LANES_OUT = QP060_DIR / "qp060_scoring_lanes.csv"
EXTERNAL_TEMPLATE_OUT = QP060_DIR / "qp060_external_data_manifest_template.csv"
ALLOWED_QUESTIONS_OUT = QP060_DIR / "qp060_allowed_questions.csv"
NEXT_FRONTIER_OUT = QP060_DIR / "qp060_next_frontier.csv"
DOC_OUT = REPORTS / "QP060_PRIVATE_SEALED_COMPARISON_PROTOCOL.md"
CAMPAIGN = CAMPAIGNS / "SAM_QP049_QP0XX_PHASE5_ISOTOPE_MASS_READOUT_CAMPAIGN.md"

PHASE5_SEALED_PREDICTION_MANIFEST = PHASE4 / "phase5_sealed_prediction_manifest.csv"
PHASE5_SEALED_HASH_MANIFEST = PHASE4 / "phase5_sealed_hash_manifest.csv"

LADDER_TABLE = PHASE4 / "phase5_isotope_neighbor_ladder_v1.csv"
PRESSURE_TABLE = PHASE4 / "phase5_residual_stability_decay_pressure_v1.csv"
DIRECTION_TABLE = PHASE4 / "phase5_decay_direction_chain_v1.csv"

SEALED_INPUTS = [
    ("QP052", "numeric_deltaN_binding_mass", PHASE4 / "phase5_numeric_deltaN_binding_mass_v1.csv"),
    ("QP054", "isotope_neighbor_ladder", LADDER_TABLE),
    ("QP056", "residual_stability_decay_pressure", PRESSURE_TABLE),
    ("QP057", "decay_direction_chain", DIRECTION_TABLE),
    ("QP059", "visual_anchor_digest", PHASE4 / "phase5_visual_anchor_digest.csv"),
    ("QP055", "phase5_isotope_freeze_summary", ARTIFACTS / "qp055" / "qp055_summary.json"),
    ("QP058", "phase5_pressure_extension_freeze_summary", ARTIFACTS / "qp058" / "qp058_summary.json"),
    ("QP059", "phase5_visual_package_summary", ARTIFACTS / "qp059" / "qp059_summary.json"),
]


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_preflight() -> None:
    QP060_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP060 Preflight - Private Sealed Comparison Protocol

```text
test_id = QP060
test_name = PRIVATE_SEALED_COMPARISON_PROTOCOL
test_type = FORWARD_PROTOCOL_BUILD
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
explicit_user_approval = proceed_to_the_vault_door
public_repo_write = false
external_data_used = false
observed_isotope_masses_used = false
observed_decay_modes_used = false
observed_half_lives_used = false
observed_abundances_used = false
free_parameters_introduced = 0
```

## Source Inputs

```text
phase4_tables/phase5_numeric_deltaN_binding_mass_v1.csv
phase4_tables/phase5_isotope_neighbor_ladder_v1.csv
phase4_tables/phase5_residual_stability_decay_pressure_v1.csv
phase4_tables/phase5_decay_direction_chain_v1.csv
phase4_tables/phase5_visual_anchor_digest.csv
artifacts/qp055/qp055_summary.json
artifacts/qp058/qp058_summary.json
artifacts/qp059/qp059_summary.json
```

## Expected Outputs

```text
artifacts/qp060/qp060_prediction_manifest.csv
artifacts/qp060/qp060_file_hash_manifest.csv
artifacts/qp060/qp060_comparison_schema.csv
artifacts/qp060/qp060_scoring_lanes.csv
artifacts/qp060/qp060_external_data_manifest_template.csv
docs/reports/QP060_PRIVATE_SEALED_COMPARISON_PROTOCOL.md
phase4_tables/phase5_sealed_prediction_manifest.csv
phase4_tables/phase5_sealed_hash_manifest.csv
```

## Forward Question

```text
Can SAM freeze the private Phase 5 isotope prediction bundle and define the
sealed comparison rules before any observed isotope data enters?
```

This gate builds the vault door. It does not open the door and does not compare
against external isotope, decay, half-life, or abundance tables.
""",
        encoding="utf-8",
    )


def row_key(row: dict[str, str]) -> tuple[str, str, str, str, str, str, str]:
    return (
        row.get("atomic_number", ""),
        row.get("symbol", ""),
        row.get("Z_candidate", ""),
        row.get("N_candidate", ""),
        row.get("A_candidate", ""),
        row.get("ladder_role", ""),
        row.get("ladder_preference", ""),
    )


def build_prediction_manifest() -> list[dict[str, Any]]:
    ladder_rows = read_csv(LADDER_TABLE)
    pressure_rows = read_csv(PRESSURE_TABLE)
    direction_rows = read_csv(DIRECTION_TABLE)

    pressure_by_key = {row_key(row): row for row in pressure_rows}
    direction_by_key = {row_key(row): row for row in direction_rows}

    rows: list[dict[str, Any]] = []
    for index, ladder in enumerate(ladder_rows, start=1):
        pressure = pressure_by_key.get(row_key(ladder), {})
        direction = direction_by_key.get(row_key(ladder), {})
        symbol = ladder.get("symbol", "")
        z_value = int(ladder.get("atomic_number", "0") or "0")
        a_value = int(ladder.get("A_candidate", "0") or "0")
        role_code = "P" if ladder.get("ladder_role") == "FLOOR_PRIMARY" else "N"
        prediction_id = f"SAM-P5-{z_value:03d}-{symbol}-{a_value:03d}-{role_code}-{index:03d}"

        rows.append(
            {
                "prediction_id": prediction_id,
                "atomic_number": ladder.get("atomic_number", ""),
                "symbol": symbol,
                "name": ladder.get("name", ""),
                "Z_candidate": ladder.get("Z_candidate", ""),
                "N_candidate": ladder.get("N_candidate", ""),
                "A_candidate": ladder.get("A_candidate", ""),
                "candidate_notation": f"{symbol}-{a_value}",
                "ladder_role": ladder.get("ladder_role", ""),
                "ladder_preference": ladder.get("ladder_preference", ""),
                "ladder_weight": ladder.get("ladder_weight", ""),
                "residual_twelfths": ladder.get("residual_twelfths", ""),
                "residual_fraction_native": ladder.get("residual_fraction_native", ""),
                "roster_stability_lane": ladder.get("roster_stability_lane", ""),
                "anchor_status": ladder.get("anchor_status", ""),
                "selected_depth_index": ladder.get("selected_depth_index", ""),
                "selected_neutron_excess_lane": ladder.get("selected_neutron_excess_lane", ""),
                "formation_lane": ladder.get("formation_lane", ""),
                "A_band": ladder.get("A_band", ""),
                "sam_isotope_mass_candidate_MeV": ladder.get("sam_isotope_mass_candidate_MeV", ""),
                "decay_pressure_lane": pressure.get("decay_pressure_lane", ""),
                "native_stability_preference": pressure.get("native_stability_preference", ""),
                "native_rebalance_direction": direction.get("native_rebalance_direction", ""),
                "native_chain_step": direction.get("native_chain_step", ""),
                "target_Z_after_step": direction.get("target_Z_after_step", ""),
                "target_N_after_step": direction.get("target_N_after_step", ""),
                "target_A_after_step": direction.get("target_A_after_step", ""),
                "sealed_source_gates": "QP052|QP054|QP056|QP057|QP059",
                "mass_convention_lock": "SAM_NATIVE_COMPOSITE_MASS_READOUT_MEV_NO_ATOMIC_ELECTRON_CORRECTION",
                "observed_data_used": "false",
                "comparison_locked_until": "QP061_APPROVED_EXTERNAL_DATA_PREFLIGHT",
                "selector_status": "SEALED_PHASE5_NATIVE_PREDICTION_ROW",
            }
        )
    return rows


def build_comparison_schema() -> list[dict[str, Any]]:
    return [
        {
            "field_name": "dataset_id",
            "owner": "external_manifest",
            "required_for_qp061": "true",
            "data_type": "string",
            "rule": "Must identify the approved external dataset before import.",
        },
        {
            "field_name": "observed_symbol",
            "owner": "external_data",
            "required_for_qp061": "true",
            "data_type": "string",
            "rule": "Must be mapped to SAM symbol without changing SAM prediction rows.",
        },
        {
            "field_name": "observed_Z",
            "owner": "external_data",
            "required_for_qp061": "true",
            "data_type": "integer",
            "rule": "Used only for row alignment.",
        },
        {
            "field_name": "observed_N",
            "owner": "external_data",
            "required_for_qp061": "conditional",
            "data_type": "integer",
            "rule": "Required for isotope-level exact candidate matching when available.",
        },
        {
            "field_name": "observed_A",
            "owner": "external_data",
            "required_for_qp061": "true",
            "data_type": "integer",
            "rule": "Primary sealed comparison key against A_candidate.",
        },
        {
            "field_name": "observed_mass_MeV",
            "owner": "external_data",
            "required_for_qp061": "conditional",
            "data_type": "float",
            "rule": "Only used after mass convention is declared.",
        },
        {
            "field_name": "mass_convention",
            "owner": "external_manifest",
            "required_for_qp061": "conditional",
            "data_type": "enum",
            "rule": "Must declare nuclear, atomic, or mass-excess convention before any mass residual.",
        },
        {
            "field_name": "observed_stability_or_half_life_class",
            "owner": "external_data",
            "required_for_qp061": "conditional",
            "data_type": "string",
            "rule": "Only used for anchor/pressure comparison if approved.",
        },
        {
            "field_name": "observed_decay_mode",
            "owner": "external_data",
            "required_for_qp061": "conditional",
            "data_type": "string",
            "rule": "Only used for decay direction comparison if approved.",
        },
        {
            "field_name": "observed_abundance",
            "owner": "external_data",
            "required_for_qp061": "conditional",
            "data_type": "float",
            "rule": "Optional abundance support channel; not required for first sealed roster comparison.",
        },
    ]


def build_scoring_lanes() -> list[dict[str, Any]]:
    return [
        {
            "lane_id": "A_EXACT_MATCH",
            "external_data_required": "observed_symbol|observed_A",
            "score_rule": "Count whether candidate_notation appears in approved observed isotope roster.",
            "qp061_status": "ALLOWED_AFTER_EXTERNAL_PREFLIGHT",
        },
        {
            "lane_id": "PRIMARY_CANDIDATE_MATCH",
            "external_data_required": "observed_symbol|observed_A",
            "score_rule": "Evaluate FLOOR_PRIMARY prediction rows separately from ceil-neighbor rows.",
            "qp061_status": "ALLOWED_AFTER_EXTERNAL_PREFLIGHT",
        },
        {
            "lane_id": "NEIGHBOR_LADDER_COVERAGE",
            "external_data_required": "observed_symbol|observed_A",
            "score_rule": "Evaluate whether primary or nearest native neighbor covers approved observed isotope roster.",
            "qp061_status": "ALLOWED_AFTER_EXTERNAL_PREFLIGHT",
        },
        {
            "lane_id": "ANCHOR_PRESSURE_ALIGNMENT",
            "external_data_required": "observed_stability_or_half_life_class",
            "score_rule": "Compare exact/half/dense/native pressure lanes to stable or long-lived categories.",
            "qp061_status": "OPTIONAL_AFTER_EXTERNAL_PREFLIGHT",
        },
        {
            "lane_id": "DECAY_DIRECTION_ALIGNMENT",
            "external_data_required": "observed_decay_mode",
            "score_rule": "Compare native rebalance direction and chain step to observed decay mode class.",
            "qp061_status": "OPTIONAL_AFTER_EXTERNAL_PREFLIGHT",
        },
        {
            "lane_id": "MASS_DELTA_DECLARED_CONVENTION",
            "external_data_required": "observed_mass_MeV|mass_convention",
            "score_rule": "Compute mass residual only after nuclear/atomic/mass-excess convention is declared.",
            "qp061_status": "OPTIONAL_AFTER_EXTERNAL_PREFLIGHT",
        },
        {
            "lane_id": "NO_REFIT_GUARD",
            "external_data_required": "none",
            "score_rule": "No SAM constants, candidate rows, lane labels, or selection rules may change after data import.",
            "qp061_status": "MANDATORY_PROTOCOL_GUARD",
        },
    ]


def build_external_template() -> list[dict[str, Any]]:
    return [
        {
            "dataset_id": "TO_BE_DECLARED_BEFORE_QP061",
            "source_name": "",
            "source_url_or_file": "",
            "retrieval_date_utc": "",
            "license_or_terms": "",
            "data_type": "isotope_roster|mass|decay|half_life|abundance",
            "mass_convention": "nuclear|atomic|mass_excess|not_applicable",
            "includes_observed_masses": "",
            "includes_decay_modes": "",
            "includes_half_lives": "",
            "includes_abundances": "",
            "columns_used": "",
            "preprocessing_declared": "",
            "approved_by": "",
            "approval_timestamp_utc": "",
            "sha256": "",
        }
    ]


def build_allowed_questions() -> list[dict[str, Any]]:
    return [
        {
            "question_id": "Q1_ROSTER_PRESENCE",
            "permitted_in_qp061": "true",
            "requires_external_data": "true",
            "answer_format": "counts and rates by element and ladder role",
            "question": "Which sealed SAM isotope A candidates appear in the approved observed isotope roster?",
        },
        {
            "question_id": "Q2_PRIMARY_VS_NEIGHBOR",
            "permitted_in_qp061": "true",
            "requires_external_data": "true",
            "answer_format": "primary coverage, neighbor coverage, misses",
            "question": "How much coverage comes from FLOOR_PRIMARY rows versus ceil-neighbor rows?",
        },
        {
            "question_id": "Q3_ANCHOR_LONG_LIFE_ALIGNMENT",
            "permitted_in_qp061": "conditional",
            "requires_external_data": "true",
            "answer_format": "contingency table",
            "question": "Do native anchor/pressure lanes align with stable or long-lived observed categories?",
        },
        {
            "question_id": "Q4_DECAY_DIRECTION",
            "permitted_in_qp061": "conditional",
            "requires_external_data": "true",
            "answer_format": "direction confusion table",
            "question": "Do native rebalance directions align with observed decay mode classes?",
        },
        {
            "question_id": "Q5_MASS_RESIDUAL",
            "permitted_in_qp061": "conditional",
            "requires_external_data": "true",
            "answer_format": "declared-convention residual table",
            "question": "What are SAM mass residuals after the observed mass convention is declared?",
        },
        {
            "question_id": "F1_NO_POST_HOC_ROW_EDIT",
            "permitted_in_qp061": "false",
            "requires_external_data": "false",
            "answer_format": "not allowed",
            "question": "Can prediction rows, candidate A values, or selector labels be changed after external data import?",
        },
    ]


def build_next_frontier() -> list[dict[str, Any]]:
    return [
        {
            "next_test_id": "QP061",
            "next_test_name": "PRIVATE_APPROVED_SEALED_ISOTOPE_COMPARISON",
            "requires_explicit_preflight": "true",
            "requires_external_data_approval": "true",
            "audit_or_retest": "false",
            "purpose": "Open the vault against an approved isotope roster/mass/decay dataset without modifying sealed predictions.",
            "status": "WAITING_FOR_EXPLICIT_EXTERNAL_DATA_PREFLIGHT",
        }
    ]


def build_hash_manifest(generated_outputs: list[tuple[str, str, Path]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for source_gate, artifact_id, path in SEALED_INPUTS:
        rows.append(
            {
                "seal_role": "SEALED_INPUT",
                "source_gate": source_gate,
                "artifact_id": artifact_id,
                "path": str(path.relative_to(ROOT)).replace("\\", "/"),
                "sha256": sha256_file(path),
            }
        )
    for source_gate, artifact_id, path in generated_outputs:
        rows.append(
            {
                "seal_role": "PROTOCOL_OUTPUT",
                "source_gate": source_gate,
                "artifact_id": artifact_id,
                "path": str(path.relative_to(ROOT)).replace("\\", "/"),
                "sha256": sha256_file(path),
            }
        )
    return rows


def write_doc(summary: dict[str, Any], hash_rows: list[dict[str, Any]]) -> None:
    input_lines = "\n".join(
        f"| {row['source_gate']} | {row['artifact_id']} | `{row['sha256'][:16]}...` | `{row['path']}` |"
        for row in hash_rows
        if row["seal_role"] == "SEALED_INPUT"
    )
    output_lines = "\n".join(
        f"| {row['artifact_id']} | `{row['sha256'][:16]}...` | `{row['path']}` |"
        for row in hash_rows
        if row["seal_role"] == "PROTOCOL_OUTPUT"
    )
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP060 - Private Sealed Comparison Protocol

## Result

```text
{summary['result_class']}
```

## Vault Door

QP060 freezes the private Phase 5 isotope prediction bundle before observed
isotope, mass, decay, half-life, or abundance data enters the workflow.

```text
prediction_manifest_rows = {summary['prediction_manifest_rows']}
source_hash_rows = {summary['source_hash_rows']}
protocol_output_hash_rows = {summary['protocol_output_hash_rows']}
external_data_used = false
observed_isotope_masses_used = false
observed_decay_modes_used = false
observed_half_lives_used = false
free_parameters_introduced = 0
prediction_manifest_sha256 = {summary['prediction_manifest_sha256']}
hash_manifest_sha256 = {summary['hash_manifest_sha256']}
next_frontier = {summary['next_frontier']}
```

## Sealed Inputs

| gate | artifact | sha256 prefix | path |
| --- | --- | --- | --- |
{input_lines}

## Protocol Outputs

| artifact | sha256 prefix | path |
| --- | --- | --- |
{output_lines}

## Comparison Rules

```text
1. QP061 may import external data only after a new explicit preflight.
2. QP061 may not modify QP060 prediction rows, candidate A values, or labels.
3. The first comparison lane is isotope roster presence by symbol and A.
4. Mass residuals are conditional until nuclear/atomic/mass-excess convention is declared.
5. Decay, half-life, and abundance channels are optional approved lanes, not hidden inputs.
6. No parameter refit is allowed after external data enters.
```

## Interpretation

The vault door is now built. The next move is not another internal selector.
The next move is an approved sealed comparison against external isotope data,
using this frozen manifest and hash record as the guardrail.
""",
        encoding="utf-8",
    )


def update_campaign(summary: dict[str, Any]) -> None:
    text = CAMPAIGN.read_text(encoding="utf-8")
    text = text.replace(
        "COMPLETE_PHASE5_VISUAL_PACKAGE_QP059_BUILT",
        "COMPLETE_PHASE5_SEALED_PROTOCOL_QP060_BUILT",
    )
    text = text.replace(
        "next_test = QP060_PRIVATE_SEALED_COMPARISON_PROTOCOL_REQUIRES_EXPLICIT_APPROVAL",
        "next_test = QP061_PRIVATE_APPROVED_SEALED_ISOTOPE_COMPARISON_REQUIRES_EXTERNAL_DATA_PREFLIGHT",
    )
    result_block = f"""### QP060 - Private Sealed Comparison Protocol

Status:

```text
COMPLETE
result_class = {summary['result_class']}
prediction_manifest_rows = {summary['prediction_manifest_rows']}
source_hash_rows = {summary['source_hash_rows']}
protocol_output_hash_rows = {summary['protocol_output_hash_rows']}
external_data_used = false
observed_isotope_masses_used = false
observed_decay_modes_used = false
observed_half_lives_used = false
free_parameters_introduced = 0
prediction_manifest_sha256 = {summary['prediction_manifest_sha256']}
next_frontier = {summary['next_frontier']}
```

Result:

```text
PASS. QP060 builds the sealed comparison protocol and freezes the private
Phase 5 prediction manifest before any external isotope data enters.
```
"""
    marker = "### QP060 - Private Sealed Comparison Protocol"
    if marker not in text:
        text += "\n\n" + result_block
    else:
        before, _ = text.split(marker, 1)
        text = before.rstrip() + "\n\n" + result_block
    CAMPAIGN.write_text(text, encoding="utf-8")


def main() -> None:
    write_preflight()
    generated_at = datetime.now(timezone.utc).isoformat()

    prediction_rows = build_prediction_manifest()
    prediction_fields = [
        "prediction_id",
        "atomic_number",
        "symbol",
        "name",
        "Z_candidate",
        "N_candidate",
        "A_candidate",
        "candidate_notation",
        "ladder_role",
        "ladder_preference",
        "ladder_weight",
        "residual_twelfths",
        "residual_fraction_native",
        "roster_stability_lane",
        "anchor_status",
        "selected_depth_index",
        "selected_neutron_excess_lane",
        "formation_lane",
        "A_band",
        "sam_isotope_mass_candidate_MeV",
        "decay_pressure_lane",
        "native_stability_preference",
        "native_rebalance_direction",
        "native_chain_step",
        "target_Z_after_step",
        "target_N_after_step",
        "target_A_after_step",
        "sealed_source_gates",
        "mass_convention_lock",
        "observed_data_used",
        "comparison_locked_until",
        "selector_status",
    ]

    write_csv(PREDICTION_MANIFEST_OUT, prediction_rows, prediction_fields)
    write_csv(PHASE5_SEALED_PREDICTION_MANIFEST, prediction_rows, prediction_fields)
    write_csv(COMPARISON_SCHEMA_OUT, build_comparison_schema(), ["field_name", "owner", "required_for_qp061", "data_type", "rule"])
    write_csv(SCORING_LANES_OUT, build_scoring_lanes(), ["lane_id", "external_data_required", "score_rule", "qp061_status"])
    write_csv(
        EXTERNAL_TEMPLATE_OUT,
        build_external_template(),
        [
            "dataset_id",
            "source_name",
            "source_url_or_file",
            "retrieval_date_utc",
            "license_or_terms",
            "data_type",
            "mass_convention",
            "includes_observed_masses",
            "includes_decay_modes",
            "includes_half_lives",
            "includes_abundances",
            "columns_used",
            "preprocessing_declared",
            "approved_by",
            "approval_timestamp_utc",
            "sha256",
        ],
    )
    write_csv(ALLOWED_QUESTIONS_OUT, build_allowed_questions(), ["question_id", "permitted_in_qp061", "requires_external_data", "answer_format", "question"])
    write_csv(
        NEXT_FRONTIER_OUT,
        build_next_frontier(),
        ["next_test_id", "next_test_name", "requires_explicit_preflight", "requires_external_data_approval", "audit_or_retest", "purpose", "status"],
    )

    generated_outputs = [
        ("QP060", "prediction_manifest", PREDICTION_MANIFEST_OUT),
        ("QP060", "phase4_prediction_manifest_copy", PHASE5_SEALED_PREDICTION_MANIFEST),
        ("QP060", "comparison_schema", COMPARISON_SCHEMA_OUT),
        ("QP060", "scoring_lanes", SCORING_LANES_OUT),
        ("QP060", "external_data_manifest_template", EXTERNAL_TEMPLATE_OUT),
        ("QP060", "allowed_questions", ALLOWED_QUESTIONS_OUT),
        ("QP060", "next_frontier", NEXT_FRONTIER_OUT),
        ("QP060", "preflight", PREFLIGHT_OUT),
    ]
    hash_rows = build_hash_manifest(generated_outputs)
    write_csv(HASH_MANIFEST_OUT, hash_rows, ["seal_role", "source_gate", "artifact_id", "path", "sha256"])
    write_csv(PHASE5_SEALED_HASH_MANIFEST, hash_rows, ["seal_role", "source_gate", "artifact_id", "path", "sha256"])

    summary = {
        "artifact": "QP060_PRIVATE_SEALED_COMPARISON_PROTOCOL",
        "result_class": "QP060_SEALED_COMPARISON_PROTOCOL_BUILT",
        "campaign_status": "COMPLETE_PHASE5_SEALED_PROTOCOL_QP060_BUILT",
        "generated_at_utc": generated_at,
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_PROTOCOL_BUILD",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "permission_required_before_run": False,
        "public_repo_write": False,
        "external_data_used": False,
        "observed_isotope_masses_used": False,
        "observed_decay_modes_used": False,
        "observed_half_lives_used": False,
        "observed_abundances_used": False,
        "free_parameters_introduced": 0,
        "prediction_manifest_rows": len(prediction_rows),
        "source_hash_rows": len(SEALED_INPUTS),
        "protocol_output_hash_rows": len(generated_outputs),
        "hash_manifest_rows": len(hash_rows),
        "prediction_manifest_sha256": sha256_file(PREDICTION_MANIFEST_OUT),
        "phase4_prediction_manifest_sha256": sha256_file(PHASE5_SEALED_PREDICTION_MANIFEST),
        "hash_manifest_sha256": sha256_file(HASH_MANIFEST_OUT),
        "phase4_hash_manifest_sha256": sha256_file(PHASE5_SEALED_HASH_MANIFEST),
        "next_frontier": "QP061_PRIVATE_APPROVED_SEALED_ISOTOPE_COMPARISON_REQUIRES_EXTERNAL_DATA_PREFLIGHT",
    }

    write_doc(summary, hash_rows)
    write_json(SUMMARY_OUT, summary)
    update_campaign(summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
