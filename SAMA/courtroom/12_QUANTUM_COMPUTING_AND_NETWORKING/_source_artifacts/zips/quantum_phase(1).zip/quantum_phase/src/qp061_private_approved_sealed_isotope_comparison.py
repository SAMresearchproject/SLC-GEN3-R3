from __future__ import annotations

import csv
import hashlib
import io
import json
import math
import urllib.request
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
ARTIFACTS = ROOT / "artifacts"
REPORTS = ROOT / "docs" / "reports"
CAMPAIGNS = ROOT / "docs" / "campaigns"
PHASE4 = ROOT / "phase4_tables"

QP061_DIR = ARTIFACTS / "qp061"
EXTERNAL_DIR = QP061_DIR / "external"
PREFLIGHT_OUT = QP061_DIR / "qp061_preflight.md"
SUMMARY_OUT = QP061_DIR / "qp061_summary.json"
SOURCE_MANIFEST_OUT = QP061_DIR / "qp061_external_source_manifest.csv"
OBSERVED_ROSTER_OUT = QP061_DIR / "qp061_observed_roster_normalized.csv"
ROW_COMPARISON_OUT = QP061_DIR / "qp061_sealed_row_comparison.csv"
ELEMENT_SUMMARY_OUT = QP061_DIR / "qp061_element_coverage_summary.csv"
LANE_SUMMARY_OUT = QP061_DIR / "qp061_lane_summary.csv"
BAND_SUMMARY_OUT = QP061_DIR / "qp061_band_summary.csv"
ANCHOR_PRESSURE_OUT = QP061_DIR / "qp061_anchor_pressure_alignment.csv"
DECAY_DIRECTION_OUT = QP061_DIR / "qp061_decay_direction_alignment.csv"
MASS_RESIDUAL_OUT = QP061_DIR / "qp061_mass_residual_declared_atomic_mass.csv"
NEXT_FRONTIER_OUT = QP061_DIR / "qp061_next_frontier.csv"
DOC_OUT = REPORTS / "QP061_PRIVATE_APPROVED_SEALED_ISOTOPE_COMPARISON.md"
CAMPAIGN = CAMPAIGNS / "SAM_QP049_QP0XX_PHASE5_ISOTOPE_MASS_READOUT_CAMPAIGN.md"

SEALED_PREDICTIONS = PHASE4 / "phase5_sealed_prediction_manifest.csv"
SEALED_HASHES = PHASE4 / "phase5_sealed_hash_manifest.csv"
QP060_SUMMARY = ARTIFACTS / "qp060" / "qp060_summary.json"

IAEA_URL = "https://nds.iaea.org/relnsd/v1/data?fields=ground_states&nuclides=all"
IAEA_LOCAL = EXTERNAL_DIR / "iaea_livechart_ground_states_all_qp061.csv"
USER_AGENT = "Livechart/1.0"

MEV_PER_U = 931.49410242
ELECTRON_MASS_MEV = 0.51099895069
LONG_LIVED_SECONDS = 365.25 * 24 * 3600


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def write_csv(path: Path, rows: list[dict[str, Any]], fields: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            writer.writerow({field: row.get(field, "") for field in fields})


def read_json(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")


def sha256_bytes(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def safe_int(value: str | None) -> int | None:
    if value is None or value == "":
        return None
    try:
        return int(float(value))
    except ValueError:
        return None


def safe_float(value: str | None) -> float | None:
    if value is None or value == "":
        return None
    try:
        number = float(value)
    except ValueError:
        return None
    if math.isnan(number):
        return None
    return number


def write_preflight() -> None:
    QP061_DIR.mkdir(parents=True, exist_ok=True)
    PREFLIGHT_OUT.write_text(
        """# QP061 Preflight - Private Approved Sealed Isotope Comparison

```text
test_id = QP061
test_name = PRIVATE_APPROVED_SEALED_ISOTOPE_COMPARISON
test_type = FORWARD_SEALED_EXTERNAL_COMPARISON
new_forward_work = true
is_audit_or_retest = false
confirmation_or_double_check = false
if_audit_or_retest_reason = NOT_APPLICABLE
permission_required_before_run = false
external_data_permission_gate = satisfied_by_user_ready_message
explicit_user_approval = I'm ready.
public_repo_write = false
external_data_used = true
external_data_source = IAEA_LiveChart_ground_states_all
observed_isotope_masses_used = true
observed_decay_modes_used = true
observed_half_lives_used = true
observed_abundances_used = true
prediction_manifest_mutation_allowed = false
free_parameters_introduced = 0
```

## Source Inputs

```text
phase4_tables/phase5_sealed_prediction_manifest.csv
phase4_tables/phase5_sealed_hash_manifest.csv
artifacts/qp060/qp060_summary.json
https://nds.iaea.org/relnsd/v1/data?fields=ground_states&nuclides=all
```

## Expected Outputs

```text
artifacts/qp061/qp061_external_source_manifest.csv
artifacts/qp061/qp061_observed_roster_normalized.csv
artifacts/qp061/qp061_sealed_row_comparison.csv
artifacts/qp061/qp061_element_coverage_summary.csv
artifacts/qp061/qp061_lane_summary.csv
artifacts/qp061/qp061_band_summary.csv
artifacts/qp061/qp061_summary.json
docs/reports/QP061_PRIVATE_APPROVED_SEALED_ISOTOPE_COMPARISON.md
```

## Forward Question

```text
What happens when the frozen QP060 Phase 5 isotope prediction manifest is opened
against an approved external isotope ground-state catalogue without refit?
```

This is not an audit, retest, or confirmation rerun. It is the first sealed
external comparison. The QP060 prediction manifest is hash-checked and then
treated as immutable.
""",
        encoding="utf-8",
    )


def fetch_iaea_snapshot() -> tuple[bytes, dict[str, Any]]:
    EXTERNAL_DIR.mkdir(parents=True, exist_ok=True)
    request = urllib.request.Request(IAEA_URL, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=60) as response:
        payload = response.read()
        status = getattr(response, "status", "")
        content_type = response.headers.get("Content-Type", "")
    IAEA_LOCAL.write_bytes(payload)
    manifest = {
        "dataset_id": "IAEA_LIVECHART_GROUND_STATES_ALL_QP061",
        "source_name": "IAEA LiveChart of Nuclides ground_states all",
        "source_url_or_file": IAEA_URL,
        "retrieval_date_utc": datetime.now(timezone.utc).isoformat(),
        "license_or_terms": "IAEA LiveChart public API; terms not modified by QP061",
        "http_status": status,
        "content_type": content_type,
        "local_path": str(IAEA_LOCAL.relative_to(ROOT)).replace("\\", "/"),
        "data_type": "isotope_roster|mass|decay|half_life|abundance",
        "mass_convention": "atomic_mass_from_IAEA_LiveChart_converted_u_to_MeV",
        "includes_observed_masses": "true",
        "includes_decay_modes": "true",
        "includes_half_lives": "true",
        "includes_abundances": "true",
        "columns_used": "z|n|symbol|half_life|unit_hl|half_life_sec|decay_1|decay_2|decay_3|abundance|atomic_mass|massexcess|binding|Extraction_date",
        "preprocessing_declared": "ground_state_rows_only_from_fields_ground_states; normalized_A=z+n; filtered_comparison_to_Z_1_118",
        "approved_by": "Sean Brady",
        "approval_timestamp_utc": "user_message_I'm_ready",
        "sha256": sha256_bytes(payload),
    }
    return payload, manifest


def verify_sealed_prediction_hash() -> dict[str, Any]:
    qp060 = read_json(QP060_SUMMARY)
    actual_prediction_hash = sha256_file(SEALED_PREDICTIONS)
    actual_hash_manifest_hash = sha256_file(SEALED_HASHES)
    expected_prediction_hash = qp060["phase4_prediction_manifest_sha256"]
    expected_hash_manifest_hash = qp060["phase4_hash_manifest_sha256"]
    ok = actual_prediction_hash == expected_prediction_hash and actual_hash_manifest_hash == expected_hash_manifest_hash
    return {
        "sealed_prediction_hash_expected": expected_prediction_hash,
        "sealed_prediction_hash_actual": actual_prediction_hash,
        "sealed_hash_manifest_expected": expected_hash_manifest_hash,
        "sealed_hash_manifest_actual": actual_hash_manifest_hash,
        "sealed_hash_guard_pass": ok,
    }


def normalize_observed(payload: bytes) -> list[dict[str, Any]]:
    text = payload.decode("utf-8-sig")
    rows = list(csv.DictReader(io.StringIO(text)))
    normalized: list[dict[str, Any]] = []
    for row in rows:
        z_value = safe_int(row.get("z"))
        n_value = safe_int(row.get("n"))
        symbol = row.get("symbol", "").strip()
        if z_value is None or n_value is None or not symbol:
            continue
        a_value = z_value + n_value
        if not (1 <= z_value <= 118):
            continue
        half_life_sec = safe_float(row.get("half_life_sec"))
        half_life = (row.get("half_life") or "").strip()
        unit_hl = (row.get("unit_hl") or "").strip()
        atomic_mass_u = safe_float(row.get("atomic_mass"))
        atomic_mass_mev = atomic_mass_u * MEV_PER_U if atomic_mass_u is not None else None
        nuclear_mass_mev_approx = atomic_mass_mev - (z_value * ELECTRON_MASS_MEV) if atomic_mass_mev is not None else None
        abundance = safe_float(row.get("abundance"))
        decay_modes = "|".join(
            mode
            for mode in [
                (row.get("decay_1") or "").strip(),
                (row.get("decay_2") or "").strip(),
                (row.get("decay_3") or "").strip(),
            ]
            if mode
        )
        is_stable = half_life.upper() == "STABLE" or unit_hl.upper() == "STABLE" or (decay_modes == "" and half_life_sec is None)
        is_long_lived = is_stable or (half_life_sec is not None and half_life_sec >= LONG_LIVED_SECONDS)
        normalized.append(
            {
                "observed_Z": z_value,
                "observed_N": n_value,
                "observed_A": a_value,
                "observed_symbol": symbol,
                "observed_notation": f"{symbol}-{a_value}",
                "half_life": half_life,
                "unit_hl": unit_hl,
                "half_life_sec": "" if half_life_sec is None else f"{half_life_sec:.12e}",
                "decay_modes": decay_modes,
                "abundance": "" if abundance is None else f"{abundance:.12e}",
                "atomic_mass_u": "" if atomic_mass_u is None else f"{atomic_mass_u:.12e}",
                "observed_atomic_mass_MeV": "" if atomic_mass_mev is None else f"{atomic_mass_mev:.12e}",
                "observed_nuclear_mass_MeV_approx": "" if nuclear_mass_mev_approx is None else f"{nuclear_mass_mev_approx:.12e}",
                "binding": row.get("binding", ""),
                "massexcess": row.get("massexcess", ""),
                "Extraction_date": row.get("Extraction_date", ""),
                "observed_stability_class": "STABLE_OR_LONG_LIVED" if is_long_lived else "RADIOACTIVE_SHORTER_THAN_ONE_YEAR",
                "is_stable_or_long_lived": "true" if is_long_lived else "false",
            }
        )
    return normalized


def pressure_expected_long_lived(pred: dict[str, str]) -> str:
    pressure = pred.get("decay_pressure_lane", "")
    direction = pred.get("native_rebalance_direction", "")
    if pressure in {
        "EXACT_CLOSURE_STABILITY_PRESSURE",
        "DENSE_CONTEXT_LONG_ANCHOR_PRESSURE",
        "HALF_WRITE_BALANCED_STABILITY_PRESSURE",
    }:
        return "true"
    if direction in {
        "NO_REBALANCE_STABLE_ANCHOR",
        "DENSE_CONTEXT_LONG_ANCHOR_HOLD",
        "HALF_WRITE_BIDIRECTIONAL_BALANCE",
    }:
        return "true"
    return "false"


def decay_direction_expected(pred: dict[str, str]) -> str:
    direction = pred.get("native_rebalance_direction", "")
    if direction == "FLOORWARD_NEUTRON_PACKET_REJECTION":
        return "BETA_MINUS_OR_NEUTRON_REJECTION_FAMILY"
    if direction == "CEILWARD_NEUTRON_PACKET_COMPLETION":
        return "BETA_PLUS_EC_OR_NEUTRON_COMPLETION_FAMILY"
    if direction == "RETURN_TO_PREFERRED_NEIGHBOR":
        return "RETURN_TO_NATIVE_NEIGHBOR"
    if direction == "SYNTHETIC_DOWNCHAIN_CASCADE":
        return "ALPHA_OR_FISSION_DOWNCHAIN_FAMILY"
    if direction in {"NO_REBALANCE_STABLE_ANCHOR", "DENSE_CONTEXT_LONG_ANCHOR_HOLD", "HALF_WRITE_BIDIRECTIONAL_BALANCE"}:
        return "STABLE_OR_LONG_LIVED_HOLD"
    return "UNMAPPED_NATIVE_DIRECTION"


def observed_decay_family(obs: dict[str, Any] | None) -> str:
    if not obs:
        return "NO_OBSERVED_ROW"
    if obs["is_stable_or_long_lived"] == "true":
        return "STABLE_OR_LONG_LIVED_HOLD"
    modes = str(obs.get("decay_modes", ""))
    if "B-" in modes:
        return "BETA_MINUS_OR_NEUTRON_REJECTION_FAMILY"
    if "B+" in modes or "EC" in modes:
        return "BETA_PLUS_EC_OR_NEUTRON_COMPLETION_FAMILY"
    if "A" in modes or "SF" in modes:
        return "ALPHA_OR_FISSION_DOWNCHAIN_FAMILY"
    return "OTHER_OR_UNDECLARED_DECAY_FAMILY"


def compare_predictions(predictions: list[dict[str, str]], observed_rows: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]]]:
    observed_by_key = {
        (str(row["observed_Z"]), str(row["observed_N"]), str(row["observed_A"]), row["observed_symbol"]): row
        for row in observed_rows
    }
    observed_by_symbol_a = defaultdict(list)
    for row in observed_rows:
        observed_by_symbol_a[(row["observed_symbol"], str(row["observed_A"]))].append(row)

    row_results: list[dict[str, Any]] = []
    mass_rows: list[dict[str, Any]] = []
    anchor_rows: list[dict[str, Any]] = []
    decay_rows: list[dict[str, Any]] = []
    element_rollup: dict[str, dict[str, Any]] = {}

    for pred in predictions:
        exact_key = (pred["Z_candidate"], pred["N_candidate"], pred["A_candidate"], pred["symbol"])
        obs = observed_by_key.get(exact_key)
        symbol_a_matches = observed_by_symbol_a.get((pred["symbol"], pred["A_candidate"]), [])
        exact_match = obs is not None
        symbol_a_match = bool(symbol_a_matches)
        if obs is None and symbol_a_matches:
            obs = symbol_a_matches[0]

        expected_long = pressure_expected_long_lived(pred)
        observed_long = obs["is_stable_or_long_lived"] if obs else "missing"
        pressure_alignment = (
            "MATCH"
            if obs and expected_long == observed_long
            else "MISMATCH"
            if obs
            else "NO_OBSERVED_ROW"
        )
        expected_decay = decay_direction_expected(pred)
        observed_decay = observed_decay_family(obs)
        decay_alignment = "MATCH" if obs and expected_decay == observed_decay else "MISMATCH" if obs else "NO_OBSERVED_ROW"

        predicted_mass = safe_float(pred.get("sam_isotope_mass_candidate_MeV"))
        observed_nuclear_mass = safe_float(obs.get("observed_nuclear_mass_MeV_approx")) if obs else None
        mass_delta = predicted_mass - observed_nuclear_mass if predicted_mass is not None and observed_nuclear_mass is not None else None

        result = {
            "prediction_id": pred["prediction_id"],
            "candidate_notation": pred["candidate_notation"],
            "atomic_number": pred["atomic_number"],
            "symbol": pred["symbol"],
            "Z_candidate": pred["Z_candidate"],
            "N_candidate": pred["N_candidate"],
            "A_candidate": pred["A_candidate"],
            "ladder_role": pred["ladder_role"],
            "ladder_preference": pred["ladder_preference"],
            "residual_fraction_native": pred["residual_fraction_native"],
            "decay_pressure_lane": pred["decay_pressure_lane"],
            "native_rebalance_direction": pred["native_rebalance_direction"],
            "exact_ZNA_match": "true" if exact_match else "false",
            "symbol_A_match": "true" if symbol_a_match else "false",
            "observed_notation": obs["observed_notation"] if obs else "",
            "observed_half_life_sec": obs["half_life_sec"] if obs else "",
            "observed_decay_modes": obs["decay_modes"] if obs else "",
            "observed_stability_class": obs["observed_stability_class"] if obs else "",
            "expected_stable_or_long_lived": expected_long,
            "pressure_alignment": pressure_alignment,
            "expected_decay_family": expected_decay,
            "observed_decay_family": observed_decay,
            "decay_alignment": decay_alignment,
            "sam_mass_MeV": pred["sam_isotope_mass_candidate_MeV"],
            "observed_nuclear_mass_MeV_approx": obs["observed_nuclear_mass_MeV_approx"] if obs else "",
            "mass_delta_MeV_declared_approx": "" if mass_delta is None else f"{mass_delta:.12e}",
            "comparison_status": "MATCHED_OBSERVED_ROSTER" if exact_match else "SYMBOL_A_ONLY_MATCH" if symbol_a_match else "NOT_IN_OBSERVED_ROSTER",
        }
        row_results.append(result)

        if obs:
            anchor_rows.append(
                {
                    "prediction_id": pred["prediction_id"],
                    "candidate_notation": pred["candidate_notation"],
                    "expected_stable_or_long_lived": expected_long,
                    "observed_stability_class": obs["observed_stability_class"],
                    "pressure_alignment": pressure_alignment,
                    "decay_pressure_lane": pred["decay_pressure_lane"],
                    "native_rebalance_direction": pred["native_rebalance_direction"],
                }
            )
            decay_rows.append(
                {
                    "prediction_id": pred["prediction_id"],
                    "candidate_notation": pred["candidate_notation"],
                    "expected_decay_family": expected_decay,
                    "observed_decay_family": observed_decay,
                    "observed_decay_modes": obs["decay_modes"],
                    "decay_alignment": decay_alignment,
                    "native_rebalance_direction": pred["native_rebalance_direction"],
                }
            )
            mass_rows.append(
                {
                    "prediction_id": pred["prediction_id"],
                    "candidate_notation": pred["candidate_notation"],
                    "sam_mass_MeV": pred["sam_isotope_mass_candidate_MeV"],
                    "observed_atomic_mass_MeV": obs["observed_atomic_mass_MeV"],
                    "observed_nuclear_mass_MeV_approx": obs["observed_nuclear_mass_MeV_approx"],
                    "mass_delta_MeV_declared_approx": "" if mass_delta is None else f"{mass_delta:.12e}",
                    "mass_convention_note": "IAEA atomic_mass converted u->MeV, approximate nuclear mass subtracts Z electron masses; binding/electron details not refit",
                }
            )

        element_key = pred["symbol"]
        element = element_rollup.setdefault(
            element_key,
            {
                "atomic_number": pred["atomic_number"],
                "symbol": pred["symbol"],
                "prediction_rows": 0,
                "exact_ZNA_matches": 0,
                "symbol_A_matches": 0,
                "primary_rows": 0,
                "primary_exact_matches": 0,
                "neighbor_rows": 0,
                "neighbor_exact_matches": 0,
            },
        )
        element["prediction_rows"] += 1
        element["exact_ZNA_matches"] += 1 if exact_match else 0
        element["symbol_A_matches"] += 1 if symbol_a_match else 0
        if pred["ladder_role"] == "FLOOR_PRIMARY":
            element["primary_rows"] += 1
            element["primary_exact_matches"] += 1 if exact_match else 0
        else:
            element["neighbor_rows"] += 1
            element["neighbor_exact_matches"] += 1 if exact_match else 0

    element_rows = list(element_rollup.values())
    for row in element_rows:
        row["element_any_exact_match"] = "true" if row["exact_ZNA_matches"] > 0 else "false"
        row["element_any_symbol_A_match"] = "true" if row["symbol_A_matches"] > 0 else "false"
    return row_results, element_rows, anchor_rows, decay_rows, mass_rows


def summarize(
    row_results: list[dict[str, Any]],
    element_rows: list[dict[str, Any]],
    observed_rows: list[dict[str, Any]],
    source_manifest: dict[str, Any],
    hash_guard: dict[str, Any],
) -> tuple[dict[str, Any], list[dict[str, Any]], list[dict[str, Any]]]:
    total_rows = len(row_results)
    exact = sum(1 for row in row_results if row["exact_ZNA_match"] == "true")
    symbol_a = sum(1 for row in row_results if row["symbol_A_match"] == "true")
    primary_rows = [row for row in row_results if row["ladder_role"] == "FLOOR_PRIMARY"]
    neighbor_rows = [row for row in row_results if row["ladder_role"] != "FLOOR_PRIMARY"]
    primary_exact = sum(1 for row in primary_rows if row["exact_ZNA_match"] == "true")
    neighbor_exact = sum(1 for row in neighbor_rows if row["exact_ZNA_match"] == "true")
    elements_any = sum(1 for row in element_rows if row["element_any_exact_match"] == "true")
    pressure_counts = Counter(row["pressure_alignment"] for row in row_results)
    decay_counts = Counter(row["decay_alignment"] for row in row_results)
    lane_counts = Counter((row["ladder_role"], row["comparison_status"]) for row in row_results)

    lane_rows = [
        {
            "lane_id": f"{role}__{status}",
            "ladder_role": role,
            "comparison_status": status,
            "count": count,
        }
        for (role, status), count in sorted(lane_counts.items())
    ]
    lane_rows.extend(
        [
            {"lane_id": f"pressure_alignment__{key}", "ladder_role": "", "comparison_status": key, "count": value}
            for key, value in sorted(pressure_counts.items())
        ]
    )
    lane_rows.extend(
        [
            {"lane_id": f"decay_alignment__{key}", "ladder_role": "", "comparison_status": key, "count": value}
            for key, value in sorted(decay_counts.items())
        ]
    )

    band_rows = build_band_summary(row_results)
    z_1_96 = next(row for row in band_rows if row["band_id"] == "Z_001_096")
    z_97_118 = next(row for row in band_rows if row["band_id"] == "Z_097_118")

    summary = {
        "artifact": "QP061_PRIVATE_APPROVED_SEALED_ISOTOPE_COMPARISON",
        "result_class": "QP061_SEALED_ISOTOPE_COMPARISON_COMPLETED",
        "campaign_status": "COMPLETE_PHASE5_SEALED_COMPARISON_QP061_RUN",
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_scope": "PRIVATE_QUANTUM_PHASE_REPO_ONLY",
        "test_type": "FORWARD_SEALED_EXTERNAL_COMPARISON",
        "new_forward_work": True,
        "is_audit_or_retest": False,
        "confirmation_or_double_check": False,
        "external_data_used": True,
        "external_data_source": source_manifest["source_name"],
        "external_data_url": source_manifest["source_url_or_file"],
        "external_data_sha256": source_manifest["sha256"],
        "observed_ground_state_rows_normalized": len(observed_rows),
        "observed_isotope_masses_used": True,
        "observed_decay_modes_used": True,
        "observed_half_lives_used": True,
        "observed_abundances_used": True,
        "prediction_manifest_mutated": False,
        "free_parameters_introduced": 0,
        "sealed_hash_guard_pass": hash_guard["sealed_hash_guard_pass"],
        "sealed_prediction_hash_actual": hash_guard["sealed_prediction_hash_actual"],
        "sealed_prediction_rows": total_rows,
        "exact_ZNA_matches": exact,
        "exact_ZNA_match_rate": exact / total_rows if total_rows else 0,
        "symbol_A_matches": symbol_a,
        "symbol_A_match_rate": symbol_a / total_rows if total_rows else 0,
        "primary_rows": len(primary_rows),
        "primary_exact_matches": primary_exact,
        "primary_exact_match_rate": primary_exact / len(primary_rows) if primary_rows else 0,
        "neighbor_rows": len(neighbor_rows),
        "neighbor_exact_matches": neighbor_exact,
        "neighbor_exact_match_rate": neighbor_exact / len(neighbor_rows) if neighbor_rows else 0,
        "elements_with_any_exact_match": elements_any,
        "element_exact_coverage_rate": elements_any / len(element_rows) if element_rows else 0,
        "pressure_alignment_counts": dict(pressure_counts),
        "decay_alignment_counts": dict(decay_counts),
        "band_Z_1_96_rows": z_1_96["sealed_rows"],
        "band_Z_1_96_exact_matches": z_1_96["exact_ZNA_matches"],
        "band_Z_1_96_exact_match_rate": z_1_96["exact_match_rate"],
        "band_Z_97_118_rows": z_97_118["sealed_rows"],
        "band_Z_97_118_exact_matches": z_97_118["exact_ZNA_matches"],
        "band_Z_97_118_exact_match_rate": z_97_118["exact_match_rate"],
        "source_manifest_path": str(SOURCE_MANIFEST_OUT.relative_to(ROOT)).replace("\\", "/"),
        "next_frontier": "QP062_PRIVATE_SEALED_MISS_AND_STRUCTURE_READOUT",
    }
    return summary, lane_rows, band_rows


def build_band_summary(row_results: list[dict[str, Any]]) -> list[dict[str, Any]]:
    bands = [
        ("Z_001_082", 1, 82, "lead-and-below band"),
        ("Z_083_096", 83, 96, "actinide-contact band through curium"),
        ("Z_001_096", 1, 96, "all sealed rows through curium"),
        ("Z_097_118", 97, 118, "transcurium/superheavy open tail"),
        ("Z_001_118", 1, 118, "full sealed Phase 5 row set"),
    ]
    rows: list[dict[str, Any]] = []
    for band_id, z_min, z_max, note in bands:
        subset = [row for row in row_results if z_min <= int(row["atomic_number"]) <= z_max]
        exact = sum(1 for row in subset if row["exact_ZNA_match"] == "true")
        primary = [row for row in subset if row["ladder_role"] == "FLOOR_PRIMARY"]
        primary_exact = sum(1 for row in primary if row["exact_ZNA_match"] == "true")
        neighbor = [row for row in subset if row["ladder_role"] != "FLOOR_PRIMARY"]
        neighbor_exact = sum(1 for row in neighbor if row["exact_ZNA_match"] == "true")
        rows.append(
            {
                "band_id": band_id,
                "z_min": z_min,
                "z_max": z_max,
                "sealed_rows": len(subset),
                "exact_ZNA_matches": exact,
                "exact_match_rate": exact / len(subset) if subset else 0,
                "primary_rows": len(primary),
                "primary_exact_matches": primary_exact,
                "primary_exact_match_rate": primary_exact / len(primary) if primary else 0,
                "neighbor_rows": len(neighbor),
                "neighbor_exact_matches": neighbor_exact,
                "neighbor_exact_match_rate": neighbor_exact / len(neighbor) if neighbor else 0,
                "readout_note": note,
            }
        )
    return rows


def write_doc(summary: dict[str, Any], source_manifest: dict[str, Any]) -> None:
    DOC_OUT.parent.mkdir(parents=True, exist_ok=True)
    DOC_OUT.write_text(
        f"""# QP061 - Private Approved Sealed Isotope Comparison

## Result

```text
{summary['result_class']}
```

## External Source

```text
source = {source_manifest['source_name']}
url = {source_manifest['source_url_or_file']}
sha256 = {source_manifest['sha256']}
retrieved_utc = {source_manifest['retrieval_date_utc']}
normalized_rows = {summary['observed_ground_state_rows_normalized']}
```

## Sealed Guard

```text
sealed_hash_guard_pass = {str(summary['sealed_hash_guard_pass']).lower()}
prediction_manifest_mutated = false
free_parameters_introduced = 0
sealed_prediction_hash_actual = {summary['sealed_prediction_hash_actual']}
```

## Roster Match

```text
sealed_prediction_rows = {summary['sealed_prediction_rows']}
exact_ZNA_matches = {summary['exact_ZNA_matches']}
exact_ZNA_match_rate = {summary['exact_ZNA_match_rate']:.6f}
symbol_A_matches = {summary['symbol_A_matches']}
symbol_A_match_rate = {summary['symbol_A_match_rate']:.6f}
primary_rows = {summary['primary_rows']}
primary_exact_matches = {summary['primary_exact_matches']}
primary_exact_match_rate = {summary['primary_exact_match_rate']:.6f}
neighbor_rows = {summary['neighbor_rows']}
neighbor_exact_matches = {summary['neighbor_exact_matches']}
neighbor_exact_match_rate = {summary['neighbor_exact_match_rate']:.6f}
elements_with_any_exact_match = {summary['elements_with_any_exact_match']}
element_exact_coverage_rate = {summary['element_exact_coverage_rate']:.6f}
```

## Banded Readout

```text
Z_001_096_rows = {summary['band_Z_1_96_rows']}
Z_001_096_exact_matches = {summary['band_Z_1_96_exact_matches']}
Z_001_096_exact_match_rate = {summary['band_Z_1_96_exact_match_rate']:.6f}
Z_097_118_rows = {summary['band_Z_97_118_rows']}
Z_097_118_exact_matches = {summary['band_Z_97_118_exact_matches']}
Z_097_118_exact_match_rate = {summary['band_Z_97_118_exact_match_rate']:.6f}
```

## Pressure And Decay Readout

```text
pressure_alignment_counts = {summary['pressure_alignment_counts']}
decay_alignment_counts = {summary['decay_alignment_counts']}
```

## Interpretation

QP061 opens the vault against IAEA LiveChart ground-state data. The sealed
prediction manifest remains unchanged. The first scoring lane is exact Z/N/A
roster presence; pressure, decay, and mass residual readouts are recorded as
declared comparison lanes, not as refits.

The result is now empirical contact. Hits and misses both stay downstream of
the frozen QP060 manifest.
""",
        encoding="utf-8",
    )


def update_campaign(summary: dict[str, Any]) -> None:
    text = CAMPAIGN.read_text(encoding="utf-8")
    text = text.replace(
        "COMPLETE_PHASE5_SEALED_PROTOCOL_QP060_BUILT",
        "COMPLETE_PHASE5_SEALED_COMPARISON_QP061_RUN",
    )
    text = text.replace(
        "next_test = QP061_PRIVATE_APPROVED_SEALED_ISOTOPE_COMPARISON_REQUIRES_EXTERNAL_DATA_PREFLIGHT",
        "next_test = QP062_PRIVATE_SEALED_MISS_AND_STRUCTURE_READOUT",
    )
    result_block = f"""### QP061 - Private Approved Sealed Isotope Comparison

Status:

```text
COMPLETE
result_class = {summary['result_class']}
external_data_source = {summary['external_data_source']}
observed_ground_state_rows_normalized = {summary['observed_ground_state_rows_normalized']}
sealed_hash_guard_pass = {str(summary['sealed_hash_guard_pass']).lower()}
sealed_prediction_rows = {summary['sealed_prediction_rows']}
exact_ZNA_matches = {summary['exact_ZNA_matches']}
exact_ZNA_match_rate = {summary['exact_ZNA_match_rate']:.6f}
Z_001_096_exact_match_rate = {summary['band_Z_1_96_exact_match_rate']:.6f}
Z_097_118_exact_match_rate = {summary['band_Z_97_118_exact_match_rate']:.6f}
primary_exact_matches = {summary['primary_exact_matches']}
primary_exact_match_rate = {summary['primary_exact_match_rate']:.6f}
neighbor_exact_matches = {summary['neighbor_exact_matches']}
neighbor_exact_match_rate = {summary['neighbor_exact_match_rate']:.6f}
elements_with_any_exact_match = {summary['elements_with_any_exact_match']}
element_exact_coverage_rate = {summary['element_exact_coverage_rate']:.6f}
prediction_manifest_mutated = false
free_parameters_introduced = 0
next_frontier = {summary['next_frontier']}
```

Result:

```text
PASS. QP061 opens the frozen Phase 5 vault against IAEA LiveChart ground-state
isotope data without modifying the sealed prediction manifest.
```
"""
    marker = "### QP061 - Private Approved Sealed Isotope Comparison"
    if marker not in text:
        text += "\n\n" + result_block
    else:
        before, _ = text.split(marker, 1)
        text = before.rstrip() + "\n\n" + result_block
    CAMPAIGN.write_text(text, encoding="utf-8")


def main() -> None:
    write_preflight()
    hash_guard = verify_sealed_prediction_hash()
    if not hash_guard["sealed_hash_guard_pass"]:
        raise RuntimeError("QP060 sealed prediction/hash manifest guard failed; refusing QP061 external comparison.")

    payload, source_manifest = fetch_iaea_snapshot()
    observed_rows = normalize_observed(payload)
    predictions = read_csv(SEALED_PREDICTIONS)
    row_results, element_rows, anchor_rows, decay_rows, mass_rows = compare_predictions(predictions, observed_rows)
    summary, lane_rows, band_rows = summarize(row_results, element_rows, observed_rows, source_manifest, hash_guard)

    write_csv(SOURCE_MANIFEST_OUT, [source_manifest], list(source_manifest.keys()))
    write_csv(
        OBSERVED_ROSTER_OUT,
        observed_rows,
        [
            "observed_Z",
            "observed_N",
            "observed_A",
            "observed_symbol",
            "observed_notation",
            "half_life",
            "unit_hl",
            "half_life_sec",
            "decay_modes",
            "abundance",
            "atomic_mass_u",
            "observed_atomic_mass_MeV",
            "observed_nuclear_mass_MeV_approx",
            "binding",
            "massexcess",
            "Extraction_date",
            "observed_stability_class",
            "is_stable_or_long_lived",
        ],
    )
    write_csv(
        ROW_COMPARISON_OUT,
        row_results,
        [
            "prediction_id",
            "candidate_notation",
            "atomic_number",
            "symbol",
            "Z_candidate",
            "N_candidate",
            "A_candidate",
            "ladder_role",
            "ladder_preference",
            "residual_fraction_native",
            "decay_pressure_lane",
            "native_rebalance_direction",
            "exact_ZNA_match",
            "symbol_A_match",
            "observed_notation",
            "observed_half_life_sec",
            "observed_decay_modes",
            "observed_stability_class",
            "expected_stable_or_long_lived",
            "pressure_alignment",
            "expected_decay_family",
            "observed_decay_family",
            "decay_alignment",
            "sam_mass_MeV",
            "observed_nuclear_mass_MeV_approx",
            "mass_delta_MeV_declared_approx",
            "comparison_status",
        ],
    )
    write_csv(
        ELEMENT_SUMMARY_OUT,
        element_rows,
        [
            "atomic_number",
            "symbol",
            "prediction_rows",
            "exact_ZNA_matches",
            "symbol_A_matches",
            "primary_rows",
            "primary_exact_matches",
            "neighbor_rows",
            "neighbor_exact_matches",
            "element_any_exact_match",
            "element_any_symbol_A_match",
        ],
    )
    write_csv(LANE_SUMMARY_OUT, lane_rows, ["lane_id", "ladder_role", "comparison_status", "count"])
    write_csv(
        BAND_SUMMARY_OUT,
        band_rows,
        [
            "band_id",
            "z_min",
            "z_max",
            "sealed_rows",
            "exact_ZNA_matches",
            "exact_match_rate",
            "primary_rows",
            "primary_exact_matches",
            "primary_exact_match_rate",
            "neighbor_rows",
            "neighbor_exact_matches",
            "neighbor_exact_match_rate",
            "readout_note",
        ],
    )
    write_csv(
        ANCHOR_PRESSURE_OUT,
        anchor_rows,
        ["prediction_id", "candidate_notation", "expected_stable_or_long_lived", "observed_stability_class", "pressure_alignment", "decay_pressure_lane", "native_rebalance_direction"],
    )
    write_csv(
        DECAY_DIRECTION_OUT,
        decay_rows,
        ["prediction_id", "candidate_notation", "expected_decay_family", "observed_decay_family", "observed_decay_modes", "decay_alignment", "native_rebalance_direction"],
    )
    write_csv(
        MASS_RESIDUAL_OUT,
        mass_rows,
        ["prediction_id", "candidate_notation", "sam_mass_MeV", "observed_atomic_mass_MeV", "observed_nuclear_mass_MeV_approx", "mass_delta_MeV_declared_approx", "mass_convention_note"],
    )
    write_csv(
        NEXT_FRONTIER_OUT,
        [
            {
                "next_test_id": "QP062",
                "next_test_name": "PRIVATE_SEALED_MISS_AND_STRUCTURE_READOUT",
                "requires_explicit_preflight": "true",
                "audit_or_retest": "false",
                "purpose": "Read the QP061 hit/miss structure and identify the next native selector pressure without changing QP060 predictions.",
                "status": "READY",
            }
        ],
        ["next_test_id", "next_test_name", "requires_explicit_preflight", "audit_or_retest", "purpose", "status"],
    )
    write_doc(summary, source_manifest)
    write_json(SUMMARY_OUT, summary)
    update_campaign(summary)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
