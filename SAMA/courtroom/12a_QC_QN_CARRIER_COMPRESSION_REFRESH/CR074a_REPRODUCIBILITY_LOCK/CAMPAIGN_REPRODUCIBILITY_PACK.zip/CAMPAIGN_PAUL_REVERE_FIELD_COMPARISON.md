# CAMPAIGN: Paul Revere Field Comparison

**Copyright (c) 2026 Sean Brady. ALL RIGHTS RESERVED.**

## Status

```text
DRAFT - NOT YET RUN
CR070a through CR075a proposed. Per-CR PRECOMMITs, runners,
declared_premises, input manifests, and result.md files not yet
written. User review requested before test execution begins.
```

## Campaign Goal

Extend branch 12a forward from CR069a's empirical T2 contact table to
produce a reproducible, presentable Paul Revere field comparison
system that:

1. Expands the NV-diamond T2 contact surface with deeper literature
   pass (CR069a's 8 rows -> CR070a's 20-30 rows), all tagged
   PROVISIONAL_AUTHOR_BEST_EFFORT pending partner-lab verification.
2. Defines the photonic-platform analog of the PR letter framework
   (photon loss / drift / entanglement fidelity equivalents of
   A_leak, A_side, A_share, T2) and onboards photonic candidates
   from the QN010 alignment work (Qunnect/Cisco metro photonic
   entanglement swap as the strongest current alignment).
3. Populates a photonic empirical contact table from published
   literature, PROVISIONAL tagged, same discipline as CR069a.
4. Tests whether the PR letter scaling holds across NV-diamond and
   photonic rows when measured on the same predictor.
5. Locks the runner chain, dependency manifest, and snapshot hashes
   so a partner lab or independent reviewer can rerun every CR
   end-to-end.
6. Produces a single-document presentation bundle that walks a
   partner-lab or potential supporter through the campaign result
   in under one working day.

## Why This Campaign Now

The Paul Revere stack reached a structural plateau:

- CR067a/CR067b ran the NV-diamond simulator (room-temp + cryo DD)
- CR068a sealed the warning-only PR alarm (8/8 predictions PASS)
- CR069a populated 8 empirical T2 rows from literature (7/8
  predictions PASS, 5/6 wrong controls PASS, 1 honestly-reported
  T2_grav floor violation, all rows tagged PROVISIONAL)

To move forward, the field comparison surface needs to (a) get wider
across platforms and (b) become reproducible enough that an external
reviewer can pick it up. This campaign closes those two gaps without
claiming hardware demonstration, partner-lab agreement, or a
commercial protocol.

## Framing per STEWARDSHIP.md

Per `STEWARDSHIP.md`, any commercial value flowing from SAM and its
derivatives should help homeless shelters, addiction recovery,
charitable medical, education, and community charities. This
campaign produces an artifact bundle that is *presentable to those
who could fund the work to continue*, not "investment-grade physics."
The system is reproducible and honest; the discipline is the
contribution.

## Out of Scope

```text
- hardware demonstration (no apparatus run by any CR)
- partner-lab agreement claim (citations remain PROVISIONAL until
  partner-lab verifies; this campaign does not negotiate that
  verification)
- commercial protocol claim (no contract, no customer, no
  deployment)
- partnership claim with Qunnect, Cisco, PsiQuantum, or any platform
  vendor
- trapped-ion or superconducting platform comparison (deferred to a
  future campaign; user direction: "we can come back to the others
  later")
- a claim that SAM has proven anything from first principles in this
  campaign (the theorem-style derivation work lives in branch 09
  CR062, branch 09a, and QP091T; this campaign tests whether the PR
  letter compares well to real data, not whether the underlying
  framework derives the data)
- a claim that any single PR letter prediction is verified (all
  external data is tagged PROVISIONAL_AUTHOR_BEST_EFFORT; partner-
  lab verification lifts PROVISIONAL to VERIFIED, and that is a
  later campaign's deliverable)
```

## Allowed Inputs (Campaign-Wide)

```text
12a/CR060a-CR069a    (all sealed branch-12a CRs to date)
12/CR050-CR059       (sealed branch-12 CRs; protocol/scoring stack)
quantum_phase/QN010  candidate_alignment_summary.csv
                     (used only for photonic candidate identification)
quantum_phase/QN014  source_pressure_pr_closed_loop_cases.csv
                     (used only for simulator sample windows)
quantum_phase/QN015  diamond_topology + budget tables
                     (used only for diamond topology and SOB split
                     reference; not for any new derivation)
external literature  published T2 / coherence / entanglement
                     fidelity values for NV-diamond and photonic
                     platforms, each tagged with citation and
                     PROVISIONAL_AUTHOR_BEST_EFFORT status
```

No new external source intake beyond published literature with
PROVISIONAL tags. No new derivation imports beyond what is already
sealed in 12a/12/09/09a/15. All inputs frozen at campaign start.

## Free Parameters

```text
free_parameters_introduced_by_campaign = 0
```

The campaign enforces the same zero-free-parameter discipline as
CR060a-CR069a. Every CR reports free_parameters_used = 0; any CR
that requires a free parameter is a CR that fails the campaign.

## No-Peek Discipline (PROVISIONAL Tag)

Per user direction, the campaign uses CR069a's PROVISIONAL tag
discipline rather than a hash-freeze-before-load rule:

```text
- Predictions and wrong controls are written in each CR PRECOMMIT
  before external data is loaded.
- External literature values are loaded with PROVISIONAL_AUTHOR_BEST_EFFORT
  tags, identical to CR069a's pattern.
- Partner-lab verification lifts a citation to VERIFIED; that step
  is OUT OF SCOPE for this campaign.
- Honest failure reporting is mandatory: result_class strings
  publish the X-of-Y outcome counts (e.g., PREDICTIONS_7_OF_8,
  WRONG_CONTROLS_5_OF_6), matching CR069a's pattern.
```

This is "don't peek too much" in practice: predictions are written
first, data is loaded with citation tags, and failures are reported
in the result string rather than buried.

## The Six CRs

### CR070a - Expanded NV-Diamond T2 Contact Table

**Question:** Can the CR069a 8-row T2 contact table be expanded to
20-30 rows from a deeper literature pass without breaking the
T2_grav v1.1 consistency claim or introducing new free parameters?

**Allowed inputs:** CR064a v1.1 (T2_grav floor formula),
CR068a (warning-only simulator), CR069a (initial 8-row table),
additional published NV-diamond T2 literature with citations.

**Expected pass meaning:** PASS means the expanded table:

```text
- has 20-30 rows from peer-reviewed or pre-print published NV-diamond T2 measurements
- every row carries citation metadata and PROVISIONAL_AUTHOR_BEST_EFFORT tag
- T2_grav v1.1 floor classification (CONSISTENT / BOUNDARY / VIOLATION) is computed per row
- aggregate classification distribution matches CR069a's pattern (majority CONSISTENT, isolated boundary/violation rows reported honestly)
- no free parameters introduced
- runner imports CR064a v1.1 and CR069a runners; does not modify either
```

**Rule-9 falsifier:** Fails if any of:
(a) fewer than 15 rows successfully populated;
(b) any free parameter introduced;
(c) the runner modifies CR064a or CR069a;
(d) a published value is loaded without a citation;
(e) the T2_grav v1.1 consistency rate drops below 50% (would signal
a serious mismatch worth its own CR).

**Reported X-of-Y outcomes:** predictions and wrong controls
reported as N-of-M in the result_class.

### CR071a - Photonic PR Letter Framework Mapping

**Question:** Can the NV-diamond PR letter framework (A_leak,
A_side, A_share, T2, alarm fire time) be mapped to photonic platform
observables (photon loss, polarization drift, entanglement fidelity
decay) without introducing new free parameters?

**Allowed inputs:** CR060a (PR letter alphabet lock), CR065a (PR
implementation spec), CR068a (warning-only V1), QN010 photonic
candidate (Qunnect/Cisco metro photonic) descriptor, published
photonic-platform protocol terminology.

**Expected pass meaning:** PASS means the mapping:

```text
- defines photonic A_leak (e.g., photon-loss + drift accumulated)
- defines photonic A_side (e.g., entanglement-fidelity warning threshold)
- defines photonic A_share (e.g., entanglement-fidelity basin-commit boundary)
- defines photonic T2-equivalent (e.g., entanglement coherence time tau_ent)
- defines photonic alarm fire time t_fire equivalent
- introduces no new free parameters (mapping uses CR060a alphabet ratios only)
- emits a mapping table (NV-diamond observable -> photonic observable)
- emits a falsifier list: what a photonic measurement would need to show for the mapping to fail
```

**Rule-9 falsifier:** Fails if any of:
(a) the mapping introduces a free parameter (e.g., a tunable
threshold not derivable from CR060a's alphabet);
(b) the mapping requires a photonic observable that is not publicly
documented for at least one platform vendor;
(c) the falsifier list is empty or vague;
(d) the mapping has internal ambiguity (more than one consistent
photonic-side assignment for the same NV-diamond observable).

### CR072a - Photonic Empirical Contact Table

**Question:** Can a photonic empirical contact table be populated
from published literature using the CR071a mapping, with all rows
tagged PROVISIONAL and consistency classified against the framework
analog of the T2_grav floor?

**Allowed inputs:** CR071a mapping table, published photonic
literature (entanglement fidelity, loss rates, drift, coherence
times for Qunnect/Cisco, PsiQuantum, Xanadu, NIST photonic
candidates), CR069a as the discipline template.

**Expected pass meaning:** PASS means the table:

```text
- has 10-20 rows from published photonic measurements
- every row carries citation metadata and PROVISIONAL_AUTHOR_BEST_EFFORT tag
- consistency classification (CONSISTENT / BOUNDARY / VIOLATION) computed per row using the CR071a-mapped framework floor
- aggregate classification reported honestly (failures included in the result_class)
- no free parameters introduced
- runner imports CR071a; does not modify it
```

**Rule-9 falsifier:** Fails if any of:
(a) fewer than 8 rows successfully populated;
(b) any free parameter introduced;
(c) a published value loaded without a citation;
(d) the CR071a mapping requires modification mid-CR;
(e) the classification logic is not the same shape as CR069a's
(would signal an unjustified discipline drift).

### CR073a - Cross-Platform PR Letter Scaling Test

**Question:** Does the Paul Revere alarm fire time t_fire scale with
the framework's predictor in the same way across NV-diamond rows
(from CR070a) and photonic rows (from CR072a)?

This is one decisive yes/no on cross-platform generalization. An NV
sanity check (does t_fire scaling still hold on the CR070a expanded
NV table alone) is folded into this CR's preamble, NOT split into a
separate CR. The actual question is cross-platform generalization,
not "twice the same NV result."

**Allowed inputs:** CR070a expanded NV table, CR072a photonic
table, CR068a warning-only V1 (for the t_fire prediction formula).

**Pre-Committed Falsifiability Block**

Three layers, pre-committed before any CR073a data loads. The
load-bearing threshold and the absolute failure floor both gate the
pass/fail. The precision indicator is informational only.

```text
LOAD-BEARING THRESHOLD (pass/fail gate)
  >= 8 of <= 12 photonic rows must satisfy
  |t_fire_predicted - t_fire_observed| / t_fire_observed <= 0.25
  against the same predictor that passes on the CR070a NV rows.

ABSOLUTE FAILURE FLOOR
  < 4 of <= 12 photonic rows within 0.25 tolerance
  means the cross-platform claim is structurally dead, not
  refinement-needed. Result class:
    CR073a_PAUL_REVERE_DOES_NOT_GENERALIZE_TO_PHOTONIC_STRUCTURAL_FLOOR

PRECISION INDICATOR (informational, not gating)
  Report the percentage of rows within 0.15 tolerance separately.
  Half-or-more within 0.15 means the pass reflects structural
  compatibility. Most-within-0.15 means quantitative agreement.
  Different downstream implications, but neither gates pass/fail.
```

**Why these specific numbers** (locked, not subject to mid-run
adjustment):

- 0.25 tolerance: 0.30 is too loose for a load-bearing claim (passes
  mostly mean "right order of magnitude"). 0.15 is too tight for
  first-attempt photonic mappings where the mapping itself carries
  structural uncertainty (would kill real signal that needs mapping
  refinement). 0.25 sits between "novel mapping has slack" and "this
  actually predicts."
- 8 of 12 ratio: clean supermajority. 7 of 12 is barely above half
  (game-able). 9 of 12 over-tightens given thin literature.
- 4-of-12 floor: < 1/3 within 0.25 means the mapping is fitting
  noise, not capturing structure. That's structurally dead, not
  "needs more rows."
- 0.15 precision indicator: free information that distinguishes
  structural compatibility from quantitative agreement without
  conflating either with the gating threshold.

**Expected pass meaning:** PASS means:

```text
- t_fire is computed per row from the same framework predictor for
  both NV and photonic rows
- NV preamble check: t_fire residuals on the CR070a expanded NV
  table are consistent with CR069a's prior NV residuals (no
  regression from expansion)
- photonic per-row residuals reported PROVISIONAL
- aggregate counts reported per the falsifiability block:
    rows_within_0.25 / total_photonic_rows (gates pass/fail)
    rows_within_0.15 / total_photonic_rows (precision indicator)
- result_class string carries both counts:
    "CR073a_..._WITHIN_0_25_N_OF_M__WITHIN_0_15_K_OF_M"
- no free parameters introduced
- predictor formula is identical for NV and photonic rows
```

**Rule-9 falsifier:** Fails if any of:
(a) the t_fire formula is allowed to differ between NV and photonic
rows;
(b) any free parameter is introduced to fit the photonic data;
(c) the load-bearing threshold or floor is adjusted mid-run;
(d) the comparison is buried in a side artifact rather than reported
in the result_class;
(e) a divergent population is presented as consistent;
(f) the NV preamble check regresses against CR069a (would signal
the CR070a expansion broke something).

**Honest failure modes:**

```text
4 <= rows_within_0.25 < 8: campaign reports REFINEMENT-NEEDED, not
  structural failure. The mapping captures something but isn't
  load-bearing yet. Next campaign refines.
rows_within_0.25 < 4: structural floor breach. Campaign reports
  CR073a_PAUL_REVERE_DOES_NOT_GENERALIZE_TO_PHOTONIC_STRUCTURAL_FLOOR.
  Honest negative result; cross-platform generalization claim is
  dropped, NV-only deliverable scoped sharply.
NV preamble regresses: CR073a fails before photonic comparison; bug
  hunt in CR070a expansion, not a framework failure.
```

### CR074a - Reproducibility Lock

**Question:** Can the CR070a-CR073a runner chain be locked with a
dependency manifest, snapshot hashes, and a minimal-rerun pack such
that an independent reviewer can rerun every CR end-to-end on stock
Python?

**Allowed inputs:** CR070a-CR073a runners and outputs, the existing
12a hash chain discipline.

**Reproducibility Minimum (locked, not Docker)**

Docker is over-engineered at this stage. The minimum a partner lab
needs for byte-identical reproduction is three disciplined files:

```text
1. requirements.txt - pinned exact package versions (==, not >=)
2. .python-version    - exact Python interpreter version pin
3. seeds.json         - deterministic seeds for every stochastic step
                        in any CR runner (load, init, sampling)

A partner lab clones the campaign repo at the pinned commit, creates
a Python venv at the .python-version, pip install -r requirements.txt
the pinned packages, exports the seeds, and runs each CR runner. If
hashes match HASHES.txt entries byte-identically, reproducibility
holds. No Docker, no containers, no orchestration.
```

**Expected pass meaning:** PASS means:

```text
- a single CAMPAIGN_REPRODUCIBILITY_PACK.zip (or .tar.gz) is emitted
- the pack contains: all CR runners, all PRECOMMIT.md, all
  declared_premises.json, all input_manifest.csv, all
  evidence_rows.csv, all wrong_controls.csv, all result.md, all
  summary.json, all HASHES.txt, plus the three reproducibility-
  minimum files (requirements.txt, .python-version, seeds.json),
  plus a single CAMPAIGN_RERUN.md that documents the exact rerun
  procedure
- the pack hashes match the hashes recorded in each CR's HASHES.txt
- the pack does NOT include external data with non-citation provenance
- the STEWARDSHIP.md is included verbatim
- the rerun procedure is verified to work on a fresh Python venv at
  the pinned version with the pinned requirements
```

**Rule-9 falsifier:** Fails if any of:
(a) any CR runner or output is missing from the pack;
(b) hashes do not match HASHES.txt entries;
(c) the rerun procedure requires Docker, containers, or any
orchestration beyond pip install;
(d) requirements.txt uses >= or ~= instead of ==;
(e) any stochastic step lacks a seed in seeds.json;
(f) STEWARDSHIP.md is omitted.

### CR075a - Field Comparison Presentation Bundle

**Question:** Can the CR070a-CR074a result set be compressed into a
single presentation document that a partner-lab contact, scientific
reviewer, or potential supporter can read in under one working day
and use to evaluate whether to engage further?

**Allowed inputs:** CR070a-CR074a summaries, the STEWARDSHIP.md, the
existing 12a result.md template.

**Expected pass meaning:** PASS means the document:

```text
- is delivered as markdown SOURCE + PDF distribution (both, not one
  or the other; markdown is the editable source of truth, PDF is the
  partner/reviewer distribution form), <=30 pages
- opens with STEWARDSHIP.md verbatim as front matter
- summarizes the PR letter framework in <=2 pages with no jargon assumed
- summarizes CR070a-CR074a in <=2 pages each
- presents every failure and every PROVISIONAL tag honestly (no hidden
  failures, no quietly-fitted parameters, no "investment-grade" framing)
- names the bus-factor-1 risk explicitly (one author; partner-lab
  verification is the next step that scales it)
- names the partner-lab verification path explicitly
- closes with a clear ask: what an engaged reader would do next
  (specific citation verification, specific photonic data partner,
  specific independent rerun)
- does NOT claim hardware demonstration, partner-lab agreement, or
  commercial deployment
```

**Rule-9 falsifier:** Fails if any of:
(a) exceeds 30 pages;
(b) requires the reader to accept SAM as a TOE before reading the
campaign;
(c) hides any CR070a-CR074a failure;
(d) makes any claim out of scope;
(e) does not open with STEWARDSHIP.md.

## Campaign Success Criterion

```text
ALL of:
  - CR070a PASS (expanded NV-diamond T2 table populated, PROVISIONAL)
  - CR071a PASS (photonic PR letter framework mapping defined)
  - CR072a PASS (photonic empirical contact table populated, PROVISIONAL)
  - CR073a PASS (cross-platform scaling test reported honestly)
  - CR074a PASS (reproducibility pack emitted, hashes match)
  - CR075a PASS (presentation bundle <=30 pages, no hidden failures)

NONE of:
  - new free parameters introduced
  - hardware demonstration claimed
  - partner-lab agreement claimed
  - commercial protocol claimed
  - STEWARDSHIP.md omitted from any CR
  - failures suppressed or hidden in side artifacts
```

CR073a is the load-bearing test. If it fails honestly (NV and
photonic populations show divergent scaling), the campaign's result
is "PAUL_REVERE_DOES_NOT_GENERALIZE_TO_PHOTONIC_AT_PROVISIONAL_GRADE"
and the bundle reports that as the campaign deliverable. A failed
campaign that names a sharp question is still a valuable
contribution; failure is not suppression.

## Campaign Failure Postures

```text
CR070a fails -> NV-diamond literature pass did not expand the table; campaign returns with a narrower deliverable.
CR071a fails -> photonic mapping has ambiguity or requires a free parameter; named open question.
CR072a fails -> photonic literature is too thin or too inconsistent to populate; named open question, possibly redirects to trapped-ion.
CR073a fails -> PR letter does not generalize across platforms (honest negative result); valuable open finding.
CR074a fails -> reproducibility pack incomplete; engineering CR follows.
CR075a fails -> bundle too large or makes claims out of scope; presentation CR follows.
```

Every failure mode has a clearly-named open question that the next
campaign can pick up. Failure does not mean the framework is broken;
it means the field comparison surface has a precisely-named gap.

## Expected Campaign Result (If All PASS)

```text
PAUL_REVERE_FIELD_COMPARISON_CAMPAIGN_PASS
  20-30 NV-diamond T2 rows, PROVISIONAL, consistent with T2_grav v1.1 floor
  photonic PR letter framework mapping defined and falsifier-listed
  10-20 photonic empirical rows, PROVISIONAL, classified honestly
  cross-platform scaling test reported with X-of-Y outcomes
  reproducibility pack emitted, hashes verified
  presentation bundle <=30 pages, STEWARDSHIP.md verbatim, all failures
    visible, partner-lab verification path named, bus-factor-1 named
  zero free parameters across all six CRs
  zero hardware/partner/commercial claims
```

If achieved, the campaign produces a bundle that:

1. A partner lab could pick up and run independently
2. A scientific reviewer could attempt to break in one working day
3. A potential supporter could read and evaluate without needing to
   accept SAM as a TOE
4. The originator could hand to any of the above without revising
   the STEWARDSHIP.md framing

## Stewardship

Per `STEWARDSHIP.md`. Any commercial value flowing from this work or
its derivatives is subject to the stewardship intent: revenue funds
humanitarian causes (homeless shelters, addiction recovery,
charitable medical, education, community charities).

## Locked Decisions (Audit Log)

This document is a campaign draft, not a CR PRECOMMIT. Each CR will
get its own PRECOMMIT.md, declared_premises.json, runner.py,
input_manifest.csv, evidence_rows.csv, wrong_controls.csv,
summary.json, and result.md following the CR069a template before any
test execution begins.

The following decisions are locked at campaign-draft time, not
subject to mid-run adjustment:

```text
CR sequence length .... 6 CRs (CR070a-CR075a).
                        Compressed-4 skips needed steps; expanded-8
                        over-engineers before knowing if PR
                        generalizes cross-platform.

Row-count targets ..... CR070a 20-30 NV-diamond / CR072a 10-20
                        photonic. Honest about literature
                        availability; do not over-promise.

CR073a structure ...... ONE CR, not split. Folds NV preamble check
                        inside; main question is cross-platform
                        generalization, one yes/no.

CR073a threshold ...... Load-bearing: >= 8 of <= 12 photonic rows
                        within 0.25 tolerance.
                        Floor: < 4 of <= 12 = structural failure.
                        Precision indicator: report % within 0.15
                        separately (informational, not gating).
                        Pre-committed; not adjustable mid-run.

CR074a environment .... Pinned requirements.txt + .python-version
                        pin + seeds.json. Not Docker (over-
                        engineered at this stage). Rerunnable on
                        stock Python with pip install at the pinned
                        commit hash.

CR075a format ......... Markdown source + PDF distribution (both).
                        Markdown is editable source of truth; PDF
                        is the partner/reviewer distribution form.
                        STEWARDSHIP.md as front matter.

Other platforms ....... Trapped-ion and superconducting deferred.
                        Expand only after CR073a passes (next
                        campaign CR076a+), or scope the negative
                        result sharply to NV+photonic if CR073a
                        fails.
```

Ready for CR070a PRECOMMIT drafting.
