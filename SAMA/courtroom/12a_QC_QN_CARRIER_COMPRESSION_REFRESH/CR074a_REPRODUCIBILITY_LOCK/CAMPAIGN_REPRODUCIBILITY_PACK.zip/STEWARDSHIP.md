# Stewardship Intent

SAM is private research, and all rights remain reserved. If SAM or related work
ever produces commercial revenue, the originator intends for that value to
carry public responsibility with it.

Any future commercial licensing, investment, acquisition, productization, or
revenue-sharing discussion should treat public-benefit participation as part of
the expected deal structure.

Priority causes include:

```text
homeless shelters and housing support
addiction recovery and rehabilitation
charitable medical support
education and opportunity access
community charities and public-good efforts chosen by Sean Brady
```

This stewardship statement is not marketing. It records the project's intent:
if anyone profits from this work, part of that upside should help people who
need help.

The work began as an idea, a question, and a long effort to turn imagination
into something testable. If it becomes valuable in the world, that value should
not flow only upward. It should also flow outward.
