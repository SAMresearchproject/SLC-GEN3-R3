"""Unified evolving custody-native architecture."""

from .adapters import (
    finite_partition_morphism,
    frustrated_triangle_energy_morphism,
    reciprocal_dyadic_morphism,
    z4_translation_morphism,
)
from .algebra import PrimeLogWeight, SymbolicEntropy, factor_positive_integer
from .compiler import CompiledCustodyMorphism, CustodyState, FiberProfile, FiberReceipt
from .contextual import (
    CompiledContextualCustodyMorphism,
    ContextIdentityReceipt,
    ContextProgram,
    ContextRoster,
    ContextualFiberProfile,
    ContextualHierarchicalReceipt,
    ContextualInput,
    ContextualObservationContract,
    ContextualState,
    DirectContextualReceipt,
    DirectContextualState,
    LocalProgramIdentityReceipt,
    contextual_z4_from_catalog,
)
from .control import (
    ControlChannelState,
    ControlObservation,
    ControlProgramReceipt,
    ObservationContract,
    Z4ControlledTranslation,
    pack_z4,
    unpack_z4,
)
from .events import CustodyOperation, ResetRecord, declare_reset
from .exact import (
    conditional_entropy_of,
    entropy_from_probabilities,
    entropy_of,
    expected_log_support,
    normalized_distribution,
    support_weight,
)
from .program import CompiledCustodyProgram, ProgramReceipt, ProgramState
from .roster import (
    HierarchicalProgramReceipt,
    HierarchyResetRecord,
    ProgramRoster,
    RosterCatalog,
    RosterIdentityReceipt,
    RosterLocalProgramReceipt,
    RosterObservationContract,
    declare_hierarchy_reset,
)
from .roster_action import (
    ALL_RECEIPTS,
    LOCAL_RECEIPT,
    ROSTER_RECEIPT,
    FlatHierarchyReceipt,
    RosterCustodyState,
    RosterInformationProfile,
    RosterNativeZ4Translation,
    RosterObservation,
)
from .application_adapters import (
    ATOM3DAdapterReceipt,
    ATOM3D_DECLARATIONS,
    ATOM3DFiniteAssignmentInput,
    AdapterDeclarations,
    ApplicationAdapterContractError,
    BennettLivenessCertificate,
    ExactInnovationRow,
    ExactInnovationSubmodularRankTable,
    ExactRankRow,
    ExactSubmodularityRow,
    ExplicitAnalyticPrimeSourceMap,
    FiniteHistoryMultiplicity,
    NONINSTALLING_CROSSWALK_ONLY,
    RANK_TABLE_BOUND_EXCEEDED,
    RANK_TABLE_EXECUTED,
    RHPrimePowerAdapterReceipt,
    RH_DECLARATIONS,
    STARBREAKER_DECLARATIONS,
    StarbreakerAdapterReceipt,
    adapt_atom3d,
    adapt_rh_prime_power,
    adapt_starbreaker,
)
from .contextual_program import (
    CompiledContextualCustodyProgram,
    CompiledContextualState,
    ContextualProgramReceipt,
    ContextualProgramState,
)
from .exact_write import (
    ArtifactPin,
    CompleteExactWriteAdapter,
    ExactWriteDependencyError,
    ExactWriteDependencyReceipt,
    ExactWriteLawAudit,
    ExactWriteLawCheck,
    ExactWriteOperationDescriptor,
    NativeBatchComparison,
    VerifiedArtifact,
    verify_exact_write_dependencies,
)
from .hd import (
    FormalLogElement,
    HDContractError,
    HDSignature,
    RationalFactorProof,
    factor_bounded_rational,
)
from .information import (
    ExactDistribution,
    ExactPrefixCode,
    InformationPartition,
    ReceiptChannel,
    ReceiptSufficiencyCertificate,
    ReceiptSystem,
    uniform_conditional_entropy_from_fiber_sizes,
)
from .ledger import InformationCustodyAnnotation, build_custody_annotation
from .operation_graph import (
    ExactWriteOperationNode,
    ExactWriteTranslationGraph,
    TranslationHistoryReceipt,
    TranslationNormalFormReceipt,
    ledger_invertibility_witness,
)
from .native_substrate import (
    AFCTransportReference,
    AVAILABLE_DEPTHS,
    CANONICAL_TYPE_REGISTRY,
    CustodyAnnotation,
    ExactComposition,
    ExactDepthBlock,
    ExactWriteOperation,
    FormalLogMonoidElement,
    GramObject,
    LogicalErasureEvent,
    NativeExactSubstratePlane,
    NativeSourceSeal,
    NativeSubstrateContractError,
    PrimeValuationVector,
    ReceiptGraph,
    SupportObject,
    TensorOrbitObject,
    Theta18Report,
    VisibleFiber,
    W8State,
    W9History,
    W9P,
    canonical_round_trip,
)
from .reciprocal import (
    ReciprocalFiberCensus,
    ReciprocalHistoryLift,
    ReciprocalOrbit,
    census_moduli,
    census_reciprocal_map,
    reciprocal_involution,
    reciprocal_receipt_system,
    reciprocal_visible_map,
)
from .thermodynamics import (
    LandauerLowerBoundReceipt,
    LogicalResetEvent,
    PhysicalResetCalibration,
    ThermodynamicsContractError,
    landauer_lower_bound,
)


PRODUCT = "SLC_CUSTODY_NATIVE_ARCHITECTURE"
CURRENT_RELEASE = "V6"
IMMEDIATE_BASELINE = "V5"
RELEASE_LINEAGE = ("V1", "V2", "V3", "V4", "V5", CURRENT_RELEASE)

V1_API = (
    "CompiledCustodyMorphism", "CompiledCustodyProgram", "CustodyOperation",
    "CustodyState", "FiberProfile", "FiberReceipt", "PrimeLogWeight",
    "ProgramReceipt", "ProgramState", "ResetRecord", "SymbolicEntropy",
    "declare_reset", "factor_positive_integer", "finite_partition_morphism",
    "frustrated_triangle_energy_morphism", "reciprocal_dyadic_morphism",
    "z4_translation_morphism",
)
V2_API = (
    "ControlChannelState", "ControlObservation", "ControlProgramReceipt",
    "ObservationContract", "Z4ControlledTranslation", "pack_z4", "unpack_z4",
)
V3_API = (
    "ALL_RECEIPTS", "LOCAL_RECEIPT", "ROSTER_RECEIPT", "FlatHierarchyReceipt",
    "HierarchicalProgramReceipt", "HierarchyResetRecord", "ProgramRoster",
    "RosterCatalog", "RosterCustodyState", "RosterIdentityReceipt",
    "RosterInformationProfile", "RosterLocalProgramReceipt",
    "RosterNativeZ4Translation", "RosterObservation", "RosterObservationContract",
    "conditional_entropy_of", "declare_hierarchy_reset",
    "entropy_from_probabilities", "entropy_of", "expected_log_support",
    "normalized_distribution", "support_weight",
)
V5_API = (
    "CompiledContextualCustodyMorphism", "ContextIdentityReceipt",
    "ContextProgram", "ContextRoster", "ContextualFiberProfile",
    "ContextualHierarchicalReceipt", "ContextualInput",
    "ContextualObservationContract", "ContextualState",
    "DirectContextualReceipt", "DirectContextualState",
    "LocalProgramIdentityReceipt", "contextual_z4_from_catalog",
)
V6_API = (
    "AFCTransportReference", "ATOM3DAdapterReceipt", "ATOM3D_DECLARATIONS",
    "AVAILABLE_DEPTHS",
    "ATOM3DFiniteAssignmentInput", "AdapterDeclarations", "ArtifactPin",
    "ApplicationAdapterContractError", "BennettLivenessCertificate",
    "CANONICAL_TYPE_REGISTRY", "CustodyAnnotation",
    "CompleteExactWriteAdapter", "CompiledContextualCustodyProgram",
    "CompiledContextualState", "ContextualProgramReceipt",
    "ContextualProgramState", "ExactComposition", "ExactDepthBlock",
    "ExactDistribution", "ExactInnovationRow",
    "ExactInnovationSubmodularRankTable", "ExactPrefixCode", "ExactRankRow",
    "ExactSubmodularityRow", "ExactWriteDependencyError",
    "ExactWriteDependencyReceipt", "ExactWriteLawAudit", "ExactWriteLawCheck",
    "ExactWriteOperation", "ExactWriteOperationDescriptor", "ExactWriteOperationNode",
    "ExactWriteTranslationGraph", "ExplicitAnalyticPrimeSourceMap",
    "FiniteHistoryMultiplicity", "FormalLogElement", "FormalLogMonoidElement",
    "GramObject", "HDContractError", "HDSignature",
    "InformationCustodyAnnotation", "InformationPartition",
    "LandauerLowerBoundReceipt", "LogicalErasureEvent", "LogicalResetEvent",
    "NativeBatchComparison", "NativeExactSubstratePlane", "NativeSourceSeal",
    "NativeSubstrateContractError",
    "NONINSTALLING_CROSSWALK_ONLY", "PhysicalResetCalibration",
    "PrimeValuationVector",
    "RANK_TABLE_BOUND_EXCEEDED", "RANK_TABLE_EXECUTED", "RHPrimePowerAdapterReceipt",
    "RH_DECLARATIONS", "RationalFactorProof", "ReceiptChannel",
    "ReceiptGraph", "ReceiptSufficiencyCertificate", "ReceiptSystem",
    "ReciprocalFiberCensus",
    "ReciprocalHistoryLift", "ReciprocalOrbit", "STARBREAKER_DECLARATIONS",
    "StarbreakerAdapterReceipt", "SupportObject", "TensorOrbitObject",
    "Theta18Report", "ThermodynamicsContractError",
    "TranslationHistoryReceipt", "TranslationNormalFormReceipt",
    "VerifiedArtifact", "VisibleFiber", "W8State", "W9History", "W9P",
    "adapt_atom3d",
    "adapt_rh_prime_power", "adapt_starbreaker", "build_custody_annotation",
    "canonical_round_trip",
    "census_moduli", "census_reciprocal_map", "factor_bounded_rational",
    "landauer_lower_bound", "ledger_invertibility_witness",
    "reciprocal_involution", "reciprocal_receipt_system",
    "reciprocal_visible_map", "uniform_conditional_entropy_from_fiber_sizes",
    "verify_exact_write_dependencies",
)

__all__ = tuple(dict.fromkeys(
    V1_API + V2_API + V3_API + V5_API + V6_API + (
        "PRODUCT", "CURRENT_RELEASE", "IMMEDIATE_BASELINE", "RELEASE_LINEAGE",
        "V1_API", "V2_API", "V3_API", "V5_API", "V6_API",
    )
))
