"""Exact symbolic multiplicity and information-weight algebra."""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from math import lcm, log
from typing import Iterable, Mapping


def factor_positive_integer(value: int) -> tuple[tuple[int, int], ...]:
    """Return the exact prime factorization of a positive integer."""

    if isinstance(value, bool) or not isinstance(value, int):
        raise TypeError("multiplicity must be an integer")
    n = value
    if n < 1:
        raise ValueError("multiplicity must be a positive integer")
    factors: list[tuple[int, int]] = []
    divisor = 2
    while divisor * divisor <= n:
        exponent = 0
        while n % divisor == 0:
            n //= divisor
            exponent += 1
        if exponent:
            factors.append((divisor, exponent))
        divisor = 3 if divisor == 2 else divisor + 2
    if n > 1:
        factors.append((n, 1))
    return tuple(factors)


def _is_prime(value: int) -> bool:
    return value >= 2 and factor_positive_integer(value) == ((value, 1),)


def _coefficient_text(value: Fraction, *, suppress_one: bool = False) -> str:
    if value == 1 and suppress_one:
        return ""
    if value.denominator == 1:
        return str(value.numerator)
    return f"{value.numerator}/{value.denominator}"


@dataclass(frozen=True, slots=True)
class PrimeLogWeight:
    """The exact additive information weight ``log(m)`` of multiplicity m."""

    multiplicity: int
    prime_exponents: tuple[tuple[int, int], ...]

    def __post_init__(self) -> None:
        if isinstance(self.multiplicity, bool) or not isinstance(
            self.multiplicity, int
        ):
            raise TypeError("multiplicity must be an integer")
        if self.multiplicity < 1:
            raise ValueError("multiplicity must be a positive integer")
        if self.prime_exponents != factor_positive_integer(self.multiplicity):
            raise ValueError("prime exponents are not the canonical factorization")

    @classmethod
    def from_multiplicity(cls, multiplicity: int) -> "PrimeLogWeight":
        return cls(multiplicity, factor_positive_integer(multiplicity))

    @property
    def expression(self) -> str:
        if self.multiplicity == 1:
            return "0"
        terms: list[str] = []
        for prime, exponent in self.prime_exponents:
            if exponent == 1:
                terms.append(f"log({prime})")
            else:
                terms.append(f"{exponent}*log({prime})")
        return " + ".join(terms)

    @property
    def nats(self) -> float:
        return log(self.multiplicity)

    @property
    def bits(self) -> float:
        return self.nats / log(2)

    def compose(self, other: "PrimeLogWeight") -> "PrimeLogWeight":
        return PrimeLogWeight.from_multiplicity(self.multiplicity * other.multiplicity)

    def quotient(self, retained: "PrimeLogWeight") -> "PrimeLogWeight":
        if self.multiplicity % retained.multiplicity:
            raise ValueError("retained multiplicity must divide source multiplicity")
        return PrimeLogWeight.from_multiplicity(self.multiplicity // retained.multiplicity)

    def to_dict(self) -> dict[str, object]:
        return {
            "multiplicity": self.multiplicity,
            "prime_exponents": [
                {"prime": prime, "exponent": exponent}
                for prime, exponent in self.prime_exponents
            ],
            "exact_nats": self.expression,
            "evaluated_nats": self.nats,
            "evaluated_bits": self.bits,
        }


@dataclass(frozen=True, slots=True)
class SymbolicEntropy:
    """A rational linear combination of exact prime logarithms."""

    coefficients: tuple[tuple[int, Fraction], ...] = ()

    def __post_init__(self) -> None:
        if self.coefficients != tuple(sorted(self.coefficients)):
            raise ValueError("prime-log coefficients must be canonically sorted")
        primes = [prime for prime, _ in self.coefficients]
        if len(primes) != len(set(primes)):
            raise ValueError("prime-log coefficients contain duplicate primes")
        for prime, coefficient in self.coefficients:
            if isinstance(prime, bool) or not isinstance(prime, int):
                raise TypeError("prime-log basis keys must be integers")
            if not _is_prime(prime):
                raise ValueError(f"prime-log basis key is not prime: {prime}")
            if not isinstance(coefficient, Fraction) or coefficient == 0:
                raise ValueError("prime-log coefficients must be nonzero Fractions")

    @classmethod
    def from_terms(cls, terms: Mapping[int, Fraction | int]) -> "SymbolicEntropy":
        normalized_rows: list[tuple[int, Fraction]] = []
        for prime, coefficient in terms.items():
            if isinstance(prime, bool) or not isinstance(prime, int):
                raise TypeError("prime-log basis keys must be integers")
            if isinstance(coefficient, bool) or not isinstance(
                coefficient, (int, Fraction)
            ):
                raise TypeError("prime-log coefficients must be exact")
            exact = coefficient if isinstance(coefficient, Fraction) else Fraction(coefficient)
            if exact:
                normalized_rows.append((prime, exact))
        normalized = tuple(sorted(normalized_rows))
        return cls(normalized)

    @classmethod
    def weighted_log(
        cls,
        multiplicity: int,
        coefficient: Fraction | int = Fraction(1),
    ) -> "SymbolicEntropy":
        if isinstance(coefficient, bool) or not isinstance(
            coefficient, (int, Fraction)
        ):
            raise TypeError("prime-log coefficients must be exact")
        scalar = coefficient if isinstance(coefficient, Fraction) else Fraction(coefficient)
        return cls.from_terms(
            {
                prime: scalar * exponent
                for prime, exponent in factor_positive_integer(multiplicity)
            }
        )

    @classmethod
    def sum(cls, values: Iterable["SymbolicEntropy"]) -> "SymbolicEntropy":
        accumulator: dict[int, Fraction] = {}
        for value in values:
            for prime, coefficient in value.coefficients:
                accumulator[prime] = accumulator.get(prime, Fraction()) + coefficient
        return cls.from_terms(accumulator)

    def __add__(self, other: "SymbolicEntropy") -> "SymbolicEntropy":
        return SymbolicEntropy.sum((self, other))

    def __sub__(self, other: "SymbolicEntropy") -> "SymbolicEntropy":
        return self + SymbolicEntropy.from_terms(
            {prime: -coefficient for prime, coefficient in other.coefficients}
        )

    @property
    def expression(self) -> str:
        if not self.coefficients:
            return "0"
        terms: list[str] = []
        for prime, coefficient in self.coefficients:
            if coefficient == 1:
                terms.append(f"log({prime})")
            elif coefficient == -1:
                terms.append(f"-log({prime})")
            else:
                terms.append(f"{_coefficient_text(coefficient)}*log({prime})")
        return " + ".join(terms).replace("+ -", "- ")

    @property
    def nats(self) -> float:
        return sum(float(coefficient) * log(prime) for prime, coefficient in self.coefficients)

    @property
    def bits(self) -> float:
        return self.nats / log(2)

    def sign(self) -> int:
        """Compare the exact logarithmic product with one using integers."""

        if not self.coefficients:
            return 0
        denominator = lcm(
            *(coefficient.denominator for _, coefficient in self.coefficients)
        )
        positive = 1
        negative = 1
        for prime, coefficient in self.coefficients:
            exponent = coefficient.numerator * (
                denominator // coefficient.denominator
            )
            if exponent > 0:
                positive *= prime**exponent
            elif exponent < 0:
                negative *= prime ** (-exponent)
        return (positive > negative) - (positive < negative)

    def to_dict(self) -> dict[str, object]:
        return {
            "prime_log_coefficients": [
                {
                    "prime": prime,
                    "coefficient": _coefficient_text(coefficient),
                }
                for prime, coefficient in self.coefficients
            ],
            "exact_nats": self.expression,
            "evaluated_nats": self.nats,
            "evaluated_bits": self.bits,
        }
