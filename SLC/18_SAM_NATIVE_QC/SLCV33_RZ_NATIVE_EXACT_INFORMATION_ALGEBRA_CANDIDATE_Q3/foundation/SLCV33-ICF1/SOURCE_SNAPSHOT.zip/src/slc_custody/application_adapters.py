"""Strict noninstalling application crosswalks for the V6 custody layer.

These adapters expose exact consequences of already-typed finite inputs.  They
do not install results into Starbreaker, ATOM3D, RH, or any live authority.
Application-specific conclusions outside the finite crosswalk are represented
as explicitly unchanged authority, never inferred by an adapter.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from itertools import combinations
from math import isqrt
from typing import Any, Hashable

from .hd import FormalLogElement, HDSignature
from .information import (
    ExactDistribution,
    InformationPartition,
    ReceiptChannel,
    ReceiptSufficiencyCertificate,
    ReceiptSystem,
    _strict_form,
)
from .thermodynamics import (
    LandauerLowerBoundReceipt,
    LogicalResetEvent,
    PhysicalResetCalibration,
    landauer_lower_bound,
)


NONINSTALLING_CROSSWALK_ONLY = "NONINSTALLING_CROSSWALK_ONLY"
RANK_TABLE_EXECUTED = "EXACT_TABLE_EXECUTED"
RANK_TABLE_BOUND_EXCEEDED = "NOT_EXECUTED_CHANNEL_BOUND_EXCEEDED"


class ApplicationAdapterContractError(ValueError):
    """An application adapter received an inconsistent typed input."""


def _required_text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise ApplicationAdapterContractError(f"{label} must be a nonempty string")
    return value


def _strict_bool(value: Any, label: str) -> bool:
    if not isinstance(value, bool):
        raise ApplicationAdapterContractError(f"{label} must be a boolean")
    return value


def _strict_int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ApplicationAdapterContractError(f"{label} must be an integer")
    return value


def _canonical_channels(value: tuple[str, ...], label: str) -> tuple[str, ...]:
    if not isinstance(value, tuple):
        raise ApplicationAdapterContractError(f"{label} must be a tuple")
    if any(not isinstance(channel, str) or not channel for channel in value):
        raise ApplicationAdapterContractError(
            f"{label} must contain nonempty strings"
        )
    if tuple(sorted(set(value))) != value:
        raise ApplicationAdapterContractError(
            f"{label} must be sorted and duplicate-free"
        )
    return value


def _fraction_dict(value: Fraction) -> dict[str, int]:
    return {"numerator": value.numerator, "denominator": value.denominator}


@dataclass(frozen=True, slots=True)
class AdapterDeclarations:
    """Fixed authority and algorithm declarations carried by every receipt."""

    native_input: str
    exact_crosswalk: str
    preserved_laws: tuple[str, ...]
    imported_theorem_or_algorithm: str
    new_exposed_capability: str
    unchanged_downstream_authority: str
    installation_status: str = NONINSTALLING_CROSSWALK_ONLY

    def __post_init__(self) -> None:
        for value, label in (
            (self.native_input, "native_input"),
            (self.exact_crosswalk, "exact_crosswalk"),
            (
                self.imported_theorem_or_algorithm,
                "imported_theorem_or_algorithm",
            ),
            (self.new_exposed_capability, "new_exposed_capability"),
            (
                self.unchanged_downstream_authority,
                "unchanged_downstream_authority",
            ),
        ):
            _required_text(value, label)
        if (
            not isinstance(self.preserved_laws, tuple)
            or not self.preserved_laws
            or any(not isinstance(item, str) or not item for item in self.preserved_laws)
            or len(set(self.preserved_laws)) != len(self.preserved_laws)
        ):
            raise ApplicationAdapterContractError(
                "preserved_laws must be a nonempty duplicate-free tuple"
            )
        if self.installation_status != NONINSTALLING_CROSSWALK_ONLY:
            raise ApplicationAdapterContractError(
                "application adapters cannot install or promote downstream authority"
            )

    def to_dict(self) -> dict[str, object]:
        return {
            "native_input": self.native_input,
            "exact_crosswalk": self.exact_crosswalk,
            "preserved_laws": list(self.preserved_laws),
            "imported_theorem_or_algorithm": self.imported_theorem_or_algorithm,
            "new_exposed_capability": self.new_exposed_capability,
            "unchanged_downstream_authority": self.unchanged_downstream_authority,
            "installation_status": self.installation_status,
        }


STARBREAKER_DECLARATIONS = AdapterDeclarations(
    native_input=(
        "LogicalResetEvent, BennettLivenessCertificate, and optional "
        "PhysicalResetCalibration"
    ),
    exact_crosswalk=(
        "typed live-channel custody -> reversible Bennett uncomputation lane + "
        "committed logical-erasure lane -> symbolic Landauer lower-bound receipt"
    ),
    preserved_laws=(
        "exact receipt reconstructibility",
        "reversible uncomputation has zero logical erasure",
        "Landauer lower bound applies only to committed logical erasure",
    ),
    imported_theorem_or_algorithm=(
        "Bennett copy-output/uncompute procedure and symbolic Landauer lower bound"
    ),
    new_exposed_capability=(
        "machine-checkable separation of avoidable cleanup and committed erasure"
    ),
    unchanged_downstream_authority="STARBREAKER_AUTHORITY_UNCHANGED",
)

ATOM3D_DECLARATIONS = AdapterDeclarations(
    native_input=(
        "exact finite assignment domain, symmetry and visible partitions, kept "
        "receipt partitions, and exact rational source law"
    ),
    exact_crosswalk=(
        "finite assignments -> orbit/visible/receipt fibers -> exact refinement, "
        "sufficiency, rank, innovation, and submodularity receipts"
    ),
    preserved_laws=(
        "finite partition refinement",
        "exact rational Shannon information",
        "monotone submodular receipt rank",
    ),
    imported_theorem_or_algorithm=(
        "finite partition joins, bounded exact receipt set cover, and Shannon "
        "polymatroid rank enumeration"
    ),
    new_exposed_capability=(
        "exact assignment-orbit and receipt-custody census without physical inference"
    ),
    unchanged_downstream_authority="ATOM3D_AUTHORITY_UNCHANGED",
)

RH_DECLARATIONS = AdapterDeclarations(
    native_input=(
        "positive prime p, positive integer m, and typed finite history "
        "multiplicity with provenance"
    ),
    exact_crosswalk=(
        "finite p^m history multiplicity -> HD prime-power composition -> "
        "L(p^m)=m*ln(p) formal-log receipt"
    ),
    preserved_laws=(
        "prime-power multiplication",
        "formal logarithm homomorphism on positive rationals",
        "exact HD multiplication",
    ),
    imported_theorem_or_algorithm=(
        "integer primality test and unique prime-factor formal-log representation"
    ),
    new_exposed_capability=(
        "typed finite-history prime-power composition receipt with no RH-sign inference"
    ),
    unchanged_downstream_authority="RH_AUTHORITY_UNCHANGED",
)


@dataclass(frozen=True, slots=True)
class BennettLivenessCertificate:
    """A declared live-state split for copy-output/uncompute/reset custody."""

    certificate_id: str
    reset_event_id: str
    live_channels_before_cleanup: tuple[str, ...]
    retained_channels_after_cleanup: tuple[str, ...]
    avoidable_uncomputation_channels: tuple[str, ...]
    committed_erasure_channels: tuple[str, ...]
    output_copy_retained: bool
    inverse_schedule_declared: bool
    reconstructs_source_after_avoidable_uncomputation: bool
    logical_source_provenance: str
    certificate_provenance: str

    def __post_init__(self) -> None:
        _required_text(self.certificate_id, "certificate_id")
        _required_text(self.reset_event_id, "reset_event_id")
        live = _canonical_channels(
            self.live_channels_before_cleanup, "live_channels_before_cleanup"
        )
        retained = _canonical_channels(
            self.retained_channels_after_cleanup,
            "retained_channels_after_cleanup",
        )
        avoidable = _canonical_channels(
            self.avoidable_uncomputation_channels,
            "avoidable_uncomputation_channels",
        )
        committed = _canonical_channels(
            self.committed_erasure_channels, "committed_erasure_channels"
        )
        if any(
            left & right
            for left, right in (
                (set(retained), set(avoidable)),
                (set(retained), set(committed)),
                (set(avoidable), set(committed)),
            )
        ):
            raise ApplicationAdapterContractError(
                "retained, avoidable, and committed channel sets must be disjoint"
            )
        if tuple(sorted(retained + avoidable + committed)) != live:
            raise ApplicationAdapterContractError(
                "live channels must equal retained + avoidable + committed channels"
            )
        output_retained = _strict_bool(
            self.output_copy_retained, "output_copy_retained"
        )
        inverse_declared = _strict_bool(
            self.inverse_schedule_declared, "inverse_schedule_declared"
        )
        _strict_bool(
            self.reconstructs_source_after_avoidable_uncomputation,
            "reconstructs_source_after_avoidable_uncomputation",
        )
        if not output_retained:
            raise ApplicationAdapterContractError(
                "a Bennett liveness certificate must retain the copied output"
            )
        if avoidable and not inverse_declared:
            raise ApplicationAdapterContractError(
                "avoidable uncomputation channels require a declared inverse schedule"
            )
        _required_text(self.logical_source_provenance, "logical_source_provenance")
        _required_text(self.certificate_provenance, "certificate_provenance")

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_BENNETT_LIVENESS_CERTIFICATE_V6",
            "certificate_id": self.certificate_id,
            "reset_event_id": self.reset_event_id,
            "live_channels_before_cleanup": list(self.live_channels_before_cleanup),
            "retained_channels_after_cleanup": list(
                self.retained_channels_after_cleanup
            ),
            "avoidable_uncomputation_channels": list(
                self.avoidable_uncomputation_channels
            ),
            "committed_erasure_channels": list(self.committed_erasure_channels),
            "output_copy_retained": self.output_copy_retained,
            "inverse_schedule_declared": self.inverse_schedule_declared,
            "reconstructs_source_after_avoidable_uncomputation": (
                self.reconstructs_source_after_avoidable_uncomputation
            ),
            "logical_source_provenance": self.logical_source_provenance,
            "certificate_provenance": self.certificate_provenance,
        }


@dataclass(frozen=True, slots=True)
class StarbreakerAdapterReceipt:
    declarations: AdapterDeclarations
    logical_reset_event: LogicalResetEvent
    liveness_certificate: BennettLivenessCertificate
    avoidable_uncomputation_channels: tuple[str, ...]
    avoidable_logical_erasure: FormalLogElement
    committed_erasure_channels: tuple[str, ...]
    committed_logical_erasure: FormalLogElement
    landauer_receipt: LandauerLowerBoundReceipt
    physical_calibration: PhysicalResetCalibration | None
    physical_calibration_supplied: bool
    physical_calibration_applied: bool

    def __post_init__(self) -> None:
        if self.declarations != STARBREAKER_DECLARATIONS:
            raise ApplicationAdapterContractError(
                "Starbreaker receipt authority declarations are not canonical"
            )
        if type(self.logical_reset_event) is not LogicalResetEvent:
            raise ApplicationAdapterContractError(
                "Starbreaker receipt requires LogicalResetEvent"
            )
        if type(self.liveness_certificate) is not BennettLivenessCertificate:
            raise ApplicationAdapterContractError(
                "Starbreaker receipt requires BennettLivenessCertificate"
            )
        if type(self.landauer_receipt) is not LandauerLowerBoundReceipt:
            raise ApplicationAdapterContractError(
                "Starbreaker receipt requires LandauerLowerBoundReceipt"
            )
        if self.physical_calibration is not None and type(
            self.physical_calibration
        ) is not PhysicalResetCalibration:
            raise ApplicationAdapterContractError(
                "Starbreaker receipt physical calibration has the wrong type"
            )
        _canonical_channels(
            self.avoidable_uncomputation_channels,
            "avoidable_uncomputation_channels",
        )
        _canonical_channels(
            self.committed_erasure_channels, "committed_erasure_channels"
        )
        if (
            self.avoidable_uncomputation_channels
            != self.liveness_certificate.avoidable_uncomputation_channels
            or self.committed_erasure_channels
            != self.liveness_certificate.committed_erasure_channels
        ):
            raise ApplicationAdapterContractError(
                "Starbreaker cleanup lanes differ from the liveness certificate"
            )
        if (
            self.logical_reset_event.event_id
            != self.liveness_certificate.reset_event_id
            or self.logical_reset_event.source_law_provenance
            != self.liveness_certificate.logical_source_provenance
        ):
            raise ApplicationAdapterContractError(
                "Starbreaker reset and liveness source custody differ"
            )
        if not isinstance(self.avoidable_logical_erasure, FormalLogElement):
            raise ApplicationAdapterContractError(
                "avoidable_logical_erasure must be a FormalLogElement"
            )
        if not self.avoidable_logical_erasure.is_zero:
            raise ApplicationAdapterContractError(
                "certified Bennett uncomputation must carry zero logical erasure"
            )
        if self.committed_logical_erasure != self.logical_reset_event.erased_information:
            raise ApplicationAdapterContractError(
                "committed erasure must equal the typed logical reset event"
            )
        if self.landauer_receipt.event_id != self.logical_reset_event.event_id:
            raise ApplicationAdapterContractError(
                "Landauer receipt belongs to a different reset event"
            )
        if (
            self.landauer_receipt.erased_information
            != self.committed_logical_erasure
        ):
            raise ApplicationAdapterContractError(
                "Landauer and committed logical-erasure quantities differ"
            )
        supplied = _strict_bool(
            self.physical_calibration_supplied, "physical_calibration_supplied"
        )
        if supplied != (self.physical_calibration is not None):
            raise ApplicationAdapterContractError(
                "physical calibration object and supplied flag differ"
            )
        applied = _strict_bool(
            self.physical_calibration_applied, "physical_calibration_applied"
        )
        if applied != (
            self.landauer_receipt.status == "IDEAL_LANDAUER_LOWER_BOUND"
        ):
            raise ApplicationAdapterContractError(
                "physical calibration application status is inconsistent"
            )
        if applied and not supplied:
            raise ApplicationAdapterContractError(
                "a physical calibration cannot be applied when none was supplied"
            )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_STARBREAKER_NONINSTALLING_ADAPTER_RECEIPT_V6",
            "declarations": self.declarations.to_dict(),
            "logical_reset_event": self.logical_reset_event.to_dict(),
            "bennett_liveness_certificate": self.liveness_certificate.to_dict(),
            "avoidable_uncomputation": {
                "channels": list(self.avoidable_uncomputation_channels),
                "action": "COPY_OUTPUT_THEN_APPLY_DECLARED_INVERSE",
                "logical_erasure_exact_nats": self.avoidable_logical_erasure.to_dict(),
            },
            "committed_erasure": {
                "channels": list(self.committed_erasure_channels),
                "logical_erasure_exact_nats": self.committed_logical_erasure.to_dict(),
            },
            "landauer_lower_bound": self.landauer_receipt.to_dict(),
            "physical_reset_calibration": (
                None
                if self.physical_calibration is None
                else self.physical_calibration.to_dict()
            ),
            "physical_calibration_supplied": self.physical_calibration_supplied,
            "physical_calibration_applied": self.physical_calibration_applied,
        }


def adapt_starbreaker(
    logical_reset_event: LogicalResetEvent,
    liveness_certificate: BennettLivenessCertificate,
    physical_calibration: PhysicalResetCalibration | None = None,
) -> StarbreakerAdapterReceipt:
    """Crosswalk one typed reset without installing a Starbreaker result."""

    if type(logical_reset_event) is not LogicalResetEvent:
        raise ApplicationAdapterContractError(
            "Starbreaker accepts only a LogicalResetEvent"
        )
    if type(liveness_certificate) is not BennettLivenessCertificate:
        raise ApplicationAdapterContractError(
            "Starbreaker accepts only a BennettLivenessCertificate"
        )
    if physical_calibration is not None and type(
        physical_calibration
    ) is not PhysicalResetCalibration:
        raise ApplicationAdapterContractError(
            "Starbreaker physical calibration has the wrong type"
        )
    certificate = liveness_certificate
    event = logical_reset_event
    if certificate.reset_event_id != event.event_id:
        raise ApplicationAdapterContractError(
            "Bennett certificate and logical reset event IDs differ"
        )
    if certificate.logical_source_provenance != event.source_law_provenance:
        raise ApplicationAdapterContractError(
            "Bennett certificate and logical reset source provenance differ"
        )
    if certificate.retained_channels_after_cleanup != event.retained_channels:
        raise ApplicationAdapterContractError(
            "Bennett retained channels do not match the logical reset event"
        )
    if certificate.committed_erasure_channels != event.destroyed_channels:
        raise ApplicationAdapterContractError(
            "Bennett committed channels do not match the logical reset event"
        )
    if (
        certificate.reconstructs_source_after_avoidable_uncomputation
        != event.reconstructs_source_before_event
    ):
        raise ApplicationAdapterContractError(
            "Bennett liveness result does not match pre-reset reconstructibility"
        )
    bound = landauer_lower_bound(event, physical_calibration)
    return StarbreakerAdapterReceipt(
        declarations=STARBREAKER_DECLARATIONS,
        logical_reset_event=event,
        liveness_certificate=certificate,
        avoidable_uncomputation_channels=(
            certificate.avoidable_uncomputation_channels
        ),
        avoidable_logical_erasure=FormalLogElement.zero(),
        committed_erasure_channels=certificate.committed_erasure_channels,
        committed_logical_erasure=event.erased_information,
        landauer_receipt=bound,
        physical_calibration=physical_calibration,
        physical_calibration_supplied=physical_calibration is not None,
        physical_calibration_applied=(
            bound.status == "IDEAL_LANDAUER_LOWER_BOUND"
        ),
    )


@dataclass(frozen=True, slots=True)
class ATOM3DFiniteAssignmentInput:
    """Exact finite ATOM3D assignment input; no physical meaning is inferred."""

    assignment_domain: tuple[Hashable, ...]
    symmetry_partition: InformationPartition
    visible_partition: InformationPartition
    kept_receipt_partitions: tuple[ReceiptChannel, ...]
    source_law: ExactDistribution
    exact_rank_channel_limit: int = 8

    def __post_init__(self) -> None:
        if not isinstance(self.assignment_domain, tuple) or not self.assignment_domain:
            raise ApplicationAdapterContractError(
                "assignment_domain must be a nonempty canonical tuple"
            )
        if type(self.symmetry_partition) is not InformationPartition:
            raise ApplicationAdapterContractError(
                "symmetry_partition has the wrong type"
            )
        if type(self.visible_partition) is not InformationPartition:
            raise ApplicationAdapterContractError(
                "visible_partition has the wrong type"
            )
        if type(self.source_law) is not ExactDistribution:
            raise ApplicationAdapterContractError("source_law has the wrong type")
        if self.assignment_domain != self.visible_partition.domain:
            raise ApplicationAdapterContractError(
                "assignment domain must equal the visible partition domain"
            )
        if self.assignment_domain != self.symmetry_partition.domain:
            raise ApplicationAdapterContractError(
                "assignment domain must equal the symmetry partition domain"
            )
        if self.assignment_domain != self.source_law.domain:
            raise ApplicationAdapterContractError(
                "assignment domain must equal the exact source-law domain"
            )
        if not isinstance(self.kept_receipt_partitions, tuple) or any(
            type(channel) is not ReceiptChannel
            for channel in self.kept_receipt_partitions
        ):
            raise ApplicationAdapterContractError(
                "kept_receipt_partitions must be a tuple of ReceiptChannel values"
            )
        ReceiptSystem(self.visible_partition, self.kept_receipt_partitions)
        limit = _strict_int(
            self.exact_rank_channel_limit, "exact_rank_channel_limit"
        )
        if limit < 0 or limit > 10:
            raise ApplicationAdapterContractError(
                "exact_rank_channel_limit must lie between zero and ten"
            )


@dataclass(frozen=True, slots=True)
class ExactRankRow:
    selected_channels: tuple[str, ...]
    rank: FormalLogElement

    def to_dict(self) -> dict[str, object]:
        return {
            "selected_channels": list(self.selected_channels),
            "rank_exact_nats": self.rank.to_dict(),
        }


@dataclass(frozen=True, slots=True)
class ExactInnovationRow:
    base_channels: tuple[str, ...]
    added_channel: str
    innovation: FormalLogElement

    def to_dict(self) -> dict[str, object]:
        return {
            "base_channels": list(self.base_channels),
            "added_channel": self.added_channel,
            "innovation_exact_nats": self.innovation.to_dict(),
            "nonnegative": self.innovation.sign >= 0,
        }


@dataclass(frozen=True, slots=True)
class ExactSubmodularityRow:
    left_channels: tuple[str, ...]
    right_channels: tuple[str, ...]
    residual: FormalLogElement

    def to_dict(self) -> dict[str, object]:
        return {
            "left_channels": list(self.left_channels),
            "right_channels": list(self.right_channels),
            "residual_exact_nats": self.residual.to_dict(),
            "nonnegative": self.residual.sign >= 0,
        }


@dataclass(frozen=True, slots=True)
class ExactInnovationSubmodularRankTable:
    status: str
    channel_count: int
    declared_channel_limit: int
    rank_rows: tuple[ExactRankRow, ...]
    innovation_rows: tuple[ExactInnovationRow, ...]
    submodularity_rows: tuple[ExactSubmodularityRow, ...]

    def __post_init__(self) -> None:
        if self.status not in {RANK_TABLE_EXECUTED, RANK_TABLE_BOUND_EXCEEDED}:
            raise ApplicationAdapterContractError("unknown rank-table status")
        channel_count = _strict_int(self.channel_count, "channel_count")
        limit = _strict_int(
            self.declared_channel_limit, "declared_channel_limit"
        )
        if channel_count < 0 or limit < 0:
            raise ApplicationAdapterContractError(
                "rank-table counts cannot be negative"
            )
        rows = self.rank_rows + self.innovation_rows + self.submodularity_rows
        if (
            any(type(row) is not ExactRankRow for row in self.rank_rows)
            or any(
                type(row) is not ExactInnovationRow for row in self.innovation_rows
            )
            or any(
                type(row) is not ExactSubmodularityRow
                for row in self.submodularity_rows
            )
        ):
            raise ApplicationAdapterContractError(
                "rank-table rows must use their exact typed row classes"
            )
        if self.status == RANK_TABLE_BOUND_EXCEEDED:
            if channel_count <= limit or rows:
                raise ApplicationAdapterContractError(
                    "bounded-out rank table must exceed its limit and contain no rows"
                )
        else:
            if channel_count > limit:
                raise ApplicationAdapterContractError(
                    "executed rank table exceeds its declared limit"
                )
            if len(self.rank_rows) != 2**channel_count:
                raise ApplicationAdapterContractError(
                    "executed rank table has the wrong subset count"
                )
            expected_innovations = (
                0 if channel_count == 0 else channel_count * 2 ** (channel_count - 1)
            )
            if len(self.innovation_rows) != expected_innovations:
                raise ApplicationAdapterContractError(
                    "executed innovation table has the wrong row count"
                )
            if len(self.submodularity_rows) != 4**channel_count:
                raise ApplicationAdapterContractError(
                    "executed submodularity table has the wrong row count"
                )
            if any(row.innovation.sign < 0 for row in self.innovation_rows):
                raise ApplicationAdapterContractError(
                    "exact information innovation cannot be negative"
                )
            if any(row.residual.sign < 0 for row in self.submodularity_rows):
                raise ApplicationAdapterContractError(
                    "exact Shannon receipt rank must be submodular"
                )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_EXACT_INNOVATION_SUBMODULAR_RANK_TABLE_V6",
            "status": self.status,
            "channel_count": self.channel_count,
            "declared_channel_limit": self.declared_channel_limit,
            "rank_rows": [row.to_dict() for row in self.rank_rows],
            "innovation_rows": [row.to_dict() for row in self.innovation_rows],
            "submodularity_rows": [
                row.to_dict() for row in self.submodularity_rows
            ],
        }


def _rank_table(
    system: ReceiptSystem,
    source_law: ExactDistribution,
    declared_limit: int,
) -> ExactInnovationSubmodularRankTable:
    names = system.channel_names
    if len(names) > declared_limit:
        return ExactInnovationSubmodularRankTable(
            status=RANK_TABLE_BOUND_EXCEEDED,
            channel_count=len(names),
            declared_channel_limit=declared_limit,
            rank_rows=(),
            innovation_rows=(),
            submodularity_rows=(),
        )
    subsets = tuple(
        tuple(candidate)
        for width in range(len(names) + 1)
        for candidate in combinations(names, width)
    )
    ranks = {
        subset: system.rank(source_law, subset)
        for subset in subsets
    }
    rank_rows = tuple(ExactRankRow(subset, ranks[subset]) for subset in subsets)
    innovations = tuple(
        ExactInnovationRow(
            base_channels=subset,
            added_channel=name,
            innovation=(
                ranks[tuple(sorted(subset + (name,)))] - ranks[subset]
            ),
        )
        for subset in subsets
        for name in names
        if name not in subset
    )
    submodularity = tuple(
        ExactSubmodularityRow(
            left_channels=left,
            right_channels=right,
            residual=(
                ranks[left]
                + ranks[right]
                - ranks[tuple(sorted(set(left) | set(right)))]
                - ranks[tuple(sorted(set(left) & set(right)))]
            ),
        )
        for left in subsets
        for right in subsets
    )
    return ExactInnovationSubmodularRankTable(
        status=RANK_TABLE_EXECUTED,
        channel_count=len(names),
        declared_channel_limit=declared_limit,
        rank_rows=rank_rows,
        innovation_rows=innovations,
        submodularity_rows=submodularity,
    )


def _sufficiency_certificate(
    system: ReceiptSystem,
) -> ReceiptSufficiencyCertificate:
    if len(system.channel_names) <= 12:
        return system.minimum_sufficient_channels(exact_limit=12)
    return system.verified_greedy_sufficient_channels()


@dataclass(frozen=True, slots=True)
class ATOM3DAdapterReceipt:
    declarations: AdapterDeclarations
    assignment_domain: tuple[Hashable, ...]
    source_law_provenance: str
    source_probabilities: tuple[Fraction, ...]
    symmetry_partition_id: str
    visible_partition_id: str
    kept_augmented_partition_id: str
    symmetry_orbit_multiplicities: tuple[int, ...]
    visible_fiber_multiplicities: tuple[int, ...]
    kept_fiber_multiplicities: tuple[int, ...]
    symmetry_refines_visible: bool
    visible_refines_symmetry: bool
    partitions_equivalent: bool
    kept_refines_visible: bool
    kept_refines_symmetry: bool
    sufficiency_certificate: ReceiptSufficiencyCertificate
    rank_table: ExactInnovationSubmodularRankTable
    geometry_inference_performed: bool = False
    scale_inference_performed: bool = False
    binding_inference_performed: bool = False
    energy_inference_performed: bool = False

    def __post_init__(self) -> None:
        if self.declarations != ATOM3D_DECLARATIONS:
            raise ApplicationAdapterContractError(
                "ATOM3D receipt authority declarations are not canonical"
            )
        if not isinstance(self.assignment_domain, tuple) or not self.assignment_domain:
            raise ApplicationAdapterContractError(
                "ATOM3D receipt requires an exact finite assignment domain"
            )
        _required_text(self.source_law_provenance, "source_law_provenance")
        if (
            not isinstance(self.source_probabilities, tuple)
            or len(self.source_probabilities) != len(self.assignment_domain)
            or any(type(value) is not Fraction for value in self.source_probabilities)
            or any(value <= 0 for value in self.source_probabilities)
            or sum(self.source_probabilities, Fraction()) != 1
        ):
            raise ApplicationAdapterContractError(
                "ATOM3D source probabilities must be exact Fractions summing to one"
            )
        for value, label in (
            (self.symmetry_partition_id, "symmetry_partition_id"),
            (self.visible_partition_id, "visible_partition_id"),
            (self.kept_augmented_partition_id, "kept_augmented_partition_id"),
        ):
            _required_text(value, label)
        if any(
            type(value) is not int or value < 1
            for rows in (
                self.symmetry_orbit_multiplicities,
                self.visible_fiber_multiplicities,
                self.kept_fiber_multiplicities,
            )
            for value in rows
        ):
            raise ApplicationAdapterContractError(
                "orbit and fiber multiplicities must be positive integers"
            )
        for value, label in (
            (self.symmetry_refines_visible, "symmetry_refines_visible"),
            (self.visible_refines_symmetry, "visible_refines_symmetry"),
            (self.partitions_equivalent, "partitions_equivalent"),
            (self.kept_refines_visible, "kept_refines_visible"),
            (self.kept_refines_symmetry, "kept_refines_symmetry"),
            (self.geometry_inference_performed, "geometry_inference_performed"),
            (self.scale_inference_performed, "scale_inference_performed"),
            (self.binding_inference_performed, "binding_inference_performed"),
            (self.energy_inference_performed, "energy_inference_performed"),
        ):
            _strict_bool(value, label)
        if self.partitions_equivalent != (
            self.symmetry_refines_visible and self.visible_refines_symmetry
        ):
            raise ApplicationAdapterContractError(
                "partition equivalence must agree with mutual refinement"
            )
        if not self.kept_refines_visible:
            raise ApplicationAdapterContractError(
                "the kept augmented partition must refine the visible partition"
            )
        domain_size = len(self.assignment_domain)
        if any(
            sum(rows) != domain_size
            for rows in (
                self.symmetry_orbit_multiplicities,
                self.visible_fiber_multiplicities,
                self.kept_fiber_multiplicities,
            )
        ):
            raise ApplicationAdapterContractError(
                "orbit and fiber multiplicities must each cover the assignment domain"
            )
        if any(
            (
                self.geometry_inference_performed,
                self.scale_inference_performed,
                self.binding_inference_performed,
                self.energy_inference_performed,
            )
        ):
            raise ApplicationAdapterContractError(
                "the finite ATOM3D adapter cannot infer physical conclusions"
            )
        if not isinstance(
            self.sufficiency_certificate, ReceiptSufficiencyCertificate
        ):
            raise ApplicationAdapterContractError(
                "ATOM3D receipt requires a sufficiency certificate"
            )
        if (
            self.sufficiency_certificate.visible_partition_id
            != self.visible_partition_id
            or self.sufficiency_certificate.augmented_partition_id
            != self.kept_augmented_partition_id
        ):
            raise ApplicationAdapterContractError(
                "ATOM3D sufficiency certificate belongs to different partitions"
            )
        if not isinstance(self.rank_table, ExactInnovationSubmodularRankTable):
            raise ApplicationAdapterContractError(
                "ATOM3D receipt requires a typed exact rank table"
            )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_ATOM3D_NONINSTALLING_ADAPTER_RECEIPT_V6",
            "declarations": self.declarations.to_dict(),
            "native_assignment_domain": [
                _strict_form(item) for item in self.assignment_domain
            ],
            "source_law": {
                "provenance": self.source_law_provenance,
                "probabilities": [
                    _fraction_dict(value) for value in self.source_probabilities
                ],
            },
            "partitions": {
                "symmetry_partition_id": self.symmetry_partition_id,
                "visible_partition_id": self.visible_partition_id,
                "kept_augmented_partition_id": self.kept_augmented_partition_id,
                "symmetry_refines_visible": self.symmetry_refines_visible,
                "visible_refines_symmetry": self.visible_refines_symmetry,
                "equivalent": self.partitions_equivalent,
                "kept_refines_visible": self.kept_refines_visible,
                "kept_refines_symmetry": self.kept_refines_symmetry,
            },
            "actual_multiplicities": {
                "symmetry_orbits": list(self.symmetry_orbit_multiplicities),
                "visible_fibers": list(self.visible_fiber_multiplicities),
                "kept_receipt_fibers": list(self.kept_fiber_multiplicities),
            },
            "sufficient_receipt_certificate": (
                self.sufficiency_certificate.to_dict()
            ),
            "exact_innovation_submodular_rank_table": self.rank_table.to_dict(),
            "inferences": {
                "geometry": False,
                "scale": False,
                "binding": False,
                "energy": False,
            },
        }


def adapt_atom3d(
    native_input: ATOM3DFiniteAssignmentInput,
) -> ATOM3DAdapterReceipt:
    """Expose exact finite ATOM3D partition custody without physical inference."""

    if type(native_input) is not ATOM3DFiniteAssignmentInput:
        raise ApplicationAdapterContractError(
            "ATOM3D accepts only ATOM3DFiniteAssignmentInput"
        )
    system = ReceiptSystem(
        native_input.visible_partition,
        native_input.kept_receipt_partitions,
    )
    kept = system.augmented(system.channel_names)
    symmetry = native_input.symmetry_partition
    visible = native_input.visible_partition
    return ATOM3DAdapterReceipt(
        declarations=ATOM3D_DECLARATIONS,
        assignment_domain=native_input.assignment_domain,
        source_law_provenance=native_input.source_law.provenance,
        source_probabilities=native_input.source_law.probabilities,
        symmetry_partition_id=symmetry.mathematical_id,
        visible_partition_id=visible.mathematical_id,
        kept_augmented_partition_id=kept.mathematical_id,
        symmetry_orbit_multiplicities=tuple(
            len(block) for block in symmetry.blocks
        ),
        visible_fiber_multiplicities=tuple(
            len(block) for block in visible.blocks
        ),
        kept_fiber_multiplicities=tuple(len(block) for block in kept.blocks),
        symmetry_refines_visible=symmetry.refines(visible),
        visible_refines_symmetry=visible.refines(symmetry),
        partitions_equivalent=symmetry.equivalent(visible),
        kept_refines_visible=kept.refines(visible),
        kept_refines_symmetry=kept.refines(symmetry),
        sufficiency_certificate=_sufficiency_certificate(system),
        rank_table=_rank_table(
            system,
            native_input.source_law,
            native_input.exact_rank_channel_limit,
        ),
    )


@dataclass(frozen=True, slots=True)
class FiniteHistoryMultiplicity:
    """Typed finite history count; it is not an analytic prime source."""

    history_space_id: str
    multiplicity: int
    provenance: str

    def __post_init__(self) -> None:
        _required_text(self.history_space_id, "history_space_id")
        multiplicity = _strict_int(self.multiplicity, "history multiplicity")
        if multiplicity < 1:
            raise ApplicationAdapterContractError(
                "history multiplicity must be positive"
            )
        _required_text(self.provenance, "history provenance")

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_FINITE_HISTORY_MULTIPLICITY_V6",
            "history_space_id": self.history_space_id,
            "multiplicity": self.multiplicity,
            "provenance": self.provenance,
            "analytic_prime_source_assigned": False,
        }


@dataclass(frozen=True, slots=True)
class ExplicitAnalyticPrimeSourceMap:
    """Caller-supplied map; its presence does not establish an RH sign."""

    map_id: str
    prime: int
    history_to_analytic_source: tuple[tuple[int, str], ...]
    provenance: str

    def __post_init__(self) -> None:
        _required_text(self.map_id, "map_id")
        prime = _strict_int(self.prime, "source-map prime")
        if not _is_prime(prime):
            raise ApplicationAdapterContractError(
                "source-map prime must be prime"
            )
        if not isinstance(self.history_to_analytic_source, tuple) or not (
            self.history_to_analytic_source
        ):
            raise ApplicationAdapterContractError(
                "analytic source map must contain explicit rows"
            )
        indices: list[int] = []
        for row in self.history_to_analytic_source:
            if not isinstance(row, tuple) or len(row) != 2:
                raise ApplicationAdapterContractError(
                    "analytic source map rows must be (history_index, source_label)"
                )
            index = _strict_int(row[0], "history index")
            if index < 0:
                raise ApplicationAdapterContractError(
                    "history indices cannot be negative"
                )
            _required_text(row[1], "analytic source label")
            indices.append(index)
        if tuple(indices) != tuple(range(len(indices))):
            raise ApplicationAdapterContractError(
                "analytic source map indices must be canonical and complete"
            )
        _required_text(self.provenance, "analytic source-map provenance")

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_EXPLICIT_ANALYTIC_PRIME_SOURCE_MAP_V6",
            "map_id": self.map_id,
            "prime": self.prime,
            "history_to_analytic_source": [
                {"history_index": index, "analytic_source": source}
                for index, source in self.history_to_analytic_source
            ],
            "provenance": self.provenance,
        }


def _is_prime(value: int) -> bool:
    if value < 2:
        return False
    if value % 2 == 0:
        return value == 2
    for divisor in range(3, isqrt(value) + 1, 2):
        if value % divisor == 0:
            return False
    return True


def _hd_power(base: HDSignature, exponent: int) -> HDSignature:
    """Exact binary exponentiation in HD coordinates."""

    result = HDSignature.from_rational(1)
    factor = base
    remaining = exponent
    while remaining:
        if remaining & 1:
            result = result.multiply(factor)
        remaining >>= 1
        if remaining:
            factor = factor.multiply(factor)
    return result


@dataclass(frozen=True, slots=True)
class RHPrimePowerAdapterReceipt:
    declarations: AdapterDeclarations
    prime: int
    exponent: int
    finite_history: FiniteHistoryMultiplicity
    prime_hd: HDSignature
    composed_prime_power_hd: HDSignature
    direct_prime_power_hd: HDSignature
    prime_formal_log: FormalLogElement
    scaled_prime_formal_log: FormalLogElement
    direct_prime_power_formal_log: FormalLogElement
    composition_residual: FormalLogElement
    exact_identity: str
    analytic_source_map: ExplicitAnalyticPrimeSourceMap | None
    analytic_source_interpretation_status: str
    rh_sign_inference: str = "NOT_PERFORMED"

    def __post_init__(self) -> None:
        if self.declarations != RH_DECLARATIONS:
            raise ApplicationAdapterContractError(
                "RH receipt authority declarations are not canonical"
            )
        prime = _strict_int(self.prime, "prime")
        exponent = _strict_int(self.exponent, "exponent")
        if not _is_prime(prime) or exponent < 1:
            raise ApplicationAdapterContractError(
                "RH prime-power receipt requires prime p and positive integer m"
            )
        if type(self.finite_history) is not FiniteHistoryMultiplicity:
            raise ApplicationAdapterContractError(
                "RH receipt requires typed finite history multiplicity"
            )
        expected_multiplicity = prime**exponent
        if self.finite_history.multiplicity != expected_multiplicity:
            raise ApplicationAdapterContractError(
                "finite history multiplicity must equal p^m"
            )
        if any(
            type(value) is not HDSignature
            for value in (
                self.prime_hd,
                self.composed_prime_power_hd,
                self.direct_prime_power_hd,
            )
        ):
            raise ApplicationAdapterContractError(
                "RH composition receipt requires typed HD signatures"
            )
        expected_prime_hd = HDSignature.from_rational(prime)
        expected_power_hd = HDSignature.from_rational(expected_multiplicity)
        if self.prime_hd != expected_prime_hd:
            raise ApplicationAdapterContractError("prime HD signature is inconsistent")
        if (
            self.composed_prime_power_hd != expected_power_hd
            or self.direct_prime_power_hd != expected_power_hd
        ):
            raise ApplicationAdapterContractError(
                "prime-power HD composition is inconsistent"
            )
        if any(
            type(value) is not FormalLogElement
            for value in (
                self.prime_formal_log,
                self.scaled_prime_formal_log,
                self.direct_prime_power_formal_log,
                self.composition_residual,
            )
        ):
            raise ApplicationAdapterContractError(
                "RH composition receipt requires typed FormalLogElement values"
            )
        expected_prime_log = FormalLogElement.from_coefficients(
            {prime: Fraction(1)}
        )
        expected_power_log = expected_prime_log.scale(exponent)
        if self.prime_formal_log != expected_prime_log:
            raise ApplicationAdapterContractError("prime formal log is inconsistent")
        if (
            self.scaled_prime_formal_log != expected_power_log
            or self.direct_prime_power_formal_log != expected_power_log
            or not self.composition_residual.is_zero
        ):
            raise ApplicationAdapterContractError(
                "L(p^m)=m*ln(p) composition receipt is inconsistent"
            )
        if self.exact_identity != f"L({prime}^{exponent}) = {exponent}*ln({prime})":
            raise ApplicationAdapterContractError(
                "RH finite-history identity string is not canonical"
            )
        if self.analytic_source_interpretation_status not in {
            "NOT_REQUESTED_NOT_INFERRED",
            "EXPLICIT_SOURCE_MAP_CARRIED_NO_SIGN_INFERENCE",
        }:
            raise ApplicationAdapterContractError(
                "unknown analytic source interpretation status"
            )
        if (
            self.analytic_source_interpretation_status
            == "EXPLICIT_SOURCE_MAP_CARRIED_NO_SIGN_INFERENCE"
        ) != (self.analytic_source_map is not None):
            raise ApplicationAdapterContractError(
                "analytic source-map custody is inconsistent"
            )
        if self.analytic_source_map is not None:
            if type(self.analytic_source_map) is not ExplicitAnalyticPrimeSourceMap:
                raise ApplicationAdapterContractError(
                    "analytic source map has the wrong type"
                )
            if (
                self.analytic_source_map.prime != prime
                or len(self.analytic_source_map.history_to_analytic_source)
                != expected_multiplicity
            ):
                raise ApplicationAdapterContractError(
                    "analytic source map does not match the finite prime-power source"
                )
        if self.rh_sign_inference != "NOT_PERFORMED":
            raise ApplicationAdapterContractError(
                "the finite RH adapter cannot infer an RH sign"
            )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_RH_PRIME_POWER_NONINSTALLING_ADAPTER_RECEIPT_V6",
            "declarations": self.declarations.to_dict(),
            "native_input": {
                "prime": self.prime,
                "exponent": self.exponent,
                "finite_history": self.finite_history.to_dict(),
            },
            "hd_composition": {
                "prime": self.prime_hd.to_dict(),
                "composed_prime_power": self.composed_prime_power_hd.to_dict(),
                "direct_prime_power": self.direct_prime_power_hd.to_dict(),
                "composition_matches": (
                    self.composed_prime_power_hd == self.direct_prime_power_hd
                ),
            },
            "formal_log_composition": {
                "L_p": self.prime_formal_log.to_dict(),
                "m_times_L_p": self.scaled_prime_formal_log.to_dict(),
                "L_p_to_m": self.direct_prime_power_formal_log.to_dict(),
                "residual": self.composition_residual.to_dict(),
                "identity": self.exact_identity,
            },
            "analytic_source_map": (
                None
                if self.analytic_source_map is None
                else self.analytic_source_map.to_dict()
            ),
            "analytic_source_interpretation_status": (
                self.analytic_source_interpretation_status
            ),
            "rh_sign_inference": self.rh_sign_inference,
        }


def adapt_rh_prime_power(
    prime: int,
    exponent: int,
    finite_history: FiniteHistoryMultiplicity,
    *,
    interpret_as_analytic_prime_source: bool = False,
    analytic_source_map: ExplicitAnalyticPrimeSourceMap | None = None,
    request_rh_sign_inference: bool = False,
) -> RHPrimePowerAdapterReceipt:
    """Return a finite prime-power receipt and no analytic RH conclusion."""

    p = _strict_int(prime, "prime")
    m = _strict_int(exponent, "exponent")
    if not _is_prime(p):
        raise ApplicationAdapterContractError("p must be a positive prime")
    if m < 1:
        raise ApplicationAdapterContractError("m must be a positive integer")
    if type(finite_history) is not FiniteHistoryMultiplicity:
        raise ApplicationAdapterContractError(
            "RH adapter requires FiniteHistoryMultiplicity"
        )
    expected_multiplicity = p**m
    if finite_history.multiplicity != expected_multiplicity:
        raise ApplicationAdapterContractError(
            "finite history multiplicity must equal p^m"
        )
    interpret = _strict_bool(
        interpret_as_analytic_prime_source,
        "interpret_as_analytic_prime_source",
    )
    request_sign = _strict_bool(
        request_rh_sign_inference, "request_rh_sign_inference"
    )
    if request_sign:
        raise ApplicationAdapterContractError(
            "this finite adapter never infers an RH sign"
        )
    if interpret and analytic_source_map is None:
        raise ApplicationAdapterContractError(
            "analytic prime-source interpretation requires a separately explicit source map"
        )
    if not interpret and analytic_source_map is not None:
        raise ApplicationAdapterContractError(
            "an analytic source map requires an explicit interpretation request"
        )
    if analytic_source_map is not None:
        if type(analytic_source_map) is not ExplicitAnalyticPrimeSourceMap:
            raise ApplicationAdapterContractError(
                "analytic_source_map has the wrong type"
            )
        if analytic_source_map.prime != p:
            raise ApplicationAdapterContractError(
                "analytic source-map prime does not match p"
            )
        if len(analytic_source_map.history_to_analytic_source) != expected_multiplicity:
            raise ApplicationAdapterContractError(
                "analytic source map must cover the exact finite history domain"
            )

    base_hd = HDSignature.from_rational(p)
    composed_hd = _hd_power(base_hd, m)
    direct_hd = HDSignature.from_rational(expected_multiplicity)
    prime_log = FormalLogElement.from_coefficients({p: Fraction(1)})
    scaled_log = prime_log.scale(m)
    direct_log = direct_hd.formal_log
    residual = direct_log - scaled_log
    return RHPrimePowerAdapterReceipt(
        declarations=RH_DECLARATIONS,
        prime=p,
        exponent=m,
        finite_history=finite_history,
        prime_hd=base_hd,
        composed_prime_power_hd=composed_hd,
        direct_prime_power_hd=direct_hd,
        prime_formal_log=prime_log,
        scaled_prime_formal_log=scaled_log,
        direct_prime_power_formal_log=direct_log,
        composition_residual=residual,
        exact_identity=f"L({p}^{m}) = {m}*ln({p})",
        analytic_source_map=analytic_source_map,
        analytic_source_interpretation_status=(
            "NOT_REQUESTED_NOT_INFERRED"
            if analytic_source_map is None
            else "EXPLICIT_SOURCE_MAP_CARRIED_NO_SIGN_INFERENCE"
        ),
    )


__all__ = (
    "ATOM3DAdapterReceipt",
    "ATOM3D_DECLARATIONS",
    "ATOM3DFiniteAssignmentInput",
    "AdapterDeclarations",
    "ApplicationAdapterContractError",
    "BennettLivenessCertificate",
    "ExactInnovationRow",
    "ExactInnovationSubmodularRankTable",
    "ExactRankRow",
    "ExactSubmodularityRow",
    "ExplicitAnalyticPrimeSourceMap",
    "FiniteHistoryMultiplicity",
    "NONINSTALLING_CROSSWALK_ONLY",
    "RANK_TABLE_BOUND_EXCEEDED",
    "RANK_TABLE_EXECUTED",
    "RHPrimePowerAdapterReceipt",
    "RH_DECLARATIONS",
    "STARBREAKER_DECLARATIONS",
    "StarbreakerAdapterReceipt",
    "adapt_atom3d",
    "adapt_rh_prime_power",
    "adapt_starbreaker",
)
