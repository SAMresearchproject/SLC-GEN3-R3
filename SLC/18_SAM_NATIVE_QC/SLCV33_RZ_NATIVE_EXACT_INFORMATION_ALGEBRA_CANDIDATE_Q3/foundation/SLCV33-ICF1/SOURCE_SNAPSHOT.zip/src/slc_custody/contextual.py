"""Generic context C and local-program J custody over native finite morphisms."""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass
from fractions import Fraction
from typing import Generic, Hashable, Iterable, TypeVar

from .algebra import PrimeLogWeight, SymbolicEntropy
from .compiler import (
    CompiledCustodyMorphism,
    FiberReceipt,
    _container_bits,
    _stable_bytes,
    _stable_form,
    _stable_sort,
)
from .control import unpack_z4
from .events import ResetRecord, declare_reset
from .exact import conditional_entropy_of
from .roster import RosterCatalog
from .adapters import z4_translation_morphism


X = TypeVar("X", bound=Hashable)
Y = TypeVar("Y", bound=Hashable)
Z = TypeVar("Z", bound=Hashable)
C = TypeVar("C", bound=Hashable)
J = TypeVar("J", bound=Hashable)


def _weight(multiplicity: int) -> dict[str, object]:
    return PrimeLogWeight.from_multiplicity(multiplicity).to_dict()


@dataclass(frozen=True, slots=True)
class ContextProgram(Generic[J, X, Y]):
    """One local identity J and its selected native morphism f_(C,J)."""

    local_identity: J
    morphism: CompiledCustodyMorphism[X, Y]


class ContextRoster(Generic[C, J, X, Y]):
    """One context identity C and its conditioned-known mapping rho_C."""

    def __init__(
        self,
        context: C,
        programs: Iterable[ContextProgram[J, X, Y]],
    ) -> None:
        try:
            hash(context)
        except TypeError as exc:
            raise TypeError("context identity C must be hashable") from exc
        self.context = context
        self.programs = tuple(programs)
        if not self.programs:
            raise ValueError("context roster cannot be empty")
        locals_seen: set[J] = set()
        common_domain = self.programs[0].morphism.domain
        for program in self.programs:
            try:
                hash(program.local_identity)
            except TypeError as exc:
                raise TypeError("local program identity J must be hashable") from exc
            if program.local_identity in locals_seen:
                raise ValueError("rho_C contains duplicate local identities")
            locals_seen.add(program.local_identity)
            if program.morphism.domain != common_domain:
                raise ValueError("every f_(C,J) must have the same data domain")
        self.data_domain = common_domain
        self._program_by_local = {
            program.local_identity: program for program in self.programs
        }
        digest = hashlib.sha256()
        digest.update(b"SLC_GENERIC_CONTEXT_ROSTER\0")
        digest.update(_stable_bytes(context))
        for program in self.programs:
            digest.update(_stable_bytes(program.local_identity))
            digest.update(program.morphism.morphism_id.encode("ascii"))
        self.roster_id = digest.hexdigest()

    @property
    def local_identities(self) -> tuple[J, ...]:
        return tuple(program.local_identity for program in self.programs)

    def program(self, local_identity: J) -> ContextProgram[J, X, Y]:
        try:
            return self._program_by_local[local_identity]
        except KeyError as exc:
            raise ValueError("local program J is outside rho_C") from exc

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_GENERIC_CONTEXT_ROSTER_V5",
            "context": _stable_form(self.context),
            "roster_id": self.roster_id,
            "conditioned_known_mapping": True,
            "local_program_count": len(self.programs),
            "local_program_support_weight": _weight(len(self.programs)),
            "programs": [
                {
                    "local_identity": _stable_form(program.local_identity),
                    "selected_morphism_id": program.morphism.morphism_id,
                }
                for program in self.programs
            ],
        }


@dataclass(frozen=True, slots=True)
class ContextualInput(Generic[X, C, J]):
    data: X
    context: C
    local_program: J


@dataclass(frozen=True, slots=True)
class ContextIdentityReceipt:
    schema: str
    contextual_morphism_id: str
    catalog_id: str
    visible_context_multiplicity: int
    context_index: int
    container_bits: int
    exact_information_nats: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class LocalProgramIdentityReceipt:
    schema: str
    contextual_morphism_id: str
    catalog_id: str
    context_roster_id: str
    visible_local_multiplicity: int
    local_index: int
    container_bits: int
    exact_information_nats: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ContextualHierarchicalReceipt:
    schema: str
    contextual_morphism_id: str
    roster_identity: ContextIdentityReceipt
    roster_local_program: LocalProgramIdentityReceipt
    data_fiber: FiberReceipt

    @property
    def container_bits(self) -> int:
        return (
            self.roster_identity.container_bits
            + self.roster_local_program.container_bits
            + self.data_fiber.container_bits
        )

    @property
    def hierarchical_support_product_multiplicity(self) -> int:
        """Product of branchwise support sizes, not Shannon information."""

        return (
            self.roster_identity.visible_context_multiplicity
            * self.roster_local_program.visible_local_multiplicity
            * self.data_fiber.fiber_multiplicity
        )

    @property
    def exact_hierarchical_support_nats(self) -> str:
        return PrimeLogWeight.from_multiplicity(
            self.hierarchical_support_product_multiplicity
        ).expression

    @property
    def information_multiplicity(self) -> int:
        """V5 compatibility alias; use hierarchical_support_product_multiplicity."""

        return self.hierarchical_support_product_multiplicity

    @property
    def exact_information_nats(self) -> str:
        """V5 compatibility alias; this is Hartley support, not Shannon entropy."""

        return self.exact_hierarchical_support_nats

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.schema,
            "contextual_morphism_id": self.contextual_morphism_id,
            "roster_identity": self.roster_identity.to_dict(),
            "roster_local_program": self.roster_local_program.to_dict(),
            "data_fiber": self.data_fiber.to_dict(),
            "container_bits": self.container_bits,
            "hierarchical_support_product_multiplicity": (
                self.hierarchical_support_product_multiplicity
            ),
            "exact_hierarchical_support_nats": self.exact_hierarchical_support_nats,
            "legacy_v5_aliases_retained_in_python_api": [
                "information_multiplicity",
                "exact_information_nats",
            ],
        }


@dataclass(frozen=True, slots=True)
class DirectContextualReceipt:
    schema: str
    contextual_morphism_id: str
    visible_fiber_multiplicity: int
    direct_index: int
    container_bits: int
    exact_information_nats: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ContextualState(Generic[Y]):
    visible: Y
    receipt: ContextualHierarchicalReceipt


@dataclass(frozen=True, slots=True)
class DirectContextualState(Generic[Y]):
    visible: Y
    receipt: DirectContextualReceipt


@dataclass(frozen=True, slots=True)
class ContextualObservationContract:
    schema: str
    name: str
    input_state: tuple[str, ...]
    conditioned_known: tuple[str, ...]
    visible_after: tuple[str, ...]
    reconstruction_target: tuple[str, ...]
    hierarchical_receipt: tuple[str, ...]
    direct_receipt: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ContextualFiberProfile:
    schema: str
    contextual_morphism_id: str
    name: str
    source_state_count: int
    data_state_count: int
    context_count: int
    context_local_pair_count: int
    visible_output_count: int
    direct_fiber_strata: tuple[tuple[int, int], ...]
    expected_direct_information: SymbolicEntropy
    expected_hierarchical_chain_information: SymbolicEntropy
    information_chain_rule_residual: SymbolicEntropy
    expected_hierarchical_support_weight: SymbolicEntropy
    expected_support_weight_overhead: SymbolicEntropy
    worst_case_direct_support_capacity: PrimeLogWeight
    worst_case_hierarchical_support_capacity: PrimeLogWeight
    expected_direct_container_bits_exact: Fraction
    expected_hierarchical_container_bits_exact: Fraction
    worst_case_direct_container_bits: int
    worst_case_hierarchical_container_bits: int
    direct_augmented_map_injective: bool
    hierarchical_augmented_map_injective: bool

    @property
    def worst_case_direct_information(self) -> PrimeLogWeight:
        """V5 compatibility alias; this quantity is Hartley support."""

        return self.worst_case_direct_support_capacity

    @property
    def worst_case_hierarchical_information(self) -> PrimeLogWeight:
        """V5 compatibility alias; this quantity is Hartley support."""

        return self.worst_case_hierarchical_support_capacity

    @property
    def expected_direct_container_bits(self) -> float:
        """V5 derived compatibility view; the exact Fraction is authoritative."""

        return float(self.expected_direct_container_bits_exact)

    @property
    def expected_hierarchical_container_bits(self) -> float:
        """V5 derived compatibility view; the exact Fraction is authoritative."""

        return float(self.expected_hierarchical_container_bits_exact)

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.schema,
            "contextual_morphism_id": self.contextual_morphism_id,
            "name": self.name,
            "source_state_count": self.source_state_count,
            "data_state_count": self.data_state_count,
            "context_count": self.context_count,
            "context_local_pair_count": self.context_local_pair_count,
            "visible_output_count": self.visible_output_count,
            "direct_fiber_strata": [
                {
                    "visible_fiber_multiplicity": multiplicity,
                    "visible_output_count": count,
                    "exact_support_capacity": _weight(multiplicity),
                }
                for multiplicity, count in self.direct_fiber_strata
            ],
            "expected_direct_information": self.expected_direct_information.to_dict(),
            "expected_hierarchical_chain_information": self.expected_hierarchical_chain_information.to_dict(),
            "information_chain_rule_residual": self.information_chain_rule_residual.to_dict(),
            "expected_hierarchical_support_weight": self.expected_hierarchical_support_weight.to_dict(),
            "expected_support_weight_overhead": self.expected_support_weight_overhead.to_dict(),
            "worst_case_direct_support_capacity": self.worst_case_direct_support_capacity.to_dict(),
            "worst_case_hierarchical_support_capacity": self.worst_case_hierarchical_support_capacity.to_dict(),
            "expected_direct_container_bits_exact": {
                "numerator": self.expected_direct_container_bits_exact.numerator,
                "denominator": self.expected_direct_container_bits_exact.denominator,
            },
            "expected_hierarchical_container_bits_exact": {
                "numerator": self.expected_hierarchical_container_bits_exact.numerator,
                "denominator": self.expected_hierarchical_container_bits_exact.denominator,
            },
            "legacy_v5_python_aliases": [
                "worst_case_direct_information",
                "worst_case_hierarchical_information",
                "expected_direct_container_bits",
                "expected_hierarchical_container_bits",
            ],
            "worst_case_direct_container_bits": self.worst_case_direct_container_bits,
            "worst_case_hierarchical_container_bits": self.worst_case_hierarchical_container_bits,
            "direct_augmented_map_injective": self.direct_augmented_map_injective,
            "hierarchical_augmented_map_injective": self.hierarchical_augmented_map_injective,
        }


class CompiledContextualCustodyMorphism(Generic[X, C, J, Y]):
    """Compile (X,C,J) -> Y with rho_C and both typed and direct receipts."""

    def __init__(
        self,
        name: str,
        rosters: Iterable[ContextRoster[C, J, X, Y]],
        *,
        source_references: tuple[str, ...] = (),
    ) -> None:
        self.name = str(name)
        self.rosters = tuple(rosters)
        self.source_references = tuple(source_references)
        if not self.name:
            raise ValueError("contextual morphism name cannot be empty")
        if not self.rosters:
            raise ValueError("contextual morphism requires at least one context roster")
        contexts = tuple(roster.context for roster in self.rosters)
        if len(set(contexts)) != len(contexts):
            raise ValueError("context catalog contains duplicate C identities")
        common_domain = self.rosters[0].data_domain
        if any(roster.data_domain != common_domain for roster in self.rosters):
            raise ValueError("every context roster must share one data domain")
        self.data_domain = common_domain
        self._roster_by_context = {roster.context: roster for roster in self.rosters}

        catalog_digest = hashlib.sha256()
        catalog_digest.update(b"SLC_GENERIC_CONTEXT_CATALOG\0")
        for roster in self.rosters:
            catalog_digest.update(roster.roster_id.encode("ascii"))
        self.catalog_id = catalog_digest.hexdigest()

        source_states: list[ContextualInput[X, C, J]] = []
        visible_by_source: dict[ContextualInput[X, C, J], Y] = {}
        mutable_direct_fibers: dict[Y, list[ContextualInput[X, C, J]]] = {}
        for roster in self.rosters:
            for program in roster.programs:
                for data in self.data_domain:
                    source = ContextualInput(data, roster.context, program.local_identity)
                    visible = program.morphism.visible(data)
                    source_states.append(source)
                    visible_by_source[source] = visible
                    mutable_direct_fibers.setdefault(visible, []).append(source)
        self.domain = tuple(source_states)
        self._visible_by_source = visible_by_source
        self._direct_fibers = {
            visible: _stable_sort(fiber)
            for visible, fiber in mutable_direct_fibers.items()
        }
        self._direct_index = {
            source: index
            for fiber in self._direct_fibers.values()
            for index, source in enumerate(fiber)
        }

        self._contexts_by_visible: dict[Y, tuple[C, ...]] = {}
        self._locals_by_visible_context: dict[tuple[Y, C], tuple[J, ...]] = {}
        for visible in self._direct_fibers:
            context_set = {source.context for source in self._direct_fibers[visible]}
            self._contexts_by_visible[visible] = tuple(
                roster.context for roster in self.rosters if roster.context in context_set
            )
            for roster in self.rosters:
                if roster.context not in context_set:
                    continue
                local_set = {
                    source.local_program
                    for source in self._direct_fibers[visible]
                    if source.context == roster.context
                }
                self._locals_by_visible_context[(visible, roster.context)] = tuple(
                    program.local_identity
                    for program in roster.programs
                    if program.local_identity in local_set
                )

        digest = hashlib.sha256()
        digest.update(b"SLC_COMPILED_CONTEXTUAL_CUSTODY_MORPHISM_V5\0")
        digest.update(self.name.encode("utf-8"))
        digest.update(self.catalog_id.encode("ascii"))
        for source in self.domain:
            digest.update(_stable_bytes(source))
            digest.update(b"->")
            digest.update(_stable_bytes(self._visible_by_source[source]))
        self.contextual_morphism_id = digest.hexdigest()
        self.observation_contract = ContextualObservationContract(
            schema="SLC_CONTEXTUAL_OBSERVATION_CONTRACT_V5",
            name=self.name,
            input_state=("X", "C", "J"),
            conditioned_known=("compiled context catalog", "rho_C", "selected f_(C,J)"),
            visible_after=("Y",),
            reconstruction_target=("X", "C", "J"),
            hierarchical_receipt=("R_C", "R_J_GIVEN_Y_C", "R_X_GIVEN_Y_C_J"),
            direct_receipt=("R_X_C_J_GIVEN_Y",),
        )
        self.profile = self._build_profile()

    @property
    def visible_outputs(self) -> tuple[Y, ...]:
        return _stable_sort(self._direct_fibers)

    def roster(self, context: C) -> ContextRoster[C, J, X, Y]:
        try:
            return self._roster_by_context[context]
        except KeyError as exc:
            raise ValueError("context C is outside the compiled catalog") from exc

    def selected_morphism(
        self,
        context: C,
        local_program: J,
    ) -> CompiledCustodyMorphism[X, Y]:
        return self.roster(context).program(local_program).morphism

    def visible(self, data: X, context: C, local_program: J) -> Y:
        source = ContextualInput(data, context, local_program)
        try:
            return self._visible_by_source[source]
        except KeyError as exc:
            raise ValueError("(X,C,J) is outside the compiled contextual domain") from exc

    def _build_profile(self) -> ContextualFiberProfile:
        total = len(self.domain)
        strata: dict[int, int] = {}
        direct_terms = []
        hierarchical_terms = []
        expected_direct_bits = Fraction()
        expected_hierarchical_bits = Fraction()
        worst_direct = 1
        worst_hierarchical = 1
        for source in self.domain:
            visible = self._visible_by_source[source]
            direct_count = len(self._direct_fibers[visible])
            context_count = len(self._contexts_by_visible[visible])
            local_count = len(
                self._locals_by_visible_context[(visible, source.context)]
            )
            data_count = len(
                self.selected_morphism(
                    source.context, source.local_program
                ).fiber(visible)
            )
            hierarchical_count = context_count * local_count * data_count
            probability = Fraction(1, total)
            direct_terms.append(SymbolicEntropy.weighted_log(direct_count, probability))
            hierarchical_terms.append(
                SymbolicEntropy.weighted_log(hierarchical_count, probability)
            )
            expected_direct_bits += probability * _container_bits(direct_count)
            expected_hierarchical_bits += probability * (
                _container_bits(context_count)
                + _container_bits(local_count)
                + _container_bits(data_count)
            )
            worst_direct = max(worst_direct, direct_count)
            worst_hierarchical = max(worst_hierarchical, hierarchical_count)
        for fiber in self._direct_fibers.values():
            strata[len(fiber)] = strata.get(len(fiber), 0) + 1
        direct_information = SymbolicEntropy.sum(direct_terms)
        hierarchical_support_weight = SymbolicEntropy.sum(hierarchical_terms)
        atoms = tuple(({
            "X": source.data,
            "C": source.context,
            "J": source.local_program,
            "Y": self._visible_by_source[source],
        }, Fraction(1, total)) for source in self.domain)
        hierarchical_chain_information = SymbolicEntropy.sum((
            conditional_entropy_of(atoms, ("C",), ("Y",)),
            conditional_entropy_of(atoms, ("J",), ("Y", "C")),
            conditional_entropy_of(atoms, ("X",), ("Y", "C", "J")),
        ))
        return ContextualFiberProfile(
            schema="SLC_CONTEXTUAL_FIBER_PROFILE_V5",
            contextual_morphism_id=self.contextual_morphism_id,
            name=self.name,
            source_state_count=total,
            data_state_count=len(self.data_domain),
            context_count=len(self.rosters),
            context_local_pair_count=sum(len(roster.programs) for roster in self.rosters),
            visible_output_count=len(self._direct_fibers),
            direct_fiber_strata=tuple(sorted(strata.items())),
            expected_direct_information=direct_information,
            expected_hierarchical_chain_information=hierarchical_chain_information,
            information_chain_rule_residual=hierarchical_chain_information - direct_information,
            expected_hierarchical_support_weight=hierarchical_support_weight,
            expected_support_weight_overhead=hierarchical_support_weight - direct_information,
            worst_case_direct_support_capacity=PrimeLogWeight.from_multiplicity(worst_direct),
            worst_case_hierarchical_support_capacity=PrimeLogWeight.from_multiplicity(worst_hierarchical),
            expected_direct_container_bits_exact=expected_direct_bits,
            expected_hierarchical_container_bits_exact=expected_hierarchical_bits,
            worst_case_direct_container_bits=_container_bits(worst_direct),
            worst_case_hierarchical_container_bits=_container_bits(worst_hierarchical),
            direct_augmented_map_injective=True,
            hierarchical_augmented_map_injective=True,
        )

    def execute(self, data: X, context: C, local_program: J) -> ContextualState[Y]:
        visible = self.visible(data, context, local_program)
        contexts = self._contexts_by_visible[visible]
        locals_for_context = self._locals_by_visible_context[(visible, context)]
        roster = self.roster(context)
        selected = roster.program(local_program).morphism
        data_state = selected.encode(data)
        context_count = len(contexts)
        local_count = len(locals_for_context)
        receipt = ContextualHierarchicalReceipt(
            schema="SLC_CONTEXTUAL_HIERARCHICAL_RECEIPT_V5",
            contextual_morphism_id=self.contextual_morphism_id,
            roster_identity=ContextIdentityReceipt(
                schema="SLC_CONTEXT_IDENTITY_RECEIPT_V5",
                contextual_morphism_id=self.contextual_morphism_id,
                catalog_id=self.catalog_id,
                visible_context_multiplicity=context_count,
                context_index=contexts.index(context),
                container_bits=_container_bits(context_count),
                exact_information_nats=PrimeLogWeight.from_multiplicity(
                    context_count
                ).expression,
            ),
            roster_local_program=LocalProgramIdentityReceipt(
                schema="SLC_LOCAL_PROGRAM_IDENTITY_RECEIPT_V5",
                contextual_morphism_id=self.contextual_morphism_id,
                catalog_id=self.catalog_id,
                context_roster_id=roster.roster_id,
                visible_local_multiplicity=local_count,
                local_index=locals_for_context.index(local_program),
                container_bits=_container_bits(local_count),
                exact_information_nats=PrimeLogWeight.from_multiplicity(
                    local_count
                ).expression,
            ),
            data_fiber=data_state.receipt,
        )
        return ContextualState(visible, receipt)

    def reconstruct(
        self,
        visible: Y,
        receipt: ContextualHierarchicalReceipt,
    ) -> ContextualInput[X, C, J]:
        if receipt.contextual_morphism_id != self.contextual_morphism_id:
            raise ValueError("receipt belongs to a different contextual morphism")
        context_receipt = receipt.roster_identity
        if (
            context_receipt.contextual_morphism_id != self.contextual_morphism_id
            or context_receipt.catalog_id != self.catalog_id
        ):
            raise ValueError("R_C belongs to a different context catalog")
        contexts = self._contexts_by_visible[visible]
        if context_receipt.visible_context_multiplicity != len(contexts):
            raise ValueError("R_C multiplicity does not match the visible context fiber")
        if not 0 <= context_receipt.context_index < len(contexts):
            raise ValueError("R_C index is outside the visible context fiber")
        context = contexts[context_receipt.context_index]
        roster = self.roster(context)

        local_receipt = receipt.roster_local_program
        if (
            local_receipt.contextual_morphism_id != self.contextual_morphism_id
            or local_receipt.catalog_id != self.catalog_id
            or local_receipt.context_roster_id != roster.roster_id
        ):
            raise ValueError("R_J|C belongs to a different context roster")
        locals_for_context = self._locals_by_visible_context[(visible, context)]
        if local_receipt.visible_local_multiplicity != len(locals_for_context):
            raise ValueError("R_J|C multiplicity does not match the local visible fiber")
        if not 0 <= local_receipt.local_index < len(locals_for_context):
            raise ValueError("R_J|C index is outside the local visible fiber")
        local_program = locals_for_context[local_receipt.local_index]
        data = self.selected_morphism(context, local_program).decode(
            visible, receipt.data_fiber
        )
        return ContextualInput(data, context, local_program)

    def execute_direct(
        self,
        data: X,
        context: C,
        local_program: J,
    ) -> DirectContextualState[Y]:
        source = ContextualInput(data, context, local_program)
        visible = self.visible(data, context, local_program)
        multiplicity = len(self._direct_fibers[visible])
        return DirectContextualState(
            visible,
            DirectContextualReceipt(
                schema="SLC_DIRECT_CONTEXTUAL_RECEIPT_V5",
                contextual_morphism_id=self.contextual_morphism_id,
                visible_fiber_multiplicity=multiplicity,
                direct_index=self._direct_index[source],
                container_bits=_container_bits(multiplicity),
                exact_information_nats=PrimeLogWeight.from_multiplicity(
                    multiplicity
                ).expression,
            ),
        )

    def reconstruct_direct(
        self,
        visible: Y,
        receipt: DirectContextualReceipt,
    ) -> ContextualInput[X, C, J]:
        if receipt.contextual_morphism_id != self.contextual_morphism_id:
            raise ValueError("direct receipt belongs to a different contextual morphism")
        fiber = self._direct_fibers[visible]
        if receipt.visible_fiber_multiplicity != len(fiber):
            raise ValueError("direct receipt multiplicity does not match visible fiber")
        if not 0 <= receipt.direct_index < len(fiber):
            raise ValueError("direct receipt index is outside visible fiber")
        return fiber[receipt.direct_index]

    def minimize_receipt(
        self,
        visible: Y,
        receipt: ContextualHierarchicalReceipt,
    ) -> DirectContextualReceipt:
        source = self.reconstruct(visible, receipt)
        return self.execute_direct(
            source.data, source.context, source.local_program
        ).receipt

    def expand_receipt(
        self,
        visible: Y,
        receipt: DirectContextualReceipt,
    ) -> ContextualHierarchicalReceipt:
        source = self.reconstruct_direct(visible, receipt)
        return self.execute(
            source.data, source.context, source.local_program
        ).receipt

    def discard_receipt(
        self,
        state: ContextualState[Y] | DirectContextualState[Y],
        *,
        physical_reset_declared: bool = False,
        temperature_kelvin: int | str | None = None,
    ) -> ResetRecord:
        if state.receipt.contextual_morphism_id != self.contextual_morphism_id:
            raise ValueError("state belongs to a different contextual morphism")
        multiplicity = len(self._direct_fibers[state.visible])
        return declare_reset(
            self.contextual_morphism_id,
            multiplicity,
            physical_reset_declared=physical_reset_declared,
            temperature_kelvin=temperature_kelvin,
        )

    def compose(
        self,
        after: CompiledCustodyMorphism[Y, Z],
        *,
        name: str | None = None,
    ) -> tuple["CompiledContextualCustodyMorphism[X, C, J, Z]", tuple[dict[str, object], ...]]:
        composed_rosters = []
        reports = []
        for roster in self.rosters:
            programs = []
            for program in roster.programs:
                composed, report = program.morphism.compose(after)
                programs.append(ContextProgram(program.local_identity, composed))
                reports.append({
                    "context": _stable_form(roster.context),
                    "local_program": _stable_form(program.local_identity),
                    "report": report,
                })
            composed_rosters.append(ContextRoster(roster.context, programs))
        return (
            CompiledContextualCustodyMorphism(
                name or f"{after.name}_AFTER_{self.name}",
                composed_rosters,
                source_references=(self.contextual_morphism_id, after.morphism_id),
            ),
            tuple(reports),
        )

    def audit(self) -> dict[str, object]:
        hierarchical_failures = []
        direct_failures = []
        minimization_failures = []
        hierarchical_keys = set()
        direct_keys = set()
        for source in self.domain:
            state = self.execute(source.data, source.context, source.local_program)
            direct = self.execute_direct(
                source.data, source.context, source.local_program
            )
            if self.reconstruct(state.visible, state.receipt) != source:
                hierarchical_failures.append(_stable_form(source))
            if self.reconstruct_direct(direct.visible, direct.receipt) != source:
                direct_failures.append(_stable_form(source))
            minimized = self.minimize_receipt(state.visible, state.receipt)
            expanded = self.expand_receipt(direct.visible, direct.receipt)
            if minimized != direct.receipt or expanded != state.receipt:
                minimization_failures.append(_stable_form(source))
            hierarchical_keys.add((
                state.visible,
                state.receipt.roster_identity.context_index,
                state.receipt.roster_local_program.local_index,
                state.receipt.data_fiber.fiber_index,
            ))
            direct_keys.add((direct.visible, direct.receipt.direct_index))
        checks = {
            "hierarchical_reconstruction": not hierarchical_failures,
            "direct_reconstruction": not direct_failures,
            "receipt_minimization_round_trip": not minimization_failures,
            "hierarchical_augmented_injective": len(hierarchical_keys) == len(self.domain),
            "direct_augmented_injective": len(direct_keys) == len(self.domain),
            "information_chain_rule": self.profile.information_chain_rule_residual.expression == "0",
            "direct_worst_case_container_not_larger": (
                self.profile.worst_case_direct_container_bits
                <= self.profile.worst_case_hierarchical_container_bits
            ),
        }
        return {
            "schema": "SLC_CONTEXTUAL_CUSTODY_MORPHISM_AUDIT_V5",
            "contextual_morphism_id": self.contextual_morphism_id,
            "source_state_count": len(self.domain),
            "checks": checks,
            "checks_passed": sum(checks.values()),
            "checks_failed": len(checks) - sum(checks.values()),
            "hierarchical_failures": hierarchical_failures,
            "direct_failures": direct_failures,
            "minimization_failures": minimization_failures,
            "status": "PASS" if all(checks.values()) else "FAIL",
        }


def contextual_z4_from_catalog(
    catalog: RosterCatalog,
    *,
    name: str | None = None,
) -> CompiledContextualCustodyMorphism[int, int, int, int]:
    """Lift a V3 Z4 roster catalog into the generic contextual core."""

    rosters = []
    for context, roster in enumerate(catalog.rosters):
        programs = []
        for local_program, packed_program in enumerate(roster.programs):
            shift = unpack_z4(packed_program, catalog.power)
            programs.append(ContextProgram(
                local_program,
                z4_translation_morphism(catalog.power, shift),
            ))
        rosters.append(ContextRoster(context, programs))
    return CompiledContextualCustodyMorphism(
        name or f"GENERIC_CONTEXTUAL_{catalog.name}",
        rosters,
        source_references=(catalog.catalog_id, "P=rho_C(J)"),
    )
