"""Multistage contextual custody with exact receipt liveness certificates."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Generic, Hashable, Iterable, TypeVar

from .compiler import CompiledCustodyMorphism, FiberReceipt, _stable_bytes, _stable_form
from .contextual import (
    CompiledContextualCustodyMorphism,
    ContextualHierarchicalReceipt,
    ContextualInput,
    DirectContextualReceipt,
)
from .hd import FormalLogElement


X = TypeVar("X", bound=Hashable)
Y = TypeVar("Y", bound=Hashable)
C = TypeVar("C", bound=Hashable)
J = TypeVar("J", bound=Hashable)


@dataclass(frozen=True, slots=True)
class ContextualProgramReceipt:
    schema: str
    program_id: str
    initial_contextual_receipt: ContextualHierarchicalReceipt
    downstream_receipts: tuple[FiberReceipt, ...]

    @property
    def container_bits(self) -> int:
        return self.initial_contextual_receipt.container_bits + sum(
            receipt.container_bits for receipt in self.downstream_receipts
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.schema,
            "program_id": self.program_id,
            "initial_contextual_receipt": self.initial_contextual_receipt.to_dict(),
            "downstream_receipts": [
                receipt.to_dict() for receipt in self.downstream_receipts
            ],
            "container_bits": self.container_bits,
        }


@dataclass(frozen=True, slots=True)
class ContextualProgramState(Generic[Y]):
    visible: Y
    receipt: ContextualProgramReceipt


@dataclass(frozen=True, slots=True)
class CompiledContextualState(Generic[Y]):
    visible: Y
    receipt: DirectContextualReceipt


class CompiledContextualCustodyProgram(Generic[X, C, J]):
    """A contextual first stage followed by ordinary exact finite stages.

    The sequential receipt preserves every generated stage channel.  A
    separately compiled contextual morphism indexes the actual final fiber and
    is therefore the lossless final-receipt form used by liveness analysis.
    """

    def __init__(
        self,
        name: str,
        initial: CompiledContextualCustodyMorphism[X, C, J, Hashable],
        downstream: Iterable[CompiledCustodyMorphism[Hashable, Hashable]],
    ) -> None:
        self.name = str(name)
        if not self.name:
            raise ValueError("contextual custody program name cannot be empty")
        self.initial = initial
        self.downstream = tuple(downstream)
        visible_support = set(initial.visible_outputs)
        for stage in self.downstream:
            missing = visible_support - set(stage.domain)
            if missing:
                raise ValueError("downstream stage does not cover prior visible support")
            visible_support = {
                stage.visible(item) for item in visible_support
            }
        digest = hashlib.sha256()
        digest.update(b"SLC_MULTISTAGE_CONTEXTUAL_CUSTODY_PROGRAM_V6\0")
        digest.update(_stable_bytes(self.name))
        digest.update(initial.contextual_morphism_id.encode("ascii"))
        for stage in self.downstream:
            digest.update(stage.morphism_id.encode("ascii"))
        self.program_id = digest.hexdigest()
        compiled = initial
        reports: list[dict[str, object]] = []
        for stage_index, stage in enumerate(self.downstream, start=1):
            compiled, stage_reports = compiled.compose(
                stage, name=f"{self.name}_COMPILED_STAGE_{stage_index}"
            )
            reports.append(
                {
                    "stage_index": stage_index,
                    "stage_morphism_id": stage.morphism_id,
                    "selected_morphism_reports": list(stage_reports),
                }
            )
        self.compiled = compiled
        self.composition_reports = tuple(reports)

    @property
    def domain(self) -> tuple[ContextualInput[X, C, J], ...]:
        return self.initial.domain

    def execute(self, source: ContextualInput[X, C, J]) -> ContextualProgramState:
        state = self.initial.execute(
            source.data, source.context, source.local_program
        )
        visible: Hashable = state.visible
        receipts: list[FiberReceipt] = []
        for stage in self.downstream:
            next_state = stage.encode(visible)
            visible = next_state.visible
            receipts.append(next_state.receipt)
        return ContextualProgramState(
            visible,
            ContextualProgramReceipt(
                schema="SLC_MULTISTAGE_CONTEXTUAL_PROGRAM_RECEIPT_V6",
                program_id=self.program_id,
                initial_contextual_receipt=state.receipt,
                downstream_receipts=tuple(receipts),
            ),
        )

    def reconstruct(
        self, final_visible: Hashable, receipt: ContextualProgramReceipt
    ) -> ContextualInput[X, C, J]:
        if receipt.program_id != self.program_id:
            raise ValueError("receipt belongs to a different contextual program")
        if len(receipt.downstream_receipts) != len(self.downstream):
            raise ValueError("contextual program receipt has the wrong stage count")
        visible = final_visible
        for stage, stage_receipt in zip(
            reversed(self.downstream), reversed(receipt.downstream_receipts)
        ):
            visible = stage.decode(visible, stage_receipt)
        return self.initial.reconstruct(
            visible, receipt.initial_contextual_receipt
        )

    def execute_compiled(
        self, source: ContextualInput[X, C, J]
    ) -> CompiledContextualState:
        state = self.compiled.execute_direct(
            source.data, source.context, source.local_program
        )
        return CompiledContextualState(state.visible, state.receipt)

    def reconstruct_compiled(
        self, final_visible: Hashable, receipt: DirectContextualReceipt
    ) -> ContextualInput[X, C, J]:
        return self.compiled.reconstruct_direct(final_visible, receipt)

    def liveness_certificate(
        self, source: ContextualInput[X, C, J]
    ) -> dict[str, object]:
        """Copy the final minimal state, then reconstruct and clear temporaries."""

        sequential = self.execute(source)
        compiled = self.execute_compiled(source)
        reconstructed_sequential = self.reconstruct(
            sequential.visible, sequential.receipt
        )
        reconstructed_compiled = self.reconstruct_compiled(
            compiled.visible, compiled.receipt
        )
        same_final = sequential.visible == compiled.visible
        both_reconstruct = (
            reconstructed_sequential == source
            and reconstructed_compiled == source
        )
        schedule = [
            {
                "step": 0,
                "action": "COPY_FINAL_VISIBLE_AND_MINIMAL_RECEIPT",
                "kept_receipt_container_bits": compiled.receipt.container_bits,
            }
        ]
        for reverse_index, receipt in enumerate(
            reversed(sequential.receipt.downstream_receipts), start=1
        ):
            schedule.append(
                {
                    "step": reverse_index,
                    "action": "APPLY_DECLARED_STAGE_RECONSTRUCTION_AND_CLEAR_RECEIPT",
                    "morphism_id": receipt.morphism_id,
                    "cleared_container_bits": receipt.container_bits,
                }
            )
        schedule.append(
            {
                "step": len(schedule),
                "action": "APPLY_CONTEXTUAL_RECONSTRUCTION_AND_CLEAR_HIERARCHY",
                "contextual_morphism_id": self.initial.contextual_morphism_id,
                "cleared_container_bits": (
                    sequential.receipt.initial_contextual_receipt.container_bits
                ),
            }
        )
        return {
            "schema": "SLC_BENNETT_CONTEXTUAL_LIVENESS_CERTIFICATE_V6",
            "program_id": self.program_id,
            "source": _stable_form(source),
            "sequential_final_visible": _stable_form(sequential.visible),
            "compiled_final_visible": _stable_form(compiled.visible),
            "same_final_visible": same_final,
            "sequential_reconstructs": reconstructed_sequential == source,
            "compiled_reconstructs": reconstructed_compiled == source,
            "peak_live_receipt_container_bits": (
                sequential.receipt.container_bits
                + compiled.receipt.container_bits
            ),
            "temporary_receipt_container_bits": sequential.receipt.container_bits,
            "final_kept_receipt_container_bits": compiled.receipt.container_bits,
            "schedule": schedule,
            "logical_erasure_exact_nats": FormalLogElement.zero().to_dict(),
            "status": (
                "PASS_ZERO_ERASURE_UNCOMPUTATION"
                if same_final and both_reconstruct
                else "FAIL"
            ),
        }

    def audit(self) -> dict[str, object]:
        failures: list[dict[str, object]] = []
        maximum_peak = 0
        maximum_final = 0
        for source in self.domain:
            certificate = self.liveness_certificate(source)
            maximum_peak = max(
                maximum_peak, certificate["peak_live_receipt_container_bits"]
            )
            maximum_final = max(
                maximum_final, certificate["final_kept_receipt_container_bits"]
            )
            if certificate["status"] != "PASS_ZERO_ERASURE_UNCOMPUTATION":
                failures.append(certificate)
        return {
            "schema": "SLC_MULTISTAGE_CONTEXTUAL_PROGRAM_AUDIT_V6",
            "program_id": self.program_id,
            "source_state_count": len(self.domain),
            "downstream_stage_count": len(self.downstream),
            "composition_reports": list(self.composition_reports),
            "maximum_peak_live_receipt_container_bits": maximum_peak,
            "maximum_final_kept_receipt_container_bits": maximum_final,
            "logical_erasure_exact_nats": FormalLogElement.zero().to_dict(),
            "failure_count": len(failures),
            "failures": failures,
            "status": "PASS" if not failures else "FAIL",
        }


__all__ = (
    "CompiledContextualCustodyProgram",
    "CompiledContextualState",
    "ContextualProgramReceipt",
    "ContextualProgramState",
)
