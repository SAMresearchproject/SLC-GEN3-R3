"""Controlled Z4 actions with separately typed data and program custody."""

from __future__ import annotations

import hashlib
from dataclasses import asdict, dataclass
from typing import Iterable


from .algebra import PrimeLogWeight
from .events import ResetRecord, declare_reset


def unpack_z4(address: int, power: int) -> tuple[int, ...]:
    """Return the little-endian Z4 coordinates of one packed address."""

    n = int(power)
    size = 4**n
    value = int(address)
    if n < 1:
        raise ValueError("Z4 power must be positive")
    if not 0 <= value < size:
        raise ValueError("packed address is outside Z4^power")
    return tuple((value >> (2 * index)) & 3 for index in range(n))


def pack_z4(digits: Iterable[int]) -> int:
    """Pack canonical Z4 coordinates into one integer address."""

    value = 0
    observed = False
    for index, digit in enumerate(digits):
        coordinate = int(digit)
        if not 0 <= coordinate < 4:
            raise ValueError("Z4 coordinates must lie in {0,1,2,3}")
        observed = True
        value |= coordinate << (2 * index)
    if not observed:
        raise ValueError("at least one Z4 coordinate is required")
    return value


def _weight(multiplicity: int) -> dict[str, object]:
    return PrimeLogWeight.from_multiplicity(multiplicity).to_dict()


@dataclass(frozen=True, slots=True)
class ObservationContract:
    """Declare exactly what is input, known, visible, retained and reset."""

    schema: str
    name: str
    input_state: tuple[str, ...]
    conditioned_known: tuple[str, ...]
    visible_after: tuple[str, ...]
    retained_receipts: tuple[str, ...]
    reset_variables: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ControlProgramReceipt:
    """Canonical control coordinate inside one visible translation fiber."""

    schema: str
    action_id: str
    program_roster_multiplicity: int
    program_index: int
    control_address: int
    container_bits: int
    exact_information_nats: str

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class ControlChannelState:
    visible: int
    program_receipt: ControlProgramReceipt


@dataclass(frozen=True, slots=True)
class ControlObservation:
    """Exact accounting under one explicit observation contract."""

    schema: str
    contract: ObservationContract
    address_capacity: dict[str, object]
    ambient_program_capacity: dict[str, object]
    active_program_capacity: dict[str, object]
    joint_input_capacity: dict[str, object]
    hidden_data_given_visible_and_program: dict[str, object]
    hidden_control_given_visible: dict[str, object]
    hidden_joint_given_visible: dict[str, object]
    program_receipt_custody: dict[str, object]
    remaining_hidden_after_retained_receipts: dict[str, object]
    logical_erasure: dict[str, object]
    reset_record: ResetRecord | None = None

    def to_dict(self) -> dict[str, object]:
        payload = asdict(self)
        payload["contract"] = self.contract.to_dict()
        payload["reset_record"] = (
            None if self.reset_record is None else self.reset_record.to_dict()
        )
        return payload


class Z4ControlledTranslation:
    """The product action Y=X+P on Z4^n with native program receipts."""

    def __init__(
        self,
        power: int,
        *,
        program_roster: Iterable[int] | None = None,
    ) -> None:
        self.power = int(power)
        if self.power < 1:
            raise ValueError("Z4 power must be positive")
        self.size = 4**self.power
        if program_roster is None:
            roster = tuple(range(self.size))
        else:
            roster = tuple(sorted(int(program) for program in program_roster))
        if not roster:
            raise ValueError("program roster cannot be empty")
        if len(set(roster)) != len(roster):
            raise ValueError("program roster contains duplicates")
        if roster[0] < 0 or roster[-1] >= self.size:
            raise ValueError("program address is outside Z4^power")
        self.program_roster = roster
        self._program_index = {
            program: index for index, program in enumerate(self.program_roster)
        }
        digest = hashlib.sha256()
        digest.update(f"Z4_CONTROLLED_TRANSLATION_POWER_{self.power}\0".encode("ascii"))
        for program in self.program_roster:
            digest.update(program.to_bytes((2 * self.power + 7) // 8, "little"))
        self.action_id = digest.hexdigest()

    @property
    def program_count(self) -> int:
        return len(self.program_roster)

    def translate(self, data_address: int, control_address: int) -> int:
        data = unpack_z4(data_address, self.power)
        control = unpack_z4(control_address, self.power)
        return pack_z4((x + p) % 4 for x, p in zip(data, control))

    def inverse(self, visible_address: int, control_address: int) -> int:
        visible = unpack_z4(visible_address, self.power)
        control = unpack_z4(control_address, self.power)
        return pack_z4((y - p) % 4 for y, p in zip(visible, control))

    def execute_dynamic(
        self,
        data_address: int,
        control_address: int,
    ) -> ControlChannelState:
        if control_address not in self._program_index:
            raise ValueError("control is not in the active program roster")
        visible = self.translate(data_address, control_address)
        receipt = ControlProgramReceipt(
            schema="SLC_CUSTODY_NATIVE_CONTROL_PROGRAM_RECEIPT_V2",
            action_id=self.action_id,
            program_roster_multiplicity=self.program_count,
            program_index=self._program_index[control_address],
            control_address=control_address,
            container_bits=(self.program_count - 1).bit_length(),
            exact_information_nats=PrimeLogWeight.from_multiplicity(
                self.program_count
            ).expression,
        )
        return ControlChannelState(visible=visible, program_receipt=receipt)

    def reconstruct_dynamic(
        self,
        visible_address: int,
        receipt: ControlProgramReceipt,
    ) -> tuple[int, int]:
        if receipt.action_id != self.action_id:
            raise ValueError("receipt belongs to a different controlled action")
        if receipt.program_roster_multiplicity != self.program_count:
            raise ValueError("receipt program multiplicity does not match action")
        if not 0 <= receipt.program_index < self.program_count:
            raise ValueError("receipt program index is outside the roster")
        expected_control = self.program_roster[receipt.program_index]
        if receipt.control_address != expected_control:
            raise ValueError("receipt control address does not match canonical index")
        data = self.inverse(visible_address, expected_control)
        return data, expected_control

    def fixed_known_observation(self, control_address: int) -> ControlObservation:
        if not 0 <= int(control_address) < self.size:
            raise ValueError("fixed control is outside Z4^power")
        contract = ObservationContract(
            schema="SLC_CUSTODY_NATIVE_OBSERVATION_CONTRACT_V2",
            name="FIXED_KNOWN_TRANSLATION",
            input_state=("X",),
            conditioned_known=("P",),
            visible_after=("Y",),
            retained_receipts=(),
            reset_variables=(),
        )
        return self._observation(contract, active_program_count=1, receipt_count=1)

    def dynamic_retained_observation(self) -> ControlObservation:
        contract = ObservationContract(
            schema="SLC_CUSTODY_NATIVE_OBSERVATION_CONTRACT_V2",
            name="DYNAMIC_TRANSLATION_WITH_PROGRAM_RECEIPT",
            input_state=("X", "P"),
            conditioned_known=(),
            visible_after=("Y",),
            retained_receipts=("R_P",),
            reset_variables=(),
        )
        return self._observation(
            contract,
            active_program_count=self.program_count,
            receipt_count=self.program_count,
        )

    def dynamic_reset_observation(
        self,
        *,
        physical_reset_declared: bool = False,
        temperature_kelvin: int | str | None = None,
    ) -> ControlObservation:
        contract = ObservationContract(
            schema="SLC_CUSTODY_NATIVE_OBSERVATION_CONTRACT_V2",
            name="DYNAMIC_TRANSLATION_AFTER_PROGRAM_RECEIPT_RESET",
            input_state=("X", "P"),
            conditioned_known=(),
            visible_after=("Y",),
            retained_receipts=(),
            reset_variables=("R_P",),
        )
        reset = declare_reset(
            self.action_id,
            self.program_count,
            physical_reset_declared=physical_reset_declared,
            temperature_kelvin=temperature_kelvin,
        )
        return self._observation(
            contract,
            active_program_count=self.program_count,
            receipt_count=1,
            reset_record=reset,
        )

    def _observation(
        self,
        contract: ObservationContract,
        *,
        active_program_count: int,
        receipt_count: int,
        reset_record: ResetRecord | None = None,
    ) -> ControlObservation:
        hidden = active_program_count
        retained = receipt_count
        if hidden % retained:
            raise ValueError("retained receipt alphabet must divide hidden fiber")
        remaining = hidden // retained
        return ControlObservation(
            schema="SLC_CUSTODY_NATIVE_CONTROL_OBSERVATION_V2",
            contract=contract,
            address_capacity=_weight(self.size),
            ambient_program_capacity=_weight(self.size),
            active_program_capacity=_weight(active_program_count),
            joint_input_capacity=_weight(self.size * active_program_count),
            hidden_data_given_visible_and_program=_weight(1),
            hidden_control_given_visible=_weight(hidden),
            hidden_joint_given_visible=_weight(hidden),
            program_receipt_custody=_weight(retained),
            remaining_hidden_after_retained_receipts=_weight(remaining),
            logical_erasure=_weight(remaining if reset_record is not None else 1),
            reset_record=reset_record,
        )

    def audit_product_action(
        self,
        *,
        fixed_control: int,
        fixed_visible: int,
        cross_pair_count: int = 4096,
    ) -> dict[str, object]:
        """Audit the separable action without expanding its 4^(2n) joint table."""

        digit_pair_failures: list[tuple[int, int]] = []
        for x in range(4):
            for p in range(4):
                y = (x + p) % 4
                if (y - p) % 4 != x:
                    digit_pair_failures.append((x, p))

        fixed_failures: list[int] = []
        for data in range(self.size):
            visible = self.translate(data, fixed_control)
            if self.inverse(visible, fixed_control) != data:
                fixed_failures.append(data)

        control_failures: list[int] = []
        for control in self.program_roster:
            data = self.inverse(fixed_visible, control)
            state = self.execute_dynamic(data, control)
            reconstructed = self.reconstruct_dynamic(state.visible, state.program_receipt)
            if state.visible != fixed_visible or reconstructed != (data, control):
                control_failures.append(control)

        cross_failures: list[int] = []
        modulus = self.size
        for index in range(int(cross_pair_count)):
            data = (index * 65_537 + 17) % modulus
            control = self.program_roster[(index * 257 + 11) % self.program_count]
            state = self.execute_dynamic(data, control)
            if self.reconstruct_dynamic(state.visible, state.program_receipt) != (
                data,
                control,
            ):
                cross_failures.append(index)

        checks = {
            "all_16_coordinate_pairs_invert": not digit_pair_failures,
            "all_fixed_program_addresses_invert": not fixed_failures,
            "all_active_controls_reconstruct_at_fixed_visible": not control_failures,
            "deterministic_cross_pairs_reconstruct": not cross_failures,
            "product_action_implies_joint_fiber_multiplicity": self.program_count > 0,
        }
        return {
            "schema": "SLC_CUSTODY_NATIVE_Z4_PRODUCT_ACTION_AUDIT_V2",
            "power": self.power,
            "address_count": self.size,
            "program_count": self.program_count,
            "implicit_joint_pair_count": self.size * self.program_count,
            "coordinate_pairs_checked": 16,
            "fixed_program_addresses_checked": self.size,
            "dynamic_controls_checked": self.program_count,
            "cross_pairs_checked": int(cross_pair_count),
            "failures": {
                "digit_pairs": digit_pair_failures,
                "fixed_addresses": fixed_failures,
                "dynamic_controls": control_failures,
                "cross_pairs": cross_failures,
            },
            "checks": checks,
            "checks_passed": sum(checks.values()),
            "checks_failed": sum(not value for value in checks.values()),
            "status": "PASS" if all(checks.values()) else "FAIL",
        }
