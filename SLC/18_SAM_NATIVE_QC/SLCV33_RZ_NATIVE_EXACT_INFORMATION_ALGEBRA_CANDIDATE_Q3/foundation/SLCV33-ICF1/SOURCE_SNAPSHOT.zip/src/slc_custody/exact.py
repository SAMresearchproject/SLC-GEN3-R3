"""Exact finite-distribution entropy over the V1 prime-log algebra."""

from __future__ import annotations

from fractions import Fraction
from typing import Hashable, Iterable, Mapping


from .algebra import PrimeLogWeight, SymbolicEntropy


Atom = tuple[Mapping[str, Hashable], Fraction]


def support_weight(cardinality: int) -> dict[str, object]:
    """Return exact Hartley support weight for a finite alphabet."""

    return PrimeLogWeight.from_multiplicity(int(cardinality)).to_dict()


def entropy_from_probabilities(probabilities: Iterable[Fraction]) -> SymbolicEntropy:
    """Return exact Shannon entropy for rational probabilities."""

    values = tuple(Fraction(probability) for probability in probabilities if probability)
    if not values or sum(values, Fraction()) != 1:
        raise ValueError("entropy probabilities must be positive and sum exactly to one")
    terms: list[SymbolicEntropy] = []
    for probability in values:
        if probability < 0:
            raise ValueError("entropy probabilities cannot be negative")
        terms.append(
            SymbolicEntropy.weighted_log(probability.denominator, probability)
            - SymbolicEntropy.weighted_log(probability.numerator, probability)
        )
    return SymbolicEntropy.sum(terms)


def normalized_distribution(
    weighted_items: Iterable[tuple[Hashable, int | Fraction]],
) -> dict[Hashable, Fraction]:
    """Combine repeated keys and normalize positive rational weights."""

    combined: dict[Hashable, Fraction] = {}
    for key, raw_weight in weighted_items:
        weight = Fraction(raw_weight)
        if weight <= 0:
            raise ValueError("distribution weights must be positive")
        combined[key] = combined.get(key, Fraction()) + weight
    total = sum(combined.values(), Fraction())
    if total <= 0:
        raise ValueError("distribution cannot be empty")
    return {key: weight / total for key, weight in combined.items()}


def projected_distribution(
    atoms: Iterable[Atom],
    fields: tuple[str, ...],
) -> dict[tuple[Hashable, ...], Fraction]:
    distribution: dict[tuple[Hashable, ...], Fraction] = {}
    for values, probability in atoms:
        key = tuple(values[field] for field in fields)
        distribution[key] = distribution.get(key, Fraction()) + probability
    if sum(distribution.values(), Fraction()) != 1:
        raise ValueError("projected atom probabilities must sum exactly to one")
    return distribution


def entropy_of(atoms: Iterable[Atom], fields: tuple[str, ...]) -> SymbolicEntropy:
    distribution = projected_distribution(tuple(atoms), fields)
    return entropy_from_probabilities(distribution.values())


def conditional_entropy_of(
    atoms: Iterable[Atom],
    target_fields: tuple[str, ...],
    given_fields: tuple[str, ...],
) -> SymbolicEntropy:
    frozen = tuple(atoms)
    joint_fields = tuple(dict.fromkeys(given_fields + target_fields))
    return entropy_of(frozen, joint_fields) - entropy_of(frozen, given_fields)


def expected_log_support(
    atoms: Iterable[Atom],
    target_fields: tuple[str, ...],
    given_fields: tuple[str, ...],
) -> SymbolicEntropy:
    """Return E[log |support(target|given)|] without assuming uniformity."""

    frozen = tuple(atoms)
    given_distribution = projected_distribution(frozen, given_fields)
    supports: dict[tuple[Hashable, ...], set[tuple[Hashable, ...]]] = {}
    for values, _probability in frozen:
        given = tuple(values[field] for field in given_fields)
        target = tuple(values[field] for field in target_fields)
        supports.setdefault(given, set()).add(target)
    return SymbolicEntropy.sum(
        SymbolicEntropy.weighted_log(len(supports[given]), probability)
        for given, probability in given_distribution.items()
    )
