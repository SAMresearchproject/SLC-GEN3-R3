"""Hash-bound Complete Exact Write substrate adapter for V6.

This module owns the successor-facing interface, dependency custody, and law
receipts.  It does not copy or modify the installed Complete Exact Write
implementation.  Every operation delegates to the immutable source module
after its repository path and SHA-256 custody have been verified.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from types import ModuleType
from typing import Any, Iterable, Mapping, Protocol, Sequence, runtime_checkable

import numpy as np


EXPECTED_CURRENT_REVISION_NAME = "SLCQ2-RZ"

CURRENT_POINTER_PATH = Path("SLC/18_SAM_NATIVE_QC/CURRENT_SLC_REVISION.json")
CURRENT_Q2_REVISION_PATH = Path(
    "SLC/18_SAM_NATIVE_QC/SLCQ2_RZ_CURRENT_REVISION_V1/release/"
    "SLCQ2-RZ_CURRENT_REVISION.json"
)
COMPLETE_EXACT_WRITE_ROOT = Path(
    "SLC/18_SAM_NATIVE_QC/"
    "SLCV10_H14F_T18_EXACT_WRITE_COMPLETE_ALGEBRA_V1"
)
COMPLETE_EXACT_WRITE_SOURCE_PATH = COMPLETE_EXACT_WRITE_ROOT / "complete_exact_write.py"
COMPLETE_EXACT_WRITE_COVERAGE_PATH = COMPLETE_EXACT_WRITE_ROOT / "EXACT_ALGEBRA_COVERAGE.md"
COMPLETE_EXACT_WRITE_INTERFACE_PATH = (
    COMPLETE_EXACT_WRITE_ROOT / "release/COMPLETE_EXACT_ALGEBRA_INTERFACE.json"
)
COMPLETE_EXACT_WRITE_RESULT_PATH = (
    COMPLETE_EXACT_WRITE_ROOT / "release/COMPLETE_EXACT_ALGEBRA_RESULT.json"
)
COMPLETE_EXACT_WRITE_VALIDATION_PATH = (
    COMPLETE_EXACT_WRITE_ROOT / "release/COMPLETE_EXACT_ALGEBRA_VALIDATION.json"
)
COMPLETE_EXACT_WRITE_NATIVE_LIBRARY_PATH = (
    COMPLETE_EXACT_WRITE_ROOT / "release/libslc_complete_exact_write.so"
)


class ExactWriteDependencyError(RuntimeError):
    """A required immutable artifact or authority field failed custody."""


@dataclass(frozen=True, slots=True)
class ArtifactPin:
    """One immutable repository artifact required by the adapter."""

    role: str
    relative_path: Path
    sha256: str

    def __post_init__(self) -> None:
        if not self.role or self.relative_path.is_absolute():
            raise ValueError("artifact pins require a role and repository-relative path")
        if len(self.sha256) != 64 or any(character not in "0123456789abcdef" for character in self.sha256):
            raise ValueError("artifact pin SHA-256 must be lowercase hexadecimal")


PINNED_ARTIFACTS = (
    ArtifactPin(
        "CURRENT_SLC_POINTER",
        CURRENT_POINTER_PATH,
        "751f6e6a6dbe01cfdc335cf303824887148c9eb657ded691264e37c6f61fa318",
    ),
    ArtifactPin(
        "CURRENT_Q2_REVISION",
        CURRENT_Q2_REVISION_PATH,
        "cc76e3c401cc0aee227a95188ae6a1ec2ae1f04524895378b5a9a3a24c732fc7",
    ),
    ArtifactPin(
        "COMPLETE_EXACT_WRITE_SOURCE",
        COMPLETE_EXACT_WRITE_SOURCE_PATH,
        "8b54927924eebb617be29ba69b299ca5144cc52a4214119d7bae6ca19311aa14",
    ),
    ArtifactPin(
        "COMPLETE_EXACT_WRITE_COVERAGE",
        COMPLETE_EXACT_WRITE_COVERAGE_PATH,
        "c65695a4127437528a4041b679e401b7f801a9f5a453d398ebec841e6049e6aa",
    ),
    ArtifactPin(
        "COMPLETE_EXACT_WRITE_INTERFACE",
        COMPLETE_EXACT_WRITE_INTERFACE_PATH,
        "ebc6b0619bb93fa110487e4a6359495628405e2ce5df29a6d10668b172008b8b",
    ),
    ArtifactPin(
        "COMPLETE_EXACT_WRITE_RESULT",
        COMPLETE_EXACT_WRITE_RESULT_PATH,
        "22c389aeff5286417def67cc107b650ae72a62cb6f6a26bac7ec33abd5c66dcb",
    ),
    ArtifactPin(
        "COMPLETE_EXACT_WRITE_VALIDATION",
        COMPLETE_EXACT_WRITE_VALIDATION_PATH,
        "e939ef58346a2f70b7aa663caff1722463b271eb0eb1ce60dfe0b03d3d4887da",
    ),
    ArtifactPin(
        "COMPLETE_EXACT_WRITE_NATIVE_LIBRARY",
        COMPLETE_EXACT_WRITE_NATIVE_LIBRARY_PATH,
        "ba9843ca4ec5860ca2aeae11c1ddb0fc14e1ce15c684704bc4df01b5366e2597",
    ),
)


@dataclass(frozen=True, slots=True)
class VerifiedArtifact:
    """Observed custody for one verified pin."""

    role: str
    relative_path: str
    sha256: str
    byte_count: int


@dataclass(frozen=True, slots=True)
class ExactWriteDependencyReceipt:
    """Complete dependency receipt produced before source execution."""

    repository_root: Path
    current_revision_name: str
    artifacts: tuple[VerifiedArtifact, ...]
    interface_semantic_sha256: str
    result_semantic_sha256: str
    validation_semantic_sha256: str

    def artifact(self, role: str) -> VerifiedArtifact:
        for artifact in self.artifacts:
            if artifact.role == role:
                return artifact
        raise KeyError(role)

    def to_dict(self) -> dict[str, object]:
        return {
            "repository_root": str(self.repository_root),
            "current_revision_name": self.current_revision_name,
            "artifacts": [
                {
                    "role": artifact.role,
                    "relative_path": artifact.relative_path,
                    "sha256": artifact.sha256,
                    "byte_count": artifact.byte_count,
                }
                for artifact in self.artifacts
            ],
            "interface_semantic_sha256": self.interface_semantic_sha256,
            "result_semantic_sha256": self.result_semantic_sha256,
            "validation_semantic_sha256": self.validation_semantic_sha256,
        }


@dataclass(frozen=True, slots=True)
class ExactWriteOperationDescriptor:
    """Strict successor-owned description of one installed coverage layer."""

    operation_id: str
    paper_object: str
    immutable_symbols: tuple[str, ...]
    input_schema: str
    output_schema: str
    exact_law: str
    reconstruction_contract: str

    def __post_init__(self) -> None:
        if not self.operation_id or not self.operation_id.isupper():
            raise ValueError("operation_id must be a nonempty uppercase identifier")
        if not all(
            (self.paper_object, self.immutable_symbols, self.input_schema,
             self.output_schema, self.exact_law, self.reconstruction_contract)
        ):
            raise ValueError("operation descriptors cannot contain empty fields")
        if any(not symbol.isidentifier() for symbol in self.immutable_symbols):
            raise ValueError("immutable source symbols must be Python identifiers")


OPERATION_DESCRIPTORS = (
    ExactWriteOperationDescriptor(
        "W8_COMPLETE_SHELL",
        "W8={0,1}^8",
        ("w8_bits", "W8Site"),
        "shell_state:int with 0<=shell_state<256",
        "eight exact binary coordinates and typed W8Site",
        "the eight coordinates encode the shell state bijectively",
        "sum(bit_i*2^i) reconstructs shell_state",
    ),
    ExactWriteOperationDescriptor(
        "HAMILTONIAN_WELD",
        "H_W9=H_W8+B DeltaH_X1",
        ("hamiltonian_weld",),
        "equal nonempty exact vectors and B in {0,1}",
        "tuple[Fraction,...]",
        "H_W9=H_W8+B*DeltaH_X1 entrywise",
        "B=0 returns H_W8 and B=1 retains the exact X1 increment",
    ),
    ExactWriteOperationDescriptor(
        "W9_RECORD_PROJECTION",
        "W9=(s,a,rho,ell), pi(W9)=s",
        ("W9Record", "project_w8"),
        "typed shell, axis, orientation, ledger receipt, before/after address",
        "typed W9Record and projected shell state",
        "projection returns the exact recorded W8 shell state",
        "pi(W9)=s",
    ),
    ExactWriteOperationDescriptor(
        "TWO_SITE_U_X1_LIFECYCLE",
        "two-site U/X1 lifecycle",
        ("ActiveWrite", "CompletedWrite", "activate_write", "complete_write"),
        "source W8Site, target W8Site, legal event metadata",
        "ActiveWrite then CompletedWrite",
        "completion clears X1, returns both sites to W8, and retains one shared W9 record",
        "the retained W9 record reconstructs shell, route, orientation, receipt, and addresses",
    ),
    ExactWriteOperationDescriptor(
        "PACKED_Z4_COORDINATE",
        "Z4^9 and q_i",
        ("q_coordinate",),
        "Theta18 address and axis in [0,9)",
        "q_i in Z4",
        "two packed bits encode each of nine Z4 coordinates",
        "all nine q_i reconstruct the packed 18-bit address",
    ),
    ExactWriteOperationDescriptor(
        "SIGNED_EVENT_MAP",
        "T_epsilon",
        ("event_map", "NativeCompleteExactWrite"),
        "Theta18 address, axis, epsilon in {-1,+1}",
        "translated Theta18 address",
        "T_epsilon(q_i)=q_i+epsilon mod 4 with all other coordinates fixed",
        "T_-epsilon is the exact inverse event",
    ),
    ExactWriteOperationDescriptor(
        "ENDPOINT_REVERSAL_COVARIANCE",
        "G_k T_epsilon=T_-epsilon G_k",
        ("event_map", "reverse_address"),
        "Theta18 address, axis, sign, k in Z4",
        "reversed Theta18 address",
        "endpoint reversal conjugates the event sign exactly",
        "G_k is involutive and preserves reciprocal event custody",
    ),
    ExactWriteOperationDescriptor(
        "SIGNED_PROGRAM_COMPOSITION",
        "signed-write composition",
        (
            "compile_translation", "apply_translation", "compose_translations",
            "inverse_translation", "NativeCompleteExactWrite",
        ),
        "finite legal signed-write program and packed addresses",
        "one Z4^9 translation and exact translated addresses",
        "sequential events equal one compiled group translation",
        "the inverse translation returns every input address",
    ),
    ExactWriteOperationDescriptor(
        "NONCONSTANT_HISTORY_QUOTIENT",
        "H_nc=H_sym^80 direct-sum H_anti^81",
        ("HistoryQuotient", "history_quotient"),
        "two exact 81-coordinate reciprocal views",
        "80 symmetric-nonconstant plus 81 antisymmetric coordinates and one anchor",
        "the quotient has exactly 161 coordinates",
        "quotient plus retained common anchor reconstructs both views",
    ),
    ExactWriteOperationDescriptor(
        "COMMON_CONSTANT_KERNEL",
        "constant kernel",
        ("HistoryQuotient", "history_quotient"),
        "two reciprocal views modulo a shared constant shift",
        "shift-invariant 161-coordinate quotient and shifted anchor",
        "a shared constant shift changes only the retained anchor",
        "the anchor selects the exact representative of the constant class",
    ),
    ExactWriteOperationDescriptor(
        "RESOLVED_RESPONSE",
        "R_res=-Pi_C(E)",
        ("ProjectionReceipt", "completed_projection"),
        "equal nonempty exact energy and nonzero completed-mode vectors",
        "exact projection and negative resolved response",
        "resolved_response=-projection",
        "projection plus orthogonal remainder reconstructs E",
    ),
    ExactWriteOperationDescriptor(
        "ORTHOGONAL_INFORMATION_REMAINDER",
        "retained orthogonal information",
        ("ProjectionReceipt", "completed_projection"),
        "exact energy and completed mode",
        "orthogonal remainder with conservation and idempotence flags",
        "norm(E)=norm(Pi_C E)+norm(E-Pi_C E) exactly",
        "projection and retained remainder reconstruct E entrywise",
    ),
    ExactWriteOperationDescriptor(
        "ANALYTIC_BT_DIFFERENCE",
        "B_t h",
        ("AnalyticWriteReceipt", "analytic_write", "qcomplex"),
        "equal nonempty rational-complex reciprocal views",
        "exact reciprocal difference",
        "B_t h=left-right",
        "symmetric plus antisymmetric views reconstruct left",
    ),
    ExactWriteOperationDescriptor(
        "ANALYTIC_ET_CORRELATIONS",
        "E_t(h) and reciprocal correlations",
        ("AnalyticWriteReceipt", "analytic_write"),
        "equal rational-complex reciprocal views",
        "write norm and forward/reverse Hermitian correlations",
        "write energy equals the conjugate-paired difference norm",
        "the reverse correlation is the exact conjugate of the forward correlation",
    ),
    ExactWriteOperationDescriptor(
        "ANALYTIC_J_PPLUS_PMINUS",
        "J, P_plus, P_minus",
        ("AnalyticWriteReceipt", "analytic_write"),
        "equal rational-complex reciprocal views",
        "half-sum and half-difference views",
        "P_plus=(left+right)/2 and P_minus=(left-right)/2",
        "left=P_plus+P_minus and right=P_plus-P_minus",
    ),
    ExactWriteOperationDescriptor(
        "CENTERED_TWO_VIEW_FACTORIZATION",
        "centered two-view factorization",
        ("AnalyticWriteReceipt", "analytic_write"),
        "equal rational-complex reciprocal views",
        "symmetric, antisymmetric, and centered energies",
        "centered_energy=antisymmetric_energy-symmetric_energy",
        "identity_closes certifies the exact factorization",
    ),
    ExactWriteOperationDescriptor(
        "MULTIPLICATIVE_LEDGER_COMPOSITION",
        "D_next=s D_now mod M",
        ("LedgerReceipt", "ledger_write", "ledger_program"),
        "positive modulus, ledger state, finite write-state sequence",
        "typed per-step receipts, final state, and composed multiplier",
        "the program product acts on the initial ledger state exactly",
        "the ordered receipts retain every before/write/after transition",
    ),
    ExactWriteOperationDescriptor(
        "MULTIPLICATIVE_LEDGER_READBACK",
        "s_hat=D_next D_now^-1",
        ("LedgerReceipt", "ledger_write"),
        "typed multiplicative receipt",
        "recovered write state or explicit None with invertible_before=False",
        "readback exists exactly iff the before state is invertible modulo M",
        "noninvertibility is retained as a typed outcome, never fabricated as an inverse",
    ),
    ExactWriteOperationDescriptor(
        "Z4_MU4_TRANSFER",
        "Z4 to MU4 transfer",
        ("MU4", "mu4_character", "mu4_multiply", "mu4_readback"),
        "Z4 coordinates",
        "exact Gaussian-unit integer pairs",
        "chi(a+b)=chi(a)chi(b) in MU4",
        "mu4_readback returns the exact directional character quotient",
    ),
)

EXPECTED_OPERATION_IDS = tuple(descriptor.operation_id for descriptor in OPERATION_DESCRIPTORS)


@runtime_checkable
class W9RecordLike(Protocol):
    shell_state: int
    axis: int
    orientation: int
    ledger_receipt: int
    address_before: int
    address_after: int


@runtime_checkable
class W8SiteLike(Protocol):
    shell_state: int
    retained_records: tuple[W9RecordLike, ...]


@runtime_checkable
class ActiveWriteLike(Protocol):
    source: W8SiteLike
    target_shell_state: int
    target_record: W9RecordLike
    x1_custody: int
    source_phase: str
    target_phase: str


@runtime_checkable
class CompletedWriteLike(Protocol):
    source: W8SiteLike
    target: W8SiteLike
    retained_record: W9RecordLike
    x1_custody: int
    source_phase: str
    target_phase: str


@runtime_checkable
class HistoryQuotientLike(Protocol):
    symmetric_nonconstant: tuple[Fraction, ...]
    antisymmetric: tuple[Fraction, ...]

    @property
    def coordinates(self) -> tuple[Fraction, ...]: ...

    def reconstruct(
        self, common_anchor: int | Fraction = 0
    ) -> tuple[tuple[Fraction, ...], tuple[Fraction, ...]]: ...


@runtime_checkable
class ProjectionReceiptLike(Protocol):
    projection: tuple[Fraction, ...]
    resolved_response: tuple[Fraction, ...]
    orthogonal_remainder: tuple[Fraction, ...]
    inner_product: Fraction
    completed_mode_norm: Fraction
    removed_norm: Fraction
    orthogonal: bool
    conserved: bool
    idempotent: bool


@runtime_checkable
class AnalyticWriteReceiptLike(Protocol):
    difference: tuple[tuple[Fraction, Fraction], ...]
    symmetric_view: tuple[tuple[Fraction, Fraction], ...]
    antisymmetric_view: tuple[tuple[Fraction, Fraction], ...]
    write_energy: Fraction
    correlation_zero_twice: Fraction
    correlation_forward: tuple[Fraction, Fraction]
    correlation_reverse: tuple[Fraction, Fraction]
    symmetric_energy: Fraction
    antisymmetric_energy: Fraction
    centered_energy: Fraction
    identity_closes: bool


@runtime_checkable
class LedgerReceiptLike(Protocol):
    modulus: int
    before: int
    write_state: int
    after: int
    recovered_write_state: int | None
    invertible_before: bool


@dataclass(frozen=True, slots=True)
class NativeBatchComparison:
    """Exact equality receipt for one deterministic native batch."""

    label: str
    address_count: int
    program_length: int
    reference_translation: int
    native_translation: int
    reference_equals_python_compiled: bool
    reference_equals_native_sequential: bool
    reference_equals_native_compiled: bool
    output_sha256: str

    @property
    def passed(self) -> bool:
        return (
            self.reference_translation == self.native_translation
            and self.reference_equals_python_compiled
            and self.reference_equals_native_sequential
            and self.reference_equals_native_compiled
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "label": self.label,
            "address_count": self.address_count,
            "program_length": self.program_length,
            "reference_translation": self.reference_translation,
            "native_translation": self.native_translation,
            "reference_equals_python_compiled": self.reference_equals_python_compiled,
            "reference_equals_native_sequential": self.reference_equals_native_sequential,
            "reference_equals_native_compiled": self.reference_equals_native_compiled,
            "output_sha256": self.output_sha256,
            "passed": self.passed,
        }


@dataclass(frozen=True, slots=True)
class ExactWriteLawCheck:
    name: str
    passed: bool
    detail: str


@dataclass(frozen=True, slots=True)
class ExactWriteLawAudit:
    """Bounded exact-law audit over every installed coverage layer."""

    current_revision_name: str
    source_sha256: str
    native_library_sha256: str
    operation_ids: tuple[str, ...]
    checks: tuple[ExactWriteLawCheck, ...]
    native_batches: tuple[NativeBatchComparison, ...]

    @property
    def checks_passed(self) -> int:
        return sum(check.passed for check in self.checks)

    @property
    def checks_total(self) -> int:
        return len(self.checks)

    @property
    def status(self) -> str:
        return "PASS" if all(check.passed for check in self.checks) else "FAIL"

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLCV33_ICF1_COMPLETE_EXACT_WRITE_LAW_AUDIT_V1",
            "current_revision_name": self.current_revision_name,
            "source_sha256": self.source_sha256,
            "native_library_sha256": self.native_library_sha256,
            "operation_ids": list(self.operation_ids),
            "checks": [
                {"name": check.name, "passed": check.passed, "detail": check.detail}
                for check in self.checks
            ],
            "native_batches": [batch.to_dict() for batch in self.native_batches],
            "checks_passed": self.checks_passed,
            "checks_total": self.checks_total,
            "status": self.status,
        }


def _candidate_roots(start: Path | str | None) -> Iterable[Path]:
    seeds: list[Path] = []
    if start is not None:
        seeds.append(Path(start))
    seeds.extend((Path(__file__), Path.cwd()))
    seen: set[Path] = set()
    for seed in seeds:
        try:
            resolved = seed.expanduser().resolve(strict=False)
        except OSError:
            continue
        base = resolved if resolved.is_dir() else resolved.parent
        for candidate in (base, *base.parents):
            if candidate not in seen:
                seen.add(candidate)
                yield candidate


def locate_repository_root(start: Path | str | None = None) -> Path:
    """Locate the SAM repository by immutable Exact Write and authority markers."""

    for candidate in _candidate_roots(start):
        if (
            (candidate / "AGENTS.md").is_file()
            and (candidate / "DECLARATION_OF_RESEARCH.md").is_file()
            and (candidate / CURRENT_POINTER_PATH).is_file()
            and (candidate / COMPLETE_EXACT_WRITE_SOURCE_PATH).is_file()
        ):
            return candidate.resolve()
    raise ExactWriteDependencyError(
        "could not locate SAM repository containing authority and Complete Exact Write markers"
    )


def _repository_file(repository_root: Path, relative_path: Path) -> Path:
    root = repository_root.resolve()
    candidate = (root / relative_path).resolve(strict=True)
    if not candidate.is_relative_to(root) or not candidate.is_file():
        raise ExactWriteDependencyError(f"artifact escapes repository or is not a file: {relative_path}")
    return candidate


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_object(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ExactWriteDependencyError(f"invalid JSON dependency: {path}") from exc
    if not isinstance(value, dict):
        raise ExactWriteDependencyError(f"JSON dependency must contain one object: {path}")
    return value


def _require_mapping(value: object, field: str) -> Mapping[str, Any]:
    if not isinstance(value, dict):
        raise ExactWriteDependencyError(f"required authority field is not an object: {field}")
    return value


def verify_exact_write_dependencies(
    repository_root: Path | str | None = None,
) -> ExactWriteDependencyReceipt:
    """Verify all frozen hashes and current Q2 authority before importing source."""

    root = locate_repository_root(repository_root)
    verified: list[VerifiedArtifact] = []
    for pin in PINNED_ARTIFACTS:
        path = _repository_file(root, pin.relative_path)
        observed = _sha256_file(path)
        if observed != pin.sha256:
            raise ExactWriteDependencyError(
                f"SHA-256 mismatch for {pin.role}: expected {pin.sha256}, observed {observed}"
            )
        verified.append(VerifiedArtifact(pin.role, pin.relative_path.as_posix(), observed, path.stat().st_size))

    pointer = _json_object(_repository_file(root, CURRENT_POINTER_PATH))
    current_name = pointer.get("current_revision_name")
    if current_name != EXPECTED_CURRENT_REVISION_NAME:
        raise ExactWriteDependencyError(
            "current_revision_name must equal exactly "
            f"{EXPECTED_CURRENT_REVISION_NAME!r}; observed {current_name!r}"
        )
    active_roster = pointer.get("active_model_roster")
    if not isinstance(active_roster, list) or len(active_roster) != 1:
        raise ExactWriteDependencyError("current pointer must declare one exclusive active model")
    active = _require_mapping(active_roster[0], "active_model_roster[0]")
    if active.get("revision_name") != EXPECTED_CURRENT_REVISION_NAME or active.get("default_use") is not True:
        raise ExactWriteDependencyError("active model roster does not exactly select SLCQ2-RZ")

    q2_revision = _json_object(_repository_file(root, CURRENT_Q2_REVISION_PATH))
    if (
        q2_revision.get("revision") != EXPECTED_CURRENT_REVISION_NAME
        or q2_revision.get("short_name") != EXPECTED_CURRENT_REVISION_NAME
    ):
        raise ExactWriteDependencyError("pinned Q2 revision identity does not equal SLCQ2-RZ")

    exact_pointer = _require_mapping(
        pointer.get("complete_exact_write_algebra"), "complete_exact_write_algebra"
    )
    expected_pointer_fields = {
        "interface_path": COMPLETE_EXACT_WRITE_INTERFACE_PATH.as_posix(),
        "interface_sha256": PINNED_ARTIFACTS[4].sha256,
        "result_path": COMPLETE_EXACT_WRITE_RESULT_PATH.as_posix(),
        "result_sha256": PINNED_ARTIFACTS[5].sha256,
        "validation_path": COMPLETE_EXACT_WRITE_VALIDATION_PATH.as_posix(),
        "validation_sha256": PINNED_ARTIFACTS[6].sha256,
        "status": "INSTALLED_ACTIVE_COMPLETE_EXACT_WRITE_COMPONENT",
    }
    for field, expected in expected_pointer_fields.items():
        if exact_pointer.get(field) != expected:
            raise ExactWriteDependencyError(
                f"current pointer Complete Exact Write field {field!r} does not match its frozen pin"
            )

    interface = _json_object(_repository_file(root, COMPLETE_EXACT_WRITE_INTERFACE_PATH))
    result = _json_object(_repository_file(root, COMPLETE_EXACT_WRITE_RESULT_PATH))
    validation = _json_object(_repository_file(root, COMPLETE_EXACT_WRITE_VALIDATION_PATH))
    if interface.get("status") != "INSTALLED_ACTIVE_COMPLETE_EXACT_WRITE_COMPONENT":
        raise ExactWriteDependencyError("Complete Exact Write interface is not the installed active component")
    if result.get("status") != "PASS" or result.get("passed") != result.get("total"):
        raise ExactWriteDependencyError("Complete Exact Write result is not a complete PASS")
    if validation.get("status") != "PASS" or validation.get("passed") != validation.get("total"):
        raise ExactWriteDependencyError("Complete Exact Write validation is not a complete PASS")

    result_artifacts = _require_mapping(result.get("artifacts"), "result.artifacts")
    if result_artifacts.get("implementation_sha256") != PINNED_ARTIFACTS[2].sha256:
        raise ExactWriteDependencyError("result source hash does not match pinned immutable source")
    if result_artifacts.get("native_library_sha256") != PINNED_ARTIFACTS[7].sha256:
        raise ExactWriteDependencyError("result native-library hash does not match pinned library")
    if validation.get("result_semantic_sha256") != result.get("semantic_sha256"):
        raise ExactWriteDependencyError("independent validation is not bound to the pinned result semantics")
    if interface.get("result_path") != COMPLETE_EXACT_WRITE_RESULT_PATH.as_posix():
        raise ExactWriteDependencyError("interface result path does not match the pinned result")

    return ExactWriteDependencyReceipt(
        repository_root=root,
        current_revision_name=str(current_name),
        artifacts=tuple(verified),
        interface_semantic_sha256=str(interface.get("semantic_sha256")),
        result_semantic_sha256=str(result.get("semantic_sha256")),
        validation_semantic_sha256=str(validation.get("semantic_sha256")),
    )


def _load_immutable_module(receipt: ExactWriteDependencyReceipt) -> ModuleType:
    source_path = _repository_file(receipt.repository_root, COMPLETE_EXACT_WRITE_SOURCE_PATH)
    module_name = "_slc_custody_frozen_complete_exact_write_8b54927924eebb61"
    existing = sys.modules.get(module_name)
    if existing is not None:
        loaded_path = Path(str(getattr(existing, "__file__", ""))).resolve(strict=False)
        if loaded_path != source_path:
            raise ExactWriteDependencyError("cached immutable module resolves to the wrong source path")
        return existing

    spec = importlib.util.spec_from_file_location(module_name, source_path)
    if spec is None or spec.loader is None:
        raise ExactWriteDependencyError("cannot construct loader for immutable Complete Exact Write source")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    previous_bytecode_policy = sys.dont_write_bytecode
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(module_name, None)
        raise
    finally:
        sys.dont_write_bytecode = previous_bytecode_policy

    observed_after_load = _sha256_file(source_path)
    expected = receipt.artifact("COMPLETE_EXACT_WRITE_SOURCE").sha256
    if observed_after_load != expected:
        sys.modules.pop(module_name, None)
        raise ExactWriteDependencyError("immutable source changed during dynamic loading")
    return module


def _validate_operation_surface(module: ModuleType) -> None:
    if len(OPERATION_DESCRIPTORS) != 19 or len(set(EXPECTED_OPERATION_IDS)) != 19:
        raise ExactWriteDependencyError("operation descriptors do not cover 19 distinct installed layers")
    missing = sorted(
        {
            symbol
            for descriptor in OPERATION_DESCRIPTORS
            for symbol in descriptor.immutable_symbols
            if not hasattr(module, symbol)
        }
    )
    if missing:
        raise ExactWriteDependencyError(f"immutable Complete Exact Write API is missing: {missing}")


def _strict_int(value: int, field: str) -> int:
    if type(value) is not int:
        raise TypeError(f"{field} must be an int")
    return value


def _strict_program(program: Sequence[tuple[int, int]]) -> tuple[tuple[int, int], ...]:
    normalized: list[tuple[int, int]] = []
    for index, item in enumerate(program):
        if not isinstance(item, tuple) or len(item) != 2:
            raise TypeError(f"program[{index}] must be an (axis, delta) tuple")
        axis = _strict_int(item[0], f"program[{index}].axis")
        delta = _strict_int(item[1], f"program[{index}].delta")
        if not 0 <= axis < 9 or delta not in (-1, 1):
            raise ValueError(f"program[{index}] is outside Z4^9 signed-event domain")
        normalized.append((axis, delta))
    return tuple(normalized)


def _strict_addresses(addresses: Iterable[int]) -> tuple[int, ...]:
    frozen = tuple(_strict_int(address, "address") for address in addresses)
    if not frozen:
        raise ValueError("native comparison requires at least one address")
    if any(not 0 <= address < (1 << 18) for address in frozen):
        raise ValueError("addresses must lie in packed Z4^9")
    return frozen


def _packed_u32_sha256(values: np.ndarray) -> str:
    canonical = np.asarray(values, dtype="<u4")
    return hashlib.sha256(canonical.tobytes(order="C")).hexdigest()


class CompleteExactWriteAdapter:
    """Strict hash-bound delegate over the immutable Complete Exact Write source."""

    __slots__ = ("_dependency_receipt", "_module", "_native")

    def __init__(self, repository_root: Path | str | None = None) -> None:
        dependency_receipt = verify_exact_write_dependencies(repository_root)
        module = _load_immutable_module(dependency_receipt)
        _validate_operation_surface(module)
        native_path = _repository_file(
            dependency_receipt.repository_root, COMPLETE_EXACT_WRITE_NATIVE_LIBRARY_PATH
        )
        native = module.NativeCompleteExactWrite(native_path)
        self._dependency_receipt = dependency_receipt
        self._module = module
        self._native = native

    @property
    def dependency_receipt(self) -> ExactWriteDependencyReceipt:
        return self._dependency_receipt

    @property
    def operation_descriptors(self) -> tuple[ExactWriteOperationDescriptor, ...]:
        return OPERATION_DESCRIPTORS

    @property
    def immutable_source_path(self) -> Path:
        return _repository_file(
            self._dependency_receipt.repository_root, COMPLETE_EXACT_WRITE_SOURCE_PATH
        )

    def descriptor(self, operation_id: str) -> ExactWriteOperationDescriptor:
        for descriptor in OPERATION_DESCRIPTORS:
            if descriptor.operation_id == operation_id:
                return descriptor
        raise KeyError(operation_id)

    def w8_bits(self, shell_state: int) -> tuple[int, ...]:
        return tuple(self._module.w8_bits(_strict_int(shell_state, "shell_state")))

    def w8_site(
        self,
        shell_state: int,
        retained_records: Sequence[W9RecordLike] = (),
    ) -> W8SiteLike:
        records = tuple(retained_records)
        if any(not isinstance(record, self._module.W9Record) for record in records):
            raise TypeError("retained_records must come from the pinned W9Record type")
        return self._module.W8Site(_strict_int(shell_state, "shell_state"), records)

    def hamiltonian_weld(
        self,
        h_w8: Sequence[int | Fraction],
        delta_h_x1: Sequence[int | Fraction],
        activation: int,
    ) -> tuple[Fraction, ...]:
        return tuple(
            self._module.hamiltonian_weld(
                h_w8, delta_h_x1, _strict_int(activation, "activation")
            )
        )

    def activate_write(
        self,
        source: W8SiteLike,
        target: W8SiteLike,
        axis: int,
        orientation: int,
        ledger_receipt: int,
        address: int,
    ) -> ActiveWriteLike:
        if not isinstance(source, self._module.W8Site) or not isinstance(target, self._module.W8Site):
            raise TypeError("source and target must be pinned W8Site values")
        return self._module.activate_write(
            source,
            target,
            _strict_int(axis, "axis"),
            _strict_int(orientation, "orientation"),
            _strict_int(ledger_receipt, "ledger_receipt"),
            _strict_int(address, "address"),
        )

    def complete_write(
        self,
        active: ActiveWriteLike,
        target_prior_records: Sequence[W9RecordLike] = (),
    ) -> CompletedWriteLike:
        if not isinstance(active, self._module.ActiveWrite):
            raise TypeError("active must be the pinned ActiveWrite type")
        records = tuple(target_prior_records)
        if any(not isinstance(record, self._module.W9Record) for record in records):
            raise TypeError("target_prior_records must use the pinned W9Record type")
        return self._module.complete_write(active, records)

    def project_w8(self, record: W9RecordLike) -> int:
        if not isinstance(record, self._module.W9Record):
            raise TypeError("record must be the pinned W9Record type")
        return int(self._module.project_w8(record))

    def q_coordinate(self, address: int, axis: int) -> int:
        return int(
            self._module.q_coordinate(
                _strict_int(address, "address"), _strict_int(axis, "axis")
            )
        )

    def event_map(self, address: int, axis: int, delta: int) -> int:
        return int(
            self._module.event_map(
                _strict_int(address, "address"),
                _strict_int(axis, "axis"),
                _strict_int(delta, "delta"),
            )
        )

    def reverse_address(self, address: int, k: int = 3) -> int:
        return int(
            self._module.reverse_address(
                _strict_int(address, "address"), _strict_int(k, "k")
            )
        )

    def compile_translation(self, program: Sequence[tuple[int, int]]) -> int:
        return int(self._module.compile_translation(_strict_program(program)))

    def apply_translation(self, address: int, translation: int) -> int:
        return int(
            self._module.apply_translation(
                _strict_int(address, "address"),
                _strict_int(translation, "translation"),
            )
        )

    def compose_translations(self, left: int, right: int) -> int:
        return int(
            self._module.compose_translations(
                _strict_int(left, "left"), _strict_int(right, "right")
            )
        )

    def inverse_translation(self, translation: int) -> int:
        return int(self._module.inverse_translation(_strict_int(translation, "translation")))

    def history_quotient(
        self,
        left: Sequence[int | Fraction],
        right: Sequence[int | Fraction],
    ) -> tuple[HistoryQuotientLike, Fraction]:
        quotient, anchor = self._module.history_quotient(left, right)
        return quotient, Fraction(anchor)

    def completed_projection(
        self,
        energy: Sequence[int | Fraction],
        completed_mode: Sequence[int | Fraction],
    ) -> ProjectionReceiptLike:
        return self._module.completed_projection(energy, completed_mode)

    def qcomplex(
        self, real: int | Fraction, imag: int | Fraction = 0
    ) -> tuple[Fraction, Fraction]:
        return self._module.qcomplex(real, imag)

    def analytic_write(
        self,
        left: Sequence[tuple[Fraction, Fraction]],
        right: Sequence[tuple[Fraction, Fraction]],
    ) -> AnalyticWriteReceiptLike:
        return self._module.analytic_write(left, right)

    def ledger_write(self, write_state: int, ledger_state: int, modulus: int) -> LedgerReceiptLike:
        return self._module.ledger_write(
            _strict_int(write_state, "write_state"),
            _strict_int(ledger_state, "ledger_state"),
            _strict_int(modulus, "modulus"),
        )

    def ledger_program(
        self,
        write_states: Sequence[int],
        ledger_state: int,
        modulus: int,
    ) -> tuple[tuple[LedgerReceiptLike, ...], int, int]:
        states = tuple(_strict_int(value, "write_state") for value in write_states)
        receipts, final_state, composed = self._module.ledger_program(
            states,
            _strict_int(ledger_state, "ledger_state"),
            _strict_int(modulus, "modulus"),
        )
        return tuple(receipts), int(final_state), int(composed)

    def mu4_character(self, q: int) -> tuple[int, int]:
        return tuple(self._module.mu4_character(_strict_int(q, "q")))

    def mu4_multiply(self, left: tuple[int, int], right: tuple[int, int]) -> tuple[int, int]:
        if (
            not isinstance(left, tuple) or len(left) != 2
            or not isinstance(right, tuple) or len(right) != 2
        ):
            raise TypeError("MU4 operands must be integer pairs")
        left_pair = (_strict_int(left[0], "left.real"), _strict_int(left[1], "left.imag"))
        right_pair = (_strict_int(right[0], "right.real"), _strict_int(right[1], "right.imag"))
        return tuple(self._module.mu4_multiply(left_pair, right_pair))

    def mu4_readback(self, q_before: int, q_after: int) -> tuple[int, int]:
        return tuple(
            self._module.mu4_readback(
                _strict_int(q_before, "q_before"), _strict_int(q_after, "q_after")
            )
        )

    def compare_native_batch(
        self,
        label: str,
        addresses: Iterable[int],
        program: Sequence[tuple[int, int]],
    ) -> NativeBatchComparison:
        """Compare pure event iteration, Python compilation, and both native routes."""

        if not label:
            raise ValueError("native comparison label cannot be empty")
        frozen_addresses = _strict_addresses(addresses)
        frozen_program = _strict_program(program)
        source = np.asarray(frozen_addresses, dtype=np.uint32)

        reference_values: list[int] = []
        for address in frozen_addresses:
            value = address
            for axis, delta in frozen_program:
                value = int(self._module.event_map(value, axis, delta))
            reference_values.append(value)
        reference = np.asarray(reference_values, dtype=np.uint32)

        reference_translation = int(self._module.compile_translation(frozen_program))
        python_compiled = np.asarray(
            [self._module.apply_translation(address, reference_translation) for address in frozen_addresses],
            dtype=np.uint32,
        )
        native_sequential = self._native.sequential(source, frozen_program)
        native_compiled, native_translation = self._native.compiled(source, frozen_program)
        return NativeBatchComparison(
            label=label,
            address_count=len(frozen_addresses),
            program_length=len(frozen_program),
            reference_translation=reference_translation,
            native_translation=int(native_translation),
            reference_equals_python_compiled=bool(np.array_equal(reference, python_compiled)),
            reference_equals_native_sequential=bool(np.array_equal(reference, native_sequential)),
            reference_equals_native_compiled=bool(np.array_equal(reference, native_compiled)),
            output_sha256=_packed_u32_sha256(reference),
        )

    @staticmethod
    def _deterministic_addresses() -> tuple[int, ...]:
        anchors = (0, 1, 2, 3, 7, 255, 256, 511, 512, (1 << 17), (1 << 18) - 1)
        generated = tuple((17 + 7_919 * index) % (1 << 18) for index in range(53))
        return tuple(dict.fromkeys(anchors + generated))

    def audit_exact_laws(self) -> ExactWriteLawAudit:
        """Execute a bounded exact fixture for every installed algebraic layer."""

        checks: list[ExactWriteLawCheck] = []

        def record(name: str, passed: bool, detail: str) -> None:
            checks.append(ExactWriteLawCheck(name, bool(passed), detail))

        # W8, Hamiltonian, W9 and two-site lifecycle.
        shell_census = tuple(self.w8_bits(shell) for shell in range(256))
        shell_reconstruction = all(
            sum(bit << index for index, bit in enumerate(bits)) == shell
            for shell, bits in enumerate(shell_census)
        )
        record(
            "W8_COMPLETE_SHELL_CENSUS",
            len(set(shell_census)) == 256 and shell_reconstruction,
            "256 shell states map bijectively to eight exact bits",
        )
        base = (Fraction(1, 3), Fraction(-2, 5), Fraction(7, 11))
        relay = (Fraction(2, 3), Fraction(1, 5), Fraction(-3, 11))
        record(
            "HAMILTONIAN_WELD_B0_B1",
            self.hamiltonian_weld(base, relay, 0) == base
            and self.hamiltonian_weld(base, relay, 1)
            == tuple(a + b for a, b in zip(base, relay)),
            "B=0 preserves H_W8 and B=1 adds the exact X1 relay",
        )
        source_site = self.w8_site(17)
        target_site = self.w8_site(93)
        active = self.activate_write(source_site, target_site, 4, -1, 37, 12_345)
        completed = self.complete_write(active)
        lifecycle_ok = (
            active.x1_custody == 1
            and active.source_phase == "W8"
            and active.target_phase == "W9"
            and self.project_w8(active.target_record) == 93
            and completed.x1_custody == 0
            and completed.source_phase == completed.target_phase == "W8"
            and completed.source.retained_records[-1] == completed.retained_record
            and completed.target.retained_records[-1] == completed.retained_record
            and completed.retained_record.address_after
            == self.event_map(12_345, 4, -1)
        )
        record(
            "W8_W9_TWO_SITE_LIFECYCLE",
            lifecycle_ok,
            "X1 activates once, both sites return to W8, and one W9 receipt is shared",
        )

        # Packed Z4^9 event laws, composition, inverse, and endpoint covariance.
        event_cases_ok = True
        for axis in range(9):
            for q in range(4):
                address = ((q & 1) << axis) | (((q >> 1) & 1) << (axis + 9))
                for delta in (-1, 1):
                    output = self.event_map(address, axis, delta)
                    event_cases_ok &= self.q_coordinate(output, axis) == (q + delta) % 4
                    event_cases_ok &= all(
                        self.q_coordinate(output, other) == self.q_coordinate(address, other)
                        for other in range(9)
                        if other != axis
                    )
        record(
            "PACKED_Z4_SIGNED_EVENT",
            event_cases_ok,
            "all 72 one-coordinate Z4 event cases increment exactly and preserve other axes",
        )

        first_program = ((0, 1), (1, -1), (8, 1), (0, 1), (4, -1), (3, 1))
        second_program = ((2, -1), (8, 1), (4, 1), (4, 1), (7, -1))
        first_translation = self.compile_translation(first_program)
        second_translation = self.compile_translation(second_program)
        composed_translation = self.compose_translations(first_translation, second_translation)
        inverse = self.inverse_translation(composed_translation)
        addresses = self._deterministic_addresses()
        translation_laws_ok = self.compile_translation(()) == 0
        for address in addresses:
            translation_laws_ok &= self.apply_translation(address, 0) == address
            translation_laws_ok &= (
                self.apply_translation(
                    self.apply_translation(address, first_translation), second_translation
                )
                == self.apply_translation(address, composed_translation)
            )
            translation_laws_ok &= self.apply_translation(
                self.apply_translation(address, composed_translation), inverse
            ) == address
        translation_laws_ok &= self.compose_translations(composed_translation, inverse) == 0
        record(
            "Z4_TRANSLATION_IDENTITY_COMPOSITION_INVERSE",
            translation_laws_ok,
            "identity, two-program composition, and exact inverse close on deterministic addresses",
        )

        covariance_ok = True
        for address in addresses[:12]:
            for axis in range(9):
                for delta in (-1, 1):
                    for k in range(4):
                        covariance_ok &= self.reverse_address(
                            self.event_map(address, axis, delta), k
                        ) == self.event_map(self.reverse_address(address, k), axis, -delta)
                        covariance_ok &= self.reverse_address(
                            self.reverse_address(address, k), k
                        ) == address
        record(
            "ENDPOINT_REVERSAL_COVARIANCE",
            covariance_ok,
            "G_k T_epsilon=T_-epsilon G_k and G_k^2=identity on bounded exact fixtures",
        )

        # History quotient, constant anchor, and exact reconstruction.
        left = tuple(Fraction(3 * index - 7, 5) for index in range(81))
        right = tuple(Fraction(2 * index + 11, 7) for index in range(81))
        quotient, anchor = self.history_quotient(left, right)
        reconstructed_left, reconstructed_right = quotient.reconstruct(anchor)
        history_ok = (
            len(quotient.symmetric_nonconstant) == 80
            and len(quotient.antisymmetric) == 81
            and len(quotient.coordinates) == 161
            and reconstructed_left == left
            and reconstructed_right == right
        )
        record(
            "HISTORY_QUOTIENT_PLUS_ANCHOR_RECONSTRUCTS",
            history_ok,
            "80+81 quotient coordinates plus the retained common anchor reconstruct both views",
        )
        common_shift = Fraction(13, 17)
        shifted_left = tuple(value + common_shift for value in left)
        shifted_right = tuple(value + common_shift for value in right)
        shifted_quotient, shifted_anchor = self.history_quotient(shifted_left, shifted_right)
        constant_kernel_ok = (
            shifted_quotient == quotient
            and shifted_anchor == anchor + 2 * common_shift
            and shifted_quotient.reconstruct(shifted_anchor) == (shifted_left, shifted_right)
        )
        record(
            "COMMON_CONSTANT_KERNEL_AND_ANCHOR",
            constant_kernel_ok,
            "a shared shift leaves the quotient fixed and moves only the reconstruction anchor",
        )

        # Completed projection and retained orthogonal information.
        energy = (Fraction(3), Fraction(4), Fraction(5))
        mode = (Fraction(1), Fraction(1), Fraction(0))
        projection = self.completed_projection(energy, mode)
        projection_ok = (
            projection.projection == (Fraction(7, 2), Fraction(7, 2), Fraction(0))
            and projection.resolved_response
            == tuple(-value for value in projection.projection)
            and tuple(
                projected + retained
                for projected, retained in zip(
                    projection.projection, projection.orthogonal_remainder
                )
            )
            == energy
            and projection.orthogonal
            and projection.conserved
            and projection.idempotent
            and self.completed_projection(projection.orthogonal_remainder, mode).projection
            == (Fraction(0), Fraction(0), Fraction(0))
        )
        record(
            "COMPLETED_PROJECTION_RESPONSE_REMAINDER",
            projection_ok,
            "negative response, exact conservation, orthogonality, reconstruction, and idempotence close",
        )

        # Analytic B_t/E_t/J/P+/P- identity.
        analytic_left = (
            self.qcomplex(1, 2), self.qcomplex(-3, 1), self.qcomplex(Fraction(5, 2), -1)
        )
        analytic_right = (
            self.qcomplex(2, -1), self.qcomplex(4, 3), self.qcomplex(Fraction(-1, 2), 2)
        )
        analytic = self.analytic_write(analytic_left, analytic_right)
        analytic_reconstructs = all(
            (
                (symmetric[0] + antisymmetric[0], symmetric[1] + antisymmetric[1])
                == original_left
                and (symmetric[0] - antisymmetric[0], symmetric[1] - antisymmetric[1])
                == original_right
            )
            for symmetric, antisymmetric, original_left, original_right in zip(
                analytic.symmetric_view,
                analytic.antisymmetric_view,
                analytic_left,
                analytic_right,
            )
        )
        record(
            "ANALYTIC_BT_ET_J_PPLUS_PMINUS",
            analytic.identity_closes and analytic_reconstructs,
            "difference energy, reciprocal correlations, exchange views, and centered factorization close exactly",
        )

        # Multiplicative ledger with explicit invertible and noninvertible types.
        invertible = self.ledger_write(7, 3, 11)
        noninvertible = self.ledger_write(5, 6, 12)
        ledger_receipts, ledger_final, ledger_composed = self.ledger_program((2, 3, 4), 5, 11)
        ledger_ok = (
            invertible.invertible_before
            and invertible.recovered_write_state == 7
            and invertible.after == 10
            and not noninvertible.invertible_before
            and noninvertible.recovered_write_state is None
            and noninvertible.after == 6
            and len(ledger_receipts) == 3
            and ledger_composed == (2 * 3 * 4) % 11
            and ledger_final == (5 * ledger_composed) % 11
            and all(
                receipt.before == (5 if index == 0 else ledger_receipts[index - 1].after)
                for index, receipt in enumerate(ledger_receipts)
            )
        )
        record(
            "MULTIPLICATIVE_LEDGER_AND_TYPED_NONINVERTIBILITY",
            ledger_ok,
            "invertible readback, exact composition, and an explicit noninvertible witness are retained",
        )

        # Z4 -> MU4 exact character and readback.
        mu4_ok = True
        for left_q in range(4):
            for right_q in range(4):
                mu4_ok &= self.mu4_multiply(
                    self.mu4_character(left_q), self.mu4_character(right_q)
                ) == self.mu4_character(left_q + right_q)
                mu4_ok &= self.mu4_readback(left_q, right_q) == self.mu4_character(
                    right_q - left_q
                )
        record(
            "Z4_MU4_CHARACTER_AND_READBACK",
            mu4_ok,
            "all 16 character products and directional readbacks close over exact integer pairs",
        )

        # Independent pure-reference/native equality on small deterministic batches.
        native_batches = (
            self.compare_native_batch("MIXED_SHORT", addresses, first_program),
            self.compare_native_batch("MIXED_COMPOSED", addresses, first_program + second_program),
            self.compare_native_batch(
                "BALANCED_CANCELLING",
                addresses,
                tuple((axis, sign) for axis in range(9) for sign in (1, -1)),
            ),
        )
        record(
            "REFERENCE_SEQUENTIAL_NATIVE_EQUALITY",
            all(batch.passed for batch in native_batches),
            "pure event iteration, Python compilation, native sequential, and native compiled outputs agree",
        )

        operation_surface_ok = (
            len(OPERATION_DESCRIPTORS) == 19
            and len(set(EXPECTED_OPERATION_IDS)) == 19
            and all(
                hasattr(self._module, symbol)
                for descriptor in OPERATION_DESCRIPTORS
                for symbol in descriptor.immutable_symbols
            )
        )
        record(
            "ALL_INSTALLED_COVERAGE_LAYERS_TYPED",
            operation_surface_ok,
            "19 paper-to-execution coverage rows have strict operation descriptors and live delegates",
        )

        final_custody = verify_exact_write_dependencies(self._dependency_receipt.repository_root)
        record(
            "IMMUTABLE_SOURCE_CUSTODY_UNCHANGED",
            final_custody == self._dependency_receipt,
            "all pinned hashes and exact SLCQ2-RZ authority fields match after execution",
        )

        return ExactWriteLawAudit(
            current_revision_name=self._dependency_receipt.current_revision_name,
            source_sha256=self._dependency_receipt.artifact("COMPLETE_EXACT_WRITE_SOURCE").sha256,
            native_library_sha256=self._dependency_receipt.artifact(
                "COMPLETE_EXACT_WRITE_NATIVE_LIBRARY"
            ).sha256,
            operation_ids=EXPECTED_OPERATION_IDS,
            checks=tuple(checks),
            native_batches=native_batches,
        )


__all__ = (
    "EXPECTED_CURRENT_REVISION_NAME",
    "PINNED_ARTIFACTS",
    "OPERATION_DESCRIPTORS",
    "EXPECTED_OPERATION_IDS",
    "ExactWriteDependencyError",
    "ArtifactPin",
    "VerifiedArtifact",
    "ExactWriteDependencyReceipt",
    "ExactWriteOperationDescriptor",
    "NativeBatchComparison",
    "ExactWriteLawCheck",
    "ExactWriteLawAudit",
    "W9RecordLike",
    "W8SiteLike",
    "ActiveWriteLike",
    "CompletedWriteLike",
    "HistoryQuotientLike",
    "ProjectionReceiptLike",
    "AnalyticWriteReceiptLike",
    "LedgerReceiptLike",
    "locate_repository_root",
    "verify_exact_write_dependencies",
    "CompleteExactWriteAdapter",
)
