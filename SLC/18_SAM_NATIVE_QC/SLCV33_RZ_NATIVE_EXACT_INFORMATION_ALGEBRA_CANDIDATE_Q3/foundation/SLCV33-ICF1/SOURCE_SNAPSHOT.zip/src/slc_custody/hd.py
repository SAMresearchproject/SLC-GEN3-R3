"""Exact formal-log and SAM HD coordinates for the V6 information plane.

Mathematical identity in this module is carried only by integers and
``fractions.Fraction``.  No logarithm is numerically evaluated and no binary
floating-point value is admitted at a construction or serialization boundary.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from functools import total_ordering
from math import gcd, lcm
from typing import Any, Iterable, Mapping


FORMAL_LOG_SCHEMA = "SLC_FORMAL_LOG_ELEMENT_V1"
FACTOR_PROOF_SCHEMA = "SLC_BOUNDED_RATIONAL_FACTOR_PROOF_V1"
HD_SCHEMA = "SLC_HD_SIGNATURE_V1"


class HDContractError(ValueError):
    """An exact HD/formal-log object violates its canonical contract."""


def _strict_int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise HDContractError(f"{label} must be an integer")
    return value


def _exact_fraction(value: Fraction | int, label: str) -> Fraction:
    if isinstance(value, bool) or not isinstance(value, (Fraction, int)):
        raise HDContractError(f"{label} must be an exact Fraction or integer")
    return value if isinstance(value, Fraction) else Fraction(value)


def _fraction_dict(value: Fraction) -> dict[str, int]:
    return {"denominator": value.denominator, "numerator": value.numerator}


def _fraction_from_dict(value: Any, label: str) -> Fraction:
    if not isinstance(value, Mapping) or set(value) != {"numerator", "denominator"}:
        raise HDContractError(f"{label} must contain numerator and denominator")
    numerator = _strict_int(value["numerator"], f"{label}.numerator")
    denominator = _strict_int(value["denominator"], f"{label}.denominator")
    if denominator <= 0:
        raise HDContractError(f"{label}.denominator must be positive")
    result = Fraction(numerator, denominator)
    if result.numerator != numerator or result.denominator != denominator:
        raise HDContractError(f"{label} must be reduced and canonical")
    return result


def _is_prime(value: int) -> bool:
    if value < 2:
        return False
    if value == 2:
        return True
    if value % 2 == 0:
        return False
    divisor = 3
    while divisor * divisor <= value:
        if value % divisor == 0:
            return False
        divisor += 2
    return True


def _factor_positive_integer(value: int) -> tuple[tuple[int, int], ...]:
    n = _strict_int(value, "factor input")
    if n < 1:
        raise HDContractError("factor input must be positive")
    factors: list[tuple[int, int]] = []
    divisor = 2
    while divisor * divisor <= n:
        exponent = 0
        while n % divisor == 0:
            n //= divisor
            exponent += 1
        if exponent:
            factors.append((divisor, exponent))
        divisor = 3 if divisor == 2 else divisor + 2
    if n > 1:
        factors.append((n, 1))
    return tuple(factors)


def _validate_factorization(
    factors: tuple[tuple[int, int], ...], label: str
) -> None:
    if not isinstance(factors, tuple):
        raise HDContractError(f"{label} must be a tuple")
    prior = 1
    for item in factors:
        if not isinstance(item, tuple) or len(item) != 2:
            raise HDContractError(f"{label} entries must be (prime, exponent) tuples")
        prime = _strict_int(item[0], f"{label}.prime")
        exponent = _strict_int(item[1], f"{label}.exponent")
        if not _is_prime(prime):
            raise HDContractError(f"{label} key {prime} is not prime")
        if prime <= prior:
            raise HDContractError(f"{label} prime keys must be strictly increasing")
        if exponent <= 0:
            raise HDContractError(f"{label} exponents must be positive")
        prior = prime


def _factor_product(factors: Iterable[tuple[int, int]]) -> int:
    product = 1
    for prime, exponent in factors:
        product *= prime**exponent
    return product


def _factor_list_to_dict(factors: tuple[tuple[int, int], ...]) -> list[dict[str, int]]:
    return [
        {"exponent": exponent, "prime": prime}
        for prime, exponent in factors
    ]


def _factor_list_from_dict(value: Any, label: str) -> tuple[tuple[int, int], ...]:
    if not isinstance(value, list):
        raise HDContractError(f"{label} must be a list")
    result: list[tuple[int, int]] = []
    for index, item in enumerate(value):
        if not isinstance(item, Mapping) or set(item) != {"prime", "exponent"}:
            raise HDContractError(
                f"{label}[{index}] must contain only prime and exponent"
            )
        result.append(
            (
                _strict_int(item["prime"], f"{label}[{index}].prime"),
                _strict_int(item["exponent"], f"{label}[{index}].exponent"),
            )
        )
    frozen = tuple(result)
    _validate_factorization(frozen, label)
    return frozen


def _coefficient_text(value: Fraction) -> str:
    if value.denominator == 1:
        return str(value.numerator)
    return f"{value.numerator}/{value.denominator}"


@total_ordering
@dataclass(frozen=True, slots=True)
class FormalLogElement:
    """A canonical finite rational linear combination of prime logarithms."""

    coefficients: tuple[tuple[int, Fraction], ...] = ()

    def __post_init__(self) -> None:
        if not isinstance(self.coefficients, tuple):
            raise HDContractError("formal-log coefficients must be a tuple")
        prior = 1
        for item in self.coefficients:
            if not isinstance(item, tuple) or len(item) != 2:
                raise HDContractError(
                    "formal-log entries must be (prime, Fraction) tuples"
                )
            prime = _strict_int(item[0], "formal-log prime")
            coefficient = item[1]
            if not isinstance(coefficient, Fraction):
                raise HDContractError("formal-log coefficients must be Fractions")
            if not _is_prime(prime):
                raise HDContractError(f"formal-log key {prime} is not prime")
            if prime <= prior:
                raise HDContractError(
                    "formal-log prime keys must be unique and strictly increasing"
                )
            if coefficient == 0:
                raise HDContractError("zero formal-log coefficients must be omitted")
            prior = prime

    @classmethod
    def zero(cls) -> "FormalLogElement":
        return cls()

    @classmethod
    def from_terms(
        cls, terms: Iterable[tuple[int, Fraction | int]]
    ) -> "FormalLogElement":
        accumulator: dict[int, Fraction] = {}
        for raw_prime, raw_coefficient in terms:
            prime = _strict_int(raw_prime, "formal-log prime")
            if not _is_prime(prime):
                raise HDContractError(f"formal-log key {prime} is not prime")
            coefficient = _exact_fraction(raw_coefficient, "formal-log coefficient")
            accumulator[prime] = accumulator.get(prime, Fraction()) + coefficient
        return cls(
            tuple(
                (prime, coefficient)
                for prime, coefficient in sorted(accumulator.items())
                if coefficient
            )
        )

    @classmethod
    def from_coefficients(
        cls, coefficients: Mapping[int, Fraction | int]
    ) -> "FormalLogElement":
        if not isinstance(coefficients, Mapping):
            raise HDContractError("formal-log coefficients must be a mapping")
        return cls.from_terms(coefficients.items())

    @classmethod
    def from_positive_rational(
        cls, value: Fraction | int
    ) -> "FormalLogElement":
        exact = _exact_fraction(value, "formal-log rational")
        if exact <= 0:
            raise HDContractError("formal logarithms require a positive rational")
        terms: list[tuple[int, int]] = list(_factor_positive_integer(exact.numerator))
        terms.extend(
            (prime, -exponent)
            for prime, exponent in _factor_positive_integer(exact.denominator)
        )
        return cls.from_terms(terms)

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "FormalLogElement":
        if not isinstance(value, Mapping) or set(value) != {
            "schema", "coefficients", "expression"
        }:
            raise HDContractError(
                "formal-log serialization must contain schema, coefficients, expression"
            )
        if value["schema"] != FORMAL_LOG_SCHEMA:
            raise HDContractError("unknown formal-log schema")
        raw_coefficients = value["coefficients"]
        if not isinstance(raw_coefficients, list):
            raise HDContractError("formal-log coefficients must serialize as a list")
        coefficients: list[tuple[int, Fraction]] = []
        for index, item in enumerate(raw_coefficients):
            if not isinstance(item, Mapping) or set(item) != {"prime", "coefficient"}:
                raise HDContractError(
                    f"formal-log coefficient {index} has noncanonical fields"
                )
            coefficients.append(
                (
                    _strict_int(item["prime"], f"coefficient[{index}].prime"),
                    _fraction_from_dict(
                        item["coefficient"], f"coefficient[{index}].coefficient"
                    ),
                )
            )
        result = cls(tuple(coefficients))
        if not isinstance(value["expression"], str) or value["expression"] != result.expression:
            raise HDContractError("formal-log expression does not match coefficients")
        return result

    def __add__(self, other: object) -> "FormalLogElement":
        if not isinstance(other, FormalLogElement):
            return NotImplemented
        return FormalLogElement.from_terms(self.coefficients + other.coefficients)

    def __sub__(self, other: object) -> "FormalLogElement":
        if not isinstance(other, FormalLogElement):
            return NotImplemented
        return self + other.scale(Fraction(-1))

    def scale(self, scalar: Fraction | int) -> "FormalLogElement":
        exact = _exact_fraction(scalar, "formal-log scale")
        return FormalLogElement.from_terms(
            (prime, exact * coefficient)
            for prime, coefficient in self.coefficients
        )

    @property
    def expression(self) -> str:
        if not self.coefficients:
            return "0"
        terms: list[str] = []
        for prime, coefficient in self.coefficients:
            magnitude = abs(coefficient)
            atom = (
                f"ln({prime})"
                if magnitude == 1
                else f"{_coefficient_text(magnitude)}*ln({prime})"
            )
            if not terms:
                terms.append(atom if coefficient > 0 else f"-{atom}")
            else:
                terms.append((" + " if coefficient > 0 else " - ") + atom)
        return "".join(terms)

    @property
    def is_zero(self) -> bool:
        """Return whether this formal-log element is the additive identity."""

        return not self.coefficients

    @property
    def sign(self) -> int:
        """Return the exact real sign without evaluating a logarithm."""

        if not self.coefficients:
            return 0
        denominator = 1
        for _prime, coefficient in self.coefficients:
            denominator = lcm(denominator, coefficient.denominator)
        numerator_product = 1
        denominator_product = 1
        for prime, coefficient in self.coefficients:
            exponent = coefficient.numerator * (denominator // coefficient.denominator)
            if exponent > 0:
                numerator_product *= prime**exponent
            else:
                denominator_product *= prime ** (-exponent)
        if numerator_product == denominator_product:
            return 0
        return 1 if numerator_product > denominator_product else -1

    def compare(self, other: "FormalLogElement") -> int:
        if not isinstance(other, FormalLogElement):
            raise TypeError("formal-log comparison requires FormalLogElement")
        return (self - other).sign

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, FormalLogElement):
            return NotImplemented
        return self.compare(other) < 0

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": FORMAL_LOG_SCHEMA,
            "coefficients": [
                {
                    "prime": prime,
                    "coefficient": _fraction_dict(coefficient),
                }
                for prime, coefficient in self.coefficients
            ],
            "expression": self.expression,
        }


@dataclass(frozen=True, slots=True)
class RationalFactorProof:
    """A complete factor certificate for one bounded nonzero rational."""

    value: Fraction
    maximum_component: int
    sign: int
    numerator_factors: tuple[tuple[int, int], ...]
    denominator_factors: tuple[tuple[int, int], ...]

    def __post_init__(self) -> None:
        if not isinstance(self.value, Fraction) or self.value == 0:
            raise HDContractError("factor-proof value must be a nonzero Fraction")
        bound = _strict_int(self.maximum_component, "maximum_component")
        if bound < 1:
            raise HDContractError("maximum_component must be positive")
        if self.sign not in (-1, 1) or self.sign != (1 if self.value > 0 else -1):
            raise HDContractError("factor-proof sign does not match its value")
        if abs(self.value.numerator) > bound or self.value.denominator > bound:
            raise HDContractError("factor-proof value exceeds maximum_component")
        _validate_factorization(self.numerator_factors, "numerator_factors")
        _validate_factorization(self.denominator_factors, "denominator_factors")
        if _factor_product(self.numerator_factors) != abs(self.value.numerator):
            raise HDContractError("numerator factor proof does not reconstruct")
        if _factor_product(self.denominator_factors) != self.value.denominator:
            raise HDContractError("denominator factor proof does not reconstruct")
        if gcd(
            _factor_product(self.numerator_factors),
            _factor_product(self.denominator_factors),
        ) != 1:
            raise HDContractError("factor proof must represent a reduced rational")

    @classmethod
    def build(
        cls,
        value: Fraction | int,
        *,
        maximum_component: int,
    ) -> "RationalFactorProof":
        exact = _exact_fraction(value, "factor-proof value")
        if exact == 0:
            raise HDContractError("zero has no ordinary prime factor proof")
        bound = _strict_int(maximum_component, "maximum_component")
        return cls(
            value=exact,
            maximum_component=bound,
            sign=1 if exact > 0 else -1,
            numerator_factors=_factor_positive_integer(abs(exact.numerator)),
            denominator_factors=_factor_positive_integer(exact.denominator),
        )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "RationalFactorProof":
        expected = {
            "schema", "value", "maximum_component", "sign",
            "numerator_factors", "denominator_factors", "complete",
        }
        if not isinstance(value, Mapping) or set(value) != expected:
            raise HDContractError("factor-proof serialization has noncanonical fields")
        if value["schema"] != FACTOR_PROOF_SCHEMA or value["complete"] is not True:
            raise HDContractError("factor-proof schema or completion marker is invalid")
        return cls(
            value=_fraction_from_dict(value["value"], "factor-proof value"),
            maximum_component=_strict_int(
                value["maximum_component"], "maximum_component"
            ),
            sign=_strict_int(value["sign"], "factor-proof sign"),
            numerator_factors=_factor_list_from_dict(
                value["numerator_factors"], "numerator_factors"
            ),
            denominator_factors=_factor_list_from_dict(
                value["denominator_factors"], "denominator_factors"
            ),
        )

    @property
    def formal_log(self) -> FormalLogElement:
        return FormalLogElement.from_terms(
            list(self.numerator_factors)
            + [(prime, -exponent) for prime, exponent in self.denominator_factors]
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": FACTOR_PROOF_SCHEMA,
            "value": _fraction_dict(self.value),
            "maximum_component": self.maximum_component,
            "sign": self.sign,
            "numerator_factors": _factor_list_to_dict(self.numerator_factors),
            "denominator_factors": _factor_list_to_dict(self.denominator_factors),
            "complete": True,
        }


def factor_bounded_rational(
    value: Fraction | int, *, maximum_component: int
) -> RationalFactorProof:
    """Return a complete exact factor proof inside a declared component bound."""

    return RationalFactorProof.build(value, maximum_component=maximum_component)


def _valuation_integer(value: int, prime: int) -> int:
    exponent = 0
    while value % prime == 0:
        value //= prime
        exponent += 1
    return exponent


def _prime_valuation(value: Fraction, prime: int) -> int:
    return _valuation_integer(abs(value.numerator), prime) - _valuation_integer(
        value.denominator, prime
    )


def _prime_power(prime: int, exponent: int) -> Fraction:
    return (
        Fraction(prime**exponent)
        if exponent >= 0
        else Fraction(1, prime ** (-exponent))
    )


@dataclass(frozen=True, slots=True)
class HDSignature:
    """Exact ``sign * 2^v2 * 3^v3 * cofactor`` coordinate or ZERO."""

    variant: str
    sign: int | None = None
    v2: int | None = None
    v3: int | None = None
    coprime_cofactor: Fraction | None = None

    def __post_init__(self) -> None:
        if self.variant == "ZERO":
            if any(
                value is not None
                for value in (self.sign, self.v2, self.v3, self.coprime_cofactor)
            ):
                raise HDContractError("ZERO HD signature has no finite coordinates")
            return
        if self.variant != "NONZERO":
            raise HDContractError("HD variant must be ZERO or NONZERO")
        if self.sign not in (-1, 1):
            raise HDContractError("nonzero HD sign must be -1 or 1")
        _strict_int(self.v2, "HD v2")
        _strict_int(self.v3, "HD v3")
        if not isinstance(self.coprime_cofactor, Fraction):
            raise HDContractError("HD cofactor must be a Fraction")
        if self.coprime_cofactor <= 0:
            raise HDContractError("HD cofactor must be positive")
        if (
            self.coprime_cofactor.numerator % 2 == 0
            or self.coprime_cofactor.denominator % 2 == 0
            or self.coprime_cofactor.numerator % 3 == 0
            or self.coprime_cofactor.denominator % 3 == 0
        ):
            raise HDContractError("HD cofactor numerator and denominator must be coprime to 6")

    @classmethod
    def zero(cls) -> "HDSignature":
        return cls("ZERO")

    @classmethod
    def from_rational(cls, value: Fraction | int) -> "HDSignature":
        exact = _exact_fraction(value, "HD input")
        if exact == 0:
            return cls.zero()
        magnitude = abs(exact)
        v2 = _prime_valuation(magnitude, 2)
        v3 = _prime_valuation(magnitude, 3)
        cofactor = magnitude / _prime_power(2, v2) / _prime_power(3, v3)
        return cls(
            variant="NONZERO",
            sign=1 if exact > 0 else -1,
            v2=v2,
            v3=v3,
            coprime_cofactor=cofactor,
        )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "HDSignature":
        if not isinstance(value, Mapping):
            raise HDContractError("HD serialization must be a mapping")
        if value.get("schema") != HD_SCHEMA:
            raise HDContractError("unknown HD schema")
        if value.get("variant") == "ZERO":
            if set(value) != {"schema", "variant"}:
                raise HDContractError("ZERO HD serialization has noncanonical fields")
            return cls.zero()
        expected = {"schema", "variant", "sign", "v2", "v3", "coprime_cofactor"}
        if set(value) != expected or value.get("variant") != "NONZERO":
            raise HDContractError("NONZERO HD serialization has noncanonical fields")
        return cls(
            variant="NONZERO",
            sign=_strict_int(value["sign"], "HD sign"),
            v2=_strict_int(value["v2"], "HD v2"),
            v3=_strict_int(value["v3"], "HD v3"),
            coprime_cofactor=_fraction_from_dict(
                value["coprime_cofactor"], "HD coprime_cofactor"
            ),
        )

    @property
    def is_zero(self) -> bool:
        return self.variant == "ZERO"

    @property
    def value(self) -> Fraction:
        if self.is_zero:
            return Fraction(0)
        assert self.sign is not None
        assert self.v2 is not None and self.v3 is not None
        assert self.coprime_cofactor is not None
        return (
            self.sign
            * _prime_power(2, self.v2)
            * _prime_power(3, self.v3)
            * self.coprime_cofactor
        )

    @property
    def formal_log(self) -> FormalLogElement:
        if self.is_zero:
            raise HDContractError("ZERO has no finite formal logarithm")
        return FormalLogElement.from_positive_rational(abs(self.value))

    def multiply(self, other: "HDSignature") -> "HDSignature":
        if not isinstance(other, HDSignature):
            raise TypeError("HD multiplication requires HDSignature")
        if self.is_zero or other.is_zero:
            return HDSignature.zero()
        assert self.sign is not None and other.sign is not None
        assert self.v2 is not None and other.v2 is not None
        assert self.v3 is not None and other.v3 is not None
        assert self.coprime_cofactor is not None
        assert other.coprime_cofactor is not None
        return HDSignature(
            "NONZERO",
            self.sign * other.sign,
            self.v2 + other.v2,
            self.v3 + other.v3,
            self.coprime_cofactor * other.coprime_cofactor,
        )

    def divide(self, other: "HDSignature") -> "HDSignature":
        if not isinstance(other, HDSignature):
            raise TypeError("HD division requires HDSignature")
        if other.is_zero:
            raise ZeroDivisionError("cannot divide by ZERO HD signature")
        if self.is_zero:
            return HDSignature.zero()
        assert self.sign is not None and other.sign is not None
        assert self.v2 is not None and other.v2 is not None
        assert self.v3 is not None and other.v3 is not None
        assert self.coprime_cofactor is not None
        assert other.coprime_cofactor is not None
        return HDSignature(
            "NONZERO",
            self.sign * other.sign,
            self.v2 - other.v2,
            self.v3 - other.v3,
            self.coprime_cofactor / other.coprime_cofactor,
        )

    def __mul__(self, other: object) -> "HDSignature":
        if not isinstance(other, HDSignature):
            return NotImplemented
        return self.multiply(other)

    def __truediv__(self, other: object) -> "HDSignature":
        if not isinstance(other, HDSignature):
            return NotImplemented
        return self.divide(other)

    def to_dict(self) -> dict[str, object]:
        if self.is_zero:
            return {"schema": HD_SCHEMA, "variant": "ZERO"}
        assert self.sign is not None
        assert self.v2 is not None and self.v3 is not None
        assert self.coprime_cofactor is not None
        return {
            "schema": HD_SCHEMA,
            "variant": "NONZERO",
            "sign": self.sign,
            "v2": self.v2,
            "v3": self.v3,
            "coprime_cofactor": _fraction_dict(self.coprime_cofactor),
        }


__all__ = (
    "FACTOR_PROOF_SCHEMA",
    "FORMAL_LOG_SCHEMA",
    "HD_SCHEMA",
    "FormalLogElement",
    "HDContractError",
    "HDSignature",
    "RationalFactorProof",
    "factor_bounded_rational",
)
