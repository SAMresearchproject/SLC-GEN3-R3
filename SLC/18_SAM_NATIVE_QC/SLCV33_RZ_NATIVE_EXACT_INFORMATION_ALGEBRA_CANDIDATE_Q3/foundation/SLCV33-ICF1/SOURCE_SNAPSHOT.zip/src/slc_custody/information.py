"""Exact finite partitions, receipt sufficiency, and information custody.

This module treats partitions as the probability-free primary object.  A
probability law is added only when Shannon quantities are requested.  No
binary floating-point number participates in a mathematical identity.
"""

from __future__ import annotations

import hashlib
import heapq
import json
from dataclasses import dataclass
from fractions import Fraction
from itertools import combinations
from typing import Callable, Hashable, Iterable, Mapping, TypeVar

from .hd import FormalLogElement


X = TypeVar("X", bound=Hashable)


def _strict_form(value: object) -> object:
    """Return a deterministic exact JSON form and reject lossy identities."""

    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, Fraction):
        return {"fraction": [value.numerator, value.denominator]}
    if isinstance(value, tuple):
        return {"tuple": [_strict_form(item) for item in value]}
    if isinstance(value, list):
        return {"list": [_strict_form(item) for item in value]}
    if isinstance(value, dict):
        rows = [
            (_strict_bytes(key), _strict_form(key), _strict_form(item))
            for key, item in value.items()
        ]
        rows.sort(key=lambda row: row[0])
        return {"dict": [[key, item] for _, key, item in rows]}
    if isinstance(value, float):
        raise TypeError("binary floating point cannot define an exact identity")
    raise TypeError(f"unsupported exact identity type: {type(value).__qualname__}")


def _strict_bytes(value: object) -> bytes:
    return json.dumps(
        _strict_form(value), sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("utf-8")


def _sorted_unique(values: Iterable[X]) -> tuple[X, ...]:
    ordered = tuple(sorted(tuple(values), key=_strict_bytes))
    if not ordered:
        raise ValueError("partition domain cannot be empty")
    if len(set(ordered)) != len(ordered):
        raise ValueError("partition domain contains duplicates")
    return ordered


def _exact_fraction(value: Fraction | int, label: str) -> Fraction:
    if isinstance(value, bool) or not isinstance(value, (Fraction, int)):
        raise TypeError(f"{label} must be an exact Fraction or integer")
    return value if isinstance(value, Fraction) else Fraction(value)


def uniform_conditional_entropy_from_fiber_sizes(
    fiber_sizes: Iterable[int],
) -> FormalLogElement:
    """Return ``(1/N) sum_y m_y ln(m_y)`` from exact finite counts."""

    sizes = tuple(fiber_sizes)
    if not sizes or any(type(size) is not int or size < 1 for size in sizes):
        raise ValueError("fiber sizes must be a nonempty sequence of positive integers")
    total = sum(sizes)
    result = FormalLogElement.zero()
    for size in sizes:
        result = result + FormalLogElement.from_positive_rational(size).scale(
            Fraction(size, total)
        )
    return result


@dataclass(frozen=True, slots=True)
class InformationPartition:
    """A finite partition represented by exact labels on a canonical domain."""

    name: str
    domain: tuple[Hashable, ...]
    labels: tuple[Hashable, ...]

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("partition name cannot be empty")
        if not self.domain or len(self.domain) != len(self.labels):
            raise ValueError("partition domain and labels must have equal nonzero length")
        if tuple(sorted(self.domain, key=_strict_bytes)) != self.domain:
            raise ValueError("partition domain must be in strict canonical order")
        if len(set(self.domain)) != len(self.domain):
            raise ValueError("partition domain contains duplicates")
        for label in self.labels:
            hash(label)
            _strict_bytes(label)

    @classmethod
    def from_map(
        cls,
        name: str,
        domain: Iterable[X],
        observable: Mapping[X, Hashable] | Callable[[X], Hashable],
    ) -> "InformationPartition":
        canonical = _sorted_unique(domain)
        function = observable.__getitem__ if isinstance(observable, Mapping) else observable
        labels = tuple(function(item) for item in canonical)
        return cls(str(name), canonical, labels)

    @property
    def blocks(self) -> tuple[tuple[Hashable, ...], ...]:
        mutable: dict[Hashable, list[Hashable]] = {}
        for item, label in zip(self.domain, self.labels):
            mutable.setdefault(label, []).append(item)
        return tuple(
            sorted(
                (tuple(items) for items in mutable.values()),
                key=lambda block: _strict_bytes(block[0]),
            )
        )

    @property
    def block_ids(self) -> tuple[int, ...]:
        """Canonical label-name-independent block identifiers."""

        by_item: dict[Hashable, int] = {}
        for index, block in enumerate(self.blocks):
            for item in block:
                by_item[item] = index
        return tuple(by_item[item] for item in self.domain)

    @property
    def mathematical_id(self) -> str:
        payload = {
            "domain": [_strict_form(item) for item in self.domain],
            "block_ids": list(self.block_ids),
        }
        raw = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()
        return hashlib.sha256(raw).hexdigest()

    @property
    def is_discrete(self) -> bool:
        return all(len(block) == 1 for block in self.blocks)

    @property
    def fiber_sizes(self) -> tuple[int, ...]:
        return tuple(sorted(len(block) for block in self.blocks))

    @property
    def worst_fiber_size(self) -> int:
        return max(self.fiber_sizes)

    @property
    def worst_container_bits(self) -> int:
        return (self.worst_fiber_size - 1).bit_length()

    def combined(
        self, other: "InformationPartition", *, name: str | None = None
    ) -> "InformationPartition":
        self._same_domain(other)
        return InformationPartition(
            name or f"{self.name}_JOIN_{other.name}",
            self.domain,
            tuple(zip(self.labels, other.labels)),
        )

    def refines(self, other: "InformationPartition") -> bool:
        """Return whether every block of self lies inside a block of other."""

        self._same_domain(other)
        seen: dict[Hashable, Hashable] = {}
        for fine, coarse in zip(self.labels, other.labels):
            previous = seen.setdefault(fine, coarse)
            if previous != coarse:
                return False
        return True

    def equivalent(self, other: "InformationPartition") -> bool:
        self._same_domain(other)
        return self.block_ids == other.block_ids

    def _same_domain(self, other: "InformationPartition") -> None:
        if self.domain != other.domain:
            raise ValueError("partitions do not have the same canonical domain")

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_INFORMATION_PARTITION_V6",
            "name": self.name,
            "mathematical_id": self.mathematical_id,
            "domain_size": len(self.domain),
            "block_count": len(self.blocks),
            "fiber_sizes": list(self.fiber_sizes),
            "discrete": self.is_discrete,
            "worst_container_bits": self.worst_container_bits,
        }


@dataclass(frozen=True, slots=True)
class ExactDistribution:
    """An exact rational probability law on a canonical finite domain."""

    domain: tuple[Hashable, ...]
    probabilities: tuple[Fraction, ...]
    provenance: str

    def __post_init__(self) -> None:
        if not self.provenance:
            raise ValueError("probability provenance cannot be empty")
        if not self.domain or len(self.domain) != len(self.probabilities):
            raise ValueError("probability law has the wrong dimension")
        if tuple(sorted(self.domain, key=_strict_bytes)) != self.domain:
            raise ValueError("probability domain must be in canonical order")
        if len(set(self.domain)) != len(self.domain):
            raise ValueError("probability domain contains duplicates")
        exact_probabilities = tuple(
            _exact_fraction(value, "probability") for value in self.probabilities
        )
        if exact_probabilities != self.probabilities:
            raise ValueError("probabilities must be stored canonically as Fractions")
        if any(value <= 0 for value in exact_probabilities):
            raise ValueError("probabilities must be strictly positive")
        if sum(exact_probabilities, Fraction()) != 1:
            raise ValueError("probabilities must sum exactly to one")

    @classmethod
    def uniform(cls, domain: Iterable[X], *, provenance: str) -> "ExactDistribution":
        canonical = _sorted_unique(domain)
        probability = Fraction(1, len(canonical))
        return cls(canonical, (probability,) * len(canonical), provenance)

    @classmethod
    def from_weights(
        cls,
        weights: Mapping[X, Fraction | int],
        *,
        provenance: str,
    ) -> "ExactDistribution":
        canonical = _sorted_unique(weights)
        exact = tuple(
            _exact_fraction(weights[item], f"source weight for {item!r}")
            for item in canonical
        )
        total = sum(exact, Fraction())
        if total <= 0:
            raise ValueError("source weights must have positive total")
        return cls(canonical, tuple(value / total for value in exact), provenance)

    def _check(self, partition: InformationPartition) -> None:
        if self.domain != partition.domain:
            raise ValueError("probability law and partition domains differ")

    @staticmethod
    def _entropy(probabilities: Iterable[Fraction]) -> FormalLogElement:
        result = FormalLogElement.zero()
        for raw in probabilities:
            probability = _exact_fraction(raw, "entropy probability")
            if probability <= 0:
                continue
            result = result - FormalLogElement.from_positive_rational(probability).scale(probability)
        return result

    @property
    def source_entropy(self) -> FormalLogElement:
        return self._entropy(self.probabilities)

    def block_masses(self, partition: InformationPartition) -> tuple[Fraction, ...]:
        self._check(partition)
        masses: dict[int, Fraction] = {}
        for block_id, probability in zip(partition.block_ids, self.probabilities):
            masses[block_id] = masses.get(block_id, Fraction()) + probability
        return tuple(masses[index] for index in sorted(masses))

    def observable_entropy(self, partition: InformationPartition) -> FormalLogElement:
        return self._entropy(self.block_masses(partition))

    def conditional_source_entropy(self, partition: InformationPartition) -> FormalLogElement:
        return self.source_entropy - self.observable_entropy(partition)

    def conditional_information(
        self,
        base: InformationPartition,
        refined: InformationPartition,
    ) -> FormalLogElement:
        if not refined.refines(base):
            raise ValueError("conditional information requires a refining partition")
        return self.observable_entropy(refined) - self.observable_entropy(base)


@dataclass(frozen=True, slots=True)
class ReceiptChannel:
    name: str
    partition: InformationPartition

    def __post_init__(self) -> None:
        if not self.name:
            raise ValueError("receipt channel name cannot be empty")


@dataclass(frozen=True, slots=True)
class ReceiptSufficiencyCertificate:
    visible_partition_id: str
    selected_channels: tuple[str, ...]
    redundant_channels: tuple[str, ...]
    collision_pair_count: int
    distinguished_pair_count: int
    augmented_partition_id: str
    reconstructs_source: bool
    sufficient_subset_exists: bool
    exact_minimum: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_RECEIPT_SUFFICIENCY_CERTIFICATE_V6",
            "visible_partition_id": self.visible_partition_id,
            "selected_channels": list(self.selected_channels),
            "redundant_channels": list(self.redundant_channels),
            "collision_pair_count": self.collision_pair_count,
            "distinguished_pair_count": self.distinguished_pair_count,
            "augmented_partition_id": self.augmented_partition_id,
            "reconstructs_source": self.reconstructs_source,
            "sufficient_subset_exists": self.sufficient_subset_exists,
            "exact_minimum": self.exact_minimum,
        }


class ReceiptSystem:
    """A visible partition and separately typed receipt channels."""

    def __init__(
        self,
        visible: InformationPartition,
        channels: Iterable[ReceiptChannel],
    ) -> None:
        self.visible = visible
        rows = tuple(sorted(tuple(channels), key=lambda row: row.name))
        if len({row.name for row in rows}) != len(rows):
            raise ValueError("receipt channel names must be unique")
        for row in rows:
            visible._same_domain(row.partition)
        self.channels = rows
        self._by_name = {row.name: row for row in rows}

    @property
    def channel_names(self) -> tuple[str, ...]:
        return tuple(row.name for row in self.channels)

    def augmented(self, selected: Iterable[str]) -> InformationPartition:
        names = tuple(sorted(set(selected)))
        unknown = set(names) - set(self._by_name)
        if unknown:
            raise KeyError(f"unknown receipt channels: {sorted(unknown)}")
        result = self.visible
        for name in names:
            result = result.combined(self._by_name[name].partition, name=f"{result.name}+{name}")
        return result

    @property
    def collision_pairs(self) -> tuple[tuple[Hashable, Hashable], ...]:
        pairs: list[tuple[Hashable, Hashable]] = []
        for block in self.visible.blocks:
            pairs.extend(combinations(block, 2))
        return tuple(pairs)

    def distinguished_pairs(self, channel: str) -> frozenset[tuple[Hashable, Hashable]]:
        partition = self._by_name[channel].partition
        labels = dict(zip(partition.domain, partition.labels))
        return frozenset(pair for pair in self.collision_pairs if labels[pair[0]] != labels[pair[1]])

    def minimum_sufficient_channels(self, *, exact_limit: int = 20) -> ReceiptSufficiencyCertificate:
        names = self.channel_names
        collisions = frozenset(self.collision_pairs)
        coverage = {name: self.distinguished_pairs(name) for name in names}
        if len(names) > exact_limit:
            raise ValueError("exact minimum receipt search exceeds declared channel limit")
        selected: tuple[str, ...] | None = None
        for width in range(len(names) + 1):
            for candidate in combinations(names, width):
                covered = frozenset().union(*(coverage[name] for name in candidate)) if candidate else frozenset()
                if covered == collisions:
                    selected = candidate
                    break
            if selected is not None:
                break
        sufficient_subset_exists = selected is not None
        if selected is None:
            selected = names
        augmented = self.augmented(selected)
        covered = frozenset().union(*(coverage[name] for name in selected)) if selected else frozenset()
        return ReceiptSufficiencyCertificate(
            visible_partition_id=self.visible.mathematical_id,
            selected_channels=selected,
            redundant_channels=tuple(name for name in names if name not in selected),
            collision_pair_count=len(collisions),
            distinguished_pair_count=len(covered),
            augmented_partition_id=augmented.mathematical_id,
            reconstructs_source=augmented.is_discrete,
            sufficient_subset_exists=sufficient_subset_exists,
            exact_minimum=sufficient_subset_exists,
        )

    def verified_greedy_sufficient_channels(self) -> ReceiptSufficiencyCertificate:
        """Greedily cover visible collisions, then verify the selected join.

        This is the bounded fallback when exhaustive minimum search is outside
        its declared channel limit. Selection uses exact collision sets and a
        deterministic name tie-break. The returned partition is independently
        checked for reconstruction and is never labeled an exact minimum.
        """

        names = self.channel_names
        collisions = frozenset(self.collision_pairs)
        coverage = {name: self.distinguished_pairs(name) for name in names}
        uncovered = set(collisions)
        selected: list[str] = []
        available = set(names)
        while uncovered and available:
            ranked = sorted(
                (
                    (-len(coverage[name] & uncovered), name)
                    for name in available
                )
            )
            negative_gain, chosen = ranked[0]
            if negative_gain == 0:
                break
            selected.append(chosen)
            uncovered.difference_update(coverage[chosen])
            available.remove(chosen)
        canonical_selected = tuple(sorted(selected))
        augmented = self.augmented(canonical_selected)
        covered = (
            frozenset().union(
                *(coverage[name] for name in canonical_selected)
            )
            if canonical_selected
            else frozenset()
        )
        reconstructs = augmented.is_discrete
        return ReceiptSufficiencyCertificate(
            visible_partition_id=self.visible.mathematical_id,
            selected_channels=canonical_selected,
            redundant_channels=tuple(
                name for name in names if name not in canonical_selected
            ),
            collision_pair_count=len(collisions),
            distinguished_pair_count=len(covered),
            augmented_partition_id=augmented.mathematical_id,
            reconstructs_source=reconstructs,
            sufficient_subset_exists=reconstructs,
            exact_minimum=False,
        )

    def information_identity(
        self,
        distribution: ExactDistribution,
        selected: Iterable[str],
    ) -> dict[str, object]:
        augmented = self.augmented(selected)
        hidden = distribution.conditional_source_entropy(self.visible)
        retained = distribution.conditional_information(self.visible, augmented)
        remaining = distribution.conditional_source_entropy(augmented)
        residual = hidden - retained - remaining
        return {
            "schema": "SLC_INFORMATION_CUSTODY_IDENTITY_V6",
            "hidden": hidden.to_dict(),
            "retained": retained.to_dict(),
            "remaining": remaining.to_dict(),
            "residual": residual.to_dict(),
            "identity_exact": residual.is_zero,
            "augmented_injective": augmented.is_discrete,
            "probability_provenance": distribution.provenance,
        }

    def rank(
        self,
        distribution: ExactDistribution,
        selected: Iterable[str],
    ) -> FormalLogElement:
        return distribution.conditional_information(self.visible, self.augmented(selected))

    def data_processing_certificate(
        self,
        distribution: ExactDistribution,
        upstream_selected: Iterable[str],
        downstream: InformationPartition,
    ) -> dict[str, object]:
        """Certify exact information monotonicity for a deterministic quotient.

        ``downstream`` must retain the visible observable and be a quotient of
        the selected augmented receipt.  These refinement conditions are the
        finite deterministic statement that the downstream value is computed
        from the upstream value without access to the source.
        """

        upstream = self.augmented(upstream_selected)
        upstream._same_domain(downstream)
        if not upstream.refines(downstream):
            raise ValueError("downstream is not a quotient of the upstream receipt")
        if not downstream.refines(self.visible):
            raise ValueError("downstream does not retain the visible observable")
        upstream_information = distribution.conditional_information(
            self.visible, upstream
        )
        downstream_information = distribution.conditional_information(
            self.visible, downstream
        )
        residual = upstream_information - downstream_information
        return {
            "schema": "SLC_EXACT_DATA_PROCESSING_CERTIFICATE_V6",
            "upstream_partition_id": upstream.mathematical_id,
            "downstream_partition_id": downstream.mathematical_id,
            "upstream_information": upstream_information.to_dict(),
            "downstream_information": downstream_information.to_dict(),
            "residual": residual.to_dict(),
            "upstream_refines_downstream": True,
            "downstream_retains_visible": True,
            "inequality_exact": residual.sign >= 0,
            "probability_provenance": distribution.provenance,
        }

    def submodularity_certificate(self, distribution: ExactDistribution) -> dict[str, object]:
        names = self.channel_names
        failures: list[dict[str, object]] = []
        checked = 0
        subsets = [
            frozenset(candidate)
            for width in range(len(names) + 1)
            for candidate in combinations(names, width)
        ]
        ranks = {subset: self.rank(distribution, subset) for subset in subsets}
        for left in subsets:
            for right in subsets:
                checked += 1
                residual = ranks[left] + ranks[right] - ranks[left | right] - ranks[left & right]
                if residual.sign < 0:
                    failures.append({
                        "left": sorted(left),
                        "right": sorted(right),
                        "residual": residual.to_dict(),
                    })
        return {
            "schema": "SLC_SHANNON_SUBMODULARITY_CERTIFICATE_V6",
            "subset_pair_count": checked,
            "failures": failures,
            "status": "PASS" if not failures else "FAIL",
        }

    def uncomputation_plan(self) -> dict[str, object]:
        certificate = self.minimum_sufficient_channels()
        kept = certificate.selected_channels
        kept_partition = self.augmented(kept)
        release_rows: list[dict[str, object]] = []
        all_recoverable = True
        for name in certificate.redundant_channels:
            recoverable = kept_partition.refines(self._by_name[name].partition)
            all_recoverable = all_recoverable and recoverable
            release_rows.append({
                "channel": name,
                "recoverable_from_final_kept_state": recoverable,
                "action": "COPY_OUTPUT_THEN_APPLY_DECLARED_INVERSE" if recoverable else "KEEP_LIVE",
            })
        return {
            "schema": "SLC_BENNETT_STYLE_UNCOMPUTATION_PLAN_V6",
            "peak_live_channel_count": len(self.channels),
            "final_kept_channel_count": len(kept),
            "kept_channels": list(kept),
            "release_schedule": release_rows,
            "final_augmented_injective": kept_partition.is_discrete,
            "all_released_channels_recoverable": all_recoverable,
            "logical_erasure_exact_nats": FormalLogElement.zero().to_dict(),
            "status": (
                "CERTIFIED_INFORMATION_RECOVERABLE"
                if kept_partition.is_discrete and all_recoverable
                else "INCOMPLETE"
            ),
        }


@dataclass(frozen=True, slots=True)
class ExactPrefixCode:
    """Canonical Huffman lengths and exact expected storage for a source law."""

    lengths: tuple[tuple[Hashable, int], ...]
    expected_bits: Fraction
    kraft_sum: Fraction
    entropy_nats: FormalLogElement
    shannon_upper_residual_nats: FormalLogElement

    @classmethod
    def build(cls, distribution: ExactDistribution) -> "ExactPrefixCode":
        counter = 0
        heap: list[tuple[Fraction, bytes, int, tuple[Hashable, ...]]] = []
        for symbol, weight in zip(distribution.domain, distribution.probabilities):
            heapq.heappush(heap, (weight, _strict_bytes(symbol), counter, (symbol,)))
            counter += 1
        lengths = {symbol: 0 for symbol in distribution.domain}
        while len(heap) > 1:
            left = heapq.heappop(heap)
            right = heapq.heappop(heap)
            joined_symbols = left[3] + right[3]
            for symbol in joined_symbols:
                lengths[symbol] += 1
            key = min(left[1], right[1])
            heapq.heappush(heap, (left[0] + right[0], key, counter, joined_symbols))
            counter += 1
        expected = sum(
            (probability * lengths[symbol] for symbol, probability in zip(distribution.domain, distribution.probabilities)),
            Fraction(),
        )
        kraft = sum((Fraction(1, 2**length) for length in lengths.values()), Fraction())
        entropy = distribution.source_entropy
        upper_residual = FormalLogElement.from_positive_rational(2).scale(expected) - entropy
        return cls(
            tuple(sorted(lengths.items(), key=lambda row: _strict_bytes(row[0]))),
            expected,
            kraft,
            entropy,
            upper_residual,
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_EXACT_PREFIX_CODE_V6",
            "code_lengths": [
                {"symbol": _strict_form(symbol), "bits": length}
                for symbol, length in self.lengths
            ],
            "expected_bits": f"{self.expected_bits.numerator}/{self.expected_bits.denominator}",
            "kraft_sum": f"{self.kraft_sum.numerator}/{self.kraft_sum.denominator}",
            "entropy_nats": self.entropy_nats.to_dict(),
            "expected_bits_times_ln2_minus_entropy": self.shannon_upper_residual_nats.to_dict(),
            "prefix_complete": self.kraft_sum == 1,
            "shannon_lower_bound_exact": self.shannon_upper_residual_nats.sign >= 0,
        }
