"""Typed information-custody annotations over exact finite receipt systems."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from fractions import Fraction
from typing import Hashable, Iterable

from .hd import FormalLogElement
from .information import (
    ExactDistribution,
    InformationPartition,
    ReceiptSystem,
    _strict_bytes,
    _strict_form,
)


NO_ERASURE_RECEIPTS_RETAINED = "NO_ERASURE_RECEIPTS_RETAINED"
WOULD_ERASE_IF_COMMITTED = "WOULD_ERASE_IF_COMMITTED"
COMMITTED_LOGICAL_ERASURE = "COMMITTED_LOGICAL_ERASURE"
EVENT_STATUSES = frozenset(
    {
        NO_ERASURE_RECEIPTS_RETAINED,
        WOULD_ERASE_IF_COMMITTED,
        COMMITTED_LOGICAL_ERASURE,
    }
)

ANCHOR_STATUSES = frozenset(
    {"NOT_APPLICABLE", "RETAINED", "DISCARDED", "REQUIRED_MISSING"}
)


def _source_hashes(
    values: Iterable[tuple[str, str]],
) -> tuple[tuple[str, str], ...]:
    rows = tuple(sorted(tuple(values)))
    if not rows or len({role for role, _digest in rows}) != len(rows):
        raise ValueError("source revision hashes must have unique nonempty roles")
    for role, digest in rows:
        if not role or len(digest) != 64 or any(
            character not in "0123456789abcdef" for character in digest
        ):
            raise ValueError("source revision hashes must be lowercase SHA-256 values")
    return rows


def _block_for_item(
    partition: InformationPartition, source_item: Hashable
) -> tuple[Hashable, ...]:
    if source_item not in partition.domain:
        raise ValueError("source item is outside the declared input space")
    for block in partition.blocks:
        if source_item in block:
            return block
    raise AssertionError("partition domain item was not assigned to a block")


def _pointwise_conditional_entropy(
    distribution: ExactDistribution,
    partition: InformationPartition,
    source_item: Hashable,
) -> FormalLogElement:
    distribution._check(partition)
    block = _block_for_item(partition, source_item)
    index_by_item = {item: index for index, item in enumerate(distribution.domain)}
    masses = tuple(distribution.probabilities[index_by_item[item]] for item in block)
    block_mass = sum(masses, Fraction())
    conditional = tuple(mass / block_mass for mass in masses)
    return distribution._entropy(conditional)


def _quantity(value: FormalLogElement | None) -> dict[str, object]:
    if value is None:
        return {"status": "UNASSIGNED", "exact_nats": None}
    return {"status": "ASSIGNED", "exact_nats": value.to_dict()}


@dataclass(frozen=True, slots=True)
class InformationCustodyAnnotation:
    annotation_id: str
    source_operation_id: str
    source_revision_and_hashes: tuple[tuple[str, str], ...]
    input_space: str
    input_domain_size: int
    visible_projection_definition: str
    probability_model_provenance: str | None
    source_item: Hashable
    visible_partition_id: str
    visible_fiber_id: str
    visible_fiber_cardinality: int
    reciprocal_orbit_cardinality: int
    generated_receipt_channels: tuple[str, ...]
    retained_receipt_channels: tuple[str, ...]
    discarded_receipt_channels: tuple[str, ...]
    common_anchor_status: str
    augmented_partition_id: str
    augmented_fiber_cardinality: int
    reconstructible: bool
    support_capacity: FormalLogElement
    remaining_support_capacity: FormalLogElement
    hidden_entropy: FormalLogElement | None
    retained_information: FormalLogElement | None
    pre_event_remaining_information: FormalLogElement | None
    remaining_information: FormalLogElement | None
    logical_erasure_event_status: str
    logical_erasure: FormalLogElement | None
    would_erase_if_committed: FormalLogElement | None
    physical_reset_declared: bool = False
    thermodynamic_calibration_status: str = "UNASSIGNED"

    def __post_init__(self) -> None:
        if self.logical_erasure_event_status not in EVENT_STATUSES:
            raise ValueError("unknown logical erasure event status")
        if self.common_anchor_status not in ANCHOR_STATUSES:
            raise ValueError("unknown common anchor status")
        if self.physical_reset_declared:
            raise ValueError(
                "physical reset belongs to the separate thermodynamic calibration type"
            )
        if self.thermodynamic_calibration_status != "UNASSIGNED":
            raise ValueError("custody annotations cannot assign thermodynamic calibration")

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_INFORMATION_CUSTODY_ANNOTATION_V6",
            "annotation_id": self.annotation_id,
            "source_operation_id": self.source_operation_id,
            "source_revision_and_hashes": [
                {"role": role, "sha256": digest}
                for role, digest in self.source_revision_and_hashes
            ],
            "input_space_and_domain": {
                "definition": self.input_space,
                "cardinality": self.input_domain_size,
                "source_item": _strict_form(self.source_item),
            },
            "visible_projection_definition": self.visible_projection_definition,
            "probability_model_and_provenance_or_NONE": (
                self.probability_model_provenance
            ),
            "visible_partition_id": self.visible_partition_id,
            "visible_fiber_id": self.visible_fiber_id,
            "visible_fiber_cardinality": self.visible_fiber_cardinality,
            "reciprocal_orbit_cardinality": self.reciprocal_orbit_cardinality,
            "generated_receipt_channels": list(self.generated_receipt_channels),
            "retained_receipt_channels": list(self.retained_receipt_channels),
            "discarded_receipt_channels": list(self.discarded_receipt_channels),
            "common_anchor_status": self.common_anchor_status,
            "augmented_partition_id": self.augmented_partition_id,
            "augmented_fiber_cardinality": self.augmented_fiber_cardinality,
            "reconstructible": self.reconstructible,
            "support_capacity_exact_nats": self.support_capacity.to_dict(),
            "remaining_support_capacity_exact_nats": (
                self.remaining_support_capacity.to_dict()
            ),
            "hidden_entropy_exact_nats_or_UNASSIGNED": _quantity(
                self.hidden_entropy
            ),
            "retained_information_exact_nats_or_UNASSIGNED": _quantity(
                self.retained_information
            ),
            "pre_event_remaining_information_exact_nats_or_UNASSIGNED": _quantity(
                self.pre_event_remaining_information
            ),
            "remaining_information_exact_nats_or_UNASSIGNED": _quantity(
                self.remaining_information
            ),
            "logical_erasure_event_status": self.logical_erasure_event_status,
            "logical_erasure_exact_nats": _quantity(self.logical_erasure),
            "would_erase_if_committed_exact_nats": _quantity(
                self.would_erase_if_committed
            ),
            "physical_reset_declared": self.physical_reset_declared,
            "thermodynamic_calibration_status": (
                self.thermodynamic_calibration_status
            ),
        }


def build_custody_annotation(
    *,
    source_operation_id: str,
    source_revision_and_hashes: Iterable[tuple[str, str]],
    input_space: str,
    visible_projection_definition: str,
    receipt_system: ReceiptSystem,
    source_item: Hashable,
    retained_channels: Iterable[str],
    reciprocal_orbit_cardinality: int,
    common_anchor_status: str,
    probability_model: ExactDistribution | None,
    logical_event_status: str = NO_ERASURE_RECEIPTS_RETAINED,
) -> InformationCustodyAnnotation:
    """Construct one exact annotation at an actual visible/augmented fiber."""

    if not source_operation_id or not input_space or not visible_projection_definition:
        raise ValueError("custody annotation definitions cannot be empty")
    if logical_event_status not in EVENT_STATUSES:
        raise ValueError("unknown logical erasure event status")
    if common_anchor_status not in ANCHOR_STATUSES:
        raise ValueError("unknown common anchor status")
    if type(reciprocal_orbit_cardinality) is not int or reciprocal_orbit_cardinality < 1:
        raise ValueError("reciprocal orbit cardinality must be a positive integer")
    source_hashes = _source_hashes(source_revision_and_hashes)
    selected = tuple(sorted(set(retained_channels)))
    generated = receipt_system.channel_names
    if not set(selected) <= set(generated):
        raise KeyError("retained receipt set contains an unknown channel")
    discarded = tuple(name for name in generated if name not in selected)
    augmented = receipt_system.augmented(selected)
    visible_block = _block_for_item(receipt_system.visible, source_item)
    augmented_block = _block_for_item(augmented, source_item)
    visible_capacity = FormalLogElement.from_positive_rational(len(visible_block))
    remaining_capacity = FormalLogElement.from_positive_rational(len(augmented_block))

    hidden: FormalLogElement | None = None
    retained: FormalLogElement | None = None
    pre_event_remaining: FormalLogElement | None = None
    remaining: FormalLogElement | None = None
    actual_erasure: FormalLogElement | None = None
    would_erase: FormalLogElement | None = None
    provenance: str | None = None
    if probability_model is not None:
        probability_model._check(receipt_system.visible)
        hidden = _pointwise_conditional_entropy(
            probability_model, receipt_system.visible, source_item
        )
        remaining = _pointwise_conditional_entropy(
            probability_model, augmented, source_item
        )
        complete_augmented = receipt_system.augmented(generated)
        pre_event_remaining = _pointwise_conditional_entropy(
            probability_model, complete_augmented, source_item
        )
        retained = hidden - remaining
        destroyed_information = remaining - pre_event_remaining
        provenance = probability_model.provenance
        if logical_event_status == COMMITTED_LOGICAL_ERASURE:
            actual_erasure = destroyed_information
        elif logical_event_status == WOULD_ERASE_IF_COMMITTED:
            actual_erasure = FormalLogElement.zero()
            would_erase = destroyed_information
        else:
            actual_erasure = FormalLogElement.zero()

    visible_fiber_id = hashlib.sha256(_strict_bytes(visible_block)).hexdigest()
    identity = {
        "source_operation_id": source_operation_id,
        "source_revision_and_hashes": source_hashes,
        "visible_partition_id": receipt_system.visible.mathematical_id,
        "visible_fiber_id": visible_fiber_id,
        "source_item": source_item,
        "retained_channels": selected,
        "logical_event_status": logical_event_status,
        "probability_provenance": provenance,
    }
    annotation_id = hashlib.sha256(_strict_bytes(identity)).hexdigest()
    return InformationCustodyAnnotation(
        annotation_id=annotation_id,
        source_operation_id=source_operation_id,
        source_revision_and_hashes=source_hashes,
        input_space=input_space,
        input_domain_size=len(receipt_system.visible.domain),
        visible_projection_definition=visible_projection_definition,
        probability_model_provenance=provenance,
        source_item=source_item,
        visible_partition_id=receipt_system.visible.mathematical_id,
        visible_fiber_id=visible_fiber_id,
        visible_fiber_cardinality=len(visible_block),
        reciprocal_orbit_cardinality=reciprocal_orbit_cardinality,
        generated_receipt_channels=generated,
        retained_receipt_channels=selected,
        discarded_receipt_channels=discarded,
        common_anchor_status=common_anchor_status,
        augmented_partition_id=augmented.mathematical_id,
        augmented_fiber_cardinality=len(augmented_block),
        reconstructible=augmented.is_discrete,
        support_capacity=visible_capacity,
        remaining_support_capacity=remaining_capacity,
        hidden_entropy=hidden,
        retained_information=retained,
        pre_event_remaining_information=pre_event_remaining,
        remaining_information=remaining,
        logical_erasure_event_status=logical_event_status,
        logical_erasure=actual_erasure,
        would_erase_if_committed=would_erase,
    )


__all__ = (
    "COMMITTED_LOGICAL_ERASURE",
    "InformationCustodyAnnotation",
    "NO_ERASURE_RECEIPTS_RETAINED",
    "WOULD_ERASE_IF_COMMITTED",
    "build_custody_annotation",
)
