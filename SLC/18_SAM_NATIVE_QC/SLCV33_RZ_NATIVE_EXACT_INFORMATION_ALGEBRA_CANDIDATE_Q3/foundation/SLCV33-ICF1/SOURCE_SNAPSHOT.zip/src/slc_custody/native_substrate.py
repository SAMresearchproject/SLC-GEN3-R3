"""Candidate-owned canonical native exact substrate surface for V6/ICF1.

The classes in this module are immutable successor types.  They do not copy
the installed Complete Exact Write implementation: executable behavior is
delegated through :class:`CompleteExactWriteAdapter` after its frozen artifact
pins have passed.  The sparse D81/D162 service is likewise loaded only after
the installed SLCV21R wrapper and its declared delegate have been hash-bound.

Every public record has a strict canonical ``to_dict``/``from_dict`` boundary.
Binary floating point, ``repr`` identity, unordered sets, and foreign runtime
objects are rejected at that boundary.
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from dataclasses import dataclass
from fractions import Fraction
from pathlib import Path
from types import ModuleType
from typing import Any, Iterable, Mapping, Sequence

from .exact_write import CompleteExactWriteAdapter
from .hd import FormalLogElement
from .information import (
    ExactDistribution,
    InformationPartition,
    ReceiptChannel,
    ReceiptSystem,
)
from .ledger import NO_ERASURE_RECEIPTS_RETAINED, build_custody_annotation
from .operation_graph import ExactWriteTranslationGraph
from .thermodynamics import LogicalResetEvent


SLCV21R_INTERFACE_PATH = Path(
    "SLC/18_SAM_NATIVE_QC/SLCV21R_CURRENT_REVISION_V1/release/"
    "SLCV21R_BLOCK_AND_RECEIPT_INTERFACE.json"
)
SLCV21R_INTERFACE_SHA256 = (
    "3621c73a2acb2f2ab8d80908162fbfc82a53661345ddf73e9be5917ee2bedfbd"
)
AVAILABLE_DEPTHS = tuple(range(1, 28)) + (81, 162)


class NativeSubstrateContractError(ValueError):
    """A candidate-owned canonical substrate contract was violated."""


def _strict_int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise NativeSubstrateContractError(f"{label} must be an integer")
    return value


def _strict_bool(value: Any, label: str) -> bool:
    if not isinstance(value, bool):
        raise NativeSubstrateContractError(f"{label} must be a boolean")
    return value


def _text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise NativeSubstrateContractError(f"{label} must be a nonempty string")
    return value


def _sha256(value: Any, label: str) -> str:
    digest = _text(value, label)
    if len(digest) != 64 or any(c not in "0123456789abcdef" for c in digest):
        raise NativeSubstrateContractError(
            f"{label} must be a lowercase hexadecimal SHA-256"
        )
    return digest


def _fraction(value: Any, label: str) -> Fraction:
    if isinstance(value, bool) or not isinstance(value, (int, Fraction)):
        raise NativeSubstrateContractError(
            f"{label} must be an exact integer or Fraction"
        )
    return value if isinstance(value, Fraction) else Fraction(value)


def _fraction_dict(value: Fraction) -> dict[str, int]:
    return {"denominator": value.denominator, "numerator": value.numerator}


def _fraction_from_dict(value: Any, label: str) -> Fraction:
    if not isinstance(value, Mapping) or set(value) != {"numerator", "denominator"}:
        raise NativeSubstrateContractError(
            f"{label} must contain numerator and denominator"
        )
    numerator = _strict_int(value["numerator"], f"{label}.numerator")
    denominator = _strict_int(value["denominator"], f"{label}.denominator")
    if denominator <= 0:
        raise NativeSubstrateContractError(f"{label}.denominator must be positive")
    result = Fraction(numerator, denominator)
    if result.numerator != numerator or result.denominator != denominator:
        raise NativeSubstrateContractError(f"{label} must be reduced")
    return result


def _tuple_text(value: Any, label: str, *, sorted_unique: bool = False) -> tuple[str, ...]:
    if not isinstance(value, (list, tuple)):
        raise NativeSubstrateContractError(f"{label} must be a list or tuple")
    result = tuple(_text(item, f"{label} item") for item in value)
    if sorted_unique and (tuple(sorted(set(result))) != result):
        raise NativeSubstrateContractError(
            f"{label} must be sorted and duplicate-free"
        )
    return result


def _normalize_payload(value: Any, label: str = "payload") -> Any:
    """Return a JSON value with exact rationals tagged and order canonicalized."""

    if isinstance(value, Fraction):
        return {"$exact_fraction": _fraction_dict(value)}
    if value is None or isinstance(value, (str, bool)):
        return value
    if isinstance(value, int) and not isinstance(value, bool):
        return value
    if isinstance(value, float):
        raise NativeSubstrateContractError(f"{label} cannot contain binary floats")
    if isinstance(value, Mapping):
        if set(value) == {"$exact_fraction"}:
            return {
                "$exact_fraction": _fraction_dict(
                    _fraction_from_dict(value["$exact_fraction"], label)
                )
            }
        if any(not isinstance(key, str) or not key for key in value):
            raise NativeSubstrateContractError(
                f"{label} mapping keys must be nonempty strings"
            )
        return {
            key: _normalize_payload(value[key], f"{label}.{key}")
            for key in sorted(value)
        }
    if isinstance(value, (list, tuple)):
        return [
            _normalize_payload(item, f"{label}[{index}]")
            for index, item in enumerate(value)
        ]
    raise NativeSubstrateContractError(
        f"{label} contains unsupported noncanonical type {type(value).__name__}"
    )


def _canonical_json(value: Any, label: str = "payload") -> str:
    return json.dumps(
        _normalize_payload(value, label),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
        allow_nan=False,
    )


def _canonical_json_value(value: str, label: str) -> Any:
    if not isinstance(value, str):
        raise NativeSubstrateContractError(f"{label} must be canonical JSON text")
    try:
        parsed = json.loads(value)
    except json.JSONDecodeError as exc:
        raise NativeSubstrateContractError(f"{label} is not JSON") from exc
    canonical = _canonical_json(parsed, label)
    if canonical != value:
        raise NativeSubstrateContractError(f"{label} is not canonical JSON")
    return parsed


def _record(value: Any, schema: str, fields: set[str], label: str) -> Mapping[str, Any]:
    if not isinstance(value, Mapping) or set(value) != fields | {"schema"}:
        raise NativeSubstrateContractError(
            f"{label} must contain exactly schema and its canonical fields"
        )
    if value["schema"] != schema:
        raise NativeSubstrateContractError(f"{label} has an unknown schema")
    return value


def _semantic_sha256(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(_canonical_json(value).encode("ascii")).hexdigest()


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


@dataclass(frozen=True, slots=True)
class NativeSourceSeal:
    """One immutable implementation or interface provenance seal."""

    role: str
    revision: str
    repository_relative_path: str
    sha256: str

    SCHEMA = "SLC_NATIVE_SOURCE_SEAL_V6"

    def __post_init__(self) -> None:
        _text(self.role, "source seal role")
        _text(self.revision, "source seal revision")
        path = Path(_text(self.repository_relative_path, "source seal path"))
        if path.is_absolute() or ".." in path.parts:
            raise NativeSubstrateContractError(
                "source seal path must be repository-relative and contained"
            )
        _sha256(self.sha256, "source seal sha256")

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "role": self.role,
            "revision": self.revision,
            "repository_relative_path": self.repository_relative_path,
            "sha256": self.sha256,
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "NativeSourceSeal":
        row = _record(
            value,
            cls.SCHEMA,
            {"role", "revision", "repository_relative_path", "sha256"},
            "source seal",
        )
        return cls(
            role=_text(row["role"], "role"),
            revision=_text(row["revision"], "revision"),
            repository_relative_path=_text(
                row["repository_relative_path"], "repository_relative_path"
            ),
            sha256=_sha256(row["sha256"], "sha256"),
        )


@dataclass(frozen=True, slots=True)
class ExactWriteOperation:
    """One executed, source-sealed canonical operation fixture."""

    operation_id: str
    domain_space: str
    codomain_space: str
    exact_law: str
    reconstruction_contract: str
    inverse_status: str
    fixture_input_canonical_json: str
    fixture_output_canonical_json: str
    law_holds: bool
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_EXACT_WRITE_OPERATION_V6"
    INVERSE_STATUSES = frozenset(
        {
            "EXACT_INVERSE_VERIFIED",
            "EXACT_RECONSTRUCTION_VERIFIED",
            "PROJECTION_RECONSTRUCTION_VERIFIED",
            "TYPED_NONINVERTIBILITY_VERIFIED",
        }
    )

    def __post_init__(self) -> None:
        operation_id = _text(self.operation_id, "operation_id")
        if not operation_id.isupper():
            raise NativeSubstrateContractError("operation_id must be uppercase")
        _text(self.domain_space, "operation domain")
        _text(self.codomain_space, "operation codomain")
        _text(self.exact_law, "exact law")
        _text(self.reconstruction_contract, "reconstruction contract")
        if self.inverse_status not in self.INVERSE_STATUSES:
            raise NativeSubstrateContractError("unknown operation inverse status")
        _canonical_json_value(
            self.fixture_input_canonical_json, "fixture input canonical JSON"
        )
        _canonical_json_value(
            self.fixture_output_canonical_json, "fixture output canonical JSON"
        )
        _strict_bool(self.law_holds, "law_holds")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("operation requires NativeSourceSeal")
        if not self.law_holds:
            raise NativeSubstrateContractError(
                "canonical operation fixtures admit only verified exact executions"
            )

    @classmethod
    def create(
        cls,
        *,
        operation_id: str,
        domain_space: str,
        codomain_space: str,
        exact_law: str,
        reconstruction_contract: str,
        inverse_status: str,
        fixture_input: Any,
        fixture_output: Any,
        law_holds: bool,
        source_seal: NativeSourceSeal,
    ) -> "ExactWriteOperation":
        return cls(
            operation_id=operation_id,
            domain_space=domain_space,
            codomain_space=codomain_space,
            exact_law=exact_law,
            reconstruction_contract=reconstruction_contract,
            inverse_status=inverse_status,
            fixture_input_canonical_json=_canonical_json(
                fixture_input, "fixture_input"
            ),
            fixture_output_canonical_json=_canonical_json(
                fixture_output, "fixture_output"
            ),
            law_holds=law_holds,
            source_seal=source_seal,
        )

    @property
    def fixture_input(self) -> Any:
        return json.loads(self.fixture_input_canonical_json)

    @property
    def fixture_output(self) -> Any:
        return json.loads(self.fixture_output_canonical_json)

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "operation_id": self.operation_id,
            "domain_space": self.domain_space,
            "codomain_space": self.codomain_space,
            "exact_law": self.exact_law,
            "reconstruction_contract": self.reconstruction_contract,
            "inverse_status": self.inverse_status,
            "fixture_input": self.fixture_input,
            "fixture_output": self.fixture_output,
            "law_holds": self.law_holds,
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ExactWriteOperation":
        fields = {
            "operation_id", "domain_space", "codomain_space", "exact_law",
            "reconstruction_contract", "inverse_status", "fixture_input",
            "fixture_output", "law_holds", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "ExactWriteOperation")
        return cls.create(
            operation_id=_text(row["operation_id"], "operation_id"),
            domain_space=_text(row["domain_space"], "domain_space"),
            codomain_space=_text(row["codomain_space"], "codomain_space"),
            exact_law=_text(row["exact_law"], "exact_law"),
            reconstruction_contract=_text(
                row["reconstruction_contract"], "reconstruction_contract"
            ),
            inverse_status=_text(row["inverse_status"], "inverse_status"),
            fixture_input=row["fixture_input"],
            fixture_output=row["fixture_output"],
            law_holds=_strict_bool(row["law_holds"], "law_holds"),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )


@dataclass(frozen=True, slots=True)
class VisibleFiber:
    """One actual visible collision with an optional injective receipt label."""

    domain_space: str
    codomain_space: str
    visible_value_canonical_json: str
    source_points_canonical_json: tuple[str, ...]
    receipt_labels: tuple[str, ...]
    inverse_status: str
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_VISIBLE_FIBER_V6"

    def __post_init__(self) -> None:
        _text(self.domain_space, "fiber domain")
        _text(self.codomain_space, "fiber codomain")
        _canonical_json_value(self.visible_value_canonical_json, "visible value")
        if not isinstance(self.source_points_canonical_json, tuple) or not self.source_points_canonical_json:
            raise NativeSubstrateContractError("visible fiber requires source points")
        for point in self.source_points_canonical_json:
            _canonical_json_value(point, "source point")
        if len(set(self.source_points_canonical_json)) != len(self.source_points_canonical_json):
            raise NativeSubstrateContractError("visible fiber source points must be distinct")
        if not isinstance(self.receipt_labels, tuple):
            raise NativeSubstrateContractError("receipt labels must be a tuple")
        if self.receipt_labels:
            if len(self.receipt_labels) != len(self.source_points_canonical_json):
                raise NativeSubstrateContractError("receipt labels must label every source point")
            _tuple_text(self.receipt_labels, "receipt labels")
            if len(set(self.receipt_labels)) != len(self.receipt_labels):
                raise NativeSubstrateContractError("receipt labels must be injective")
            expected = "EXACT_RECEIPT_INVERSE"
        else:
            expected = "TYPED_VISIBLE_NONINVERTIBILITY"
        if self.inverse_status != expected:
            raise NativeSubstrateContractError("visible fiber inverse status is inconsistent")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("visible fiber requires source seal")

    @classmethod
    def create(
        cls,
        *,
        domain_space: str,
        codomain_space: str,
        visible_value: Any,
        source_points: Sequence[Any],
        receipt_labels: Sequence[str] = (),
        source_seal: NativeSourceSeal,
    ) -> "VisibleFiber":
        labels = tuple(receipt_labels)
        return cls(
            domain_space=domain_space,
            codomain_space=codomain_space,
            visible_value_canonical_json=_canonical_json(visible_value, "visible_value"),
            source_points_canonical_json=tuple(
                _canonical_json(point, "source_point") for point in source_points
            ),
            receipt_labels=labels,
            inverse_status=(
                "EXACT_RECEIPT_INVERSE"
                if labels
                else "TYPED_VISIBLE_NONINVERTIBILITY"
            ),
            source_seal=source_seal,
        )

    @property
    def cardinality(self) -> int:
        return len(self.source_points_canonical_json)

    @property
    def visible_value(self) -> Any:
        return json.loads(self.visible_value_canonical_json)

    @property
    def source_points(self) -> tuple[Any, ...]:
        return tuple(json.loads(value) for value in self.source_points_canonical_json)

    def reconstruct(self, receipt_label: str) -> Any:
        if not self.receipt_labels:
            raise NativeSubstrateContractError(
                "visible projection is typed noninvertible without a receipt"
            )
        try:
            index = self.receipt_labels.index(receipt_label)
        except ValueError as exc:
            raise KeyError(receipt_label) from exc
        return self.source_points[index]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": self.domain_space,
            "codomain_space": self.codomain_space,
            "visible_value": self.visible_value,
            "source_points": list(self.source_points),
            "receipt_labels": list(self.receipt_labels),
            "fiber_cardinality": self.cardinality,
            "inverse_status": self.inverse_status,
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "VisibleFiber":
        fields = {
            "domain_space", "codomain_space", "visible_value", "source_points",
            "receipt_labels", "fiber_cardinality", "inverse_status", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "VisibleFiber")
        result = cls.create(
            domain_space=_text(row["domain_space"], "domain_space"),
            codomain_space=_text(row["codomain_space"], "codomain_space"),
            visible_value=row["visible_value"],
            source_points=row["source_points"],
            receipt_labels=_tuple_text(row["receipt_labels"], "receipt_labels"),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )
        if _strict_int(row["fiber_cardinality"], "fiber_cardinality") != result.cardinality:
            raise NativeSubstrateContractError("fiber cardinality does not match points")
        if row["inverse_status"] != result.inverse_status:
            raise NativeSubstrateContractError("fiber inverse status changed")
        return result


@dataclass(frozen=True, slots=True)
class ReceiptGraph:
    """Canonical signed-write graph plus its retained sequential receipt."""

    graph_id: str
    receipt_id: str
    domain_space: str
    codomain_space: str
    sequential_program: tuple[tuple[int, int], ...]
    compiled_translation: int
    inverse_translation: int
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_RECEIPT_GRAPH_V6"

    def __post_init__(self) -> None:
        _sha256(self.graph_id, "graph_id")
        _sha256(self.receipt_id, "receipt_id")
        _text(self.domain_space, "receipt graph domain")
        _text(self.codomain_space, "receipt graph codomain")
        if not isinstance(self.sequential_program, tuple) or not self.sequential_program:
            raise NativeSubstrateContractError("receipt graph requires a nonempty program")
        for index, event in enumerate(self.sequential_program):
            if not isinstance(event, tuple) or len(event) != 2:
                raise NativeSubstrateContractError(
                    f"receipt graph event {index} must be an (axis,delta) tuple"
                )
            axis = _strict_int(event[0], f"event {index} axis")
            delta = _strict_int(event[1], f"event {index} delta")
            if not 0 <= axis < 9 or delta not in (-1, 1):
                raise NativeSubstrateContractError("receipt graph event is outside signed Z4^9")
        for value, label in (
            (self.compiled_translation, "compiled_translation"),
            (self.inverse_translation, "inverse_translation"),
        ):
            exact = _strict_int(value, label)
            if not 0 <= exact < (1 << 18):
                raise NativeSubstrateContractError(f"{label} is outside packed Z4^9")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("receipt graph requires source seal")

    def execute(self, adapter: CompleteExactWriteAdapter, address: int) -> int:
        if not isinstance(adapter, CompleteExactWriteAdapter):
            raise TypeError("receipt graph execution requires CompleteExactWriteAdapter")
        return adapter.apply_translation(
            _strict_int(address, "address"), self.compiled_translation
        )

    def reconstruct(self, adapter: CompleteExactWriteAdapter, final_address: int) -> int:
        if not isinstance(adapter, CompleteExactWriteAdapter):
            raise TypeError("receipt graph reconstruction requires CompleteExactWriteAdapter")
        return adapter.apply_translation(
            _strict_int(final_address, "final_address"), self.inverse_translation
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "graph_id": self.graph_id,
            "receipt_id": self.receipt_id,
            "domain_space": self.domain_space,
            "codomain_space": self.codomain_space,
            "sequential_program": [
                {"axis": axis, "delta": delta}
                for axis, delta in self.sequential_program
            ],
            "compiled_translation": self.compiled_translation,
            "inverse_translation": self.inverse_translation,
            "inverse_status": "EXACT_INVERSE_VERIFIED",
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ReceiptGraph":
        fields = {
            "graph_id", "receipt_id", "domain_space", "codomain_space",
            "sequential_program", "compiled_translation", "inverse_translation",
            "inverse_status", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "ReceiptGraph")
        raw_program = row["sequential_program"]
        if not isinstance(raw_program, list):
            raise NativeSubstrateContractError("sequential_program must be a list")
        program: list[tuple[int, int]] = []
        for index, event in enumerate(raw_program):
            if not isinstance(event, Mapping) or set(event) != {"axis", "delta"}:
                raise NativeSubstrateContractError(
                    f"sequential_program[{index}] has noncanonical fields"
                )
            program.append(
                (
                    _strict_int(event["axis"], f"event {index} axis"),
                    _strict_int(event["delta"], f"event {index} delta"),
                )
            )
        if row["inverse_status"] != "EXACT_INVERSE_VERIFIED":
            raise NativeSubstrateContractError("receipt graph inverse status changed")
        return cls(
            graph_id=_sha256(row["graph_id"], "graph_id"),
            receipt_id=_sha256(row["receipt_id"], "receipt_id"),
            domain_space=_text(row["domain_space"], "domain_space"),
            codomain_space=_text(row["codomain_space"], "codomain_space"),
            sequential_program=tuple(program),
            compiled_translation=_strict_int(
                row["compiled_translation"], "compiled_translation"
            ),
            inverse_translation=_strict_int(
                row["inverse_translation"], "inverse_translation"
            ),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )


@dataclass(frozen=True, slots=True)
class W8State:
    """Canonical W8 shell state with exact binary reconstruction."""

    shell_state: int
    bits: tuple[int, ...]
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_W8_STATE_V6"

    def __post_init__(self) -> None:
        shell = _strict_int(self.shell_state, "W8 shell state")
        if not 0 <= shell < 256:
            raise NativeSubstrateContractError("W8 shell state must lie in [0,256)")
        if not isinstance(self.bits, tuple) or len(self.bits) != 8:
            raise NativeSubstrateContractError("W8 bits must be an eight-coordinate tuple")
        if any(_strict_int(bit, "W8 bit") not in (0, 1) for bit in self.bits):
            raise NativeSubstrateContractError("W8 coordinates must be binary")
        if self.reconstruct_shell() != shell:
            raise NativeSubstrateContractError("W8 bits do not reconstruct shell state")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("W8 state requires source seal")

    def reconstruct_shell(self) -> int:
        return sum(bit << index for index, bit in enumerate(self.bits))

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": "W8ShellInteger[0,256)",
            "codomain_space": "{0,1}^8",
            "shell_state": self.shell_state,
            "bits": list(self.bits),
            "reconstructed_shell_state": self.reconstruct_shell(),
            "inverse_status": "EXACT_INVERSE_VERIFIED",
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "W8State":
        fields = {
            "domain_space", "codomain_space", "shell_state", "bits",
            "reconstructed_shell_state", "inverse_status", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "W8State")
        if row["domain_space"] != "W8ShellInteger[0,256)" or row["codomain_space"] != "{0,1}^8":
            raise NativeSubstrateContractError("W8 type spaces changed")
        if row["inverse_status"] != "EXACT_INVERSE_VERIFIED":
            raise NativeSubstrateContractError("W8 inverse status changed")
        bits_raw = row["bits"]
        if not isinstance(bits_raw, list):
            raise NativeSubstrateContractError("W8 bits must serialize as a list")
        result = cls(
            shell_state=_strict_int(row["shell_state"], "shell_state"),
            bits=tuple(_strict_int(bit, "W8 bit") for bit in bits_raw),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )
        if _strict_int(row["reconstructed_shell_state"], "reconstructed_shell_state") != result.reconstruct_shell():
            raise NativeSubstrateContractError("serialized W8 reconstruction changed")
        return result


@dataclass(frozen=True, slots=True)
class W9P:
    """Canonical projected W9 receipt retaining the exact W8 preimage."""

    shell_state: int
    axis: int
    orientation: int
    ledger_receipt: int
    address_before: int
    address_after: int
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_W9P_V6"

    def __post_init__(self) -> None:
        if not 0 <= _strict_int(self.shell_state, "W9P shell_state") < 256:
            raise NativeSubstrateContractError("W9P shell state is outside W8")
        if not 0 <= _strict_int(self.axis, "W9P axis") < 9:
            raise NativeSubstrateContractError("W9P axis is outside Theta18")
        if _strict_int(self.orientation, "W9P orientation") not in (-1, 1):
            raise NativeSubstrateContractError("W9P orientation must be signed")
        _strict_int(self.ledger_receipt, "W9P ledger_receipt")
        for address, label in (
            (self.address_before, "W9P address_before"),
            (self.address_after, "W9P address_after"),
        ):
            if not 0 <= _strict_int(address, label) < (1 << 18):
                raise NativeSubstrateContractError(f"{label} is outside Theta18")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("W9P requires source seal")

    def project_w8(self) -> int:
        return self.shell_state

    def reconstruct_record(self) -> tuple[int, int, int, int, int, int]:
        return (
            self.shell_state,
            self.axis,
            self.orientation,
            self.ledger_receipt,
            self.address_before,
            self.address_after,
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": "W9Receipt",
            "codomain_space": "W8ShellState",
            "shell_state": self.shell_state,
            "axis": self.axis,
            "orientation": self.orientation,
            "ledger_receipt": self.ledger_receipt,
            "address_before": self.address_before,
            "address_after": self.address_after,
            "projected_w8": self.project_w8(),
            "reconstruction_status": "EXACT_RECORD_RECONSTRUCTION",
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "W9P":
        fields = {
            "domain_space", "codomain_space", "shell_state", "axis",
            "orientation", "ledger_receipt", "address_before", "address_after",
            "projected_w8", "reconstruction_status", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "W9P")
        if row["domain_space"] != "W9Receipt" or row["codomain_space"] != "W8ShellState":
            raise NativeSubstrateContractError("W9P spaces changed")
        if row["reconstruction_status"] != "EXACT_RECORD_RECONSTRUCTION":
            raise NativeSubstrateContractError("W9P reconstruction status changed")
        result = cls(
            shell_state=_strict_int(row["shell_state"], "shell_state"),
            axis=_strict_int(row["axis"], "axis"),
            orientation=_strict_int(row["orientation"], "orientation"),
            ledger_receipt=_strict_int(row["ledger_receipt"], "ledger_receipt"),
            address_before=_strict_int(row["address_before"], "address_before"),
            address_after=_strict_int(row["address_after"], "address_after"),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )
        if _strict_int(row["projected_w8"], "projected_w8") != result.project_w8():
            raise NativeSubstrateContractError("W9P projection changed")
        return result


@dataclass(frozen=True, slots=True)
class W9History:
    """An ordered immutable receipt history, distinct from its visible state."""

    records: tuple[W9P, ...]
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_W9_HISTORY_V6"

    def __post_init__(self) -> None:
        if not isinstance(self.records, tuple) or not self.records:
            raise NativeSubstrateContractError("W9 history requires records")
        if any(not isinstance(record, W9P) for record in self.records):
            raise NativeSubstrateContractError("W9 history records must be W9P")
        if any(record.source_seal != self.source_seal for record in self.records):
            raise NativeSubstrateContractError("W9 history records must share one source seal")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("W9 history requires source seal")

    @property
    def history_id(self) -> str:
        body = {
            "schema": self.SCHEMA,
            "records": [record.to_dict() for record in self.records],
        }
        return _semantic_sha256(body)

    def reconstruct_shell_history(self) -> tuple[int, ...]:
        return tuple(record.project_w8() for record in self.records)

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": "OrderedW9Receipts",
            "codomain_space": "OrderedW8ShellHistory",
            "history_id": self.history_id,
            "records": [record.to_dict() for record in self.records],
            "reconstructed_shell_history": list(self.reconstruct_shell_history()),
            "reconstruction_status": "EXACT_ORDERED_HISTORY_RECONSTRUCTION",
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "W9History":
        fields = {
            "domain_space", "codomain_space", "history_id", "records",
            "reconstructed_shell_history", "reconstruction_status", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "W9History")
        if row["domain_space"] != "OrderedW9Receipts" or row["codomain_space"] != "OrderedW8ShellHistory":
            raise NativeSubstrateContractError("W9 history spaces changed")
        if row["reconstruction_status"] != "EXACT_ORDERED_HISTORY_RECONSTRUCTION":
            raise NativeSubstrateContractError("W9 history reconstruction status changed")
        raw_records = row["records"]
        if not isinstance(raw_records, list):
            raise NativeSubstrateContractError("W9 records must serialize as a list")
        result = cls(
            records=tuple(W9P.from_dict(item) for item in raw_records),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )
        if row["history_id"] != result.history_id:
            raise NativeSubstrateContractError("W9 history identity changed")
        raw_shells = row["reconstructed_shell_history"]
        if not isinstance(raw_shells, list) or tuple(raw_shells) != result.reconstruct_shell_history():
            raise NativeSubstrateContractError("W9 reconstructed shell history changed")
        return result


@dataclass(frozen=True, slots=True)
class AFCTransportReference:
    """One exact common-reference transport with its packed inverse."""

    reference_id: str
    domain_space: str
    codomain_space: str
    address_before: int
    address_after: int
    translation: int
    inverse_translation: int
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_AFC_TRANSPORT_REFERENCE_V6"

    def __post_init__(self) -> None:
        _sha256(self.reference_id, "AFC reference_id")
        _text(self.domain_space, "AFC domain")
        _text(self.codomain_space, "AFC codomain")
        for value, label in (
            (self.address_before, "address_before"),
            (self.address_after, "address_after"),
            (self.translation, "translation"),
            (self.inverse_translation, "inverse_translation"),
        ):
            if not 0 <= _strict_int(value, label) < (1 << 18):
                raise NativeSubstrateContractError(f"AFC {label} is outside packed Z4^9")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("AFC transport requires source seal")

    def transport(self, adapter: CompleteExactWriteAdapter) -> int:
        if not isinstance(adapter, CompleteExactWriteAdapter):
            raise TypeError("AFC transport requires CompleteExactWriteAdapter")
        observed = adapter.apply_translation(self.address_before, self.translation)
        if observed != self.address_after:
            raise NativeSubstrateContractError("AFC stored transport no longer closes")
        return observed

    def reconstruct_before(self, adapter: CompleteExactWriteAdapter) -> int:
        if not isinstance(adapter, CompleteExactWriteAdapter):
            raise TypeError("AFC reconstruction requires CompleteExactWriteAdapter")
        observed = adapter.apply_translation(self.address_after, self.inverse_translation)
        if observed != self.address_before:
            raise NativeSubstrateContractError("AFC inverse no longer reconstructs")
        return observed

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "reference_id": self.reference_id,
            "domain_space": self.domain_space,
            "codomain_space": self.codomain_space,
            "address_before": self.address_before,
            "address_after": self.address_after,
            "translation": self.translation,
            "inverse_translation": self.inverse_translation,
            "inverse_status": "EXACT_INVERSE_VERIFIED",
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "AFCTransportReference":
        fields = {
            "reference_id", "domain_space", "codomain_space", "address_before",
            "address_after", "translation", "inverse_translation", "inverse_status",
            "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "AFCTransportReference")
        if row["inverse_status"] != "EXACT_INVERSE_VERIFIED":
            raise NativeSubstrateContractError("AFC inverse status changed")
        return cls(
            reference_id=_sha256(row["reference_id"], "reference_id"),
            domain_space=_text(row["domain_space"], "domain_space"),
            codomain_space=_text(row["codomain_space"], "codomain_space"),
            address_before=_strict_int(row["address_before"], "address_before"),
            address_after=_strict_int(row["address_after"], "address_after"),
            translation=_strict_int(row["translation"], "translation"),
            inverse_translation=_strict_int(
                row["inverse_translation"], "inverse_translation"
            ),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )


@dataclass(frozen=True, slots=True)
class Theta18Report:
    """Exact nine-coordinate Z4 report for one packed Theta18 address."""

    address: int
    coordinates: tuple[int, ...]
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_THETA18_REPORT_V6"

    def __post_init__(self) -> None:
        if not 0 <= _strict_int(self.address, "Theta18 address") < (1 << 18):
            raise NativeSubstrateContractError("Theta18 address is outside [0,2^18)")
        if not isinstance(self.coordinates, tuple) or len(self.coordinates) != 9:
            raise NativeSubstrateContractError("Theta18 requires nine Z4 coordinates")
        if any(not 0 <= _strict_int(q, "Theta18 coordinate") < 4 for q in self.coordinates):
            raise NativeSubstrateContractError("Theta18 coordinates must lie in Z4")
        if self.reconstruct_address() != self.address:
            raise NativeSubstrateContractError("Theta18 coordinates do not reconstruct address")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("Theta18 report requires source seal")

    def reconstruct_address(self) -> int:
        address = 0
        for axis, q in enumerate(self.coordinates):
            address |= (q & 1) << axis
            address |= ((q >> 1) & 1) << (axis + 9)
        return address

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": "PackedTheta18Address[0,2^18)",
            "codomain_space": "Z4^9",
            "address": self.address,
            "coordinates": list(self.coordinates),
            "reconstructed_address": self.reconstruct_address(),
            "inverse_status": "EXACT_INVERSE_VERIFIED",
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "Theta18Report":
        fields = {
            "domain_space", "codomain_space", "address", "coordinates",
            "reconstructed_address", "inverse_status", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "Theta18Report")
        if row["domain_space"] != "PackedTheta18Address[0,2^18)" or row["codomain_space"] != "Z4^9":
            raise NativeSubstrateContractError("Theta18 spaces changed")
        if row["inverse_status"] != "EXACT_INVERSE_VERIFIED":
            raise NativeSubstrateContractError("Theta18 inverse status changed")
        raw = row["coordinates"]
        if not isinstance(raw, list):
            raise NativeSubstrateContractError("Theta18 coordinates must serialize as list")
        result = cls(
            address=_strict_int(row["address"], "address"),
            coordinates=tuple(_strict_int(q, "coordinate") for q in raw),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )
        if _strict_int(row["reconstructed_address"], "reconstructed_address") != result.address:
            raise NativeSubstrateContractError("Theta18 reconstruction changed")
        return result


@dataclass(frozen=True, slots=True)
class SupportObject:
    """An exact sparse support vector in a declared finite ambient space."""

    ambient_space: str
    dimension: int
    support_indices: tuple[int, ...]
    coefficients: tuple[Fraction, ...]
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_SUPPORT_OBJECT_V6"

    def __post_init__(self) -> None:
        _text(self.ambient_space, "support ambient_space")
        dimension = _strict_int(self.dimension, "support dimension")
        if dimension < 1:
            raise NativeSubstrateContractError("support dimension must be positive")
        if not isinstance(self.support_indices, tuple) or not self.support_indices:
            raise NativeSubstrateContractError("support indices require a nonempty tuple")
        indices = tuple(_strict_int(index, "support index") for index in self.support_indices)
        if tuple(sorted(set(indices))) != indices or any(not 0 <= index < dimension for index in indices):
            raise NativeSubstrateContractError("support indices must be sorted unique in range")
        if not isinstance(self.coefficients, tuple) or len(self.coefficients) != len(indices):
            raise NativeSubstrateContractError("support coefficients must align with indices")
        if any(not isinstance(value, Fraction) or value == 0 for value in self.coefficients):
            raise NativeSubstrateContractError("support coefficients must be nonzero Fractions")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("support object requires source seal")

    def reconstruct_vector(self) -> tuple[Fraction, ...]:
        vector = [Fraction()] * self.dimension
        for index, coefficient in zip(self.support_indices, self.coefficients, strict=True):
            vector[index] = coefficient
        return tuple(vector)

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": "SparseExactCoordinates",
            "codomain_space": self.ambient_space,
            "ambient_space": self.ambient_space,
            "dimension": self.dimension,
            "support_indices": list(self.support_indices),
            "coefficients": [_fraction_dict(value) for value in self.coefficients],
            "reconstruction_status": "EXACT_SPARSE_RECONSTRUCTION",
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "SupportObject":
        fields = {
            "domain_space", "codomain_space", "ambient_space", "dimension",
            "support_indices", "coefficients", "reconstruction_status", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "SupportObject")
        if row["domain_space"] != "SparseExactCoordinates" or row["codomain_space"] != row["ambient_space"]:
            raise NativeSubstrateContractError("support type spaces changed")
        if row["reconstruction_status"] != "EXACT_SPARSE_RECONSTRUCTION":
            raise NativeSubstrateContractError("support reconstruction status changed")
        indices = row["support_indices"]
        coefficients = row["coefficients"]
        if not isinstance(indices, list) or not isinstance(coefficients, list):
            raise NativeSubstrateContractError("support arrays must serialize as lists")
        return cls(
            ambient_space=_text(row["ambient_space"], "ambient_space"),
            dimension=_strict_int(row["dimension"], "dimension"),
            support_indices=tuple(_strict_int(index, "support index") for index in indices),
            coefficients=tuple(
                _fraction_from_dict(item, "support coefficient") for item in coefficients
            ),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )


@dataclass(frozen=True, slots=True)
class GramObject:
    """Exact Gram matrix together with its declared generating vectors."""

    ambient_space: str
    vectors: tuple[tuple[Fraction, ...], ...]
    gram_matrix: tuple[tuple[Fraction, ...], ...]
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_GRAM_OBJECT_V6"

    def __post_init__(self) -> None:
        _text(self.ambient_space, "Gram ambient_space")
        if not isinstance(self.vectors, tuple) or not self.vectors:
            raise NativeSubstrateContractError("Gram object requires vectors")
        dimension = len(self.vectors[0])
        if dimension < 1:
            raise NativeSubstrateContractError("Gram vectors cannot be empty")
        for vector in self.vectors:
            if not isinstance(vector, tuple) or len(vector) != dimension:
                raise NativeSubstrateContractError("Gram vectors must share a dimension")
            if any(not isinstance(value, Fraction) for value in vector):
                raise NativeSubstrateContractError("Gram vector entries must be Fractions")
        expected = self._compute(self.vectors)
        if self.gram_matrix != expected:
            raise NativeSubstrateContractError("Gram matrix does not equal exact vector products")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("Gram object requires source seal")

    @staticmethod
    def _compute(vectors: tuple[tuple[Fraction, ...], ...]) -> tuple[tuple[Fraction, ...], ...]:
        return tuple(
            tuple(sum((a * b for a, b in zip(left, right, strict=True)), Fraction()) for right in vectors)
            for left in vectors
        )

    @classmethod
    def from_vectors(
        cls,
        ambient_space: str,
        vectors: Sequence[Sequence[int | Fraction]],
        source_seal: NativeSourceSeal,
    ) -> "GramObject":
        frozen = tuple(
            tuple(_fraction(value, "Gram vector entry") for value in vector)
            for vector in vectors
        )
        return cls(ambient_space, frozen, cls._compute(frozen), source_seal)

    @property
    def is_symmetric(self) -> bool:
        return all(
            self.gram_matrix[i][j] == self.gram_matrix[j][i]
            for i in range(len(self.gram_matrix))
            for j in range(len(self.gram_matrix))
        )

    def to_dict(self) -> dict[str, object]:
        encode = lambda matrix: [
            [_fraction_dict(value) for value in row] for row in matrix
        ]
        return {
            "schema": self.SCHEMA,
            "domain_space": f"{self.ambient_space}^{len(self.vectors)}",
            "codomain_space": f"Sym_{len(self.vectors)}(Q)",
            "ambient_space": self.ambient_space,
            "vectors": encode(self.vectors),
            "gram_matrix": encode(self.gram_matrix),
            "symmetric": self.is_symmetric,
            "reconstruction_status": "EXACT_VECTOR_GRAM_RECOMPUTATION",
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "GramObject":
        fields = {
            "domain_space", "codomain_space", "ambient_space", "vectors",
            "gram_matrix", "symmetric", "reconstruction_status", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "GramObject")
        ambient = _text(row["ambient_space"], "ambient_space")
        raw_vectors = row["vectors"]
        raw_gram = row["gram_matrix"]
        if not isinstance(raw_vectors, list) or not isinstance(raw_gram, list):
            raise NativeSubstrateContractError("Gram arrays must serialize as lists")
        decode = lambda matrix: tuple(
            tuple(_fraction_from_dict(entry, "Gram entry") for entry in vector)
            for vector in matrix
        )
        result = cls(
            ambient_space=ambient,
            vectors=decode(raw_vectors),
            gram_matrix=decode(raw_gram),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )
        if row["domain_space"] != f"{ambient}^{len(result.vectors)}" or row["codomain_space"] != f"Sym_{len(result.vectors)}(Q)":
            raise NativeSubstrateContractError("Gram type spaces changed")
        if _strict_bool(row["symmetric"], "symmetric") != result.is_symmetric:
            raise NativeSubstrateContractError("Gram symmetry receipt changed")
        if row["reconstruction_status"] != "EXACT_VECTOR_GRAM_RECOMPUTATION":
            raise NativeSubstrateContractError("Gram reconstruction status changed")
        return result


@dataclass(frozen=True, slots=True)
class TensorOrbitObject:
    """Exact finite orbit of a tensor coordinate under cyclic permutation."""

    tensor_space: str
    seed: tuple[int, ...]
    orbit: tuple[tuple[int, ...], ...]
    action_id: str
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_TENSOR_ORBIT_OBJECT_V6"

    def __post_init__(self) -> None:
        _text(self.tensor_space, "tensor_space")
        _text(self.action_id, "action_id")
        if self.action_id != "CYCLIC_COORDINATE_ROTATION":
            raise NativeSubstrateContractError("unknown tensor orbit action")
        if not isinstance(self.seed, tuple) or not self.seed:
            raise NativeSubstrateContractError("tensor orbit requires a seed")
        if any(isinstance(value, bool) or not isinstance(value, int) for value in self.seed):
            raise NativeSubstrateContractError("tensor seed entries must be integers")
        expected = self._cyclic_orbit(self.seed)
        if self.orbit != expected:
            raise NativeSubstrateContractError("tensor orbit is not the canonical cyclic orbit")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("tensor orbit requires source seal")

    @staticmethod
    def _cyclic_orbit(seed: tuple[int, ...]) -> tuple[tuple[int, ...], ...]:
        candidates = tuple(seed[index:] + seed[:index] for index in range(len(seed)))
        return tuple(dict.fromkeys(candidates))

    @classmethod
    def from_seed(
        cls,
        tensor_space: str,
        seed: Sequence[int],
        source_seal: NativeSourceSeal,
    ) -> "TensorOrbitObject":
        frozen = tuple(_strict_int(value, "tensor seed entry") for value in seed)
        return cls(
            tensor_space=tensor_space,
            seed=frozen,
            orbit=cls._cyclic_orbit(frozen),
            action_id="CYCLIC_COORDINATE_ROTATION",
            source_seal=source_seal,
        )

    def inverse_action(self, orbit_index: int, point: Sequence[int]) -> tuple[int, ...]:
        index = _strict_int(orbit_index, "orbit_index")
        frozen = tuple(_strict_int(value, "orbit point entry") for value in point)
        if not 0 <= index < len(self.seed) or frozen != self.seed[index:] + self.seed[:index]:
            raise NativeSubstrateContractError("point is not the declared indexed orbit action")
        if index == 0:
            return frozen
        return frozen[-index:] + frozen[:-index]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": self.tensor_space,
            "codomain_space": f"Orbit({self.tensor_space})",
            "tensor_space": self.tensor_space,
            "seed": list(self.seed),
            "orbit": [list(point) for point in self.orbit],
            "orbit_cardinality": len(self.orbit),
            "action_id": self.action_id,
            "inverse_status": "EXACT_GROUP_ACTION_INVERSE",
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "TensorOrbitObject":
        fields = {
            "domain_space", "codomain_space", "tensor_space", "seed", "orbit",
            "orbit_cardinality", "action_id", "inverse_status", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "TensorOrbitObject")
        tensor_space = _text(row["tensor_space"], "tensor_space")
        if row["domain_space"] != tensor_space or row["codomain_space"] != f"Orbit({tensor_space})":
            raise NativeSubstrateContractError("tensor orbit type spaces changed")
        if row["inverse_status"] != "EXACT_GROUP_ACTION_INVERSE":
            raise NativeSubstrateContractError("tensor orbit inverse status changed")
        raw_seed = row["seed"]
        raw_orbit = row["orbit"]
        if not isinstance(raw_seed, list) or not isinstance(raw_orbit, list):
            raise NativeSubstrateContractError("tensor arrays must serialize as lists")
        result = cls(
            tensor_space=tensor_space,
            seed=tuple(_strict_int(value, "seed entry") for value in raw_seed),
            orbit=tuple(
                tuple(_strict_int(value, "orbit entry") for value in point)
                for point in raw_orbit
            ),
            action_id=_text(row["action_id"], "action_id"),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )
        if _strict_int(row["orbit_cardinality"], "orbit_cardinality") != len(result.orbit):
            raise NativeSubstrateContractError("tensor orbit cardinality changed")
        return result


@dataclass(frozen=True, slots=True)
class ExactDepthBlock:
    """One executed authenticated D1--D27/D81/D162 block receipt surface."""

    depth: int
    composition: tuple[int, ...]
    prior_state: tuple[int, int, int, int]
    following_state: tuple[int, int, int, int]
    history_reconstructs: bool
    receipt_semantic_sha256: str
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_EXACT_DEPTH_BLOCK_V6"

    def __post_init__(self) -> None:
        depth = _strict_int(self.depth, "depth")
        if depth not in AVAILABLE_DEPTHS:
            raise NativeSubstrateContractError("depth is not installed by the delegated interface")
        if not isinstance(self.composition, tuple) or not self.composition:
            raise NativeSubstrateContractError("depth composition requires components")
        if any(_strict_int(item, "depth component") not in range(1, 28) and item != 81 for item in self.composition):
            raise NativeSubstrateContractError("depth composition has an unavailable component")
        if sum(self.composition) != depth:
            raise NativeSubstrateContractError("depth composition does not sum to depth")
        for state, label in (
            (self.prior_state, "prior_state"),
            (self.following_state, "following_state"),
        ):
            if not isinstance(state, tuple) or len(state) != 4:
                raise NativeSubstrateContractError(f"{label} must be a four-integer tuple")
            for value in state:
                _strict_int(value, f"{label} entry")
        if self.prior_state[0] != self.following_state[0]:
            raise NativeSubstrateContractError("depth block cannot change modulus")
        if self.following_state[3] - self.prior_state[3] != depth:
            raise NativeSubstrateContractError("depth block step increment does not equal depth")
        if not _strict_bool(self.history_reconstructs, "history_reconstructs"):
            raise NativeSubstrateContractError("canonical depth block requires exact history reconstruction")
        _sha256(self.receipt_semantic_sha256, "depth receipt semantic sha256")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("depth block requires source seal")

    def reconstruct_prior(self) -> tuple[int, int, int, int]:
        if not self.history_reconstructs:
            raise NativeSubstrateContractError("depth history is not reconstructing")
        return self.prior_state

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": "DyadicState(modulus,common,directional,step)",
            "codomain_space": "DyadicState(modulus,common,directional,step+depth)",
            "depth": self.depth,
            "composition": list(self.composition),
            "prior_state": list(self.prior_state),
            "following_state": list(self.following_state),
            "history_reconstructs": self.history_reconstructs,
            "receipt_semantic_sha256": self.receipt_semantic_sha256,
            "inverse_status": "EXACT_HISTORY_RECONSTRUCTION_VERIFIED",
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ExactDepthBlock":
        fields = {
            "domain_space", "codomain_space", "depth", "composition", "prior_state",
            "following_state", "history_reconstructs", "receipt_semantic_sha256",
            "inverse_status", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "ExactDepthBlock")
        if row["domain_space"] != "DyadicState(modulus,common,directional,step)" or row["codomain_space"] != "DyadicState(modulus,common,directional,step+depth)":
            raise NativeSubstrateContractError("depth block type spaces changed")
        if row["inverse_status"] != "EXACT_HISTORY_RECONSTRUCTION_VERIFIED":
            raise NativeSubstrateContractError("depth block inverse status changed")
        composition = row["composition"]
        prior = row["prior_state"]
        following = row["following_state"]
        if not isinstance(composition, list) or not isinstance(prior, list) or not isinstance(following, list):
            raise NativeSubstrateContractError("depth block arrays must serialize as lists")
        return cls(
            depth=_strict_int(row["depth"], "depth"),
            composition=tuple(_strict_int(item, "composition item") for item in composition),
            prior_state=tuple(_strict_int(item, "prior state entry") for item in prior),  # type: ignore[arg-type]
            following_state=tuple(_strict_int(item, "following state entry") for item in following),  # type: ignore[arg-type]
            history_reconstructs=_strict_bool(row["history_reconstructs"], "history_reconstructs"),
            receipt_semantic_sha256=_sha256(
                row["receipt_semantic_sha256"], "receipt_semantic_sha256"
            ),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )


@dataclass(frozen=True, slots=True)
class ExactComposition:
    """Canonical composition in the packed Z4^9 translation group."""

    domain_space: str
    codomain_space: str
    left_translation: int
    right_translation: int
    composed_translation: int
    inverse_translation: int
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_EXACT_COMPOSITION_V6"

    def __post_init__(self) -> None:
        _text(self.domain_space, "composition domain")
        _text(self.codomain_space, "composition codomain")
        for value, label in (
            (self.left_translation, "left_translation"),
            (self.right_translation, "right_translation"),
            (self.composed_translation, "composed_translation"),
            (self.inverse_translation, "inverse_translation"),
        ):
            if not 0 <= _strict_int(value, label) < (1 << 18):
                raise NativeSubstrateContractError(f"{label} is outside packed Z4^9")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("composition requires source seal")

    def execute(self, adapter: CompleteExactWriteAdapter, address: int) -> int:
        if not isinstance(adapter, CompleteExactWriteAdapter):
            raise TypeError("composition execution requires CompleteExactWriteAdapter")
        return adapter.apply_translation(_strict_int(address, "address"), self.composed_translation)

    def reconstruct(self, adapter: CompleteExactWriteAdapter, output: int) -> int:
        if not isinstance(adapter, CompleteExactWriteAdapter):
            raise TypeError("composition reconstruction requires CompleteExactWriteAdapter")
        return adapter.apply_translation(_strict_int(output, "output"), self.inverse_translation)

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": self.domain_space,
            "codomain_space": self.codomain_space,
            "left_translation": self.left_translation,
            "right_translation": self.right_translation,
            "composed_translation": self.composed_translation,
            "inverse_translation": self.inverse_translation,
            "inverse_status": "EXACT_INVERSE_VERIFIED",
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "ExactComposition":
        fields = {
            "domain_space", "codomain_space", "left_translation", "right_translation",
            "composed_translation", "inverse_translation", "inverse_status", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "ExactComposition")
        if row["inverse_status"] != "EXACT_INVERSE_VERIFIED":
            raise NativeSubstrateContractError("composition inverse status changed")
        return cls(
            domain_space=_text(row["domain_space"], "domain_space"),
            codomain_space=_text(row["codomain_space"], "codomain_space"),
            left_translation=_strict_int(row["left_translation"], "left_translation"),
            right_translation=_strict_int(row["right_translation"], "right_translation"),
            composed_translation=_strict_int(row["composed_translation"], "composed_translation"),
            inverse_translation=_strict_int(row["inverse_translation"], "inverse_translation"),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )


def _is_prime(value: int) -> bool:
    if value < 2:
        return False
    divisor = 2
    while divisor * divisor <= value:
        if value % divisor == 0:
            return value == divisor
        divisor += 1
    return True


@dataclass(frozen=True, slots=True)
class PrimeValuationVector:
    """Canonical signed rational represented by its complete prime valuations."""

    sign: int
    valuations: tuple[tuple[int, int], ...]
    source_provenance: str

    SCHEMA = "SLC_PRIME_VALUATION_VECTOR_V6"

    def __post_init__(self) -> None:
        if _strict_int(self.sign, "valuation sign") not in (-1, 1):
            raise NativeSubstrateContractError("valuation sign must be -1 or +1")
        if not isinstance(self.valuations, tuple):
            raise NativeSubstrateContractError("valuations must be a tuple")
        prior = 1
        for prime, exponent in self.valuations:
            prime = _strict_int(prime, "valuation prime")
            exponent = _strict_int(exponent, "valuation exponent")
            if not _is_prime(prime) or prime <= prior or exponent == 0:
                raise NativeSubstrateContractError(
                    "valuation primes must be increasing primes with nonzero exponents"
                )
            prior = prime
        _text(self.source_provenance, "valuation source provenance")

    @classmethod
    def from_rational(
        cls, value: int | Fraction, *, source_provenance: str
    ) -> "PrimeValuationVector":
        exact = _fraction(value, "valuation rational")
        if exact == 0:
            raise NativeSubstrateContractError("zero has no finite prime valuation vector")
        sign = 1 if exact > 0 else -1
        formal = FormalLogElement.from_positive_rational(abs(exact))
        valuations: list[tuple[int, int]] = []
        for prime, coefficient in formal.coefficients:
            if coefficient.denominator != 1:
                raise AssertionError("rational factorization produced nonintegral valuation")
            valuations.append((prime, coefficient.numerator))
        return cls(sign, tuple(valuations), source_provenance)

    @property
    def rational_value(self) -> Fraction:
        value = Fraction(self.sign)
        for prime, exponent in self.valuations:
            if exponent > 0:
                value *= prime**exponent
            else:
                value /= prime ** (-exponent)
        return value

    def compose(self, other: "PrimeValuationVector", *, provenance: str) -> "PrimeValuationVector":
        if not isinstance(other, PrimeValuationVector):
            raise TypeError("valuation composition requires PrimeValuationVector")
        return PrimeValuationVector.from_rational(
            self.rational_value * other.rational_value,
            source_provenance=provenance,
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": "Q_nonzero_multiplicative",
            "codomain_space": "{+1,-1} x direct_sum_p Z",
            "sign": self.sign,
            "valuations": [
                {"prime": prime, "exponent": exponent}
                for prime, exponent in self.valuations
            ],
            "rational_value": _fraction_dict(self.rational_value),
            "source_provenance": self.source_provenance,
            "inverse_status": "EXACT_FACTORIZATION_RECONSTRUCTION",
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PrimeValuationVector":
        fields = {
            "domain_space", "codomain_space", "sign", "valuations",
            "rational_value", "source_provenance", "inverse_status",
        }
        row = _record(value, cls.SCHEMA, fields, "PrimeValuationVector")
        if row["domain_space"] != "Q_nonzero_multiplicative" or row["codomain_space"] != "{+1,-1} x direct_sum_p Z":
            raise NativeSubstrateContractError("valuation type spaces changed")
        if row["inverse_status"] != "EXACT_FACTORIZATION_RECONSTRUCTION":
            raise NativeSubstrateContractError("valuation inverse status changed")
        raw = row["valuations"]
        if not isinstance(raw, list):
            raise NativeSubstrateContractError("valuations must serialize as a list")
        entries: list[tuple[int, int]] = []
        for item in raw:
            if not isinstance(item, Mapping) or set(item) != {"prime", "exponent"}:
                raise NativeSubstrateContractError("valuation row has noncanonical fields")
            entries.append(
                (
                    _strict_int(item["prime"], "valuation prime"),
                    _strict_int(item["exponent"], "valuation exponent"),
                )
            )
        result = cls(
            sign=_strict_int(row["sign"], "sign"),
            valuations=tuple(entries),
            source_provenance=_text(row["source_provenance"], "source_provenance"),
        )
        if _fraction_from_dict(row["rational_value"], "rational_value") != result.rational_value:
            raise NativeSubstrateContractError("valuation rational reconstruction changed")
        return result


@dataclass(frozen=True, slots=True)
class FormalLogMonoidElement:
    """Additive formal-log image of an exact positive rational multiplier."""

    value: FormalLogElement
    source_provenance: str

    SCHEMA = "SLC_FORMAL_LOG_MONOID_ELEMENT_V6"

    def __post_init__(self) -> None:
        if not isinstance(self.value, FormalLogElement):
            raise NativeSubstrateContractError("formal-log monoid value has wrong type")
        _text(self.source_provenance, "formal-log source provenance")

    @classmethod
    def from_positive_rational(
        cls, value: int | Fraction, *, source_provenance: str
    ) -> "FormalLogMonoidElement":
        return cls(
            FormalLogElement.from_positive_rational(
                _fraction(value, "formal-log positive rational")
            ),
            source_provenance,
        )

    def compose(
        self, other: "FormalLogMonoidElement", *, provenance: str
    ) -> "FormalLogMonoidElement":
        if not isinstance(other, FormalLogMonoidElement):
            raise TypeError("formal-log composition requires FormalLogMonoidElement")
        return FormalLogMonoidElement(self.value + other.value, provenance)

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": "Q_positive_multiplicative",
            "codomain_space": "direct_sum_p Q[ln(p)]_additive",
            "formal_log": self.value.to_dict(),
            "source_provenance": self.source_provenance,
            "composition_law": "L(x*y)=L(x)+L(y)",
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "FormalLogMonoidElement":
        fields = {
            "domain_space", "codomain_space", "formal_log", "source_provenance",
            "composition_law",
        }
        row = _record(value, cls.SCHEMA, fields, "FormalLogMonoidElement")
        if row["domain_space"] != "Q_positive_multiplicative" or row["codomain_space"] != "direct_sum_p Q[ln(p)]_additive":
            raise NativeSubstrateContractError("formal-log monoid spaces changed")
        if row["composition_law"] != "L(x*y)=L(x)+L(y)":
            raise NativeSubstrateContractError("formal-log composition law changed")
        return cls(
            value=FormalLogElement.from_dict(row["formal_log"]),
            source_provenance=_text(row["source_provenance"], "source_provenance"),
        )


@dataclass(frozen=True, slots=True)
class CustodyAnnotation:
    """Canonical successor view of exact visible/receipt information custody."""

    annotation_id: str
    source_operation_id: str
    input_space: str
    visible_fiber_cardinality: int
    generated_receipt_channels: tuple[str, ...]
    retained_receipt_channels: tuple[str, ...]
    reconstructible: bool
    hidden_information: FormalLogMonoidElement
    retained_information: FormalLogMonoidElement
    logical_erasure: FormalLogMonoidElement
    logical_erasure_status: str
    probability_model_provenance: str
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_CANONICAL_CUSTODY_ANNOTATION_V6"

    def __post_init__(self) -> None:
        _sha256(self.annotation_id, "custody annotation_id")
        _text(self.source_operation_id, "custody source_operation_id")
        _text(self.input_space, "custody input_space")
        if _strict_int(self.visible_fiber_cardinality, "visible_fiber_cardinality") < 1:
            raise NativeSubstrateContractError("visible fiber cardinality must be positive")
        generated = _tuple_text(
            self.generated_receipt_channels,
            "generated receipt channels",
            sorted_unique=True,
        )
        retained = _tuple_text(
            self.retained_receipt_channels,
            "retained receipt channels",
            sorted_unique=True,
        )
        if not set(retained) <= set(generated):
            raise NativeSubstrateContractError("retained channels must be generated")
        _strict_bool(self.reconstructible, "custody reconstructible")
        for value, label in (
            (self.hidden_information, "hidden_information"),
            (self.retained_information, "retained_information"),
            (self.logical_erasure, "logical_erasure"),
        ):
            if not isinstance(value, FormalLogMonoidElement):
                raise NativeSubstrateContractError(f"{label} has wrong type")
            if value.value.sign < 0:
                raise NativeSubstrateContractError(f"{label} cannot be negative")
        if self.hidden_information.value != self.retained_information.value + self.logical_erasure.value:
            raise NativeSubstrateContractError(
                "custody ledger must close hidden=retained+erased"
            )
        if self.logical_erasure_status != NO_ERASURE_RECEIPTS_RETAINED:
            raise NativeSubstrateContractError(
                "this canonical fixture surface admits retained-receipt custody only"
            )
        if not self.reconstructible or not self.logical_erasure.value.is_zero:
            raise NativeSubstrateContractError(
                "retained-receipt custody must reconstruct with zero erasure"
            )
        _text(self.probability_model_provenance, "probability model provenance")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("custody annotation requires source seal")

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": self.input_space,
            "codomain_space": "VisibleState x RetainedReceipt",
            "annotation_id": self.annotation_id,
            "source_operation_id": self.source_operation_id,
            "input_space": self.input_space,
            "visible_fiber_cardinality": self.visible_fiber_cardinality,
            "generated_receipt_channels": list(self.generated_receipt_channels),
            "retained_receipt_channels": list(self.retained_receipt_channels),
            "reconstructible": self.reconstructible,
            "hidden_information": self.hidden_information.to_dict(),
            "retained_information": self.retained_information.to_dict(),
            "logical_erasure": self.logical_erasure.to_dict(),
            "ledger_identity": "hidden_information=retained_information+logical_erasure",
            "logical_erasure_status": self.logical_erasure_status,
            "probability_model_provenance": self.probability_model_provenance,
            "inverse_status": "EXACT_RECEIPT_INVERSE",
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "CustodyAnnotation":
        fields = {
            "domain_space", "codomain_space", "annotation_id", "source_operation_id",
            "input_space", "visible_fiber_cardinality", "generated_receipt_channels",
            "retained_receipt_channels", "reconstructible", "hidden_information",
            "retained_information", "logical_erasure", "ledger_identity",
            "logical_erasure_status", "probability_model_provenance", "inverse_status",
            "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "CustodyAnnotation")
        if row["domain_space"] != row["input_space"] or row["codomain_space"] != "VisibleState x RetainedReceipt":
            raise NativeSubstrateContractError("custody type spaces changed")
        if row["ledger_identity"] != "hidden_information=retained_information+logical_erasure":
            raise NativeSubstrateContractError("custody ledger identity changed")
        if row["inverse_status"] != "EXACT_RECEIPT_INVERSE":
            raise NativeSubstrateContractError("custody inverse status changed")
        return cls(
            annotation_id=_sha256(row["annotation_id"], "annotation_id"),
            source_operation_id=_text(row["source_operation_id"], "source_operation_id"),
            input_space=_text(row["input_space"], "input_space"),
            visible_fiber_cardinality=_strict_int(
                row["visible_fiber_cardinality"], "visible_fiber_cardinality"
            ),
            generated_receipt_channels=_tuple_text(
                row["generated_receipt_channels"],
                "generated_receipt_channels",
                sorted_unique=True,
            ),
            retained_receipt_channels=_tuple_text(
                row["retained_receipt_channels"],
                "retained_receipt_channels",
                sorted_unique=True,
            ),
            reconstructible=_strict_bool(row["reconstructible"], "reconstructible"),
            hidden_information=FormalLogMonoidElement.from_dict(row["hidden_information"]),
            retained_information=FormalLogMonoidElement.from_dict(row["retained_information"]),
            logical_erasure=FormalLogMonoidElement.from_dict(row["logical_erasure"]),
            logical_erasure_status=_text(
                row["logical_erasure_status"], "logical_erasure_status"
            ),
            probability_model_provenance=_text(
                row["probability_model_provenance"], "probability_model_provenance"
            ),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )


@dataclass(frozen=True, slots=True)
class LogicalErasureEvent:
    """Logical event boundary; physical heat and temperature are not assigned."""

    event_id: str
    event_kind: str
    destroyed_channels: tuple[str, ...]
    retained_channels: tuple[str, ...]
    reconstructs_source_before: bool
    reconstructs_source_after: bool
    erased_information: FormalLogMonoidElement
    source_law_provenance: str
    source_seal: NativeSourceSeal

    SCHEMA = "SLC_CANONICAL_LOGICAL_ERASURE_EVENT_V6"

    def __post_init__(self) -> None:
        _text(self.event_id, "logical event_id")
        if self.event_kind not in {
            "REVERSIBLE_RECEIPT_RETENTION",
            "IRREVERSIBLE_CHANNEL_DESTRUCTION",
        }:
            raise NativeSubstrateContractError("unknown logical event kind")
        destroyed = _tuple_text(
            self.destroyed_channels, "destroyed channels", sorted_unique=True
        )
        retained = _tuple_text(
            self.retained_channels, "retained channels", sorted_unique=True
        )
        if set(destroyed) & set(retained):
            raise NativeSubstrateContractError("destroyed and retained channels overlap")
        _strict_bool(self.reconstructs_source_before, "reconstructs_source_before")
        _strict_bool(self.reconstructs_source_after, "reconstructs_source_after")
        if not isinstance(self.erased_information, FormalLogMonoidElement):
            raise NativeSubstrateContractError("erased information has wrong type")
        if self.erased_information.value.sign < 0:
            raise NativeSubstrateContractError("erased information cannot be negative")
        _text(self.source_law_provenance, "logical source law provenance")
        if not isinstance(self.source_seal, NativeSourceSeal):
            raise NativeSubstrateContractError("logical event requires source seal")
        if self.event_kind == "REVERSIBLE_RECEIPT_RETENTION":
            if destroyed or not retained or not self.reconstructs_source_after or not self.erased_information.value.is_zero:
                raise NativeSubstrateContractError("reversible receipt event is inconsistent")
        else:
            if not destroyed or self.reconstructs_source_after:
                raise NativeSubstrateContractError("irreversible event requires destroyed custody")

    @classmethod
    def from_reset_event(
        cls, event: LogicalResetEvent, source_seal: NativeSourceSeal
    ) -> "LogicalErasureEvent":
        if not isinstance(event, LogicalResetEvent):
            raise TypeError("logical canonicalization requires LogicalResetEvent")
        return cls(
            event_id=event.event_id,
            event_kind=event.event_kind,
            destroyed_channels=event.destroyed_channels,
            retained_channels=event.retained_channels,
            reconstructs_source_before=event.reconstructs_source_before_event,
            reconstructs_source_after=event.reconstructs_source_after_event,
            erased_information=FormalLogMonoidElement(
                event.erased_information, event.source_law_provenance
            ),
            source_law_provenance=event.source_law_provenance,
            source_seal=source_seal,
        )

    @property
    def inverse_status(self) -> str:
        return (
            "EXACT_RECEIPT_INVERSE"
            if self.reconstructs_source_after
            else "TYPED_NONINVERTIBILITY_EVENT"
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "domain_space": "Source x VisibleState x ReceiptStateBeforeEvent",
            "codomain_space": "VisibleState x ReceiptStateAfterEvent",
            "event_id": self.event_id,
            "event_kind": self.event_kind,
            "destroyed_channels": list(self.destroyed_channels),
            "retained_channels": list(self.retained_channels),
            "reconstructs_source_before": self.reconstructs_source_before,
            "reconstructs_source_after": self.reconstructs_source_after,
            "erased_information": self.erased_information.to_dict(),
            "source_law_provenance": self.source_law_provenance,
            "inverse_status": self.inverse_status,
            "physical_temperature": None,
            "realized_heat_claim": None,
            "source_seal": self.source_seal.to_dict(),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "LogicalErasureEvent":
        fields = {
            "domain_space", "codomain_space", "event_id", "event_kind",
            "destroyed_channels", "retained_channels", "reconstructs_source_before",
            "reconstructs_source_after", "erased_information", "source_law_provenance",
            "inverse_status", "physical_temperature", "realized_heat_claim", "source_seal",
        }
        row = _record(value, cls.SCHEMA, fields, "LogicalErasureEvent")
        if row["domain_space"] != "Source x VisibleState x ReceiptStateBeforeEvent" or row["codomain_space"] != "VisibleState x ReceiptStateAfterEvent":
            raise NativeSubstrateContractError("logical event type spaces changed")
        if row["physical_temperature"] is not None or row["realized_heat_claim"] is not None:
            raise NativeSubstrateContractError("logical event cannot assign physical heat")
        result = cls(
            event_id=_text(row["event_id"], "event_id"),
            event_kind=_text(row["event_kind"], "event_kind"),
            destroyed_channels=_tuple_text(
                row["destroyed_channels"], "destroyed_channels", sorted_unique=True
            ),
            retained_channels=_tuple_text(
                row["retained_channels"], "retained_channels", sorted_unique=True
            ),
            reconstructs_source_before=_strict_bool(
                row["reconstructs_source_before"], "reconstructs_source_before"
            ),
            reconstructs_source_after=_strict_bool(
                row["reconstructs_source_after"], "reconstructs_source_after"
            ),
            erased_information=FormalLogMonoidElement.from_dict(row["erased_information"]),
            source_law_provenance=_text(
                row["source_law_provenance"], "source_law_provenance"
            ),
            source_seal=NativeSourceSeal.from_dict(row["source_seal"]),
        )
        if row["inverse_status"] != result.inverse_status:
            raise NativeSubstrateContractError("logical event inverse status changed")
        return result


_DEPTH_MODULE_NAME = "_slc_custody_frozen_slcv20r_d162_02c746c614cf7ff6"
_DEPTH_NODE_CACHE: dict[Path, Any] = {}


def _contained_file(repository_root: Path, relative_path: str) -> Path:
    relative = Path(relative_path)
    if relative.is_absolute() or ".." in relative.parts:
        raise NativeSubstrateContractError("delegated artifact path is not contained")
    root = repository_root.resolve()
    path = (root / relative).resolve(strict=True)
    if not path.is_relative_to(root) or not path.is_file():
        raise NativeSubstrateContractError("delegated artifact is not a repository file")
    return path


def _load_hash_bound_depth_node(
    adapter: CompleteExactWriteAdapter,
) -> tuple[Any, NativeSourceSeal, NativeSourceSeal]:
    root = adapter.dependency_receipt.repository_root
    cached = _DEPTH_NODE_CACHE.get(root)
    wrapper_path = _contained_file(root, SLCV21R_INTERFACE_PATH.as_posix())
    if _file_sha256(wrapper_path) != SLCV21R_INTERFACE_SHA256:
        raise NativeSubstrateContractError("SLCV21R depth wrapper hash changed")
    try:
        wrapper = json.loads(wrapper_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise NativeSubstrateContractError("SLCV21R depth wrapper is invalid JSON") from exc
    if not isinstance(wrapper, dict):
        raise NativeSubstrateContractError("SLCV21R depth wrapper must be an object")
    if tuple(wrapper.get("available_depths", ())) != AVAILABLE_DEPTHS:
        raise NativeSubstrateContractError("SLCV21R depth roster changed")
    if wrapper.get("targeted_anchors") != {"D81": [27, 27, 27], "D162": [81, 81]}:
        raise NativeSubstrateContractError("SLCV21R targeted depth composition changed")
    delegation = wrapper.get("delegation")
    if not isinstance(delegation, dict) or not isinstance(delegation.get("implementation"), dict):
        raise NativeSubstrateContractError("SLCV21R implementation delegation is missing")
    implementation = delegation["implementation"]
    relative_path = _text(implementation.get("path"), "delegated implementation path")
    expected_sha256 = _sha256(
        implementation.get("sha256"), "delegated implementation sha256"
    )
    implementation_path = _contained_file(root, relative_path)
    if _file_sha256(implementation_path) != expected_sha256:
        raise NativeSubstrateContractError("delegated D162 implementation hash changed")
    interface_seal = NativeSourceSeal(
        role="SLCV21R_BLOCK_RECEIPT_INTERFACE",
        revision="SLCV21R",
        repository_relative_path=SLCV21R_INTERFACE_PATH.as_posix(),
        sha256=SLCV21R_INTERFACE_SHA256,
    )
    implementation_seal = NativeSourceSeal(
        role="DELEGATED_D1_D27_D81_D162_IMPLEMENTATION",
        revision=_text(delegation.get("parent_revision"), "delegated parent revision"),
        repository_relative_path=relative_path,
        sha256=expected_sha256,
    )
    if cached is not None:
        return cached, interface_seal, implementation_seal

    existing = sys.modules.get(_DEPTH_MODULE_NAME)
    if existing is None:
        spec = importlib.util.spec_from_file_location(
            _DEPTH_MODULE_NAME, implementation_path
        )
        if spec is None or spec.loader is None:
            raise NativeSubstrateContractError("cannot load delegated depth API")
        module = importlib.util.module_from_spec(spec)
        sys.modules[_DEPTH_MODULE_NAME] = module
        previous_policy = sys.dont_write_bytecode
        sys.dont_write_bytecode = True
        try:
            spec.loader.exec_module(module)
        except Exception:
            sys.modules.pop(_DEPTH_MODULE_NAME, None)
            raise
        finally:
            sys.dont_write_bytecode = previous_policy
    else:
        module = existing
        if Path(str(getattr(module, "__file__", ""))).resolve(strict=False) != implementation_path:
            raise NativeSubstrateContractError("cached depth module resolves to wrong path")
    if _file_sha256(implementation_path) != expected_sha256:
        raise NativeSubstrateContractError("delegated implementation changed during load")
    node_type = getattr(module, "SLCV20RD162FullReceiptNode", None)
    if node_type is None:
        raise NativeSubstrateContractError("delegated depth API type is missing")
    node = node_type()
    if tuple(node.available_depths) != AVAILABLE_DEPTHS:
        raise NativeSubstrateContractError("delegated runtime depth roster changed")
    _DEPTH_NODE_CACHE[root] = node
    return node, interface_seal, implementation_seal


def _state_tuple(state: Any) -> tuple[int, int, int, int]:
    try:
        values = (state.modulus, state.common, state.directional, state.step)
    except AttributeError as exc:
        raise NativeSubstrateContractError("delegated state has unknown fields") from exc
    return tuple(_strict_int(value, "dyadic state entry") for value in values)  # type: ignore[return-value]


def _w9p_from_runtime(record: Any, source_seal: NativeSourceSeal) -> W9P:
    try:
        return W9P(
            shell_state=_strict_int(record.shell_state, "W9 shell_state"),
            axis=_strict_int(record.axis, "W9 axis"),
            orientation=_strict_int(record.orientation, "W9 orientation"),
            ledger_receipt=_strict_int(record.ledger_receipt, "W9 ledger_receipt"),
            address_before=_strict_int(record.address_before, "W9 address_before"),
            address_after=_strict_int(record.address_after, "W9 address_after"),
            source_seal=source_seal,
        )
    except AttributeError as exc:
        raise NativeSubstrateContractError("runtime W9 record surface changed") from exc


class NativeExactSubstratePlane:
    """Immutable canonical facade over frozen Exact Write and depth services."""

    __slots__ = (
        "adapter",
        "exact_write_source_seal",
        "depth_interface_seal",
        "depth_implementation_seal",
        "_depth_node",
    )

    SCHEMA = "SLC_NATIVE_EXACT_SUBSTRATE_PLANE_V6"

    def __init__(self, adapter: CompleteExactWriteAdapter) -> None:
        if not isinstance(adapter, CompleteExactWriteAdapter):
            raise TypeError("native substrate plane requires CompleteExactWriteAdapter")
        artifact = adapter.dependency_receipt.artifact("COMPLETE_EXACT_WRITE_SOURCE")
        self.adapter = adapter
        self.exact_write_source_seal = NativeSourceSeal(
            role=artifact.role,
            revision=adapter.dependency_receipt.current_revision_name,
            repository_relative_path=artifact.relative_path,
            sha256=artifact.sha256,
        )
        node, interface_seal, implementation_seal = _load_hash_bound_depth_node(adapter)
        self._depth_node = node
        self.depth_interface_seal = interface_seal
        self.depth_implementation_seal = implementation_seal

    @property
    def source_seals(self) -> tuple[NativeSourceSeal, ...]:
        return (
            self.exact_write_source_seal,
            self.depth_interface_seal,
            self.depth_implementation_seal,
        )

    def exact_write_operations(self) -> tuple[ExactWriteOperation, ...]:
        """Execute one exact typed fixture for every installed operation descriptor."""

        adapter = self.adapter
        seal = self.exact_write_source_seal

        shell = 173
        bits = adapter.w8_bits(shell)
        welded = adapter.hamiltonian_weld((1, 2, 3), (3, -1, 2), 1)
        source = adapter.w8_site(4)
        target = adapter.w8_site(11)
        active = adapter.activate_write(source, target, 2, 1, 19, 257)
        completed = adapter.complete_write(active)
        projected = adapter.project_w8(completed.retained_record)
        address = 74_321
        axis = 4
        delta = 1
        q_before = adapter.q_coordinate(address, axis)
        event_after = adapter.event_map(address, axis, delta)
        event_inverse = adapter.event_map(event_after, axis, -delta)
        reversed_after = adapter.reverse_address(event_after, 3)
        covariance_after = adapter.event_map(adapter.reverse_address(address, 3), axis, -delta)
        program_left = ((0, 1), (4, -1), (7, 1))
        program_right = ((2, 1), (0, -1))
        translation_left = adapter.compile_translation(program_left)
        translation_right = adapter.compile_translation(program_right)
        composed = adapter.compose_translations(translation_left, translation_right)
        program_output = adapter.apply_translation(address, composed)
        program_reconstructed = adapter.apply_translation(
            program_output, adapter.inverse_translation(composed)
        )

        left_history = tuple(Fraction(index, 3) for index in range(81))
        right_history = tuple(Fraction(2 * index + 1, 5) for index in range(81))
        quotient, anchor = adapter.history_quotient(left_history, right_history)
        reconstructed_history = quotient.reconstruct(anchor)
        shift = Fraction(7, 2)
        shifted_quotient, shifted_anchor = adapter.history_quotient(
            tuple(value + shift for value in left_history),
            tuple(value + shift for value in right_history),
        )

        projection = adapter.completed_projection((3, 4, 5), (1, 1, 0))
        analytic_left = (adapter.qcomplex(1, 2), adapter.qcomplex(3, -1))
        analytic_right = (adapter.qcomplex(-2, 1), adapter.qcomplex(4, 5))
        analytic = adapter.analytic_write(analytic_left, analytic_right)
        ledger_receipts, ledger_final, ledger_composed = adapter.ledger_program(
            (5, 7, 11), 1, 17
        )
        noninvertible = adapter.ledger_write(5, 6, 12)
        mu_left = adapter.mu4_character(1)
        mu_right = adapter.mu4_character(3)
        mu_product = adapter.mu4_multiply(mu_left, mu_right)
        mu_readback = adapter.mu4_readback(1, 0)

        fixture: dict[str, tuple[Any, Any, bool, str]] = {
            "W8_COMPLETE_SHELL": (
                {"shell_state": shell},
                {"bits": bits, "reconstructed_shell": sum(bit << i for i, bit in enumerate(bits))},
                sum(bit << i for i, bit in enumerate(bits)) == shell,
                "EXACT_INVERSE_VERIFIED",
            ),
            "HAMILTONIAN_WELD": (
                {"h_w8": (1, 2, 3), "delta_h_x1": (3, -1, 2), "activation": 1},
                {"welded": welded},
                welded == (Fraction(4), Fraction(1), Fraction(5)),
                "EXACT_RECONSTRUCTION_VERIFIED",
            ),
            "W9_RECORD_PROJECTION": (
                {"record": _w9p_from_runtime(completed.retained_record, seal).to_dict()},
                {"projected_w8": projected},
                projected == 11,
                "PROJECTION_RECONSTRUCTION_VERIFIED",
            ),
            "TWO_SITE_U_X1_LIFECYCLE": (
                {"source_shell": 4, "target_shell": 11, "axis": 2, "orientation": 1},
                {
                    "source_phase": completed.source_phase,
                    "target_phase": completed.target_phase,
                    "x1_custody": completed.x1_custody,
                    "shared_record": completed.source.retained_records[-1] is completed.target.retained_records[-1],
                },
                completed.source_phase == completed.target_phase == "W8"
                and completed.x1_custody == 0
                and completed.source.retained_records[-1] is completed.target.retained_records[-1],
                "EXACT_RECONSTRUCTION_VERIFIED",
            ),
            "PACKED_Z4_COORDINATE": (
                {"address": address, "axis": axis},
                {"q_coordinate": q_before},
                q_before in range(4),
                "EXACT_INVERSE_VERIFIED",
            ),
            "SIGNED_EVENT_MAP": (
                {"address": address, "axis": axis, "delta": delta},
                {"address_after": event_after, "reconstructed": event_inverse},
                event_inverse == address,
                "EXACT_INVERSE_VERIFIED",
            ),
            "ENDPOINT_REVERSAL_COVARIANCE": (
                {"address": address, "axis": axis, "delta": delta, "k": 3},
                {"left": reversed_after, "right": covariance_after},
                reversed_after == covariance_after,
                "EXACT_INVERSE_VERIFIED",
            ),
            "SIGNED_PROGRAM_COMPOSITION": (
                {"left_program": program_left, "right_program": program_right, "address": address},
                {
                    "left_translation": translation_left,
                    "right_translation": translation_right,
                    "composed_translation": composed,
                    "output": program_output,
                    "reconstructed": program_reconstructed,
                },
                program_reconstructed == address,
                "EXACT_INVERSE_VERIFIED",
            ),
            "NONCONSTANT_HISTORY_QUOTIENT": (
                {"coordinate_count_per_view": 81},
                {
                    "quotient_coordinate_count": len(quotient.coordinates),
                    "common_anchor": anchor,
                    "reconstructs": reconstructed_history == (left_history, right_history),
                },
                len(quotient.coordinates) == 161 and reconstructed_history == (left_history, right_history),
                "EXACT_RECONSTRUCTION_VERIFIED",
            ),
            "COMMON_CONSTANT_KERNEL": (
                {"common_shift": shift},
                {
                    "quotient_unchanged": shifted_quotient.coordinates == quotient.coordinates,
                    "anchor_shift": shifted_anchor - anchor,
                },
                shifted_quotient.coordinates == quotient.coordinates and shifted_anchor - anchor == 2 * shift,
                "EXACT_RECONSTRUCTION_VERIFIED",
            ),
            "RESOLVED_RESPONSE": (
                {"energy": (3, 4, 5), "completed_mode": (1, 1, 0)},
                {"projection": projection.projection, "resolved_response": projection.resolved_response},
                projection.resolved_response == tuple(-value for value in projection.projection),
                "PROJECTION_RECONSTRUCTION_VERIFIED",
            ),
            "ORTHOGONAL_INFORMATION_REMAINDER": (
                {"energy": (3, 4, 5), "completed_mode": (1, 1, 0)},
                {
                    "orthogonal_remainder": projection.orthogonal_remainder,
                    "orthogonal": projection.orthogonal,
                    "conserved": projection.conserved,
                    "idempotent": projection.idempotent,
                },
                projection.orthogonal and projection.conserved and projection.idempotent,
                "EXACT_RECONSTRUCTION_VERIFIED",
            ),
            "ANALYTIC_BT_DIFFERENCE": (
                {"left": analytic_left, "right": analytic_right},
                {"difference": analytic.difference},
                analytic.difference == tuple(
                    (a[0] - b[0], a[1] - b[1]) for a, b in zip(analytic_left, analytic_right, strict=True)
                ),
                "EXACT_RECONSTRUCTION_VERIFIED",
            ),
            "ANALYTIC_ET_CORRELATIONS": (
                {"left": analytic_left, "right": analytic_right},
                {
                    "write_energy": analytic.write_energy,
                    "correlation_forward": analytic.correlation_forward,
                    "correlation_reverse": analytic.correlation_reverse,
                },
                analytic.correlation_reverse == (
                    analytic.correlation_forward[0], -analytic.correlation_forward[1]
                ),
                "EXACT_RECONSTRUCTION_VERIFIED",
            ),
            "ANALYTIC_J_PPLUS_PMINUS": (
                {"left": analytic_left, "right": analytic_right},
                {
                    "symmetric_view": analytic.symmetric_view,
                    "antisymmetric_view": analytic.antisymmetric_view,
                },
                all(
                    (s[0] + a[0], s[1] + a[1]) == left
                    for s, a, left in zip(
                        analytic.symmetric_view, analytic.antisymmetric_view, analytic_left, strict=True
                    )
                ),
                "EXACT_RECONSTRUCTION_VERIFIED",
            ),
            "CENTERED_TWO_VIEW_FACTORIZATION": (
                {"left": analytic_left, "right": analytic_right},
                {
                    "symmetric_energy": analytic.symmetric_energy,
                    "antisymmetric_energy": analytic.antisymmetric_energy,
                    "centered_energy": analytic.centered_energy,
                    "identity_closes": analytic.identity_closes,
                },
                analytic.identity_closes,
                "EXACT_RECONSTRUCTION_VERIFIED",
            ),
            "MULTIPLICATIVE_LEDGER_COMPOSITION": (
                {"write_states": (5, 7, 11), "ledger_state": 1, "modulus": 17},
                {
                    "transition_count": len(ledger_receipts),
                    "final_state": ledger_final,
                    "composed_multiplier": ledger_composed,
                },
                len(ledger_receipts) == 3 and ledger_final == ledger_composed % 17,
                "EXACT_RECONSTRUCTION_VERIFIED",
            ),
            "MULTIPLICATIVE_LEDGER_READBACK": (
                {"write_state": 5, "ledger_state": 6, "modulus": 12},
                {
                    "after": noninvertible.after,
                    "invertible_before": noninvertible.invertible_before,
                    "recovered_write_state": noninvertible.recovered_write_state,
                },
                not noninvertible.invertible_before and noninvertible.recovered_write_state is None,
                "TYPED_NONINVERTIBILITY_VERIFIED",
            ),
            "Z4_MU4_TRANSFER": (
                {"left_q": 1, "right_q": 3},
                {
                    "left_character": mu_left,
                    "right_character": mu_right,
                    "product": mu_product,
                    "readback_1_to_0": mu_readback,
                },
                mu_product == adapter.mu4_character(0) and mu_readback == adapter.mu4_character(3),
                "EXACT_INVERSE_VERIFIED",
            ),
        }

        operations: list[ExactWriteOperation] = []
        for descriptor in adapter.operation_descriptors:
            if descriptor.operation_id not in fixture:
                raise NativeSubstrateContractError(
                    f"missing canonical fixture for {descriptor.operation_id}"
                )
            input_value, output_value, law_holds, inverse_status = fixture[descriptor.operation_id]
            if not law_holds:
                raise NativeSubstrateContractError(
                    f"executed canonical fixture failed for {descriptor.operation_id}"
                )
            operations.append(
                ExactWriteOperation.create(
                    operation_id=descriptor.operation_id,
                    domain_space=descriptor.input_schema,
                    codomain_space=descriptor.output_schema,
                    exact_law=descriptor.exact_law,
                    reconstruction_contract=descriptor.reconstruction_contract,
                    inverse_status=inverse_status,
                    fixture_input=input_value,
                    fixture_output=output_value,
                    law_holds=bool(law_holds),
                    source_seal=seal,
                )
            )
        if len(operations) != 19:
            raise NativeSubstrateContractError("canonical Exact Write operation roster is not 19")
        return tuple(operations)

    def receipt_graph_fixture(self) -> ReceiptGraph:
        graph = ExactWriteTranslationGraph(
            self.adapter, ((0, 1), (4, -1), (0, -1), (7, 1))
        )
        inverse = self.adapter.inverse_translation(graph.compiled_translation)
        fixture = ReceiptGraph(
            graph_id=graph.graph_id,
            receipt_id=graph.receipt.receipt_id,
            domain_space="PackedTheta18Address[0,2^18)",
            codomain_space="PackedTheta18Address[0,2^18)",
            sequential_program=graph.sequential_program,
            compiled_translation=graph.compiled_translation,
            inverse_translation=inverse,
            source_seal=self.exact_write_source_seal,
        )
        output = fixture.execute(self.adapter, 12_345)
        if fixture.reconstruct(self.adapter, output) != 12_345:
            raise NativeSubstrateContractError("receipt graph fixture inverse failed")
        return fixture

    def visible_fiber_fixture(self) -> VisibleFiber:
        source = self.adapter.w8_site(4)
        target = self.adapter.w8_site(11)
        records: list[W9P] = []
        for orientation in (-1, 1):
            completed = self.adapter.complete_write(
                self.adapter.activate_write(
                    source, target, 2, orientation, 19, 257
                )
            )
            if self.adapter.project_w8(completed.retained_record) != 11:
                raise NativeSubstrateContractError("W9 visible projection fixture changed")
            records.append(
                _w9p_from_runtime(
                    completed.retained_record, self.exact_write_source_seal
                )
            )
        fiber = VisibleFiber.create(
            domain_space="DeclaredTwoOrientationW9ReceiptFixture",
            codomain_space="W8ShellState",
            visible_value=11,
            source_points=[record.to_dict() for record in records],
            receipt_labels=("NEGATIVE_ORIENTATION", "POSITIVE_ORIENTATION"),
            source_seal=self.exact_write_source_seal,
        )
        if fiber.reconstruct("NEGATIVE_ORIENTATION") != records[0].to_dict():
            raise NativeSubstrateContractError("visible fiber receipt inverse failed")
        return fiber

    def w8_fixture(self) -> W8State:
        shell = 173
        return W8State(
            shell_state=shell,
            bits=self.adapter.w8_bits(shell),
            source_seal=self.exact_write_source_seal,
        )

    def w9_history_fixture(self) -> W9History:
        records: list[W9P] = []
        for shell, target_shell, axis, orientation, address in (
            (4, 11, 2, 1, 257),
            (11, 7, 5, -1, 913),
        ):
            completed = self.adapter.complete_write(
                self.adapter.activate_write(
                    self.adapter.w8_site(shell),
                    self.adapter.w8_site(target_shell),
                    axis,
                    orientation,
                    19 + axis,
                    address,
                )
            )
            records.append(
                _w9p_from_runtime(
                    completed.retained_record, self.exact_write_source_seal
                )
            )
        history = W9History(tuple(records), self.exact_write_source_seal)
        if history.reconstruct_shell_history() != (11, 7):
            raise NativeSubstrateContractError("W9 history projection fixture changed")
        return history

    def afc_transport_fixture(self) -> AFCTransportReference:
        graph = self.receipt_graph_fixture()
        before = 91_337
        after = graph.execute(self.adapter, before)
        body = {
            "schema": "SLC_AFC_TRANSPORT_REFERENCE_ID_V6",
            "before": before,
            "after": after,
            "translation": graph.compiled_translation,
            "source_sha256": self.exact_write_source_seal.sha256,
        }
        result = AFCTransportReference(
            reference_id=_semantic_sha256(body),
            domain_space="AFCCommonReferenceTheta18",
            codomain_space="AFCTransportedReferenceTheta18",
            address_before=before,
            address_after=after,
            translation=graph.compiled_translation,
            inverse_translation=graph.inverse_translation,
            source_seal=self.exact_write_source_seal,
        )
        result.transport(self.adapter)
        result.reconstruct_before(self.adapter)
        return result

    def theta18_fixture(self) -> Theta18Report:
        address = 74_321
        return Theta18Report(
            address=address,
            coordinates=tuple(
                self.adapter.q_coordinate(address, axis) for axis in range(9)
            ),
            source_seal=self.exact_write_source_seal,
        )

    def support_fixture(self) -> SupportObject:
        theta = self.theta18_fixture()
        indices = tuple(
            index for index, coordinate in enumerate(theta.coordinates) if coordinate
        )
        coefficients = tuple(Fraction(theta.coordinates[index]) for index in indices)
        return SupportObject(
            ambient_space="Q^9_Theta18CoordinateSupport",
            dimension=9,
            support_indices=indices,
            coefficients=coefficients,
            source_seal=self.exact_write_source_seal,
        )

    def gram_fixture(self) -> GramObject:
        bits = self.w8_fixture().bits
        return GramObject.from_vectors(
            "Q^8_W8ShellCoordinates",
            (
                bits,
                tuple(1 - bit for bit in bits),
                tuple(1 if index % 2 == 0 else -1 for index in range(8)),
            ),
            self.exact_write_source_seal,
        )

    def tensor_orbit_fixture(self) -> TensorOrbitObject:
        theta = self.theta18_fixture()
        return TensorOrbitObject.from_seed(
            "Z4^3_tensor_coordinate",
            theta.coordinates[:3],
            self.exact_write_source_seal,
        )

    def composition_fixture(self) -> ExactComposition:
        left = self.adapter.compile_translation(((0, 1), (3, -1)))
        right = self.adapter.compile_translation(((7, 1), (0, -1)))
        composed = self.adapter.compose_translations(left, right)
        result = ExactComposition(
            domain_space="PackedTheta18Address[0,2^18)",
            codomain_space="PackedTheta18Address[0,2^18)",
            left_translation=left,
            right_translation=right,
            composed_translation=composed,
            inverse_translation=self.adapter.inverse_translation(composed),
            source_seal=self.exact_write_source_seal,
        )
        output = result.execute(self.adapter, 17_171)
        if result.reconstruct(self.adapter, output) != 17_171:
            raise NativeSubstrateContractError("exact composition inverse failed")
        return result

    def prime_valuation_fixture(self) -> PrimeValuationVector:
        left = PrimeValuationVector.from_rational(
            Fraction(12, 5), source_provenance="DECLARED_EXACT_12_OVER_5_FIXTURE"
        )
        right = PrimeValuationVector.from_rational(
            Fraction(15, 2), source_provenance="DECLARED_EXACT_15_OVER_2_FIXTURE"
        )
        result = left.compose(right, provenance="EXACT_RATIONAL_COMPOSITION_18")
        if result.rational_value != 18:
            raise NativeSubstrateContractError("prime valuation composition failed")
        return result

    def formal_log_fixture(self) -> FormalLogMonoidElement:
        left = FormalLogMonoidElement.from_positive_rational(
            12, source_provenance="DECLARED_ROUTE_RADIX_12"
        )
        right = FormalLogMonoidElement.from_positive_rational(
            Fraction(3, 2), source_provenance="DECLARED_OVERFLOW_3_OVER_2"
        )
        result = left.compose(right, provenance="EXACT_12_TIMES_3_OVER_2_EQUALS_18")
        expected = FormalLogElement.from_positive_rational(18)
        if result.value != expected:
            raise NativeSubstrateContractError("formal-log monoid composition failed")
        return result

    def custody_fixture(self) -> CustodyAnnotation:
        domain = ("NEGATIVE_ORIENTATION", "POSITIVE_ORIENTATION")
        visible = InformationPartition.from_map(
            "V6_CANONICAL_VISIBLE_W8",
            domain,
            {item: "SHELL_11" for item in domain},
        )
        branch = InformationPartition.from_map(
            "V6_CANONICAL_ANTISYMMETRIC_BRANCH",
            domain,
            {item: item for item in domain},
        )
        system = ReceiptSystem(
            visible,
            (ReceiptChannel("ANTISYMMETRIC_BRANCH", branch),),
        )
        law = ExactDistribution.uniform(
            domain,
            provenance="DECLARED_UNIFORM_TWO_ORIENTATION_EXACT_WRITE_FIXTURE",
        )
        native = build_custody_annotation(
            source_operation_id="W9_RECORD_PROJECTION",
            source_revision_and_hashes=((
                self.exact_write_source_seal.role,
                self.exact_write_source_seal.sha256,
            ),),
            input_space="DeclaredTwoOrientationW9ReceiptFixture",
            visible_projection_definition="project_w8(W9P)=shell_state",
            receipt_system=system,
            source_item=domain[0],
            retained_channels=("ANTISYMMETRIC_BRANCH",),
            reciprocal_orbit_cardinality=2,
            common_anchor_status="NOT_APPLICABLE",
            probability_model=law,
            logical_event_status=NO_ERASURE_RECEIPTS_RETAINED,
        )
        if native.hidden_entropy is None or native.retained_information is None or native.logical_erasure is None:
            raise NativeSubstrateContractError("custody fixture did not assign exact information")
        return CustodyAnnotation(
            annotation_id=native.annotation_id,
            source_operation_id=native.source_operation_id,
            input_space=native.input_space,
            visible_fiber_cardinality=native.visible_fiber_cardinality,
            generated_receipt_channels=native.generated_receipt_channels,
            retained_receipt_channels=native.retained_receipt_channels,
            reconstructible=native.reconstructible,
            hidden_information=FormalLogMonoidElement(
                native.hidden_entropy, law.provenance
            ),
            retained_information=FormalLogMonoidElement(
                native.retained_information, law.provenance
            ),
            logical_erasure=FormalLogMonoidElement(
                native.logical_erasure, law.provenance
            ),
            logical_erasure_status=native.logical_erasure_event_status,
            probability_model_provenance=law.provenance,
            source_seal=self.exact_write_source_seal,
        )

    def logical_erasure_fixtures(self) -> tuple[LogicalErasureEvent, LogicalErasureEvent]:
        reversible = LogicalResetEvent.reversible_exact_write(
            "V6_CANONICAL_RECEIPT_RETENTION",
            retained_channels=("ANTISYMMETRIC_BRANCH",),
            source_law_provenance="DECLARED_UNIFORM_TWO_ORIENTATION_EXACT_WRITE_FIXTURE",
        )
        irreversible = LogicalResetEvent.uniform_irreversible_destruction(
            "V6_CANONICAL_RECEIPT_DESTRUCTION",
            2,
            destroyed_channels=("ANTISYMMETRIC_BRANCH",),
            retained_channels=("VISIBLE_W8",),
            source_law_provenance="DECLARED_UNIFORM_TWO_ORIENTATION_EXACT_WRITE_FIXTURE",
        )
        return (
            LogicalErasureEvent.from_reset_event(
                reversible, self.exact_write_source_seal
            ),
            LogicalErasureEvent.from_reset_event(
                irreversible, self.exact_write_source_seal
            ),
        )

    def depth_blocks(self) -> tuple[ExactDepthBlock, ...]:
        initial = self._depth_node.DyadicState(127, 3, 5, 0)
        prior = _state_tuple(initial)
        blocks: list[ExactDepthBlock] = []
        for depth in AVAILABLE_DEPTHS:
            receipt = self._depth_node.block_step(initial, depth)
            if not isinstance(receipt, dict):
                raise NativeSubstrateContractError("delegated depth receipt is not an object")
            following = _state_tuple(receipt.get("following"))
            composition = tuple(self._depth_node.composition_for_depth(depth))
            history_reconstructs = receipt.get("history_reconstructs")
            body = {
                "schema": "SLC_CANONICAL_DEPTH_RECEIPT_ID_V6",
                "depth": depth,
                "composition": composition,
                "prior_state": prior,
                "following_state": following,
                "history_reconstructs": history_reconstructs,
                "source_sha256": self.depth_implementation_seal.sha256,
            }
            blocks.append(
                ExactDepthBlock(
                    depth=depth,
                    composition=composition,
                    prior_state=prior,
                    following_state=following,
                    history_reconstructs=_strict_bool(
                        history_reconstructs, "delegated history_reconstructs"
                    ),
                    receipt_semantic_sha256=_semantic_sha256(body),
                    source_seal=self.depth_implementation_seal,
                )
            )
        if tuple(block.depth for block in blocks) != AVAILABLE_DEPTHS:
            raise NativeSubstrateContractError("canonical depth fixture roster changed")
        return tuple(blocks)

    def canonical_fixtures(self) -> tuple[object, ...]:
        """Return every canonical type fixture, including both logical event cases."""

        return (
            self.exact_write_operations()[0],
            self.visible_fiber_fixture(),
            self.receipt_graph_fixture(),
            self.w8_fixture(),
            self.w9_history_fixture(),
            self.w9_history_fixture().records[0],
            self.afc_transport_fixture(),
            self.theta18_fixture(),
            self.support_fixture(),
            self.gram_fixture(),
            self.tensor_orbit_fixture(),
            self.depth_blocks()[0],
            self.composition_fixture(),
            self.prime_valuation_fixture(),
            self.formal_log_fixture(),
            self.custody_fixture(),
            *self.logical_erasure_fixtures(),
        )

    def audit(self) -> dict[str, object]:
        operations = self.exact_write_operations()
        depths = self.depth_blocks()
        typed = self.canonical_fixtures()
        round_trip_failures: list[str] = []
        for record in typed:
            try:
                rebuilt = canonical_round_trip(record)
            except Exception as exc:  # recorded, then failed by status below
                round_trip_failures.append(f"{type(record).__name__}: {exc}")
                continue
            if rebuilt != record:
                round_trip_failures.append(f"{type(record).__name__}: inequality")
        status = (
            len(operations) == 19
            and all(operation.law_holds for operation in operations)
            and tuple(block.depth for block in depths) == AVAILABLE_DEPTHS
            and not round_trip_failures
        )
        return {
            "schema": "SLC_NATIVE_EXACT_SUBSTRATE_PLANE_AUDIT_V6",
            "operation_count": len(operations),
            "operation_ids": [operation.operation_id for operation in operations],
            "operation_fixtures_passed": sum(operation.law_holds for operation in operations),
            "depth_service_count": len(depths),
            "available_depths": list(AVAILABLE_DEPTHS),
            "canonical_type_fixture_count": len(typed),
            "round_trip_failure_count": len(round_trip_failures),
            "round_trip_failures": round_trip_failures,
            "source_seals": [seal.to_dict() for seal in self.source_seals],
            "predecessor_implementation_copied": False,
            "status": "PASS" if status else "FAIL",
        }

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.SCHEMA,
            "status": "CANDIDATE_UNINSTALLED",
            "domain_space": "FrozenExactWriteAndDyadicServiceInputs",
            "codomain_space": "CanonicalNativeExactSubstrateObjects",
            "current_revision_required": self.adapter.dependency_receipt.current_revision_name,
            "operation_ids": [
                descriptor.operation_id
                for descriptor in self.adapter.operation_descriptors
            ],
            "available_depths": list(AVAILABLE_DEPTHS),
            "source_seals": [seal.to_dict() for seal in self.source_seals],
            "mutation_allowed": False,
            "predecessor_implementation_copied": False,
        }

    @classmethod
    def from_dict(
        cls, value: Mapping[str, Any], adapter: CompleteExactWriteAdapter
    ) -> "NativeExactSubstratePlane":
        fields = {
            "status", "domain_space", "codomain_space", "current_revision_required",
            "operation_ids", "available_depths", "source_seals", "mutation_allowed",
            "predecessor_implementation_copied",
        }
        row = _record(value, cls.SCHEMA, fields, "NativeExactSubstratePlane")
        rebuilt = cls(adapter)
        if _canonical_json(row) != _canonical_json(rebuilt.to_dict()):
            raise NativeSubstrateContractError("serialized substrate plane does not match frozen services")
        return rebuilt


CANONICAL_TYPE_REGISTRY = (
    NativeSourceSeal,
    ExactWriteOperation,
    VisibleFiber,
    ReceiptGraph,
    W8State,
    W9History,
    W9P,
    AFCTransportReference,
    Theta18Report,
    SupportObject,
    GramObject,
    TensorOrbitObject,
    ExactDepthBlock,
    ExactComposition,
    PrimeValuationVector,
    FormalLogMonoidElement,
    CustodyAnnotation,
    LogicalErasureEvent,
)


def canonical_round_trip(record: object) -> object:
    """Strictly serialize and reconstruct one registered canonical record."""

    record_type = type(record)
    if record_type not in CANONICAL_TYPE_REGISTRY:
        raise TypeError("record type is not in the native canonical registry")
    return record_type.from_dict(record.to_dict())


__all__ = (
    "AFCTransportReference",
    "AVAILABLE_DEPTHS",
    "CANONICAL_TYPE_REGISTRY",
    "CustodyAnnotation",
    "ExactComposition",
    "ExactDepthBlock",
    "ExactWriteOperation",
    "FormalLogMonoidElement",
    "GramObject",
    "LogicalErasureEvent",
    "NativeExactSubstratePlane",
    "NativeSourceSeal",
    "NativeSubstrateContractError",
    "PrimeValuationVector",
    "ReceiptGraph",
    "SupportObject",
    "TensorOrbitObject",
    "Theta18Report",
    "VisibleFiber",
    "W8State",
    "W9History",
    "W9P",
    "canonical_round_trip",
)
