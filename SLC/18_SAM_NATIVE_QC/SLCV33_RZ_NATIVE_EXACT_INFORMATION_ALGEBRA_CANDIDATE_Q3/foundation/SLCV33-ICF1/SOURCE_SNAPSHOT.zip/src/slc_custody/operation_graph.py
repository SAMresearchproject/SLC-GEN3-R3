"""Canonical typed operation graphs over the frozen Complete Exact Write API."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Iterable, Mapping, Sequence

from .exact_write import CompleteExactWriteAdapter


def _canonical_bytes(value: object) -> bytes:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=True
    ).encode("utf-8")


@dataclass(frozen=True, slots=True)
class ExactWriteOperationNode:
    node_index: int
    operation_id: str
    domain_type: str
    codomain_type: str
    parameters: tuple[tuple[str, int], ...]
    forward_contract: str
    inverse_status: str
    inverse_contract: str
    visible_projection: str
    generated_receipt_channels: tuple[str, ...]
    immutable_source_sha256: str

    def __post_init__(self) -> None:
        if type(self.node_index) is not int or self.node_index < 0:
            raise ValueError("operation node index must be a nonnegative integer")
        if not self.operation_id or not self.operation_id.isupper():
            raise ValueError("operation node id must be uppercase")
        if self.inverse_status not in {
            "DECLARED_INVERSE",
            "LEFT_INVERSE",
            "RIGHT_INVERSE",
            "NONINVERTIBLE_WITNESS",
        }:
            raise ValueError("operation node has an unknown inverse status")
        if len(self.immutable_source_sha256) != 64:
            raise ValueError("operation node requires a source SHA-256")
        if tuple(sorted(self.parameters)) != self.parameters:
            raise ValueError("operation parameters must be canonically sorted")

    def to_dict(self) -> dict[str, object]:
        return {
            "node_index": self.node_index,
            "operation_id": self.operation_id,
            "domain_type": self.domain_type,
            "codomain_type": self.codomain_type,
            "parameters": [
                {"name": name, "value": value} for name, value in self.parameters
            ],
            "forward_contract": self.forward_contract,
            "inverse_status": self.inverse_status,
            "inverse_contract": self.inverse_contract,
            "visible_projection": self.visible_projection,
            "generated_receipt_channels": list(self.generated_receipt_channels),
            "immutable_source_sha256": self.immutable_source_sha256,
        }


@dataclass(frozen=True, slots=True)
class TranslationHistoryReceipt:
    schema: str
    graph_id: str
    receipt_id: str
    sequential_program: tuple[tuple[int, int], ...]
    compiled_translation: int
    immutable_source_sha256: str

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.schema,
            "graph_id": self.graph_id,
            "receipt_id": self.receipt_id,
            "sequential_program": [
                {"axis": axis, "delta": delta}
                for axis, delta in self.sequential_program
            ],
            "compiled_translation": self.compiled_translation,
            "immutable_source_sha256": self.immutable_source_sha256,
        }


@dataclass(frozen=True, slots=True)
class TranslationNormalFormReceipt:
    """Minimal fixed translation retained when sequential history may be released."""

    schema: str
    graph_id: str
    compiled_translation: int
    immutable_source_sha256: str

    def __post_init__(self) -> None:
        if self.schema != "SLC_EXACT_WRITE_TRANSLATION_NORMAL_FORM_RECEIPT_V6":
            raise ValueError("unknown translation normal-form receipt schema")
        for digest, label in (
            (self.graph_id, "graph_id"),
            (self.immutable_source_sha256, "immutable_source_sha256"),
        ):
            if len(digest) != 64 or any(character not in "0123456789abcdef" for character in digest):
                raise ValueError(f"{label} must be a lowercase SHA-256")
        if type(self.compiled_translation) is not int or not 0 <= self.compiled_translation < (1 << 18):
            raise ValueError("compiled translation must lie in packed Z4^9")

    @property
    def fixed_container_bits(self) -> int:
        return 18

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.schema,
            "graph_id": self.graph_id,
            "compiled_translation": self.compiled_translation,
            "immutable_source_sha256": self.immutable_source_sha256,
            "fixed_container_bits": self.fixed_container_bits,
        }


class ExactWriteTranslationGraph:
    """One canonical group element plus an optional sequential-history receipt."""

    def __init__(
        self,
        adapter: CompleteExactWriteAdapter,
        program: Sequence[tuple[int, int]],
    ) -> None:
        if not isinstance(adapter, CompleteExactWriteAdapter):
            raise TypeError("operation graph requires CompleteExactWriteAdapter")
        frozen: list[tuple[int, int]] = []
        source_sha = adapter.dependency_receipt.artifact(
            "COMPLETE_EXACT_WRITE_SOURCE"
        ).sha256
        descriptor = adapter.descriptor("SIGNED_EVENT_MAP")
        nodes: list[ExactWriteOperationNode] = []
        for index, raw in enumerate(program):
            if not isinstance(raw, tuple) or len(raw) != 2:
                raise TypeError("translation program rows must be (axis,delta) tuples")
            axis, delta = raw
            if type(axis) is not int or type(delta) is not int:
                raise TypeError("translation program coordinates must be integers")
            if not 0 <= axis < 9 or delta not in (-1, 1):
                raise ValueError("translation event is outside signed Z4^9")
            frozen.append((axis, delta))
            nodes.append(
                ExactWriteOperationNode(
                    node_index=index,
                    operation_id="SIGNED_EVENT_MAP",
                    domain_type="Theta18Address",
                    codomain_type="Theta18Address",
                    parameters=(("axis", axis), ("delta", delta)),
                    forward_contract=descriptor.exact_law,
                    inverse_status="DECLARED_INVERSE",
                    inverse_contract="same axis with negated delta",
                    visible_projection="translated Theta18 address",
                    generated_receipt_channels=("SIGNED_EVENT_HISTORY",),
                    immutable_source_sha256=source_sha,
                )
            )
        if not frozen:
            raise ValueError("translation operation graph requires at least one event")
        self.adapter = adapter
        self.sequential_program = tuple(frozen)
        self.sequential_nodes = tuple(nodes)
        self.compiled_translation = adapter.compile_translation(
            self.sequential_program
        )
        graph_body = {
            "schema": "SLC_EXACT_WRITE_TRANSLATION_GRAPH_IDENTITY_V6",
            "operation_id": "SIGNED_PROGRAM_COMPOSITION",
            "domain_type": "Theta18Address",
            "codomain_type": "Theta18Address",
            "normal_form_translation": self.compiled_translation,
            "immutable_source_sha256": source_sha,
        }
        self.graph_id = hashlib.sha256(_canonical_bytes(graph_body)).hexdigest()
        receipt_body = {
            "graph_id": self.graph_id,
            "sequential_program": self.sequential_program,
            "immutable_source_sha256": source_sha,
        }
        receipt_id = hashlib.sha256(_canonical_bytes(receipt_body)).hexdigest()
        self.receipt = TranslationHistoryReceipt(
            schema="SLC_EXACT_WRITE_TRANSLATION_HISTORY_RECEIPT_V6",
            graph_id=self.graph_id,
            receipt_id=receipt_id,
            sequential_program=self.sequential_program,
            compiled_translation=self.compiled_translation,
            immutable_source_sha256=source_sha,
        )
        self.normal_form_receipt = TranslationNormalFormReceipt(
            schema="SLC_EXACT_WRITE_TRANSLATION_NORMAL_FORM_RECEIPT_V6",
            graph_id=self.graph_id,
            compiled_translation=self.compiled_translation,
            immutable_source_sha256=source_sha,
        )

    @property
    def normal_form_node(self) -> ExactWriteOperationNode:
        descriptor = self.adapter.descriptor("SIGNED_PROGRAM_COMPOSITION")
        source_sha = self.receipt.immutable_source_sha256
        return ExactWriteOperationNode(
            node_index=0,
            operation_id="SIGNED_PROGRAM_COMPOSITION",
            domain_type="Theta18Address",
            codomain_type="Theta18Address",
            parameters=(("translation", self.compiled_translation),),
            forward_contract=descriptor.exact_law,
            inverse_status="DECLARED_INVERSE",
            inverse_contract="inverse Z4^9 translation",
            visible_projection="final translated Theta18 address",
            generated_receipt_channels=("SEQUENTIAL_PROGRAM_HISTORY",),
            immutable_source_sha256=source_sha,
        )

    def execute_reference(self, address: int) -> int:
        visible = address
        for axis, delta in self.sequential_program:
            visible = self.adapter.event_map(visible, axis, delta)
        return visible

    def execute_compiled(self, address: int) -> int:
        return self.adapter.apply_translation(address, self.compiled_translation)

    def reconstruct_input(
        self, final_address: int, receipt: TranslationHistoryReceipt
    ) -> int:
        if receipt.graph_id != self.graph_id:
            raise ValueError("history receipt belongs to a different normal-form graph")
        if receipt.receipt_id != self.receipt.receipt_id or receipt != self.receipt:
            raise ValueError("history receipt does not match the declared sequential program")
        inverse = self.adapter.inverse_translation(receipt.compiled_translation)
        return self.adapter.apply_translation(final_address, inverse)

    def reconstruct_input_from_normal_form(
        self,
        final_address: int,
        receipt: TranslationNormalFormReceipt,
    ) -> int:
        if not isinstance(receipt, TranslationNormalFormReceipt):
            raise TypeError("input reconstruction requires a normal-form receipt")
        if receipt != self.normal_form_receipt:
            raise ValueError("normal-form receipt belongs to a different graph")
        inverse = self.adapter.inverse_translation(receipt.compiled_translation)
        return self.adapter.apply_translation(final_address, inverse)

    def custody_compilation_certificate(
        self, addresses: Iterable[int]
    ) -> dict[str, object]:
        """Certify release of event history when only source recovery is required."""

        frozen = tuple(addresses)
        reconstructs = all(
            self.reconstruct_input_from_normal_form(
                self.execute_compiled(address), self.normal_form_receipt
            )
            == address
            for address in frozen
        )
        event_history_bits = 5 * len(self.sequential_program)
        full_receipt_bits = event_history_bits + 18
        return {
            "schema": "SLC_EXACT_WRITE_TRANSLATION_CUSTODY_COMPILATION_V6",
            "graph_id": self.graph_id,
            "observation_boundary": (
                "final translated address plus conditioned-known graph identity"
            ),
            "sequential_program_history_required": False,
            "sequential_program_history_reconstructible_after_release": False,
            "source_address_reconstructible": reconstructs,
            "declared_fixed_encoding": {
                "axis_bits_per_event": 4,
                "sign_bits_per_event": 1,
                "packed_Z4_9_normal_form_bits": 18,
            },
            "sequential_event_count": len(self.sequential_program),
            "full_history_plus_normal_form_container_bits": full_receipt_bits,
            "final_normal_form_container_bits": 18,
            "released_temporary_container_bits": event_history_bits,
            "logical_source_erasure_exact_nats": "0",
            "program_history_information_erasure": "UNASSIGNED_NO_PROGRAM_SOURCE_LAW",
            "timing_claim": "NOT_MEASURED",
            "schedule": [
                "COPY_FINAL_ADDRESS_AND_NORMAL_FORM_RECEIPT",
                "APPLY_INVERSE_EVENTS_TO_CLEAR_TEMPORARY_EVENT_HISTORY",
                "RETAIN_COMPILED_TRANSLATION_FOR_SOURCE_RECONSTRUCTION",
            ],
            "status": "PASS_ZERO_SOURCE_ERASURE" if reconstructs else "FAIL",
        }

    def audit(self, addresses: Iterable[int]) -> dict[str, object]:
        frozen = tuple(addresses)
        failures: list[dict[str, int]] = []
        for address in frozen:
            reference = self.execute_reference(address)
            compiled = self.execute_compiled(address)
            reconstructed = self.reconstruct_input(compiled, self.receipt)
            if reference != compiled or reconstructed != address:
                failures.append(
                    {
                        "address": address,
                        "reference": reference,
                        "compiled": compiled,
                        "reconstructed": reconstructed,
                    }
                )
        return {
            "schema": "SLC_EXACT_WRITE_OPERATION_GRAPH_AUDIT_V6",
            "graph_id": self.graph_id,
            "receipt_id": self.receipt.receipt_id,
            "normal_form_node": self.normal_form_node.to_dict(),
            "sequential_nodes": [node.to_dict() for node in self.sequential_nodes],
            "address_count": len(frozen),
            "failure_count": len(failures),
            "failures": failures,
            "reference_compiled_inverse_exact": not failures,
            "status": "PASS" if not failures else "FAIL",
        }


def ledger_invertibility_witness(
    adapter: CompleteExactWriteAdapter,
    *,
    write_state: int,
    ledger_state: int,
    modulus: int,
) -> dict[str, object]:
    receipt = adapter.ledger_write(write_state, ledger_state, modulus)
    return {
        "schema": "SLC_EXACT_WRITE_LEDGER_INVERTIBILITY_WITNESS_V6",
        "operation_id": "MULTIPLICATIVE_LEDGER_READBACK",
        "before": receipt.before,
        "write_state": receipt.write_state,
        "after": receipt.after,
        "modulus": receipt.modulus,
        "inverse_status": (
            "DECLARED_INVERSE"
            if receipt.invertible_before
            else "NONINVERTIBLE_WITNESS"
        ),
        "recovered_write_state": receipt.recovered_write_state,
        "noninvertibility_is_typed": (
            receipt.invertible_before or receipt.recovered_write_state is None
        ),
    }


__all__ = (
    "ExactWriteOperationNode",
    "ExactWriteTranslationGraph",
    "TranslationHistoryReceipt",
    "TranslationNormalFormReceipt",
    "ledger_invertibility_witness",
)
