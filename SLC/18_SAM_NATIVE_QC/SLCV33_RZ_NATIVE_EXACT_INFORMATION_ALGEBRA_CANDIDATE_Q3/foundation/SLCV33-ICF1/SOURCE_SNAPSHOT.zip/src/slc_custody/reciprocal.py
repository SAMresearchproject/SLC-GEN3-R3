"""Actual reciprocal orbits, visible fibers, and lifted history custody."""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable

from .exact_write import CompleteExactWriteAdapter
from .information import InformationPartition, ReceiptChannel, ReceiptSystem


Pair = tuple[int, int]


def _canonical_bytes(value: object) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _strict_modulus(modulus: int) -> int:
    if type(modulus) is not int or modulus < 2:
        raise ValueError("reciprocal modulus must be an integer at least two")
    return modulus


def reciprocal_involution(pair: Pair, modulus: int) -> Pair:
    modulus = _strict_modulus(modulus)
    if (
        not isinstance(pair, tuple)
        or len(pair) != 2
        or any(type(value) is not int for value in pair)
    ):
        raise TypeError("reciprocal source point must be an integer pair")
    s, d = pair
    if not 0 <= s < modulus or not 0 <= d < modulus:
        raise ValueError("reciprocal source point is outside the finite domain")
    return ((-s) % modulus, (-d) % modulus)


def reciprocal_visible_map(pair: Pair, modulus: int) -> Pair:
    """The installed finite reciprocal map F_M(s,d)."""

    modulus = _strict_modulus(modulus)
    s, d = pair
    reciprocal_involution(pair, modulus)
    return ((s * s - 2) % modulus, (s * d) % modulus)


@dataclass(frozen=True, slots=True)
class ReciprocalOrbit:
    modulus: int
    members: tuple[Pair, ...]
    fixed_point: bool
    orbit_id: str

    @classmethod
    def containing(cls, pair: Pair, modulus: int) -> "ReciprocalOrbit":
        partner = reciprocal_involution(pair, modulus)
        members = tuple(sorted({pair, partner}))
        orbit_id = hashlib.sha256(
            _canonical_bytes(
                {"schema": "SLC_RECIPROCAL_ORBIT_V6", "modulus": modulus, "members": members}
            )
        ).hexdigest()
        return cls(modulus, members, len(members) == 1, orbit_id)

    @property
    def cardinality(self) -> int:
        return len(self.members)

    def branch_index(self, pair: Pair) -> int:
        try:
            return self.members.index(pair)
        except ValueError as exc:
            raise ValueError("point is outside this reciprocal orbit") from exc

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_RECIPROCAL_ORBIT_V6",
            "modulus": self.modulus,
            "members": [list(member) for member in self.members],
            "cardinality": self.cardinality,
            "fixed_point": self.fixed_point,
            "orbit_id": self.orbit_id,
        }


@dataclass(frozen=True, slots=True)
class ReciprocalFiberCensus:
    modulus: int
    input_count: int
    visible_output_count: int
    visible_fiber_histogram: tuple[tuple[int, int], ...]
    reciprocal_orbit_histogram: tuple[tuple[int, int], ...]
    reciprocal_covariance: bool
    generated_receipt_channels: tuple[str, ...]
    minimum_sufficient_channels: tuple[str, ...]
    augmented_map_injective: bool

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_RECIPROCAL_FIBER_CENSUS_V6",
            "modulus": self.modulus,
            "input_count": self.input_count,
            "visible_output_count": self.visible_output_count,
            "visible_fiber_histogram": [
                {"fiber_cardinality": size, "visible_output_count": count}
                for size, count in self.visible_fiber_histogram
            ],
            "reciprocal_orbit_histogram": [
                {"orbit_cardinality": size, "orbit_count": count}
                for size, count in self.reciprocal_orbit_histogram
            ],
            "reciprocal_covariance": self.reciprocal_covariance,
            "generated_receipt_channels": list(self.generated_receipt_channels),
            "minimum_sufficient_channels": list(self.minimum_sufficient_channels),
            "augmented_map_injective": self.augmented_map_injective,
        }


def reciprocal_receipt_system(modulus: int) -> ReceiptSystem:
    modulus = _strict_modulus(modulus)
    domain = tuple((s, d) for s in range(modulus) for d in range(modulus))
    visible = InformationPartition.from_map(
        f"F_{modulus}", domain, lambda pair: reciprocal_visible_map(pair, modulus)
    )
    orbit_partition = InformationPartition.from_map(
        "reciprocal_orbit_identity",
        domain,
        lambda pair: ReciprocalOrbit.containing(pair, modulus).members,
    )
    branch_partition = InformationPartition.from_map(
        "antisymmetric_branch",
        domain,
        lambda pair: ReciprocalOrbit.containing(pair, modulus).branch_index(pair),
    )
    return ReceiptSystem(
        visible,
        (
            ReceiptChannel("ANTISYMMETRIC_BRANCH", branch_partition),
            ReceiptChannel("RECIPROCAL_ORBIT_IDENTITY", orbit_partition),
        ),
    )


def census_reciprocal_map(modulus: int) -> ReciprocalFiberCensus:
    system = reciprocal_receipt_system(modulus)
    fiber_histogram: dict[int, int] = {}
    for block in system.visible.blocks:
        fiber_histogram[len(block)] = fiber_histogram.get(len(block), 0) + 1
    observed_orbits: dict[tuple[Pair, ...], ReciprocalOrbit] = {}
    covariance = True
    for pair in system.visible.domain:
        orbit = ReciprocalOrbit.containing(pair, modulus)
        observed_orbits[orbit.members] = orbit
        covariance = covariance and (
            reciprocal_visible_map(pair, modulus)
            == reciprocal_visible_map(reciprocal_involution(pair, modulus), modulus)
        )
    orbit_histogram: dict[int, int] = {}
    for orbit in observed_orbits.values():
        orbit_histogram[orbit.cardinality] = (
            orbit_histogram.get(orbit.cardinality, 0) + 1
        )
    sufficient = system.minimum_sufficient_channels()
    return ReciprocalFiberCensus(
        modulus=modulus,
        input_count=len(system.visible.domain),
        visible_output_count=len(system.visible.blocks),
        visible_fiber_histogram=tuple(sorted(fiber_histogram.items())),
        reciprocal_orbit_histogram=tuple(sorted(orbit_histogram.items())),
        reciprocal_covariance=covariance,
        generated_receipt_channels=system.channel_names,
        minimum_sufficient_channels=sufficient.selected_channels,
        augmented_map_injective=system.augmented(system.channel_names).is_discrete,
    )


@dataclass(frozen=True, slots=True)
class ReciprocalHistoryLift:
    prior_common: int
    prior_directional: int
    next_common: int
    next_directional: int
    left: tuple[Fraction, ...]
    right: tuple[Fraction, ...]
    symmetric: tuple[Fraction, ...]
    antisymmetric: tuple[Fraction, ...]
    quotient_coordinates: tuple[Fraction, ...]
    common_anchor: Fraction
    reconstructs: bool

    @classmethod
    def build(
        cls,
        adapter: CompleteExactWriteAdapter,
        *,
        prior_common: int,
        prior_directional: int,
        next_common: int,
        next_directional: int,
    ) -> "ReciprocalHistoryLift":
        if any(
            type(value) is not int
            for value in (
                prior_common,
                prior_directional,
                next_common,
                next_directional,
            )
        ):
            raise TypeError("reciprocal history coordinates must be integers")
        left_raw = [0] * 81
        right_raw = [0] * 81
        left_raw[:4] = [
            prior_common,
            prior_directional,
            next_common,
            next_directional,
        ]
        right_raw[:4] = [
            -prior_common,
            -prior_directional,
            next_common,
            next_directional,
        ]
        left = tuple(Fraction(value) for value in left_raw)
        right = tuple(Fraction(value) for value in right_raw)
        symmetric = tuple(a + b for a, b in zip(left, right))
        antisymmetric = tuple(a - b for a, b in zip(left, right))
        quotient, anchor = adapter.history_quotient(left, right)
        reconstructed = quotient.reconstruct(anchor)
        return cls(
            prior_common,
            prior_directional,
            next_common,
            next_directional,
            left,
            right,
            symmetric,
            antisymmetric,
            tuple(quotient.coordinates),
            anchor,
            reconstructed == (left, right),
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_RECIPROCAL_HISTORY_LIFT_V6",
            "source": {
                "prior_common": self.prior_common,
                "prior_directional": self.prior_directional,
                "next_common": self.next_common,
                "next_directional": self.next_directional,
            },
            "coordinate_counts": {
                "left": len(self.left),
                "right": len(self.right),
                "symmetric": len(self.symmetric),
                "antisymmetric": len(self.antisymmetric),
                "quotient": len(self.quotient_coordinates),
                "common_anchor": 1,
            },
            "symmetric_first_four": [str(value) for value in self.symmetric[:4]],
            "antisymmetric_first_four": [str(value) for value in self.antisymmetric[:4]],
            "common_next_state_is_symmetric": (
                self.symmetric[:4]
                == (
                    Fraction(0),
                    Fraction(0),
                    Fraction(2 * self.next_common),
                    Fraction(2 * self.next_directional),
                )
            ),
            "incoming_reciprocal_distinction_is_antisymmetric": (
                self.antisymmetric[:4]
                == (
                    Fraction(2 * self.prior_common),
                    Fraction(2 * self.prior_directional),
                    Fraction(0),
                    Fraction(0),
                )
            ),
            "quotient_plus_anchor_reconstructs": self.reconstructs,
        }


def census_moduli(moduli: Iterable[int]) -> tuple[ReciprocalFiberCensus, ...]:
    return tuple(census_reciprocal_map(modulus) for modulus in moduli)


__all__ = (
    "ReciprocalFiberCensus",
    "ReciprocalHistoryLift",
    "ReciprocalOrbit",
    "census_moduli",
    "census_reciprocal_map",
    "reciprocal_involution",
    "reciprocal_receipt_system",
    "reciprocal_visible_map",
)
