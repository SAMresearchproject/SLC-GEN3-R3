"""Typed roster identities, hierarchical receipts, and reset records."""

from __future__ import annotations

import hashlib
import json
from dataclasses import asdict, dataclass, field
from decimal import Decimal, getcontext
from fractions import Fraction
from typing import Iterable

from .exact import SymbolicEntropy, entropy_from_probabilities, support_weight


getcontext().prec = 50
K_B_EXACT_SI = Decimal("1.380649e-23")


def _semantic_hash(payload: object) -> str:
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _container_bits(cardinality: int) -> int:
    value = int(cardinality)
    if value < 1:
        raise ValueError("container alphabet must be nonempty")
    return (value - 1).bit_length()


@dataclass(frozen=True, slots=True)
class ProgramRoster:
    """One declared context C and its ordered local map rho_C(j)."""

    name: str
    power: int
    programs: tuple[int, ...]
    weights: tuple[int, ...]
    mapping_id: str = field(init=False)
    roster_id: str = field(init=False)

    def __post_init__(self) -> None:
        name = str(self.name)
        power = int(self.power)
        programs = tuple(int(program) for program in self.programs)
        weights = tuple(int(weight) for weight in self.weights)
        if not name:
            raise ValueError("roster name cannot be empty")
        if power < 1:
            raise ValueError("Z4 power must be positive")
        if not programs:
            raise ValueError("program roster cannot be empty")
        if len(programs) != len(weights):
            raise ValueError("every local program requires one selection weight")
        if len(set(programs)) != len(programs):
            raise ValueError("program roster contains duplicate addresses")
        if min(programs) < 0 or max(programs) >= 4**power:
            raise ValueError("program address is outside Z4^power")
        if any(weight <= 0 for weight in weights):
            raise ValueError("program selection weights must be positive integers")
        object.__setattr__(self, "name", name)
        object.__setattr__(self, "power", power)
        object.__setattr__(self, "programs", programs)
        object.__setattr__(self, "weights", weights)
        mapping_payload = {
            "schema": "SLC_PROGRAM_ROSTER_MAPPING_V3",
            "power": power,
            "programs_in_local_index_order": programs,
        }
        mapping_id = _semantic_hash(mapping_payload)
        object.__setattr__(self, "mapping_id", mapping_id)
        object.__setattr__(self, "roster_id", _semantic_hash({
            "schema": "SLC_PROGRAM_ROSTER_CONTEXT_V3",
            "name": name,
            "mapping_id": mapping_id,
            "selection_weights": weights,
        }))

    @property
    def size(self) -> int:
        return len(self.programs)

    @property
    def probabilities(self) -> tuple[Fraction, ...]:
        total = sum(self.weights)
        return tuple(Fraction(weight, total) for weight in self.weights)

    @property
    def entropy(self) -> SymbolicEntropy:
        return entropy_from_probabilities(self.probabilities)

    def program(self, local_index: int) -> int:
        index = int(local_index)
        if not 0 <= index < self.size:
            raise ValueError("local program index is outside rho_C")
        return self.programs[index]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_PROGRAM_ROSTER_CONTEXT_V3",
            "name": self.name,
            "power": self.power,
            "roster_id": self.roster_id,
            "mapping_id": self.mapping_id,
            "programs_in_local_index_order": list(self.programs),
            "selection_weights": list(self.weights),
            "selection_probabilities": [str(value) for value in self.probabilities],
            "support_cardinality": self.size,
            "support_weight": support_weight(self.size),
            "shannon_entropy": self.entropy.to_dict(),
            "roster_local_container_bits": _container_bits(self.size),
        }


class RosterCatalog:
    """Conditioned-known decoder catalog for dynamic roster identity C."""

    def __init__(
        self,
        name: str,
        rosters: Iterable[ProgramRoster],
        selection_weights: Iterable[int],
    ) -> None:
        self.name = str(name)
        self.rosters = tuple(rosters)
        self.selection_weights = tuple(int(weight) for weight in selection_weights)
        if not self.name:
            raise ValueError("catalog name cannot be empty")
        if not self.rosters:
            raise ValueError("roster catalog cannot be empty")
        if len(self.rosters) != len(self.selection_weights):
            raise ValueError("every roster requires one catalog selection weight")
        if any(weight <= 0 for weight in self.selection_weights):
            raise ValueError("catalog selection weights must be positive integers")
        powers = {roster.power for roster in self.rosters}
        if len(powers) != 1:
            raise ValueError("all catalog rosters must use the same Z4 power")
        if len({roster.roster_id for roster in self.rosters}) != len(self.rosters):
            raise ValueError("catalog contains duplicate roster identities")
        self.power = next(iter(powers))
        self.catalog_id = _semantic_hash({
            "schema": "SLC_PROGRAM_ROSTER_CATALOG_V3",
            "name": self.name,
            "power": self.power,
            "roster_ids_in_index_order": [roster.roster_id for roster in self.rosters],
            "selection_weights": self.selection_weights,
        })
        offsets: list[int] = []
        running = 0
        for roster in self.rosters:
            offsets.append(running)
            running += roster.size
        self.flat_offsets = tuple(offsets)
        self.pair_count = running

    @property
    def size(self) -> int:
        return len(self.rosters)

    @property
    def probabilities(self) -> tuple[Fraction, ...]:
        total = sum(self.selection_weights)
        return tuple(Fraction(weight, total) for weight in self.selection_weights)

    @property
    def entropy(self) -> SymbolicEntropy:
        return entropy_from_probabilities(self.probabilities)

    @property
    def roster_receipt_bits(self) -> int:
        return _container_bits(self.size)

    @property
    def local_receipt_bits(self) -> int:
        return _container_bits(max(roster.size for roster in self.rosters))

    @property
    def pair_receipt_bits(self) -> int:
        return self.roster_receipt_bits + self.local_receipt_bits

    @property
    def flat_receipt_bits(self) -> int:
        return _container_bits(self.pair_count)

    def roster(self, roster_index: int) -> ProgramRoster:
        index = int(roster_index)
        if not 0 <= index < self.size:
            raise ValueError("roster index is outside the conditioned catalog")
        return self.rosters[index]

    def flat_index(self, roster_index: int, local_index: int) -> int:
        roster = self.roster(roster_index)
        roster.program(local_index)
        return self.flat_offsets[roster_index] + int(local_index)

    def unflatten(self, flat_index: int) -> tuple[int, int]:
        value = int(flat_index)
        if not 0 <= value < self.pair_count:
            raise ValueError("flat hierarchy index is outside the catalog")
        for roster_index in range(self.size - 1, -1, -1):
            offset = self.flat_offsets[roster_index]
            if value >= offset:
                return roster_index, value - offset
        raise AssertionError("unreachable flat-index branch")

    def control_atoms(self) -> tuple[tuple[int, int, int, Fraction], ...]:
        atoms: list[tuple[int, int, int, Fraction]] = []
        for roster_index, (roster, roster_probability) in enumerate(
            zip(self.rosters, self.probabilities)
        ):
            for local_index, (program, local_probability) in enumerate(
                zip(roster.programs, roster.probabilities)
            ):
                atoms.append((
                    roster_index,
                    local_index,
                    program,
                    roster_probability * local_probability,
                ))
        if sum((atom[3] for atom in atoms), Fraction()) != 1:
            raise AssertionError("catalog control probabilities do not sum to one")
        return tuple(atoms)

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": "SLC_PROGRAM_ROSTER_CATALOG_V3",
            "name": self.name,
            "power": self.power,
            "catalog_id": self.catalog_id,
            "conditioned_known_for_decoding": True,
            "roster_count": self.size,
            "roster_ids_in_index_order": [roster.roster_id for roster in self.rosters],
            "roster_selection_weights": list(self.selection_weights),
            "roster_selection_probabilities": [str(value) for value in self.probabilities],
            "roster_support_weight": support_weight(self.size),
            "roster_selection_entropy": self.entropy.to_dict(),
            "hierarchy_pair_count": self.pair_count,
            "hierarchy_pair_support_weight": support_weight(self.pair_count),
            "roster_receipt_container_bits": self.roster_receipt_bits,
            "local_receipt_fixed_container_bits": self.local_receipt_bits,
            "pair_receipt_container_bits": self.pair_receipt_bits,
            "direct_flat_container_bits": self.flat_receipt_bits,
            "direct_flat_container_savings": self.pair_receipt_bits - self.flat_receipt_bits,
            "rosters": [roster.to_dict() for roster in self.rosters],
        }


@dataclass(frozen=True, slots=True)
class RosterIdentityReceipt:
    schema: str
    action_id: str
    catalog_id: str
    roster_index: int
    container_bits: int

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class RosterLocalProgramReceipt:
    schema: str
    action_id: str
    catalog_id: str
    local_index: int
    fixed_container_bits: int

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class HierarchicalProgramReceipt:
    schema: str
    roster_identity: RosterIdentityReceipt
    roster_local_program: RosterLocalProgramReceipt

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.schema,
            "roster_identity": self.roster_identity.to_dict(),
            "roster_local_program": self.roster_local_program.to_dict(),
        }


@dataclass(frozen=True, slots=True)
class RosterObservationContract:
    schema: str
    name: str
    reconstruction_target: str
    input_state: tuple[str, ...]
    conditioned_known: tuple[str, ...]
    visible_after: tuple[str, ...]
    retained_receipts: tuple[str, ...]
    reset_variables: tuple[str, ...]

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


@dataclass(frozen=True, slots=True)
class HierarchyResetRecord:
    schema: str
    action_id: str
    reset_components: tuple[str, ...]
    support_upper_bound: int
    support_weight: dict[str, object]
    erased_information: dict[str, object]
    physical_reset_declared: bool
    temperature_kelvin: str | None
    landauer_lower_bound_exact_joules: str | None
    landauer_lower_bound_joules: str | None

    def to_dict(self) -> dict[str, object]:
        return asdict(self)


def declare_hierarchy_reset(
    action_id: str,
    reset_components: tuple[str, ...],
    erased_entropy: SymbolicEntropy,
    support_upper_bound: int,
    *,
    physical_reset_declared: bool = False,
    temperature_kelvin: int | str | Decimal | None = None,
) -> HierarchyResetRecord:
    """Declare last-copy reset with exact Shannon and support accounting."""

    if not reset_components:
        raise ValueError("hierarchical reset must name at least one receipt component")
    temperature_text: str | None = None
    exact_joules: str | None = None
    evaluated_joules: str | None = None
    if temperature_kelvin is not None:
        temperature = Decimal(str(temperature_kelvin))
        if temperature < 0:
            raise ValueError("temperature cannot be negative")
        temperature_text = str(temperature)
    else:
        temperature = None
    if physical_reset_declared:
        if temperature is None:
            raise ValueError("a physical reset requires temperature")
        exact_joules = f"k_B*{temperature_text}*({erased_entropy.expression})"
        evaluated_joules = str(
            K_B_EXACT_SI
            * temperature
            * Decimal(str(erased_entropy.nats))
        )
    return HierarchyResetRecord(
        schema="SLC_ROSTER_HIERARCHY_RESET_RECORD_V3",
        action_id=action_id,
        reset_components=reset_components,
        support_upper_bound=int(support_upper_bound),
        support_weight=support_weight(int(support_upper_bound)),
        erased_information=erased_entropy.to_dict(),
        physical_reset_declared=physical_reset_declared,
        temperature_kelvin=temperature_text,
        landauer_lower_bound_exact_joules=exact_joules,
        landauer_lower_bound_joules=evaluated_joules,
    )
