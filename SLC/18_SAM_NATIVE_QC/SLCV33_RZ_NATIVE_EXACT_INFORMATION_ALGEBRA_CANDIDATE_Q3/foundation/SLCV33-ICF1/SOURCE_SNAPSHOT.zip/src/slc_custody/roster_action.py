"""Roster-native Z4 translations with hierarchical receipt custody."""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from fractions import Fraction
from typing import Iterable


from .control import pack_z4, unpack_z4

from .exact import (
    Atom,
    SymbolicEntropy,
    conditional_entropy_of,
    entropy_of,
    expected_log_support,
    normalized_distribution,
    projected_distribution,
    support_weight,
)
from .roster import (
    HierarchicalProgramReceipt,
    HierarchyResetRecord,
    RosterCatalog,
    RosterIdentityReceipt,
    RosterLocalProgramReceipt,
    RosterObservationContract,
    declare_hierarchy_reset,
)


ROSTER_RECEIPT = "R_C"
LOCAL_RECEIPT = "R_P_GIVEN_C"
ALL_RECEIPTS = frozenset((ROSTER_RECEIPT, LOCAL_RECEIPT))


@dataclass(frozen=True, slots=True)
class RosterCustodyState:
    visible: int
    receipt: HierarchicalProgramReceipt


@dataclass(frozen=True, slots=True)
class FlatHierarchyReceipt:
    schema: str
    action_id: str
    catalog_id: str
    flat_index: int
    container_bits: int

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.schema,
            "action_id": self.action_id,
            "catalog_id": self.catalog_id,
            "flat_index": self.flat_index,
            "container_bits": self.container_bits,
        }


@dataclass(frozen=True, slots=True)
class RosterInformationProfile:
    schema: str
    scope: str
    source_support_count: int
    visible_output_count: int
    atom_count: int
    full_uniform_translation_symmetry: bool
    entropies: dict[str, SymbolicEntropy]
    support_counts: dict[str, int]
    expected_support_weights: dict[str, SymbolicEntropy]
    chain_rule_checks: dict[str, bool]

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.schema,
            "scope": self.scope,
            "source_support_count": self.source_support_count,
            "visible_output_count": self.visible_output_count,
            "atom_count": self.atom_count,
            "full_uniform_translation_symmetry": self.full_uniform_translation_symmetry,
            "entropies": {
                name: entropy.to_dict() for name, entropy in self.entropies.items()
            },
            "support_counts": self.support_counts,
            "support_weights": {
                name: support_weight(count)
                for name, count in self.support_counts.items()
            },
            "expected_support_weights": {
                name: weight.to_dict()
                for name, weight in self.expected_support_weights.items()
            },
            "chain_rule_checks": self.chain_rule_checks,
            "status": "PASS" if all(self.chain_rule_checks.values()) else "FAIL",
        }


@dataclass(frozen=True, slots=True)
class RosterObservation:
    schema: str
    contract: RosterObservationContract
    hidden_before_receipts: SymbolicEntropy
    retained_receipt_custody: SymbolicEntropy
    remaining_hidden_after_retained_receipts: SymbolicEntropy
    logical_erasure: SymbolicEntropy
    reset_record: HierarchyResetRecord | None

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": self.schema,
            "contract": self.contract.to_dict(),
            "hidden_before_receipts": self.hidden_before_receipts.to_dict(),
            "retained_receipt_custody": self.retained_receipt_custody.to_dict(),
            "remaining_hidden_after_retained_receipts": (
                self.remaining_hidden_after_retained_receipts.to_dict()
            ),
            "logical_erasure": self.logical_erasure.to_dict(),
            "reset_record": (
                None if self.reset_record is None else self.reset_record.to_dict()
            ),
        }


class RosterNativeZ4Translation:
    """Execute Y=X+rho_C(j) with R=(R_C,R_{P|C})."""

    def __init__(self, catalog: RosterCatalog) -> None:
        self.catalog = catalog
        self.power = catalog.power
        self.size = 4**self.power
        digest = hashlib.sha256()
        digest.update(b"SLC_ROSTER_NATIVE_Z4_TRANSLATION_V3\0")
        digest.update(self.catalog.catalog_id.encode("ascii"))
        self.action_id = digest.hexdigest()

    def translate(self, data_address: int, program_address: int) -> int:
        data = unpack_z4(data_address, self.power)
        program = unpack_z4(program_address, self.power)
        return pack_z4((x + p) % 4 for x, p in zip(data, program))

    def inverse(self, visible_address: int, program_address: int) -> int:
        visible = unpack_z4(visible_address, self.power)
        program = unpack_z4(program_address, self.power)
        return pack_z4((y - p) % 4 for y, p in zip(visible, program))

    def execute(
        self,
        data_address: int,
        roster_index: int,
        local_index: int,
    ) -> RosterCustodyState:
        roster = self.catalog.roster(roster_index)
        program = roster.program(local_index)
        visible = self.translate(data_address, program)
        receipt = HierarchicalProgramReceipt(
            schema="SLC_ROSTER_HIERARCHICAL_PROGRAM_RECEIPT_V3",
            roster_identity=RosterIdentityReceipt(
                schema="SLC_ROSTER_IDENTITY_RECEIPT_V3",
                action_id=self.action_id,
                catalog_id=self.catalog.catalog_id,
                roster_index=int(roster_index),
                container_bits=self.catalog.roster_receipt_bits,
            ),
            roster_local_program=RosterLocalProgramReceipt(
                schema="SLC_ROSTER_LOCAL_PROGRAM_RECEIPT_V3",
                action_id=self.action_id,
                catalog_id=self.catalog.catalog_id,
                local_index=int(local_index),
                fixed_container_bits=self.catalog.local_receipt_bits,
            ),
        )
        return RosterCustodyState(visible=visible, receipt=receipt)

    def reconstruct(
        self,
        visible_address: int,
        receipt: HierarchicalProgramReceipt,
    ) -> tuple[int, int, int, int]:
        roster_receipt = receipt.roster_identity
        local_receipt = receipt.roster_local_program
        for component in (roster_receipt, local_receipt):
            if component.action_id != self.action_id:
                raise ValueError("receipt component belongs to a different action")
            if component.catalog_id != self.catalog.catalog_id:
                raise ValueError("receipt component belongs to a different catalog")
        roster_index = roster_receipt.roster_index
        local_index = local_receipt.local_index
        roster = self.catalog.roster(roster_index)
        program = roster.program(local_index)
        data = self.inverse(visible_address, program)
        return data, roster_index, local_index, program

    def flatten_receipt(self, receipt: HierarchicalProgramReceipt) -> FlatHierarchyReceipt:
        roster_index = receipt.roster_identity.roster_index
        local_index = receipt.roster_local_program.local_index
        self.catalog.roster(roster_index).program(local_index)
        return FlatHierarchyReceipt(
            schema="SLC_FLAT_SERIALIZED_HIERARCHY_RECEIPT_V3",
            action_id=self.action_id,
            catalog_id=self.catalog.catalog_id,
            flat_index=self.catalog.flat_index(roster_index, local_index),
            container_bits=self.catalog.flat_receipt_bits,
        )

    def expand_flat_receipt(self, receipt: FlatHierarchyReceipt) -> HierarchicalProgramReceipt:
        if receipt.action_id != self.action_id:
            raise ValueError("flat receipt belongs to a different action")
        if receipt.catalog_id != self.catalog.catalog_id:
            raise ValueError("flat receipt belongs to a different catalog")
        roster_index, local_index = self.catalog.unflatten(receipt.flat_index)
        return self.execute(0, roster_index, local_index).receipt

    def _conditional_control_atoms(self) -> tuple[Atom, ...]:
        """Represent the exact control distribution conditional on any full-space Y."""

        atoms: list[Atom] = []
        for roster_index, local_index, program, probability in self.catalog.control_atoms():
            atoms.append(({
                "x": self.inverse(0, program),
                "c": roster_index,
                "j": local_index,
                "p": program,
                "y": 0,
            }, probability))
        return tuple(atoms)

    def profile_full_uniform_data(self) -> RosterInformationProfile:
        """Profile every output using translation invariance of uniform Z4^n data."""

        atoms = self._conditional_control_atoms()
        return self._profile_from_atoms(
            atoms,
            scope="FULL_UNIFORM_Z4_POWER_DATA",
            source_support_count=self.size,
            visible_output_count=self.size,
            atom_count=self.size * self.catalog.pair_count,
            full_uniform_translation_symmetry=True,
        )

    def profile_restricted_data(
        self,
        data_support: Iterable[int],
        data_weights: Iterable[int],
        *,
        scope: str = "RESTRICTED_SOURCE_DATA",
    ) -> RosterInformationProfile:
        frozen_support = tuple(data_support)
        frozen_weights = tuple(data_weights)
        if len(frozen_support) != len(frozen_weights):
            raise ValueError("every restricted data state requires one weight")
        weighted_data = tuple(zip(frozen_support, frozen_weights))
        data_distribution = normalized_distribution(weighted_data)
        for data in data_distribution:
            unpack_z4(int(data), self.power)
        atoms: list[Atom] = []
        for data, data_probability in data_distribution.items():
            for roster_index, local_index, program, control_probability in self.catalog.control_atoms():
                atoms.append(({
                    "x": int(data),
                    "c": roster_index,
                    "j": local_index,
                    "p": program,
                    "y": self.translate(int(data), program),
                }, data_probability * control_probability))
        visible_count = len(projected_distribution(atoms, ("y",)))
        return self._profile_from_atoms(
            tuple(atoms),
            scope=scope,
            source_support_count=len(data_distribution),
            visible_output_count=visible_count,
            atom_count=len(atoms),
            full_uniform_translation_symmetry=False,
        )

    def _profile_from_atoms(
        self,
        atoms: tuple[Atom, ...],
        *,
        scope: str,
        source_support_count: int,
        visible_output_count: int,
        atom_count: int,
        full_uniform_translation_symmetry: bool,
    ) -> RosterInformationProfile:
        h_cj_y = conditional_entropy_of(atoms, ("c", "j"), ("y",))
        h_c_y = conditional_entropy_of(atoms, ("c",), ("y",))
        h_j_y = conditional_entropy_of(atoms, ("j",), ("y",))
        h_j_yc = conditional_entropy_of(atoms, ("j",), ("y", "c"))
        h_c_yj = conditional_entropy_of(atoms, ("c",), ("y", "j"))
        entropies = {
            "roster_identity_given_visible": h_c_y,
            "local_index_given_visible": h_j_y,
            "local_index_given_visible_and_roster": h_j_yc,
            "roster_identity_given_visible_and_local_index": h_c_yj,
            "exact_hierarchy_given_visible": h_cj_y,
            "program_action_given_visible": conditional_entropy_of(
                atoms, ("p",), ("y",)
            ),
            "data_state_given_visible": conditional_entropy_of(
                atoms, ("x",), ("y",)
            ),
            "exact_hierarchy_given_visible_and_program_action": conditional_entropy_of(
                atoms, ("c", "j"), ("y", "p")
            ),
            "data_state_given_visible_and_exact_hierarchy": conditional_entropy_of(
                atoms, ("x",), ("y", "c", "j")
            ),
            "roster_selection_unconditioned": entropy_of(atoms, ("c",)),
            "local_index_given_roster_unconditioned": conditional_entropy_of(
                atoms, ("j",), ("c",)
            ),
            "exact_hierarchy_unconditioned": entropy_of(atoms, ("c", "j")),
            "program_action_unconditioned": entropy_of(atoms, ("p",)),
        }

        hierarchy_by_y: dict[object, set[tuple[object, object]]] = {}
        programs_by_y: dict[object, set[object]] = {}
        data_by_y: dict[object, set[object]] = {}
        roster_by_yj: dict[tuple[object, object], set[object]] = {}
        local_by_yc: dict[tuple[object, object], set[object]] = {}
        for values, _probability in atoms:
            y = values["y"]
            hierarchy_by_y.setdefault(y, set()).add((values["c"], values["j"]))
            programs_by_y.setdefault(y, set()).add(values["p"])
            data_by_y.setdefault(y, set()).add(values["x"])
            roster_by_yj.setdefault((y, values["j"]), set()).add(values["c"])
            local_by_yc.setdefault((y, values["c"]), set()).add(values["j"])
        support_counts = {
            "max_exact_hierarchy_per_visible": max(map(len, hierarchy_by_y.values())),
            "max_program_actions_per_visible": max(map(len, programs_by_y.values())),
            "max_data_states_per_visible": max(map(len, data_by_y.values())),
            "max_rosters_per_visible_and_local_index": max(map(len, roster_by_yj.values())),
            "max_local_indices_per_visible_and_roster": max(map(len, local_by_yc.values())),
        }
        expected_support_weights = {
            "exact_hierarchy_given_visible": expected_log_support(
                atoms, ("c", "j"), ("y",)
            ),
            "program_action_given_visible": expected_log_support(
                atoms, ("p",), ("y",)
            ),
            "data_state_given_visible": expected_log_support(
                atoms, ("x",), ("y",)
            ),
            "roster_identity_given_visible_and_local_index": expected_log_support(
                atoms, ("c",), ("y", "j")
            ),
            "local_index_given_visible_and_roster": expected_log_support(
                atoms, ("j",), ("y", "c")
            ),
        }
        zero = SymbolicEntropy()
        checks = {
            "chain_roster_then_local": h_cj_y == h_c_y + h_j_yc,
            "chain_local_then_roster": h_cj_y == h_j_y + h_c_yj,
            "exact_hierarchy_reconstructs_data": (
                entropies["data_state_given_visible_and_exact_hierarchy"] == zero
            ),
            "program_action_is_hierarchy_quotient": (
                (h_cj_y - entropies["program_action_given_visible"]).sign() >= 0
            ),
            "shannon_not_above_expected_hartley": all(
                (expected_support_weights[name] - entropies[name]).sign() >= 0
                for name in expected_support_weights
            ),
        }
        return RosterInformationProfile(
            schema="SLC_ROSTER_INFORMATION_PROFILE_V3",
            scope=scope,
            source_support_count=source_support_count,
            visible_output_count=visible_output_count,
            atom_count=atom_count,
            full_uniform_translation_symmetry=full_uniform_translation_symmetry,
            entropies=entropies,
            support_counts=support_counts,
            expected_support_weights=expected_support_weights,
            chain_rule_checks=checks,
        )

    def observe_exact_hierarchy(
        self,
        profile: RosterInformationProfile,
        *,
        name: str,
        retained_receipts: tuple[str, ...],
        reset_variables: tuple[str, ...] = (),
        physical_reset_declared: bool = False,
        temperature_kelvin: int | str | None = None,
    ) -> RosterObservation:
        retained = frozenset(retained_receipts)
        reset = frozenset(reset_variables)
        if not retained <= ALL_RECEIPTS or not reset <= ALL_RECEIPTS:
            raise ValueError("unknown roster receipt channel")
        if retained & reset:
            raise ValueError("a receipt channel cannot be retained and reset")
        if retained | reset != ALL_RECEIPTS:
            raise ValueError("each hierarchy receipt must be retained or explicitly reset")

        total = profile.entropies["exact_hierarchy_given_visible"]
        if retained == ALL_RECEIPTS:
            residual = SymbolicEntropy()
            support_bound = 1
        elif retained == frozenset((ROSTER_RECEIPT,)):
            residual = profile.entropies["local_index_given_visible_and_roster"]
            support_bound = profile.support_counts[
                "max_local_indices_per_visible_and_roster"
            ]
        elif retained == frozenset((LOCAL_RECEIPT,)):
            residual = profile.entropies[
                "roster_identity_given_visible_and_local_index"
            ]
            support_bound = profile.support_counts[
                "max_rosters_per_visible_and_local_index"
            ]
        else:
            residual = total
            support_bound = profile.support_counts[
                "max_exact_hierarchy_per_visible"
            ]
        custody = total - residual
        erasure = residual if reset else SymbolicEntropy()
        reset_record = None
        if reset:
            reset_record = declare_hierarchy_reset(
                self.action_id,
                tuple(sorted(reset)),
                erasure,
                support_bound,
                physical_reset_declared=physical_reset_declared,
                temperature_kelvin=temperature_kelvin,
            )
        contract = RosterObservationContract(
            schema="SLC_ROSTER_OBSERVATION_CONTRACT_V3",
            name=name,
            reconstruction_target="EXACT_ROSTER_AND_LOCAL_PROGRAM_HIERARCHY",
            input_state=("X", "C", "J", "P=rho_C(J)"),
            conditioned_known=(f"ROSTER_CATALOG:{self.catalog.catalog_id}",),
            visible_after=("Y",),
            retained_receipts=tuple(sorted(retained)),
            reset_variables=tuple(sorted(reset)),
        )
        return RosterObservation(
            schema="SLC_ROSTER_OBSERVATION_V3",
            contract=contract,
            hidden_before_receipts=total,
            retained_receipt_custody=custody,
            remaining_hidden_after_retained_receipts=residual,
            logical_erasure=erasure,
            reset_record=reset_record,
        )

    def audit_full_action(self) -> dict[str, object]:
        """Execute every data/hierarchy pair in the bounded catalog."""

        failures: list[dict[str, int]] = []
        executed = 0
        receipt_pairs: set[tuple[int, int]] = set()
        flat_indices: set[int] = set()
        programs: set[int] = set()
        for roster_index, roster in enumerate(self.catalog.rosters):
            for local_index, program in enumerate(roster.programs):
                programs.add(program)
                sample = self.execute(0, roster_index, local_index)
                flat = self.flatten_receipt(sample.receipt)
                expanded = self.expand_flat_receipt(flat)
                receipt_pairs.add((
                    expanded.roster_identity.roster_index,
                    expanded.roster_local_program.local_index,
                ))
                flat_indices.add(flat.flat_index)
                for data in range(self.size):
                    state = self.execute(data, roster_index, local_index)
                    reconstructed = self.reconstruct(state.visible, state.receipt)
                    executed += 1
                    if reconstructed != (data, roster_index, local_index, program):
                        if len(failures) < 16:
                            failures.append({
                                "data": data,
                                "roster_index": roster_index,
                                "local_index": local_index,
                                "program": program,
                            })
        local_fields = set(RosterLocalProgramReceipt.__dataclass_fields__)
        checks = {
            "all_hierarchy_states_reconstruct": not failures,
            "receipt_pair_alphabet_complete": len(receipt_pairs) == self.catalog.pair_count,
            "flat_alphabet_complete": flat_indices == set(range(self.catalog.pair_count)),
            "duplicate_program_quotient_present": len(programs) < self.catalog.pair_count,
            "local_receipt_omits_roster_identity": "roster_index" not in local_fields and "roster_id" not in local_fields,
            "local_receipt_omits_program_address": "program_address" not in local_fields and "control_address" not in local_fields,
            "direct_flat_serialization_saves_container_bits": self.catalog.flat_receipt_bits < self.catalog.pair_receipt_bits,
        }
        return {
            "schema": "SLC_ROSTER_NATIVE_FULL_ACTION_AUDIT_V3",
            "address_count": self.size,
            "roster_count": self.catalog.size,
            "hierarchy_pair_count": self.catalog.pair_count,
            "unique_program_action_count": len(programs),
            "executed_data_hierarchy_states": executed,
            "expected_data_hierarchy_states": self.size * self.catalog.pair_count,
            "failure_examples": failures,
            "checks": checks,
            "checks_passed": sum(checks.values()),
            "checks_failed": sum(not value for value in checks.values()),
            "status": "PASS" if all(checks.values()) else "FAIL",
        }
