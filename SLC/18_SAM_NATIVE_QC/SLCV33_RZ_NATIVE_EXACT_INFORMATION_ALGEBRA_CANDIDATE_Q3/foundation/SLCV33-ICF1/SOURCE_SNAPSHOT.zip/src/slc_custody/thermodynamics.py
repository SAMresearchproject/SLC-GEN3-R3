"""Typed logical-reset and optional Landauer-calibration boundary.

Logical information destruction is an exact finite-source statement.  A
physical temperature calibration is a separate object, and the resulting
Landauer value is an ideal lower-bound receipt rather than a claim of realized
heat.  Binary floating point is prohibited throughout this module.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from typing import Any, Iterable, Mapping

from .hd import FormalLogElement
from .information import ExactDistribution, ReceiptSystem


LOGICAL_RESET_SCHEMA = "SLC_LOGICAL_RESET_EVENT_V6"
PHYSICAL_CALIBRATION_SCHEMA = "SLC_PHYSICAL_RESET_CALIBRATION_V6"
LANDAUER_RECEIPT_SCHEMA = "SLC_LANDAUER_LOWER_BOUND_RECEIPT_V6"


class ThermodynamicsContractError(ValueError):
    """A logical-reset or physical-calibration contract is inconsistent."""


def _strict_int(value: Any, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ThermodynamicsContractError(f"{label} must be an integer")
    return value


def _exact_fraction(value: Fraction | int, label: str) -> Fraction:
    if isinstance(value, bool) or not isinstance(value, (Fraction, int)):
        raise ThermodynamicsContractError(
            f"{label} must be an exact Fraction or integer"
        )
    return value if isinstance(value, Fraction) else Fraction(value)


def _fraction_dict(value: Fraction) -> dict[str, int]:
    return {"denominator": value.denominator, "numerator": value.numerator}


def _fraction_from_dict(value: Any, label: str) -> Fraction:
    if not isinstance(value, Mapping) or set(value) != {"numerator", "denominator"}:
        raise ThermodynamicsContractError(
            f"{label} must contain numerator and denominator"
        )
    numerator = _strict_int(value["numerator"], f"{label}.numerator")
    denominator = _strict_int(value["denominator"], f"{label}.denominator")
    if denominator <= 0:
        raise ThermodynamicsContractError(f"{label}.denominator must be positive")
    result = Fraction(numerator, denominator)
    if result.numerator != numerator or result.denominator != denominator:
        raise ThermodynamicsContractError(f"{label} must be reduced and canonical")
    return result


def _temperature_text(value: Fraction) -> str:
    return (
        str(value.numerator)
        if value.denominator == 1
        else f"({value.numerator}/{value.denominator})"
    )


def _strict_bool(value: Any, label: str) -> bool:
    if not isinstance(value, bool):
        raise ThermodynamicsContractError(f"{label} must be a boolean")
    return value


def _canonical_channels(channels: Iterable[str], label: str) -> tuple[str, ...]:
    raw = tuple(channels)
    if any(not isinstance(channel, str) or not channel for channel in raw):
        raise ThermodynamicsContractError(f"{label} must contain nonempty strings")
    if len(set(raw)) != len(raw):
        raise ThermodynamicsContractError(f"{label} contains duplicates")
    return tuple(sorted(raw))


def _require_canonical_channels(channels: tuple[str, ...], label: str) -> None:
    if not isinstance(channels, tuple) or channels != _canonical_channels(channels, label):
        raise ThermodynamicsContractError(
            f"{label} must be a sorted duplicate-free tuple"
        )


def _required_text(value: Any, label: str) -> str:
    if not isinstance(value, str) or not value:
        raise ThermodynamicsContractError(f"{label} must be a nonempty string")
    return value


@dataclass(frozen=True, slots=True)
class LogicalResetEvent:
    """Exact result of retaining or irreversibly destroying receipt channels."""

    event_id: str
    event_kind: str
    destroyed_channels: tuple[str, ...]
    retained_channels: tuple[str, ...]
    reconstructs_source_before_event: bool
    reconstructs_source_after_event: bool
    irreversible_destruction_declared: bool
    erased_information: FormalLogElement
    source_law_provenance: str
    computation_basis: str
    visible_partition_id: str | None = None
    initial_augmented_partition_id: str | None = None
    final_augmented_partition_id: str | None = None

    def __post_init__(self) -> None:
        _required_text(self.event_id, "event_id")
        if self.event_kind not in {
            "REVERSIBLE_RECEIPT_RETENTION",
            "IRREVERSIBLE_CHANNEL_DESTRUCTION",
        }:
            raise ThermodynamicsContractError("unknown logical event kind")
        _require_canonical_channels(self.destroyed_channels, "destroyed_channels")
        _require_canonical_channels(self.retained_channels, "retained_channels")
        if set(self.destroyed_channels) & set(self.retained_channels):
            raise ThermodynamicsContractError(
                "a receipt channel cannot be both destroyed and retained"
            )
        _strict_bool(
            self.reconstructs_source_before_event,
            "reconstructs_source_before_event",
        )
        _strict_bool(
            self.reconstructs_source_after_event,
            "reconstructs_source_after_event",
        )
        _strict_bool(
            self.irreversible_destruction_declared,
            "irreversible_destruction_declared",
        )
        if not isinstance(self.erased_information, FormalLogElement):
            raise ThermodynamicsContractError(
                "erased_information must be a FormalLogElement"
            )
        if self.erased_information.sign < 0:
            raise ThermodynamicsContractError("erased information cannot be negative")
        _required_text(self.source_law_provenance, "source_law_provenance")
        if self.computation_basis not in {
            "EXACT_RECEIPT_SYSTEM",
            "DECLARED_UNIFORM_FINITE_SOURCE",
            "EXACT_WRITE_RECONSTRUCTION",
        }:
            raise ThermodynamicsContractError("unknown reset computation basis")
        for value, label in (
            (self.visible_partition_id, "visible_partition_id"),
            (self.initial_augmented_partition_id, "initial_augmented_partition_id"),
            (self.final_augmented_partition_id, "final_augmented_partition_id"),
        ):
            if value is not None:
                _required_text(value, label)

        if self.event_kind == "REVERSIBLE_RECEIPT_RETENTION":
            if self.destroyed_channels:
                raise ThermodynamicsContractError(
                    "reversible retention cannot list destroyed channels"
                )
            if self.irreversible_destruction_declared:
                raise ThermodynamicsContractError(
                    "reversible retention cannot declare irreversible destruction"
                )
            if (
                not self.reconstructs_source_before_event
                or not self.reconstructs_source_after_event
                or not self.erased_information.is_zero
            ):
                raise ThermodynamicsContractError(
                    "reversible retained receipts must reconstruct with zero erasure"
                )
        else:
            if not self.irreversible_destruction_declared:
                raise ThermodynamicsContractError(
                    "channel destruction must be explicitly declared irreversible"
                )
            if not self.destroyed_channels:
                raise ThermodynamicsContractError(
                    "an irreversible destruction event must name destroyed channels"
                )

        if (
            self.reconstructs_source_after_event
            and not self.reconstructs_source_before_event
        ):
            raise ThermodynamicsContractError(
                "destroying channels cannot create source reconstructibility"
            )
        if self.erased_information.sign > 0 and (
            self.reconstructs_source_after_event
            or not self.irreversible_destruction_declared
        ):
            raise ThermodynamicsContractError(
                "positive erasure requires failed reconstruction and declared destruction"
            )

    @classmethod
    def reversible_exact_write(
        cls,
        event_id: str,
        *,
        retained_channels: Iterable[str],
        source_law_provenance: str,
    ) -> "LogicalResetEvent":
        retained = _canonical_channels(retained_channels, "retained_channels")
        if not retained:
            raise ThermodynamicsContractError(
                "Exact Write retention must name its reconstructing receipt channels"
            )
        return cls(
            event_id=event_id,
            event_kind="REVERSIBLE_RECEIPT_RETENTION",
            destroyed_channels=(),
            retained_channels=retained,
            reconstructs_source_before_event=True,
            reconstructs_source_after_event=True,
            irreversible_destruction_declared=False,
            erased_information=FormalLogElement.zero(),
            source_law_provenance=source_law_provenance,
            computation_basis="EXACT_WRITE_RECONSTRUCTION",
        )

    @classmethod
    def uniform_irreversible_destruction(
        cls,
        event_id: str,
        multiplicity: int,
        *,
        destroyed_channels: Iterable[str],
        retained_channels: Iterable[str] = (),
        source_law_provenance: str,
    ) -> "LogicalResetEvent":
        exact_multiplicity = _strict_int(multiplicity, "multiplicity")
        if exact_multiplicity < 2:
            raise ThermodynamicsContractError(
                "irrecoverable uniform multiplicity must be at least two"
            )
        return cls(
            event_id=event_id,
            event_kind="IRREVERSIBLE_CHANNEL_DESTRUCTION",
            destroyed_channels=_canonical_channels(
                destroyed_channels, "destroyed_channels"
            ),
            retained_channels=_canonical_channels(retained_channels, "retained_channels"),
            reconstructs_source_before_event=True,
            reconstructs_source_after_event=False,
            irreversible_destruction_declared=True,
            erased_information=FormalLogElement.from_positive_rational(
                exact_multiplicity
            ),
            source_law_provenance=source_law_provenance,
            computation_basis="DECLARED_UNIFORM_FINITE_SOURCE",
        )

    @classmethod
    def from_receipt_system(
        cls,
        event_id: str,
        receipt_system: ReceiptSystem,
        source_law: ExactDistribution,
        *,
        destroyed_channels: Iterable[str],
        irreversible_destruction_declared: bool,
    ) -> "LogicalResetEvent":
        if not isinstance(receipt_system, ReceiptSystem):
            raise ThermodynamicsContractError("receipt_system has the wrong type")
        if not isinstance(source_law, ExactDistribution):
            raise ThermodynamicsContractError("source_law has the wrong type")
        destroyed = _canonical_channels(destroyed_channels, "destroyed_channels")
        unknown = set(destroyed) - set(receipt_system.channel_names)
        if unknown:
            raise ThermodynamicsContractError(
                f"unknown destroyed receipt channels: {sorted(unknown)}"
            )
        retained = tuple(
            name for name in receipt_system.channel_names if name not in destroyed
        )
        initial_partition = receipt_system.augmented(receipt_system.channel_names)
        final_partition = receipt_system.augmented(retained)
        initial_uncertainty = source_law.conditional_source_entropy(initial_partition)
        final_uncertainty = source_law.conditional_source_entropy(final_partition)
        erased = final_uncertainty - initial_uncertainty
        reconstructs_before = initial_partition.is_discrete
        reconstructs_after = final_partition.is_discrete
        declared = _strict_bool(
            irreversible_destruction_declared,
            "irreversible_destruction_declared",
        )
        if destroyed:
            kind = "IRREVERSIBLE_CHANNEL_DESTRUCTION"
        else:
            kind = "REVERSIBLE_RECEIPT_RETENTION"
        return cls(
            event_id=event_id,
            event_kind=kind,
            destroyed_channels=destroyed,
            retained_channels=retained,
            reconstructs_source_before_event=reconstructs_before,
            reconstructs_source_after_event=reconstructs_after,
            irreversible_destruction_declared=declared,
            erased_information=erased,
            source_law_provenance=source_law.provenance,
            computation_basis="EXACT_RECEIPT_SYSTEM",
            visible_partition_id=receipt_system.visible.mathematical_id,
            initial_augmented_partition_id=initial_partition.mathematical_id,
            final_augmented_partition_id=final_partition.mathematical_id,
        )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "LogicalResetEvent":
        expected = {
            "schema", "event_id", "event_kind", "destroyed_channels",
            "retained_channels", "reconstructs_source_before_event",
            "reconstructs_source_after_event",
            "irreversible_destruction_declared", "erased_information",
            "source_law_provenance", "computation_basis",
            "visible_partition_id", "initial_augmented_partition_id",
            "final_augmented_partition_id",
        }
        if not isinstance(value, Mapping) or set(value) != expected:
            raise ThermodynamicsContractError(
                "logical reset serialization has noncanonical fields"
            )
        if value["schema"] != LOGICAL_RESET_SCHEMA:
            raise ThermodynamicsContractError("unknown logical reset schema")
        if not isinstance(value["destroyed_channels"], list) or not isinstance(
            value["retained_channels"], list
        ):
            raise ThermodynamicsContractError("logical reset channels must be lists")
        return cls(
            event_id=_required_text(value["event_id"], "event_id"),
            event_kind=_required_text(value["event_kind"], "event_kind"),
            destroyed_channels=tuple(value["destroyed_channels"]),
            retained_channels=tuple(value["retained_channels"]),
            reconstructs_source_before_event=_strict_bool(
                value["reconstructs_source_before_event"],
                "reconstructs_source_before_event",
            ),
            reconstructs_source_after_event=_strict_bool(
                value["reconstructs_source_after_event"],
                "reconstructs_source_after_event",
            ),
            irreversible_destruction_declared=_strict_bool(
                value["irreversible_destruction_declared"],
                "irreversible_destruction_declared",
            ),
            erased_information=FormalLogElement.from_dict(
                value["erased_information"]
            ),
            source_law_provenance=_required_text(
                value["source_law_provenance"], "source_law_provenance"
            ),
            computation_basis=_required_text(
                value["computation_basis"], "computation_basis"
            ),
            visible_partition_id=value["visible_partition_id"],
            initial_augmented_partition_id=value["initial_augmented_partition_id"],
            final_augmented_partition_id=value["final_augmented_partition_id"],
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": LOGICAL_RESET_SCHEMA,
            "event_id": self.event_id,
            "event_kind": self.event_kind,
            "destroyed_channels": list(self.destroyed_channels),
            "retained_channels": list(self.retained_channels),
            "reconstructs_source_before_event": self.reconstructs_source_before_event,
            "reconstructs_source_after_event": self.reconstructs_source_after_event,
            "irreversible_destruction_declared": self.irreversible_destruction_declared,
            "erased_information": self.erased_information.to_dict(),
            "source_law_provenance": self.source_law_provenance,
            "computation_basis": self.computation_basis,
            "visible_partition_id": self.visible_partition_id,
            "initial_augmented_partition_id": self.initial_augmented_partition_id,
            "final_augmented_partition_id": self.final_augmented_partition_id,
        }


@dataclass(frozen=True, slots=True)
class PhysicalResetCalibration:
    """Complete declared reset calibration for an ideal bound, not heat evidence."""

    calibration_id: str
    temperature_kelvin: Fraction
    provenance: str
    reservoir_model: str
    temperature_unit: str
    temperature_uncertainty_kelvin: Fraction
    reset_protocol: str
    calibration_source: str
    measured_heat_joules: Fraction | None = None
    measured_heat_uncertainty_joules: Fraction | None = None
    realized_heat_claimed: bool = False

    def __post_init__(self) -> None:
        _required_text(self.calibration_id, "calibration_id")
        if not isinstance(self.temperature_kelvin, Fraction):
            raise ThermodynamicsContractError(
                "temperature_kelvin must be stored as a Fraction"
            )
        if self.temperature_kelvin <= 0:
            raise ThermodynamicsContractError("temperature_kelvin must be positive")
        _required_text(self.provenance, "physical calibration provenance")
        _required_text(self.reservoir_model, "reservoir_model")
        if self.temperature_unit != "K":
            raise ThermodynamicsContractError("temperature_unit must equal 'K'")
        if not isinstance(self.temperature_uncertainty_kelvin, Fraction):
            raise ThermodynamicsContractError(
                "temperature_uncertainty_kelvin must be stored as a Fraction"
            )
        if self.temperature_uncertainty_kelvin < 0:
            raise ThermodynamicsContractError(
                "temperature_uncertainty_kelvin cannot be negative"
            )
        _required_text(self.reset_protocol, "reset_protocol")
        _required_text(self.calibration_source, "calibration_source")
        if (
            self.measured_heat_joules is not None
            or self.measured_heat_uncertainty_joules is not None
        ):
            raise ThermodynamicsContractError(
                "calibration-only records must leave measured heat UNASSIGNED"
            )
        if self.realized_heat_claimed is not False:
            raise ThermodynamicsContractError(
                "a lower-bound calibration cannot claim realized heat"
            )

    @classmethod
    def create(
        cls,
        calibration_id: str,
        *,
        temperature_kelvin: Fraction | int,
        provenance: str,
        reservoir_model: str,
        temperature_uncertainty_kelvin: Fraction | int,
        reset_protocol: str,
        calibration_source: str,
    ) -> "PhysicalResetCalibration":
        return cls(
            calibration_id=calibration_id,
            temperature_kelvin=_exact_fraction(
                temperature_kelvin, "temperature_kelvin"
            ),
            provenance=provenance,
            reservoir_model=reservoir_model,
            temperature_unit="K",
            temperature_uncertainty_kelvin=_exact_fraction(
                temperature_uncertainty_kelvin,
                "temperature_uncertainty_kelvin",
            ),
            reset_protocol=reset_protocol,
            calibration_source=calibration_source,
        )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "PhysicalResetCalibration":
        expected = {
            "schema", "calibration_id", "temperature_kelvin", "provenance",
            "reservoir_model", "temperature_unit",
            "temperature_uncertainty_kelvin", "reset_protocol",
            "calibration_source", "measured_heat_joules",
            "measured_heat_uncertainty_joules", "realized_heat_claimed",
        }
        if not isinstance(value, Mapping) or set(value) != expected:
            raise ThermodynamicsContractError(
                "physical calibration serialization has noncanonical fields"
            )
        if value["schema"] != PHYSICAL_CALIBRATION_SCHEMA:
            raise ThermodynamicsContractError("unknown physical calibration schema")
        return cls(
            calibration_id=_required_text(value["calibration_id"], "calibration_id"),
            temperature_kelvin=_fraction_from_dict(
                value["temperature_kelvin"], "temperature_kelvin"
            ),
            provenance=_required_text(value["provenance"], "provenance"),
            reservoir_model=_required_text(
                value["reservoir_model"], "reservoir_model"
            ),
            temperature_unit=_required_text(
                value["temperature_unit"], "temperature_unit"
            ),
            temperature_uncertainty_kelvin=_fraction_from_dict(
                value["temperature_uncertainty_kelvin"],
                "temperature_uncertainty_kelvin",
            ),
            reset_protocol=_required_text(
                value["reset_protocol"], "reset_protocol"
            ),
            calibration_source=_required_text(
                value["calibration_source"], "calibration_source"
            ),
            measured_heat_joules=value["measured_heat_joules"],
            measured_heat_uncertainty_joules=(
                value["measured_heat_uncertainty_joules"]
            ),
            realized_heat_claimed=_strict_bool(
                value["realized_heat_claimed"], "realized_heat_claimed"
            ),
        )

    @property
    def symbolic_kbt_multiplier(self) -> str:
        return f"k_B*{_temperature_text(self.temperature_kelvin)}"

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": PHYSICAL_CALIBRATION_SCHEMA,
            "calibration_id": self.calibration_id,
            "temperature_kelvin": _fraction_dict(self.temperature_kelvin),
            "provenance": self.provenance,
            "reservoir_model": self.reservoir_model,
            "temperature_unit": self.temperature_unit,
            "temperature_uncertainty_kelvin": _fraction_dict(
                self.temperature_uncertainty_kelvin
            ),
            "reset_protocol": self.reset_protocol,
            "calibration_source": self.calibration_source,
            "measured_heat_joules": None,
            "measured_heat_uncertainty_joules": None,
            "realized_heat_claimed": False,
        }


@dataclass(frozen=True, slots=True)
class LandauerLowerBoundReceipt:
    """Logical erasure plus an optional exact ideal physical lower bound."""

    event_id: str
    erased_information: FormalLogElement
    status: str
    calibration_id: str | None
    calibration_provenance: str | None
    reservoir_model: str | None
    temperature_kelvin: Fraction | None
    temperature_unit: str | None
    temperature_uncertainty_kelvin: Fraction | None
    reset_protocol: str | None
    calibration_source: str | None
    scaled_information: FormalLogElement | None
    exact_lower_bound_joules: str | None
    realized_heat_claimed: bool = False

    def __post_init__(self) -> None:
        _required_text(self.event_id, "event_id")
        if not isinstance(self.erased_information, FormalLogElement):
            raise ThermodynamicsContractError(
                "erased_information must be a FormalLogElement"
            )
        if self.erased_information.sign < 0:
            raise ThermodynamicsContractError("erased information cannot be negative")
        if self.status not in {
            "ZERO_REVERSIBLE_LOWER_BOUND",
            "LOGICAL_ERASURE_PHYSICAL_CALIBRATION_ABSENT",
            "IDEAL_LANDAUER_LOWER_BOUND",
        }:
            raise ThermodynamicsContractError("unknown Landauer receipt status")
        if self.realized_heat_claimed is not False:
            raise ThermodynamicsContractError(
                "Landauer lower-bound receipt cannot claim realized heat"
            )
        if self.status == "ZERO_REVERSIBLE_LOWER_BOUND":
            if not self.erased_information.is_zero or self.exact_lower_bound_joules != "0 J":
                raise ThermodynamicsContractError(
                    "zero reversible receipt must carry exact zero"
                )
            if any(
                value is not None
                for value in (
                    self.calibration_id,
                    self.calibration_provenance,
                    self.reservoir_model,
                    self.temperature_kelvin,
                    self.temperature_unit,
                    self.temperature_uncertainty_kelvin,
                    self.reset_protocol,
                    self.calibration_source,
                    self.scaled_information,
                )
            ):
                raise ThermodynamicsContractError(
                    "zero reversible bound requires no physical calibration"
                )
        elif self.status == "LOGICAL_ERASURE_PHYSICAL_CALIBRATION_ABSENT":
            if self.erased_information.is_zero:
                raise ThermodynamicsContractError(
                    "uncalibrated erasure status requires positive information"
                )
            if any(
                value is not None
                for value in (
                    self.calibration_id,
                    self.calibration_provenance,
                    self.reservoir_model,
                    self.temperature_kelvin,
                    self.temperature_unit,
                    self.temperature_uncertainty_kelvin,
                    self.reset_protocol,
                    self.calibration_source,
                    self.scaled_information,
                    self.exact_lower_bound_joules,
                )
            ):
                raise ThermodynamicsContractError(
                    "uncalibrated receipt cannot contain physical fields"
                )
        else:
            _required_text(self.calibration_id, "calibration_id")
            _required_text(self.calibration_provenance, "calibration_provenance")
            _required_text(self.reservoir_model, "reservoir_model")
            if not isinstance(self.temperature_kelvin, Fraction):
                raise ThermodynamicsContractError(
                    "calibrated temperature must be a Fraction"
                )
            if self.temperature_kelvin <= 0:
                raise ThermodynamicsContractError(
                    "calibrated temperature must be positive"
                )
            if self.temperature_unit != "K":
                raise ThermodynamicsContractError(
                    "calibrated temperature_unit must equal 'K'"
                )
            if not isinstance(self.temperature_uncertainty_kelvin, Fraction):
                raise ThermodynamicsContractError(
                    "calibrated temperature uncertainty must be a Fraction"
                )
            if self.temperature_uncertainty_kelvin < 0:
                raise ThermodynamicsContractError(
                    "calibrated temperature uncertainty cannot be negative"
                )
            _required_text(self.reset_protocol, "reset_protocol")
            _required_text(self.calibration_source, "calibration_source")
            if not isinstance(self.scaled_information, FormalLogElement):
                raise ThermodynamicsContractError(
                    "scaled_information must be a FormalLogElement"
                )
            _required_text(self.exact_lower_bound_joules, "exact_lower_bound_joules")
            if self.erased_information.is_zero:
                raise ThermodynamicsContractError(
                    "positive calibrated status cannot carry zero erasure"
                )
            if self.scaled_information != self.erased_information.scale(
                self.temperature_kelvin
            ):
                raise ThermodynamicsContractError(
                    "scaled_information does not equal T times erased information"
                )
            expected_expression = (
                f"k_B*{_temperature_text(self.temperature_kelvin)}*"
                f"({self.erased_information.expression}) J"
            )
            if self.exact_lower_bound_joules != expected_expression:
                raise ThermodynamicsContractError(
                    "exact lower-bound expression is not canonical"
                )

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> "LandauerLowerBoundReceipt":
        expected = {
            "schema", "event_id", "erased_information", "status",
            "calibration_id", "calibration_provenance", "reservoir_model",
            "temperature_kelvin", "temperature_unit",
            "temperature_uncertainty_kelvin", "reset_protocol",
            "calibration_source", "scaled_information", "exact_lower_bound_joules",
            "realized_heat_claimed",
        }
        if not isinstance(value, Mapping) or set(value) != expected:
            raise ThermodynamicsContractError(
                "Landauer receipt serialization has noncanonical fields"
            )
        if value["schema"] != LANDAUER_RECEIPT_SCHEMA:
            raise ThermodynamicsContractError("unknown Landauer receipt schema")
        temperature = value["temperature_kelvin"]
        scaled = value["scaled_information"]
        return cls(
            event_id=_required_text(value["event_id"], "event_id"),
            erased_information=FormalLogElement.from_dict(value["erased_information"]),
            status=_required_text(value["status"], "status"),
            calibration_id=value["calibration_id"],
            calibration_provenance=value["calibration_provenance"],
            reservoir_model=value["reservoir_model"],
            temperature_kelvin=(
                None
                if temperature is None
                else _fraction_from_dict(temperature, "temperature_kelvin")
            ),
            temperature_unit=value["temperature_unit"],
            temperature_uncertainty_kelvin=(
                None
                if value["temperature_uncertainty_kelvin"] is None
                else _fraction_from_dict(
                    value["temperature_uncertainty_kelvin"],
                    "temperature_uncertainty_kelvin",
                )
            ),
            reset_protocol=value["reset_protocol"],
            calibration_source=value["calibration_source"],
            scaled_information=(
                None if scaled is None else FormalLogElement.from_dict(scaled)
            ),
            exact_lower_bound_joules=value["exact_lower_bound_joules"],
            realized_heat_claimed=_strict_bool(
                value["realized_heat_claimed"], "realized_heat_claimed"
            ),
        )

    def to_dict(self) -> dict[str, object]:
        return {
            "schema": LANDAUER_RECEIPT_SCHEMA,
            "event_id": self.event_id,
            "erased_information": self.erased_information.to_dict(),
            "status": self.status,
            "calibration_id": self.calibration_id,
            "calibration_provenance": self.calibration_provenance,
            "reservoir_model": self.reservoir_model,
            "temperature_kelvin": (
                None
                if self.temperature_kelvin is None
                else _fraction_dict(self.temperature_kelvin)
            ),
            "temperature_unit": self.temperature_unit,
            "temperature_uncertainty_kelvin": (
                None
                if self.temperature_uncertainty_kelvin is None
                else _fraction_dict(self.temperature_uncertainty_kelvin)
            ),
            "reset_protocol": self.reset_protocol,
            "calibration_source": self.calibration_source,
            "scaled_information": (
                None
                if self.scaled_information is None
                else self.scaled_information.to_dict()
            ),
            "exact_lower_bound_joules": self.exact_lower_bound_joules,
            "realized_heat_claimed": False,
        }


def landauer_lower_bound(
    event: LogicalResetEvent,
    calibration: PhysicalResetCalibration | None = None,
) -> LandauerLowerBoundReceipt:
    """Emit zero, logical-only, or calibrated ideal-bound custody."""

    if not isinstance(event, LogicalResetEvent):
        raise ThermodynamicsContractError("event has the wrong type")
    erased = event.erased_information
    if erased.is_zero:
        return LandauerLowerBoundReceipt(
            event_id=event.event_id,
            erased_information=erased,
            status="ZERO_REVERSIBLE_LOWER_BOUND",
            calibration_id=None,
            calibration_provenance=None,
            reservoir_model=None,
            temperature_kelvin=None,
            temperature_unit=None,
            temperature_uncertainty_kelvin=None,
            reset_protocol=None,
            calibration_source=None,
            scaled_information=None,
            exact_lower_bound_joules="0 J",
        )
    if not event.irreversible_destruction_declared or event.reconstructs_source_after_event:
        raise ThermodynamicsContractError(
            "positive Landauer information requires actual irrecoverable destruction"
        )
    if calibration is None:
        return LandauerLowerBoundReceipt(
            event_id=event.event_id,
            erased_information=erased,
            status="LOGICAL_ERASURE_PHYSICAL_CALIBRATION_ABSENT",
            calibration_id=None,
            calibration_provenance=None,
            reservoir_model=None,
            temperature_kelvin=None,
            temperature_unit=None,
            temperature_uncertainty_kelvin=None,
            reset_protocol=None,
            calibration_source=None,
            scaled_information=None,
            exact_lower_bound_joules=None,
        )
    if not isinstance(calibration, PhysicalResetCalibration):
        raise ThermodynamicsContractError("calibration has the wrong type")
    scaled = erased.scale(calibration.temperature_kelvin)
    expression = (
        f"k_B*{_temperature_text(calibration.temperature_kelvin)}*"
        f"({erased.expression}) J"
    )
    return LandauerLowerBoundReceipt(
        event_id=event.event_id,
        erased_information=erased,
        status="IDEAL_LANDAUER_LOWER_BOUND",
        calibration_id=calibration.calibration_id,
        calibration_provenance=calibration.provenance,
        reservoir_model=calibration.reservoir_model,
        temperature_kelvin=calibration.temperature_kelvin,
        temperature_unit=calibration.temperature_unit,
        temperature_uncertainty_kelvin=(
            calibration.temperature_uncertainty_kelvin
        ),
        reset_protocol=calibration.reset_protocol,
        calibration_source=calibration.calibration_source,
        scaled_information=scaled,
        exact_lower_bound_joules=expression,
    )


__all__ = (
    "LANDAUER_RECEIPT_SCHEMA",
    "LOGICAL_RESET_SCHEMA",
    "PHYSICAL_CALIBRATION_SCHEMA",
    "LandauerLowerBoundReceipt",
    "LogicalResetEvent",
    "PhysicalResetCalibration",
    "ThermodynamicsContractError",
    "landauer_lower_bound",
)
