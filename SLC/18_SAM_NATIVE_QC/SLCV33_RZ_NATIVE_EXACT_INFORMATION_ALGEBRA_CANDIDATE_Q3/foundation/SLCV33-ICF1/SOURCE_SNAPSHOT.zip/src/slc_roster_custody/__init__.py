"""Compatibility re-export of the original roster custody API."""

import slc_custody as _unified


__all__ = list(_unified.V3_API)
globals().update({name: getattr(_unified, name) for name in __all__})
