#!/usr/bin/env python3
"""Focused controls for the custody-native SLC successor."""

from __future__ import annotations

import math
import unittest

from slc_custody_native import (
    CompiledCustodyMorphism,
    CompiledCustodyProgram,
    PrimeLogWeight,
    factor_positive_integer,
    finite_partition_morphism,
    frustrated_triangle_energy_morphism,
    reciprocal_dyadic_morphism,
    z4_translation_morphism,
)


class ExactInformationAlgebraTests(unittest.TestCase):
    def test_sam_two_three_factorization(self) -> None:
        weight = PrimeLogWeight.from_multiplicity(13_824)
        self.assertEqual(factor_positive_integer(13_824), ((2, 9), (3, 3)))
        self.assertEqual(weight.expression, "9*log(2) + 3*log(3)")

    def test_multiplicative_composition_is_additive(self) -> None:
        two = PrimeLogWeight.from_multiplicity(2)
        four = PrimeLogWeight.from_multiplicity(4)
        self.assertEqual(two.compose(four).multiplicity, 8)
        self.assertEqual(two.compose(four).expression, "3*log(2)")


class NativeMorphismTests(unittest.TestCase):
    def test_reciprocal_strata_and_reconstruction(self) -> None:
        morphism = reciprocal_dyadic_morphism(7)
        self.assertEqual(morphism.profile.fiber_strata, ((2, 21), (7, 1)))
        self.assertEqual(morphism.audit()["status"], "PASS")
        for item in morphism.domain:
            state = morphism.encode(item)
            self.assertEqual(morphism.decode(state.visible, state.receipt), item)

    def test_wrong_morphism_receipt_rejects(self) -> None:
        first = reciprocal_dyadic_morphism(5)
        second = reciprocal_dyadic_morphism(7)
        state = first.encode(first.domain[0])
        with self.assertRaises(ValueError):
            second.decode(second.visible(second.domain[0]), state.receipt)

    def test_fixed_z4_translation_is_visible_bijection(self) -> None:
        morphism = z4_translation_morphism(4, (1, 3, 2, 0))
        self.assertTrue(morphism.profile.visible_map_injective)
        self.assertEqual(morphism.profile.fiber_strata, ((1, 256),))
        self.assertEqual(morphism.profile.expected_hidden_information.expression, "0")
        self.assertEqual(morphism.audit()["status"], "PASS")

    def test_frustrated_triangle_has_two_and_six_state_fibers(self) -> None:
        morphism = frustrated_triangle_energy_morphism()
        self.assertEqual(morphism.profile.fiber_strata, ((2, 1), (6, 1)))
        coefficients = dict(morphism.profile.expected_hidden_information.coefficients)
        self.assertEqual(coefficients[2], 1)
        self.assertEqual(coefficients[3], 3 / 4)
        self.assertEqual(morphism.audit()["status"], "PASS")

    def test_receipt_discard_is_explicit(self) -> None:
        morphism = reciprocal_dyadic_morphism(5)
        ordinary = next(
            item for item in morphism.domain if morphism.encode(item).receipt.fiber_multiplicity == 2
        )
        state = morphism.encode(ordinary)
        logical = morphism.discard_receipt(state)
        self.assertEqual(logical.erased_information_exact_nats, "log(2)")
        self.assertIsNone(logical.landauer_lower_bound_joules)
        physical = morphism.discard_receipt(
            state,
            physical_reset_declared=True,
            temperature_kelvin=300,
        )
        self.assertAlmostEqual(
            float(physical.landauer_lower_bound_joules),
            1.380649e-23 * 300 * math.log(2),
        )

    def test_physical_reset_requires_temperature(self) -> None:
        morphism = reciprocal_dyadic_morphism(5)
        state = morphism.encode(morphism.domain[0])
        with self.assertRaises(ValueError):
            morphism.discard_receipt(state, physical_reset_declared=True)

    def test_composition_directly_minimizes_receipt(self) -> None:
        first = finite_partition_morphism(
            "VARIABLE_FIRST_FIBERS",
            range(6),
            {0: "A", 1: "A", 2: "A", 3: "A", 4: "B", 5: "C"},
        )
        second = finite_partition_morphism(
            "COLLAPSE_INTERMEDIATE",
            ("A", "B", "C"),
            {"A": "Z", "B": "Z", "C": "Z"},
        )
        composed, report = first.compose(second)
        self.assertEqual(composed.profile.fiber_strata, ((6, 1),))
        self.assertEqual(report["raw_pair_expected_container_bits"], 4.0)
        self.assertEqual(report["direct_minimal_expected_container_bits"], 3.0)
        self.assertEqual(report["expected_container_bit_savings"], 1.0)
        self.assertEqual(composed.audit()["status"], "PASS")

    def test_program_reconstructs_and_minimizes_stage_receipts(self) -> None:
        first = finite_partition_morphism(
            "PROGRAM_VARIABLE_FIRST_FIBERS",
            range(6),
            {0: "A", 1: "A", 2: "A", 3: "A", 4: "B", 5: "C"},
        )
        second = finite_partition_morphism(
            "PROGRAM_COLLAPSE_INTERMEDIATE",
            ("A", "B", "C"),
            {"A": "Z", "B": "Z", "C": "Z"},
        )
        program = CompiledCustodyProgram("TWO_STAGE_PROGRAM", (first, second))
        for item in program.domain:
            state = program.execute(item)
            self.assertEqual(program.reconstruct(state.visible, state.receipt), item)
        audit = program.audit()
        self.assertEqual(audit["status"], "PASS")
        self.assertEqual(
            audit["direct_minimized_profile"]["worst_case_receipt_container_bits"],
            3,
        )

    def test_invalid_partition_rejects(self) -> None:
        with self.assertRaises(ValueError):
            finite_partition_morphism("BAD", range(3), {0: "x", 1: "x"})

    def test_fiber_receipt_alphabet_is_exact(self) -> None:
        morphism = frustrated_triangle_energy_morphism()
        for visible in morphism.visible_outputs:
            indices = {
                morphism.encode(item).receipt.fiber_index
                for item in morphism.fiber(visible)
            }
            self.assertEqual(indices, set(range(len(morphism.fiber(visible)))))


if __name__ == "__main__":
    unittest.main(verbosity=2)
