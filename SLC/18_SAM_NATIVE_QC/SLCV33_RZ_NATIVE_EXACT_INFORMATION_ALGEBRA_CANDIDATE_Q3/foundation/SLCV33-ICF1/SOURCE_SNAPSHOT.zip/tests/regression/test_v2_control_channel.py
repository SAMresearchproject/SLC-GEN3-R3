#!/usr/bin/env python3
"""Focused tests for the native control/program custody refinement."""

from __future__ import annotations

import math
import unittest

from slc_custody_control import Z4ControlledTranslation, pack_z4, unpack_z4


class Z4PackingTests(unittest.TestCase):
    def test_pack_unpack_round_trip(self) -> None:
        digits = (0, 1, 2, 3, 3, 2, 1, 0, 1)
        self.assertEqual(unpack_z4(pack_z4(digits), 9), digits)

    def test_invalid_coordinate_rejects(self) -> None:
        with self.assertRaises(ValueError):
            pack_z4((0, 4))


class ControlledTranslationTests(unittest.TestCase):
    def setUp(self) -> None:
        self.action = Z4ControlledTranslation(3)

    def test_translation_inverse_for_complete_small_action(self) -> None:
        for data in range(self.action.size):
            for control in self.action.program_roster:
                visible = self.action.translate(data, control)
                self.assertEqual(self.action.inverse(visible, control), data)

    def test_dynamic_receipt_reconstructs_data_and_program(self) -> None:
        state = self.action.execute_dynamic(37, 51)
        self.assertEqual(self.action.reconstruct_dynamic(state.visible, state.program_receipt), (37, 51))

    def test_wrong_action_receipt_rejects(self) -> None:
        other = Z4ControlledTranslation(3, program_roster=(0, 1, 2))
        state = self.action.execute_dynamic(12, 7)
        with self.assertRaises(ValueError):
            other.reconstruct_dynamic(state.visible, state.program_receipt)

    def test_fixed_known_view_separates_capacity_from_custody(self) -> None:
        view = self.action.fixed_known_observation(7)
        self.assertEqual(view.address_capacity["evaluated_bits"], 6.0)
        self.assertEqual(view.ambient_program_capacity["evaluated_bits"], 6.0)
        self.assertEqual(view.active_program_capacity["exact_nats"], "0")
        self.assertEqual(view.hidden_data_given_visible_and_program["exact_nats"], "0")
        self.assertEqual(view.program_receipt_custody["exact_nats"], "0")
        self.assertEqual(view.logical_erasure["exact_nats"], "0")

    def test_dynamic_retained_view_custodies_program(self) -> None:
        view = self.action.dynamic_retained_observation()
        self.assertEqual(view.joint_input_capacity["evaluated_bits"], 12.0)
        self.assertEqual(view.hidden_control_given_visible["evaluated_bits"], 6.0)
        self.assertEqual(view.hidden_joint_given_visible["evaluated_bits"], 6.0)
        self.assertEqual(view.program_receipt_custody["evaluated_bits"], 6.0)
        self.assertEqual(view.remaining_hidden_after_retained_receipts["exact_nats"], "0")
        self.assertEqual(view.logical_erasure["exact_nats"], "0")

    def test_dynamic_reset_view_erases_program_fiber(self) -> None:
        view = self.action.dynamic_reset_observation()
        self.assertEqual(view.program_receipt_custody["exact_nats"], "0")
        self.assertEqual(view.remaining_hidden_after_retained_receipts["evaluated_bits"], 6.0)
        self.assertEqual(view.logical_erasure["evaluated_bits"], 6.0)
        self.assertEqual(view.reset_record.erased_information_exact_nats, "6*log(2)")

    def test_physical_control_reset_requires_temperature(self) -> None:
        with self.assertRaises(ValueError):
            self.action.dynamic_reset_observation(physical_reset_declared=True)

    def test_physical_control_reset_has_landauer_value(self) -> None:
        view = self.action.dynamic_reset_observation(
            physical_reset_declared=True,
            temperature_kelvin=300,
        )
        observed = float(view.reset_record.landauer_lower_bound_joules)
        expected = 1.380649e-23 * 300 * 6 * math.log(2)
        self.assertAlmostEqual(observed, expected)

    def test_subset_roster_uses_log_roster_not_ambient_capacity(self) -> None:
        action = Z4ControlledTranslation(3, program_roster=(0, 1, 7))
        view = action.dynamic_retained_observation()
        self.assertEqual(view.ambient_program_capacity["exact_nats"], "6*log(2)")
        self.assertEqual(view.active_program_capacity["exact_nats"], "log(3)")
        self.assertEqual(view.hidden_control_given_visible["exact_nats"], "log(3)")
        self.assertEqual(view.program_receipt_custody["exact_nats"], "log(3)")
        self.assertAlmostEqual(
            view.program_receipt_custody["evaluated_bits"],
            math.log2(3),
        )

    def test_observation_contracts_declare_all_five_surfaces(self) -> None:
        views = (
            self.action.fixed_known_observation(0),
            self.action.dynamic_retained_observation(),
            self.action.dynamic_reset_observation(),
        )
        for view in views:
            contract = view.contract
            self.assertTrue(contract.input_state)
            self.assertIsInstance(contract.conditioned_known, tuple)
            self.assertTrue(contract.visible_after)
            self.assertIsInstance(contract.retained_receipts, tuple)
            self.assertIsInstance(contract.reset_variables, tuple)

    def test_product_audit_passes(self) -> None:
        audit = self.action.audit_product_action(
            fixed_control=7,
            fixed_visible=19,
            cross_pair_count=257,
        )
        self.assertEqual(audit["status"], "PASS")
        self.assertEqual(audit["implicit_joint_pair_count"], 4096)


if __name__ == "__main__":
    unittest.main(verbosity=2)
