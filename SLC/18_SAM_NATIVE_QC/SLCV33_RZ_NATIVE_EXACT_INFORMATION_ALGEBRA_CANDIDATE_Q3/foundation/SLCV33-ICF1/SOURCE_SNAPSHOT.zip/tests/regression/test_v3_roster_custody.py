#!/usr/bin/env python3
"""Focused controls for roster identity and hierarchical program custody."""

from __future__ import annotations

import math
import unittest

from slc_roster_custody import (
    LOCAL_RECEIPT,
    ROSTER_RECEIPT,
    ProgramRoster,
    RosterCatalog,
    RosterNativeZ4Translation,
)


def shannon_bits(probabilities: tuple[float, ...]) -> float:
    return -sum(probability * math.log2(probability) for probability in probabilities)


def main_catalog(power: int = 4) -> RosterCatalog:
    rosters = (
        ProgramRoster("FIXED_ZERO", power, (0,), (1,)),
        ProgramRoster("WEIGHTED_TRIAD", power, (1, 7, 31), (1, 2, 1)),
        ProgramRoster(
            "WEIGHTED_PENTAD",
            power,
            (0, 1, 7, 31, 127),
            (1, 1, 2, 3, 1),
        ),
    )
    return RosterCatalog("THREE_ROSTER_TEST_CATALOG", rosters, (1, 2, 1))


class RosterIdentityTests(unittest.TestCase):
    def test_mapping_and_context_identity_are_separate(self) -> None:
        first = ProgramRoster("FIRST", 2, (0, 1), (1, 1))
        second = ProgramRoster("SECOND", 2, (0, 1), (1, 3))
        self.assertEqual(first.mapping_id, second.mapping_id)
        self.assertNotEqual(first.roster_id, second.roster_id)

    def test_duplicate_program_in_one_roster_rejects(self) -> None:
        with self.assertRaises(ValueError):
            ProgramRoster("BAD", 2, (0, 0), (1, 1))

    def test_nonuniform_roster_uses_shannon_entropy(self) -> None:
        roster = ProgramRoster("WEIGHTED", 2, (0, 1, 2), (1, 2, 1))
        self.assertEqual(roster.to_dict()["support_weight"]["exact_nats"], "log(3)")
        self.assertAlmostEqual(roster.entropy.bits, 1.5)
        self.assertLess(roster.entropy.bits, math.log2(3))

    def test_catalog_containers_preserve_channels_and_flatten_storage(self) -> None:
        catalog = main_catalog()
        self.assertEqual(catalog.roster_receipt_bits, 2)
        self.assertEqual(catalog.local_receipt_bits, 3)
        self.assertEqual(catalog.pair_receipt_bits, 5)
        self.assertEqual(catalog.flat_receipt_bits, 4)
        self.assertEqual(catalog.pair_count, 9)


class HierarchicalReceiptTests(unittest.TestCase):
    def setUp(self) -> None:
        self.catalog = main_catalog()
        self.action = RosterNativeZ4Translation(self.catalog)

    def test_pair_receipt_reconstructs_x_c_j_and_program(self) -> None:
        state = self.action.execute(93, 2, 4)
        self.assertEqual(self.action.reconstruct(state.visible, state.receipt), (93, 2, 4, 127))

    def test_local_receipt_contains_no_roster_or_program_identity(self) -> None:
        local = self.action.execute(12, 1, 2).receipt.roster_local_program.to_dict()
        self.assertNotIn("roster_index", local)
        self.assertNotIn("roster_id", local)
        self.assertNotIn("program_address", local)
        self.assertNotIn("control_address", local)

    def test_same_local_index_can_require_roster_identity(self) -> None:
        first = self.action.execute(12, 1, 0)
        second = self.action.execute(12, 2, 0)
        self.assertEqual(first.receipt.roster_local_program.local_index, 0)
        self.assertNotEqual(self.catalog.roster(1).program(0), self.catalog.roster(2).program(0))
        self.assertNotEqual(first.visible, second.visible)

    def test_flat_serialization_round_trip_preserves_logical_pair(self) -> None:
        for roster_index, roster in enumerate(self.catalog.rosters):
            for local_index in range(roster.size):
                receipt = self.action.execute(0, roster_index, local_index).receipt
                flat = self.action.flatten_receipt(receipt)
                expanded = self.action.expand_flat_receipt(flat)
                self.assertEqual(expanded, receipt)

    def test_full_small_action_audit_passes(self) -> None:
        audit = self.action.audit_full_action()
        self.assertEqual(audit["status"], "PASS")
        self.assertEqual(audit["executed_data_hierarchy_states"], 256 * 9)
        self.assertEqual(audit["unique_program_action_count"], 5)


class InformationProfileTests(unittest.TestCase):
    def setUp(self) -> None:
        self.catalog = main_catalog()
        self.action = RosterNativeZ4Translation(self.catalog)
        self.profile = self.action.profile_full_uniform_data()

    def test_full_profile_matches_direct_hierarchical_entropy(self) -> None:
        h_c = shannon_bits((0.25, 0.5, 0.25))
        h_j_given_c = (
            0.25 * 0.0
            + 0.5 * shannon_bits((0.25, 0.5, 0.25))
            + 0.25 * shannon_bits((0.125, 0.125, 0.25, 0.375, 0.125))
        )
        observed = self.profile.entropies["exact_hierarchy_given_visible"].bits
        self.assertAlmostEqual(observed, h_c + h_j_given_c)
        self.assertTrue(all(self.profile.chain_rule_checks.values()))

    def test_program_action_is_strict_hierarchy_quotient(self) -> None:
        hierarchy = self.profile.entropies["exact_hierarchy_given_visible"].bits
        action = self.profile.entropies["program_action_given_visible"].bits
        data = self.profile.entropies["data_state_given_visible"].bits
        self.assertLess(action, hierarchy)
        self.assertAlmostEqual(data, action)
        self.assertGreater(
            self.profile.entropies[
                "exact_hierarchy_given_visible_and_program_action"
            ].bits,
            0.0,
        )

    def test_shannon_custody_is_below_nine_pair_support(self) -> None:
        shannon = self.profile.entropies["exact_hierarchy_given_visible"].bits
        hartley = self.profile.expected_support_weights[
            "exact_hierarchy_given_visible"
        ].bits
        self.assertAlmostEqual(hartley, math.log2(9))
        self.assertLess(shannon, hartley)

    def test_both_receipts_reconstruct_without_erasure(self) -> None:
        view = self.action.observe_exact_hierarchy(
            self.profile,
            name="BOTH_RETAINED",
            retained_receipts=(ROSTER_RECEIPT, LOCAL_RECEIPT),
        )
        self.assertEqual(view.remaining_hidden_after_retained_receipts.expression, "0")
        self.assertEqual(view.logical_erasure.expression, "0")
        self.assertEqual(
            view.retained_receipt_custody,
            self.profile.entropies["exact_hierarchy_given_visible"],
        )

    def test_separate_resets_use_separate_conditional_entropies(self) -> None:
        local_reset = self.action.observe_exact_hierarchy(
            self.profile,
            name="LOCAL_RESET",
            retained_receipts=(ROSTER_RECEIPT,),
            reset_variables=(LOCAL_RECEIPT,),
        )
        roster_reset = self.action.observe_exact_hierarchy(
            self.profile,
            name="ROSTER_RESET",
            retained_receipts=(LOCAL_RECEIPT,),
            reset_variables=(ROSTER_RECEIPT,),
        )
        self.assertEqual(
            local_reset.logical_erasure,
            self.profile.entropies["local_index_given_visible_and_roster"],
        )
        self.assertEqual(
            roster_reset.logical_erasure,
            self.profile.entropies["roster_identity_given_visible_and_local_index"],
        )

    def test_composite_physical_reset_uses_shannon_not_support(self) -> None:
        view = self.action.observe_exact_hierarchy(
            self.profile,
            name="COMPOSITE_RESET",
            retained_receipts=(),
            reset_variables=(ROSTER_RECEIPT, LOCAL_RECEIPT),
            physical_reset_declared=True,
            temperature_kelvin=300,
        )
        self.assertEqual(
            view.logical_erasure,
            self.profile.entropies["exact_hierarchy_given_visible"],
        )
        self.assertIsNotNone(view.reset_record.landauer_lower_bound_joules)
        self.assertNotEqual(
            view.logical_erasure.expression,
            self.profile.expected_support_weights[
                "exact_hierarchy_given_visible"
            ].expression,
        )

    def test_physical_reset_requires_temperature(self) -> None:
        with self.assertRaises(ValueError):
            self.action.observe_exact_hierarchy(
                self.profile,
                name="BAD_PHYSICAL_RESET",
                retained_receipts=(),
                reset_variables=(ROSTER_RECEIPT, LOCAL_RECEIPT),
                physical_reset_declared=True,
            )


class RestrictedSourceTests(unittest.TestCase):
    def test_output_reveals_action_but_not_duplicate_roster_identity(self) -> None:
        catalog = RosterCatalog(
            "OUTPUT_REVEAL_CONTROL",
            (
                ProgramRoster("LEFT", 2, (0, 1), (1, 1)),
                ProgramRoster("RIGHT", 2, (0, 4), (1, 1)),
            ),
            (1, 1),
        )
        action = RosterNativeZ4Translation(catalog)
        profile = action.profile_restricted_data((0,), (1,))
        self.assertEqual(profile.entropies["program_action_given_visible"].expression, "0")
        self.assertEqual(profile.entropies["data_state_given_visible"].expression, "0")
        self.assertAlmostEqual(
            profile.entropies["exact_hierarchy_given_visible"].bits,
            0.5,
        )
        self.assertAlmostEqual(
            profile.entropies[
                "roster_identity_given_visible_and_local_index"
            ].bits,
            0.5,
        )
        self.assertEqual(
            profile.entropies["local_index_given_visible_and_roster"].expression,
            "0",
        )

    def test_restricted_source_weight_mismatch_rejects(self) -> None:
        action = RosterNativeZ4Translation(main_catalog())
        with self.assertRaises(ValueError):
            action.profile_restricted_data((0, 1), (1,))


if __name__ == "__main__":
    unittest.main(verbosity=2)
