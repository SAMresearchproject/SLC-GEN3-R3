#!/usr/bin/env python3
"""Focused tests for native generic C/J custody integration."""

from __future__ import annotations

import unittest
from dataclasses import replace

from slc_custody import (
    CompiledContextualCustodyMorphism,
    ContextProgram,
    ContextRoster,
    ContextualInput,
    ProgramRoster,
    RosterCatalog,
    RosterNativeZ4Translation,
    contextual_z4_from_catalog,
    finite_partition_morphism,
)


def example_contextual() -> CompiledContextualCustodyMorphism[int, str, str, str]:
    domain = range(4)
    a0 = finite_partition_morphism(
        "A_J0", domain, {0: "u", 1: "v", 2: "u", 3: "v"}
    )
    a1 = finite_partition_morphism(
        "A_J1", domain, {0: "u", 1: "u", 2: "u", 3: "u"}
    )
    b0 = finite_partition_morphism(
        "B_J0", domain, {0: "u", 1: "w", 2: "w", 3: "w"}
    )
    return CompiledContextualCustodyMorphism(
        "GENERIC_CJ_EXAMPLE",
        (
            ContextRoster("A", (ContextProgram("j0", a0), ContextProgram("j1", a1))),
            ContextRoster("B", (ContextProgram("j0", b0),)),
        ),
    )


class ContextRosterTests(unittest.TestCase):
    def test_roster_preserves_c_j_and_selected_morphism(self) -> None:
        contextual = example_contextual()
        self.assertEqual(contextual.roster("A").local_identities, ("j0", "j1"))
        self.assertEqual(contextual.selected_morphism("A", "j1").name, "A_J1")

    def test_duplicate_local_identity_rejects(self) -> None:
        morphism = finite_partition_morphism("DUP", range(2), {0: 0, 1: 1})
        with self.assertRaises(ValueError):
            ContextRoster("A", (ContextProgram("j", morphism), ContextProgram("j", morphism)))

    def test_mismatched_program_domains_reject(self) -> None:
        first = finite_partition_morphism("D2", range(2), {0: 0, 1: 1})
        second = finite_partition_morphism("D3", range(3), {0: 0, 1: 1, 2: 2})
        with self.assertRaises(ValueError):
            ContextRoster("A", (ContextProgram("j0", first), ContextProgram("j1", second)))

    def test_duplicate_context_identity_rejects(self) -> None:
        morphism = finite_partition_morphism("C_DUP", range(2), {0: 0, 1: 1})
        roster = ContextRoster("A", (ContextProgram("j", morphism),))
        with self.assertRaises(ValueError):
            CompiledContextualCustodyMorphism("BAD_C", (roster, roster))

    def test_catalog_identity_changes_with_rho(self) -> None:
        original = example_contextual()
        self.assertEqual(original.catalog_id, example_contextual().catalog_id)
        changed_map = finite_partition_morphism(
            "CHANGED", range(4), {0: "u", 1: "u", 2: "v", 3: "v"}
        )
        changed = CompiledContextualCustodyMorphism(
            "GENERIC_CJ_EXAMPLE",
            (ContextRoster("A", (ContextProgram("j0", changed_map),)),),
        )
        self.assertNotEqual(original.catalog_id, changed.catalog_id)


class ContextualReceiptTests(unittest.TestCase):
    def setUp(self) -> None:
        self.contextual = example_contextual()

    def test_observation_contract_types_conditioned_known_rho(self) -> None:
        contract = self.contextual.observation_contract
        self.assertEqual(contract.input_state, ("X", "C", "J"))
        self.assertIn("rho_C", contract.conditioned_known)
        self.assertEqual(contract.reconstruction_target, ("X", "C", "J"))

    def test_hierarchical_receipt_reconstructs_all_sources(self) -> None:
        for source in self.contextual.domain:
            state = self.contextual.execute(source.data, source.context, source.local_program)
            self.assertEqual(self.contextual.reconstruct(state.visible, state.receipt), source)

    def test_hierarchical_channels_use_visible_conditional_supports(self) -> None:
        state = self.contextual.execute(0, "A", "j1")
        self.assertEqual(state.visible, "u")
        self.assertEqual(state.receipt.roster_identity.visible_context_multiplicity, 2)
        self.assertEqual(state.receipt.roster_local_program.visible_local_multiplicity, 2)
        self.assertEqual(state.receipt.data_fiber.fiber_multiplicity, 4)
        self.assertEqual(state.receipt.information_multiplicity, 16)

    def test_wrong_catalog_receipt_rejects(self) -> None:
        state = self.contextual.execute(0, "A", "j0")
        bad_context = replace(state.receipt.roster_identity, catalog_id="wrong")
        bad_receipt = replace(state.receipt, roster_identity=bad_context)
        with self.assertRaises(ValueError):
            self.contextual.reconstruct(state.visible, bad_receipt)

    def test_direct_receipt_reconstructs_all_sources(self) -> None:
        for source in self.contextual.domain:
            state = self.contextual.execute_direct(source.data, source.context, source.local_program)
            self.assertEqual(self.contextual.reconstruct_direct(state.visible, state.receipt), source)

    def test_receipt_minimization_and_expansion_are_inverse(self) -> None:
        state = self.contextual.execute(0, "A", "j1")
        direct = self.contextual.minimize_receipt(state.visible, state.receipt)
        self.assertEqual(direct.visible_fiber_multiplicity, 7)
        self.assertEqual(direct.container_bits, 3)
        self.assertEqual(self.contextual.expand_receipt(state.visible, direct), state.receipt)

    def test_direct_fiber_profile_is_exact(self) -> None:
        profile = self.contextual.profile
        self.assertEqual(profile.source_state_count, 12)
        self.assertEqual(profile.direct_fiber_strata, ((2, 1), (3, 1), (7, 1)))

    def test_information_chain_rule_is_exact(self) -> None:
        profile = self.contextual.profile
        self.assertEqual(profile.information_chain_rule_residual.expression, "0")
        self.assertEqual(
            profile.expected_direct_information.expression,
            profile.expected_hierarchical_chain_information.expression,
        )

    def test_hierarchical_support_weight_is_separate_from_information(self) -> None:
        profile = self.contextual.profile
        self.assertGreater(profile.expected_support_weight_overhead.bits, 0.0)
        self.assertEqual(profile.information_chain_rule_residual.bits, 0.0)

    def test_direct_worst_case_container_is_minimized(self) -> None:
        profile = self.contextual.profile
        self.assertEqual(profile.worst_case_direct_container_bits, 3)
        self.assertEqual(profile.worst_case_hierarchical_container_bits, 4)

    def test_fixed_known_c_j_reduces_to_selected_v1_morphism(self) -> None:
        selected = self.contextual.selected_morphism("A", "j0")
        generic = self.contextual.execute(2, "A", "j0")
        fixed = selected.encode(2)
        self.assertEqual(generic.visible, fixed.visible)
        self.assertEqual(generic.receipt.data_fiber, fixed.receipt)

    def test_discard_receipt_erases_true_full_visible_fiber(self) -> None:
        state = self.contextual.execute(0, "A", "j1")
        reset = self.contextual.discard_receipt(state)
        self.assertEqual(reset.erased_information_exact_nats, "log(7)")


class ContextualCompositionTests(unittest.TestCase):
    def test_downstream_composition_preserves_c_j_and_reconstruction(self) -> None:
        contextual = example_contextual()
        after = finite_partition_morphism(
            "COLLAPSE_VISIBLE", ("u", "v", "w"), {"u": "z", "v": "z", "w": "z"}
        )
        composed, reports = contextual.compose(after)
        self.assertEqual(len(reports), 3)
        self.assertEqual(composed.profile.direct_fiber_strata, ((12, 1),))
        self.assertEqual(composed.audit()["status"], "PASS")

    def test_full_contextual_audit_passes(self) -> None:
        audit = example_contextual().audit()
        self.assertEqual(audit["checks_passed"], 7)
        self.assertEqual(audit["status"], "PASS")


class Z4ContextLiftTests(unittest.TestCase):
    def test_v3_catalog_lifts_into_generic_c_j_core(self) -> None:
        catalog = RosterCatalog(
            "GENERIC_Z4_LIFT",
            (
                ProgramRoster("LEFT", 2, (0, 1), (1, 1)),
                ProgramRoster("RIGHT", 2, (0, 4), (1, 1)),
            ),
            (1, 1),
        )
        legacy = RosterNativeZ4Translation(catalog)
        generic = contextual_z4_from_catalog(catalog)
        legacy_state = legacy.execute(9, 1, 1)
        generic_state = generic.execute(9, 1, 1)
        self.assertEqual(generic_state.visible, legacy_state.visible)
        self.assertEqual(
            generic.reconstruct(generic_state.visible, generic_state.receipt),
            ContextualInput(9, 1, 1),
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
