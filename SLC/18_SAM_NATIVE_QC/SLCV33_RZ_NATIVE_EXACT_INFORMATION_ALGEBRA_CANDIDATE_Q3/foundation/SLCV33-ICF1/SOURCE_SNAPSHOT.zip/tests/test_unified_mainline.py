#!/usr/bin/env python3
"""Focused tests for the unified continuous mainline."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

import slc_custody as custody
import slc_custody_control
import slc_custody_native
import slc_roster_custody


class UnifiedMainlineTests(unittest.TestCase):
    def test_release_lineage_builds_v6_on_v5(self) -> None:
        self.assertEqual(custody.PRODUCT, "SLC_CUSTODY_NATIVE_ARCHITECTURE")
        self.assertEqual(custody.CURRENT_RELEASE, "V6")
        self.assertEqual(custody.IMMEDIATE_BASELINE, "V5")
        self.assertEqual(custody.RELEASE_LINEAGE, ("V1", "V2", "V3", "V4", "V5", "V6"))

    def test_parent_public_apis_are_disjoint_and_exported(self) -> None:
        apis = tuple(map(set, (custody.V1_API, custody.V2_API, custody.V3_API)))
        self.assertFalse(apis[0] & apis[1])
        self.assertFalse(apis[0] & apis[2])
        self.assertFalse(apis[1] & apis[2])
        expected = set().union(*apis)
        self.assertTrue(expected <= set(custody.__all__))
        self.assertTrue(all(hasattr(custody, name) for name in expected))

    def test_compatibility_packages_reexport_unified_objects(self) -> None:
        for shim, names in (
            (slc_custody_native, custody.V1_API),
            (slc_custody_control, custody.V2_API),
            (slc_roster_custody, custody.V3_API),
        ):
            self.assertTrue(all(getattr(shim, name) is getattr(custody, name) for name in names))

    def test_v1_prime_log_algebra_remains_available(self) -> None:
        weight = custody.PrimeLogWeight.from_multiplicity(13_824)
        self.assertEqual(weight.expression, "9*log(2) + 3*log(3)")

    def test_v1_generic_morphism_remains_available(self) -> None:
        morphism = custody.finite_partition_morphism(
            "MAINLINE_V1_PARTITION",
            range(4),
            {0: "A", 1: "A", 2: "B", 3: "B"},
        )
        self.assertEqual(morphism.profile.fiber_strata, ((2, 2),))
        self.assertEqual(morphism.audit()["status"], "PASS")

    def test_v1_program_forward_reverse_remains_available(self) -> None:
        first = custody.finite_partition_morphism(
            "MAINLINE_PROGRAM_FIRST", range(4), {0: "A", 1: "A", 2: "B", 3: "B"}
        )
        second = custody.finite_partition_morphism(
            "MAINLINE_PROGRAM_SECOND", ("A", "B"), {"A": "Z", "B": "Z"}
        )
        program = custody.CompiledCustodyProgram("MAINLINE_PROGRAM", (first, second))
        state = program.execute(3)
        self.assertEqual(program.reconstruct(state.visible, state.receipt), 3)

    def test_v1_reciprocal_adapter_remains_available(self) -> None:
        morphism = custody.reciprocal_dyadic_morphism(7)
        self.assertEqual(morphism.profile.fiber_strata, ((2, 21), (7, 1)))
        self.assertEqual(morphism.audit()["status"], "PASS")

    def test_v2_fixed_control_view_remains_available(self) -> None:
        view = custody.Z4ControlledTranslation(3).fixed_known_observation(7)
        self.assertEqual(view.address_capacity["evaluated_bits"], 6.0)
        self.assertEqual(view.logical_erasure["exact_nats"], "0")

    def test_v2_restricted_roster_uses_active_m_not_ambient_space(self) -> None:
        view = custody.Z4ControlledTranslation(
            3, program_roster=(0, 7, 11)
        ).dynamic_retained_observation()
        self.assertEqual(view.active_program_capacity["exact_nats"], "log(3)")
        self.assertEqual(view.program_receipt_custody["exact_nats"], "log(3)")

    def test_v2_reset_view_remains_available(self) -> None:
        view = custody.Z4ControlledTranslation(3).dynamic_reset_observation()
        self.assertEqual(view.logical_erasure["exact_nats"], "6*log(2)")

    def test_v3_roster_receipt_remains_available(self) -> None:
        catalog = custody.RosterCatalog(
            "MAINLINE_V3",
            (
                custody.ProgramRoster("LEFT", 2, (0, 1), (1, 1)),
                custody.ProgramRoster("RIGHT", 2, (0, 4), (1, 1)),
            ),
            (1, 1),
        )
        action = custody.RosterNativeZ4Translation(catalog)
        state = action.execute(9, 1, 1)
        self.assertEqual(action.reconstruct(state.visible, state.receipt), (9, 1, 1, 4))

    def test_v3_target_quotient_remains_available(self) -> None:
        catalog = custody.RosterCatalog(
            "MAINLINE_V3_QUOTIENT",
            (
                custody.ProgramRoster("LEFT", 2, (0, 1), (1, 1)),
                custody.ProgramRoster("RIGHT", 2, (0, 4), (1, 1)),
            ),
            (1, 1),
        )
        profile = custody.RosterNativeZ4Translation(catalog).profile_restricted_data((0,), (1,))
        self.assertEqual(profile.entropies["program_action_given_visible"].expression, "0")
        self.assertEqual(
            profile.entropies["exact_hierarchy_given_visible"].expression,
            "1/2*log(2)",
        )

    def test_loaded_implementation_modules_resolve_inside_active_source(self) -> None:
        source_root = Path(custody.__file__).resolve().parents[1]
        modules = [
            module
            for name, module in sys.modules.items()
            if name == "slc_custody" or name.startswith("slc_custody.")
        ]
        self.assertTrue(modules)
        for module in modules:
            self.assertTrue(Path(module.__file__).resolve().is_relative_to(source_root))

    def test_v5_api_does_not_shadow_parent_api_names(self) -> None:
        parent = set(custody.V1_API) | set(custody.V2_API) | set(custody.V3_API)
        self.assertFalse(parent & set(custody.V5_API))

    def test_v6_api_is_disjoint_and_exported(self) -> None:
        prior = set().union(custody.V1_API, custody.V2_API, custody.V3_API, custody.V5_API)
        self.assertFalse(prior & set(custody.V6_API))
        self.assertTrue(set(custody.V6_API) <= set(custody.__all__))
        self.assertTrue(all(hasattr(custody, name) for name in custody.V6_API))

    def test_active_implementation_has_no_path_mutation_or_version_path(self) -> None:
        package = Path(custody.__file__).resolve().parent
        for path in package.glob("*.py"):
            text = path.read_text(encoding="utf-8")
            self.assertNotIn("sys.path", text, path)
            self.assertNotIn("SLC_CUSTODY_NATIVE_ARCHITECTURE_V", text, path)

    def test_active_implementation_does_not_import_compatibility_packages(self) -> None:
        package = Path(custody.__file__).resolve().parent
        forbidden = ("import slc_custody_native", "import slc_custody_control", "import slc_roster_custody")
        for path in package.glob("*.py"):
            text = path.read_text(encoding="utf-8")
            self.assertTrue(all(token not in text for token in forbidden), path)


if __name__ == "__main__":
    unittest.main(verbosity=2)
