from __future__ import annotations

from dataclasses import replace
from fractions import Fraction
from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from slc_custody.application_adapters import (  # noqa: E402
    ATOM3D_DECLARATIONS,
    ATOM3DFiniteAssignmentInput,
    AdapterDeclarations,
    ApplicationAdapterContractError,
    BennettLivenessCertificate,
    ExplicitAnalyticPrimeSourceMap,
    FiniteHistoryMultiplicity,
    NONINSTALLING_CROSSWALK_ONLY,
    RANK_TABLE_BOUND_EXCEEDED,
    RANK_TABLE_EXECUTED,
    RH_DECLARATIONS,
    adapt_atom3d,
    adapt_rh_prime_power,
    adapt_starbreaker,
)
from slc_custody.hd import FormalLogElement, HDSignature  # noqa: E402
from slc_custody.information import (  # noqa: E402
    ExactDistribution,
    InformationPartition,
    ReceiptChannel,
)
from slc_custody.thermodynamics import (  # noqa: E402
    LogicalResetEvent,
    PhysicalResetCalibration,
)


def reversible_starbreaker_pair(
) -> tuple[LogicalResetEvent, BennettLivenessCertificate]:
    event = LogicalResetEvent.reversible_exact_write(
        "STARBREAKER_KEEP",
        retained_channels=("OUTPUT",),
        source_law_provenance="DECLARED_FINITE_STARBREAKER_SOURCE",
    )
    liveness = BennettLivenessCertificate(
        certificate_id="BENNETT_KEEP",
        reset_event_id=event.event_id,
        live_channels_before_cleanup=("OUTPUT", "SCRATCH"),
        retained_channels_after_cleanup=("OUTPUT",),
        avoidable_uncomputation_channels=("SCRATCH",),
        committed_erasure_channels=(),
        output_copy_retained=True,
        inverse_schedule_declared=True,
        reconstructs_source_after_avoidable_uncomputation=True,
        logical_source_provenance=event.source_law_provenance,
        certificate_provenance="DECLARED_BENNETT_INVERSE_SCHEDULE",
    )
    return event, liveness


def committed_starbreaker_pair(
) -> tuple[LogicalResetEvent, BennettLivenessCertificate]:
    event = LogicalResetEvent.uniform_irreversible_destruction(
        "STARBREAKER_COMMIT",
        2,
        destroyed_channels=("BIT_RECEIPT",),
        retained_channels=("OUTPUT",),
        source_law_provenance="DECLARED_UNIFORM_STARBREAKER_BIT",
    )
    liveness = BennettLivenessCertificate(
        certificate_id="BENNETT_COMMIT",
        reset_event_id=event.event_id,
        live_channels_before_cleanup=("BIT_RECEIPT", "OUTPUT", "SCRATCH"),
        retained_channels_after_cleanup=("OUTPUT",),
        avoidable_uncomputation_channels=("SCRATCH",),
        committed_erasure_channels=("BIT_RECEIPT",),
        output_copy_retained=True,
        inverse_schedule_declared=True,
        reconstructs_source_after_avoidable_uncomputation=True,
        logical_source_provenance=event.source_law_provenance,
        certificate_provenance="DECLARED_BENNETT_INVERSE_AND_RESET_SPLIT",
    )
    return event, liveness


def atom3d_input(*, rank_limit: int = 8) -> ATOM3DFiniteAssignmentInput:
    domain = (0, 1, 2, 3)
    visible = InformationPartition.from_map(
        "visible", domain, {item: "one_visible_fiber" for item in domain}
    )
    symmetry = InformationPartition.from_map(
        "symmetry_orbits", domain, {0: "A", 1: "A", 2: "B", 3: "B"}
    )
    orbit_receipt = InformationPartition.from_map(
        "orbit_receipt", domain, {0: 0, 1: 0, 2: 1, 3: 1}
    )
    parity_receipt = InformationPartition.from_map(
        "parity_receipt", domain, {0: 0, 1: 1, 2: 0, 3: 1}
    )
    law = ExactDistribution.from_weights(
        {0: 1, 1: 1, 2: 1, 3: 1},
        provenance="DECLARED_UNIFORM_FOUR_ASSIGNMENT_SOURCE",
    )
    return ATOM3DFiniteAssignmentInput(
        assignment_domain=domain,
        symmetry_partition=symmetry,
        visible_partition=visible,
        kept_receipt_partitions=(
            ReceiptChannel("ORBIT", orbit_receipt),
            ReceiptChannel("PARITY", parity_receipt),
        ),
        source_law=law,
        exact_rank_channel_limit=rank_limit,
    )


class StarbreakerAdapterTests(unittest.TestCase):
    def test_reversible_bennett_lane_is_zero_and_separate(self) -> None:
        event, liveness = reversible_starbreaker_pair()
        receipt = adapt_starbreaker(event, liveness)
        self.assertEqual(
            receipt.declarations.installation_status,
            NONINSTALLING_CROSSWALK_ONLY,
        )
        self.assertEqual(receipt.avoidable_uncomputation_channels, ("SCRATCH",))
        self.assertTrue(receipt.avoidable_logical_erasure.is_zero)
        self.assertEqual(receipt.committed_erasure_channels, ())
        self.assertTrue(receipt.committed_logical_erasure.is_zero)
        self.assertEqual(
            receipt.landauer_receipt.status, "ZERO_REVERSIBLE_LOWER_BOUND"
        )
        self.assertFalse(receipt.physical_calibration_supplied)
        self.assertFalse(receipt.physical_calibration_applied)

    def test_committed_erasure_gets_symbolic_bound_only(self) -> None:
        event, liveness = committed_starbreaker_pair()
        calibration = PhysicalResetCalibration.create(
            "STARBREAKER_300K",
            temperature_kelvin=300,
            provenance="DECLARED_SYMBOLIC_BATH_NOT_HEAT_MEASUREMENT",
            reservoir_model="DECLARED_STARBREAKER_TEST_RESERVOIR",
            temperature_uncertainty_kelvin=0,
            reset_protocol="DECLARED_STARBREAKER_TEST_RESET_PROTOCOL",
            calibration_source="DECLARED_STARBREAKER_TEST_CALIBRATION_SOURCE",
        )
        receipt = adapt_starbreaker(event, liveness, calibration)
        self.assertEqual(
            receipt.committed_logical_erasure,
            FormalLogElement.from_positive_rational(2),
        )
        self.assertTrue(receipt.avoidable_logical_erasure.is_zero)
        self.assertEqual(
            receipt.landauer_receipt.exact_lower_bound_joules,
            "k_B*300*(ln(2)) J",
        )
        self.assertTrue(receipt.physical_calibration_applied)
        self.assertIs(receipt.physical_calibration, calibration)
        self.assertEqual(
            receipt.to_dict()["physical_reset_calibration"]["reservoir_model"],
            "DECLARED_STARBREAKER_TEST_RESERVOIR",
        )
        self.assertFalse(receipt.landauer_receipt.realized_heat_claimed)

    def test_wrong_types_and_source_mismatch_reject(self) -> None:
        event, liveness = reversible_starbreaker_pair()
        with self.assertRaises(ApplicationAdapterContractError):
            adapt_starbreaker(event.to_dict(), liveness)  # type: ignore[arg-type]
        with self.assertRaises(ApplicationAdapterContractError):
            adapt_starbreaker(event, liveness, Fraction(300))  # type: ignore[arg-type]
        mismatched = replace(
            liveness, logical_source_provenance="DIFFERENT_SOURCE"
        )
        with self.assertRaises(ApplicationAdapterContractError):
            adapt_starbreaker(event, mismatched)

    def test_unverified_bennett_inverse_rejects(self) -> None:
        with self.assertRaises(ApplicationAdapterContractError):
            BennettLivenessCertificate(
                certificate_id="NO_INVERSE",
                reset_event_id="E",
                live_channels_before_cleanup=("OUTPUT", "SCRATCH"),
                retained_channels_after_cleanup=("OUTPUT",),
                avoidable_uncomputation_channels=("SCRATCH",),
                committed_erasure_channels=(),
                output_copy_retained=True,
                inverse_schedule_declared=False,
                reconstructs_source_after_avoidable_uncomputation=True,
                logical_source_provenance="SOURCE",
                certificate_provenance="INCOMPLETE",
            )


class ATOM3DAdapterTests(unittest.TestCase):
    def test_large_channel_roster_uses_verified_greedy_sufficiency(self) -> None:
        domain = (0, 1)
        visible = InformationPartition.from_map(
            "large_visible", domain, {0: "same", 1: "same"}
        )
        discrete = InformationPartition.from_map(
            "large_discrete", domain, {0: 0, 1: 1}
        )
        channels = tuple(
            ReceiptChannel(f"C{index:02d}", discrete) for index in range(13)
        )
        native = ATOM3DFiniteAssignmentInput(
            assignment_domain=domain,
            symmetry_partition=discrete,
            visible_partition=visible,
            kept_receipt_partitions=channels,
            source_law=ExactDistribution.uniform(
                domain, provenance="DECLARED_UNIFORM_GREEDY_CONTROL"
            ),
            exact_rank_channel_limit=10,
        )
        receipt = adapt_atom3d(native)
        certificate = receipt.sufficiency_certificate
        self.assertTrue(certificate.reconstructs_source)
        self.assertFalse(certificate.exact_minimum)
        self.assertEqual(certificate.selected_channels, ("C00",))
        self.assertEqual(len(certificate.redundant_channels), 12)

    def test_exact_orbits_refinement_sufficiency_and_rank_table(self) -> None:
        receipt = adapt_atom3d(atom3d_input())
        self.assertEqual(receipt.symmetry_orbit_multiplicities, (2, 2))
        self.assertEqual(receipt.visible_fiber_multiplicities, (4,))
        self.assertEqual(receipt.kept_fiber_multiplicities, (1, 1, 1, 1))
        self.assertTrue(receipt.symmetry_refines_visible)
        self.assertFalse(receipt.visible_refines_symmetry)
        self.assertFalse(receipt.partitions_equivalent)
        self.assertTrue(receipt.kept_refines_visible)
        self.assertTrue(receipt.kept_refines_symmetry)
        certificate = receipt.sufficiency_certificate
        self.assertTrue(certificate.reconstructs_source)
        self.assertTrue(certificate.exact_minimum)
        self.assertEqual(certificate.selected_channels, ("ORBIT", "PARITY"))

        table = receipt.rank_table
        self.assertEqual(table.status, RANK_TABLE_EXECUTED)
        self.assertEqual(len(table.rank_rows), 4)
        self.assertEqual(len(table.innovation_rows), 4)
        self.assertEqual(len(table.submodularity_rows), 16)
        full = next(
            row for row in table.rank_rows
            if row.selected_channels == ("ORBIT", "PARITY")
        )
        self.assertEqual(
            full.rank,
            FormalLogElement.from_coefficients({2: Fraction(2)}),
        )
        self.assertTrue(all(row.innovation.sign >= 0 for row in table.innovation_rows))
        self.assertTrue(all(row.residual.sign >= 0 for row in table.submodularity_rows))

    def test_bound_is_declared_without_approximate_rank_rows(self) -> None:
        receipt = adapt_atom3d(atom3d_input(rank_limit=1))
        self.assertEqual(receipt.rank_table.status, RANK_TABLE_BOUND_EXCEEDED)
        self.assertEqual(receipt.rank_table.rank_rows, ())
        self.assertEqual(receipt.rank_table.innovation_rows, ())
        self.assertEqual(receipt.rank_table.submodularity_rows, ())
        self.assertTrue(receipt.sufficiency_certificate.reconstructs_source)

    def test_no_geometry_scale_binding_or_energy_inference(self) -> None:
        receipt = adapt_atom3d(atom3d_input())
        self.assertFalse(receipt.geometry_inference_performed)
        self.assertFalse(receipt.scale_inference_performed)
        self.assertFalse(receipt.binding_inference_performed)
        self.assertFalse(receipt.energy_inference_performed)
        self.assertEqual(
            receipt.declarations.unchanged_downstream_authority,
            "ATOM3D_AUTHORITY_UNCHANGED",
        )
        with self.assertRaises(ApplicationAdapterContractError):
            replace(receipt, energy_inference_performed=True)

    def test_wrong_type_and_source_domain_reject(self) -> None:
        native = atom3d_input()
        with self.assertRaises(ApplicationAdapterContractError):
            adapt_atom3d({"domain": native.assignment_domain})  # type: ignore[arg-type]
        wrong_law = ExactDistribution.uniform(
            (0, 1), provenance="WRONG_DOMAIN_SOURCE"
        )
        with self.assertRaises(ApplicationAdapterContractError):
            replace(native, source_law=wrong_law)
        with self.assertRaises(ApplicationAdapterContractError):
            replace(
                native,
                kept_receipt_partitions=list(native.kept_receipt_partitions),  # type: ignore[arg-type]
            )


class RHPrimePowerAdapterTests(unittest.TestCase):
    def test_exact_prime_power_hd_and_formal_log_composition(self) -> None:
        history = FiniteHistoryMultiplicity(
            "P3_DEPTH2_HISTORIES",
            9,
            "DECLARED_FINITE_NINE_HISTORY_SOURCE",
        )
        receipt = adapt_rh_prime_power(3, 2, history)
        expected = FormalLogElement.from_coefficients({3: Fraction(2)})
        self.assertEqual(receipt.direct_prime_power_formal_log, expected)
        self.assertEqual(receipt.scaled_prime_formal_log, expected)
        self.assertTrue(receipt.composition_residual.is_zero)
        self.assertEqual(receipt.composed_prime_power_hd, HDSignature.from_rational(9))
        self.assertEqual(receipt.direct_prime_power_hd.value, Fraction(9))
        self.assertEqual(receipt.exact_identity, "L(3^2) = 2*ln(3)")
        self.assertEqual(receipt.rh_sign_inference, "NOT_PERFORMED")
        self.assertEqual(
            receipt.declarations.unchanged_downstream_authority,
            "RH_AUTHORITY_UNCHANGED",
        )

    def test_explicit_analytic_source_map_is_carried_without_sign(self) -> None:
        history = FiniteHistoryMultiplicity(
            "P2_DEPTH2_HISTORIES",
            4,
            "DECLARED_FINITE_FOUR_HISTORY_SOURCE",
        )
        source_map = ExplicitAnalyticPrimeSourceMap(
            map_id="EXPLICIT_P2_ANALYTIC_MAP",
            prime=2,
            history_to_analytic_source=tuple(
                (index, f"DECLARED_ANALYTIC_SOURCE_{index}") for index in range(4)
            ),
            provenance="OWNER_SUPPLIED_EXPLICIT_SOURCE_MAP",
        )
        receipt = adapt_rh_prime_power(
            2,
            2,
            history,
            interpret_as_analytic_prime_source=True,
            analytic_source_map=source_map,
        )
        self.assertEqual(receipt.analytic_source_map, source_map)
        self.assertEqual(
            receipt.to_dict()["analytic_source_map"]["provenance"],
            "OWNER_SUPPLIED_EXPLICIT_SOURCE_MAP",
        )
        self.assertEqual(
            receipt.analytic_source_interpretation_status,
            "EXPLICIT_SOURCE_MAP_CARRIED_NO_SIGN_INFERENCE",
        )
        self.assertEqual(receipt.rh_sign_inference, "NOT_PERFORMED")

    def test_prime_exponent_and_history_source_rejections(self) -> None:
        history = FiniteHistoryMultiplicity("H", 9, "FINITE_SOURCE")
        with self.assertRaises(ApplicationAdapterContractError):
            adapt_rh_prime_power(9, 1, history)
        with self.assertRaises(ApplicationAdapterContractError):
            adapt_rh_prime_power(3, 2.0, history)  # type: ignore[arg-type]
        with self.assertRaises(ApplicationAdapterContractError):
            adapt_rh_prime_power(3, 2, {"multiplicity": 9})  # type: ignore[arg-type]
        wrong_count = FiniteHistoryMultiplicity("H8", 8, "FINITE_SOURCE")
        with self.assertRaises(ApplicationAdapterContractError):
            adapt_rh_prime_power(3, 2, wrong_count)

    def test_analytic_interpretation_requires_separate_explicit_map(self) -> None:
        history = FiniteHistoryMultiplicity("H4", 4, "FINITE_SOURCE")
        with self.assertRaises(ApplicationAdapterContractError):
            adapt_rh_prime_power(
                2,
                2,
                history,
                interpret_as_analytic_prime_source=True,
            )
        source_map = ExplicitAnalyticPrimeSourceMap(
            "MAP",
            2,
            tuple((index, f"S{index}") for index in range(4)),
            "EXPLICIT_MAP",
        )
        with self.assertRaises(ApplicationAdapterContractError):
            adapt_rh_prime_power(2, 2, history, analytic_source_map=source_map)

    def test_rh_sign_request_is_rejected(self) -> None:
        history = FiniteHistoryMultiplicity("H4", 4, "FINITE_SOURCE")
        with self.assertRaises(ApplicationAdapterContractError):
            adapt_rh_prime_power(
                2,
                2,
                history,
                request_rh_sign_inference=True,
            )


class AuthorityBoundaryTests(unittest.TestCase):
    def test_installing_declaration_is_rejected(self) -> None:
        with self.assertRaises(ApplicationAdapterContractError):
            AdapterDeclarations(
                native_input="typed input",
                exact_crosswalk="exact crosswalk",
                preserved_laws=("law",),
                imported_theorem_or_algorithm="algorithm",
                new_exposed_capability="capability",
                unchanged_downstream_authority="unchanged",
                installation_status="INSTALL_AND_PROMOTE",
            )

    def test_receipt_rejects_changed_downstream_authority(self) -> None:
        receipt = adapt_atom3d(atom3d_input())
        changed = replace(
            ATOM3D_DECLARATIONS,
            unchanged_downstream_authority="ATOM3D_AUTHORITY_CHANGED",
        )
        with self.assertRaises(ApplicationAdapterContractError):
            replace(receipt, declarations=changed)

        history = FiniteHistoryMultiplicity("H4", 4, "FINITE_SOURCE")
        rh_receipt = adapt_rh_prime_power(2, 2, history)
        changed_rh = replace(
            RH_DECLARATIONS,
            unchanged_downstream_authority="RH_SIGN_INSTALLED",
        )
        with self.assertRaises(ApplicationAdapterContractError):
            replace(rh_receipt, declarations=changed_rh)


if __name__ == "__main__":
    unittest.main()
