from __future__ import annotations

import unittest

from slc_custody.adapters import finite_partition_morphism
from slc_custody.contextual import (
    CompiledContextualCustodyMorphism,
    ContextProgram,
    ContextRoster,
)
from slc_custody.contextual_program import CompiledContextualCustodyProgram


def build_program() -> CompiledContextualCustodyProgram:
    domain = range(4)
    a0 = finite_partition_morphism(
        "A0", domain, {0: "u", 1: "v", 2: "u", 3: "v"}
    )
    a1 = finite_partition_morphism(
        "A1", domain, {0: "u", 1: "u", 2: "v", 3: "v"}
    )
    b0 = finite_partition_morphism(
        "B0", domain, {0: "u", 1: "v", 2: "v", 3: "u"}
    )
    contextual = CompiledContextualCustodyMorphism(
        "CONTEXTUAL_PROGRAM_FIXTURE",
        (
            ContextRoster("A", (ContextProgram("j0", a0), ContextProgram("j1", a1))),
            ContextRoster("B", (ContextProgram("j0", b0),)),
        ),
    )
    collapse = finite_partition_morphism(
        "COLLAPSE_UV", ("u", "v"), {"u": 0, "v": 0}
    )
    terminal = finite_partition_morphism("TERMINAL", (0,), {0: "done"})
    return CompiledContextualCustodyProgram(
        "TWO_STAGE_AFTER_CONTEXT", contextual, (collapse, terminal)
    )


class ContextualProgramTests(unittest.TestCase):
    def test_sequential_and_compiled_lanes_match_and_reconstruct(self) -> None:
        program = build_program()
        for source in program.domain:
            sequential = program.execute(source)
            compiled = program.execute_compiled(source)
            self.assertEqual(sequential.visible, compiled.visible)
            self.assertEqual(
                program.reconstruct(sequential.visible, sequential.receipt), source
            )
            self.assertEqual(
                program.reconstruct_compiled(compiled.visible, compiled.receipt), source
            )

    def test_liveness_uncomputes_temporary_receipts_with_zero_erasure(self) -> None:
        program = build_program()
        certificate = program.liveness_certificate(program.domain[0])
        self.assertEqual(certificate["status"], "PASS_ZERO_ERASURE_UNCOMPUTATION")
        self.assertEqual(certificate["logical_erasure_exact_nats"]["expression"], "0")
        self.assertGreaterEqual(
            certificate["peak_live_receipt_container_bits"],
            certificate["final_kept_receipt_container_bits"],
        )
        self.assertEqual(
            certificate["schedule"][0]["action"],
            "COPY_FINAL_VISIBLE_AND_MINIMAL_RECEIPT",
        )

    def test_complete_program_audit_passes(self) -> None:
        audit = build_program().audit()
        self.assertEqual(audit["status"], "PASS")
        self.assertEqual(audit["source_state_count"], 12)
        self.assertEqual(audit["downstream_stage_count"], 2)
        self.assertEqual(audit["failure_count"], 0)

    def test_incompatible_downstream_support_rejects(self) -> None:
        program = build_program()
        bad = finite_partition_morphism("BAD", ("u",), {"u": 0})
        with self.assertRaises(ValueError):
            CompiledContextualCustodyProgram("BAD_PROGRAM", program.initial, (bad,))


if __name__ == "__main__":
    unittest.main()
