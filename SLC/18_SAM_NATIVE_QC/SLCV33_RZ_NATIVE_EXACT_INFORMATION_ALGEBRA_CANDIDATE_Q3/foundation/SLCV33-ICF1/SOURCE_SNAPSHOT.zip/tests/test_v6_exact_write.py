#!/usr/bin/env python3
"""Bounded V6 tests for the hash-bound Complete Exact Write substrate."""

from __future__ import annotations

import sys
import unittest
from fractions import Fraction
from pathlib import Path

from slc_custody.exact_write import (
    EXPECTED_CURRENT_REVISION_NAME,
    EXPECTED_OPERATION_IDS,
    OPERATION_DESCRIPTORS,
    PINNED_ARTIFACTS,
    CompleteExactWriteAdapter,
    ExactWriteDependencyReceipt,
    locate_repository_root,
    verify_exact_write_dependencies,
)


class V6ExactWriteDependencyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.repository_root = locate_repository_root(Path(__file__))
        cls.receipt = verify_exact_write_dependencies(cls.repository_root)

    def test_repository_discovery_uses_authority_and_exact_write_markers(self) -> None:
        self.assertTrue((self.repository_root / "AGENTS.md").is_file())
        self.assertTrue((self.repository_root / "DECLARATION_OF_RESEARCH.md").is_file())
        self.assertEqual(locate_repository_root(self.repository_root / "SAM_REVIEW"), self.repository_root)

    def test_all_frozen_artifact_hashes_match(self) -> None:
        self.assertIsInstance(self.receipt, ExactWriteDependencyReceipt)
        expected = {pin.role: pin.sha256 for pin in PINNED_ARTIFACTS}
        observed = {artifact.role: artifact.sha256 for artifact in self.receipt.artifacts}
        self.assertEqual(observed, expected)
        self.assertTrue(all(artifact.byte_count > 0 for artifact in self.receipt.artifacts))

    def test_current_revision_field_is_exact_q2(self) -> None:
        self.assertEqual(EXPECTED_CURRENT_REVISION_NAME, "SLCQ2-RZ")
        self.assertEqual(self.receipt.current_revision_name, "SLCQ2-RZ")

    def test_semantic_receipts_are_present_and_exactly_typed(self) -> None:
        for semantic_hash in (
            self.receipt.interface_semantic_sha256,
            self.receipt.result_semantic_sha256,
            self.receipt.validation_semantic_sha256,
        ):
            self.assertEqual(len(semantic_hash), 64)
            self.assertTrue(set(semantic_hash) <= set("0123456789abcdef"))


class V6ExactWriteOperationSurfaceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.adapter = CompleteExactWriteAdapter(Path(__file__))

    def test_every_installed_coverage_row_has_one_strict_descriptor(self) -> None:
        self.assertEqual(len(OPERATION_DESCRIPTORS), 19)
        self.assertEqual(len(EXPECTED_OPERATION_IDS), 19)
        self.assertEqual(len(set(EXPECTED_OPERATION_IDS)), 19)
        self.assertEqual(self.adapter.operation_descriptors, OPERATION_DESCRIPTORS)
        for descriptor in OPERATION_DESCRIPTORS:
            self.assertIs(self.adapter.descriptor(descriptor.operation_id), descriptor)
            self.assertTrue(descriptor.immutable_symbols)
            self.assertTrue(descriptor.exact_law)
            self.assertTrue(descriptor.reconstruction_contract)

    def test_unknown_operation_id_rejects(self) -> None:
        with self.assertRaises(KeyError):
            self.adapter.descriptor("NOT_AN_INSTALLED_LAYER")

    def test_adapter_dynamically_resolves_the_pinned_source(self) -> None:
        source = self.adapter.immutable_source_path
        artifact = self.adapter.dependency_receipt.artifact("COMPLETE_EXACT_WRITE_SOURCE")
        self.assertEqual(source.relative_to(self.adapter.dependency_receipt.repository_root).as_posix(), artifact.relative_path)
        loaded = sys.modules["_slc_custody_frozen_complete_exact_write_8b54927924eebb61"]
        self.assertEqual(Path(loaded.__file__).resolve(), source)

    def test_strict_primitive_types_reject_bool_and_foreign_records(self) -> None:
        with self.assertRaises(TypeError):
            self.adapter.w8_bits(True)
        with self.assertRaises(TypeError):
            self.adapter.w8_site(1, (object(),))
        with self.assertRaises(TypeError):
            self.adapter.compile_translation(((True, 1),))


class V6ExactWriteLawTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.adapter = CompleteExactWriteAdapter(Path(__file__))
        cls.audit = cls.adapter.audit_exact_laws()

    def test_full_bounded_exact_law_audit_passes(self) -> None:
        self.assertEqual(self.audit.status, "PASS")
        self.assertEqual(self.audit.checks_passed, self.audit.checks_total)
        self.assertEqual(self.audit.checks_total, 15)
        self.assertEqual(self.audit.operation_ids, EXPECTED_OPERATION_IDS)
        self.assertEqual(
            {check.name for check in self.audit.checks},
            {
                "W8_COMPLETE_SHELL_CENSUS",
                "HAMILTONIAN_WELD_B0_B1",
                "W8_W9_TWO_SITE_LIFECYCLE",
                "PACKED_Z4_SIGNED_EVENT",
                "Z4_TRANSLATION_IDENTITY_COMPOSITION_INVERSE",
                "ENDPOINT_REVERSAL_COVARIANCE",
                "HISTORY_QUOTIENT_PLUS_ANCHOR_RECONSTRUCTS",
                "COMMON_CONSTANT_KERNEL_AND_ANCHOR",
                "COMPLETED_PROJECTION_RESPONSE_REMAINDER",
                "ANALYTIC_BT_ET_J_PPLUS_PMINUS",
                "MULTIPLICATIVE_LEDGER_AND_TYPED_NONINVERTIBILITY",
                "Z4_MU4_CHARACTER_AND_READBACK",
                "REFERENCE_SEQUENTIAL_NATIVE_EQUALITY",
                "ALL_INSTALLED_COVERAGE_LAYERS_TYPED",
                "IMMUTABLE_SOURCE_CUSTODY_UNCHANGED",
            },
        )

    def test_native_batches_equal_pure_reference_and_python_compilation(self) -> None:
        self.assertEqual(len(self.audit.native_batches), 3)
        self.assertTrue(all(batch.passed for batch in self.audit.native_batches))
        self.assertTrue(all(batch.address_count <= 64 for batch in self.audit.native_batches))
        self.assertTrue(all(batch.program_length <= 18 for batch in self.audit.native_batches))
        self.assertTrue(all(len(batch.output_sha256) == 64 for batch in self.audit.native_batches))

    def test_history_quotient_requires_and_uses_the_common_anchor(self) -> None:
        left = tuple(Fraction(index, 3) for index in range(81))
        right = tuple(Fraction(2 * index + 1, 5) for index in range(81))
        quotient, anchor = self.adapter.history_quotient(left, right)
        self.assertEqual(len(quotient.coordinates), 161)
        self.assertEqual(quotient.reconstruct(anchor), (left, right))
        self.assertNotEqual(quotient.reconstruct(), (left, right))

    def test_w8_w9_lifecycle_retains_one_shared_receipt(self) -> None:
        source = self.adapter.w8_site(4)
        target = self.adapter.w8_site(11)
        active = self.adapter.activate_write(source, target, 2, 1, 19, 257)
        completed = self.adapter.complete_write(active)
        self.assertEqual(completed.x1_custody, 0)
        self.assertEqual(completed.source_phase, "W8")
        self.assertEqual(completed.target_phase, "W8")
        self.assertIs(completed.source.retained_records[-1], completed.retained_record)
        self.assertIs(completed.target.retained_records[-1], completed.retained_record)
        self.assertEqual(self.adapter.project_w8(completed.retained_record), 11)

    def test_multiplicative_ledger_types_noninvertibility(self) -> None:
        receipt = self.adapter.ledger_write(5, 6, 12)
        self.assertFalse(receipt.invertible_before)
        self.assertIsNone(receipt.recovered_write_state)
        self.assertEqual(receipt.after, 6)

    def test_projection_and_analytic_outputs_remain_exact_fractions(self) -> None:
        projection = self.adapter.completed_projection((3, 4, 5), (1, 1, 0))
        self.assertEqual(projection.projection, (Fraction(7, 2), Fraction(7, 2), Fraction(0)))
        self.assertTrue(projection.orthogonal and projection.conserved and projection.idempotent)
        analytic = self.adapter.analytic_write(
            (self.adapter.qcomplex(1, 2), self.adapter.qcomplex(3, -1)),
            (self.adapter.qcomplex(-2, 1), self.adapter.qcomplex(4, 5)),
        )
        self.assertTrue(analytic.identity_closes)
        self.assertIsInstance(analytic.write_energy, Fraction)

    def test_audit_serialization_contains_no_float_authority(self) -> None:
        serialized = self.audit.to_dict()
        self.assertEqual(serialized["status"], "PASS")
        self.assertNotIn("exact_nats", serialized)
        self.assertNotIn("physical_heat", serialized)


if __name__ == "__main__":
    unittest.main(verbosity=2)
