from __future__ import annotations

from fractions import Fraction
from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from slc_custody.hd import (  # noqa: E402
    FormalLogElement,
    HDContractError,
    HDSignature,
    RationalFactorProof,
    factor_bounded_rational,
)


class FormalLogTests(unittest.TestCase):
    def test_sam_exact_identities(self) -> None:
        l4 = FormalLogElement.from_positive_rational(Fraction(4))
        l12 = FormalLogElement.from_positive_rational(Fraction(12))
        l18 = FormalLogElement.from_positive_rational(Fraction(18))
        l18_over_12 = FormalLogElement.from_positive_rational(Fraction(18, 12))
        l9_over_8 = FormalLogElement.from_positive_rational(Fraction(9, 8))

        self.assertEqual(l4.coefficients, ((2, Fraction(2)),))
        self.assertEqual(
            l12.coefficients,
            ((2, Fraction(2)), (3, Fraction(1))),
        )
        self.assertEqual(
            l18.coefficients,
            ((2, Fraction(1)), (3, Fraction(2))),
        )
        self.assertEqual(
            l18_over_12.coefficients,
            ((2, Fraction(-1)), (3, Fraction(1))),
        )
        self.assertEqual(
            l9_over_8.coefficients,
            ((2, Fraction(-3)), (3, Fraction(2))),
        )
        self.assertEqual(l18 - l12, l18_over_12)

    def test_add_subtract_scale_and_zero(self) -> None:
        l2 = FormalLogElement.from_positive_rational(2)
        l3 = FormalLogElement.from_positive_rational(3)
        self.assertEqual(l2 + l2.scale(2), FormalLogElement.from_positive_rational(8))
        self.assertEqual((l2 + l3) - l3, l2)
        self.assertEqual(l2.scale(0), FormalLogElement.zero())
        self.assertEqual(
            FormalLogElement.from_positive_rational(4).scale(Fraction(1, 2)),
            l2,
        )
        self.assertEqual(FormalLogElement.from_positive_rational(1).expression, "0")

    def test_exact_sign_and_comparison_use_no_transcendental_value(self) -> None:
        l12 = FormalLogElement.from_positive_rational(12)
        l18 = FormalLogElement.from_positive_rational(18)
        self.assertLess(l12, l18)
        self.assertEqual(l12.compare(l18), -1)
        self.assertEqual((l18 - l12).sign, 1)
        self.assertEqual(FormalLogElement.from_positive_rational(Fraction(2, 3)).sign, -1)
        self.assertEqual(FormalLogElement.zero().sign, 0)

    def test_expression_and_strict_serialization_round_trip(self) -> None:
        value = FormalLogElement.from_coefficients(
            {2: Fraction(-3, 2), 3: Fraction(2), 5: Fraction(-1)}
        )
        self.assertEqual(value.expression, "-3/2*ln(2) + 2*ln(3) - ln(5)")
        self.assertEqual(FormalLogElement.from_dict(value.to_dict()), value)

        extra = dict(value.to_dict())
        extra["evaluated_nats"] = 0
        with self.assertRaises(HDContractError):
            FormalLogElement.from_dict(extra)

        unreduced = value.to_dict()
        unreduced["coefficients"][0]["coefficient"] = {
            "numerator": -6,
            "denominator": 4,
        }
        with self.assertRaises(HDContractError):
            FormalLogElement.from_dict(unreduced)

    def test_prime_keys_and_coefficients_are_canonical(self) -> None:
        with self.assertRaises(HDContractError):
            FormalLogElement(((4, Fraction(1)),))
        with self.assertRaises(HDContractError):
            FormalLogElement(((3, Fraction(1)), (2, Fraction(1))))
        with self.assertRaises(HDContractError):
            FormalLogElement(((2, Fraction(1)), (2, Fraction(2))))
        with self.assertRaises(HDContractError):
            FormalLogElement(((2, Fraction(0)),))
        with self.assertRaises(HDContractError):
            FormalLogElement(((2, 1),))  # type: ignore[arg-type]
        with self.assertRaises(HDContractError):
            FormalLogElement.from_positive_rational(2.0)  # type: ignore[arg-type]
        with self.assertRaises(HDContractError):
            FormalLogElement.from_positive_rational(0)


class RationalFactorProofTests(unittest.TestCase):
    def test_bounded_signed_rational_factor_proof(self) -> None:
        proof = factor_bounded_rational(
            Fraction(-420, 143), maximum_component=500
        )
        self.assertEqual(proof.sign, -1)
        self.assertEqual(
            proof.numerator_factors,
            ((2, 2), (3, 1), (5, 1), (7, 1)),
        )
        self.assertEqual(proof.denominator_factors, ((11, 1), (13, 1)))
        self.assertEqual(proof.formal_log, FormalLogElement.from_positive_rational(Fraction(420, 143)))
        self.assertEqual(RationalFactorProof.from_dict(proof.to_dict()), proof)

    def test_factor_proof_enforces_bound_and_exact_inputs(self) -> None:
        with self.assertRaises(HDContractError):
            factor_bounded_rational(Fraction(501), maximum_component=500)
        with self.assertRaises(HDContractError):
            factor_bounded_rational(Fraction(0), maximum_component=500)
        with self.assertRaises(HDContractError):
            factor_bounded_rational(1.5, maximum_component=500)  # type: ignore[arg-type]


class HDSignatureTests(unittest.TestCase):
    def test_sam_hd_coordinates(self) -> None:
        expected = {
            Fraction(4): (1, 2, 0, Fraction(1)),
            Fraction(12): (1, 2, 1, Fraction(1)),
            Fraction(18): (1, 1, 2, Fraction(1)),
            Fraction(18, 12): (1, -1, 1, Fraction(1)),
            Fraction(9, 8): (1, -3, 2, Fraction(1)),
        }
        for value, coordinates in expected.items():
            signature = HDSignature.from_rational(value)
            self.assertEqual(
                (signature.sign, signature.v2, signature.v3, signature.coprime_cofactor),
                coordinates,
            )
            self.assertEqual(signature.value, value)
            self.assertEqual(
                signature.formal_log,
                FormalLogElement.from_positive_rational(value),
            )

    def test_coprime_cofactor_and_sign_are_retained(self) -> None:
        signature = HDSignature.from_rational(Fraction(-70, 33))
        self.assertEqual(signature.sign, -1)
        self.assertEqual(signature.v2, 1)
        self.assertEqual(signature.v3, -1)
        self.assertEqual(signature.coprime_cofactor, Fraction(35, 11))
        self.assertEqual(signature.value, Fraction(-70, 33))

    def test_exact_multiply_divide_and_formal_log_laws(self) -> None:
        hd4 = HDSignature.from_rational(4)
        hd12 = HDSignature.from_rational(12)
        hd18 = HDSignature.from_rational(18)
        quotient = hd18 / hd12

        self.assertEqual(quotient, HDSignature.from_rational(Fraction(18, 12)))
        self.assertEqual(hd12 * quotient, hd18)
        self.assertEqual((hd4 * hd18).value, Fraction(72))
        self.assertEqual((hd4 * hd18).formal_log, hd4.formal_log + hd18.formal_log)
        self.assertEqual(quotient.formal_log, hd18.formal_log - hd12.formal_log)

    def test_zero_is_a_distinct_variant(self) -> None:
        zero = HDSignature.from_rational(0)
        nonzero = HDSignature.from_rational(1)
        self.assertTrue(zero.is_zero)
        self.assertEqual(zero.to_dict(), {"schema": "SLC_HD_SIGNATURE_V1", "variant": "ZERO"})
        self.assertEqual(zero * nonzero, zero)
        self.assertEqual(zero / nonzero, zero)
        with self.assertRaises(ZeroDivisionError):
            nonzero / zero
        with self.assertRaises(HDContractError):
            _ = zero.formal_log

    def test_hd_strict_serialization(self) -> None:
        for value in (Fraction(0), Fraction(-70, 33), Fraction(9, 8)):
            signature = HDSignature.from_rational(value)
            self.assertEqual(HDSignature.from_dict(signature.to_dict()), signature)

        invalid_zero = HDSignature.zero().to_dict()
        invalid_zero["v2"] = 8
        with self.assertRaises(HDContractError):
            HDSignature.from_dict(invalid_zero)

        invalid_cofactor = HDSignature.from_rational(Fraction(35, 11)).to_dict()
        invalid_cofactor["coprime_cofactor"] = {"numerator": 70, "denominator": 22}
        with self.assertRaises(HDContractError):
            HDSignature.from_dict(invalid_cofactor)

    def test_direct_noncanonical_signatures_reject(self) -> None:
        with self.assertRaises(HDContractError):
            HDSignature("NONZERO", 0, 0, 0, Fraction(1))
        with self.assertRaises(HDContractError):
            HDSignature("NONZERO", 1, 0, 0, Fraction(5, 6))
        with self.assertRaises(HDContractError):
            HDSignature("ZERO", 0, None, None, None)
        with self.assertRaises(HDContractError):
            HDSignature.from_rational(Fraction(1, 2) + 0.0)  # type: ignore[arg-type]


if __name__ == "__main__":
    unittest.main()
