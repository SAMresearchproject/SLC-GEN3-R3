from __future__ import annotations

import unittest
from fractions import Fraction

from slc_custody.hd import FormalLogElement
from slc_custody.information import (
    ExactDistribution,
    ExactPrefixCode,
    InformationPartition,
    ReceiptChannel,
    ReceiptSystem,
    uniform_conditional_entropy_from_fiber_sizes,
)


class InformationPartitionTests(unittest.TestCase):
    def test_partition_identity_ignores_observable_label_names(self) -> None:
        domain = ("x+", "x-", "z+", "z-")
        first = InformationPartition.from_map(
            "first", domain, {"x+": "x", "x-": "x", "z+": "z", "z-": "z"}
        )
        renamed = InformationPartition.from_map(
            "renamed", domain, {"x+": 8, "x-": 8, "z+": 9, "z-": 9}
        )
        discrete = InformationPartition.from_map("source", domain, lambda item: item)
        self.assertTrue(first.equivalent(renamed))
        self.assertEqual(first.mathematical_id, renamed.mathematical_id)
        self.assertTrue(discrete.refines(first))
        self.assertFalse(first.refines(discrete))
        self.assertEqual(first.fiber_sizes, (2, 2))
        self.assertEqual(first.worst_container_bits, 1)

    def test_strict_exact_identity_rejects_float_labels(self) -> None:
        with self.assertRaises(TypeError):
            InformationPartition.from_map("bad", ("a", "b"), {"a": 0.5, "b": 1.5})


class ExactDistributionTests(unittest.TestCase):
    def test_uniform_fiber_count_formula_is_exact_prime_log_vector(self) -> None:
        entropy = uniform_conditional_entropy_from_fiber_sizes((1, 2, 3))
        expected = FormalLogElement.from_terms(
            ((2, Fraction(1, 3)), (3, Fraction(1, 2)))
        )
        self.assertEqual(entropy, expected)
        self.assertEqual(
            uniform_conditional_entropy_from_fiber_sizes((1, 1, 1)),
            FormalLogElement.zero(),
        )
        with self.assertRaises(ValueError):
            uniform_conditional_entropy_from_fiber_sizes((1, 0))

    def test_nonuniform_source_law_has_exact_provenance_and_entropy(self) -> None:
        law = ExactDistribution.from_weights(
            {"a": 1, "b": 3}, provenance="DECLARED_NONUNIFORM_TEST_LAW"
        )
        expected = FormalLogElement.from_terms(((2, 2), (3, Fraction(-3, 4))))
        self.assertEqual(law.probabilities, (Fraction(1, 4), Fraction(3, 4)))
        self.assertEqual(law.source_entropy, expected)
        self.assertEqual(law.provenance, "DECLARED_NONUNIFORM_TEST_LAW")

    def test_float_probability_and_weight_are_rejected(self) -> None:
        with self.assertRaises(TypeError):
            ExactDistribution(("a", "b"), (Fraction(1, 2), 0.5), "bad")
        with self.assertRaises(TypeError):
            ExactDistribution.from_weights(
                {"a": 1.0, "b": 1}, provenance="bad float weight"
            )

    def test_legacy_prime_log_boundary_rejects_lossy_values(self) -> None:
        from slc_custody.algebra import (
            PrimeLogWeight,
            SymbolicEntropy,
            factor_positive_integer,
        )

        with self.assertRaises(TypeError):
            factor_positive_integer(2.0)
        with self.assertRaises(TypeError):
            PrimeLogWeight.from_multiplicity(2.0)
        with self.assertRaises(TypeError):
            SymbolicEntropy.from_terms({2: 0.5})
        with self.assertRaises(TypeError):
            SymbolicEntropy.from_terms({2.0: Fraction(1)})


class ReceiptCustodyTests(unittest.TestCase):
    def setUp(self) -> None:
        self.domain = ((0, 0), (0, 1), (1, 0), (1, 1))
        self.visible = InformationPartition.from_map(
            "visible_collision", self.domain, lambda _item: "same"
        )
        self.bit_a = InformationPartition.from_map(
            "bit_a", self.domain, lambda item: item[0]
        )
        self.bit_b = InformationPartition.from_map(
            "bit_b", self.domain, lambda item: item[1]
        )
        self.parity = InformationPartition.from_map(
            "parity", self.domain, lambda item: (item[0] + item[1]) % 2
        )
        self.system = ReceiptSystem(
            self.visible,
            (
                ReceiptChannel("a", self.bit_a),
                ReceiptChannel("b", self.bit_b),
                ReceiptChannel("parity", self.parity),
            ),
        )
        self.uniform = ExactDistribution.uniform(
            self.domain, provenance="UNIFORM_FOUR_HISTORY_CONTROL"
        )

    def test_minimum_sufficient_receipt_and_uncomputation(self) -> None:
        certificate = self.system.minimum_sufficient_channels()
        self.assertEqual(certificate.selected_channels, ("a", "b"))
        self.assertEqual(certificate.redundant_channels, ("parity",))
        self.assertTrue(certificate.sufficient_subset_exists)
        self.assertTrue(certificate.exact_minimum)
        self.assertTrue(certificate.reconstructs_source)
        plan = self.system.uncomputation_plan()
        self.assertEqual(plan["status"], "CERTIFIED_INFORMATION_RECOVERABLE")
        self.assertEqual(plan["logical_erasure_exact_nats"]["expression"], "0")
        self.assertTrue(plan["all_released_channels_recoverable"])

    def test_verified_greedy_fallback_reconstructs_without_minimum_claim(self) -> None:
        certificate = self.system.verified_greedy_sufficient_channels()
        self.assertTrue(certificate.reconstructs_source)
        self.assertTrue(certificate.sufficient_subset_exists)
        self.assertFalse(certificate.exact_minimum)
        self.assertEqual(
            self.system.augmented(certificate.selected_channels).is_discrete,
            True,
        )

    def test_information_chain_rule_and_ln2_reciprocal_case(self) -> None:
        reciprocal_domain = ("x+", "x-")
        visible = InformationPartition.from_map(
            "visible", reciprocal_domain, lambda _item: "x"
        )
        sign = InformationPartition.from_map(
            "antisymmetric_receipt", reciprocal_domain, lambda item: item[-1]
        )
        system = ReceiptSystem(visible, (ReceiptChannel("sign", sign),))
        law = ExactDistribution.uniform(
            reciprocal_domain, provenance="EQUIPROBABLE_RECIPROCAL_FIBER"
        )
        identity = system.information_identity(law, ("sign",))
        self.assertTrue(identity["identity_exact"])
        self.assertTrue(identity["augmented_injective"])
        self.assertEqual(identity["hidden"]["expression"], "ln(2)")
        self.assertEqual(identity["retained"]["expression"], "ln(2)")
        self.assertEqual(identity["remaining"]["expression"], "0")

    def test_exact_data_processing_and_submodularity(self) -> None:
        upstream = self.system.augmented(("a", "b"))
        downstream = self.visible.combined(self.parity, name="visible_plus_parity")
        self.assertTrue(upstream.refines(downstream))
        certificate = self.system.data_processing_certificate(
            self.uniform, ("a", "b"), downstream
        )
        self.assertTrue(certificate["inequality_exact"])
        self.assertEqual(certificate["residual"]["expression"], "ln(2)")
        submodularity = self.system.submodularity_certificate(self.uniform)
        self.assertEqual(submodularity["status"], "PASS")
        self.assertEqual(submodularity["subset_pair_count"], 64)

    def test_absent_sufficient_receipt_is_reported_exactly(self) -> None:
        constant = InformationPartition.from_map(
            "constant", self.domain, lambda _item: 0
        )
        system = ReceiptSystem(
            self.visible, (ReceiptChannel("constant", constant),)
        )
        certificate = system.minimum_sufficient_channels()
        self.assertFalse(certificate.sufficient_subset_exists)
        self.assertFalse(certificate.exact_minimum)
        self.assertFalse(certificate.reconstructs_source)


class ExactPrefixCodeTests(unittest.TestCase):
    def test_huffman_code_uses_exact_expected_bits_and_shannon_bound(self) -> None:
        law = ExactDistribution.from_weights(
            {"a": 1, "b": 1, "c": 2}, provenance="TERNARY_PREFIX_CONTROL"
        )
        code = ExactPrefixCode.build(law)
        self.assertEqual(code.expected_bits, Fraction(3, 2))
        self.assertEqual(code.kraft_sum, 1)
        self.assertTrue(code.to_dict()["shannon_lower_bound_exact"])
        self.assertTrue(code.shannon_upper_residual_nats.is_zero)


if __name__ == "__main__":
    unittest.main()
