from __future__ import annotations

import unittest
from fractions import Fraction

from slc_custody.hd import FormalLogElement
from slc_custody.information import (
    ExactDistribution,
    InformationPartition,
    ReceiptChannel,
    ReceiptSystem,
)
from slc_custody.ledger import (
    COMMITTED_LOGICAL_ERASURE,
    NO_ERASURE_RECEIPTS_RETAINED,
    WOULD_ERASE_IF_COMMITTED,
    build_custody_annotation,
)


SOURCE_HASH = "1" * 64


def reciprocal_system() -> ReceiptSystem:
    domain = ("x+", "x-")
    visible = InformationPartition.from_map("visible", domain, lambda _item: "x")
    sign = InformationPartition.from_map("sign", domain, lambda item: item[-1])
    return ReceiptSystem(visible, (ReceiptChannel("antisymmetric", sign),))


def annotate(
    system: ReceiptSystem,
    *,
    source_item="x+",
    kept=("antisymmetric",),
    law=None,
    event=NO_ERASURE_RECEIPTS_RETAINED,
    orbit=2,
):
    return build_custody_annotation(
        source_operation_id="EXACT_WRITE_RECIPROCAL_FIXTURE",
        source_revision_and_hashes=(("SOURCE", SOURCE_HASH),),
        input_space="declared reciprocal history source",
        visible_projection_definition="forget antisymmetric history",
        receipt_system=system,
        source_item=source_item,
        retained_channels=kept,
        reciprocal_orbit_cardinality=orbit,
        common_anchor_status="RETAINED",
        probability_model=law,
        logical_event_status=event,
    )


class CustodyLedgerTests(unittest.TestCase):
    def test_uniform_reciprocal_receipt_holds_ln2_and_erases_zero(self) -> None:
        system = reciprocal_system()
        law = ExactDistribution.uniform(
            system.visible.domain, provenance="UNIFORM_RECIPROCAL_TEST"
        )
        row = annotate(system, law=law)
        self.assertEqual(row.visible_fiber_cardinality, 2)
        self.assertEqual(row.augmented_fiber_cardinality, 1)
        self.assertTrue(row.reconstructible)
        self.assertEqual(row.support_capacity.expression, "ln(2)")
        self.assertEqual(row.hidden_entropy.expression, "ln(2)")
        self.assertEqual(row.retained_information.expression, "ln(2)")
        self.assertTrue(row.remaining_information.is_zero)
        self.assertTrue(row.logical_erasure.is_zero)
        self.assertFalse(row.physical_reset_declared)
        self.assertEqual(row.thermodynamic_calibration_status, "UNASSIGNED")

    def test_nonuniform_binary_entropy_is_not_assigned_ln2(self) -> None:
        system = reciprocal_system()
        law = ExactDistribution.from_weights(
            {"x+": 1, "x-": 3}, provenance="NONUNIFORM_RECIPROCAL_TEST"
        )
        row = annotate(system, law=law)
        expected = FormalLogElement.from_terms(((2, 2), (3, Fraction(-3, 4))))
        self.assertEqual(row.hidden_entropy, expected)
        self.assertNotEqual(row.hidden_entropy.expression, "ln(2)")

    def test_committed_discard_is_erasure_but_projection_is_only_counterfactual(self) -> None:
        system = reciprocal_system()
        law = ExactDistribution.uniform(
            system.visible.domain, provenance="UNIFORM_RECIPROCAL_TEST"
        )
        hypothetical = annotate(
            system, kept=(), law=law, event=WOULD_ERASE_IF_COMMITTED
        )
        committed = annotate(
            system, kept=(), law=law, event=COMMITTED_LOGICAL_ERASURE
        )
        self.assertTrue(hypothetical.logical_erasure.is_zero)
        self.assertEqual(hypothetical.would_erase_if_committed.expression, "ln(2)")
        self.assertEqual(committed.logical_erasure.expression, "ln(2)")
        self.assertFalse(committed.reconstructible)

    def test_probability_free_partition_reports_support_not_entropy(self) -> None:
        system = reciprocal_system()
        row = annotate(system, law=None)
        serialized = row.to_dict()
        self.assertEqual(row.support_capacity.expression, "ln(2)")
        self.assertIsNone(row.hidden_entropy)
        self.assertEqual(
            serialized["hidden_entropy_exact_nats_or_UNASSIGNED"]["status"],
            "UNASSIGNED",
        )

    def test_bijective_and_fixed_orbit_have_zero_support_capacity(self) -> None:
        domain = ("fixed",)
        visible = InformationPartition.from_map("identity", domain, lambda item: item)
        system = ReceiptSystem(visible, ())
        law = ExactDistribution.uniform(domain, provenance="POINT_MASS")
        row = annotate(
            system, source_item="fixed", kept=(), law=law, orbit=1
        )
        self.assertEqual(row.reciprocal_orbit_cardinality, 1)
        self.assertTrue(row.support_capacity.is_zero)
        self.assertTrue(row.hidden_entropy.is_zero)

    def test_nonbinary_fiber_retains_actual_symbolic_capacity(self) -> None:
        domain = ("a", "b", "c")
        visible = InformationPartition.from_map("singular", domain, lambda _item: 0)
        system = ReceiptSystem(visible, ())
        row = build_custody_annotation(
            source_operation_id="SINGULAR_CONTROL",
            source_revision_and_hashes=(("SOURCE", SOURCE_HASH),),
            input_space="three state singular fiber",
            visible_projection_definition="constant map",
            receipt_system=system,
            source_item="a",
            retained_channels=(),
            reciprocal_orbit_cardinality=1,
            common_anchor_status="NOT_APPLICABLE",
            probability_model=None,
            logical_event_status=WOULD_ERASE_IF_COMMITTED,
        )
        self.assertEqual(row.visible_fiber_cardinality, 3)
        self.assertEqual(row.support_capacity.expression, "ln(3)")

    def test_erasure_charges_entropy_delta_not_preexisting_ambiguity(self) -> None:
        domain = (0, 1, 2, 3)
        visible = InformationPartition.from_map("visible", domain, lambda _item: 0)
        partial = InformationPartition.from_map(
            "partial", domain, lambda item: item // 2
        )
        system = ReceiptSystem(visible, (ReceiptChannel("partial", partial),))
        law = ExactDistribution.uniform(domain, provenance="UNIFORM_FOUR_STATE")
        row = build_custody_annotation(
            source_operation_id="PARTIAL_RECEIPT_CONTROL",
            source_revision_and_hashes=(("SOURCE", SOURCE_HASH),),
            input_space="four states with an incomplete generated receipt",
            visible_projection_definition="constant map",
            receipt_system=system,
            source_item=0,
            retained_channels=(),
            reciprocal_orbit_cardinality=1,
            common_anchor_status="NOT_APPLICABLE",
            probability_model=law,
            logical_event_status=COMMITTED_LOGICAL_ERASURE,
        )
        self.assertEqual(row.pre_event_remaining_information.expression, "ln(2)")
        self.assertEqual(row.remaining_information.expression, "2*ln(2)")
        self.assertEqual(row.logical_erasure.expression, "ln(2)")

    def test_physical_fields_cannot_be_smuggled_into_annotation(self) -> None:
        system = reciprocal_system()
        law = ExactDistribution.uniform(
            system.visible.domain, provenance="UNIFORM_RECIPROCAL_TEST"
        )
        row = annotate(system, law=law)
        with self.assertRaises(ValueError):
            type(row)(
                **{
                    field: getattr(row, field)
                    for field in row.__dataclass_fields__
                    if field not in {"physical_reset_declared"}
                },
                physical_reset_declared=True,
            )


if __name__ == "__main__":
    unittest.main()
