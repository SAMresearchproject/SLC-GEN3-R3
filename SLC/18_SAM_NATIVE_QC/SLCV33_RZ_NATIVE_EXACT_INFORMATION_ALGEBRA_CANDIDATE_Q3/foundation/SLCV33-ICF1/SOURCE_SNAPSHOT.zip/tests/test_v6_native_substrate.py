#!/usr/bin/env python3
"""Focused tests for the candidate-owned V6 native substrate surface."""

from __future__ import annotations

import json
import unittest
from fractions import Fraction
from pathlib import Path

from slc_custody.exact_write import CompleteExactWriteAdapter, EXPECTED_OPERATION_IDS
from slc_custody.hd import FormalLogElement
from slc_custody.native_substrate import (
    AFCTransportReference,
    AVAILABLE_DEPTHS,
    CANONICAL_TYPE_REGISTRY,
    CustodyAnnotation,
    ExactComposition,
    ExactDepthBlock,
    ExactWriteOperation,
    FormalLogMonoidElement,
    GramObject,
    LogicalErasureEvent,
    NativeExactSubstratePlane,
    NativeSourceSeal,
    NativeSubstrateContractError,
    PrimeValuationVector,
    ReceiptGraph,
    SupportObject,
    TensorOrbitObject,
    Theta18Report,
    VisibleFiber,
    W8State,
    W9History,
    W9P,
    canonical_round_trip,
)


class V6NativeSubstrateSurfaceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.adapter = CompleteExactWriteAdapter(Path(__file__))
        cls.plane = NativeExactSubstratePlane(cls.adapter)
        cls.operations = cls.plane.exact_write_operations()
        cls.depths = cls.plane.depth_blocks()

    def test_plane_is_hash_bound_without_copying_predecessor(self) -> None:
        surface = self.plane.to_dict()
        self.assertEqual(surface["status"], "CANDIDATE_UNINSTALLED")
        self.assertFalse(surface["mutation_allowed"])
        self.assertFalse(surface["predecessor_implementation_copied"])
        self.assertEqual(len(surface["source_seals"]), 3)
        self.assertEqual(
            self.plane.exact_write_source_seal.sha256,
            "8b54927924eebb617be29ba69b299ca5144cc52a4214119d7bae6ca19311aa14",
        )
        self.assertEqual(
            self.plane.depth_interface_seal.sha256,
            "3621c73a2acb2f2ab8d80908162fbfc82a53661345ddf73e9be5917ee2bedfbd",
        )

    def test_all_19_operation_descriptors_have_executed_typed_fixtures(self) -> None:
        self.assertEqual(len(self.operations), 19)
        self.assertEqual(
            tuple(operation.operation_id for operation in self.operations),
            EXPECTED_OPERATION_IDS,
        )
        self.assertTrue(all(operation.law_holds for operation in self.operations))
        self.assertTrue(
            all(operation.source_seal == self.plane.exact_write_source_seal for operation in self.operations)
        )

    def test_operation_fixtures_round_trip_without_float_authority(self) -> None:
        for operation in self.operations:
            with self.subTest(operation=operation.operation_id):
                self.assertEqual(canonical_round_trip(operation), operation)
                serialized = json.dumps(operation.to_dict(), sort_keys=True)
                self.assertNotIn("NaN", serialized)
                self.assertNotIn("Infinity", serialized)
        readback = next(
            operation
            for operation in self.operations
            if operation.operation_id == "MULTIPLICATIVE_LEDGER_READBACK"
        )
        self.assertEqual(readback.inverse_status, "TYPED_NONINVERTIBILITY_VERIFIED")
        self.assertIsNone(readback.fixture_output["recovered_write_state"])

    def test_w8_state_reconstructs_exact_shell(self) -> None:
        state = self.plane.w8_fixture()
        self.assertIsInstance(state, W8State)
        self.assertEqual(state.reconstruct_shell(), state.shell_state)
        self.assertEqual(canonical_round_trip(state), state)

    def test_w9p_and_w9_history_retain_ordered_receipts(self) -> None:
        history = self.plane.w9_history_fixture()
        self.assertIsInstance(history, W9History)
        self.assertTrue(all(isinstance(record, W9P) for record in history.records))
        self.assertEqual(history.reconstruct_shell_history(), (11, 7))
        self.assertEqual(canonical_round_trip(history), history)
        self.assertEqual(canonical_round_trip(history.records[0]), history.records[0])

    def test_visible_fiber_has_working_receipt_inverse(self) -> None:
        fiber = self.plane.visible_fiber_fixture()
        self.assertIsInstance(fiber, VisibleFiber)
        self.assertEqual(fiber.cardinality, 2)
        self.assertEqual(fiber.inverse_status, "EXACT_RECEIPT_INVERSE")
        negative = fiber.reconstruct("NEGATIVE_ORIENTATION")
        positive = fiber.reconstruct("POSITIVE_ORIENTATION")
        self.assertNotEqual(negative, positive)
        self.assertEqual(negative["projected_w8"], positive["projected_w8"])
        self.assertEqual(canonical_round_trip(fiber), fiber)

    def test_visible_only_fiber_types_noninvertibility(self) -> None:
        fiber = VisibleFiber.create(
            domain_space="TwoState",
            codomain_space="OneState",
            visible_value="merged",
            source_points=("left", "right"),
            source_seal=self.plane.exact_write_source_seal,
        )
        self.assertEqual(fiber.inverse_status, "TYPED_VISIBLE_NONINVERTIBILITY")
        with self.assertRaises(NativeSubstrateContractError):
            fiber.reconstruct("missing")

    def test_receipt_graph_executes_and_reconstructs(self) -> None:
        graph = self.plane.receipt_graph_fixture()
        self.assertIsInstance(graph, ReceiptGraph)
        for address in (0, 1, 17, 65_535, (1 << 18) - 1):
            output = graph.execute(self.adapter, address)
            self.assertEqual(graph.reconstruct(self.adapter, output), address)
        self.assertEqual(canonical_round_trip(graph), graph)

    def test_afc_transport_reference_is_exactly_invertible(self) -> None:
        reference = self.plane.afc_transport_fixture()
        self.assertIsInstance(reference, AFCTransportReference)
        self.assertEqual(reference.transport(self.adapter), reference.address_after)
        self.assertEqual(reference.reconstruct_before(self.adapter), reference.address_before)
        self.assertEqual(canonical_round_trip(reference), reference)

    def test_theta18_report_reconstructs_packed_address(self) -> None:
        report = self.plane.theta18_fixture()
        self.assertIsInstance(report, Theta18Report)
        self.assertEqual(len(report.coordinates), 9)
        self.assertEqual(report.reconstruct_address(), report.address)
        self.assertEqual(canonical_round_trip(report), report)

    def test_support_object_reconstructs_exact_sparse_vector(self) -> None:
        support = self.plane.support_fixture()
        self.assertIsInstance(support, SupportObject)
        vector = support.reconstruct_vector()
        self.assertEqual(len(vector), support.dimension)
        self.assertEqual(
            tuple(index for index, value in enumerate(vector) if value),
            support.support_indices,
        )
        self.assertEqual(canonical_round_trip(support), support)

    def test_gram_object_is_exact_and_recomputable(self) -> None:
        gram = self.plane.gram_fixture()
        self.assertIsInstance(gram, GramObject)
        self.assertTrue(gram.is_symmetric)
        self.assertTrue(all(isinstance(value, Fraction) for row in gram.gram_matrix for value in row))
        self.assertEqual(canonical_round_trip(gram), gram)

    def test_tensor_orbit_has_exact_inverse_action(self) -> None:
        tensor = self.plane.tensor_orbit_fixture()
        self.assertIsInstance(tensor, TensorOrbitObject)
        for index in range(len(tensor.seed)):
            point = tensor.seed[index:] + tensor.seed[:index]
            self.assertEqual(tensor.inverse_action(index, point), tensor.seed)
        self.assertEqual(canonical_round_trip(tensor), tensor)

    def test_all_d1_d27_d81_d162_services_execute(self) -> None:
        self.assertEqual(len(self.depths), 29)
        self.assertEqual(tuple(block.depth for block in self.depths), AVAILABLE_DEPTHS)
        self.assertTrue(all(isinstance(block, ExactDepthBlock) for block in self.depths))
        self.assertTrue(all(block.history_reconstructs for block in self.depths))
        self.assertEqual(self.depths[-2].composition, (27, 27, 27))
        self.assertEqual(self.depths[-1].composition, (81, 81))
        self.assertTrue(all(block.following_state[3] == block.depth for block in self.depths))

    def test_depth_receipts_round_trip_and_reconstruct_prior(self) -> None:
        for block in self.depths:
            with self.subTest(depth=block.depth):
                self.assertEqual(block.reconstruct_prior(), (127, 3, 5, 0))
                self.assertEqual(canonical_round_trip(block), block)

    def test_exact_composition_executes_and_inverts(self) -> None:
        composition = self.plane.composition_fixture()
        self.assertIsInstance(composition, ExactComposition)
        output = composition.execute(self.adapter, 177_171)
        self.assertEqual(composition.reconstruct(self.adapter, output), 177_171)
        self.assertEqual(canonical_round_trip(composition), composition)

    def test_prime_valuation_vector_composes_and_reconstructs(self) -> None:
        vector = self.plane.prime_valuation_fixture()
        self.assertIsInstance(vector, PrimeValuationVector)
        self.assertEqual(vector.rational_value, 18)
        self.assertEqual(vector.valuations, ((2, 1), (3, 2)))
        self.assertEqual(canonical_round_trip(vector), vector)

    def test_formal_log_monoid_composes_symbolically(self) -> None:
        element = self.plane.formal_log_fixture()
        self.assertIsInstance(element, FormalLogMonoidElement)
        self.assertEqual(element.value, FormalLogElement.from_positive_rational(18))
        self.assertEqual(element.value.expression, "ln(2) + 2*ln(3)")
        self.assertEqual(canonical_round_trip(element), element)

    def test_custody_annotation_closes_ln2_equals_ln2_plus_zero(self) -> None:
        annotation = self.plane.custody_fixture()
        self.assertIsInstance(annotation, CustodyAnnotation)
        ln2 = FormalLogElement.from_positive_rational(2)
        self.assertEqual(annotation.hidden_information.value, ln2)
        self.assertEqual(annotation.retained_information.value, ln2)
        self.assertTrue(annotation.logical_erasure.value.is_zero)
        self.assertTrue(annotation.reconstructible)
        self.assertEqual(canonical_round_trip(annotation), annotation)

    def test_logical_event_distinguishes_retention_from_destruction(self) -> None:
        retained, destroyed = self.plane.logical_erasure_fixtures()
        self.assertIsInstance(retained, LogicalErasureEvent)
        self.assertTrue(retained.reconstructs_source_after)
        self.assertTrue(retained.erased_information.value.is_zero)
        self.assertEqual(retained.inverse_status, "EXACT_RECEIPT_INVERSE")
        self.assertFalse(destroyed.reconstructs_source_after)
        self.assertEqual(
            destroyed.erased_information.value,
            FormalLogElement.from_positive_rational(2),
        )
        self.assertEqual(destroyed.inverse_status, "TYPED_NONINVERTIBILITY_EVENT")
        self.assertIsNone(destroyed.to_dict()["physical_temperature"])
        self.assertIsNone(destroyed.to_dict()["realized_heat_claim"])
        self.assertEqual(canonical_round_trip(retained), retained)
        self.assertEqual(canonical_round_trip(destroyed), destroyed)

    def test_every_registered_canonical_type_has_a_round_trip_fixture(self) -> None:
        fixtures = self.plane.canonical_fixtures()
        represented = {type(fixture) for fixture in fixtures}
        represented.add(NativeSourceSeal)
        required = set(CANONICAL_TYPE_REGISTRY)
        self.assertEqual(represented, required)
        for fixture in fixtures:
            self.assertEqual(canonical_round_trip(fixture), fixture)
        self.assertEqual(
            canonical_round_trip(self.plane.exact_write_source_seal),
            self.plane.exact_write_source_seal,
        )

    def test_plane_serialization_round_trip_rebinds_frozen_services(self) -> None:
        rebuilt = NativeExactSubstratePlane.from_dict(self.plane.to_dict(), self.adapter)
        self.assertEqual(rebuilt.to_dict(), self.plane.to_dict())

    def test_plane_audit_passes_complete_type_operation_and_depth_rosters(self) -> None:
        audit = self.plane.audit()
        self.assertEqual(audit["status"], "PASS")
        self.assertEqual(audit["operation_count"], 19)
        self.assertEqual(audit["operation_fixtures_passed"], 19)
        self.assertEqual(audit["depth_service_count"], 29)
        self.assertEqual(audit["round_trip_failure_count"], 0)
        self.assertFalse(audit["predecessor_implementation_copied"])

    def test_strict_boundaries_reject_float_bool_and_noncanonical_payloads(self) -> None:
        with self.assertRaises(NativeSubstrateContractError):
            W8State(True, (0,) * 8, self.plane.exact_write_source_seal)  # type: ignore[arg-type]
        with self.assertRaises(NativeSubstrateContractError):
            ExactWriteOperation.create(
                operation_id="FLOAT_REJECTION",
                domain_space="Q",
                codomain_space="Q",
                exact_law="identity",
                reconstruction_contract="identity",
                inverse_status="EXACT_INVERSE_VERIFIED",
                fixture_input={"value": 0.5},
                fixture_output={"value": 0.5},
                law_holds=True,
                source_seal=self.plane.exact_write_source_seal,
            )
        with self.assertRaises(NativeSubstrateContractError):
            PrimeValuationVector.from_rational(
                2.0, source_provenance="FLOAT_REJECTED"  # type: ignore[arg-type]
            )
        with self.assertRaises(NativeSubstrateContractError):
            FormalLogMonoidElement.from_positive_rational(
                2.0, source_provenance="FLOAT_REJECTED"  # type: ignore[arg-type]
            )

    def test_tampered_serializations_and_unregistered_types_reject(self) -> None:
        seal = self.plane.exact_write_source_seal.to_dict()
        seal["sha256"] = str(seal["sha256"]).upper()
        with self.assertRaises(NativeSubstrateContractError):
            NativeSourceSeal.from_dict(seal)

        graph = self.plane.receipt_graph_fixture().to_dict()
        graph["inverse_status"] = "FABRICATED_INVERSE"
        with self.assertRaises(NativeSubstrateContractError):
            ReceiptGraph.from_dict(graph)

        event = self.plane.logical_erasure_fixtures()[1].to_dict()
        event["physical_temperature"] = 300
        with self.assertRaises(NativeSubstrateContractError):
            LogicalErasureEvent.from_dict(event)

        with self.assertRaises(TypeError):
            canonical_round_trip({"not": "registered"})

    def test_inconsistent_gram_and_unavailable_depth_reject(self) -> None:
        seal = self.plane.exact_write_source_seal
        with self.assertRaises(NativeSubstrateContractError):
            GramObject(
                ambient_space="Q^2",
                vectors=((Fraction(1), Fraction(0)),),
                gram_matrix=((Fraction(2),),),
                source_seal=seal,
            )
        with self.assertRaises(NativeSubstrateContractError):
            ExactDepthBlock(
                depth=28,
                composition=(28,),
                prior_state=(127, 3, 5, 0),
                following_state=(127, 3, 5, 28),
                history_reconstructs=True,
                receipt_semantic_sha256="0" * 64,
                source_seal=self.plane.depth_implementation_seal,
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
