from __future__ import annotations

from dataclasses import replace
from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from slc_custody.exact_write import CompleteExactWriteAdapter  # noqa: E402
from slc_custody.operation_graph import (  # noqa: E402
    ExactWriteTranslationGraph,
    ledger_invertibility_witness,
)


class OperationGraphTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.adapter = CompleteExactWriteAdapter(Path(__file__))

    def test_associative_reordering_has_one_canonical_group_identity(self) -> None:
        first = ExactWriteTranslationGraph(
            self.adapter, ((0, 1), (3, -1), (0, 1), (8, 1))
        )
        reordered = ExactWriteTranslationGraph(
            self.adapter, ((8, 1), (0, 1), (0, 1), (3, -1))
        )
        self.assertEqual(first.compiled_translation, reordered.compiled_translation)
        self.assertEqual(first.graph_id, reordered.graph_id)
        self.assertNotEqual(first.receipt.receipt_id, reordered.receipt.receipt_id)

    def test_reference_compiled_and_inverse_reconstruction_match(self) -> None:
        graph = ExactWriteTranslationGraph(
            self.adapter, ((0, 1), (4, -1), (0, -1), (7, 1))
        )
        audit = graph.audit((0, 1, 17, 4095, (1 << 18) - 1))
        self.assertEqual(audit["status"], "PASS")
        self.assertEqual(audit["failure_count"], 0)
        self.assertEqual(len(audit["sequential_nodes"]), 4)

    def test_normal_form_receipt_releases_history_without_source_erasure(self) -> None:
        graph = ExactWriteTranslationGraph(
            self.adapter,
            ((0, 1), (4, -1), (0, -1), (7, 1), (8, 1), (8, -1)),
        )
        addresses = (0, 1, 17, 4095, (1 << 18) - 1)
        certificate = graph.custody_compilation_certificate(addresses)
        self.assertEqual(certificate["status"], "PASS_ZERO_SOURCE_ERASURE")
        self.assertTrue(certificate["source_address_reconstructible"])
        self.assertFalse(
            certificate["sequential_program_history_reconstructible_after_release"]
        )
        self.assertEqual(
            certificate["full_history_plus_normal_form_container_bits"], 48
        )
        self.assertEqual(certificate["final_normal_form_container_bits"], 18)
        self.assertEqual(certificate["released_temporary_container_bits"], 30)
        for address in addresses:
            final = graph.execute_compiled(address)
            self.assertEqual(
                graph.reconstruct_input_from_normal_form(
                    final, graph.normal_form_receipt
                ),
                address,
            )

    def test_foreign_or_mutated_history_receipt_rejects(self) -> None:
        graph = ExactWriteTranslationGraph(self.adapter, ((1, 1), (2, -1)))
        foreign = ExactWriteTranslationGraph(self.adapter, ((1, 1),))
        final = graph.execute_compiled(19)
        with self.assertRaises(ValueError):
            graph.reconstruct_input(final, foreign.receipt)
        with self.assertRaises(ValueError):
            graph.reconstruct_input(
                final,
                replace(graph.receipt, receipt_id="0" * 64),
            )

    def test_ledger_noninvertibility_is_a_typed_witness(self) -> None:
        witness = ledger_invertibility_witness(
            self.adapter, write_state=5, ledger_state=6, modulus=12
        )
        self.assertEqual(witness["inverse_status"], "NONINVERTIBLE_WITNESS")
        self.assertIsNone(witness["recovered_write_state"])
        self.assertTrue(witness["noninvertibility_is_typed"])


if __name__ == "__main__":
    unittest.main()
