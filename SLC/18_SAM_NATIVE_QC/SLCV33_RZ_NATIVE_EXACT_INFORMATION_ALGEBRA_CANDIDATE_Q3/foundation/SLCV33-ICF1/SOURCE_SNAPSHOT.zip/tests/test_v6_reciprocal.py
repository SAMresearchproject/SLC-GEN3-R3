from __future__ import annotations

from fractions import Fraction
from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from slc_custody.exact_write import CompleteExactWriteAdapter  # noqa: E402
from slc_custody.reciprocal import (  # noqa: E402
    ReciprocalHistoryLift,
    ReciprocalOrbit,
    census_reciprocal_map,
    reciprocal_involution,
    reciprocal_visible_map,
)


class ReciprocalFiberTests(unittest.TestCase):
    def test_involution_covariance_and_fixed_point(self) -> None:
        pair = (5, 17)
        partner = reciprocal_involution(pair, 127)
        self.assertEqual(reciprocal_involution(partner, 127), pair)
        self.assertEqual(
            reciprocal_visible_map(pair, 127),
            reciprocal_visible_map(partner, 127),
        )
        fixed = ReciprocalOrbit.containing((0, 0), 127)
        ordinary = ReciprocalOrbit.containing(pair, 127)
        self.assertTrue(fixed.fixed_point)
        self.assertEqual(fixed.cardinality, 1)
        self.assertFalse(ordinary.fixed_point)
        self.assertEqual(ordinary.cardinality, 2)

    def test_modulus_127_predecessor_census_reproduces_and_generalizes_receipts(self) -> None:
        census = census_reciprocal_map(127)
        self.assertEqual(census.input_count, 127 * 127)
        self.assertEqual(census.visible_fiber_histogram, ((2, 8001), (127, 1)))
        self.assertEqual(census.reciprocal_orbit_histogram, ((1, 1), (2, 8064)))
        self.assertTrue(census.reciprocal_covariance)
        self.assertTrue(census.augmented_map_injective)
        self.assertEqual(
            census.minimum_sufficient_channels,
            ("ANTISYMMETRIC_BRANCH", "RECIPROCAL_ORBIT_IDENTITY"),
        )

    def test_even_modulus_has_actual_fixed_orbits_not_forced_binary(self) -> None:
        census = census_reciprocal_map(4)
        self.assertEqual(dict(census.reciprocal_orbit_histogram)[1], 4)
        self.assertTrue(census.augmented_map_injective)


class ReciprocalHistoryLiftTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.adapter = CompleteExactWriteAdapter(Path(__file__))

    def test_symmetric_next_state_and_antisymmetric_incoming_state(self) -> None:
        lift = ReciprocalHistoryLift.build(
            self.adapter,
            prior_common=7,
            prior_directional=-3,
            next_common=11,
            next_directional=5,
        )
        self.assertEqual(
            lift.symmetric[:4],
            (Fraction(0), Fraction(0), Fraction(22), Fraction(10)),
        )
        self.assertEqual(
            lift.antisymmetric[:4],
            (Fraction(14), Fraction(-6), Fraction(0), Fraction(0)),
        )
        self.assertEqual(len(lift.quotient_coordinates), 161)
        self.assertTrue(lift.reconstructs)
        receipt = lift.to_dict()
        self.assertTrue(receipt["common_next_state_is_symmetric"])
        self.assertTrue(receipt["incoming_reciprocal_distinction_is_antisymmetric"])
        self.assertTrue(receipt["quotient_plus_anchor_reconstructs"])


if __name__ == "__main__":
    unittest.main()
