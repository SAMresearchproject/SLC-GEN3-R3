from __future__ import annotations

from fractions import Fraction
from pathlib import Path
import sys
import unittest


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from slc_custody.hd import FormalLogElement  # noqa: E402
from slc_custody.information import (  # noqa: E402
    ExactDistribution,
    InformationPartition,
    ReceiptChannel,
    ReceiptSystem,
)
from slc_custody.thermodynamics import (  # noqa: E402
    LandauerLowerBoundReceipt,
    LogicalResetEvent,
    PhysicalResetCalibration,
    ThermodynamicsContractError,
    landauer_lower_bound,
)


def binary_receipt_system() -> tuple[ReceiptSystem, ExactDistribution]:
    domain = ("x_minus", "x_plus")
    visible = InformationPartition.from_map(
        "visible_collision", domain, {item: "y" for item in domain}
    )
    history = InformationPartition.from_map(
        "antisymmetric_history", domain, {item: item for item in domain}
    )
    system = ReceiptSystem(
        visible,
        (ReceiptChannel("ANTISYMMETRIC_HISTORY", history),),
    )
    law = ExactDistribution.uniform(
        domain, provenance="DECLARED_UNIFORM_RECIPROCAL_ORBIT"
    )
    return system, law


class LogicalResetTests(unittest.TestCase):
    def test_reversible_exact_write_has_zero_erasure_and_bound(self) -> None:
        event = LogicalResetEvent.reversible_exact_write(
            "WRITE_RETAINED",
            retained_channels=("ANTISYMMETRIC_HISTORY", "COMMON_ANCHOR"),
            source_law_provenance="DECLARED_UNIFORM_RECIPROCAL_ORBIT",
        )
        receipt = landauer_lower_bound(event)
        self.assertTrue(event.reconstructs_source_before_event)
        self.assertTrue(event.reconstructs_source_after_event)
        self.assertTrue(event.erased_information.is_zero)
        self.assertEqual(receipt.status, "ZERO_REVERSIBLE_LOWER_BOUND")
        self.assertEqual(receipt.exact_lower_bound_joules, "0 J")
        self.assertIsNone(receipt.temperature_kelvin)
        self.assertFalse(receipt.realized_heat_claimed)

    def test_receipt_system_binary_destruction_is_exact_ln2(self) -> None:
        system, law = binary_receipt_system()
        event = LogicalResetEvent.from_receipt_system(
            "DESTROY_HISTORY",
            system,
            law,
            destroyed_channels=("ANTISYMMETRIC_HISTORY",),
            irreversible_destruction_declared=True,
        )
        self.assertTrue(event.reconstructs_source_before_event)
        self.assertFalse(event.reconstructs_source_after_event)
        self.assertEqual(
            event.erased_information,
            FormalLogElement.from_positive_rational(2),
        )
        logical_only = landauer_lower_bound(event)
        self.assertEqual(
            logical_only.status,
            "LOGICAL_ERASURE_PHYSICAL_CALIBRATION_ABSENT",
        )
        self.assertIsNone(logical_only.exact_lower_bound_joules)

    def test_retained_receipt_system_reconstructs_and_stays_zero(self) -> None:
        system, law = binary_receipt_system()
        event = LogicalResetEvent.from_receipt_system(
            "KEEP_HISTORY",
            system,
            law,
            destroyed_channels=(),
            irreversible_destruction_declared=False,
        )
        self.assertTrue(event.reconstructs_source_after_event)
        self.assertTrue(event.erased_information.is_zero)
        self.assertEqual(landauer_lower_bound(event).exact_lower_bound_joules, "0 J")

    def test_uniform_m_uses_ln_m_only_after_declared_destruction(self) -> None:
        event = LogicalResetEvent.uniform_irreversible_destruction(
            "DESTROY_ROSTER",
            12,
            destroyed_channels=("ROSTER_IDENTITY",),
            source_law_provenance="DECLARED_UNIFORM_TWELVE_STATE_ROSTER",
        )
        self.assertEqual(
            event.erased_information,
            FormalLogElement.from_positive_rational(12),
        )
        self.assertEqual(event.erased_information.expression, "2*ln(2) + ln(3)")

    def test_nonuniform_binary_source_is_not_renamed_ln2(self) -> None:
        system, _uniform = binary_receipt_system()
        law = ExactDistribution.from_weights(
            {"x_minus": 1, "x_plus": 3},
            provenance="DECLARED_NONUNIFORM_BINARY_SOURCE_1_TO_3",
        )
        event = LogicalResetEvent.from_receipt_system(
            "DESTROY_NONUNIFORM_HISTORY",
            system,
            law,
            destroyed_channels=("ANTISYMMETRIC_HISTORY",),
            irreversible_destruction_declared=True,
        )
        expected = FormalLogElement.from_coefficients(
            {2: Fraction(2), 3: Fraction(-3, 4)}
        )
        self.assertEqual(event.erased_information, expected)
        self.assertNotEqual(
            event.erased_information,
            FormalLogElement.from_positive_rational(2),
        )

    def test_destroying_redundant_channel_can_have_zero_logical_erasure(self) -> None:
        domain = (0, 1)
        visible = InformationPartition.from_map("visible", domain, {0: 0, 1: 0})
        first = InformationPartition.from_map("first", domain, {0: 0, 1: 1})
        duplicate = InformationPartition.from_map("duplicate", domain, {0: "a", 1: "b"})
        system = ReceiptSystem(
            visible,
            (
                ReceiptChannel("FIRST", first),
                ReceiptChannel("REDUNDANT_COPY", duplicate),
            ),
        )
        law = ExactDistribution.uniform(domain, provenance="DECLARED_UNIFORM_BINARY")
        event = LogicalResetEvent.from_receipt_system(
            "DESTROY_REDUNDANT",
            system,
            law,
            destroyed_channels=("REDUNDANT_COPY",),
            irreversible_destruction_declared=True,
        )
        self.assertTrue(event.reconstructs_source_after_event)
        self.assertTrue(event.erased_information.is_zero)
        self.assertEqual(landauer_lower_bound(event).exact_lower_bound_joules, "0 J")

    def test_destruction_charges_entropy_delta_not_preexisting_ambiguity(self) -> None:
        domain = (0, 1, 2, 3)
        visible = InformationPartition.from_map(
            "visible", domain, {item: "collision" for item in domain}
        )
        partial_receipt = InformationPartition.from_map(
            "partial_receipt", domain, {0: 0, 1: 0, 2: 1, 3: 1}
        )
        system = ReceiptSystem(
            visible,
            (ReceiptChannel("PARTIAL_RECEIPT", partial_receipt),),
        )
        law = ExactDistribution.uniform(
            domain, provenance="DECLARED_UNIFORM_FOUR_STATE_SOURCE"
        )
        event = LogicalResetEvent.from_receipt_system(
            "DESTROY_PARTIAL_RECEIPT",
            system,
            law,
            destroyed_channels=("PARTIAL_RECEIPT",),
            irreversible_destruction_declared=True,
        )
        self.assertFalse(event.reconstructs_source_before_event)
        self.assertFalse(event.reconstructs_source_after_event)
        self.assertEqual(
            event.erased_information,
            FormalLogElement.from_positive_rational(2),
        )


class PhysicalCalibrationTests(unittest.TestCase):
    def test_temperature_without_irreversible_reset_emits_no_calibrated_energy(self) -> None:
        event = LogicalResetEvent.reversible_exact_write(
            "RETAIN_RECEIPT",
            retained_channels=("OUTPUT", "RECEIPT"),
            source_law_provenance="DECLARED_REVERSIBLE_SOURCE",
        )
        calibration = PhysicalResetCalibration.create(
            "UNUSED_CALIBRATION",
            temperature_kelvin=300,
            provenance="DECLARED_TEMPERATURE_ONLY",
            reservoir_model="DECLARED_TEST_RESERVOIR",
            temperature_uncertainty_kelvin=0,
            reset_protocol="NO_RESET_OCCURRED",
            calibration_source="DECLARED_TEST_CALIBRATION_SOURCE",
        )
        receipt = landauer_lower_bound(event, calibration)
        self.assertEqual(receipt.status, "ZERO_REVERSIBLE_LOWER_BOUND")
        self.assertEqual(receipt.exact_lower_bound_joules, "0 J")
        self.assertIsNone(receipt.calibration_id)
        self.assertIsNone(receipt.temperature_kelvin)

    def test_calibration_is_separate_and_emits_only_symbolic_lower_bound(self) -> None:
        event = LogicalResetEvent.uniform_irreversible_destruction(
            "DESTROY_BIT",
            2,
            destroyed_channels=("BIT_RECEIPT",),
            source_law_provenance="DECLARED_UNIFORM_BIT",
        )
        calibration = PhysicalResetCalibration.create(
            "CAL_300K",
            temperature_kelvin=300,
            provenance="DECLARED_IDEAL_BATH_TEMPERATURE_NOT_HEAT_MEASUREMENT",
            reservoir_model="DECLARED_IDEAL_THERMAL_RESERVOIR",
            temperature_uncertainty_kelvin=0,
            reset_protocol="DECLARED_BIT_RESET_PROTOCOL",
            calibration_source="DECLARED_SYMBOLIC_CALIBRATION_SOURCE",
        )
        receipt = landauer_lower_bound(event, calibration)
        self.assertEqual(receipt.status, "IDEAL_LANDAUER_LOWER_BOUND")
        self.assertEqual(receipt.exact_lower_bound_joules, "k_B*300*(ln(2)) J")
        self.assertEqual(
            receipt.scaled_information,
            FormalLogElement.from_coefficients({2: Fraction(300)}),
        )
        self.assertEqual(
            receipt.calibration_provenance,
            "DECLARED_IDEAL_BATH_TEMPERATURE_NOT_HEAT_MEASUREMENT",
        )
        self.assertFalse(receipt.realized_heat_claimed)

    def test_fractional_temperature_is_exact(self) -> None:
        calibration = PhysicalResetCalibration.create(
            "CAL_HALF",
            temperature_kelvin=Fraction(3, 2),
            provenance="EXACT_SYMBOLIC_TEST",
            reservoir_model="DECLARED_EXACT_TEST_RESERVOIR",
            temperature_uncertainty_kelvin=Fraction(1, 100),
            reset_protocol="DECLARED_EXACT_TEST_RESET_PROTOCOL",
            calibration_source="DECLARED_EXACT_TEST_CALIBRATION_SOURCE",
        )
        self.assertEqual(calibration.symbolic_kbt_multiplier, "k_B*(3/2)")
        self.assertEqual(
            PhysicalResetCalibration.from_dict(calibration.to_dict()), calibration
        )
        serialized = calibration.to_dict()
        self.assertEqual(serialized["temperature_unit"], "K")
        self.assertEqual(
            serialized["temperature_uncertainty_kelvin"],
            {"numerator": 1, "denominator": 100},
        )
        self.assertIsNone(serialized["measured_heat_joules"])

    def test_float_temperature_and_realized_heat_claim_reject(self) -> None:
        with self.assertRaises(ThermodynamicsContractError):
            PhysicalResetCalibration.create(
                "FLOAT",
                temperature_kelvin=300.0,  # type: ignore[arg-type]
                provenance="INVALID",
                reservoir_model="DECLARED_TEST_RESERVOIR",
                temperature_uncertainty_kelvin=0,
                reset_protocol="DECLARED_TEST_RESET_PROTOCOL",
                calibration_source="DECLARED_TEST_CALIBRATION_SOURCE",
            )
        with self.assertRaises(ThermodynamicsContractError):
            PhysicalResetCalibration(
                calibration_id="HEAT_CLAIM",
                temperature_kelvin=Fraction(300),
                provenance="INVALID_REALIZED_HEAT_CLAIM",
                reservoir_model="DECLARED_TEST_RESERVOIR",
                temperature_unit="K",
                temperature_uncertainty_kelvin=Fraction(0),
                reset_protocol="DECLARED_TEST_RESET_PROTOCOL",
                calibration_source="DECLARED_TEST_CALIBRATION_SOURCE",
                realized_heat_claimed=True,
            )


class ContractAndSerializationTests(unittest.TestCase):
    def test_logical_event_and_landauer_round_trip_strictly(self) -> None:
        event = LogicalResetEvent.uniform_irreversible_destruction(
            "SERIAL",
            2,
            destroyed_channels=("R",),
            source_law_provenance="DECLARED_UNIFORM_BIT",
        )
        calibration = PhysicalResetCalibration.create(
            "SERIAL_CAL",
            temperature_kelvin=Fraction(301, 2),
            provenance="EXACT_SERIALIZATION_TEST",
            reservoir_model="DECLARED_SERIAL_TEST_RESERVOIR",
            temperature_uncertainty_kelvin=Fraction(1, 20),
            reset_protocol="DECLARED_SERIAL_RESET_PROTOCOL",
            calibration_source="DECLARED_SERIAL_CALIBRATION_SOURCE",
        )
        receipt = landauer_lower_bound(event, calibration)
        self.assertEqual(LogicalResetEvent.from_dict(event.to_dict()), event)
        self.assertEqual(LandauerLowerBoundReceipt.from_dict(receipt.to_dict()), receipt)

        extra = event.to_dict()
        extra["temperature_kelvin"] = 300
        with self.assertRaises(ThermodynamicsContractError):
            LogicalResetEvent.from_dict(extra)

    def test_inconsistent_positive_erasure_contracts_reject(self) -> None:
        ln2 = FormalLogElement.from_positive_rational(2)
        with self.assertRaises(ThermodynamicsContractError):
            LogicalResetEvent(
                event_id="NO_CHANNEL",
                event_kind="IRREVERSIBLE_CHANNEL_DESTRUCTION",
                destroyed_channels=(),
                retained_channels=(),
                reconstructs_source_before_event=True,
                reconstructs_source_after_event=False,
                irreversible_destruction_declared=True,
                erased_information=ln2,
                source_law_provenance="DECLARED_UNIFORM_BIT",
                computation_basis="DECLARED_UNIFORM_FINITE_SOURCE",
            )
        with self.assertRaises(ThermodynamicsContractError):
            LogicalResetEvent(
                event_id="STILL_RECONSTRUCTS",
                event_kind="IRREVERSIBLE_CHANNEL_DESTRUCTION",
                destroyed_channels=("R",),
                retained_channels=(),
                reconstructs_source_before_event=True,
                reconstructs_source_after_event=True,
                irreversible_destruction_declared=True,
                erased_information=ln2,
                source_law_provenance="DECLARED_UNIFORM_BIT",
                computation_basis="DECLARED_UNIFORM_FINITE_SOURCE",
            )
        with self.assertRaises(ThermodynamicsContractError):
            LogicalResetEvent.uniform_irreversible_destruction(
                "FLOAT_M",
                2.0,  # type: ignore[arg-type]
                destroyed_channels=("R",),
                source_law_provenance="INVALID",
            )

    def test_tampered_calibrated_receipt_rejects(self) -> None:
        event = LogicalResetEvent.uniform_irreversible_destruction(
            "TAMPER_EVENT",
            2,
            destroyed_channels=("R",),
            source_law_provenance="DECLARED_UNIFORM_BIT",
        )
        calibration = PhysicalResetCalibration.create(
            "TAMPER_CAL",
            temperature_kelvin=300,
            provenance="EXACT_TEST_CALIBRATION",
            reservoir_model="DECLARED_TAMPER_TEST_RESERVOIR",
            temperature_uncertainty_kelvin=0,
            reset_protocol="DECLARED_TAMPER_RESET_PROTOCOL",
            calibration_source="DECLARED_TAMPER_CALIBRATION_SOURCE",
        )
        serialized = landauer_lower_bound(event, calibration).to_dict()
        serialized["exact_lower_bound_joules"] = "k_B*301*(ln(2)) J"
        with self.assertRaises(ThermodynamicsContractError):
            LandauerLowerBoundReceipt.from_dict(serialized)

    def test_receipt_system_projection_requires_irreversible_declaration(self) -> None:
        system, law = binary_receipt_system()
        with self.assertRaises(ThermodynamicsContractError):
            LogicalResetEvent.from_receipt_system(
                "WOULD_ERASE_ONLY",
                system,
                law,
                destroyed_channels=("ANTISYMMETRIC_HISTORY",),
                irreversible_destruction_declared=False,
            )


if __name__ == "__main__":
    unittest.main()
